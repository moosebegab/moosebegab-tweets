var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2016_11.js",
  "year" : 2016,
  "var_name" : "tweets_2016_11",
  "tweet_count" : 1940,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2016_10.js",
  "year" : 2016,
  "var_name" : "tweets_2016_10",
  "tweet_count" : 457,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2016_09.js",
  "year" : 2016,
  "var_name" : "tweets_2016_09",
  "tweet_count" : 382,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2016_08.js",
  "year" : 2016,
  "var_name" : "tweets_2016_08",
  "tweet_count" : 264,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2016_07.js",
  "year" : 2016,
  "var_name" : "tweets_2016_07",
  "tweet_count" : 248,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2016_06.js",
  "year" : 2016,
  "var_name" : "tweets_2016_06",
  "tweet_count" : 239,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2016_05.js",
  "year" : 2016,
  "var_name" : "tweets_2016_05",
  "tweet_count" : 247,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2016_04.js",
  "year" : 2016,
  "var_name" : "tweets_2016_04",
  "tweet_count" : 186,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2016_03.js",
  "year" : 2016,
  "var_name" : "tweets_2016_03",
  "tweet_count" : 536,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2016_02.js",
  "year" : 2016,
  "var_name" : "tweets_2016_02",
  "tweet_count" : 439,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2016_01.js",
  "year" : 2016,
  "var_name" : "tweets_2016_01",
  "tweet_count" : 319,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2015_12.js",
  "year" : 2015,
  "var_name" : "tweets_2015_12",
  "tweet_count" : 245,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2015_11.js",
  "year" : 2015,
  "var_name" : "tweets_2015_11",
  "tweet_count" : 292,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2015_10.js",
  "year" : 2015,
  "var_name" : "tweets_2015_10",
  "tweet_count" : 324,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2015_09.js",
  "year" : 2015,
  "var_name" : "tweets_2015_09",
  "tweet_count" : 282,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2015_08.js",
  "year" : 2015,
  "var_name" : "tweets_2015_08",
  "tweet_count" : 432,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2015_07.js",
  "year" : 2015,
  "var_name" : "tweets_2015_07",
  "tweet_count" : 322,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2015_06.js",
  "year" : 2015,
  "var_name" : "tweets_2015_06",
  "tweet_count" : 269,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2015_05.js",
  "year" : 2015,
  "var_name" : "tweets_2015_05",
  "tweet_count" : 237,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2015_04.js",
  "year" : 2015,
  "var_name" : "tweets_2015_04",
  "tweet_count" : 544,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2015_03.js",
  "year" : 2015,
  "var_name" : "tweets_2015_03",
  "tweet_count" : 590,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2015_02.js",
  "year" : 2015,
  "var_name" : "tweets_2015_02",
  "tweet_count" : 354,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2015_01.js",
  "year" : 2015,
  "var_name" : "tweets_2015_01",
  "tweet_count" : 519,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2014_12.js",
  "year" : 2014,
  "var_name" : "tweets_2014_12",
  "tweet_count" : 576,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2014_11.js",
  "year" : 2014,
  "var_name" : "tweets_2014_11",
  "tweet_count" : 424,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2014_10.js",
  "year" : 2014,
  "var_name" : "tweets_2014_10",
  "tweet_count" : 459,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2014_09.js",
  "year" : 2014,
  "var_name" : "tweets_2014_09",
  "tweet_count" : 598,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2014_08.js",
  "year" : 2014,
  "var_name" : "tweets_2014_08",
  "tweet_count" : 461,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2014_07.js",
  "year" : 2014,
  "var_name" : "tweets_2014_07",
  "tweet_count" : 711,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2014_06.js",
  "year" : 2014,
  "var_name" : "tweets_2014_06",
  "tweet_count" : 357,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2014_05.js",
  "year" : 2014,
  "var_name" : "tweets_2014_05",
  "tweet_count" : 138,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2014_04.js",
  "year" : 2014,
  "var_name" : "tweets_2014_04",
  "tweet_count" : 653,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2014_03.js",
  "year" : 2014,
  "var_name" : "tweets_2014_03",
  "tweet_count" : 607,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2014_02.js",
  "year" : 2014,
  "var_name" : "tweets_2014_02",
  "tweet_count" : 625,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2014_01.js",
  "year" : 2014,
  "var_name" : "tweets_2014_01",
  "tweet_count" : 108,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2013_12.js",
  "year" : 2013,
  "var_name" : "tweets_2013_12",
  "tweet_count" : 297,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2013_11.js",
  "year" : 2013,
  "var_name" : "tweets_2013_11",
  "tweet_count" : 381,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2013_10.js",
  "year" : 2013,
  "var_name" : "tweets_2013_10",
  "tweet_count" : 512,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2013_09.js",
  "year" : 2013,
  "var_name" : "tweets_2013_09",
  "tweet_count" : 474,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2013_08.js",
  "year" : 2013,
  "var_name" : "tweets_2013_08",
  "tweet_count" : 231,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2013_07.js",
  "year" : 2013,
  "var_name" : "tweets_2013_07",
  "tweet_count" : 195,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2013_06.js",
  "year" : 2013,
  "var_name" : "tweets_2013_06",
  "tweet_count" : 565,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2013_05.js",
  "year" : 2013,
  "var_name" : "tweets_2013_05",
  "tweet_count" : 322,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2013_04.js",
  "year" : 2013,
  "var_name" : "tweets_2013_04",
  "tweet_count" : 306,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2013_03.js",
  "year" : 2013,
  "var_name" : "tweets_2013_03",
  "tweet_count" : 465,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2013_02.js",
  "year" : 2013,
  "var_name" : "tweets_2013_02",
  "tweet_count" : 417,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2013_01.js",
  "year" : 2013,
  "var_name" : "tweets_2013_01",
  "tweet_count" : 323,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2012_12.js",
  "year" : 2012,
  "var_name" : "tweets_2012_12",
  "tweet_count" : 412,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2012_11.js",
  "year" : 2012,
  "var_name" : "tweets_2012_11",
  "tweet_count" : 544,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2012_10.js",
  "year" : 2012,
  "var_name" : "tweets_2012_10",
  "tweet_count" : 618,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2012_09.js",
  "year" : 2012,
  "var_name" : "tweets_2012_09",
  "tweet_count" : 668,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2012_08.js",
  "year" : 2012,
  "var_name" : "tweets_2012_08",
  "tweet_count" : 161,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2012_07.js",
  "year" : 2012,
  "var_name" : "tweets_2012_07",
  "tweet_count" : 408,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2012_06.js",
  "year" : 2012,
  "var_name" : "tweets_2012_06",
  "tweet_count" : 412,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2012_05.js",
  "year" : 2012,
  "var_name" : "tweets_2012_05",
  "tweet_count" : 820,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2012_04.js",
  "year" : 2012,
  "var_name" : "tweets_2012_04",
  "tweet_count" : 728,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2012_03.js",
  "year" : 2012,
  "var_name" : "tweets_2012_03",
  "tweet_count" : 834,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2012_02.js",
  "year" : 2012,
  "var_name" : "tweets_2012_02",
  "tweet_count" : 388,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2012_01.js",
  "year" : 2012,
  "var_name" : "tweets_2012_01",
  "tweet_count" : 548,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2011_12.js",
  "year" : 2011,
  "var_name" : "tweets_2011_12",
  "tweet_count" : 706,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2011_11.js",
  "year" : 2011,
  "var_name" : "tweets_2011_11",
  "tweet_count" : 742,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2011_10.js",
  "year" : 2011,
  "var_name" : "tweets_2011_10",
  "tweet_count" : 653,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2011_09.js",
  "year" : 2011,
  "var_name" : "tweets_2011_09",
  "tweet_count" : 268,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2011_08.js",
  "year" : 2011,
  "var_name" : "tweets_2011_08",
  "tweet_count" : 165,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2011_07.js",
  "year" : 2011,
  "var_name" : "tweets_2011_07",
  "tweet_count" : 75,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2011_06.js",
  "year" : 2011,
  "var_name" : "tweets_2011_06",
  "tweet_count" : 502,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2011_05.js",
  "year" : 2011,
  "var_name" : "tweets_2011_05",
  "tweet_count" : 575,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2011_04.js",
  "year" : 2011,
  "var_name" : "tweets_2011_04",
  "tweet_count" : 539,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2011_03.js",
  "year" : 2011,
  "var_name" : "tweets_2011_03",
  "tweet_count" : 341,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2011_02.js",
  "year" : 2011,
  "var_name" : "tweets_2011_02",
  "tweet_count" : 711,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2011_01.js",
  "year" : 2011,
  "var_name" : "tweets_2011_01",
  "tweet_count" : 972,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2010_12.js",
  "year" : 2010,
  "var_name" : "tweets_2010_12",
  "tweet_count" : 815,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2010_11.js",
  "year" : 2010,
  "var_name" : "tweets_2010_11",
  "tweet_count" : 172,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2010_10.js",
  "year" : 2010,
  "var_name" : "tweets_2010_10",
  "tweet_count" : 642,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2010_09.js",
  "year" : 2010,
  "var_name" : "tweets_2010_09",
  "tweet_count" : 847,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2010_08.js",
  "year" : 2010,
  "var_name" : "tweets_2010_08",
  "tweet_count" : 1023,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2010_07.js",
  "year" : 2010,
  "var_name" : "tweets_2010_07",
  "tweet_count" : 959,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2010_06.js",
  "year" : 2010,
  "var_name" : "tweets_2010_06",
  "tweet_count" : 1628,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2010_05.js",
  "year" : 2010,
  "var_name" : "tweets_2010_05",
  "tweet_count" : 1348,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2010_04.js",
  "year" : 2010,
  "var_name" : "tweets_2010_04",
  "tweet_count" : 1548,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2010_03.js",
  "year" : 2010,
  "var_name" : "tweets_2010_03",
  "tweet_count" : 1602,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2010_02.js",
  "year" : 2010,
  "var_name" : "tweets_2010_02",
  "tweet_count" : 1577,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2010_01.js",
  "year" : 2010,
  "var_name" : "tweets_2010_01",
  "tweet_count" : 744,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2009_12.js",
  "year" : 2009,
  "var_name" : "tweets_2009_12",
  "tweet_count" : 132,
  "month" : 12
} ]