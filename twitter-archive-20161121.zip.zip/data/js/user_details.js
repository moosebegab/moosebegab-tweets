var user_details =  {
  "screen_name" : "moosebegab",
  "location" : "Millbrook, New York",
  "full_name" : "Gabrielle P Campbell",
  "bio" : "I love animals, nature, reading, staying at home. Excitement is NOT my middle name. Fat, lazy cow. Anarchist.",
  "id" : "93747129",
  "created_at" : "2009-12-01 00:25:03 +0000"
}