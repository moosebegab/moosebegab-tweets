Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29325145978",
  "text" : "RT @abe_quotes: There r so many who believe that it is more important that their child fit into society than that their child resonate w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29324764385",
    "text" : "There r so many who believe that it is more important that their child fit into society than that their child resonate w\/ their own Source.",
    "id" : 29324764385,
    "created_at" : "2010-11-01 00:18:11 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 29325145978,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 3, 19 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29336851437",
  "text" : "RT @simonwoodwrites: My dog loves Halloween. He's convinced it's the night children come to the house to pet him and tell him he's pretty.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29336074962",
    "text" : "My dog loves Halloween. He's convinced it's the night children come to the house to pet him and tell him he's pretty.",
    "id" : 29336074962,
    "created_at" : "2010-11-01 02:47:47 +0000",
    "user" : {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "protected" : false,
      "id_str" : "30077179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786815188955570176\/XPC8uW7z_normal.jpg",
      "id" : 30077179,
      "verified" : false
    }
  },
  "id" : 29336851437,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29397109042",
  "text" : "To live as equals with dogs requires treating them, for lack of a better phrase, like human beings. http:\/\/bit.ly\/9Bjk3d",
  "id" : 29397109042,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29204917434",
  "text" : "FREE Amazon $3 Credit for MP3s (US only) exp Nov 1 http:\/\/bit.ly\/ay5RP6",
  "id" : 29204917434,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29213746921",
  "text" : "RT @Wylieknowords: Why? Tea Baggers call health care Socialism but they don't call the 2 wars Socialistic Wars,roads Socialistic Highway ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29212608753",
    "text" : "Why? Tea Baggers call health care Socialism but they don't call the 2 wars Socialistic Wars,roads Socialistic Highways,Socialistic Nat Parks",
    "id" : 29212608753,
    "created_at" : "2010-10-30 19:48:44 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 29213746921,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 7, 21 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29213936630",
  "text" : "LOL RT @Unique_Misfit: I was in the menswear section at work today and I'll tell you something, men are hard to assist while shopping.",
  "id" : 29213936630,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29215395272",
  "text" : "Cute cats play pattycake http:\/\/bit.ly\/aLUuJ4",
  "id" : 29215395272,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29227437469",
  "text" : "@UncleTweety Thanks for the message letting me know. : ) Love 2 follow you!",
  "id" : 29227437469,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29228208062",
  "text" : "RT @BooksOnTheKnob: Get $3 in Free MP3's at Amazon http:\/\/bit.ly\/cQnPvM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29227694600",
    "text" : "Get $3 in Free MP3's at Amazon http:\/\/bit.ly\/cQnPvM",
    "id" : 29227694600,
    "created_at" : "2010-10-30 23:48:08 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 29228208062,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 0, 8 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29044563020",
  "geo" : { },
  "id_str" : "29048453712",
  "in_reply_to_user_id" : 7339162,
  "text" : "@arphaus I'm so sorry. It shouldn't be that way. ((hugs))",
  "id" : 29048453712,
  "in_reply_to_status_id" : 29044563020,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "thisisarp",
  "in_reply_to_user_id_str" : "7339162",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29048493163",
  "text" : "RT @Wylieknowords: An oyster can change its sex from male to female and back again many times during its lifetime.  N. Wylie Jones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29044819504",
    "text" : "An oyster can change its sex from male to female and back again many times during its lifetime.  N. Wylie Jones",
    "id" : 29044819504,
    "created_at" : "2010-10-29 01:43:14 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 29048493163,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigi Driggers",
      "screen_name" : "Vampiregigi",
      "indices" : [ 3, 15 ],
      "id_str" : "30769522",
      "id" : 30769522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29048591398",
  "text" : "RT @Vampiregigi: You shouldn't judge someone at all, you haven't lived their past, mind your own journey!!! :\u20AC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29045235856",
    "text" : "You shouldn't judge someone at all, you haven't lived their past, mind your own journey!!! :\u20AC",
    "id" : 29045235856,
    "created_at" : "2010-10-29 01:48:29 +0000",
    "user" : {
      "name" : "Gigi Driggers",
      "screen_name" : "Vampiregigi",
      "protected" : false,
      "id_str" : "30769522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/322129446\/92608_012_normal.JPG",
      "id" : 30769522,
      "verified" : false
    }
  },
  "id" : 29048591398,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigi Driggers",
      "screen_name" : "Vampiregigi",
      "indices" : [ 3, 15 ],
      "id_str" : "30769522",
      "id" : 30769522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29048603837",
  "text" : "RT @Vampiregigi: I saw a tweet that said you shouldn't judge someone until you know them. I think......",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29045156937",
    "text" : "I saw a tweet that said you shouldn't judge someone until you know them. I think......",
    "id" : 29045156937,
    "created_at" : "2010-10-29 01:47:29 +0000",
    "user" : {
      "name" : "Gigi Driggers",
      "screen_name" : "Vampiregigi",
      "protected" : false,
      "id_str" : "30769522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/322129446\/92608_012_normal.JPG",
      "id" : 30769522,
      "verified" : false
    }
  },
  "id" : 29048603837,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29133068983",
  "text" : "RT @CoyoteSings: \/\/ ghosts of old dogs \u2022 sleeping \u2022 at the foot of my bed \/\/ #haiku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 60, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29130261997",
    "text" : "\/\/ ghosts of old dogs \u2022 sleeping \u2022 at the foot of my bed \/\/ #haiku",
    "id" : 29130261997,
    "created_at" : "2010-10-29 22:56:38 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 29133068983,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28943204249",
  "text" : "Love it! RT @WhiteRoseWiccan: Doing what I do best! http:\/\/yfrog.com\/5x4jlj",
  "id" : 28943204249,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28943448741",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan I'm not going to get around to making the spirit mask... I'm sorry!",
  "id" : 28943448741,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28943845605",
  "text" : "I feel like I've been away a lot longer.. Not that I've been away, just occupied w other things.",
  "id" : 28943845605,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28943760792",
  "geo" : { },
  "id_str" : "28944030782",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan I started to but then ppl came into room.. Have to remember to do again.. Lol",
  "id" : 28944030782,
  "in_reply_to_status_id" : 28943760792,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28988106379",
  "text" : "Mmm! MT @sacredsuds: Made more milk & honey soap yesterday.  I love this soap - it's so comforting and natural http:\/\/fb.me\/JyQCyMPR",
  "id" : 28988106379,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28988283778",
  "text" : "Got tree ppl outside house today. Hope they are not here all day.. (no offense 2 tree ppl just don't like activity around me)",
  "id" : 28988283778,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28988714113",
  "text" : "After 3 yrs of Hell, weird but very nice to have DD \"content\" w this school year. She's doing well all around! So very grateful!!",
  "id" : 28988714113,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK Rising",
      "screen_name" : "DKRising",
      "indices" : [ 3, 12 ],
      "id_str" : "716678263855267840",
      "id" : 716678263855267840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29010424143",
  "text" : "RT @DKRising: I hope it's normal to talk to your Halloween decorations. I think it's only a problem if they talk back.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29007346535",
    "text" : "I hope it's normal to talk to your Halloween decorations. I think it's only a problem if they talk back.",
    "id" : 29007346535,
    "created_at" : "2010-10-28 17:06:51 +0000",
    "user" : {
      "name" : "DK",
      "screen_name" : "horseandahalf",
      "protected" : false,
      "id_str" : "28032888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2250219073\/3622258089_0d9032f127_b_normal.jpg",
      "id" : 28032888,
      "verified" : false
    }
  },
  "id" : 29010424143,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa-BarkTalk.com",
      "screen_name" : "BarkTalk",
      "indices" : [ 3, 12 ],
      "id_str" : "20888772",
      "id" : 20888772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29010516612",
  "text" : "RT @BarkTalk: FUNNY t-shirt!  Your dog doesn't know sit.  BOL! http:\/\/twitpic.com\/31mml9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29007309873",
    "text" : "FUNNY t-shirt!  Your dog doesn't know sit.  BOL! http:\/\/twitpic.com\/31mml9",
    "id" : 29007309873,
    "created_at" : "2010-10-28 17:06:21 +0000",
    "user" : {
      "name" : "Lisa-BarkTalk.com",
      "screen_name" : "BarkTalk",
      "protected" : false,
      "id_str" : "20888772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1154466432\/IMG_8387_normal.JPG",
      "id" : 20888772,
      "verified" : false
    }
  },
  "id" : 29010516612,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29010628131",
  "text" : "Stop running. They'll fly by if you let them. RT @akaAshkuff: ...just can't seem to outrun his doubts.",
  "id" : 29010628131,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BaltimoreGal",
      "screen_name" : "BaltimoreGal",
      "indices" : [ 3, 16 ],
      "id_str" : "12224342",
      "id" : 12224342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29010670911",
  "text" : "RT @BaltimoreGal: AR school board member says only way he'll wear purple is if all gays kill themselves. Call for his resignation: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HumanRightsCampaign",
        "screen_name" : "HRC",
        "indices" : [ 134, 138 ],
        "id_str" : "19608297",
        "id" : 19608297
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29008241515",
    "text" : "AR school board member says only way he'll wear purple is if all gays kill themselves. Call for his resignation: http:\/\/bit.ly\/cym3QV @HRC",
    "id" : 29008241515,
    "created_at" : "2010-10-28 17:18:56 +0000",
    "user" : {
      "name" : "BaltimoreGal",
      "screen_name" : "BaltimoreGal",
      "protected" : false,
      "id_str" : "12224342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797863635838242816\/cd0GNtF2_normal.jpg",
      "id" : 12224342,
      "verified" : false
    }
  },
  "id" : 29010670911,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 27, 40 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mynatgivaway",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "itunes",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29010683050",
  "text" : "RT @MyNatureApps: Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway #itunes Enter here -&gt; http:\/\/tinyurl.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff",
        "screen_name" : "MyNatureApps",
        "indices" : [ 9, 22 ],
        "id_str" : "93072985",
        "id" : 93072985
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mynatgivaway",
        "indices" : [ 62, 75 ]
      }, {
        "text" : "itunes",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29008722801",
    "text" : "Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway #itunes Enter here -&gt; http:\/\/tinyurl.com\/22uoqsp",
    "id" : 29008722801,
    "created_at" : "2010-10-28 17:25:37 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 29010683050,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29020392339",
  "text" : "RT @squintinginfog: I want something and I don't know what it is & I'm going to consume far too many calories trying to figure it out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29018809734",
    "text" : "I want something and I don't know what it is & I'm going to consume far too many calories trying to figure it out.",
    "id" : 29018809734,
    "created_at" : "2010-10-28 20:00:03 +0000",
    "user" : {
      "name" : "Christi Bowman",
      "screen_name" : "fastingfoody",
      "protected" : false,
      "id_str" : "199743576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499337090\/fastingfoody_normal.jpg",
      "id" : 199743576,
      "verified" : false
    }
  },
  "id" : 29020392339,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gogyohka",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29020580106",
  "text" : "RT @CoyoteSings: \/\/ ravens \u2022 arguing \u2022 with crows \u2022 over \u2022 who owns the night \/\/ #gogyohka",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gogyohka",
        "indices" : [ 64, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29020146092",
    "text" : "\/\/ ravens \u2022 arguing \u2022 with crows \u2022 over \u2022 who owns the night \/\/ #gogyohka",
    "id" : 29020146092,
    "created_at" : "2010-10-28 20:20:41 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 29020580106,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29010899414",
  "geo" : { },
  "id_str" : "29020604091",
  "in_reply_to_user_id" : 199743576,
  "text" : "@squintinginfog muah! : )",
  "id" : 29020604091,
  "in_reply_to_status_id" : 29010899414,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "fastingfoody",
  "in_reply_to_user_id_str" : "199743576",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28930561173",
  "text" : "Carole's Thoughtful Spot: Can You Guess What This Is? http:\/\/bit.ly\/95655I",
  "id" : 28930561173,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28891020305",
  "text" : "@tragic_pizza glad it wasn't more serious. ((hugs))",
  "id" : 28891020305,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28822736006",
  "text" : "I've hardly been on twitter at all past few days.. Weird!! Been working on my computer (websites) and stuff..",
  "id" : 28822736006,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aspergers",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28822884345",
  "text" : "Both DD & I took Autism Spectrum Quotient on Facebook. She scored 30. I got 35. Avg is 15. #Aspergers",
  "id" : 28822884345,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28823072655",
  "text" : "RT @bunnybuddhism: Too much intellectualism closes the bunny heart.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28821775295",
    "text" : "Too much intellectualism closes the bunny heart.",
    "id" : 28821775295,
    "created_at" : "2010-10-26 20:13:19 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 28823072655,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28823121858",
  "text" : "The Autism Spectrum Quotient Test on Facebook http:\/\/bit.ly\/bgPQ2y",
  "id" : 28823121858,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28823152357",
  "text" : "Autism Spectrum Quotient - Wikipedia, the free encyclopedia http:\/\/bit.ly\/b9fpsi",
  "id" : 28823152357,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28823865658",
  "text" : "@ThePlushGourmet Autism-Spectrum Quotient on wired.com http:\/\/bit.ly\/crdwH1 (see prev tweets for test on facebook, wiki link)",
  "id" : 28823865658,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28823897144",
  "geo" : { },
  "id_str" : "28824247546",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yay someone missed me! ((hugs))",
  "id" : 28824247546,
  "in_reply_to_status_id" : 28823897144,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28644191844",
  "geo" : { },
  "id_str" : "28645581975",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves How about a nice ((hug))? : )",
  "id" : 28645581975,
  "in_reply_to_status_id" : 28644191844,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28645635752",
  "text" : "@akaAshkuff ewwwwww.. that's not normal, is it? hope its ok.",
  "id" : 28645635752,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMGFacts Celebs",
      "screen_name" : "OMGFactsCelebs",
      "indices" : [ 3, 18 ],
      "id_str" : "705411897323970560",
      "id" : 705411897323970560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28645658725",
  "text" : "RT @OMGFactsCelebs: The computers on The Office are actually connected to the Internet. Cast members admitted to surfing the web during  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tplus.me\" rel=\"nofollow\"\u003EtPlus.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28543330444",
    "text" : "The computers on The Office are actually connected to the Internet. Cast members admitted to surfing the web during the filming of scenes.",
    "id" : 28543330444,
    "created_at" : "2010-10-23 23:30:01 +0000",
    "user" : {
      "name" : "Dose Hollywood",
      "screen_name" : "DoseOfHollywood",
      "protected" : false,
      "id_str" : "184648622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705417258235875328\/f3xWXtH1_normal.jpg",
      "id" : 184648622,
      "verified" : false
    }
  },
  "id" : 28645658725,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28645869496",
  "text" : "chocolate ice cream mixed with cheerios.. yum!!",
  "id" : 28645869496,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28646375505",
  "text" : "RT @cancertusk: is this new covert wave of h1n1 vaccination a fresh attempt to kickstart the depopulation agenda?..have jab,get ill,its  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28628206267",
    "text" : "is this new covert wave of h1n1 vaccination a fresh attempt to kickstart the depopulation agenda?..have jab,get ill,its that simple.",
    "id" : 28628206267,
    "created_at" : "2010-10-24 21:00:54 +0000",
    "user" : {
      "name" : "AirArsehole Skum",
      "screen_name" : "eclypticlunacy",
      "protected" : false,
      "id_str" : "157481845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1227802825\/gasmask2_normal.jpg",
      "id" : 157481845,
      "verified" : false
    }
  },
  "id" : 28646375505,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28646960152",
  "text" : "RT @WarriorBanker: What do you think about formspring.me so far? \u2014 It'd be better if more people asked questions. The canned ones are\u2026 h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/spring.me\" rel=\"nofollow\"\u003ESpring.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28646244204",
    "text" : "What do you think about formspring.me so far? \u2014 It'd be better if more people asked questions. The canned ones are\u2026 http:\/\/4ms.me\/bFcRJT",
    "id" : 28646244204,
    "created_at" : "2010-10-25 01:06:28 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 28646960152,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feels Like Home Blog",
      "screen_name" : "FeelsLikeHome",
      "indices" : [ 3, 17 ],
      "id_str" : "290598968",
      "id" : 290598968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "savvyblogging",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28647404913",
  "text" : "RT @FeelsLikeHome: I'm feeling silly about admitting this, but I don't know how to create a template in Wordpress. Help! #savvyblogging  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "savvyblogging",
        "indices" : [ 102, 116 ]
      }, {
        "text" : "relevant10",
        "indices" : [ 117, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28645361802",
    "text" : "I'm feeling silly about admitting this, but I don't know how to create a template in Wordpress. Help! #savvyblogging #relevant10",
    "id" : 28645361802,
    "created_at" : "2010-10-25 00:55:05 +0000",
    "user" : {
      "name" : "Tara Ziegmont",
      "screen_name" : "TaraZiegmont",
      "protected" : false,
      "id_str" : "15366424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744931435895730176\/DUfvBhzX_normal.jpg",
      "id" : 15366424,
      "verified" : false
    }
  },
  "id" : 28647404913,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 0, 16 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28715701929",
  "geo" : { },
  "id_str" : "28716721710",
  "in_reply_to_user_id" : 30077179,
  "text" : "@simonwoodwrites RIP Bug. ((hugs))",
  "id" : 28716721710,
  "in_reply_to_status_id" : 28715701929,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "simonwoodwrites",
  "in_reply_to_user_id_str" : "30077179",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28546404011",
  "text" : "Hubby just came home. I said FEED ME. He's like.. You didn't eat? I give him funny look. Like I'd feed myself?? Sigh.",
  "id" : 28546404011,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 15, 27 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28554650402",
  "text" : "Nice smile! RT @mindymayhem: Bailey! Marty's Dutch Shepherd-Grayhound mix we worked with today http:\/\/twitpic.com\/30aq16",
  "id" : 28554650402,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28554817038",
  "text" : "Had PB & honey sandwich 4 dinner just now. Sigh.",
  "id" : 28554817038,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28554867694",
  "text" : "I gave up watching Saw. It was irritating my aura.",
  "id" : 28554867694,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "rodney",
      "screen_name" : "rodney_at_large",
      "indices" : [ 15, 31 ],
      "id_str" : "149308499",
      "id" : 149308499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28554960982",
  "text" : "RT @BestAt: RT @rodney_at_large: Look, this isn't working for me. I think it's time we follow other people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rodney",
        "screen_name" : "rodney_at_large",
        "indices" : [ 3, 19 ],
        "id_str" : "149308499",
        "id" : 149308499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28554521045",
    "text" : "RT @rodney_at_large: Look, this isn't working for me. I think it's time we follow other people.",
    "id" : 28554521045,
    "created_at" : "2010-10-24 02:06:54 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 28554960982,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28554997723",
  "text" : "RT @Mahala: I am being bitched at because I do not barf properly. Who knew there were rules??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28554677241",
    "text" : "I am being bitched at because I do not barf properly. Who knew there were rules??",
    "id" : 28554677241,
    "created_at" : "2010-10-24 02:09:02 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 28554997723,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Siler",
      "screen_name" : "TrueLoveQuest",
      "indices" : [ 0, 14 ],
      "id_str" : "117213782",
      "id" : 117213782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28546555747",
  "geo" : { },
  "id_str" : "28555227318",
  "in_reply_to_user_id" : 117213782,
  "text" : "@TrueLoveQuest not sure if empathy sigh or sigh of \"why can't this dame feed herself\" but thanks 4 reply either way : )",
  "id" : 28555227318,
  "in_reply_to_status_id" : 28546555747,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "TrueLoveQuest",
  "in_reply_to_user_id_str" : "117213782",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28555256011",
  "geo" : { },
  "id_str" : "28555569830",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I usually don't watch much on tv. Prefer my pc or books.",
  "id" : 28555569830,
  "in_reply_to_status_id" : 28555256011,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28617083306",
  "text" : "nothing like hearing a tree cracking and waiting to die... ((heartinthroat))",
  "id" : 28617083306,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28617336470",
  "text" : "I am very grateful no one is hurt and no holes, cracks on inside of house.. no wires pulled down either. Just very startling. Need valium!",
  "id" : 28617336470,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unknown.",
      "screen_name" : "dark_intruder",
      "indices" : [ 0, 14 ],
      "id_str" : "1186382574",
      "id" : 1186382574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28618285196",
  "text" : "@Dark_Intruder I heard about it awhile ago.. creepy yet fascinating in a creepy way..lol",
  "id" : 28618285196,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28618554602",
  "text" : "RT @wow_trees: A girl asked him why he was wearing so much purple & after he explained it, she said, \"but why do you care? Gay people DE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28618405749",
    "text" : "A girl asked him why he was wearing so much purple & after he explained it, she said, \"but why do you care? Gay people DESERVE to die.\"",
    "id" : 28618405749,
    "created_at" : "2010-10-24 18:38:06 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 28618554602,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unknown.",
      "screen_name" : "dark_intruder",
      "indices" : [ 0, 14 ],
      "id_str" : "1186382574",
      "id" : 1186382574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28618738125",
  "text" : "@Dark_Intruder I'll be interested to see what you think. I was watching Saw last night but the torture got to me..",
  "id" : 28618738125,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28619046579",
  "text" : "Now poor hubs is outside cutting up tree parts.. Like he doesn't have enough to do.. But still.. We are ok.",
  "id" : 28619046579,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unknown.",
      "screen_name" : "dark_intruder",
      "indices" : [ 0, 14 ],
      "id_str" : "1186382574",
      "id" : 1186382574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28619986332",
  "text" : "@Dark_Intruder No. just fell out of the blue. luckily was only half the tree.. the whole tree would have come thru roof.",
  "id" : 28619986332,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unknown.",
      "screen_name" : "dark_intruder",
      "indices" : [ 0, 14 ],
      "id_str" : "1186382574",
      "id" : 1186382574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28620224473",
  "text" : "@Dark_Intruder I think Im calmed down now..lol.. Amazing hubby's taking it in stride. He's really mellowed out. : )",
  "id" : 28620224473,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 3, 18 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28621383088",
  "text" : "RT @JonathanElliot: Sobering.  Show this to your kids. Documentary on Hiroshima bomb (cool special effects) http:\/\/youtu.be\/x9lwvImJqT0  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28619352774",
    "text" : "Sobering.  Show this to your kids. Documentary on Hiroshima bomb (cool special effects) http:\/\/youtu.be\/x9lwvImJqT0  Never again?",
    "id" : 28619352774,
    "created_at" : "2010-10-24 18:52:01 +0000",
    "user" : {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "protected" : false,
      "id_str" : "30825946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1534911961\/black_square_normal.jpg",
      "id" : 30825946,
      "verified" : false
    }
  },
  "id" : 28621383088,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28621553573",
  "text" : "wow.. ppl vaporized in an instant from the H-bomb. they were the lucky ones. one second alive, next sec not.. prob didnt know what happened.",
  "id" : 28621553573,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28621616961",
  "text" : "the ones that survived suffering from burns, rad poisoning.. sigh.",
  "id" : 28621616961,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28621558341",
  "geo" : { },
  "id_str" : "28621755519",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yes.. everything\/everyone ok. house ok. just very startling to hear that crack and not know where it is...",
  "id" : 28621755519,
  "in_reply_to_status_id" : 28621558341,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28621558341",
  "geo" : { },
  "id_str" : "28621833222",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts amazing it didnt do more damage. caught corner of house. like an angel caught it and layed it down gently..lol",
  "id" : 28621833222,
  "in_reply_to_status_id" : 28621558341,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Mark Sutherland",
      "screen_name" : "BreakThruGuy",
      "indices" : [ 3, 16 ],
      "id_str" : "21080122",
      "id" : 21080122
    }, {
      "name" : "Sinan Si Alhir",
      "screen_name" : "SAlhir",
      "indices" : [ 21, 28 ],
      "id_str" : "724031614540353536",
      "id" : 724031614540353536
    }, {
      "name" : "BILLY COX",
      "screen_name" : "Billy_Cox",
      "indices" : [ 32, 42 ],
      "id_str" : "23249204",
      "id" : 23249204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28621886826",
  "text" : "RT @BreakThruGuy: RT @SAlhir RT @Billy_Cox: There are no mistakes, no coincidences, all events are given to us to learn from. Elizabeth  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sinan Si Alhir",
        "screen_name" : "SAlhir",
        "indices" : [ 3, 10 ],
        "id_str" : "724031614540353536",
        "id" : 724031614540353536
      }, {
        "name" : "BILLY COX",
        "screen_name" : "Billy_Cox",
        "indices" : [ 14, 24 ],
        "id_str" : "23249204",
        "id" : 23249204
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 125, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28621624182",
    "text" : "RT @SAlhir RT @Billy_Cox: There are no mistakes, no coincidences, all events are given to us to learn from. Elizabeth K Ross #quote",
    "id" : 28621624182,
    "created_at" : "2010-10-24 19:24:50 +0000",
    "user" : {
      "name" : "Paul Mark Sutherland",
      "screen_name" : "BreakThruGuy",
      "protected" : false,
      "id_str" : "21080122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3410134896\/0c44288b7f54c8cf1b7d618b9e068aa1_normal.png",
      "id" : 21080122,
      "verified" : false
    }
  },
  "id" : 28621886826,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28621937655",
  "geo" : { },
  "id_str" : "28622164018",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts no storm today. cloudy, cool.",
  "id" : 28622164018,
  "in_reply_to_status_id" : 28621937655,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "donni saphire",
      "screen_name" : "donni",
      "indices" : [ 15, 21 ],
      "id_str" : "4230121",
      "id" : 4230121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28623296413",
  "text" : "RT @BestAt: RT @donni: I wonder what trees did to get grounded for life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "donni saphire",
        "screen_name" : "donni",
        "indices" : [ 3, 9 ],
        "id_str" : "4230121",
        "id" : 4230121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28622471444",
    "text" : "RT @donni: I wonder what trees did to get grounded for life.",
    "id" : 28622471444,
    "created_at" : "2010-10-24 19:37:07 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 28623296413,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28622931771",
  "geo" : { },
  "id_str" : "28623490722",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts one part ripped from the other and fell.",
  "id" : 28623490722,
  "in_reply_to_status_id" : 28622931771,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 25, 38 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28625536642",
  "text" : "using the tree id app by @MyNatureApps , I was able to determine it was a sugar maple that fell on my house..lol.. poor tree.",
  "id" : 28625536642,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETSY",
      "indices" : [ 106, 111 ]
    }, {
      "text" : "TOTES",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28625752268",
  "text" : "RT @PeggySueCusses: Extra Large Red Peacock Toile Tote fully lined by KatelynsKrafts http:\/\/bit.ly\/9yI2UQ #ETSY #TOTES New Listing Today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ETSY",
        "indices" : [ 86, 91 ]
      }, {
        "text" : "TOTES",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28623990820",
    "text" : "Extra Large Red Peacock Toile Tote fully lined by KatelynsKrafts http:\/\/bit.ly\/9yI2UQ #ETSY #TOTES New Listing Today",
    "id" : 28623990820,
    "created_at" : "2010-10-24 19:58:15 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 28625752268,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28626286846",
  "geo" : { },
  "id_str" : "28627549817",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps yes, yes I did. all is ok, tho. landed on corner of house. no inside damage so far. a big limb separated and fell. No storm.",
  "id" : 28627549817,
  "in_reply_to_status_id" : 28626286846,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28627640553",
  "text" : "I got chicken quesadilla for dinner - woohoo!! : )",
  "id" : 28627640553,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28630036861",
  "text" : "RT @mindymayhem: Lipsynching and interpretive torso dancing in the car to the delight of my brother and nieces in car and passerby.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28629704869",
    "text" : "Lipsynching and interpretive torso dancing in the car to the delight of my brother and nieces in car and passerby.",
    "id" : 28629704869,
    "created_at" : "2010-10-24 21:23:02 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 28630036861,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28541513924",
  "text" : "Also waiting 4 hubby 2 get home & FEED ME!!",
  "id" : 28541513924,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28527571628",
  "geo" : { },
  "id_str" : "28541586121",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts sorry, been off twitter this aft. working on computer",
  "id" : 28541586121,
  "in_reply_to_status_id" : 28527571628,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28544560235",
  "text" : "@HEATHENRABBIT awww, you're such a doll..lol",
  "id" : 28544560235,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28505587484",
  "text" : "what a good boy.. he made coffee before he left!",
  "id" : 28505587484,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Facts",
      "screen_name" : "OMGFactsAnimals",
      "indices" : [ 3, 19 ],
      "id_str" : "2403744476",
      "id" : 2403744476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28505743198",
  "text" : "RT @OMGFactsAnimals: The monarch butterfly can detect its lover's scent eight kilometers away.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tplus.me\" rel=\"nofollow\"\u003EtPlus.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28440482550",
    "text" : "The monarch butterfly can detect its lover's scent eight kilometers away.",
    "id" : 28440482550,
    "created_at" : "2010-10-22 21:16:02 +0000",
    "user" : {
      "name" : "Dose Animals",
      "screen_name" : "DoseofAnimals",
      "protected" : false,
      "id_str" : "184651802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705416109495709696\/0rNJfZMZ_normal.jpg",
      "id" : 184651802,
      "verified" : false
    }
  },
  "id" : 28505743198,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28505786757",
  "text" : "RT @bunnybuddhism: I am a bunny, and I do bunny things.  It doesn't make me good, bad, right, or wrong.  It just makes me a bunny.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28503491965",
    "text" : "I am a bunny, and I do bunny things.  It doesn't make me good, bad, right, or wrong.  It just makes me a bunny.",
    "id" : 28503491965,
    "created_at" : "2010-10-23 14:11:30 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 28505786757,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28505944506",
  "text" : "RT @MyNatureApps: First Snow, Adirondack Sunrise http:\/\/bit.ly\/9hCiuU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28503010663",
    "text" : "First Snow, Adirondack Sunrise http:\/\/bit.ly\/9hCiuU",
    "id" : 28503010663,
    "created_at" : "2010-10-23 14:05:39 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 28505944506,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28506611254",
  "text" : "@HEATHENRABBIT I remember that show! Was so good! lol",
  "id" : 28506611254,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28505920115",
  "geo" : { },
  "id_str" : "28506863237",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yeah, he does come in handy sometimes..lol",
  "id" : 28506863237,
  "in_reply_to_status_id" : 28505920115,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28507097926",
  "text" : "wondering why I am reading my twitter on the web the past two days.. much prefer twittering on my Touch..",
  "id" : 28507097926,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28507350274",
  "geo" : { },
  "id_str" : "28511430738",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I consider it a gift from my Dad as I used life ins. money 2 get it. I think he approves! Lol",
  "id" : 28511430738,
  "in_reply_to_status_id" : 28507350274,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28507350274",
  "geo" : { },
  "id_str" : "28511556164",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I also have a Sony 505. that wud b my snuggle bunny. I like 2 read in bed with it..lol. Gift from hubby. : )",
  "id" : 28511556164,
  "in_reply_to_status_id" : 28507350274,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 21, 36 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28511868053",
  "text" : "Need advil now... RT @ReformedBuddha: Owwww, this hurt my eyes http:\/\/i.imgur.com\/F9O5s.jpg",
  "id" : 28511868053,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28512058671",
  "text" : "My brain has missing connections. Can't make leap to AHA sometimes.",
  "id" : 28512058671,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28512217726",
  "text" : "Best way 2 describe me: half genius, half down syndrome. Explains why I am so strange for ppl..",
  "id" : 28512217726,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28511851477",
  "geo" : { },
  "id_str" : "28512595770",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yes I am.. I wud not survive w\/o hubby. I can't take care of myself really...",
  "id" : 28512595770,
  "in_reply_to_status_id" : 28511851477,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28513179016",
  "text" : "Miniature Art on the Tip of Pencil by Dalton Ghetti http:\/\/bit.ly\/9qZcf7",
  "id" : 28513179016,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28513509096",
  "text" : "I love the comment about how he changed his approach...\n\nWhen Dalton, from Connecticut, USA, first started he (cont) http:\/\/tl.gd\/6k9rqd",
  "id" : 28513509096,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28515786205",
  "text" : "The mouse has gotta go. I feel like Wile E Coyote...",
  "id" : 28515786205,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28516359033",
  "text" : "It's really annoying all the rules around ebooks... esp how you can only buy certain books if you live in a (cont) http:\/\/tl.gd\/6kabpe",
  "id" : 28516359033,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28516657439",
  "text" : "I didn't count the cheese slices but I had exact number of crackers! Coolio!!",
  "id" : 28516657439,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 11, 26 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28525786091",
  "text" : "SO CUTE RT @ReformedBuddha: No WAY!! http:\/\/i.imgur.com\/QR6my.gif",
  "id" : 28525786091,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "robert",
      "screen_name" : "bardorobot",
      "indices" : [ 23, 34 ],
      "id_str" : "54371019",
      "id" : 54371019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28525921811",
  "text" : "RT @KerriFar: Cute! RT @bardorobot: say hello to my little friend; he hung w\/ me for almost an hour this morning.  http:\/\/twitpic.com\/306pk2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "robert",
        "screen_name" : "bardorobot",
        "indices" : [ 9, 20 ],
        "id_str" : "54371019",
        "id" : 54371019
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28524505101",
    "text" : "Cute! RT @bardorobot: say hello to my little friend; he hung w\/ me for almost an hour this morning.  http:\/\/twitpic.com\/306pk2",
    "id" : 28524505101,
    "created_at" : "2010-10-23 18:35:10 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 28525921811,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 55, 69 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28526590322",
  "text" : "I think its cute but how you feel is important. : ) RT @Unique_Misfit: Not sure my haircut is nice. Whady'a think? http:\/\/twitpic.com\/30780e",
  "id" : 28526590322,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 0, 14 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28526732688",
  "geo" : { },
  "id_str" : "28526991721",
  "in_reply_to_user_id" : 159213309,
  "text" : "@Unique_Misfit aww, sorry yr not happy w it but it will grow out.",
  "id" : 28526991721,
  "in_reply_to_status_id" : 28526732688,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28538346748",
  "geo" : { },
  "id_str" : "28541011175",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem my, aren't you popular? ; ) ((jealous))",
  "id" : 28541011175,
  "in_reply_to_status_id" : 28538346748,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28541462164",
  "text" : "Watching Saw 3 after watching Saw 2",
  "id" : 28541462164,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew E. Kaufman",
      "screen_name" : "andrewekaufman",
      "indices" : [ 34, 49 ],
      "id_str" : "160072595",
      "id" : 160072595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28404242482",
  "text" : "\"Each day is a one-time offer.\" - @andrewekaufman http:\/\/bit.ly\/aVMAWL",
  "id" : 28404242482,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28406243690",
  "text" : "\"focus\" -book on finding simplicity in the age of distractions http:\/\/bit.ly\/cyKCHu free pdf ebook",
  "id" : 28406243690,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28427512278",
  "text" : "RT @WestofMars: it's a quiet day at Win a Book. Anyone got a giveaway you need me to list? A guest author interview or blog post?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28425918383",
    "text" : "it's a quiet day at Win a Book. Anyone got a giveaway you need me to list? A guest author interview or blog post?",
    "id" : 28425918383,
    "created_at" : "2010-10-22 17:42:21 +0000",
    "user" : {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "protected" : false,
      "id_str" : "34258680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454321783588413442\/gndVsGba_normal.png",
      "id" : 34258680,
      "verified" : false
    }
  },
  "id" : 28427512278,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28427659421",
  "text" : "RT @DarciaHelle: Total books for Indie Books Holiday Giveaway Event is now 267! Deadline to participate is Nov. 15. Details: darcia@quie ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28424920365",
    "text" : "Total books for Indie Books Holiday Giveaway Event is now 267! Deadline to participate is Nov. 15. Details: darcia@quietfurybooks.com",
    "id" : 28424920365,
    "created_at" : "2010-10-22 17:28:38 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 28427659421,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28431686760",
  "text" : "RT @ChrisCade: (video) Which wolf will you feed inside yourself? http:\/\/www.flickspire.com\/m\/ShareThis\/TwoWolves",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28430962044",
    "text" : "(video) Which wolf will you feed inside yourself? http:\/\/www.flickspire.com\/m\/ShareThis\/TwoWolves",
    "id" : 28430962044,
    "created_at" : "2010-10-22 18:54:20 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 28431686760,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Winograd",
      "screen_name" : "nwinograd",
      "indices" : [ 3, 13 ],
      "id_str" : "49656730",
      "id" : 49656730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28431865241",
  "text" : "RT @nwinograd: You can't kill your way to not killing: http:\/\/bit.ly\/973fMw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28429685582",
    "text" : "You can't kill your way to not killing: http:\/\/bit.ly\/973fMw",
    "id" : 28429685582,
    "created_at" : "2010-10-22 18:36:29 +0000",
    "user" : {
      "name" : "Nathan Winograd",
      "screen_name" : "nwinograd",
      "protected" : false,
      "id_str" : "49656730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2681062698\/40f8e0c0d2a0fbaf040ffde4a14fe243_normal.jpeg",
      "id" : 49656730,
      "verified" : false
    }
  },
  "id" : 28431865241,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "indices" : [ 3, 13 ],
      "id_str" : "14343511",
      "id" : 14343511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28433124504",
  "text" : "RT @lexsisney: So my 5 year old daughter blew my mind with her  take on the expansion of the Universe. http:\/\/bit.ly\/9jAJQl #physics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "physics",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28431905407",
    "text" : "So my 5 year old daughter blew my mind with her  take on the expansion of the Universe. http:\/\/bit.ly\/9jAJQl #physics",
    "id" : 28431905407,
    "created_at" : "2010-10-22 19:07:36 +0000",
    "user" : {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "protected" : false,
      "id_str" : "14343511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468433962952425472\/VU87Ljmz_normal.jpeg",
      "id" : 14343511,
      "verified" : false
    }
  },
  "id" : 28433124504,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28433756635",
  "geo" : { },
  "id_str" : "28445905310",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy Liar, liar, pants on fire! ; ) but thanks",
  "id" : 28445905310,
  "in_reply_to_status_id" : 28433756635,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28433714476",
  "geo" : { },
  "id_str" : "28445997304",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy taekwondo. hi-ya!! : )",
  "id" : 28445997304,
  "in_reply_to_status_id" : 28433714476,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28446090524",
  "text" : "I am itching like crazy today!",
  "id" : 28446090524,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28446296465",
  "text" : "hope the pecans arent bad...",
  "id" : 28446296465,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28446072499",
  "geo" : { },
  "id_str" : "28446464768",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy weird way of saying \"must be gab\".. I think mooses are cool and abfabgab was already taken O-o",
  "id" : 28446464768,
  "in_reply_to_status_id" : 28446072499,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28446583001",
  "text" : "RT @Dwayne_Reaves: To my friends \"For it was not into my ear you whispered, but into my heart. It was not my lips you kissed, but my sou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28446438574",
    "text" : "To my friends \"For it was not into my ear you whispered, but into my heart. It was not my lips you kissed, but my soul.\" Judy Garland",
    "id" : 28446438574,
    "created_at" : "2010-10-22 22:43:53 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 28446583001,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 18, 29 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28446603655",
  "text" : "RT @derekrootboy: @moosebegab What does moosebegab mean? Moose as in mutant reindeer? begab? Inciting mutant reindeer to talk? Am I on t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28446072499",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab What does moosebegab mean? Moose as in mutant reindeer? begab? Inciting mutant reindeer to talk? Am I on the right lines?",
    "id" : 28446072499,
    "created_at" : "2010-10-22 22:38:33 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 28446603655,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 17, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28449448457",
  "text" : "got so many nice #FF today and I was naughty.. did not do them today.",
  "id" : 28449448457,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28449777753",
  "text" : "wonder what happened to @jackdaw841 .. fellow crow lover?",
  "id" : 28449777753,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28040831554",
  "text" : "ok, I can still get my free meds. I like my new health care place. all is well.",
  "id" : 28040831554,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28049022665",
  "text" : "RT @ShhDragon: Rainy days are perfect for catching up with (falling asleep on) paperwork http:\/\/plixi.com\/p\/52004159",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28044955212",
    "text" : "Rainy days are perfect for catching up with (falling asleep on) paperwork http:\/\/plixi.com\/p\/52004159",
    "id" : 28044955212,
    "created_at" : "2010-10-21 17:13:54 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 28049022665,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28051140326",
  "text" : "@tragic_pizza hope you're having a good day! : )",
  "id" : 28051140326,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28044892376",
  "geo" : { },
  "id_str" : "28051441694",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan havent even started yet..lol. gave directions to hubby-cuz I need help!. maybe tomorrow or sunday he can help me start. : )",
  "id" : 28051441694,
  "in_reply_to_status_id" : 28044892376,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 18, 30 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28051649274",
  "geo" : { },
  "id_str" : "28051747470",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan  @Jeweldspear havent been on twitter much today so I think I missed that one. altho brain forgets easy, too!",
  "id" : 28051747470,
  "in_reply_to_status_id" : 28051649274,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gale Kuebler",
      "screen_name" : "kueblerelves",
      "indices" : [ 3, 16 ],
      "id_str" : "146310140",
      "id" : 146310140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28052113172",
  "text" : "RT @kueblerelves: Need an inexpensive yet lovely house warming gift? Give them a votive candle holder made with real wildflowers! http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28051886067",
    "text" : "Need an inexpensive yet lovely house warming gift? Give them a votive candle holder made with real wildflowers! http:\/\/tinyurl.com\/2fxhogo",
    "id" : 28051886067,
    "created_at" : "2010-10-21 18:56:51 +0000",
    "user" : {
      "name" : "Gale Kuebler",
      "screen_name" : "kueblerelves",
      "protected" : false,
      "id_str" : "146310140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1115886496\/48748_1537574558_3815_q_normal.jpg",
      "id" : 146310140,
      "verified" : false
    }
  },
  "id" : 28052113172,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28052206642",
  "text" : "@tragic_pizza better than I thought it was going to go..so I'm happy (well..relatively..lol)",
  "id" : 28052206642,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28054106128",
  "text" : "my head feels wonky. making me feel slightly nauseous. maybe sinuses. ugh. have #TKD tonight, too. sigh.",
  "id" : 28054106128,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28058501943",
  "text" : "hey they took my new twitter away.. how weird",
  "id" : 28058501943,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28023357530",
  "text" : "going to dr this am for my rx.. but wyeth now is part of pfizer who changed my free effexor program. this could get ugly...",
  "id" : 28023357530,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27925835354",
  "text" : "RT @RichardWiseman: Carry small plastic foot at all times. When you see a baby, reach under blanket, remove plastic foot and say 'is thi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27923367625",
    "text" : "Carry small plastic foot at all times. When you see a baby, reach under blanket, remove plastic foot and say 'is this supposed to come off?'",
    "id" : 27923367625,
    "created_at" : "2010-10-20 11:50:36 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 27925835354,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 3, 18 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27926281044",
  "text" : "RT @VeryShortStory: \"I like my sausages a little burnt,\" she said, cooking our breakfast. I felt a desperate urge to put my pants on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27925493931",
    "text" : "\"I like my sausages a little burnt,\" she said, cooking our breakfast. I felt a desperate urge to put my pants on.",
    "id" : 27925493931,
    "created_at" : "2010-10-20 12:20:14 +0000",
    "user" : {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "protected" : false,
      "id_str" : "31986700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/141070636\/42291_normal.jpg",
      "id" : 31986700,
      "verified" : false
    }
  },
  "id" : 27926281044,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Death",
      "screen_name" : "its_death",
      "indices" : [ 3, 13 ],
      "id_str" : "1251479634",
      "id" : 1251479634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27927735893",
  "text" : "RT @Its_Death: The Apocalypse has been cancelled due to lack of funds. If you could all hurl yourselves into the Abyss it would be a BIG ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csr",
        "indices" : [ 128, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27926114265",
    "text" : "The Apocalypse has been cancelled due to lack of funds. If you could all hurl yourselves into the Abyss it would be a BIG help. #csr",
    "id" : 27926114265,
    "created_at" : "2010-10-20 12:28:41 +0000",
    "user" : {
      "name" : "Dave Turner",
      "screen_name" : "mrdaveturner",
      "protected" : false,
      "id_str" : "188716376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766196596463788032\/4q3O7zZ6_normal.jpg",
      "id" : 188716376,
      "verified" : false
    }
  },
  "id" : 27927735893,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27927965532",
  "text" : "I watched \"Parenthood\" last night. One kid is aspie.. He wanted to trick or treat for 1st time. Parents freaking out. Good show.",
  "id" : 27927965532,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27928082577",
  "text" : "As a mom to a likely aspie kid, I could relate to the parents anxiety...",
  "id" : 27928082577,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 28, 41 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27928194339",
  "text" : "Ill take youre word..lol RT @Joeandrasi93: SuperString Theory absolutely boggles my mind!...but can explain alot...",
  "id" : 27928194339,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27928246257",
  "text" : "I am likely aspie myself which explains a lot..lol",
  "id" : 27928246257,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carla R. Wilson",
      "screen_name" : "WilsonVA",
      "indices" : [ 3, 12 ],
      "id_str" : "18947875",
      "id" : 18947875
    }, {
      "name" : "Prosperity by Design",
      "screen_name" : "prosperbydesign",
      "indices" : [ 17, 33 ],
      "id_str" : "493521983",
      "id" : 493521983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27928362720",
  "text" : "RT @WilsonVA: RT @prosperbydesign: To find your strength, push past your comfort zone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Prosperity by Design",
        "screen_name" : "prosperbydesign",
        "indices" : [ 3, 19 ],
        "id_str" : "493521983",
        "id" : 493521983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27926823401",
    "text" : "RT @prosperbydesign: To find your strength, push past your comfort zone.",
    "id" : 27926823401,
    "created_at" : "2010-10-20 12:38:01 +0000",
    "user" : {
      "name" : "Carla R. Wilson",
      "screen_name" : "WilsonVA",
      "protected" : false,
      "id_str" : "18947875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569198242127040512\/Ggl2bzN__normal.jpeg",
      "id" : 18947875,
      "verified" : false
    }
  },
  "id" : 27928362720,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27928365130",
  "geo" : { },
  "id_str" : "27928493585",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 LOL yeah, I love all that quantum stuff..what I can understand of it, that is ; )",
  "id" : 27928493585,
  "in_reply_to_status_id" : 27928365130,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27928701398",
  "text" : "@HEATHENRABBIT aspie is short for Aspergers .. high functioning autism.",
  "id" : 27928701398,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27928558306",
  "geo" : { },
  "id_str" : "27928925120",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 I believe so from what I've read. No official diagnosis. But DD scored high on test at school showing aspie traits.",
  "id" : 27928925120,
  "in_reply_to_status_id" : 27928558306,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27928976707",
  "geo" : { },
  "id_str" : "27929138866",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 oh no, don't see as bad.. I've always celebrated uniqueness.. : )",
  "id" : 27929138866,
  "in_reply_to_status_id" : 27928976707,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27929385971",
  "text" : "@HEATHENRABBIT yeah.. Labels are good & bad...",
  "id" : 27929385971,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27929441805",
  "geo" : { },
  "id_str" : "27929853484",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 Awesome! DD is bright but 6-8 grades.. Ugh! 9th grade doing well. Less stress.. Weird.. But I'll take it!",
  "id" : 27929853484,
  "in_reply_to_status_id" : 27929441805,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27929441805",
  "geo" : { },
  "id_str" : "27930014207",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 from young age always hated school, said no college & talked about dropping out at 16 (won't get permission, tho)",
  "id" : 27930014207,
  "in_reply_to_status_id" : 27929441805,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27929739390",
  "geo" : { },
  "id_str" : "27930500801",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 psychology wud b my major choice. Failed math til grade 12, got great teacher. So excited to get those A's!",
  "id" : 27930500801,
  "in_reply_to_status_id" : 27929739390,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 0, 15 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27933221467",
  "geo" : { },
  "id_str" : "27934380436",
  "in_reply_to_user_id" : 23193505,
  "text" : "@stevetheseeker A most joyous birthday to you, Sir! : )",
  "id" : 27934380436,
  "in_reply_to_status_id" : 27933221467,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "stevetheseeker",
  "in_reply_to_user_id_str" : "23193505",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 16, 28 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27937997997",
  "text" : "Love it! : ) RT @angelaharms: Maybe I will get a tattoo that says \"There is nothing wrong with you.\"",
  "id" : 27937997997,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enlightened Warrior",
      "screen_name" : "GetInTheVortex",
      "indices" : [ 3, 18 ],
      "id_str" : "82787787",
      "id" : 82787787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27938106114",
  "text" : "RT @GetInTheVortex: If you conduct yourself as though you expect to be successful and happy, you will seldom be disappointed. ~ Brian Tracy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27936521218",
    "text" : "If you conduct yourself as though you expect to be successful and happy, you will seldom be disappointed. ~ Brian Tracy",
    "id" : 27936521218,
    "created_at" : "2010-10-20 14:35:45 +0000",
    "user" : {
      "name" : "Enlightened Warrior",
      "screen_name" : "GetInTheVortex",
      "protected" : false,
      "id_str" : "82787787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3584098641\/67bf02b400fd2f8e36bc9ae4ce8e2954_normal.jpeg",
      "id" : 82787787,
      "verified" : false
    }
  },
  "id" : 27938106114,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FunnyOneLiners",
      "screen_name" : "Funnyoneliners",
      "indices" : [ 3, 18 ],
      "id_str" : "40885516",
      "id" : 40885516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27938128847",
  "text" : "RT @funnyoneliners: No one can be exactly like me. Even I have trouble doing it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdhouseapp.com\" rel=\"nofollow\"\u003EBirdhouse\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27922841070",
    "text" : "No one can be exactly like me. Even I have trouble doing it.",
    "id" : 27922841070,
    "created_at" : "2010-10-20 11:42:41 +0000",
    "user" : {
      "name" : "FunnyOneLiners",
      "screen_name" : "Funnyoneliners",
      "protected" : false,
      "id_str" : "40885516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642168488195436544\/kiOSQaiM_normal.jpg",
      "id" : 40885516,
      "verified" : false
    }
  },
  "id" : 27938128847,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27936959600",
  "geo" : { },
  "id_str" : "27938214797",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yeah!! ((throwingrosepetals))",
  "id" : 27938214797,
  "in_reply_to_status_id" : 27936959600,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27938328855",
  "text" : "I lost my bliss AGAIN.. but then I found it once I got over myself.. Lol",
  "id" : 27938328855,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27938427813",
  "geo" : { },
  "id_str" : "27938624782",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan I wouldn't know where to start? Is it paper m\u00E2ch\u00E9? Do you have example pics?",
  "id" : 27938624782,
  "in_reply_to_status_id" : 27938427813,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hildy Gottlieb",
      "screen_name" : "HildyGottlieb",
      "indices" : [ 3, 17 ],
      "id_str" : "17794287",
      "id" : 17794287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27943915238",
  "text" : "RT @HildyGottlieb: Do we condemn others for having closed minds, when that very condemning closes our own minds to any possible connection?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27942845486",
    "text" : "Do we condemn others for having closed minds, when that very condemning closes our own minds to any possible connection?",
    "id" : 27942845486,
    "created_at" : "2010-10-20 15:49:10 +0000",
    "user" : {
      "name" : "Hildy Gottlieb",
      "screen_name" : "HildyGottlieb",
      "protected" : false,
      "id_str" : "17794287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482566435630104578\/b41GP1w2_normal.jpeg",
      "id" : 17794287,
      "verified" : false
    }
  },
  "id" : 27943915238,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27938717946",
  "geo" : { },
  "id_str" : "27944171110",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan dm sent : )",
  "id" : 27944171110,
  "in_reply_to_status_id" : 27938717946,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27944545422",
  "text" : "RT @NewMindMirror: Study shows that dogs help autistic children adapt - Psyorg  http:\/\/su.pr\/3tQ7eX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27943903869",
    "text" : "Study shows that dogs help autistic children adapt - Psyorg  http:\/\/su.pr\/3tQ7eX",
    "id" : 27943903869,
    "created_at" : "2010-10-20 16:01:32 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 27944545422,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27944727591",
  "text" : "Hmm.. 2 party system. One pitted against the other. How can that ever work??? (on verge of aha moment here!)",
  "id" : 27944727591,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27948506473",
  "geo" : { },
  "id_str" : "27950622075",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses I have iPod Touch. I don't pay extra 4 Internet. I connect wirelessly to the Internet we have for pc's. HTH",
  "id" : 27950622075,
  "in_reply_to_status_id" : 27948506473,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27950632292",
  "geo" : { },
  "id_str" : "27951138629",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOL.. both me & my 15yo have 1 & love them. Music, apps (lots of free), email, FB, Twitter, contacts. Great in car.",
  "id" : 27951138629,
  "in_reply_to_status_id" : 27950632292,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27950853723",
  "geo" : { },
  "id_str" : "27951403442",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses iTunes on pc. Credit card. You can gift apps. You can get prepaid iTunes cards.",
  "id" : 27951403442,
  "in_reply_to_status_id" : 27950853723,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27950853723",
  "geo" : { },
  "id_str" : "27951564840",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses download using wifi or directly from pc w iTunes.",
  "id" : 27951564840,
  "in_reply_to_status_id" : 27950853723,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27951131313",
  "geo" : { },
  "id_str" : "27951828100",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hubby buys us the prepaid iTunes gift cards (found in pharmacies, grocery stores, etc) then we use wifi 2 DL apps, etc",
  "id" : 27951828100,
  "in_reply_to_status_id" : 27951131313,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27951967370",
  "text" : "RT @Wylieknowords: \"A smart phone is only as smart as the person using it.\" N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27951750774",
    "text" : "\"A smart phone is only as smart as the person using it.\" N. Wylie Jones www.knowords.com",
    "id" : 27951750774,
    "created_at" : "2010-10-20 17:50:22 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27951967370,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27960337656",
  "text" : "RT @Wylieknowords: \"Art is a conspiracy to make us think.\" N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27958236384",
    "text" : "\"Art is a conspiracy to make us think.\" N. Wylie Jones www.knowords.com",
    "id" : 27958236384,
    "created_at" : "2010-10-20 19:23:22 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27960337656,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27983045257",
  "text" : "RT @Davescotperth: If you think that onions are the only veg that make you cry, try being whacked in the face with a potato!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/apps.facebook.com\/status-shuffle\/?from=twitter\" rel=\"nofollow\"\u003EStatus Shuffle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27982372480",
    "text" : "If you think that onions are the only veg that make you cry, try being whacked in the face with a potato!",
    "id" : 27982372480,
    "created_at" : "2010-10-21 01:05:56 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 27983045257,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "indices" : [ 3, 17 ],
      "id_str" : "37490555",
      "id" : 37490555
    }, {
      "name" : "Shauna Fido & Wino",
      "screen_name" : "fidoandwino",
      "indices" : [ 22, 34 ],
      "id_str" : "44071744",
      "id" : 44071744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27984487213",
  "text" : "RT @doggiestylish: RT @fidoandwino: Latest post: \"I love that my dog knew my dad was a safe spot for him\" http:\/\/ht.ly\/2WQBl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shauna Fido & Wino",
        "screen_name" : "fidoandwino",
        "indices" : [ 3, 15 ],
        "id_str" : "44071744",
        "id" : 44071744
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27983438655",
    "text" : "RT @fidoandwino: Latest post: \"I love that my dog knew my dad was a safe spot for him\" http:\/\/ht.ly\/2WQBl",
    "id" : 27983438655,
    "created_at" : "2010-10-21 01:19:38 +0000",
    "user" : {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "protected" : false,
      "id_str" : "37490555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466092491\/jersey_normal.jpg",
      "id" : 37490555,
      "verified" : false
    }
  },
  "id" : 27984487213,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27986587700",
  "text" : "RT @Davescotperth: Really feels like I should tidy up, so I'm just gonna lie here and wait for that feeling to pass",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27986458027",
    "text" : "Really feels like I should tidy up, so I'm just gonna lie here and wait for that feeling to pass",
    "id" : 27986458027,
    "created_at" : "2010-10-21 01:58:58 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 27986587700,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27782668208",
  "geo" : { },
  "id_str" : "27794177142",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan yes, thank you : )",
  "id" : 27794177142,
  "in_reply_to_status_id" : 27782668208,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27837091198",
  "text" : "BookmarkTracker : Free online storage, management, synchronizing and RSS sharing of your bookmarks http:\/\/bit.ly\/b0ZetE",
  "id" : 27837091198,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoteden",
      "screen_name" : "Coyoteguy",
      "indices" : [ 3, 13 ],
      "id_str" : "14715669",
      "id" : 14715669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27866463120",
  "text" : "RT @Coyoteguy: So true.  RT @LearnAnimalTalk \"\"Old age means realizing you will never own all the dogs you wanted to.\" ~ Joe Gores",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27866019120",
    "text" : "So true.  RT @LearnAnimalTalk \"\"Old age means realizing you will never own all the dogs you wanted to.\" ~ Joe Gores",
    "id" : 27866019120,
    "created_at" : "2010-10-19 20:32:18 +0000",
    "user" : {
      "name" : "Yoteden",
      "screen_name" : "Coyoteguy",
      "protected" : false,
      "id_str" : "14715669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671682675124645888\/fhJNxoZj_normal.jpg",
      "id" : 14715669,
      "verified" : false
    }
  },
  "id" : 27866463120,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 6, 18 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27866716757",
  "text" : "Wow.. @mindymayhem is one intelligent chick! I just read her blog... I wish I could think like that nevermind writing.. Lol",
  "id" : 27866716757,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27866938963",
  "text" : "The fall of a giant: A personal history with the Crystal Cathedral | Mindymayhem's Blog http:\/\/bit.ly\/aNI92k",
  "id" : 27866938963,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27868691205",
  "text" : "I think I would be classified as \"neutral\"...",
  "id" : 27868691205,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27869523025",
  "text" : "I dont hang out here too much but I LOVE my profile : )  &gt;&gt; eons.com http:\/\/bit.ly\/bbASC3",
  "id" : 27869523025,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "indices" : [ 3, 12 ],
      "id_str" : "48164887",
      "id" : 48164887
    }, {
      "name" : "RavenClause",
      "screen_name" : "RavenClause",
      "indices" : [ 17, 29 ],
      "id_str" : "2546207569",
      "id" : 2546207569
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27779839184",
  "text" : "RT @amoz1939: RT @RavenClause: A flock of ravens ~ pulled the dawn out ~ from darkness. #haiku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RavenClause",
        "screen_name" : "RavenClause",
        "indices" : [ 3, 15 ],
        "id_str" : "2546207569",
        "id" : 2546207569
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27778341616",
    "text" : "RT @RavenClause: A flock of ravens ~ pulled the dawn out ~ from darkness. #haiku",
    "id" : 27778341616,
    "created_at" : "2010-10-18 23:06:20 +0000",
    "user" : {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "protected" : false,
      "id_str" : "48164887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775135706238758913\/cwiqEl_8_normal.jpg",
      "id" : 48164887,
      "verified" : false
    }
  },
  "id" : 27779839184,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27779278759",
  "geo" : { },
  "id_str" : "27780097349",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time LOL...",
  "id" : 27780097349,
  "in_reply_to_status_id" : 27779278759,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27772786040",
  "geo" : { },
  "id_str" : "27780302415",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan forgive my ignorance.. What's a spirit mask?",
  "id" : 27780302415,
  "in_reply_to_status_id" : 27772786040,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27728706406",
  "text" : "RT @wow_trees: Why are Bill & Melinda Gates investing so much in Monsanto & Cargill?: http:\/\/bit.ly\/bEN0WM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27725760311",
    "text" : "Why are Bill & Melinda Gates investing so much in Monsanto & Cargill?: http:\/\/bit.ly\/bEN0WM",
    "id" : 27725760311,
    "created_at" : "2010-10-18 11:36:29 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 27728706406,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    }, {
      "name" : "Bekka Black",
      "screen_name" : "bekka_black",
      "indices" : [ 47, 59 ],
      "id_str" : "113212239",
      "id" : 113212239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentionMonday",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27728994713",
  "text" : "RT @ThrillersRockT: #MentionMonday iDrakula by @bekka_black\u2026hey, it\u2019s that time of year! (plus a give away!!) http:\/\/bit.ly\/aXFZ78 Plz RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bekka Black",
        "screen_name" : "bekka_black",
        "indices" : [ 27, 39 ],
        "id_str" : "113212239",
        "id" : 113212239
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MentionMonday",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27726124734",
    "text" : "#MentionMonday iDrakula by @bekka_black\u2026hey, it\u2019s that time of year! (plus a give away!!) http:\/\/bit.ly\/aXFZ78 Plz RT",
    "id" : 27726124734,
    "created_at" : "2010-10-18 11:41:53 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 27728994713,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27731335781",
  "text" : "I got to feed my mom yesterday. Weird yet interesting.",
  "id" : 27731335781,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27733372308",
  "text" : "Etsy ppl-this is cool! &gt;&gt; Etsy Marketing Email Signature for Sellers http:\/\/bit.ly\/dtBxY2",
  "id" : 27733372308,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27736080685",
  "text" : "RT @Buddhaworld: strong efforts lead to strong results.-love buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27734196165",
    "text" : "strong efforts lead to strong results.-love buddha volko",
    "id" : 27734196165,
    "created_at" : "2010-10-18 13:29:01 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 27736080685,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedRabbit",
      "screen_name" : "DonkeyPr",
      "indices" : [ 3, 12 ],
      "id_str" : "4437188367",
      "id" : 4437188367
    }, {
      "name" : "BBC Radio 2 Factoids",
      "screen_name" : "bigshowfactoids",
      "indices" : [ 32, 48 ],
      "id_str" : "148303865",
      "id" : 148303865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27736208903",
  "text" : "RT @DonkeyPR: Donkeys too... RT @bigshowfactoids The underside of a horses hoof is called a frog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Radio 2 Factoids",
        "screen_name" : "bigshowfactoids",
        "indices" : [ 18, 34 ],
        "id_str" : "148303865",
        "id" : 148303865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27734946981",
    "text" : "Donkeys too... RT @bigshowfactoids The underside of a horses hoof is called a frog",
    "id" : 27734946981,
    "created_at" : "2010-10-18 13:37:54 +0000",
    "user" : {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "protected" : false,
      "id_str" : "95607516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710457498201952257\/F4zdnP4M_normal.jpg",
      "id" : 95607516,
      "verified" : true
    }
  },
  "id" : 27736208903,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeadEndFiction",
      "screen_name" : "DeadEndFiction",
      "indices" : [ 3, 18 ],
      "id_str" : "129790203",
      "id" : 129790203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27739346618",
  "text" : "RT @DeadEndFiction: Was my camera cursed? With each portrait I took, she became more brittle. I couldn\u2019t stop snapping in my attempt to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27737085377",
    "text" : "Was my camera cursed? With each portrait I took, she became more brittle. I couldn\u2019t stop snapping in my attempt to capture her dying beauty",
    "id" : 27737085377,
    "created_at" : "2010-10-18 14:02:32 +0000",
    "user" : {
      "name" : "DeadEndFiction",
      "screen_name" : "DeadEndFiction",
      "protected" : false,
      "id_str" : "129790203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1156140184\/tree-halloween_normal.jpg",
      "id" : 129790203,
      "verified" : false
    }
  },
  "id" : 27739346618,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capt. S.J.Singh",
      "screen_name" : "surinderJsingh",
      "indices" : [ 18, 33 ],
      "id_str" : "49132710",
      "id" : 49132710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27739434180",
  "text" : "A good ponder! RT @surinderJsingh: It is evident that each atom is intelligent because it does what it does without instructions from anyone",
  "id" : 27739434180,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27740155986",
  "text" : "RT @Joeandrasi93: Since current Physics  now considers at least 11 dimesions of space, how do you think this supports paranormal phenomena?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27740086893",
    "text" : "Since current Physics  now considers at least 11 dimesions of space, how do you think this supports paranormal phenomena?",
    "id" : 27740086893,
    "created_at" : "2010-10-18 14:36:03 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 27740155986,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27741264687",
  "text" : "be prepared 2 click! LOL &gt;&gt;Free animated signatures http:\/\/bit.ly\/bjrGY7",
  "id" : 27741264687,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27750522656",
  "text" : "RT @thesexyatheist: In case ya missed my hot date from Friday Nite.  Yes, I like 'em young, young and delicious. Nom nom nom. http:\/\/twi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27749685482",
    "text" : "In case ya missed my hot date from Friday Nite.  Yes, I like 'em young, young and delicious. Nom nom nom. http:\/\/twitpic.com\/2yrtg5",
    "id" : 27749685482,
    "created_at" : "2010-10-18 16:23:34 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 27750522656,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27749793137",
  "geo" : { },
  "id_str" : "27750638767",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I love it when those moments happen to me... : )",
  "id" : 27750638767,
  "in_reply_to_status_id" : 27749793137,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27742043336",
  "geo" : { },
  "id_str" : "27750757405",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts hey there! Not much. Some laundry, sorting stuff.",
  "id" : 27750757405,
  "in_reply_to_status_id" : 27742043336,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "John",
      "screen_name" : "QJ0hn",
      "indices" : [ 19, 25 ],
      "id_str" : "733991620316651524",
      "id" : 733991620316651524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27754084450",
  "text" : "RT @TrishScott: RT @qj0hn: Existence is only a phase for those who cannot handle non-existence.\/\/\/LOL. Let me try let me try let me try!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John",
        "screen_name" : "QJ0hn",
        "indices" : [ 3, 9 ],
        "id_str" : "733991620316651524",
        "id" : 733991620316651524
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27752767596",
    "text" : "RT @qj0hn: Existence is only a phase for those who cannot handle non-existence.\/\/\/LOL. Let me try let me try let me try!",
    "id" : 27752767596,
    "created_at" : "2010-10-18 17:03:05 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 27754084450,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myrre Neuquer",
      "screen_name" : "persephone419",
      "indices" : [ 3, 17 ],
      "id_str" : "81416239",
      "id" : 81416239
    }, {
      "name" : "Jason Boehm",
      "screen_name" : "jayrox",
      "indices" : [ 22, 29 ],
      "id_str" : "14766533",
      "id" : 14766533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27754445184",
  "text" : "RT @persephone419: RT @jayrox: Only thing better than pizza is free pizza \/Only thing better than pizza is @tragic_pizza ... Open door",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Boehm",
        "screen_name" : "jayrox",
        "indices" : [ 3, 10 ],
        "id_str" : "14766533",
        "id" : 14766533
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27750604999",
    "text" : "RT @jayrox: Only thing better than pizza is free pizza \/Only thing better than pizza is @tragic_pizza ... Open door",
    "id" : 27750604999,
    "created_at" : "2010-10-18 16:35:09 +0000",
    "user" : {
      "name" : "Myrre Neuquer",
      "screen_name" : "persephone419",
      "protected" : false,
      "id_str" : "81416239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1246434154\/chicken_avatar_bigger_normal.jpg",
      "id" : 81416239,
      "verified" : false
    }
  },
  "id" : 27754445184,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Winterburn",
      "screen_name" : "5tevenw",
      "indices" : [ 3, 11 ],
      "id_str" : "71806313",
      "id" : 71806313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27754484643",
  "text" : "RT @5tevenw: When life gives you melons, you know you\u2019re dyslexic.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27753430137",
    "text" : "When life gives you melons, you know you\u2019re dyslexic.",
    "id" : 27753430137,
    "created_at" : "2010-10-18 17:11:58 +0000",
    "user" : {
      "name" : "Steven Winterburn",
      "screen_name" : "5tevenw",
      "protected" : false,
      "id_str" : "71806313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697440590\/twitterProfilePhoto_normal.jpg",
      "id" : 71806313,
      "verified" : false
    }
  },
  "id" : 27754484643,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27761276600",
  "text" : "YouTube - Adam Lambert: \"It Gets Better\" http:\/\/bit.ly\/aOJfJl",
  "id" : 27761276600,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTD",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27761394314",
  "text" : "RT @wildobs: Wildlife Species of the day: Rosy Maple Moth: http:\/\/bit.ly\/bDthuo #SOTD Talk about eye candy. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTD",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27759196483",
    "text" : "Wildlife Species of the day: Rosy Maple Moth: http:\/\/bit.ly\/bDthuo #SOTD Talk about eye candy. :)",
    "id" : 27759196483,
    "created_at" : "2010-10-18 18:35:46 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 27761394314,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27761439937",
  "text" : "RT @Wylieknowords: \"Imagine a Twitter for poets to pine \/\n All of the Tweets flowing like wine.\" N. Wylie Jones  www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27759435610",
    "text" : "\"Imagine a Twitter for poets to pine \/\n All of the Tweets flowing like wine.\" N. Wylie Jones  www.knowords.com",
    "id" : 27759435610,
    "created_at" : "2010-10-18 18:39:14 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27761439937,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27761473844",
  "text" : "RT @Wylieknowords: \"the stupid logic of war. If we stop now, the ones who died before died in vain. So, let's keep dying and kill thousa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27759534834",
    "text" : "\"the stupid logic of war. If we stop now, the ones who died before died in vain. So, let's keep dying and kill thousands more. And more. And",
    "id" : 27759534834,
    "created_at" : "2010-10-18 18:40:42 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27761473844,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Wright",
      "screen_name" : "Helenwrites",
      "indices" : [ 3, 15 ],
      "id_str" : "20229575",
      "id" : 20229575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27765985670",
  "text" : "RT @Helenwrites: Did you find a locket in London last night? It's worth nothing, but means everything to me. My last hope - Please RT to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27540467612",
    "text" : "Did you find a locket in London last night? It's worth nothing, but means everything to me. My last hope - Please RT to the power of twitter",
    "id" : 27540467612,
    "created_at" : "2010-10-16 13:32:16 +0000",
    "user" : {
      "name" : "Helen Wright",
      "screen_name" : "Helenwrites",
      "protected" : false,
      "id_str" : "20229575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793436089394536452\/VmvrtjrV_normal.jpg",
      "id" : 20229575,
      "verified" : false
    }
  },
  "id" : 27765985670,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "burdr",
      "screen_name" : "burdr",
      "indices" : [ 13, 19 ],
      "id_str" : "18826472",
      "id" : 18826472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "birding",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "photography",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27766141482",
  "text" : "So sweet! RT @burdr: \"Super Friendly Chickadees\" http:\/\/bit.ly\/9mDbIy #birds #birding #photography",
  "id" : 27766141482,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27766178922",
  "text" : "RT @earthXplorer: When the going gets tough, the tough get tweeting! ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27764580218",
    "text" : "When the going gets tough, the tough get tweeting! ;)",
    "id" : 27764580218,
    "created_at" : "2010-10-18 19:56:53 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 27766178922,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27766295729",
  "text" : "@SamsaricWarrior hubby says yes PN is lighter...",
  "id" : 27766295729,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27766440996",
  "text" : "@SamsaricWarrior oh my 15yo DD recommends NO wine..lol.. She's very anti-alky.. Funny kid.",
  "id" : 27766440996,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27766687186",
  "text" : "RT @GraveStomper: It's amazing how many people proudly proclaim their disregard for other people while justifying it by saying: (cont) h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27765611762",
    "text" : "It's amazing how many people proudly proclaim their disregard for other people while justifying it by saying: (cont) http:\/\/tl.gd\/6htcua",
    "id" : 27765611762,
    "created_at" : "2010-10-18 20:12:21 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 27766687186,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27769686001",
  "geo" : { },
  "id_str" : "27770468309",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan black & orange lace streams w spiders (or cats!); mini skeletons dangling from top.. hmm..",
  "id" : 27770468309,
  "in_reply_to_status_id" : 27769686001,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27770497221",
  "text" : "RT @Wylieknowords: \"In the South every day is Fry day.\" N. Wylie Jones  www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27769745166",
    "text" : "\"In the South every day is Fry day.\" N. Wylie Jones  www.knowords.com",
    "id" : 27769745166,
    "created_at" : "2010-10-18 21:12:41 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27770497221,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27770903107",
  "geo" : { },
  "id_str" : "27771508812",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan that sounds awesome! Something 4 the base? Hmm.. Twine? Garland?",
  "id" : 27771508812,
  "in_reply_to_status_id" : 27770903107,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27770745606",
  "geo" : { },
  "id_str" : "27771535029",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan heehee : )",
  "id" : 27771535029,
  "in_reply_to_status_id" : 27770745606,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27771927554",
  "geo" : { },
  "id_str" : "27772014583",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan Nice idea, I like!",
  "id" : 27772014583,
  "in_reply_to_status_id" : 27771927554,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MeowMonday",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27779476776",
  "text" : "RT @CoyoteSings: \"Cats seem to go on the principle that it never does any harm to ask for what you want.\" -Joseph Wood Krutch #MeowMonday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MeowMonday",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27776821112",
    "text" : "\"Cats seem to go on the principle that it never does any harm to ask for what you want.\" -Joseph Wood Krutch #MeowMonday",
    "id" : 27776821112,
    "created_at" : "2010-10-18 22:48:09 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 27779476776,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27587351870",
  "text" : "Well this weekend IS sucking waffles...",
  "id" : 27587351870,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "American Airlines",
      "screen_name" : "AmericanAir",
      "indices" : [ 31, 43 ],
      "id_str" : "22536055",
      "id" : 22536055
    }, {
      "name" : "Doc Gurley",
      "screen_name" : "docgurley",
      "indices" : [ 74, 84 ],
      "id_str" : "36997518",
      "id" : 36997518
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiti",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27588096560",
  "text" : "RT @AlisynGayle: Not only does @AmericanAir not donate #Haiti transport 4 @docgurley's ALL VOLUNTEER Medical team but also doesn't honor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Airlines",
        "screen_name" : "AmericanAir",
        "indices" : [ 14, 26 ],
        "id_str" : "22536055",
        "id" : 22536055
      }, {
        "name" : "Doc Gurley",
        "screen_name" : "docgurley",
        "indices" : [ 57, 67 ],
        "id_str" : "36997518",
        "id" : 36997518
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Haiti",
        "indices" : [ 38, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27587943151",
    "text" : "Not only does @AmericanAir not donate #Haiti transport 4 @docgurley's ALL VOLUNTEER Medical team but also doesn't honor PAID 1st class fare!",
    "id" : 27587943151,
    "created_at" : "2010-10-17 00:19:22 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 27588096560,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27588787184",
  "text" : "RT @Para411Michelle: . @Para_Tara34 Want to encourage reaching out to understand what's happening. It's critical. The world, universe is ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27586863573",
    "text" : ". @Para_Tara34 Want to encourage reaching out to understand what's happening. It's critical. The world, universe is abt 2 b seen w\/new eyes",
    "id" : 27586863573,
    "created_at" : "2010-10-17 00:04:02 +0000",
    "user" : {
      "name" : "Michelle Coppock",
      "screen_name" : "MichelleCoppock",
      "protected" : false,
      "id_str" : "31959055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757811196573523968\/E1MpffS5_normal.jpg",
      "id" : 31959055,
      "verified" : false
    }
  },
  "id" : 27588787184,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27592762200",
  "text" : "RT @bend_time: my dog and his neighbor\/fiancee.we decided a dog wedding is a great reason 4 a party.plus maybe greenie gifts :) http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27592051109",
    "text" : "my dog and his neighbor\/fiancee.we decided a dog wedding is a great reason 4 a party.plus maybe greenie gifts :) http:\/\/twitpic.com\/2y9q2k",
    "id" : 27592051109,
    "created_at" : "2010-10-17 01:15:57 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 27592762200,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27592816946",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time oh the wisdom & love in those eyes! Beautiful...",
  "id" : 27592816946,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27597367839",
  "text" : "RT @Wylieknowords: \"Want to go back in history a hundred years? Go viisit a Texas prison.\"N.Wylie Jones (Read Texas Though by Robert Per ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27596597246",
    "text" : "\"Want to go back in history a hundred years? Go viisit a Texas prison.\"N.Wylie Jones (Read Texas Though by Robert Perkinson.)",
    "id" : 27596597246,
    "created_at" : "2010-10-17 02:15:27 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27597367839,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27663557770",
  "text" : "Authors Wanted for Holiday Giveaway Event by 11\/15 (print or ebook) http:\/\/bit.ly\/aQhabS",
  "id" : 27663557770,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 7, 16 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27664011494",
  "text" : "LOL RT @Fernwise: Some women collect jewels - I collect domain names.  Just bought two more today.",
  "id" : 27664011494,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 3, 17 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27664066446",
  "text" : "RT @Unique_Misfit: It's like how 'wrong numbers' are NEVER busy!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27663028259",
    "text" : "It's like how 'wrong numbers' are NEVER busy!!",
    "id" : 27663028259,
    "created_at" : "2010-10-17 19:00:21 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 27664066446,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 3, 17 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27664073190",
  "text" : "RT @Unique_Misfit: It's like there are 'wrong numbers' to exist in the world just waiting for someone to ring them LMFAO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27663075636",
    "text" : "It's like there are 'wrong numbers' to exist in the world just waiting for someone to ring them LMFAO",
    "id" : 27663075636,
    "created_at" : "2010-10-17 19:00:58 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 27664073190,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ch\u00E9rie De Sues",
      "screen_name" : "writtenbycherie",
      "indices" : [ 3, 19 ],
      "id_str" : "75220203",
      "id" : 75220203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27666336526",
  "text" : "RT @writtenbycherie: New contest at http:\/\/tiny.ly\/07K Give me your Halloween or Samhain recipe and WIN 3 ebooks and your recipe goes in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27664982529",
    "text" : "New contest at http:\/\/tiny.ly\/07K Give me your Halloween or Samhain recipe and WIN 3 ebooks and your recipe goes inside my novel!",
    "id" : 27664982529,
    "created_at" : "2010-10-17 19:27:36 +0000",
    "user" : {
      "name" : "Ch\u00E9rie De Sues",
      "screen_name" : "writtenbycherie",
      "protected" : false,
      "id_str" : "75220203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458471821214359552\/sg9cnwhc_normal.jpeg",
      "id" : 75220203,
      "verified" : false
    }
  },
  "id" : 27666336526,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "giveaways",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27669376445",
  "text" : "RT @DarciaHelle: October Book Giveaway - Win 'Hit List' & a new mousepad! http:\/\/bit.ly\/cHmcMg #books #giveaways",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "giveaways",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27667794157",
    "text" : "October Book Giveaway - Win 'Hit List' & a new mousepad! http:\/\/bit.ly\/cHmcMg #books #giveaways",
    "id" : 27667794157,
    "created_at" : "2010-10-17 20:06:29 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 27669376445,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27669496708",
  "text" : "RT @worldtreeman: not really a bible dude, but i do love bits of it.....'there are many rooms in my fathers mansion'..too right! many re ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27668542305",
    "text" : "not really a bible dude, but i do love bits of it.....'there are many rooms in my fathers mansion'..too right! many realities\/vistas\/worlds",
    "id" : 27668542305,
    "created_at" : "2010-10-17 20:17:13 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 27669496708,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27669592236",
  "text" : "RT @worldtreeman: the great thing about tweeting from tthe heart is that you never know what those words can do..they can support,change ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27669071990",
    "text" : "the great thing about tweeting from tthe heart is that you never know what those words can do..they can support,change,embrace and heal",
    "id" : 27669071990,
    "created_at" : "2010-10-17 20:24:56 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 27669592236,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27580334934",
  "text" : "RT @Wylieknowords: \"Does this ((((TWEET))) make me look fat?\" N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27580123049",
    "text" : "\"Does this ((((TWEET))) make me look fat?\" N. Wylie Jones www.knowords.com",
    "id" : 27580123049,
    "created_at" : "2010-10-16 22:24:32 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27580334934,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27581633503",
  "text" : "RT @Wylieknowords: \"Kindle--books without the weight or the wait.\" N. Wylie Jones www.knowords.com",
  "id" : 27581633503,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    }, {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 13, 20 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27490918742",
  "text" : "RT @hvspca: \"@hvspca: HVSPCA arrest horse trainer in Mount Hope go to midhudsonnews.com for full story\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hudson Valley SPCA",
        "screen_name" : "hvspca",
        "indices" : [ 1, 8 ],
        "id_str" : "99531497",
        "id" : 99531497
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27490255715",
    "text" : "\"@hvspca: HVSPCA arrest horse trainer in Mount Hope go to midhudsonnews.com for full story\"",
    "id" : 27490255715,
    "created_at" : "2010-10-15 23:57:59 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 27490918742,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27491094464",
  "text" : "@HEATHENRABBIT sounds like a good time to me! : )",
  "id" : 27491094464,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27492565072",
  "text" : "RT @RevDebra: My assistant was verbally taunted on train this am by soldiers because he appeared gay. Heartbreaking in CT in 2010",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27491136402",
    "text" : "My assistant was verbally taunted on train this am by soldiers because he appeared gay. Heartbreaking in CT in 2010",
    "id" : 27491136402,
    "created_at" : "2010-10-16 00:09:37 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 27492565072,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27492582112",
  "text" : "RT @derekrootboy: i love my followers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27491232838",
    "text" : "i love my followers.",
    "id" : 27491232838,
    "created_at" : "2010-10-16 00:10:52 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 27492582112,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 9, 22 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27492622323",
  "text" : "&lt;3 RT @derekrootboy: i love my followers.",
  "id" : 27492622323,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 13, 28 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27492765859",
  "text" : "Awwwwww!! RT @ReformedBuddha: I'm telling ya'll, the resemblance is uncanny. http:\/\/twitpic.com\/2xwtym",
  "id" : 27492765859,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27492841563",
  "text" : "RT @screek: My Photo For The Day \"Whispering Deer\" http:\/\/bit.ly\/9JIaxz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27491765274",
    "text" : "My Photo For The Day \"Whispering Deer\" http:\/\/bit.ly\/9JIaxz",
    "id" : 27491765274,
    "created_at" : "2010-10-16 00:17:51 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 27492841563,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27493161965",
  "text" : "RT @Dwayne_Reaves: Blog post about some of my hearing difficulties. \"Delayed Hearing, Changing the Subject\" http:\/\/bit.ly\/9oKkC5 #hearin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hearingloss",
        "indices" : [ 110, 122 ]
      }, {
        "text" : "blog",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27492567889",
    "text" : "Blog post about some of my hearing difficulties. \"Delayed Hearing, Changing the Subject\" http:\/\/bit.ly\/9oKkC5 #hearingloss #blog",
    "id" : 27492567889,
    "created_at" : "2010-10-16 00:28:07 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 27493161965,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Chapman or FBH",
      "screen_name" : "TerryFBH",
      "indices" : [ 3, 12 ],
      "id_str" : "134459295",
      "id" : 134459295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27494244401",
  "text" : "RT @TerryFBH: To maintain a healthy level of insanity Tell your children over dinner, \"Due to the economy, we are going to have to let o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27365842330",
    "text" : "To maintain a healthy level of insanity Tell your children over dinner, \"Due to the economy, we are going to have to let one of you go.\"",
    "id" : 27365842330,
    "created_at" : "2010-10-14 18:32:34 +0000",
    "user" : {
      "name" : "Terry Chapman or FBH",
      "screen_name" : "TerryFBH",
      "protected" : false,
      "id_str" : "134459295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614127084139638784\/u6ddT74q_normal.jpg",
      "id" : 134459295,
      "verified" : false
    }
  },
  "id" : 27494244401,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 8, 20 ],
      "id_str" : "130344581",
      "id" : 130344581
    }, {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 22, 37 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27498403425",
  "text" : "Aww! RT @_karmadorje: @ReformedBuddha She found the teddy when she was Dexter's age. She won't let go of it.  http:\/\/twitpic.com\/2xx7zp",
  "id" : 27498403425,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 13, 24 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27499860812",
  "text" : "Just watched @CaplinROUS on 20\/20.. He's adorable! Loved Wild Thing the bison, too. Amazing bonds between the animals & humans!",
  "id" : 27499860812,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gale Kuebler",
      "screen_name" : "kueblerelves",
      "indices" : [ 0, 13 ],
      "id_str" : "146310140",
      "id" : 146310140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27499529702",
  "geo" : { },
  "id_str" : "27500019099",
  "in_reply_to_user_id" : 146310140,
  "text" : "@kueblerelves Hi! hope you're feeling better!",
  "id" : 27500019099,
  "in_reply_to_status_id" : 27499529702,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "kueblerelves",
  "in_reply_to_user_id_str" : "146310140",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27500529870",
  "geo" : { },
  "id_str" : "27500948036",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves I liked your post. Resonated w me. Don't always understand things (normal hearing tho but hard w other noise).",
  "id" : 27500948036,
  "in_reply_to_status_id" : 27500529870,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27543075098",
  "text" : "RT @derekrootboy: Humanists need 2 understand social role of different religions & why so many good people embrace them. Atheists don't  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27542978259",
    "text" : "Humanists need 2 understand social role of different religions & why so many good people embrace them. Atheists don't have all the answers",
    "id" : 27542978259,
    "created_at" : "2010-10-16 14:04:16 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 27543075098,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    }, {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 44, 56 ],
      "id_str" : "130344581",
      "id" : 130344581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27551954670",
  "text" : "@ReformedBuddha think you meant to reply to @_karmadorje .. But does look like DD's kitty! : )",
  "id" : 27551954670,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27553072785",
  "geo" : { },
  "id_str" : "27555209940",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses u cud make an ebook or ecourse showing ppl how to do what u do.. just a thought. I'm always thinking.. Lol",
  "id" : 27555209940,
  "in_reply_to_status_id" : 27553072785,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27555481898",
  "text" : "Watching Chiller channel.. Beyond Belief: Fact or Fiction.",
  "id" : 27555481898,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27555582683",
  "text" : "We all like to make our guesses which scenarios are true.. it's fun..hehe",
  "id" : 27555582683,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 7, 21 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27558752956",
  "text" : "LOL RT @Wylieknowords: \"What happens in Twitter DM's stays in Twitter DM's.\" N. Wylie Jones  www.knowords.com",
  "id" : 27558752956,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27559132019",
  "text" : "Me thinks my hormones are having a party.. Easily cranky, sleepsweats, weird dreams past few days...",
  "id" : 27559132019,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27563923870",
  "geo" : { },
  "id_str" : "27567078646",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle LOL",
  "id" : 27567078646,
  "in_reply_to_status_id" : 27563923870,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27567253165",
  "text" : "RT @bunnybuddhism: Every hop counts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27565285727",
    "text" : "Every hop counts.",
    "id" : 27565285727,
    "created_at" : "2010-10-16 18:34:10 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 27567253165,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27567280810",
  "text" : "RT @Wylieknowords: \"Twitter is my T-spot.\" N. Wylie Jones  www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27565495178",
    "text" : "\"Twitter is my T-spot.\" N. Wylie Jones  www.knowords.com",
    "id" : 27565495178,
    "created_at" : "2010-10-16 18:37:08 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27567280810,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK Rising",
      "screen_name" : "DKRising",
      "indices" : [ 3, 12 ],
      "id_str" : "716678263855267840",
      "id" : 716678263855267840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27567874608",
  "text" : "RT @DKRising: You don't scare me. I scare me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27567272132",
    "text" : "You don't scare me. I scare me.",
    "id" : 27567272132,
    "created_at" : "2010-10-16 19:03:04 +0000",
    "user" : {
      "name" : "DK",
      "screen_name" : "horseandahalf",
      "protected" : false,
      "id_str" : "28032888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2250219073\/3622258089_0d9032f127_b_normal.jpg",
      "id" : 28032888,
      "verified" : false
    }
  },
  "id" : 27567874608,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27567936938",
  "text" : "RT @ShhDragon: Saki bows to firepit http:\/\/plixi.com\/p\/51055987",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27567610260",
    "text" : "Saki bows to firepit http:\/\/plixi.com\/p\/51055987",
    "id" : 27567610260,
    "created_at" : "2010-10-16 19:07:59 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 27567936938,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 30, 40 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27568013344",
  "text" : "Inspector Saki on the job! RT @ShhDragon: Saki enters firepit http:\/\/plixi.com\/p\/51056164",
  "id" : 27568013344,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27571259135",
  "text" : "@SamsaricWarrior the whole pic is pretty! Nice shot.",
  "id" : 27571259135,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27571457681",
  "text" : "DD came home w costume.. \"Fallen\" Cat.. All black, wings, shackles.",
  "id" : 27571457681,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27573879591",
  "text" : "RT @angelaharms: \"When work feels overwhelming, remember that you're going to die.\"--Leon, from EdgeCase.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27571742302",
    "text" : "\"When work feels overwhelming, remember that you're going to die.\"--Leon, from EdgeCase.",
    "id" : 27571742302,
    "created_at" : "2010-10-16 20:11:31 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 27573879591,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 37, 50 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mynatgivaway",
      "indices" : [ 90, 103 ]
    }, {
      "text" : "itunes",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27573889159",
  "text" : "RT @MyNatureApps: FREE !!!! Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway #itunes Enter here -&gt; http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff",
        "screen_name" : "MyNatureApps",
        "indices" : [ 19, 32 ],
        "id_str" : "93072985",
        "id" : 93072985
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mynatgivaway",
        "indices" : [ 72, 85 ]
      }, {
        "text" : "itunes",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27571821377",
    "text" : "FREE !!!! Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway #itunes Enter here -&gt; http:\/\/tinyurl.com\/22uoqsp",
    "id" : 27571821377,
    "created_at" : "2010-10-16 20:12:46 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 27573889159,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 17, 31 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27573994995",
  "text" : "I hate 2 cry! RT @Wylieknowords: I got a paper cut trying to quickly turn the pages of \"The Road\" by Cormac McCarthy. Want to cry, read it.",
  "id" : 27573994995,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 35, 47 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27580100467",
  "text" : "Ive had a few of these lately.. RT @AlisynGayle: Why did I just watch that? :-\/",
  "id" : 27580100467,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Winterburn",
      "screen_name" : "5tevenw",
      "indices" : [ 3, 11 ],
      "id_str" : "71806313",
      "id" : 71806313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27580163990",
  "text" : "RT @5tevenw: \u028E\u0250q\u01DD uo p\u0279\u0250oq\u028E\u01DD\u029E \u0250 \u028Enq \u0131 \u01DD\u026F\u0131\u0287 \u0287s\u0250\u05DF \u01DD\u0265\u0287 s\u0131 s\u0131\u0265\u0287 'u\u026F\u0250p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27477920067",
    "text" : "\u028E\u0250q\u01DD uo p\u0279\u0250oq\u028E\u01DD\u029E \u0250 \u028Enq \u0131 \u01DD\u026F\u0131\u0287 \u0287s\u0250\u05DF \u01DD\u0265\u0287 s\u0131 s\u0131\u0265\u0287 'u\u026F\u0250p",
    "id" : 27477920067,
    "created_at" : "2010-10-15 21:03:20 +0000",
    "user" : {
      "name" : "Steven Winterburn",
      "screen_name" : "5tevenw",
      "protected" : false,
      "id_str" : "71806313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697440590\/twitterProfilePhoto_normal.jpg",
      "id" : 71806313,
      "verified" : false
    }
  },
  "id" : 27580163990,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ny",
      "indices" : [ 112, 115 ]
    }, {
      "text" : "hudsonvalley",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27580262679",
  "text" : "RT @hvspca: HVSPCA needs wet dog food, dry dog food, pedigree or purina. Cat food purina: http:\/\/wp.me\/pLcDB-7I #ny #hudsonvalley",
  "id" : 27580262679,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27459779647",
  "text" : "I'm freezing but everytime I put on sweater I get TOO warm.. Sigh.",
  "id" : 27459779647,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 7, 23 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "armchairparent",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27459928896",
  "text" : "LOL RT @hauntedcomputer: I love being able to check up on my daughter by looking at her Facebook page. \"Who is that BOY?\" #armchairparent",
  "id" : 27459928896,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27459960339",
  "text" : "RT @bend_time: Halloween in LA...how many girls undr 30 will hv the cr8tivity & confidence 2 NOT dress like a hooker? 2%.self_objectific ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27459864412",
    "text" : "Halloween in LA...how many girls undr 30 will hv the cr8tivity & confidence 2 NOT dress like a hooker? 2%.self_objectification complete",
    "id" : 27459864412,
    "created_at" : "2010-10-15 16:55:06 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 27459960339,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hazel Evans",
      "screen_name" : "Hayzlenut",
      "indices" : [ 0, 10 ],
      "id_str" : "34858888",
      "id" : 34858888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27460022706",
  "geo" : { },
  "id_str" : "27460672396",
  "in_reply_to_user_id" : 34858888,
  "text" : "@Hayzlenut Cool! : )",
  "id" : 27460672396,
  "in_reply_to_status_id" : 27460022706,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Hayzlenut",
  "in_reply_to_user_id_str" : "34858888",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27461175583",
  "geo" : { },
  "id_str" : "27461697177",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses that's cool idea. I was thinking Lottery should have gift card so ppl can choose when they play...",
  "id" : 27461697177,
  "in_reply_to_status_id" : 27461175583,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27461356164",
  "geo" : { },
  "id_str" : "27461774469",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses now that sounds like awesome list to be on! : )",
  "id" : 27461774469,
  "in_reply_to_status_id" : 27461356164,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27463639042",
  "text" : "RT @DeepakChopra: Today tell yourself every word I utter will be chosen consciously. I will refrain from complaints, criticism, and cond ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27462206595",
    "text" : "Today tell yourself every word I utter will be chosen consciously. I will refrain from complaints, criticism, and condemnation.",
    "id" : 27462206595,
    "created_at" : "2010-10-15 17:23:10 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 27463639042,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "148Apps Now Free",
      "screen_name" : "148apps_nowfree",
      "indices" : [ 3, 19 ],
      "id_str" : "47228465",
      "id" : 47228465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27463774613",
  "text" : "RT @148apps_nowfree: The Crystals of Atlantis Deluxe is now FREE (down from $0.99) - http:\/\/148apps.com\/app\/358284672",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/148apps.com\" rel=\"nofollow\"\u003EUpdates 148apps_nowfree\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27462836735",
    "text" : "The Crystals of Atlantis Deluxe is now FREE (down from $0.99) - http:\/\/148apps.com\/app\/358284672",
    "id" : 27462836735,
    "created_at" : "2010-10-15 17:31:02 +0000",
    "user" : {
      "name" : "148Apps Now Free",
      "screen_name" : "148apps_nowfree",
      "protected" : false,
      "id_str" : "47228465",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/263274165\/148-dollar-sign2---square_normal.jpg",
      "id" : 47228465,
      "verified" : false
    }
  },
  "id" : 27463774613,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27469566603",
  "geo" : { },
  "id_str" : "27471113395",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC true.. I try to mix it up each week. It's tough! : )",
  "id" : 27471113395,
  "in_reply_to_status_id" : 27469566603,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK Rising",
      "screen_name" : "DKRising",
      "indices" : [ 3, 12 ],
      "id_str" : "716678263855267840",
      "id" : 716678263855267840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27471395250",
  "text" : "RT @DKRising: Why is it so cold? This is unacceptable. Change it now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27471173917",
    "text" : "Why is it so cold? This is unacceptable. Change it now.",
    "id" : 27471173917,
    "created_at" : "2010-10-15 19:25:03 +0000",
    "user" : {
      "name" : "DK",
      "screen_name" : "horseandahalf",
      "protected" : false,
      "id_str" : "28032888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2250219073\/3622258089_0d9032f127_b_normal.jpg",
      "id" : 28032888,
      "verified" : false
    }
  },
  "id" : 27471395250,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27471484726",
  "text" : "I can tell already that the weekend's gonna suck waffles.. Sigh.",
  "id" : 27471484726,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27471540132",
  "text" : "I hate Fridays. They are usually hubby's busy day.",
  "id" : 27471540132,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27471488656",
  "geo" : { },
  "id_str" : "27471605147",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 LOL. true...",
  "id" : 27471605147,
  "in_reply_to_status_id" : 27471488656,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27480107579",
  "text" : "@ReformedBuddha Pumpkin, hubby says Sunkissed.",
  "id" : 27480107579,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27392067979",
  "text" : "Me: I want to move somewhere warm. Hub: I hear Hell is very warm this time of year.",
  "id" : 27392067979,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karmadorje",
      "screen_name" : "_karmadorje",
      "indices" : [ 0, 12 ],
      "id_str" : "130344581",
      "id" : 130344581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27387809011",
  "geo" : { },
  "id_str" : "27393093060",
  "in_reply_to_user_id" : 130344581,
  "text" : "@_karmadorje aww ((hugs)) yes, hubby fed me.. feeling better now. : )",
  "id" : 27393093060,
  "in_reply_to_status_id" : 27387809011,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "_karmadorje",
  "in_reply_to_user_id_str" : "130344581",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27394445482",
  "text" : "RT @CaplinROUS: Which is a better pet, a capybara or a bison? Watch 20\/20 tomorrow and decide! http:\/\/bit.ly\/dfEyDL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27394106780",
    "text" : "Which is a better pet, a capybara or a bison? Watch 20\/20 tomorrow and decide! http:\/\/bit.ly\/dfEyDL",
    "id" : 27394106780,
    "created_at" : "2010-10-15 00:58:38 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 27394445482,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 3, 12 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pagan",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "wicca",
      "indices" : [ 99, 105 ]
    }, {
      "text" : "wiccan",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "Samhain",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "witch",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27438584658",
  "text" : "RT @Fernwise: Ouija boards! http:\/\/fernsfronds.blogspot.com\/2009\/10\/using-ouija-boards.html #pagan #wicca #wiccan #Samhain #witch #occul ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pagan",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "wicca",
        "indices" : [ 85, 91 ]
      }, {
        "text" : "wiccan",
        "indices" : [ 92, 99 ]
      }, {
        "text" : "Samhain",
        "indices" : [ 100, 108 ]
      }, {
        "text" : "witch",
        "indices" : [ 109, 115 ]
      }, {
        "text" : "occult",
        "indices" : [ 116, 123 ]
      }, {
        "text" : "divination",
        "indices" : [ 124, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27437975439",
    "text" : "Ouija boards! http:\/\/fernsfronds.blogspot.com\/2009\/10\/using-ouija-boards.html #pagan #wicca #wiccan #Samhain #witch #occult #divination",
    "id" : 27437975439,
    "created_at" : "2010-10-15 12:57:11 +0000",
    "user" : {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "protected" : false,
      "id_str" : "23538653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/253664055\/FernForTwitter_normal.png",
      "id" : 23538653,
      "verified" : false
    }
  },
  "id" : 27438584658,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27453798563",
  "text" : "Having some AHA moments today which always makes me happy...",
  "id" : 27453798563,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 23, 36 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27454770819",
  "text" : "Geez, what is it about @DeepakChopra that causes such a ruckus? Ppl seem to love him or hate him.",
  "id" : 27454770819,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 30, 44 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    }, {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 45, 55 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    }, {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 73, 87 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    }, {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 88, 103 ],
      "id_str" : "23193505",
      "id" : 23193505
    }, {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 104, 119 ],
      "id_str" : "30825946",
      "id" : 30825946
    }, {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 120, 132 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 12, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27455821759",
  "text" : "My VIP List #FF @tragic_pizza @HEATHENRABBIT @ID_vs_EGO @SamsaricWarrior @Unique_Misfit @stevetheseeker @JonathanElliot @Buddhaworld",
  "id" : 27455821759,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolfram|Alpha",
      "screen_name" : "Wolfram_Alpha",
      "indices" : [ 3, 17 ],
      "id_str" : "35005086",
      "id" : 35005086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27455931896",
  "text" : "RT @Wolfram_Alpha: We're celebrating Dictionary Day (Oct. 16) with new word data in Wolfram|Alpha! What's your favorite word? http:\/\/bit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27454314688",
    "text" : "We're celebrating Dictionary Day (Oct. 16) with new word data in Wolfram|Alpha! What's your favorite word? http:\/\/bit.ly\/9PNC0M",
    "id" : 27454314688,
    "created_at" : "2010-10-15 15:53:13 +0000",
    "user" : {
      "name" : "Wolfram|Alpha",
      "screen_name" : "Wolfram_Alpha",
      "protected" : false,
      "id_str" : "35005086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489803647153217537\/NH6ZQxzT_normal.png",
      "id" : 35005086,
      "verified" : true
    }
  },
  "id" : 27455931896,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abeman",
      "screen_name" : "abeman",
      "indices" : [ 35, 42 ],
      "id_str" : "16679523",
      "id" : 16679523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27457011404",
  "text" : "good rant about homeschooling!\nvia @abeman \nGetting pissed off again about this bogus 'socialization' concern (cont) http:\/\/tl.gd\/6gbt2t",
  "id" : 27457011404,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27456319022",
  "geo" : { },
  "id_str" : "27457932691",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts my issue? U mean regarding DC? eh, just see posts & wonder why. I dunno, I don't see it..",
  "id" : 27457932691,
  "in_reply_to_status_id" : 27456319022,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27458024304",
  "text" : "My iPod Touch keeps beeping at me .. On & off. Annoys me!",
  "id" : 27458024304,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 25, 36 ],
      "id_str" : "39331231",
      "id" : 39331231
    }, {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 37, 46 ],
      "id_str" : "46760072",
      "id" : 46760072
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 78, 93 ],
      "id_str" : "62867227",
      "id" : 62867227
    }, {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 94, 102 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 103, 112 ],
      "id_str" : "15396585",
      "id" : 15396585
    }, {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 113, 124 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 125, 137 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27458593467",
  "text" : "When I need a hug... #FF @dhammagirl @WahminSC @WhiteRoseWiccan @Twyttlededum @thesexyatheist @SangyeH @Moonrust @mimismutts @AlisynGayle",
  "id" : 27458593467,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27458695642",
  "geo" : { },
  "id_str" : "27459646384",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I'm not obsessed fan but I like what he has to say. A lot resonates w me.. where I'm at now.",
  "id" : 27459646384,
  "in_reply_to_status_id" : 27458695642,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elsa Joy Bailey",
      "screen_name" : "iamwun",
      "indices" : [ 3, 10 ],
      "id_str" : "32729111",
      "id" : 32729111
    }, {
      "name" : "Dean Boedeker",
      "screen_name" : "deanboedeker",
      "indices" : [ 15, 28 ],
      "id_str" : "60471583",
      "id" : 60471583
    }, {
      "name" : "Mike Nelson Pedde",
      "screen_name" : "wolfnowl",
      "indices" : [ 30, 39 ],
      "id_str" : "28144954",
      "id" : 28144954
    }, {
      "name" : "Christopher Wheat",
      "screen_name" : "nantucketartist",
      "indices" : [ 41, 57 ],
      "id_str" : "25935621",
      "id" : 25935621
    }, {
      "name" : "Lucky Balaraman",
      "screen_name" : "luckyb52",
      "indices" : [ 59, 68 ],
      "id_str" : "3291901",
      "id" : 3291901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27299889204",
  "text" : "RT @iamwun: RT @deanboedeker: @wolfnowl: @nantucketartist: @luckyb52:  \"I met God. I met the devil. God won.\" ~Mario Sepulveda, Chilean  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dean Boedeker",
        "screen_name" : "deanboedeker",
        "indices" : [ 3, 16 ],
        "id_str" : "60471583",
        "id" : 60471583
      }, {
        "name" : "Mike Nelson Pedde",
        "screen_name" : "wolfnowl",
        "indices" : [ 18, 27 ],
        "id_str" : "28144954",
        "id" : 28144954
      }, {
        "name" : "Christopher Wheat",
        "screen_name" : "nantucketartist",
        "indices" : [ 29, 45 ],
        "id_str" : "25935621",
        "id" : 25935621
      }, {
        "name" : "Lucky Balaraman",
        "screen_name" : "luckyb52",
        "indices" : [ 47, 56 ],
        "id_str" : "3291901",
        "id" : 3291901
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27297458522",
    "text" : "RT @deanboedeker: @wolfnowl: @nantucketartist: @luckyb52:  \"I met God. I met the devil. God won.\" ~Mario Sepulveda, Chilean miner",
    "id" : 27297458522,
    "created_at" : "2010-10-14 01:33:47 +0000",
    "user" : {
      "name" : "Elsa Joy Bailey",
      "screen_name" : "iamwun",
      "protected" : false,
      "id_str" : "32729111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421678021\/rose4_normal.PNG",
      "id" : 32729111,
      "verified" : false
    }
  },
  "id" : 27299889204,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27300489682",
  "text" : "RT @TheEntertainer: If someone doesn't like you or is jealous of you or projects their sh*t on you, don't take it seriously. Just Do You ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27298993290",
    "text" : "If someone doesn't like you or is jealous of you or projects their sh*t on you, don't take it seriously. Just Do You anyway!",
    "id" : 27298993290,
    "created_at" : "2010-10-14 01:51:22 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 27300489682,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make Money Online",
      "screen_name" : "davescotperth",
      "indices" : [ 3, 17 ],
      "id_str" : "2156594318",
      "id" : 2156594318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27301185319",
  "text" : "RT @Davescotperth: loading brain . . . please wait..   99% Complete...   Failed please try again.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27301152357",
    "text" : "loading brain . . . please wait..   99% Complete...   Failed please try again.",
    "id" : 27301152357,
    "created_at" : "2010-10-14 02:16:52 +0000",
    "user" : {
      "name" : "Dave Kay",
      "screen_name" : "Riseofperdition",
      "protected" : false,
      "id_str" : "74907005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560991643776471040\/ThLc9EEQ_normal.jpeg",
      "id" : 74907005,
      "verified" : false
    }
  },
  "id" : 27301185319,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27340429939",
  "text" : "Another night of sweat & chills. Aren't I too young for this???",
  "id" : 27340429939,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Harv Eker",
      "screen_name" : "T_Harv_Eker",
      "indices" : [ 3, 15 ],
      "id_str" : "17884330",
      "id" : 17884330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27340485670",
  "text" : "RT @T_Harv_Eker: Today's Declaration: I can be kind, loving, balanced, and really really rich!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27338100743",
    "text" : "Today's Declaration: I can be kind, loving, balanced, and really really rich!",
    "id" : 27338100743,
    "created_at" : "2010-10-14 13:00:52 +0000",
    "user" : {
      "name" : "T. Harv Eker",
      "screen_name" : "T_Harv_Eker",
      "protected" : false,
      "id_str" : "17884330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/72605619\/harvmind2jpg_normal.JPG",
      "id" : 17884330,
      "verified" : false
    }
  },
  "id" : 27340485670,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27340803485",
  "text" : "So DD's progress report was really really good. What's up w that?",
  "id" : 27340803485,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27343795280",
  "geo" : { },
  "id_str" : "27346715629",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts I don't get hot \"flashes\" per se but I do get hot easily.. & the sweating thing while sleeping.. I'm 44.",
  "id" : 27346715629,
  "in_reply_to_status_id" : 27343795280,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27365660675",
  "geo" : { },
  "id_str" : "27366258278",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL",
  "id" : 27366258278,
  "in_reply_to_status_id" : 27365660675,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 0, 9 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27371075817",
  "geo" : { },
  "id_str" : "27374013143",
  "in_reply_to_user_id" : 15396585,
  "text" : "@Moonrust saw this on news.. Interesting..",
  "id" : 27374013143,
  "in_reply_to_status_id" : 27371075817,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27372092620",
  "geo" : { },
  "id_str" : "27374260065",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ((highfive))",
  "id" : 27374260065,
  "in_reply_to_status_id" : 27372092620,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27374518078",
  "text" : "I'm not going to TKD tonight. Hubby hasn't fed me yet & he thinks French toast will suffice for dinner. I'm not a happy camper!!!!",
  "id" : 27374518078,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27374603973",
  "text" : "My blood sugar drops a lot if I don't eat. I had cereal this am, 2 pcs toast this aft. I'm starving here...",
  "id" : 27374603973,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 23, 38 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27375303857",
  "text" : "Mmm I love cheese!! RT @ReformedBuddha: In every moment, there is an opportunity to see this is the only moment - I hate my cheesy quotes",
  "id" : 27375303857,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27375373886",
  "geo" : { },
  "id_str" : "27375499262",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 exactly! Never understood the sin thing & graphic showing sin separates us from god blahblahblah",
  "id" : 27375499262,
  "in_reply_to_status_id" : 27375373886,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27375569682",
  "text" : "Warning: I'm really really hungry so I'm insane right now & will be sassy. Sorry in advance!",
  "id" : 27375569682,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vortex",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27375623730",
  "text" : "RT @abe_quotes: ...We want you to ignore reality long enough to get into the #Vortex...",
  "id" : 27375623730,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 28, 44 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27376781939",
  "text" : "This explains a lot! Lol RT @DoreenVirtue444: Quiet solitude is a nutritional need of your ascending body, dear children.",
  "id" : 27376781939,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 27, 40 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mynatgivaway",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "itunes",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27376890739",
  "text" : "RT @MyNatureApps: Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway #itunes Enter here -&gt; http:\/\/tinyurl.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff",
        "screen_name" : "MyNatureApps",
        "indices" : [ 9, 22 ],
        "id_str" : "93072985",
        "id" : 93072985
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mynatgivaway",
        "indices" : [ 62, 75 ]
      }, {
        "text" : "itunes",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27376500560",
    "text" : "Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway #itunes Enter here -&gt; http:\/\/tinyurl.com\/22uoqsp",
    "id" : 27376500560,
    "created_at" : "2010-10-14 21:08:14 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 27376890739,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 0, 10 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27377069038",
  "text" : "@ID_vs_EGO hahaha!! : )",
  "id" : 27377069038,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27381948761",
  "text" : "RT @richarddoetsch: \u265EHow many people live for tomorrow at the sacrifice of today? - The 13th Hour",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27379026822",
    "text" : "\u265EHow many people live for tomorrow at the sacrifice of today? - The 13th Hour",
    "id" : 27379026822,
    "created_at" : "2010-10-14 21:44:15 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 27381948761,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 0, 9 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27380134253",
  "geo" : { },
  "id_str" : "27382149678",
  "in_reply_to_user_id" : 15396585,
  "text" : "@Moonrust LOL : )",
  "id" : 27382149678,
  "in_reply_to_status_id" : 27380134253,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27382457364",
  "text" : "Love to see my tweeps hugging.. makes me weepy.. Lol",
  "id" : 27382457364,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "Jesus_M_Christ",
      "indices" : [ 3, 18 ],
      "id_str" : "31206614",
      "id" : 31206614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatwouldbeawesome",
      "indices" : [ 59, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27385802700",
  "text" : "RT @Jesus_M_Christ: If y'all would stop killing in my name #thatwouldbeawesome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thatwouldbeawesome",
        "indices" : [ 39, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27382083204",
    "text" : "If y'all would stop killing in my name #thatwouldbeawesome",
    "id" : 27382083204,
    "created_at" : "2010-10-14 22:26:24 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "Jesus_M_Christ",
      "protected" : false,
      "id_str" : "31206614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2343720581\/bn83yd6d4bg5qkjfhlok_normal.jpeg",
      "id" : 31206614,
      "verified" : false
    }
  },
  "id" : 27385802700,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27385959575",
  "text" : "RT @HannahKicksLyme: Who came up with the idea that a massive deer hunt would downsize tick population and Lyme disease? Stupid.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27382598426",
    "text" : "Who came up with the idea that a massive deer hunt would downsize tick population and Lyme disease? Stupid.",
    "id" : 27382598426,
    "created_at" : "2010-10-14 22:33:21 +0000",
    "user" : {
      "name" : "Hannah",
      "screen_name" : "HealingHannah",
      "protected" : false,
      "id_str" : "52291216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800241867807932416\/83xhRpbI_normal.jpg",
      "id" : 52291216,
      "verified" : false
    }
  },
  "id" : 27385959575,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Nico Martini",
      "screen_name" : "drnicomartini",
      "indices" : [ 54, 68 ],
      "id_str" : "16228113",
      "id" : 16228113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27385992399",
  "text" : "RT @ZachsMind: I wasn't aware she now OWNS Alaska! RT @drnicomartini: Just saw a preview of Sarah Palin's Alaska.. It actually looks kin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nico Martini",
        "screen_name" : "drnicomartini",
        "indices" : [ 39, 53 ],
        "id_str" : "16228113",
        "id" : 16228113
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bwe10",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27384239381",
    "text" : "I wasn't aware she now OWNS Alaska! RT @drnicomartini: Just saw a preview of Sarah Palin's Alaska.. It actually looks kinda amazing.. #bwe10",
    "id" : 27384239381,
    "created_at" : "2010-10-14 22:55:13 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 27385992399,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27382692751",
  "geo" : { },
  "id_str" : "27386317003",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC back at ya! : )",
  "id" : 27386317003,
  "in_reply_to_status_id" : 27382692751,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27386454846",
  "text" : "Sometimes reading my tweet stream is like watching a soap opera! I love my tweeps. I like it when they get along. : )",
  "id" : 27386454846,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 9, 22 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27386490178",
  "text" : "YES!! RT @earthXplorer: Two words make my night-- The Office :)",
  "id" : 27386490178,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 16, 26 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27386686535",
  "text" : "RT @SangyeH: RT @JALpalyul: In science we've learned that objects, indeed, ppl r mostly space. We have atoms &molecules & betw them is e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 3, 13 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27386582224",
    "text" : "RT @JALpalyul: In science we've learned that objects, indeed, ppl r mostly space. We have atoms &molecules & betw them is empty space. So it",
    "id" : 27386582224,
    "created_at" : "2010-10-14 23:25:16 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 27386686535,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27270583229",
  "text" : "I don't want to die because I don't want to have to come back.",
  "id" : 27270583229,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27270710954",
  "text" : "Teacher wants DD's class to watch the news to be informed... Umm, that's against my religion?",
  "id" : 27270710954,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27270786119",
  "geo" : { },
  "id_str" : "27272323761",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts for me? Both.",
  "id" : 27272323761,
  "in_reply_to_status_id" : 27270786119,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "QJ0hn",
      "indices" : [ 0, 6 ],
      "id_str" : "733991620316651524",
      "id" : 733991620316651524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27272738424",
  "text" : "@qj0hn : )",
  "id" : 27272738424,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27272822806",
  "text" : "RT @ShhDragon: The shortest distance between two points is under construction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27272337589",
    "text" : "The shortest distance between two points is under construction",
    "id" : 27272337589,
    "created_at" : "2010-10-13 20:06:16 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 27272822806,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "QJ0hn",
      "indices" : [ 0, 6 ],
      "id_str" : "733991620316651524",
      "id" : 733991620316651524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27273025269",
  "text" : "@qj0hn this is a scary thought in a way.. so I'll still be screwed up, huh? Lol",
  "id" : 27273025269,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27273124445",
  "text" : "I left my job at a good time. They were clamping down on Internet access.",
  "id" : 27273124445,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 16, 31 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27191776021",
  "text" : "RT @mimismutts: @JonathanElliot As best I can figure, God hears all prayers free unless you use a minister at which point you owe a mana ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Elliot",
        "screen_name" : "JonathanElliot",
        "indices" : [ 0, 15 ],
        "id_str" : "30825946",
        "id" : 30825946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "27189293768",
    "geo" : { },
    "id_str" : "27189545213",
    "in_reply_to_user_id" : 30825946,
    "text" : "@JonathanElliot As best I can figure, God hears all prayers free unless you use a minister at which point you owe a management fee",
    "id" : 27189545213,
    "in_reply_to_status_id" : 27189293768,
    "created_at" : "2010-10-13 00:33:19 +0000",
    "in_reply_to_screen_name" : "JonathanElliot",
    "in_reply_to_user_id_str" : "30825946",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 27191776021,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 27, 40 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mynatgivaway",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27196654391",
  "text" : "RT @MyNatureApps: Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway Enter here -&gt; http:\/\/tinyurl.com\/22uoqsp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff",
        "screen_name" : "MyNatureApps",
        "indices" : [ 9, 22 ],
        "id_str" : "93072985",
        "id" : 93072985
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mynatgivaway",
        "indices" : [ 62, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27196193947",
    "text" : "Awesome! @mynatureapps is giving away a $15 iTunes Gift Card! #mynatgivaway Enter here -&gt; http:\/\/tinyurl.com\/22uoqsp",
    "id" : 27196193947,
    "created_at" : "2010-10-13 01:38:36 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 27196654391,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    }, {
      "name" : "Lynne A.",
      "screen_name" : "LynneElmira",
      "indices" : [ 23, 35 ],
      "id_str" : "23255171",
      "id" : 23255171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27233514520",
  "text" : "RT @stevetheseeker: RT @LynneElmira: - \" The power elite\" ...a hugely powerful global group...hindering we the people ...all the time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lynne A.",
        "screen_name" : "LynneElmira",
        "indices" : [ 3, 15 ],
        "id_str" : "23255171",
        "id" : 23255171
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27230938376",
    "text" : "RT @LynneElmira: - \" The power elite\" ...a hugely powerful global group...hindering we the people ...all the time.",
    "id" : 27230938376,
    "created_at" : "2010-10-13 11:08:39 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 27233514520,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "Sheriff Jim Wilson",
      "screen_name" : "sheriffjim",
      "indices" : [ 21, 32 ],
      "id_str" : "43161701",
      "id" : 43161701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27233707083",
  "text" : "RT @MyNatureApps: RT @sheriffjim: We all learn from experience but some of us have to go to summer school.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sheriff Jim Wilson",
        "screen_name" : "sheriffjim",
        "indices" : [ 3, 14 ],
        "id_str" : "43161701",
        "id" : 43161701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27232465079",
    "text" : "RT @sheriffjim: We all learn from experience but some of us have to go to summer school.",
    "id" : 27232465079,
    "created_at" : "2010-10-13 11:34:31 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 27233707083,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dog Lover",
      "screen_name" : "DogsMyLove",
      "indices" : [ 15, 26 ],
      "id_str" : "88103001",
      "id" : 88103001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27236400125",
  "text" : "RT @RMoGib: RT @DogsMyLove: Outside of a dog, a book is a man's best friend: and inside a dog, it's too dark to read. - Groucho Marx #do ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dog Lover",
        "screen_name" : "DogsMyLove",
        "indices" : [ 3, 14 ],
        "id_str" : "88103001",
        "id" : 88103001
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dog",
        "indices" : [ 121, 125 ]
      }, {
        "text" : "quote",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27234270865",
    "text" : "RT @DogsMyLove: Outside of a dog, a book is a man's best friend: and inside a dog, it's too dark to read. - Groucho Marx #dog #quote",
    "id" : 27234270865,
    "created_at" : "2010-10-13 12:02:26 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 27236400125,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27265731840",
  "text" : "RT @abe_quotes: Parents in despair, far from their Vortices of Well-Being, have no love to give.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27265269746",
    "text" : "Parents in despair, far from their Vortices of Well-Being, have no love to give.",
    "id" : 27265269746,
    "created_at" : "2010-10-13 18:21:28 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 27265731840,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27265737511",
  "text" : "RT @abe_quotes: ...And so, the child assumes he is not loved because something is wrong with him...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27265310639",
    "text" : "...And so, the child assumes he is not loved because something is wrong with him...",
    "id" : 27265310639,
    "created_at" : "2010-10-13 18:22:04 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 27265737511,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Abraham",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27265749646",
  "text" : "RT @abe_quotes: ...rather than understanding he is not being loved by his parents because they are out of alignment with love.\n\n#Abraham ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abraham",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27265338448",
    "text" : "...rather than understanding he is not being loved by his parents because they are out of alignment with love.\n\n#Abraham via yahoo groups",
    "id" : 27265338448,
    "created_at" : "2010-10-13 18:22:29 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 27265749646,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 10, 25 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27268087835",
  "text" : "Hmmm.. RT @MartijnLinssen: Amazed to read people who've been \"seekers\" for 40 years now - patience isn't always a virtue",
  "id" : 27268087835,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27268359519",
  "text" : "I ate a muffin I shouldn't have eaten. Ugh.. My non-existent gallbladder does not like..",
  "id" : 27268359519,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27268392732",
  "text" : "I was hungry & I'm too lazy to cook anything. I wait for hubby.",
  "id" : 27268392732,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27268628157",
  "text" : "I get high on my ideas then I crash...",
  "id" : 27268628157,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27268158440",
  "geo" : { },
  "id_str" : "27268760889",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen so it all comes to nothing?? I'm tired of searching, doubting. Just want to be happy. Sigh.",
  "id" : 27268760889,
  "in_reply_to_status_id" : 27268158440,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27268813734",
  "text" : "I'm feeling really cranky this afternoon! : (",
  "id" : 27268813734,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27269335444",
  "geo" : { },
  "id_str" : "27270491448",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen you got a point there, sir. Good article. Thx 4 link. : )",
  "id" : 27270491448,
  "in_reply_to_status_id" : 27269335444,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "Chris",
      "screen_name" : "CM57",
      "indices" : [ 13, 18 ],
      "id_str" : "22081769",
      "id" : 22081769
    }, {
      "name" : "Lisa Reid",
      "screen_name" : "lisareid",
      "indices" : [ 19, 28 ],
      "id_str" : "14656530",
      "id" : 14656530
    }, {
      "name" : "Candid Kippax",
      "screen_name" : "CandidK",
      "indices" : [ 29, 37 ],
      "id_str" : "710348550115368960",
      "id" : 710348550115368960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27089633921",
  "text" : "RT @CandyTX: @CM57 @lisareid @candidk I love my Sony 505 but I want a Kindle for Xmas 4 DD & I 2 share..lol",
  "id" : 27089633921,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27093263032",
  "text" : "RT @DeepakChopra: Never give up hope. Know that you are loved.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27091940790",
    "text" : "Never give up hope. Know that you are loved.",
    "id" : 27091940790,
    "created_at" : "2010-10-12 01:28:41 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 27093263032,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Sambuchino",
      "screen_name" : "ChuckSambuchino",
      "indices" : [ 3, 19 ],
      "id_str" : "87096816",
      "id" : 87096816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27093481526",
  "text" : "RT @ChuckSambuchino: A good book is one you flip through with no intention of actually reading, and before you know it, you've gone thro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27092794703",
    "text" : "A good book is one you flip through with no intention of actually reading, and before you know it, you've gone through 30 pages.",
    "id" : 27092794703,
    "created_at" : "2010-10-12 01:37:53 +0000",
    "user" : {
      "name" : "Chuck Sambuchino",
      "screen_name" : "ChuckSambuchino",
      "protected" : false,
      "id_str" : "87096816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515155018\/c2_normal.bmp",
      "id" : 87096816,
      "verified" : false
    }
  },
  "id" : 27093481526,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OP",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27093764206",
  "text" : "RT @oshum: There will come a time..soon...when all will return to innocence..when the fractured whole will be wholy holy once more. #OP",
  "id" : 27093764206,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27093876404",
  "text" : "@Diane_Can me, too : )",
  "id" : 27093876404,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27094047584",
  "text" : "RT @gemswinc: Cat And Pet Skunk Make Great Siblings - http:\/\/bzfd.it\/aJQ55M  ~ major cute alert!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/buzzfeed.com\" rel=\"nofollow\"\u003EBuzzFeed Mobile\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27093799082",
    "text" : "Cat And Pet Skunk Make Great Siblings - http:\/\/bzfd.it\/aJQ55M  ~ major cute alert!",
    "id" : 27093799082,
    "created_at" : "2010-10-12 01:50:54 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 27094047584,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev Run",
      "screen_name" : "RevRunWisdom",
      "indices" : [ 3, 16 ],
      "id_str" : "23832022",
      "id" : 23832022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27094771522",
  "text" : "RT @RevRunWisdom: For peace of mind stop tryin 2 b general manager of the universe!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27062084303",
    "text" : "For peace of mind stop tryin 2 b general manager of the universe!!!",
    "id" : 27062084303,
    "created_at" : "2010-10-11 19:24:19 +0000",
    "user" : {
      "name" : "Rev Run",
      "screen_name" : "RevRunWisdom",
      "protected" : false,
      "id_str" : "23832022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1163695042\/Mr._Simmons_3A_normal.jpg",
      "id" : 23832022,
      "verified" : true
    }
  },
  "id" : 27094771522,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27096551149",
  "text" : "@Diane_Can that all is divinely perfect.. Endings bring beginnings.. It's all good even if I don't understand.",
  "id" : 27096551149,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AtheistRE",
      "screen_name" : "AtheistRE",
      "indices" : [ 3, 13 ],
      "id_str" : "27731797",
      "id" : 27731797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27096700203",
  "text" : "RT @AtheistRE: You are not born worthless, wretched, broken, or lost.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27093980670",
    "text" : "You are not born worthless, wretched, broken, or lost.",
    "id" : 27093980670,
    "created_at" : "2010-10-12 01:53:01 +0000",
    "user" : {
      "name" : "AtheistRE",
      "screen_name" : "AtheistRE",
      "protected" : false,
      "id_str" : "27731797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1162540433\/atheistre_bike_normal.jpg",
      "id" : 27731797,
      "verified" : false
    }
  },
  "id" : 27096700203,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unvirtuous Abbey",
      "screen_name" : "UnvirtuousAbbey",
      "indices" : [ 3, 19 ],
      "id_str" : "174526877",
      "id" : 174526877
    }, {
      "name" : "Unvirtuous Abbey",
      "screen_name" : "UnvirtuousAbbey",
      "indices" : [ 76, 92 ],
      "id_str" : "174526877",
      "id" : 174526877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27139113197",
  "text" : "RT @UnvirtuousAbbey: This morning, we've been working our own miracles here @UnvirtuousAbbey by turning water into coffee.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unvirtuous Abbey",
        "screen_name" : "UnvirtuousAbbey",
        "indices" : [ 55, 71 ],
        "id_str" : "174526877",
        "id" : 174526877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27136834579",
    "text" : "This morning, we've been working our own miracles here @UnvirtuousAbbey by turning water into coffee.",
    "id" : 27136834579,
    "created_at" : "2010-10-12 13:13:42 +0000",
    "user" : {
      "name" : "Unvirtuous Abbey",
      "screen_name" : "UnvirtuousAbbey",
      "protected" : false,
      "id_str" : "174526877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714045317461753857\/zPXbzkE4_normal.jpg",
      "id" : 174526877,
      "verified" : false
    }
  },
  "id" : 27139113197,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zoe Nishimuta",
      "screen_name" : "zoenishimuta",
      "indices" : [ 14, 27 ],
      "id_str" : "21393675",
      "id" : 21393675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27139198942",
  "text" : "Smooches!! RT @zoenishimuta: Mysty says hi http:\/\/yfrog.com\/3tvr0qj",
  "id" : 27139198942,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori Krout",
      "screen_name" : "DogPawPrint",
      "indices" : [ 3, 15 ],
      "id_str" : "30969375",
      "id" : 30969375
    }, {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 65, 78 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27165440689",
  "text" : "RT @DogPawPrint: Be careful of xylitol too (in sugarless gum) RT @grouchypuppy: With Halloween comes chocolate...keep your dogs safehttp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grouchy Puppy\u00AE",
        "screen_name" : "grouchypuppy",
        "indices" : [ 48, 61 ],
        "id_str" : "29913475",
        "id" : 29913475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27080330924",
    "text" : "Be careful of xylitol too (in sugarless gum) RT @grouchypuppy: With Halloween comes chocolate...keep your dogs safehttp:\/\/cot.ag\/ctX1Tp",
    "id" : 27080330924,
    "created_at" : "2010-10-11 23:46:09 +0000",
    "user" : {
      "name" : "Lori Krout",
      "screen_name" : "DogPawPrint",
      "protected" : false,
      "id_str" : "30969375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2160451073\/LoriProfileforWeb_normal.jpg",
      "id" : 30969375,
      "verified" : false
    }
  },
  "id" : 27165440689,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27166569976",
  "geo" : { },
  "id_str" : "27167134900",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 ((hugs)) MIL doing therapy 4 new knee.. hoping I die B4 joints fall apart...",
  "id" : 27167134900,
  "in_reply_to_status_id" : 27166569976,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "indices" : [ 11, 23 ],
      "id_str" : "27426615",
      "id" : 27426615
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 30, 38 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27057817104",
  "text" : "Agree!! RT @DaveUrsillo: Dear @Twitter, there MUST be an easier way to sort, and especially DELETE DMs en masse.",
  "id" : 27057817104,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeadEndFiction",
      "screen_name" : "DeadEndFiction",
      "indices" : [ 3, 18 ],
      "id_str" : "129790203",
      "id" : 129790203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27058027451",
  "text" : "RT @DeadEndFiction: Her baby bit into her nipple, she could not wrench it from her breast; it sucked her dry, leaving Rusk-like remains  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27055541309",
    "text" : "Her baby bit into her nipple, she could not wrench it from her breast; it sucked her dry, leaving Rusk-like remains and no one to burp it.",
    "id" : 27055541309,
    "created_at" : "2010-10-11 17:50:54 +0000",
    "user" : {
      "name" : "DeadEndFiction",
      "screen_name" : "DeadEndFiction",
      "protected" : false,
      "id_str" : "129790203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1156140184\/tree-halloween_normal.jpg",
      "id" : 129790203,
      "verified" : false
    }
  },
  "id" : 27058027451,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "dusty gedge",
      "screen_name" : "greenroofsuk",
      "indices" : [ 23, 36 ],
      "id_str" : "53416347",
      "id" : 53416347
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IUCN",
      "indices" : [ 85, 90 ]
    }, {
      "text" : "iyb",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27061537412",
  "text" : "RT @KerriFar: tiny! RT @greenroofsuk: Cute but little known - S. American Opossum is #IUCN species of hte day - #iyb # biodiversity http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dusty gedge",
        "screen_name" : "greenroofsuk",
        "indices" : [ 9, 22 ],
        "id_str" : "53416347",
        "id" : 53416347
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IUCN",
        "indices" : [ 71, 76 ]
      }, {
        "text" : "iyb",
        "indices" : [ 98, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27058924641",
    "text" : "tiny! RT @greenroofsuk: Cute but little known - S. American Opossum is #IUCN species of hte day - #iyb # biodiversity http:\/\/ow.ly\/2RtPw",
    "id" : 27058924641,
    "created_at" : "2010-10-11 18:37:53 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 27061537412,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27064862693",
  "text" : "the dog just french-kissed me.. ohlala! ; )",
  "id" : 27064862693,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27065275511",
  "text" : "She kissed me cuz I had kibble on my lips from playing in her dish.",
  "id" : 27065275511,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27066688821",
  "text" : "I think I need to duke it out w the Universe.. Sigh.",
  "id" : 27066688821,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristiBowman",
      "screen_name" : "ChristiBowman",
      "indices" : [ 3, 17 ],
      "id_str" : "15826206",
      "id" : 15826206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27068119168",
  "text" : "RT @ChristiBowman: RT @seculagaytheist: I am bored. As in hoping-Mormons-will-knock-on-my door bored. &lt;~ Ha! Ha! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27067066064",
    "text" : "RT @seculagaytheist: I am bored. As in hoping-Mormons-will-knock-on-my door bored. &lt;~ Ha! Ha! :)",
    "id" : 27067066064,
    "created_at" : "2010-10-11 20:39:42 +0000",
    "user" : {
      "name" : "ChristiBowman",
      "screen_name" : "ChristiBowman",
      "protected" : false,
      "id_str" : "15826206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2360738687\/image_normal.jpg",
      "id" : 15826206,
      "verified" : false
    }
  },
  "id" : 27068119168,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27074576779",
  "text" : "RT @Wylieknowords: \"The great versatility of mathematics depends on the fact that it is a language empitied of any meaning.\" scientist - ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27072122581",
    "text" : "\"The great versatility of mathematics depends on the fact that it is a language empitied of any meaning.\" scientist - Lugi Foschini",
    "id" : 27072122581,
    "created_at" : "2010-10-11 21:56:11 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 27074576779,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27074705564",
  "text" : "@SamsaricWarrior It's beautiful! I love it! : )",
  "id" : 27074705564,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27074800524",
  "text" : "RT @angelaharms: Want to be an Agile mentor? The first post is up on http:\/\/myAgileEducation.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27072756389",
    "text" : "Want to be an Agile mentor? The first post is up on http:\/\/myAgileEducation.com",
    "id" : 27072756389,
    "created_at" : "2010-10-11 22:05:17 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 27074800524,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 13, 25 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27075338515",
  "text" : "AWWWWWW!! RT @mindymayhem: The kitten helps me make Halloween cards http:\/\/twitpic.com\/2wtuhf",
  "id" : 27075338515,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 0, 14 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27074809262",
  "geo" : { },
  "id_str" : "27075372480",
  "in_reply_to_user_id" : 159213309,
  "text" : "@Unique_Misfit nighty-night : )",
  "id" : 27075372480,
  "in_reply_to_status_id" : 27074809262,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27076597997",
  "geo" : { },
  "id_str" : "27077061144",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL (sorry...)",
  "id" : 27077061144,
  "in_reply_to_status_id" : 27076597997,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27077225357",
  "text" : "I look out over my twitter stream and I am... pleased.",
  "id" : 27077225357,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27080405532",
  "text" : "RT @KerriFar: Sweeeeet! RT @ReneeFineArt Through my lens today: Mischievous cat in a pink bag http:\/\/t.co\/vRKjPeu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 99 ],
        "url" : "http:\/\/t.co\/vRKjPeu",
        "expanded_url" : "http:\/\/rhfineartphoto.posterous.com\/mischievous-cat-in-a-pink-bag",
        "display_url" : "rhfineartphoto.posterous.com\/mischievous-ca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "27079751750",
    "text" : "Sweeeeet! RT @ReneeFineArt Through my lens today: Mischievous cat in a pink bag http:\/\/t.co\/vRKjPeu",
    "id" : 27079751750,
    "created_at" : "2010-10-11 23:39:23 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 27080405532,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26984199919",
  "text" : "Phrenic Philosophy: a mind unleashed: Video: Agnosticism & Labels http:\/\/bit.ly\/bwAl8N",
  "id" : 26984199919,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26987690672",
  "text" : "Battleground God http:\/\/bit.ly\/cFqNyh",
  "id" : 26987690672,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26988903122",
  "text" : "RT @WhiteRoseWiccan: Life is the School, Love is the Lesson:)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26988862730",
    "text" : "Life is the School, Love is the Lesson:)",
    "id" : 26988862730,
    "created_at" : "2010-10-11 01:23:52 +0000",
    "user" : {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "protected" : false,
      "id_str" : "36200541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791356505366863872\/Cf1sRt7f_normal.jpg",
      "id" : 36200541,
      "verified" : false
    }
  },
  "id" : 26988903122,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheikh Muhammad",
      "screen_name" : "Sheikh_Muhammad",
      "indices" : [ 3, 19 ],
      "id_str" : "18446484",
      "id" : 18446484
    }, {
      "name" : "amy4669",
      "screen_name" : "amy4669",
      "indices" : [ 24, 32 ],
      "id_str" : "18528603",
      "id" : 18528603
    }, {
      "name" : "Beki",
      "screen_name" : "TheRustedChain",
      "indices" : [ 36, 51 ],
      "id_str" : "18645279",
      "id" : 18645279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26991425781",
  "text" : "RT @Sheikh_Muhammad: RT @amy4669 RT @TheRustedChain: Today I broke my record for number of days I haven't died. Tomorrow I hope to break ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "amy4669",
        "screen_name" : "amy4669",
        "indices" : [ 3, 11 ],
        "id_str" : "18528603",
        "id" : 18528603
      }, {
        "name" : "Beki",
        "screen_name" : "TheRustedChain",
        "indices" : [ 15, 30 ],
        "id_str" : "18645279",
        "id" : 18645279
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26983785859",
    "text" : "RT @amy4669 RT @TheRustedChain: Today I broke my record for number of days I haven't died. Tomorrow I hope to break it again.",
    "id" : 26983785859,
    "created_at" : "2010-10-11 00:16:47 +0000",
    "user" : {
      "name" : "Sheikh Muhammad",
      "screen_name" : "Sheikh_Muhammad",
      "protected" : false,
      "id_str" : "18446484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2194923023\/522614_10151570442025066_512780065_23739600_1914873734_n_normal.jpg",
      "id" : 18446484,
      "verified" : false
    }
  },
  "id" : 26991425781,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 3, 15 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26991628829",
  "text" : "RT @HuffPostPol: Carl Paladino: Don't Be 'Brainwashed' Into Thinking Homosexuality Is An 'Equally Valid' Lifestyle (VIDEO) http:\/\/huff.t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26987136835",
    "text" : "Carl Paladino: Don't Be 'Brainwashed' Into Thinking Homosexuality Is An 'Equally Valid' Lifestyle (VIDEO) http:\/\/huff.to\/drovg9",
    "id" : 26987136835,
    "created_at" : "2010-10-11 01:02:03 +0000",
    "user" : {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "protected" : false,
      "id_str" : "15458694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696718733721542656\/2lsNdbhH_normal.png",
      "id" : 15458694,
      "verified" : true
    }
  },
  "id" : 26991628829,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Ravitch",
      "screen_name" : "DianeRavitch",
      "indices" : [ 3, 16 ],
      "id_str" : "59010637",
      "id" : 59010637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26992698275",
  "text" : "RT @DianeRavitch: Our national obsession with testing is nuts: http:\/\/tinyurl.com\/359gjtx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26384987893",
    "text" : "Our national obsession with testing is nuts: http:\/\/tinyurl.com\/359gjtx",
    "id" : 26384987893,
    "created_at" : "2010-10-04 18:11:28 +0000",
    "user" : {
      "name" : "Diane Ravitch",
      "screen_name" : "DianeRavitch",
      "protected" : false,
      "id_str" : "59010637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432006051806711808\/j9yLHBaQ_normal.png",
      "id" : 59010637,
      "verified" : false
    }
  },
  "id" : 26992698275,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27033088763",
  "text" : "@SamsaricWarrior had 2 look that up..lol.. Nice yard & patio.",
  "id" : 27033088763,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27033184491",
  "text" : "RT @earthXplorer: Please deposit more coffee to continue......",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tap11.com\" rel=\"nofollow\"\u003ETap11\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27029757841",
    "text" : "Please deposit more coffee to continue......",
    "id" : 27029757841,
    "created_at" : "2010-10-11 12:43:48 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 27033184491,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27033376105",
  "text" : "RT @GraveStomper: If you never adventure out from your own little ghetto of people who you're comfortable with you'll never be more than ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27031230323",
    "text" : "If you never adventure out from your own little ghetto of people who you're comfortable with you'll never be more than you are now.",
    "id" : 27031230323,
    "created_at" : "2010-10-11 13:03:25 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 27033376105,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27033405754",
  "text" : "RT @GraveStomper: Every threat to your identity that you attack is a wasted opportunity to become something greater than you are right now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27031436545",
    "text" : "Every threat to your identity that you attack is a wasted opportunity to become something greater than you are right now.",
    "id" : 27031436545,
    "created_at" : "2010-10-11 13:06:09 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 27033405754,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Socall",
      "screen_name" : "kristinesocall",
      "indices" : [ 3, 18 ],
      "id_str" : "136400434",
      "id" : 136400434
    }, {
      "name" : "T\u1ECD\u0301p\u1EB9\u0301 F\u00E1d\u00ECran",
      "screen_name" : "graceishuman",
      "indices" : [ 20, 33 ],
      "id_str" : "167426475",
      "id" : 167426475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27033444419",
  "text" : "RT @kristinesocall: @graceishuman just a thot mayB we shld elim words like \"they\" - coz, we're part of the \"they\" too and that just crea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "T\u1ECD\u0301p\u1EB9\u0301 F\u00E1d\u00ECran",
        "screen_name" : "graceishuman",
        "indices" : [ 0, 13 ],
        "id_str" : "167426475",
        "id" : 167426475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "27031578970",
    "geo" : { },
    "id_str" : "27031712635",
    "in_reply_to_user_id" : 167426475,
    "text" : "@graceishuman just a thot mayB we shld elim words like \"they\" - coz, we're part of the \"they\" too and that just creates \"sides\"",
    "id" : 27031712635,
    "in_reply_to_status_id" : 27031578970,
    "created_at" : "2010-10-11 13:09:29 +0000",
    "in_reply_to_screen_name" : "graceishuman",
    "in_reply_to_user_id_str" : "167426475",
    "user" : {
      "name" : "Kris Socall",
      "screen_name" : "kristinesocall",
      "protected" : false,
      "id_str" : "136400434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1518236037\/kris_normal.jpg",
      "id" : 136400434,
      "verified" : false
    }
  },
  "id" : 27033444419,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sacred Witness",
      "screen_name" : "SacredWitness",
      "indices" : [ 3, 17 ],
      "id_str" : "3085133691",
      "id" : 3085133691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27034639857",
  "text" : "RT @SacredWitness: Columbus Day Musings: \nColumbus Day.\u00A0 How is it that the USA can celebrate Christopher Columbus\u2014a man who started ... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27034213660",
    "text" : "Columbus Day Musings: \nColumbus Day.\u00A0 How is it that the USA can celebrate Christopher Columbus\u2014a man who started ... http:\/\/bit.ly\/c2yL3T",
    "id" : 27034213660,
    "created_at" : "2010-10-11 13:39:56 +0000",
    "user" : {
      "name" : "Carla Royal",
      "screen_name" : "CarlaRoyal",
      "protected" : false,
      "id_str" : "28894048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823476520\/13fdf78af18d23f2cf1dc63aceb88301_normal.jpeg",
      "id" : 28894048,
      "verified" : false
    }
  },
  "id" : 27034639857,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "B.laqphamas",
      "screen_name" : "blaqphamas",
      "indices" : [ 97, 108 ],
      "id_str" : "29975781",
      "id" : 29975781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27034772094",
  "text" : "RT @DeepakChopra: No sin is ignorance. Everyone does their best from their level of awareness RT @Blaqphamas:do you believe in sin?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "B.laqphamas",
        "screen_name" : "blaqphamas",
        "indices" : [ 79, 90 ],
        "id_str" : "29975781",
        "id" : 29975781
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27034485911",
    "text" : "No sin is ignorance. Everyone does their best from their level of awareness RT @Blaqphamas:do you believe in sin?",
    "id" : 27034485911,
    "created_at" : "2010-10-11 13:43:06 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 27034772094,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27035926929",
  "text" : "RT @RevDebra: Nat'l Coming Out Day. I support LGBT people because sexual + gender diversity is a blessing that enriches us all...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27026268395",
    "text" : "Nat'l Coming Out Day. I support LGBT people because sexual + gender diversity is a blessing that enriches us all...",
    "id" : 27026268395,
    "created_at" : "2010-10-11 11:52:49 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 27035926929,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "webs",
      "screen_name" : "websdotcom",
      "indices" : [ 3, 14 ],
      "id_str" : "365066474",
      "id" : 365066474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27036002128",
  "text" : "RT @websdotcom: There are a lot of different things one must consider when making a website. One important characteristic of a... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27035004468",
    "text" : "There are a lot of different things one must consider when making a website. One important characteristic of a... http:\/\/fb.me\/FmGNderv",
    "id" : 27035004468,
    "created_at" : "2010-10-11 13:49:08 +0000",
    "user" : {
      "name" : "Webs",
      "screen_name" : "webs",
      "protected" : false,
      "id_str" : "17473289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684823130347573248\/Xj0Kq180_normal.png",
      "id" : 17473289,
      "verified" : false
    }
  },
  "id" : 27036002128,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27036128138",
  "text" : "RT @BigBookofYou: 7 Amazing Lessons from 7 Distinguished Billionaires: http:\/\/dld.bz\/c5TC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27035264882",
    "text" : "7 Amazing Lessons from 7 Distinguished Billionaires: http:\/\/dld.bz\/c5TC",
    "id" : 27035264882,
    "created_at" : "2010-10-11 13:52:09 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 27036128138,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27036376738",
  "text" : "The light is expanding faster. So many changes happening. What an exciting time to be alive!",
  "id" : 27036376738,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Halloween",
      "indices" : [ 118, 128 ]
    }, {
      "text" : "kindle",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27036593254",
  "text" : "RT @hauntedcomputer: Enter your favorite Halloween candy at http:\/\/www.jennsbookshelves.com and maybe win a Kindle DX #Halloween #kindle ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Halloween",
        "indices" : [ 97, 107 ]
      }, {
        "text" : "kindle",
        "indices" : [ 108, 115 ]
      }, {
        "text" : "books",
        "indices" : [ 116, 122 ]
      }, {
        "text" : "bookbloggers",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27035987820",
    "text" : "Enter your favorite Halloween candy at http:\/\/www.jennsbookshelves.com and maybe win a Kindle DX #Halloween #kindle #books #bookbloggers",
    "id" : 27035987820,
    "created_at" : "2010-10-11 14:01:21 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 27036593254,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 3, 13 ],
      "id_str" : "41457590",
      "id" : 41457590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27036666774",
  "text" : "RT @38harmony: ~ Like rungs on a ladder we ascend with each loving  tweet :)  http:\/\/twitpic.com\/2up1k2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27036154316",
    "text" : "~ Like rungs on a ladder we ascend with each loving  tweet :)  http:\/\/twitpic.com\/2up1k2",
    "id" : 27036154316,
    "created_at" : "2010-10-11 14:03:14 +0000",
    "user" : {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "protected" : false,
      "id_str" : "41457590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1671334755\/2-HH-5-27-7_normal.jpg",
      "id" : 41457590,
      "verified" : false
    }
  },
  "id" : 27036666774,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Griffith",
      "screen_name" : "TarotHeals",
      "indices" : [ 3, 14 ],
      "id_str" : "35105327",
      "id" : 35105327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27036875448",
  "text" : "RT @TarotHeals: 10+11+2010=6 Lovers: Opportunities today for connecting with like minded people!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27036824622",
    "text" : "10+11+2010=6 Lovers: Opportunities today for connecting with like minded people!",
    "id" : 27036824622,
    "created_at" : "2010-10-11 14:10:37 +0000",
    "user" : {
      "name" : "Cindy Griffith",
      "screen_name" : "TarotHeals",
      "protected" : false,
      "id_str" : "35105327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603941015423217664\/jeP-h5xH_normal.jpg",
      "id" : 35105327,
      "verified" : false
    }
  },
  "id" : 27036875448,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27039074113",
  "text" : "RT @DeepakChopra: I do not believe in sin. I believe that humans are in different stages of spiritual development & act from their level ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27037388414",
    "text" : "I do not believe in sin. I believe that humans are in different stages of spiritual development & act from their level of awareness",
    "id" : 27037388414,
    "created_at" : "2010-10-11 14:16:47 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 27039074113,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27047441911",
  "text" : "\"you're honestly the one person in our grade who has never pissed me off\" -classmate to DD.. thought that was funny..lol",
  "id" : 27047441911,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 35, 46 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27047737968",
  "text" : "Pretty! Is it warm enuf 2 swim? RT @mimismutts: Good morning tweeps boy fall in AZ http:\/\/twitpic.com\/2wqwg9",
  "id" : 27047737968,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27048152523",
  "geo" : { },
  "id_str" : "27049579322",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle on FB, they say like my status & I'll tell u what I like\/dislike about u.. DD loves those..lol",
  "id" : 27049579322,
  "in_reply_to_status_id" : 27048152523,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27049458946",
  "geo" : { },
  "id_str" : "27049696514",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts mmm.. Nice!",
  "id" : 27049696514,
  "in_reply_to_status_id" : 27049458946,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26888919557",
  "geo" : { },
  "id_str" : "26890756578",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem Yes!! It was meant to be. : ) happy for you & kitty",
  "id" : 26890756578,
  "in_reply_to_status_id" : 26888919557,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "indices" : [ 3, 18 ],
      "id_str" : "17621549",
      "id" : 17621549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChooseKindness",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26895635280",
  "text" : "RT @ReikiAwakening: You have a choice. We all do. #ChooseKindness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChooseKindness",
        "indices" : [ 30, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26894955503",
    "text" : "You have a choice. We all do. #ChooseKindness",
    "id" : 26894955503,
    "created_at" : "2010-10-10 01:42:57 +0000",
    "user" : {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "protected" : false,
      "id_str" : "17621549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487076852842778625\/uKEYUGdu_normal.jpeg",
      "id" : 17621549,
      "verified" : false
    }
  },
  "id" : 26895635280,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26895711671",
  "text" : "RT @PinarAkal1: Be kind, for everyone you meet is fighting a hard battle. ~Plato",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26895201590",
    "text" : "Be kind, for everyone you meet is fighting a hard battle. ~Plato",
    "id" : 26895201590,
    "created_at" : "2010-10-10 01:46:13 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 26895711671,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD",
      "screen_name" : "argylestyle",
      "indices" : [ 3, 15 ],
      "id_str" : "17241517",
      "id" : 17241517
    }, {
      "name" : "Dee",
      "screen_name" : "deephil11",
      "indices" : [ 20, 30 ],
      "id_str" : "177810624",
      "id" : 177810624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26897161481",
  "text" : "RT @argylestyle: RT @deephil11: Don't let those who lack empathy bring you down. Compassion is a heavy burden. Not everyone can handle it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dee",
        "screen_name" : "deephil11",
        "indices" : [ 3, 13 ],
        "id_str" : "177810624",
        "id" : 177810624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26896105618",
    "text" : "RT @deephil11: Don't let those who lack empathy bring you down. Compassion is a heavy burden. Not everyone can handle it.",
    "id" : 26896105618,
    "created_at" : "2010-10-10 01:58:08 +0000",
    "user" : {
      "name" : "JD",
      "screen_name" : "argylestyle",
      "protected" : false,
      "id_str" : "17241517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650816811211038720\/rHoijTlR_normal.jpg",
      "id" : 17241517,
      "verified" : false
    }
  },
  "id" : 26897161481,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26898120069",
  "geo" : { },
  "id_str" : "26898242166",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yes, she's adorable! : )",
  "id" : 26898242166,
  "in_reply_to_status_id" : 26898120069,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DouglasAdams",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26942796413",
  "text" : "RT @ShhDragon: Today is 10\/10\/10 day or 101010 in binary.  Which is... 42.\n\n#DouglasAdams",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DouglasAdams",
        "indices" : [ 61, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26941386223",
    "text" : "Today is 10\/10\/10 day or 101010 in binary.  Which is... 42.\n\n#DouglasAdams",
    "id" : 26941386223,
    "created_at" : "2010-10-10 14:33:32 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 26942796413,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK Rising",
      "screen_name" : "DKRising",
      "indices" : [ 3, 12 ],
      "id_str" : "716678263855267840",
      "id" : 716678263855267840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26947043088",
  "text" : "RT @DKRising: It's Sunday. It's cold. Two things I do not like.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26946278177",
    "text" : "It's Sunday. It's cold. Two things I do not like.",
    "id" : 26946278177,
    "created_at" : "2010-10-10 15:31:01 +0000",
    "user" : {
      "name" : "DK",
      "screen_name" : "horseandahalf",
      "protected" : false,
      "id_str" : "28032888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2250219073\/3622258089_0d9032f127_b_normal.jpg",
      "id" : 28032888,
      "verified" : false
    }
  },
  "id" : 26947043088,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26949834386",
  "text" : "Scott Nicholson Blog Tour: Twenty-Kindle Giveaway | Simply Stacie http:\/\/bit.ly\/cY9fnh",
  "id" : 26949834386,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny",
      "screen_name" : "gennepher",
      "indices" : [ 3, 13 ],
      "id_str" : "62311852",
      "id" : 62311852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gogyohka",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26951474073",
  "text" : "RT @gennepher: the bird in the cage \/ who sings \/ to be free \/ the child looks out \/ of the classroom window #gogyohka Flickrpic http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitthat.com\/\" rel=\"nofollow\"\u003Etwitthat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gogyohka",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26950702035",
    "text" : "the bird in the cage \/ who sings \/ to be free \/ the child looks out \/ of the classroom window #gogyohka Flickrpic http:\/\/bit.ly\/bGA6S6",
    "id" : 26950702035,
    "created_at" : "2010-10-10 16:24:39 +0000",
    "user" : {
      "name" : "Jenny",
      "screen_name" : "gennepher",
      "protected" : false,
      "id_str" : "62311852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1453903991\/copy_2nd_but_cat_normal.png",
      "id" : 62311852,
      "verified" : false
    }
  },
  "id" : 26951474073,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HumanRightsCampaign",
      "screen_name" : "HRC",
      "indices" : [ 134, 138 ],
      "id_str" : "19608297",
      "id" : 19608297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "comingout",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "comingout",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954079649",
  "text" : "I am a straight ally and I'm #comingout for LGBT equality this National Coming Out Day. Join me! http:\/\/bit.ly\/bWALby #comingout (via @HRC)",
  "id" : 26954079649,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954455683",
  "text" : "RT @wow_trees: Let's not be anti-anything. Instead let's be pro-something.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26951877574",
    "text" : "Let's not be anti-anything. Instead let's be pro-something.",
    "id" : 26951877574,
    "created_at" : "2010-10-10 16:39:20 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 26954455683,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Effie Mcintosh",
      "screen_name" : "AKbirder",
      "indices" : [ 41, 50 ],
      "id_str" : "4202024795",
      "id" : 4202024795
    }, {
      "name" : "Angela Gonzalez",
      "screen_name" : "ayatlin",
      "indices" : [ 55, 63 ],
      "id_str" : "19104042",
      "id" : 19104042
    }, {
      "name" : "Marc Lester",
      "screen_name" : "marclesterphoto",
      "indices" : [ 80, 96 ],
      "id_str" : "121832583",
      "id" : 121832583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954686046",
  "text" : "RT @KerriFar: What a FAB shot! WOWZA! RT @AKbirder: RT @ayatlin: Great shot! RT @marclesterphoto: Photo: Moose in the mountains. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Effie Mcintosh",
        "screen_name" : "AKbirder",
        "indices" : [ 27, 36 ],
        "id_str" : "4202024795",
        "id" : 4202024795
      }, {
        "name" : "Angela Gonzalez",
        "screen_name" : "ayatlin",
        "indices" : [ 41, 49 ],
        "id_str" : "19104042",
        "id" : 19104042
      }, {
        "name" : "Marc Lester",
        "screen_name" : "marclesterphoto",
        "indices" : [ 66, 82 ],
        "id_str" : "121832583",
        "id" : 121832583
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26952719300",
    "text" : "What a FAB shot! WOWZA! RT @AKbirder: RT @ayatlin: Great shot! RT @marclesterphoto: Photo: Moose in the mountains. http:\/\/bit.ly\/cCR8xO",
    "id" : 26952719300,
    "created_at" : "2010-10-10 16:50:05 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 26954686046,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954895927",
  "text" : "RT @bunnybuddhism: Neither fire nor wind, birth nor death can erase the bunniness we extend to others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26953443019",
    "text" : "Neither fire nor wind, birth nor death can erase the bunniness we extend to others.",
    "id" : 26953443019,
    "created_at" : "2010-10-10 16:59:27 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 26954895927,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954950302",
  "text" : "RT @BestAt: RT @DrippingAsh: 10-10-10 is XXX in Roman numerals. HAPPY PORN DAY!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26953943365",
    "text" : "RT @DrippingAsh: 10-10-10 is XXX in Roman numerals. HAPPY PORN DAY!",
    "id" : 26953943365,
    "created_at" : "2010-10-10 17:05:51 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 26954950302,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enlightened Warrior",
      "screen_name" : "GetInTheVortex",
      "indices" : [ 3, 18 ],
      "id_str" : "82787787",
      "id" : 82787787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954993563",
  "text" : "RT @GetInTheVortex: Your only goal is to feel good no matter what and that means getting into the Vortex.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26954306955",
    "text" : "Your only goal is to feel good no matter what and that means getting into the Vortex.",
    "id" : 26954306955,
    "created_at" : "2010-10-10 17:10:29 +0000",
    "user" : {
      "name" : "Enlightened Warrior",
      "screen_name" : "GetInTheVortex",
      "protected" : false,
      "id_str" : "82787787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3584098641\/67bf02b400fd2f8e36bc9ae4ce8e2954_normal.jpeg",
      "id" : 82787787,
      "verified" : false
    }
  },
  "id" : 26954993563,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26973547521",
  "text" : "Carly thinks it's weird that Griffen likes PeeWee Babies.. Sigh.",
  "id" : 26973547521,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 0, 14 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26971513452",
  "geo" : { },
  "id_str" : "26973662829",
  "in_reply_to_user_id" : 159213309,
  "text" : "@Unique_Misfit you have to make them different & I know you will.",
  "id" : 26973662829,
  "in_reply_to_status_id" : 26971513452,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26973703853",
  "text" : "RT @BrianRathbone: I'm looking for a voice actor to read 20 or so lines as an older, dim-witted man for a short story. Deep(ish) voice p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26972290916",
    "text" : "I'm looking for a voice actor to read 20 or so lines as an older, dim-witted man for a short story. Deep(ish) voice preferred. Interested?",
    "id" : 26972290916,
    "created_at" : "2010-10-10 21:23:11 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 26973703853,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26973890040",
  "text" : "Gone all afternoon and no @ tweets 4 me. Does it mean I'm crazy that I'm disappointed & that I have no life so @ tweets are highlight of day",
  "id" : 26973890040,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26973956391",
  "text" : "Went to visit inlaws. MIL loves family visits : ) Cheers her up.",
  "id" : 26973956391,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 0, 13 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26974439386",
  "geo" : { },
  "id_str" : "26974772585",
  "in_reply_to_user_id" : 41965454,
  "text" : "@manzano_moon awww! Back at ya! : )",
  "id" : 26974772585,
  "in_reply_to_status_id" : 26974439386,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "manzano_moon",
  "in_reply_to_user_id_str" : "41965454",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26974860241",
  "text" : "OMG!! Carly broke up w him because he collected mini stuffed animals! WTF???",
  "id" : 26974860241,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Help the Animals",
      "screen_name" : "HelpAnimals",
      "indices" : [ 3, 15 ],
      "id_str" : "16953808",
      "id" : 16953808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26977479729",
  "text" : "RT @HelpAnimals: Urgent, NY: handsome dog to be killed unless someone comes for him. Please give him a home. He wants to live. He's... h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26976122787",
    "text" : "Urgent, NY: handsome dog to be killed unless someone comes for him. Please give him a home. He wants to live. He's... http:\/\/fb.me\/HBAqEgsI",
    "id" : 26976122787,
    "created_at" : "2010-10-10 22:24:30 +0000",
    "user" : {
      "name" : "Help the Animals",
      "screen_name" : "HelpAnimals",
      "protected" : false,
      "id_str" : "16953808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501748691\/Tiger_Jumping_normal.gif",
      "id" : 16953808,
      "verified" : false
    }
  },
  "id" : 26977479729,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Carlson, LWBMG",
      "screen_name" : "rabbitboxer3",
      "indices" : [ 3, 16 ],
      "id_str" : "123799953",
      "id" : 123799953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26978957326",
  "text" : "RT @rabbitboxer3: look I believe in god I just don't think god would want men saying what is right or wrong in his name or harm anyone",
  "id" : 26978957326,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26887651103",
  "text" : "@tragic_pizza ehhh.. I kinda miss the other pizza...",
  "id" : 26887651103,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26886803544",
  "geo" : { },
  "id_str" : "26887979947",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle I may have to find an eye patch. Going to mall, stores gives me headaches from looking out.",
  "id" : 26887979947,
  "in_reply_to_status_id" : 26886803544,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26888017807",
  "text" : "A nice bath lightened my mood a bit : )",
  "id" : 26888017807,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26887647604",
  "geo" : { },
  "id_str" : "26888154548",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis me, too!",
  "id" : 26888154548,
  "in_reply_to_status_id" : 26887647604,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26888330014",
  "text" : "@tragic_pizza nonono.. Never saw other pizza as victim.. Bold, honest, caring 4 the underdog",
  "id" : 26888330014,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26888629595",
  "text" : "@tragic_pizza I kinda figured you were doing something there.. LOL",
  "id" : 26888629595,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Pyle",
      "screen_name" : "djpyle",
      "indices" : [ 3, 10 ],
      "id_str" : "23011183",
      "id" : 23011183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26801334172",
  "text" : "RT @djpyle: Who wants to see the wraparound paperback cover for DISMEMBER?  http:\/\/twitpic.com\/2vtwcl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26799031303",
    "text" : "Who wants to see the wraparound paperback cover for DISMEMBER?  http:\/\/twitpic.com\/2vtwcl",
    "id" : 26799031303,
    "created_at" : "2010-10-09 00:32:03 +0000",
    "user" : {
      "name" : "Daniel Pyle",
      "screen_name" : "djpyle",
      "protected" : false,
      "id_str" : "23011183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629382459205881856\/kw0s3bz6_normal.png",
      "id" : 23011183,
      "verified" : false
    }
  },
  "id" : 26801334172,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26852145385",
  "text" : "The dog is having grand time ripping apart Ritz crackers box.",
  "id" : 26852145385,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26852242136",
  "text" : "Half-n-half in my coffee this morning = bliss",
  "id" : 26852242136,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26854714116",
  "geo" : { },
  "id_str" : "26855604316",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem while I don't think you lack maturity, Mindy, I do side with Carmen in that you argue a lot..lol..but I'm still fond of you : )",
  "id" : 26855604316,
  "in_reply_to_status_id" : 26854714116,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26855922636",
  "geo" : { },
  "id_str" : "26856035124",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts well... That's just.. weird! LOL",
  "id" : 26856035124,
  "in_reply_to_status_id" : 26855922636,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26856463759",
  "geo" : { },
  "id_str" : "26856873516",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem Agreed on that point. I like Carmen, too. Two bright, caring women w soft spot 4 animals! : )",
  "id" : 26856873516,
  "in_reply_to_status_id" : 26856463759,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26856973614",
  "text" : "What's this about twitter not being \"real life\".. Who died & made you God?? ; )",
  "id" : 26856973614,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26857076128",
  "text" : "I love my tweeps. Their tweets make me happy, sad, joyful, angry.. Whole gamut of emotions..",
  "id" : 26857076128,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26856662761",
  "geo" : { },
  "id_str" : "26857188749",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem and you're a great teacher! Muah!!",
  "id" : 26857188749,
  "in_reply_to_status_id" : 26856662761,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 0, 13 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26856926169",
  "geo" : { },
  "id_str" : "26857277745",
  "in_reply_to_user_id" : 41965454,
  "text" : "@manzano_moon Happy Birthday!! ((confettieverywhere!)) : )",
  "id" : 26857277745,
  "in_reply_to_status_id" : 26856926169,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "manzano_moon",
  "in_reply_to_user_id_str" : "41965454",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "teaparty",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26857602445",
  "text" : "RT @mindymayhem: You can read a lexicon to a vegetable but you can't make it capable of independent thought.  #tcot  #teaparty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 93, 98 ]
      }, {
        "text" : "teaparty",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26857509338",
    "text" : "You can read a lexicon to a vegetable but you can't make it capable of independent thought.  #tcot  #teaparty",
    "id" : 26857509338,
    "created_at" : "2010-10-09 16:31:25 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 26857602445,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26857637249",
  "geo" : { },
  "id_str" : "26857930318",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem I remember you posting about a cat you liked. Hopefully you'll be a new mommy today!",
  "id" : 26857930318,
  "in_reply_to_status_id" : 26857637249,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tom jamieson",
      "screen_name" : "jamiesont",
      "indices" : [ 3, 13 ],
      "id_str" : "36941760",
      "id" : 36941760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26858130299",
  "text" : "RT @jamiesont: Theoretical physicists come to blows ar rally over whether time is of the essence or is an artificial construct #sciencei ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scienceisvital",
        "indices" : [ 112, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26857949200",
    "text" : "Theoretical physicists come to blows ar rally over whether time is of the essence or is an artificial construct #scienceisvital",
    "id" : 26857949200,
    "created_at" : "2010-10-09 16:36:55 +0000",
    "user" : {
      "name" : "tom jamieson",
      "screen_name" : "jamiesont",
      "protected" : false,
      "id_str" : "36941760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608567338510766080\/uu7O2py8_normal.png",
      "id" : 36941760,
      "verified" : false
    }
  },
  "id" : 26858130299,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceisvital",
      "indices" : [ 18, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26859664518",
  "text" : "RT @derekrootboy: #scienceisvital Yes, it is. But so are universal benefits, decent wages for everyone, free education. Tax the rich. We ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scienceisvital",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26858781842",
    "text" : "#scienceisvital Yes, it is. But so are universal benefits, decent wages for everyone, free education. Tax the rich. Welfare not warfare",
    "id" : 26858781842,
    "created_at" : "2010-10-09 16:47:11 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 26859664518,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26858793159",
  "geo" : { },
  "id_str" : "26859754046",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind of course animals have souls, too! &lt;3",
  "id" : 26859754046,
  "in_reply_to_status_id" : 26858793159,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26860054657",
  "text" : "RT @TheEntertainer: Being free is a state of mind, it's a choice, it's a \"vibe.\" Everybody nude. (oops, different party.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26859974887",
    "text" : "Being free is a state of mind, it's a choice, it's a \"vibe.\" Everybody nude. (oops, different party.)",
    "id" : 26859974887,
    "created_at" : "2010-10-09 17:02:14 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 26860054657,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26860246765",
  "geo" : { },
  "id_str" : "26860533372",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind which would be why I never followed religion. Sorry I missed point. Brain has missed connections!",
  "id" : 26860533372,
  "in_reply_to_status_id" : 26860246765,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "QJ0hn",
      "indices" : [ 0, 6 ],
      "id_str" : "733991620316651524",
      "id" : 733991620316651524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26864642921",
  "text" : "@qj0hn impossible! lol",
  "id" : 26864642921,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "QJ0hn",
      "indices" : [ 0, 6 ],
      "id_str" : "733991620316651524",
      "id" : 733991620316651524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26864657275",
  "text" : "@qj0hn impossible! lol",
  "id" : 26864657275,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26865007529",
  "text" : "RT @Palidan: \"A good deed is never lost; he who sows courtesy reaps friendship; and he who plants kindness gathers love.\" St. Basil",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26864729413",
    "text" : "\"A good deed is never lost; he who sows courtesy reaps friendship; and he who plants kindness gathers love.\" St. Basil",
    "id" : 26864729413,
    "created_at" : "2010-10-09 18:05:03 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 26865007529,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teenage Atheist",
      "screen_name" : "TeenageAtheist",
      "indices" : [ 0, 15 ],
      "id_str" : "152397330",
      "id" : 152397330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26486702114",
  "geo" : { },
  "id_str" : "26865386708",
  "in_reply_to_user_id" : 152397330,
  "text" : "@TeenageAtheist Cool! I'm not a spider-stomper but my DD is.. :\/ Live & let live I say! : )",
  "id" : 26865386708,
  "in_reply_to_status_id" : 26486702114,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "TeenageAtheist",
  "in_reply_to_user_id_str" : "152397330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26866200193",
  "text" : "RT @Palidan: \"Don't let someone else's opinion of you become your reality.\" Les Brown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26865993552",
    "text" : "\"Don't let someone else's opinion of you become your reality.\" Les Brown",
    "id" : 26865993552,
    "created_at" : "2010-10-09 18:23:02 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 26866200193,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 11, 25 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26867952435",
  "text" : "Me! : ) RT @NewMindMirror: How to Treat Your Introvert  http:\/\/su.pr\/1HkRM5",
  "id" : 26867952435,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26868374913",
  "geo" : { },
  "id_str" : "26868821998",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 heehee yeah, that was good!",
  "id" : 26868821998,
  "in_reply_to_status_id" : 26868374913,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Friedman",
      "screen_name" : "Lauren_Hannah",
      "indices" : [ 3, 17 ],
      "id_str" : "17354295",
      "id" : 17354295
    }, {
      "name" : "Quotes For Writers",
      "screen_name" : "quotes4writers",
      "indices" : [ 22, 37 ],
      "id_str" : "229636388",
      "id" : 229636388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26868963063",
  "text" : "RT @Lauren_Hannah: RT @quotes4writers \"Don't annoy the writer. They may put you in a book and kill you.\" Anonymous (Related article: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quotes For Writers",
        "screen_name" : "quotes4writers",
        "indices" : [ 3, 18 ],
        "id_str" : "229636388",
        "id" : 229636388
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26868404413",
    "text" : "RT @quotes4writers \"Don't annoy the writer. They may put you in a book and kill you.\" Anonymous (Related article: http:\/\/dld.bz\/dSg9)",
    "id" : 26868404413,
    "created_at" : "2010-10-09 19:00:16 +0000",
    "user" : {
      "name" : "Lauren Friedman",
      "screen_name" : "Lauren_Hannah",
      "protected" : false,
      "id_str" : "17354295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735982115834068992\/Cp-Y8ppR_normal.jpg",
      "id" : 17354295,
      "verified" : true
    }
  },
  "id" : 26868963063,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26873556037",
  "text" : "\"Success is my only motherfucking option, failure's not\" Lose Yourself - Eminem",
  "id" : 26873556037,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26876405153",
  "text" : "Waiting for hubby to finish making dinner. I'm getting hungry...",
  "id" : 26876405153,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26883876145",
  "text" : "Hubby's watching stupid movies & I'm bored...",
  "id" : 26883876145,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26883894914",
  "text" : "Very bored...",
  "id" : 26883894914,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26884032412",
  "text" : "Oh so bored...",
  "id" : 26884032412,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26884077322",
  "text" : "I can't even take a bath as DD just took a shower.",
  "id" : 26884077322,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26884227678",
  "geo" : { },
  "id_str" : "26885096524",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem I'm sorry you didn't get to go today...",
  "id" : 26885096524,
  "in_reply_to_status_id" : 26884227678,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26885250207",
  "text" : "I want to poke my left eye out.",
  "id" : 26885250207,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26885308173",
  "text" : "Electronic eyes should have been invented by now, seriously.",
  "id" : 26885308173,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26885435597",
  "text" : "I'm kinda missing my nephew.. haven't seen him since March. That would make my mom sad...",
  "id" : 26885435597,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26885409556",
  "geo" : { },
  "id_str" : "26885541919",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle I'm happiest when I have ideas...",
  "id" : 26885541919,
  "in_reply_to_status_id" : 26885409556,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26885450275",
  "geo" : { },
  "id_str" : "26885668005",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle Wait.. what?? I always feel like poking that eye out. My eyes don't work together in distance.",
  "id" : 26885668005,
  "in_reply_to_status_id" : 26885450275,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26885494080",
  "geo" : { },
  "id_str" : "26885778780",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle You have a point.. I could drag out some craft thing..",
  "id" : 26885778780,
  "in_reply_to_status_id" : 26885494080,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26885836460",
  "text" : "RT @bunnybuddhism: One must approach bunniness with gentle yet precise discipline.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26885792496",
    "text" : "One must approach bunniness with gentle yet precise discipline.",
    "id" : 26885792496,
    "created_at" : "2010-10-09 23:35:16 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 26885836460,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26777848323",
  "text" : "RT @Wylieknowords: \"Does this (((((TWEET))))) make me look fat?\" N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26777636746",
    "text" : "\"Does this (((((TWEET))))) make me look fat?\" N. Wylie Jones www.knowords.com",
    "id" : 26777636746,
    "created_at" : "2010-10-08 19:17:48 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 26777848323,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nasty Julie",
      "screen_name" : "JulieLeto",
      "indices" : [ 3, 13 ],
      "id_str" : "16271640",
      "id" : 16271640
    }, {
      "name" : "SueG LS",
      "screen_name" : "SueGrimshaw",
      "indices" : [ 15, 27 ],
      "id_str" : "27507236",
      "id" : 27507236
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ninc",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26793870101",
  "text" : "RT @JulieLeto: @SueGrimshaw #ninc Learned that social media and reader\/author interaction will be (is?) game changer in new publishing w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SueG LS",
        "screen_name" : "SueGrimshaw",
        "indices" : [ 0, 12 ],
        "id_str" : "27507236",
        "id" : 27507236
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ninc",
        "indices" : [ 13, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26783511327",
    "in_reply_to_user_id" : 27507236,
    "text" : "@SueGrimshaw #ninc Learned that social media and reader\/author interaction will be (is?) game changer in new publishing world.",
    "id" : 26783511327,
    "created_at" : "2010-10-08 20:46:59 +0000",
    "in_reply_to_screen_name" : "SueGrimshaw",
    "in_reply_to_user_id_str" : "27507236",
    "user" : {
      "name" : "Nasty Julie",
      "screen_name" : "JulieLeto",
      "protected" : false,
      "id_str" : "16271640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1624041949\/headshot_normal.jpg",
      "id" : 16271640,
      "verified" : false
    }
  },
  "id" : 26793870101,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26689254111",
  "geo" : { },
  "id_str" : "26704191877",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords Im sorry I couldnt be of more help : ( I hate it when I cant figure out a computer thing...",
  "id" : 26704191877,
  "in_reply_to_status_id" : 26689254111,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26704613267",
  "text" : "@HEATHENRABBIT Hubby & I were in tears with Marley & Me.. just sobbing.. not a pretty sight!!",
  "id" : 26704613267,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Damn Dirty Ape",
      "screen_name" : "Zaius13",
      "indices" : [ 20, 28 ],
      "id_str" : "16952499",
      "id" : 16952499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26704938097",
  "text" : "RT @mindymayhem: RT @Zaius13: I hate to brag, but it's the most effortless way to enlighten people about my magnificence.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Damn Dirty Ape",
        "screen_name" : "Zaius13",
        "indices" : [ 3, 11 ],
        "id_str" : "16952499",
        "id" : 16952499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26702070428",
    "text" : "RT @Zaius13: I hate to brag, but it's the most effortless way to enlighten people about my magnificence.",
    "id" : 26702070428,
    "created_at" : "2010-10-08 00:51:26 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 26704938097,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26709903911",
  "text" : "RT @Wylieknowords: Any of my followers have trouble getting RT, reply,etc. at the botttom of the Tweet on New Twitter?Could it be my bro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26708574760",
    "text" : "Any of my followers have trouble getting RT, reply,etc. at the botttom of the Tweet on New Twitter?Could it be my browser or computer power?",
    "id" : 26708574760,
    "created_at" : "2010-10-08 02:11:16 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 26709903911,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26709970645",
  "text" : "RT @Wylieknowords: I tried New Twitter this morning and the RT and reply,etc.didn't show up on the Tweets at the bottom.Happen to anyone ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26706231960",
    "text" : "I tried New Twitter this morning and the RT and reply,etc.didn't show up on the Tweets at the bottom.Happen to anyone else?",
    "id" : 26706231960,
    "created_at" : "2010-10-08 01:42:07 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 26709970645,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Hunter",
      "screen_name" : "amyandwillow",
      "indices" : [ 3, 16 ],
      "id_str" : "188067857",
      "id" : 188067857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26710445744",
  "text" : "RT @amyandwillow: \u201CThe law of attraction is the law of love, and it is the law that is operating your life.\u201D Rhonda Byrne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26710298776",
    "text" : "\u201CThe law of attraction is the law of love, and it is the law that is operating your life.\u201D Rhonda Byrne",
    "id" : 26710298776,
    "created_at" : "2010-10-08 02:33:53 +0000",
    "user" : {
      "name" : "Amy Hunter",
      "screen_name" : "amyandwillow",
      "protected" : false,
      "id_str" : "188067857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120602620\/lab11_normal.jpg",
      "id" : 188067857,
      "verified" : false
    }
  },
  "id" : 26710445744,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26710903977",
  "text" : "RT @FreeRangeKids: Four young kids left in a car at a school for 5 minutes. And 3 onlookers yelling, \"TERRIBLE MOM!\"  http:\/\/bit.ly\/bCb5sE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26710516772",
    "text" : "Four young kids left in a car at a school for 5 minutes. And 3 onlookers yelling, \"TERRIBLE MOM!\"  http:\/\/bit.ly\/bCb5sE",
    "id" : 26710516772,
    "created_at" : "2010-10-08 02:36:41 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 26710903977,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26747605226",
  "text" : "Interesting - The Space Between Atoms http:\/\/bit.ly\/8Xyzpr",
  "id" : 26747605226,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Autism Tips",
      "screen_name" : "AutismTips",
      "indices" : [ 3, 14 ],
      "id_str" : "46947210",
      "id" : 46947210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26753786089",
  "text" : "RT @AutismTips: \u201CIf a child can't learn the way we teach, maybe we should teach the way they learn.\u201D - Ignacio Estrada",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26751480872",
    "text" : "\u201CIf a child can't learn the way we teach, maybe we should teach the way they learn.\u201D - Ignacio Estrada",
    "id" : 26751480872,
    "created_at" : "2010-10-08 14:00:31 +0000",
    "user" : {
      "name" : "Autism Tips",
      "screen_name" : "AutismTips",
      "protected" : false,
      "id_str" : "46947210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000439938754\/a237eff4bb23b2ae7ec9bcec31e9d9d9_normal.jpeg",
      "id" : 46947210,
      "verified" : false
    }
  },
  "id" : 26753786089,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26754290039",
  "text" : "RT @earthXplorer: Followers aren't numbers, they're ppl. Individuals w\/ideas, hopes, dreams, troubles & triumphs! I'm grateful 4 each &  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tap11.com\" rel=\"nofollow\"\u003ETap11\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 127, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26754173749",
    "text" : "Followers aren't numbers, they're ppl. Individuals w\/ideas, hopes, dreams, troubles & triumphs! I'm grateful 4 each & every 1! #FF",
    "id" : 26754173749,
    "created_at" : "2010-10-08 14:29:07 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 26754290039,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26754741394",
  "text" : "Dear Universe, I so appreciate that DDs freshman year is going smoothly. TY!!",
  "id" : 26754741394,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "contests",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "giveaways",
      "indices" : [ 109, 119 ]
    }, {
      "text" : "books",
      "indices" : [ 120, 126 ]
    }, {
      "text" : "read",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26759119047",
  "text" : "RT @DarciaHelle: Win 'Hit List' & a new mousepad in my October Book Giveaway! http:\/\/bit.ly\/cHmcMg #contests #giveaways #books #read",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "contests",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "giveaways",
        "indices" : [ 92, 102 ]
      }, {
        "text" : "books",
        "indices" : [ 103, 109 ]
      }, {
        "text" : "read",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26758324128",
    "text" : "Win 'Hit List' & a new mousepad in my October Book Giveaway! http:\/\/bit.ly\/cHmcMg #contests #giveaways #books #read",
    "id" : 26758324128,
    "created_at" : "2010-10-08 15:12:46 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 26759119047,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26758527291",
  "geo" : { },
  "id_str" : "26759234359",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms oh that's exc idea!",
  "id" : 26759234359,
  "in_reply_to_status_id" : 26758527291,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26759900807",
  "text" : "RT @earthXplorer: It's so simple....be nice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tap11.com\" rel=\"nofollow\"\u003ETap11\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26759817996",
    "text" : "It's so simple....be nice",
    "id" : 26759817996,
    "created_at" : "2010-10-08 15:29:08 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 26759900807,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 24, 38 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26768121256",
  "text" : "LOL (smooches 4 pup) RT @Unique_Misfit: He has a fucking pink cone on his head. How can you be scared of him?!",
  "id" : 26768121256,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jule Hewitt",
      "screen_name" : "julebob",
      "indices" : [ 0, 8 ],
      "id_str" : "619946576",
      "id" : 619946576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26768763076",
  "text" : "@julebob Nice to meet you! I follow your son @SamsaricWarrior . He's pretty cool guy. Welcome, welcome and feel free to ask anything! : )",
  "id" : 26768763076,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26770269489",
  "geo" : { },
  "id_str" : "26771567467",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan interesting.. Def sounds like it means something.. Lol",
  "id" : 26771567467,
  "in_reply_to_status_id" : 26770269489,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26771601204",
  "geo" : { },
  "id_str" : "26772131114",
  "in_reply_to_user_id" : 36200541,
  "text" : "@WhiteRoseWiccan oh my LOL",
  "id" : 26772131114,
  "in_reply_to_status_id" : 26771601204,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aplacetobark",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26777005808",
  "text" : "RT @aplacetobark: Ultimate cuteness!!! Great Pyrenees\/x puppy along w\/ 22 other dogs rescued by #aplacetobark \"Go Doggy\" :)  http:\/\/twit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aplacetobark",
        "indices" : [ 78, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26773816034",
    "text" : "Ultimate cuteness!!! Great Pyrenees\/x puppy along w\/ 22 other dogs rescued by #aplacetobark \"Go Doggy\" :)  http:\/\/twitpic.com\/2vqy6g",
    "id" : 26773816034,
    "created_at" : "2010-10-08 18:21:27 +0000",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 26777005808,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26774644702",
  "geo" : { },
  "id_str" : "26777229376",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl ((hugs)) : )",
  "id" : 26777229376,
  "in_reply_to_status_id" : 26774644702,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aplacetobark",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26777243277",
  "text" : "RT @aplacetobark: Help me rescue dogs in need! Pls view & give 5 stars if u believe in life & RT http:\/\/bit.ly\/8XAaIY #aplacetobark I'm  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aplacetobark",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26774764843",
    "text" : "Help me rescue dogs in need! Pls view & give 5 stars if u believe in life & RT http:\/\/bit.ly\/8XAaIY #aplacetobark I'm saving dogs right now!",
    "id" : 26774764843,
    "created_at" : "2010-10-08 18:35:23 +0000",
    "user" : {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "protected" : false,
      "id_str" : "14669290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772470271580082176\/1UJeJ2DG_normal.jpg",
      "id" : 14669290,
      "verified" : false
    }
  },
  "id" : 26777243277,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26777342450",
  "text" : "RT @Wylieknowords: New Twitter sucks. It won't let me RT, reply,etc. on the bottom of the Tweet. Doesn't show up. What is wrong with it? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26775122640",
    "text" : "New Twitter sucks. It won't let me RT, reply,etc. on the bottom of the Tweet. Doesn't show up. What is wrong with it? I wanted to like it.",
    "id" : 26775122640,
    "created_at" : "2010-10-08 18:40:33 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 26777342450,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 0, 14 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26776682638",
  "geo" : { },
  "id_str" : "26777703842",
  "in_reply_to_user_id" : 159213309,
  "text" : "@Unique_Misfit forty here in USA",
  "id" : 26777703842,
  "in_reply_to_status_id" : 26776682638,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26660928810",
  "text" : "Ugh. All I need is a Rx for effexor to send in to get my free meds. I been on it for 10+ yrs.. I don't need therapy appts! 1 lousy rx",
  "id" : 26660928810,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26661070184",
  "text" : "I cant guarantee what will happen if I don't take it.. When I'm late w pill, head gets really weird & get nauseous.",
  "id" : 26661070184,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 13, 23 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26661223620",
  "text" : "Awww! : ) RT @ShhDragon: Turtle day http:\/\/plixi.com\/p\/49207843",
  "id" : 26661223620,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 27, 37 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26662947160",
  "text" : "Go in peace, lil buddy. RT @ShhDragon: One more:  http:\/\/plixi.com\/p\/49208566",
  "id" : 26662947160,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26663320205",
  "text" : "Ok Universe.. I need an Rx for Effexor XR Refill 3x. Before my current stash runs out. Need it w\/out much fuss & not costly. TY!!",
  "id" : 26663320205,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26669319759",
  "geo" : { },
  "id_str" : "26670866305",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist yah, I saw that.. Did u see his site? He wrote article about \"ppl who are convinced they are gay\".. Sigh.",
  "id" : 26670866305,
  "in_reply_to_status_id" : 26669319759,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26669669461",
  "geo" : { },
  "id_str" : "26671088985",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords hover mouse over the tweet then options show up : )",
  "id" : 26671088985,
  "in_reply_to_status_id" : 26669669461,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26671829105",
  "geo" : { },
  "id_str" : "26672089966",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords frankly I think ppl don't read most of their followers. Prolly list their faves & only read those.",
  "id" : 26672089966,
  "in_reply_to_status_id" : 26671829105,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26671829105",
  "geo" : { },
  "id_str" : "26672175745",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords I don't do follow-backs, only follow who interests me. Try to read tweets. But I'm on here reg. Some aren't..",
  "id" : 26672175745,
  "in_reply_to_status_id" : 26671829105,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JANAE CHANG",
      "screen_name" : "pinkdandy",
      "indices" : [ 0, 10 ],
      "id_str" : "24666070",
      "id" : 24666070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26673576278",
  "geo" : { },
  "id_str" : "26674071548",
  "in_reply_to_user_id" : 24666070,
  "text" : "@pinkdandy brown sugar or coconut vanilla : ) mmmmm...",
  "id" : 26674071548,
  "in_reply_to_status_id" : 26673576278,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "pinkdandy",
  "in_reply_to_user_id_str" : "24666070",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26673120963",
  "geo" : { },
  "id_str" : "26674195567",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist only read that 1 article then left b4 I got really annoyed.. Lol.",
  "id" : 26674195567,
  "in_reply_to_status_id" : 26673120963,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26675003330",
  "geo" : { },
  "id_str" : "26676460325",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem because not everyone has your strength dear : )",
  "id" : 26676460325,
  "in_reply_to_status_id" : 26675003330,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26675989889",
  "geo" : { },
  "id_str" : "26676791446",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords on left side",
  "id" : 26676791446,
  "in_reply_to_status_id" : 26675989889,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26675989889",
  "geo" : { },
  "id_str" : "26677365616",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords if you click on name it will bring up their tweets on right",
  "id" : 26677365616,
  "in_reply_to_status_id" : 26675989889,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nancy babcock",
      "screen_name" : "nancybabcock",
      "indices" : [ 3, 16 ],
      "id_str" : "45443149",
      "id" : 45443149
    }, {
      "name" : "Kari Lonning",
      "screen_name" : "karibaskets",
      "indices" : [ 20, 32 ],
      "id_str" : "22083667",
      "id" : 22083667
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Govt",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "wildhorses",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26677383996",
  "text" : "RT @nancybabcock: RT@karibaskets: Did you know  #Govt is running #wildhorses to death w\/helicopters?  http:\/\/bit.ly\/959X8q stallion died ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kari Lonning",
        "screen_name" : "karibaskets",
        "indices" : [ 2, 14 ],
        "id_str" : "22083667",
        "id" : 22083667
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Govt",
        "indices" : [ 30, 35 ]
      }, {
        "text" : "wildhorses",
        "indices" : [ 47, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26675606620",
    "text" : "RT@karibaskets: Did you know  #Govt is running #wildhorses to death w\/helicopters?  http:\/\/bit.ly\/959X8q stallion died, foal watched",
    "id" : 26675606620,
    "created_at" : "2010-10-07 18:42:40 +0000",
    "user" : {
      "name" : "nancy babcock",
      "screen_name" : "nancybabcock",
      "protected" : false,
      "id_str" : "45443149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111265602\/0940eed0-7684-4dea-9435-c63e1911fb15_normal.png",
      "id" : 45443149,
      "verified" : false
    }
  },
  "id" : 26677383996,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26675989889",
  "geo" : { },
  "id_str" : "26677761471",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords I discovered you don't have to hover, you can click on it. Then under tweet is time, fav, rt, reply.",
  "id" : 26677761471,
  "in_reply_to_status_id" : 26675989889,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 14, 25 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26680445078",
  "text" : "LOLOL yes! RT @adampknave: I hate that this is so very, very true. But it is: http:\/\/bit.ly\/bzYiw4",
  "id" : 26680445078,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "\u2764 Cherie \u2764",
      "screen_name" : "Sahrazad528",
      "indices" : [ 20, 32 ],
      "id_str" : "120357592",
      "id" : 120357592
    }, {
      "name" : "Jenny",
      "screen_name" : "gennepher",
      "indices" : [ 37, 47 ],
      "id_str" : "62311852",
      "id" : 62311852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 96, 102 ]
    }, {
      "text" : "senryu",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "micropoetry",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26680543312",
  "text" : "RT @CoyoteSings: RT @Sahrazad528: RT @gennepher: two ravens ~ shadows on the road ~ playing tag #haiku #senryu #micropoetry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u2764 Cherie \u2764",
        "screen_name" : "Sahrazad528",
        "indices" : [ 3, 15 ],
        "id_str" : "120357592",
        "id" : 120357592
      }, {
        "name" : "Jenny",
        "screen_name" : "gennepher",
        "indices" : [ 20, 30 ],
        "id_str" : "62311852",
        "id" : 62311852
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 79, 85 ]
      }, {
        "text" : "senryu",
        "indices" : [ 86, 93 ]
      }, {
        "text" : "micropoetry",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26680467806",
    "text" : "RT @Sahrazad528: RT @gennepher: two ravens ~ shadows on the road ~ playing tag #haiku #senryu #micropoetry",
    "id" : 26680467806,
    "created_at" : "2010-10-07 19:58:07 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 26680543312,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "couragethedog",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26683804550",
  "text" : "I love naughty Fred!! #couragethedog",
  "id" : 26683804550,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 31, 45 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26686966196",
  "text" : "Anyone have ideas? &gt;&gt; RT @Wylieknowords: On New Twitter, how do you RT? ..hovering on both sides and seeing nothing?",
  "id" : 26686966196,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 0, 9 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26685949234",
  "geo" : { },
  "id_str" : "26687055872",
  "in_reply_to_user_id" : 15396585,
  "text" : "@Moonrust sending you positive vibes : ) feel good",
  "id" : 26687055872,
  "in_reply_to_status_id" : 26685949234,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 84, 98 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26687231192",
  "geo" : { },
  "id_str" : "26687418254",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen ya, he tried that but my impression is the options don't show up... @Wylieknowords",
  "id" : 26687418254,
  "in_reply_to_status_id" : 26687231192,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26687597078",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords I sent you email. Don't know if you'll see it. Tried to copy what I see on my page.",
  "id" : 26687597078,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26687545296",
  "geo" : { },
  "id_str" : "26687929052",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen Thx 4 your input : )",
  "id" : 26687929052,
  "in_reply_to_status_id" : 26687545296,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "carol ciocco",
      "screen_name" : "carolann3888",
      "indices" : [ 24, 37 ],
      "id_str" : "66716192",
      "id" : 66716192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26689483950",
  "text" : "RT @CoyoteSings: lol MT @carolann3888: What if you believe in reincarnation, so, when you die, instead of RIP on your gravestone it says ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "carol ciocco",
        "screen_name" : "carolann3888",
        "indices" : [ 7, 20 ],
        "id_str" : "66716192",
        "id" : 66716192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26689046043",
    "text" : "lol MT @carolann3888: What if you believe in reincarnation, so, when you die, instead of RIP on your gravestone it says BRB?",
    "id" : 26689046043,
    "created_at" : "2010-10-07 22:03:26 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 26689483950,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26689644712",
  "text" : "Going to Open House 4 school. Be back later...",
  "id" : 26689644712,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26600673532",
  "text" : "I finally got new twitter.. not sure what I think yet.. might be okay",
  "id" : 26600673532,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26602829506",
  "text" : "RT @DeepakChopra: When you change the way you see the world , the world that you see will change",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26602688033",
    "text" : "When you change the way you see the world , the world that you see will change",
    "id" : 26602688033,
    "created_at" : "2010-10-07 00:43:49 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 26602829506,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darlene Wiggins",
      "screen_name" : "Diamondsongrass",
      "indices" : [ 3, 19 ],
      "id_str" : "46929478",
      "id" : 46929478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26607961363",
  "text" : "RT @Diamondsongrass: At this very moment, there are people only you can reach\u2026and differences only you can make. Mike Dooley",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26607908755",
    "text" : "At this very moment, there are people only you can reach\u2026and differences only you can make. Mike Dooley",
    "id" : 26607908755,
    "created_at" : "2010-10-07 01:48:22 +0000",
    "user" : {
      "name" : "Darlene Wiggins",
      "screen_name" : "Diamondsongrass",
      "protected" : false,
      "id_str" : "46929478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1826084222\/picture_of_white_daisy_flower_normal.jpg",
      "id" : 46929478,
      "verified" : false
    }
  },
  "id" : 26607961363,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skeptic Blacksheep",
      "screen_name" : "SkepticSheep",
      "indices" : [ 3, 16 ],
      "id_str" : "67305283",
      "id" : 67305283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26640963218",
  "text" : "RT @SkepticSheep: \"Though no one can go back and make a brand new start, anyone can start from now and make a brand new ending.\" ~ Carl Bard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26623560727",
    "text" : "\"Though no one can go back and make a brand new start, anyone can start from now and make a brand new ending.\" ~ Carl Bard",
    "id" : 26623560727,
    "created_at" : "2010-10-07 05:41:28 +0000",
    "user" : {
      "name" : "Skeptic Blacksheep",
      "screen_name" : "SkepticSheep",
      "protected" : false,
      "id_str" : "67305283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1824063583\/black_normal.jpg",
      "id" : 67305283,
      "verified" : false
    }
  },
  "id" : 26640963218,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26641594114",
  "text" : "RT @stevetheseeker: If you won't take responsibility for your perception, how can you attract a teacher that is beyond this level?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26641086359",
    "text" : "If you won't take responsibility for your perception, how can you attract a teacher that is beyond this level?",
    "id" : 26641086359,
    "created_at" : "2010-10-07 11:49:44 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 26641594114,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26642998101",
  "text" : "@HEATHENRABBIT are u replying 2 something specific? Very true, tho. Hunger complicates things. When hungry, harder 4 me to stay on path.",
  "id" : 26642998101,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26643652251",
  "text" : "@HEATHENRABBIT yes, agreed. certain things don't \"make sense\" or sit right so I pay no attention to arguments for it...",
  "id" : 26643652251,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26643877451",
  "text" : "Emotions & desires.. Is that what makes us human? What if they are stripped away?",
  "id" : 26643877451,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26643950840",
  "text" : "Why am I such a thinker?",
  "id" : 26643950840,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26644095472",
  "text" : "I want the things I want! I can be blissful without specific things.. But I still want.",
  "id" : 26644095472,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26644657154",
  "text" : "@HEATHENRABBIT Sweet dreams: ) GN",
  "id" : 26644657154,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26645266039",
  "text" : "I wonder.. does what I believe affect my behavior? I wonder if I care about anything at all, really.",
  "id" : 26645266039,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26645368955",
  "text" : "I find it much easier to have sympathy 4 an animal over a human. Not because I dislike humans or think they are bad.",
  "id" : 26645368955,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26645404542",
  "text" : "Like all living things, humans just are.",
  "id" : 26645404542,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26645523419",
  "text" : "It has always been nature & animals that gave me feeling of something divine \"working out there\"..",
  "id" : 26645523419,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26645973728",
  "text" : "If I believed that death was the end, I don't think I'd care about the future, the planet at all...",
  "id" : 26645973728,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26646081077",
  "text" : "I wouldn't wrestle w the things my being is concerned with.. because it wouldn't matter.",
  "id" : 26646081077,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26646317674",
  "text" : "Why did I take up #TKD ? I'm not into health at all.. I'm sloth-like. I could easily be a brain w no body.",
  "id" : 26646317674,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26646438336",
  "text" : "Yet I feel like #TKD is good 4 my soul. That there is a purpose or a reason 4 me to go there...",
  "id" : 26646438336,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26646289646",
  "geo" : { },
  "id_str" : "26646604818",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen referring to death as an atheist sees it.. THE END.. no sequels, etc. Lol",
  "id" : 26646604818,
  "in_reply_to_status_id" : 26646289646,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 21, 36 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26646673013",
  "text" : "Bleh (agree, tho) RT @stevetheseeker: It's ok to admit you're wrong. In fact, you can't grow without it.",
  "id" : 26646673013,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26646877279",
  "text" : "RT @stevetheseeker: One of the traits of the ego is to defend your actions 24\/7 365, so you never have to change.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26646628906",
    "text" : "One of the traits of the ego is to defend your actions 24\/7 365, so you never have to change.",
    "id" : 26646628906,
    "created_at" : "2010-10-07 13:08:06 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 26646877279,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26646755822",
  "geo" : { },
  "id_str" : "26647034283",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen hey don't go throwing in another monkey wrench to my thoughts.. Lol",
  "id" : 26647034283,
  "in_reply_to_status_id" : 26646755822,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atheist World",
      "screen_name" : "AtheistWorld",
      "indices" : [ 3, 16 ],
      "id_str" : "101297831",
      "id" : 101297831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26647195445",
  "text" : "RT @AtheistWorld: How can theists say atheists don't have morals, for they come from god, when they discriminate, condemn and stone peop ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26646809314",
    "text" : "How can theists say atheists don't have morals, for they come from god, when they discriminate, condemn and stone people to death?",
    "id" : 26646809314,
    "created_at" : "2010-10-07 13:10:23 +0000",
    "user" : {
      "name" : "Atheist World",
      "screen_name" : "AtheistWorld",
      "protected" : false,
      "id_str" : "101297831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717807702760525824\/El5u60R8_normal.jpg",
      "id" : 101297831,
      "verified" : false
    }
  },
  "id" : 26647195445,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 0, 8 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26647006474",
  "geo" : { },
  "id_str" : "26647229004",
  "in_reply_to_user_id" : 7339162,
  "text" : "@arphaus yeah!! ; )",
  "id" : 26647229004,
  "in_reply_to_status_id" : 26647006474,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "thisisarp",
  "in_reply_to_user_id_str" : "7339162",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RescueInstitute",
      "screen_name" : "RescueInstitute",
      "indices" : [ 3, 19 ],
      "id_str" : "17189512",
      "id" : 17189512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26647389721",
  "text" : "RT @RescueInstitute: The ONLY TRUE FOE we will ever face is our EGO. ~The Rescue Institute",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26647330832",
    "text" : "The ONLY TRUE FOE we will ever face is our EGO. ~The Rescue Institute",
    "id" : 26647330832,
    "created_at" : "2010-10-07 13:16:56 +0000",
    "user" : {
      "name" : "RescueInstitute",
      "screen_name" : "RescueInstitute",
      "protected" : false,
      "id_str" : "17189512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63664250\/ri_user_normal.jpg",
      "id" : 17189512,
      "verified" : false
    }
  },
  "id" : 26647389721,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26647479969",
  "text" : "I feel like I'm giving birth... with my brain! Lol",
  "id" : 26647479969,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26648581714",
  "text" : "\"persons who are convinced that they are homosexual\" Between the Boy and the Bridge http:\/\/bit.ly\/b0ySSw",
  "id" : 26648581714,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 13, 27 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26648946121",
  "text" : "Me sad, 2 RT @Unique_Misfit: I saw this little beagle dog tied up all by himself and it made me sad :(",
  "id" : 26648946121,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 35, 49 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26649298360",
  "text" : "Yes i truly believe it does : ) RT @Unique_Misfit: Every little helps.",
  "id" : 26649298360,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26649337055",
  "text" : "RT @stevetheseeker: If you put God in a box, you put yourself in a box while God remains free and beyond any mental image of this world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26648661942",
    "text" : "If you put God in a box, you put yourself in a box while God remains free and beyond any mental image of this world.",
    "id" : 26648661942,
    "created_at" : "2010-10-07 13:33:16 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 26649337055,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26649791284",
  "text" : "@HEATHENRABBIT you are so wise : )",
  "id" : 26649791284,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon F. Merz",
      "screen_name" : "jonfmerz",
      "indices" : [ 3, 12 ],
      "id_str" : "755103",
      "id" : 755103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26650283060",
  "text" : "RT @jonfmerz: New blog post: \"Methods & Goals (or How to Control Your Universe)\" http:\/\/bit.ly\/aRnRBY  Please share with others who may  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26649685642",
    "text" : "New blog post: \"Methods & Goals (or How to Control Your Universe)\" http:\/\/bit.ly\/aRnRBY  Please share with others who may dig it.  Thanks!",
    "id" : 26649685642,
    "created_at" : "2010-10-07 13:45:24 +0000",
    "user" : {
      "name" : "Jon F. Merz",
      "screen_name" : "jonfmerz",
      "protected" : false,
      "id_str" : "755103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611120614007402496\/b724Co13_normal.jpg",
      "id" : 755103,
      "verified" : false
    }
  },
  "id" : 26650283060,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26652489852",
  "text" : "RT @ThadSquirrel: \"We're not churchgoers but use the word God often. Every time I'm in the woods, I feel like I'm in church.\" Pete Seeger",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26650984689",
    "text" : "\"We're not churchgoers but use the word God often. Every time I'm in the woods, I feel like I'm in church.\" Pete Seeger",
    "id" : 26650984689,
    "created_at" : "2010-10-07 14:00:43 +0000",
    "user" : {
      "name" : "Tom Rapsas",
      "screen_name" : "TomRapsas",
      "protected" : false,
      "id_str" : "84377368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459003600174206977\/OcjkrDsf_normal.jpeg",
      "id" : 84377368,
      "verified" : false
    }
  },
  "id" : 26652489852,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26656496926",
  "text" : "RT @Mahala: I'm trying to find my inner peace dammit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26656009252",
    "text" : "I'm trying to find my inner peace dammit.",
    "id" : 26656009252,
    "created_at" : "2010-10-07 14:58:31 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 26656496926,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26656669451",
  "text" : "RT @gemswinc: Ancient Galaxies Found in Modern Universe http:\/\/tinyurl.com\/2almmem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/news.discovery.com\/\" rel=\"nofollow\"\u003EDiscovery News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26656268861",
    "text" : "Ancient Galaxies Found in Modern Universe http:\/\/tinyurl.com\/2almmem",
    "id" : 26656268861,
    "created_at" : "2010-10-07 15:01:22 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 26656669451,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SarahRobinson",
      "screen_name" : "SarahRobinson",
      "indices" : [ 3, 17 ],
      "id_str" : "14058790",
      "id" : 14058790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26656842428",
  "text" : "RT @SarahRobinson: Escaping Mediocrity: Admitting I'm wrong is a sign of strength & confidence. Not an admission of weakness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26655416446",
    "text" : "Escaping Mediocrity: Admitting I'm wrong is a sign of strength & confidence. Not an admission of weakness.",
    "id" : 26655416446,
    "created_at" : "2010-10-07 14:51:49 +0000",
    "user" : {
      "name" : "SarahRobinson",
      "screen_name" : "SarahRobinson",
      "protected" : false,
      "id_str" : "14058790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702171111476191232\/1T61Ap-c_normal.jpg",
      "id" : 14058790,
      "verified" : false
    }
  },
  "id" : 26656842428,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 0, 11 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26656341366",
  "geo" : { },
  "id_str" : "26656969905",
  "in_reply_to_user_id" : 2772041,
  "text" : "@adampknave freaky? You haven't seen chimp & frog vid, have you? Oops. I wasn't ever going to mention that again.. must go puke now.",
  "id" : 26656969905,
  "in_reply_to_status_id" : 26656341366,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26657085486",
  "text" : "Have to do something but keep putting it off as it involves speaking to live person on phone.. Ugh!!",
  "id" : 26657085486,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26657210554",
  "text" : "Also involves long explanation so it probably won't be simple, easy, quick or painless.. sigh.",
  "id" : 26657210554,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 0, 11 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26657173435",
  "geo" : { },
  "id_str" : "26657381316",
  "in_reply_to_user_id" : 2772041,
  "text" : "@adampknave Yeah, gotcha.. Lol",
  "id" : 26657381316,
  "in_reply_to_status_id" : 26657173435,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calypso",
      "screen_name" : "Clippy",
      "indices" : [ 3, 10 ],
      "id_str" : "2664471",
      "id" : 2664471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26657449622",
  "text" : "RT @Clippy: Everything you do in business or life all leads to something, however small it seems at the time..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26649568421",
    "text" : "Everything you do in business or life all leads to something, however small it seems at the time..",
    "id" : 26649568421,
    "created_at" : "2010-10-07 13:44:01 +0000",
    "user" : {
      "name" : "Calypso",
      "screen_name" : "Clippy",
      "protected" : false,
      "id_str" : "2664471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077803726\/twitterpic2_normal.jpg",
      "id" : 2664471,
      "verified" : false
    }
  },
  "id" : 26657449622,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Drayer",
      "screen_name" : "directselling",
      "indices" : [ 3, 17 ],
      "id_str" : "15531975",
      "id" : 15531975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Scentsy",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26564621272",
  "text" : "RT @directselling: Check out #Scentsy Holiday Collection.  The Fright Night is pretty cute.\nhttps:\/\/diane.scentsy.us\/Buy\/Collection\/158",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Scentsy",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26563185550",
    "text" : "Check out #Scentsy Holiday Collection.  The Fright Night is pretty cute.\nhttps:\/\/diane.scentsy.us\/Buy\/Collection\/158",
    "id" : 26563185550,
    "created_at" : "2010-10-06 15:49:57 +0000",
    "user" : {
      "name" : "Diane Drayer",
      "screen_name" : "directselling",
      "protected" : false,
      "id_str" : "15531975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57040305\/women-100-gif_normal.gif",
      "id" : 15531975,
      "verified" : false
    }
  },
  "id" : 26564621272,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 11, 18 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26566944747",
  "text" : "Awww... RT @screek: Coyote rescued in Millville http:\/\/bit.ly\/d0eGbu",
  "id" : 26566944747,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26548263106",
  "text" : "RT @ShipsofSong: Unfortunately one tends to look at the lessons rather than the learnings.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26547541513",
    "text" : "Unfortunately one tends to look at the lessons rather than the learnings.",
    "id" : 26547541513,
    "created_at" : "2010-10-06 12:44:47 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 26548263106,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26548400593",
  "text" : "Note to me: I do not need every free app that looks interesting! :\/",
  "id" : 26548400593,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 20, 29 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 40, 47 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26562474340",
  "text" : "Beautiful pup... RT @DawnFine: Sad  Via @screek I Do Have Unpleasant Outdoor Adventures http:\/\/bit.ly\/9l4xRV #nature",
  "id" : 26562474340,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inkmesh",
      "screen_name" : "inkmesh",
      "indices" : [ 3, 11 ],
      "id_str" : "30119257",
      "id" : 30119257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26409878732",
  "text" : "RT @inkmesh: Sony Reader Store Free Ebook Alert: Intervention: A Novel by Terri Blackstock http:\/\/bit.ly\/cpnHf4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/inkmesh.com\" rel=\"nofollow\"\u003ETwinkmesh\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26409156072",
    "text" : "Sony Reader Store Free Ebook Alert: Intervention: A Novel by Terri Blackstock http:\/\/bit.ly\/cpnHf4",
    "id" : 26409156072,
    "created_at" : "2010-10-05 00:15:35 +0000",
    "user" : {
      "name" : "Inkmesh",
      "screen_name" : "inkmesh",
      "protected" : false,
      "id_str" : "30119257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436812923\/Inkmesh_Logo_100x100_normal.png",
      "id" : 30119257,
      "verified" : false
    }
  },
  "id" : 26409878732,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristian Quiroga",
      "screen_name" : "BlessedByGod1",
      "indices" : [ 3, 17 ],
      "id_str" : "1488468991",
      "id" : 1488468991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26454082965",
  "text" : "RT @BlessedByGod1: when you\u2019re feeling discouraged and feeling a little blue, take a look at a mighty oak and see what a nut can do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26453198580",
    "text" : "when you\u2019re feeling discouraged and feeling a little blue, take a look at a mighty oak and see what a nut can do.",
    "id" : 26453198580,
    "created_at" : "2010-10-05 12:52:00 +0000",
    "user" : {
      "name" : "Linda van der Merwe",
      "screen_name" : "lindapvdmerwe",
      "protected" : false,
      "id_str" : "21425866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1368752296\/Photo0473_normal.jpg",
      "id" : 21425866,
      "verified" : false
    }
  },
  "id" : 26454082965,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26455755320",
  "text" : "Mishka Husky sings w iPad http:\/\/bit.ly\/d0D2qV",
  "id" : 26455755320,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26467201678",
  "text" : "RT @DarciaHelle: Looking for books to review on your blog? Members are offering free books! #http:\/\/www.BestsellerBound.com #bookblogger ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bookbloggers",
        "indices" : [ 107, 120 ]
      }, {
        "text" : "read",
        "indices" : [ 121, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26463255925",
    "text" : "Looking for books to review on your blog? Members are offering free books! #http:\/\/www.BestsellerBound.com #bookbloggers #read",
    "id" : 26463255925,
    "created_at" : "2010-10-05 14:51:58 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 26467201678,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KB Deal of the Day",
      "screen_name" : "KBDealOfTheDay",
      "indices" : [ 3, 18 ],
      "id_str" : "141035213",
      "id" : 141035213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26472565572",
  "text" : "RT @KBDealOfTheDay: Down the Drain, a novelette from Daniel Pyle. Just when you thought it was safe to go back in your bathtub... $0.99  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26468949591",
    "text" : "Down the Drain, a novelette from Daniel Pyle. Just when you thought it was safe to go back in your bathtub... $0.99 http:\/\/amzn.to\/d96GWR",
    "id" : 26468949591,
    "created_at" : "2010-10-05 15:58:01 +0000",
    "user" : {
      "name" : "KB Deal of the Day",
      "screen_name" : "KBDealOfTheDay",
      "protected" : false,
      "id_str" : "141035213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887961588\/kb-deal-of-the-day-icon_normal.jpg",
      "id" : 141035213,
      "verified" : false
    }
  },
  "id" : 26472565572,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26476321944",
  "text" : "RT @ShhDragon: 11.5 lb. Saki back fr vet. Blood was shed. Vet was clawed, bitten & scared. Teflon gloves needed. Good kitty :)\n http:\/\/p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26472890686",
    "text" : "11.5 lb. Saki back fr vet. Blood was shed. Vet was clawed, bitten & scared. Teflon gloves needed. Good kitty :)\n http:\/\/plixi.com\/p\/48889667",
    "id" : 26472890686,
    "created_at" : "2010-10-05 16:47:35 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 26476321944,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 0, 8 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26476834013",
  "geo" : { },
  "id_str" : "26477631950",
  "in_reply_to_user_id" : 7339162,
  "text" : "@arphaus oh Exciting! Keep us updated. : )",
  "id" : 26477631950,
  "in_reply_to_status_id" : 26476834013,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "thisisarp",
  "in_reply_to_user_id_str" : "7339162",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26472407943",
  "geo" : { },
  "id_str" : "26477744485",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl love the song & message... & Esp that last line : )",
  "id" : 26477744485,
  "in_reply_to_status_id" : 26472407943,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26477818194",
  "text" : "RT @PeggySueCusses: Glowing Pumpkins Halloween Placemat Set of 4 NEW LISTING TODAY http:\/\/bit.ly\/a4Auav It's time for Halloween decorati ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26477384616",
    "text" : "Glowing Pumpkins Halloween Placemat Set of 4 NEW LISTING TODAY http:\/\/bit.ly\/a4Auav It's time for Halloween decorations & placemats!!",
    "id" : 26477384616,
    "created_at" : "2010-10-05 17:48:58 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 26477818194,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26482533982",
  "text" : "88! DD got an 88 on a... MATH test!!! and she rated today as an 8 out of 10!! Who took my child??? LOL",
  "id" : 26482533982,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 22, 34 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26493378168",
  "text" : "Looks quite comfy! RT @mindymayhem: Sleepy dog... http:\/\/plixi.com\/p\/48926802",
  "id" : 26493378168,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26499380499",
  "text" : "RT @MWM4444: Here's a way cool interactive tool for comparing sizes, from the Universe as a whole down to Einstein's \"quantum foam\": htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26484162741",
    "text" : "Here's a way cool interactive tool for comparing sizes, from the Universe as a whole down to Einstein's \"quantum foam\": http:\/\/bit.ly\/cbxaAw",
    "id" : 26484162741,
    "created_at" : "2010-10-05 19:33:41 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 26499380499,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26315661185",
  "text" : "World's Strangest Vending Machines http:\/\/yhoo.it\/931WFB",
  "id" : 26315661185,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "Cynthia L. White",
      "screen_name" : "preskittgurl",
      "indices" : [ 34, 47 ],
      "id_str" : "56779008",
      "id" : 56779008
    }, {
      "name" : "Jann Dorothy",
      "screen_name" : "BirdGalAlcatraz",
      "indices" : [ 52, 68 ],
      "id_str" : "157487922",
      "id" : 157487922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26319670113",
  "text" : "RT @DawnFine: Awww door a bull RT @preskittgurl: MT @BirdGalAlcatraz: this \"blond\" squirrel is unlike any I've seen. http:\/\/bit.ly\/d7cQm4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cynthia L. White",
        "screen_name" : "preskittgurl",
        "indices" : [ 20, 33 ],
        "id_str" : "56779008",
        "id" : 56779008
      }, {
        "name" : "Jann Dorothy",
        "screen_name" : "BirdGalAlcatraz",
        "indices" : [ 38, 54 ],
        "id_str" : "157487922",
        "id" : 157487922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26319597094",
    "text" : "Awww door a bull RT @preskittgurl: MT @BirdGalAlcatraz: this \"blond\" squirrel is unlike any I've seen. http:\/\/bit.ly\/d7cQm4",
    "id" : 26319597094,
    "created_at" : "2010-10-04 01:13:50 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 26319670113,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DC Debbie",
      "screen_name" : "DCdebbie",
      "indices" : [ 3, 12 ],
      "id_str" : "14266637",
      "id" : 14266637
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ModernDayVersionOfYouDontBringMeFlowersAnyMore",
      "indices" : [ 45, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26324089281",
  "text" : "RT @DCdebbie: You never retweet me any more! #ModernDayVersionOfYouDontBringMeFlowersAnyMore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ModernDayVersionOfYouDontBringMeFlowersAnyMore",
        "indices" : [ 31, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26323012224",
    "text" : "You never retweet me any more! #ModernDayVersionOfYouDontBringMeFlowersAnyMore",
    "id" : 26323012224,
    "created_at" : "2010-10-04 01:56:25 +0000",
    "user" : {
      "name" : "DC Debbie",
      "screen_name" : "DCdebbie",
      "protected" : false,
      "id_str" : "14266637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799768285705306112\/utB9T2ip_normal.jpg",
      "id" : 14266637,
      "verified" : false
    }
  },
  "id" : 26324089281,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26324397944",
  "text" : "RT @parkstepp: I really don't care if you're gay, straight, black, asian, middle eastern, christian, atheist, agnostic,... http:\/\/tumblr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26324030327",
    "text" : "I really don't care if you're gay, straight, black, asian, middle eastern, christian, atheist, agnostic,... http:\/\/tumblr.com\/xjwki4aw3",
    "id" : 26324030327,
    "created_at" : "2010-10-04 02:09:27 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 26324397944,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 3, 17 ],
      "id_str" : "15855422",
      "id" : 15855422
    }, {
      "name" : "Linda Fitzgerald",
      "screen_name" : "lindaAWI",
      "indices" : [ 33, 42 ],
      "id_str" : "18141297",
      "id" : 18141297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lindaAWI",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26359738023",
  "text" : "RT @MelodyLeaLamb: Beautiful! RT @lindaAWI Don't overlook the small, for blessings often come disguised as the insignificant. #lindaAWI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Linda Fitzgerald",
        "screen_name" : "lindaAWI",
        "indices" : [ 14, 23 ],
        "id_str" : "18141297",
        "id" : 18141297
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lindaAWI",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26359581614",
    "text" : "Beautiful! RT @lindaAWI Don't overlook the small, for blessings often come disguised as the insignificant. #lindaAWI",
    "id" : 26359581614,
    "created_at" : "2010-10-04 13:01:17 +0000",
    "user" : {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "protected" : false,
      "id_str" : "15855422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94236021\/NewPic_normal.JPG",
      "id" : 15855422,
      "verified" : false
    }
  },
  "id" : 26359738023,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26359775550",
  "text" : "RT @DoreenVirtue444: Remember that you draw people to you who vibrate at a similar energetic wavelengths.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26359746228",
    "text" : "Remember that you draw people to you who vibrate at a similar energetic wavelengths.",
    "id" : 26359746228,
    "created_at" : "2010-10-04 13:03:28 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 26359775550,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liesyoushouldntfallfor",
      "indices" : [ 17, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26362012430",
  "text" : "RT @brandonrofl: #liesyoushouldntfallfor \"You're no one. You're worthless. You'll never be anybody. You can't do anything right.\" - Prov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "liesyoushouldntfallfor",
        "indices" : [ 0, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26360526220",
    "text" : "#liesyoushouldntfallfor \"You're no one. You're worthless. You'll never be anybody. You can't do anything right.\" - Prove them wrong.",
    "id" : 26360526220,
    "created_at" : "2010-10-04 13:13:10 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 26362012430,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "John B.",
      "screen_name" : "dendroica",
      "indices" : [ 79, 89 ],
      "id_str" : "10238542",
      "id" : 10238542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26362115677",
  "text" : "RT @DawnFine: Another great looking moth..is moth id harder than bird Id?: Via @Dendroica Yellow-collared Scape Moth http:\/\/bit.ly\/92aaw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John B.",
        "screen_name" : "dendroica",
        "indices" : [ 65, 75 ],
        "id_str" : "10238542",
        "id" : 10238542
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26360745502",
    "text" : "Another great looking moth..is moth id harder than bird Id?: Via @Dendroica Yellow-collared Scape Moth http:\/\/bit.ly\/92aawX #Nature",
    "id" : 26360745502,
    "created_at" : "2010-10-04 13:15:51 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 26362115677,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26365405967",
  "text" : "RT @fearfuldogs: i need images of shy dogs 4 book. get credited & receive a free copy! DM 4 more info. thanks!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26364058524",
    "text" : "i need images of shy dogs 4 book. get credited & receive a free copy! DM 4 more info. thanks!",
    "id" : 26364058524,
    "created_at" : "2010-10-04 13:55:31 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 26365405967,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 3, 11 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "website",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26375250550",
  "text" : "RT @arphaus: Anyone need a #website, or help with one?",
  "id" : 26375250550,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26381010452",
  "geo" : { },
  "id_str" : "26381871858",
  "in_reply_to_user_id" : 99910224,
  "text" : "@PaganGmaSayin hugs 4 you & kitty!",
  "id" : 26381871858,
  "in_reply_to_status_id" : 26381010452,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26382171979",
  "text" : "\"You can do anything you set your mind to, man\" - \"Lose Yourself\" Eminem",
  "id" : 26382171979,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "indices" : [ 0, 11 ],
      "id_str" : "15767534",
      "id" : 15767534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26383812448",
  "geo" : { },
  "id_str" : "26384560594",
  "in_reply_to_user_id" : 15767534,
  "text" : "@micahbales I love my Sony 505! Are you familiar with http:\/\/bit.ly\/dxIL3o ? Great place to chat ereaders & ebooks.",
  "id" : 26384560594,
  "in_reply_to_status_id" : 26383812448,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "micahbales",
  "in_reply_to_user_id_str" : "15767534",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26387827551",
  "text" : "RT @adampknave: I'll give a copy of every prose book I've written (and Popgun 4) to the person who can find this dog a home: http:\/\/bit. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26386133284",
    "text" : "I'll give a copy of every prose book I've written (and Popgun 4) to the person who can find this dog a home: http:\/\/bit.ly\/ckCG35",
    "id" : 26386133284,
    "created_at" : "2010-10-04 18:29:00 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 26387827551,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26388089946",
  "text" : "My DD had a good day! Hallelujah!!",
  "id" : 26388089946,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristiBowman",
      "screen_name" : "ChristiBowman",
      "indices" : [ 0, 14 ],
      "id_str" : "15826206",
      "id" : 15826206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26388948199",
  "geo" : { },
  "id_str" : "26389096209",
  "in_reply_to_user_id" : 15826206,
  "text" : "@ChristiBowman these kinda days give me hope : )",
  "id" : 26389096209,
  "in_reply_to_status_id" : 26388948199,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ChristiBowman",
  "in_reply_to_user_id_str" : "15826206",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26389202589",
  "text" : "TRUE! RT @SamsaricWarrior: If you dont learn to accept yourself, then no matter where you go or what you do you will never feel accepted.",
  "id" : 26389202589,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felicia Rangel",
      "screen_name" : "Feferang",
      "indices" : [ 3, 12 ],
      "id_str" : "15666403",
      "id" : 15666403
    }, {
      "name" : "Gotham Chopra",
      "screen_name" : "gothamchopra",
      "indices" : [ 65, 78 ],
      "id_str" : "19845137",
      "id" : 19845137
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 79, 92 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalkingWidsom",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26391437779",
  "text" : "RT @Feferang: Giving away 2 advanced copies of #WalkingWidsom by @gothamchopra @deepakchopra Q: What types of lessons do our pets teach  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gotham Chopra",
        "screen_name" : "gothamchopra",
        "indices" : [ 51, 64 ],
        "id_str" : "19845137",
        "id" : 19845137
      }, {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 65, 78 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WalkingWidsom",
        "indices" : [ 33, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26390711106",
    "text" : "Giving away 2 advanced copies of #WalkingWidsom by @gothamchopra @deepakchopra Q: What types of lessons do our pets teach us? Answer + RT",
    "id" : 26390711106,
    "created_at" : "2010-10-04 19:54:47 +0000",
    "user" : {
      "name" : "Felicia Rangel",
      "screen_name" : "Feferang",
      "protected" : false,
      "id_str" : "15666403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591763024903438336\/7OjWOx3t_normal.jpg",
      "id" : 15666403,
      "verified" : false
    }
  },
  "id" : 26391437779,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felicia Rangel",
      "screen_name" : "Feferang",
      "indices" : [ 0, 9 ],
      "id_str" : "15666403",
      "id" : 15666403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26391497936",
  "in_reply_to_user_id" : 15666403,
  "text" : "@Feferang to live in the now, to enjoy every moment, to not take life seriously.",
  "id" : 26391497936,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Feferang",
  "in_reply_to_user_id_str" : "15666403",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 0, 15 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26400176873",
  "geo" : { },
  "id_str" : "26402763191",
  "in_reply_to_user_id" : 30825946,
  "text" : "@JonathanElliot ouch, feel better soon! : )",
  "id" : 26402763191,
  "in_reply_to_status_id" : 26400176873,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "JonathanElliot",
  "in_reply_to_user_id_str" : "30825946",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26403358244",
  "text" : "Just got back from grocery shopping. Now my left eye is sore.",
  "id" : 26403358244,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 7, 21 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26403470716",
  "text" : "LOL RT @Wylieknowords: \"Does this ((((TWEET))) make me look fat?\" N. Wylie Jones",
  "id" : 26403470716,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26299845339",
  "text" : "RT @JacksonPearce: Thanks, those of you that are supporting authors by buying ebooks or hard copies, not downloading. We appreciate it.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26295708651",
    "text" : "Thanks, those of you that are supporting authors by buying ebooks or hard copies, not downloading. We appreciate it. For reals.",
    "id" : 26295708651,
    "created_at" : "2010-10-03 19:53:20 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 26299845339,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 126, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26300502207",
  "text" : "RT @JimBrownBooks: The Earth spins at 1,000 mph but it travels through space at an incredible 67,000 mph. No wonder I\u2019m dizzy #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 107, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26300386673",
    "text" : "The Earth spins at 1,000 mph but it travels through space at an incredible 67,000 mph. No wonder I\u2019m dizzy #fb",
    "id" : 26300386673,
    "created_at" : "2010-10-03 21:00:28 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 26300502207,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 0, 14 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26300686761",
  "geo" : { },
  "id_str" : "26300833574",
  "in_reply_to_user_id" : 159213309,
  "text" : "@Unique_Misfit that's her problem, then.. ((hugs))",
  "id" : 26300833574,
  "in_reply_to_status_id" : 26300686761,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dillon Ramdass",
      "screen_name" : "unique_misfit",
      "indices" : [ 3, 17 ],
      "id_str" : "784053507108339712",
      "id" : 784053507108339712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26300892390",
  "text" : "RT @Unique_Misfit: Then she said 'there's no such thing as someone who doesn't believe in God.' What kind of retarded statement IS that?!",
  "id" : 26300892390,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26304398272",
  "text" : "RT @Wylieknowords: \"Spending the majority of money and time to prep for state testing is leaving all the children behind in a race to th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26301868567",
    "text" : "\"Spending the majority of money and time to prep for state testing is leaving all the children behind in a race to the botttom.\" N. Wylie J.",
    "id" : 26301868567,
    "created_at" : "2010-10-03 21:21:49 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 26304398272,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christians",
      "indices" : [ 25, 36 ]
    }, {
      "text" : "atheists",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "God",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26308023793",
  "text" : "RT @Reverend_Sue: To the #Christians who want me to deny #atheists their non-belief and push #God on them, forget about it. It's not gon ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Christians",
        "indices" : [ 7, 18 ]
      }, {
        "text" : "atheists",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "God",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "tolerance",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26307970447",
    "text" : "To the #Christians who want me to deny #atheists their non-belief and push #God on them, forget about it. It's not gonna' happen. #tolerance",
    "id" : 26307970447,
    "created_at" : "2010-10-03 22:46:37 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 26308023793,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheryl Lorraine",
      "screen_name" : "cherapple",
      "indices" : [ 3, 13 ],
      "id_str" : "18154412",
      "id" : 18154412
    }, {
      "name" : "Home Education Magaz",
      "screen_name" : "HomeEdMag",
      "indices" : [ 40, 50 ],
      "id_str" : "25975209",
      "id" : 25975209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26308946247",
  "text" : "RT @cherapple: \"Government\" schools. RT @HomeEdMag: \"Public schools have essentially been turned into prisons w constant surveillance. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Home Education Magaz",
        "screen_name" : "HomeEdMag",
        "indices" : [ 25, 35 ],
        "id_str" : "25975209",
        "id" : 25975209
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26308785771",
    "text" : "\"Government\" schools. RT @HomeEdMag: \"Public schools have essentially been turned into prisons w constant surveillance. http:\/\/bit.ly\/camWGv",
    "id" : 26308785771,
    "created_at" : "2010-10-03 22:57:14 +0000",
    "user" : {
      "name" : "Cheryl Lorraine",
      "screen_name" : "cherapple",
      "protected" : false,
      "id_str" : "18154412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457861367463936\/OXLJGgzB_normal.jpg",
      "id" : 18154412,
      "verified" : false
    }
  },
  "id" : 26308946247,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26310113716",
  "geo" : { },
  "id_str" : "26311926752",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 anything specific?",
  "id" : 26311926752,
  "in_reply_to_status_id" : 26310113716,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26218032076",
  "text" : "@tragic_pizza LOL. I love your tweets. You have so much to say and you're gonna say it, dagnabbit! : )",
  "id" : 26218032076,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26218116548",
  "text" : "Awww ((grouphug)) love my tweeps!!",
  "id" : 26218116548,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26218177895",
  "geo" : { },
  "id_str" : "26218268288",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts muah! : )",
  "id" : 26218268288,
  "in_reply_to_status_id" : 26218177895,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26218264006",
  "geo" : { },
  "id_str" : "26218324751",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 eeek! lol",
  "id" : 26218324751,
  "in_reply_to_status_id" : 26218264006,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HWTM",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26218437490",
  "text" : "RT @BigBookofYou: Just make peace with where you are. Eva Gregory #HWTM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HWTM",
        "indices" : [ 48, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26218419455",
    "text" : "Just make peace with where you are. Eva Gregory #HWTM",
    "id" : 26218419455,
    "created_at" : "2010-10-03 00:06:09 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 26218437490,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26220925295",
  "text" : "RT @abe_quotes: Whether I am right in my blame or wrong in my blame, my blame is still messing up my experience.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26220478752",
    "text" : "Whether I am right in my blame or wrong in my blame, my blame is still messing up my experience.",
    "id" : 26220478752,
    "created_at" : "2010-10-03 00:37:17 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 26220925295,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Steve LeGendre",
      "screen_name" : "windowsot",
      "indices" : [ 3, 13 ],
      "id_str" : "24274908",
      "id" : 24274908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOVE",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26224248677",
  "text" : "RT @windowsot: Friendships come in all shapes and sizes and somehow they all fit in our hearts. #LOVE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetree.com\" rel=\"nofollow\"\u003ETweetree\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LOVE",
        "indices" : [ 81, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26223674111",
    "text" : "Friendships come in all shapes and sizes and somehow they all fit in our hearts. #LOVE",
    "id" : 26223674111,
    "created_at" : "2010-10-03 01:23:04 +0000",
    "user" : {
      "name" : "Rob Steve LeGendre",
      "screen_name" : "windowsot",
      "protected" : false,
      "id_str" : "24274908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000717433867\/a26ebe785a236f0d882cd6951df54b9a_normal.jpeg",
      "id" : 24274908,
      "verified" : false
    }
  },
  "id" : 26224248677,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Hunter",
      "screen_name" : "amyandwillow",
      "indices" : [ 3, 16 ],
      "id_str" : "188067857",
      "id" : 188067857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26224459857",
  "text" : "RT @amyandwillow: \u201CEverything you want to be, do, or have comes from love.\u201D Rhonda Byrne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26224312648",
    "text" : "\u201CEverything you want to be, do, or have comes from love.\u201D Rhonda Byrne",
    "id" : 26224312648,
    "created_at" : "2010-10-03 01:31:59 +0000",
    "user" : {
      "name" : "Amy Hunter",
      "screen_name" : "amyandwillow",
      "protected" : false,
      "id_str" : "188067857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120602620\/lab11_normal.jpg",
      "id" : 188067857,
      "verified" : false
    }
  },
  "id" : 26224459857,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric K",
      "screen_name" : "ericbrooklyn",
      "indices" : [ 3, 16 ],
      "id_str" : "100707584",
      "id" : 100707584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26224495832",
  "text" : "RT @ericbrooklyn: Focus is worried abt \"homosexuality lessons\"? Do ppl think you can catch it? Ask yourself, could you just decide to ch ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26224329088",
    "text" : "Focus is worried abt \"homosexuality lessons\"? Do ppl think you can catch it? Ask yourself, could you just decide to change YOUR orientation?",
    "id" : 26224329088,
    "created_at" : "2010-10-03 01:32:13 +0000",
    "user" : {
      "name" : "Eric K",
      "screen_name" : "ericbrooklyn",
      "protected" : false,
      "id_str" : "100707584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604950914\/white_normal.jpg",
      "id" : 100707584,
      "verified" : false
    }
  },
  "id" : 26224495832,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26273955677",
  "text" : "RT @elloyd74: Being visibly queer-friendly: please consider it (And RT): http:\/\/shelfcheck.blogspot.com\/2010\/10\/being-visibly-queer-frie ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26186409594",
    "text" : "Being visibly queer-friendly: please consider it (And RT): http:\/\/shelfcheck.blogspot.com\/2010\/10\/being-visibly-queer-friendly-please.html",
    "id" : 26186409594,
    "created_at" : "2010-10-02 16:02:13 +0000",
    "user" : {
      "name" : "Emily Lloyd",
      "screen_name" : "PoesyGalore",
      "protected" : false,
      "id_str" : "1659941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762126259153408000\/EVdlQmbh_normal.jpg",
      "id" : 1659941,
      "verified" : false
    }
  },
  "id" : 26273955677,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26275301919",
  "text" : "RT @Wylieknowords: `\"I'm not here to make friends.\" Reality TV  \"I am here to make friends.\" Twitter\nN. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26274845792",
    "text" : "`\"I'm not here to make friends.\" Reality TV  \"I am here to make friends.\" Twitter\nN. Wylie Jones www.knowords.com",
    "id" : 26274845792,
    "created_at" : "2010-10-03 15:15:15 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 26275301919,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26278165005",
  "text" : "RT @gemswinc: 10 Amazing Stories of Animals Rescuing Humans (Slideshow)... http:\/\/bit.ly\/aaXVnm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26277975973",
    "text" : "10 Amazing Stories of Animals Rescuing Humans (Slideshow)... http:\/\/bit.ly\/aaXVnm",
    "id" : 26277975973,
    "created_at" : "2010-10-03 15:52:30 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 26278165005,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "indices" : [ 3, 12 ],
      "id_str" : "19636553",
      "id" : 19636553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26279803120",
  "text" : "RT @LunaJune: Let others vibrate as they vibrate and want the best for them. Never mind how they're flowing to you. You (cont) http:\/\/tl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26278237357",
    "text" : "Let others vibrate as they vibrate and want the best for them. Never mind how they're flowing to you. You (cont) http:\/\/tl.gd\/6an5vh",
    "id" : 26278237357,
    "created_at" : "2010-10-03 15:55:36 +0000",
    "user" : {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "protected" : false,
      "id_str" : "19636553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521342919387533313\/KI-XkoTw_normal.jpeg",
      "id" : 19636553,
      "verified" : false
    }
  },
  "id" : 26279803120,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 9, 24 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26279992994",
  "text" : "Cute! RT @PeggySueCusses: One of a Kind Daisy Print tote. http:\/\/bit.ly\/aq59rA",
  "id" : 26279992994,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26280994509",
  "text" : "Guess what? No matter who you are, what you believe or how you act, there is someone who thinks you  are wrong (at very least.)",
  "id" : 26280994509,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26281332448",
  "text" : "Ppl think I'm wishy-washy. \"Pay her no attention. She stands for nothing!\" Yes, you do need to watch out for the quiet ones.. Lol.",
  "id" : 26281332448,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 17, 30 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26281393774",
  "text" : "RT @JohnCali: RT @DeepakChopra: The most important people in our life are our best friends and our worst critics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 3, 16 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26281168550",
    "text" : "RT @DeepakChopra: The most important people in our life are our best friends and our worst critics",
    "id" : 26281168550,
    "created_at" : "2010-10-03 16:31:31 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 26281393774,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26281742012",
  "text" : "We ARE all in this together. Do you really think 1 person has THE  answer? I think it's like a jigsaw puzzle. We are all pieces of big pic.",
  "id" : 26281742012,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Hywel Owen",
      "screen_name" : "hywelowen",
      "indices" : [ 97, 107 ],
      "id_str" : "16073116",
      "id" : 16073116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26282207121",
  "text" : "RT @DeepakChopra: Some request help for clarity. It's better than selling cigarettes drugs guns:)@hywelowen: Then why sell books that he ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hywel Owen",
        "screen_name" : "hywelowen",
        "indices" : [ 79, 89 ],
        "id_str" : "16073116",
        "id" : 16073116
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26282085159",
    "text" : "Some request help for clarity. It's better than selling cigarettes drugs guns:)@hywelowen: Then why sell books that help you look for it?",
    "id" : 26282085159,
    "created_at" : "2010-10-03 16:43:12 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 26282207121,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "Brad Farris",
      "screen_name" : "blfarris",
      "indices" : [ 16, 25 ],
      "id_str" : "17952486",
      "id" : 17952486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287003323",
  "text" : "RT @CandyTX: RT @blfarris: The debate whether you're reading books in hard copy or electronic is immaterial. The ? is:Are you reading bo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brad Farris",
        "screen_name" : "blfarris",
        "indices" : [ 3, 12 ],
        "id_str" : "17952486",
        "id" : 17952486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26285436677",
    "text" : "RT @blfarris: The debate whether you're reading books in hard copy or electronic is immaterial. The ? is:Are you reading books? - Alan Weiss",
    "id" : 26285436677,
    "created_at" : "2010-10-03 17:27:05 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 26287003323,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287035742",
  "text" : "RT @CreativeArtwks: When it comes to chocolate, resistance is futile. Regina Brett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26285511482",
    "text" : "When it comes to chocolate, resistance is futile. Regina Brett",
    "id" : 26285511482,
    "created_at" : "2010-10-03 17:28:07 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 26287035742,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287046983",
  "text" : "RT @CreativeArtwks: Get rid of anything that isn't useful, beautiful or joyful. - Regina Brett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26285553325",
    "text" : "Get rid of anything that isn't useful, beautiful or joyful. - Regina Brett",
    "id" : 26285553325,
    "created_at" : "2010-10-03 17:28:42 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 26287046983,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Want",
      "screen_name" : "Brain_wash",
      "indices" : [ 21, 32 ],
      "id_str" : "391152878",
      "id" : 391152878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humor",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287251218",
  "text" : "RT @Reverend_Sue: RT @Brain_Wash: Some people should come with subtitles. #humor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mr. Want",
        "screen_name" : "Brain_wash",
        "indices" : [ 3, 14 ],
        "id_str" : "391152878",
        "id" : 391152878
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "humor",
        "indices" : [ 56, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26286439203",
    "text" : "RT @Brain_Wash: Some people should come with subtitles. #humor",
    "id" : 26286439203,
    "created_at" : "2010-10-03 17:41:00 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 26287251218,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26286625950",
  "geo" : { },
  "id_str" : "26287316284",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL",
  "id" : 26287316284,
  "in_reply_to_status_id" : 26286625950,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "QJ0hn",
      "indices" : [ 9, 15 ],
      "id_str" : "733991620316651524",
      "id" : 733991620316651524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287480995",
  "text" : "Nice! RT @qj0hn: Bliss http:\/\/plixi.com\/p\/48581104",
  "id" : 26287480995,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287621050",
  "text" : "@tragic_pizza well, cool then! Perhaps I am changing after all. Thx!",
  "id" : 26287621050,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26287454138",
  "geo" : { },
  "id_str" : "26287916863",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts Hubs gets mad when I ruin his pans..heehee. Which could be why I don't cook! Lol",
  "id" : 26287916863,
  "in_reply_to_status_id" : 26287454138,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Priesnitz",
      "screen_name" : "WendyPriesnitz",
      "indices" : [ 3, 18 ],
      "id_str" : "61526521",
      "id" : 61526521
    }, {
      "name" : "Darren Beck",
      "screen_name" : "DarrenBeck",
      "indices" : [ 20, 31 ],
      "id_str" : "15823023",
      "id" : 15823023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287960860",
  "text" : "RT @WendyPriesnitz: @DarrenBeck Looking forward to the day when school will be written about as the \"extreme.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darren Beck",
        "screen_name" : "DarrenBeck",
        "indices" : [ 0, 11 ],
        "id_str" : "15823023",
        "id" : 15823023
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "26287180819",
    "geo" : { },
    "id_str" : "26287515747",
    "in_reply_to_user_id" : 15823023,
    "text" : "@DarrenBeck Looking forward to the day when school will be written about as the \"extreme.\"",
    "id" : 26287515747,
    "in_reply_to_status_id" : 26287180819,
    "created_at" : "2010-10-03 17:56:10 +0000",
    "in_reply_to_screen_name" : "DarrenBeck",
    "in_reply_to_user_id_str" : "15823023",
    "user" : {
      "name" : "Wendy Priesnitz",
      "screen_name" : "WendyPriesnitz",
      "protected" : false,
      "id_str" : "61526521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646343824487268352\/3k0doiNi_normal.jpg",
      "id" : 61526521,
      "verified" : false
    }
  },
  "id" : 26287960860,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26288154040",
  "text" : "I DO have 1 skill. If THEY cannot find it in this house.. 99.9% of time, I find it less than 5 minutes.",
  "id" : 26288154040,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u042F\u043A\u0443\u0448\u043E\u0432a \u042E\u043B\u0438\u044F",
      "screen_name" : "inlifeawareness",
      "indices" : [ 31, 47 ],
      "id_str" : "2815733911",
      "id" : 2815733911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26288641679",
  "text" : "64 million dollar question! RT @inlifeawareness: What do you really, really want?",
  "id" : 26288641679,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26138042739",
  "geo" : { },
  "id_str" : "26141122736",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 ((hugs))",
  "id" : 26141122736,
  "in_reply_to_status_id" : 26138042739,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Hersey",
      "screen_name" : "JackHersey",
      "indices" : [ 3, 14 ],
      "id_str" : "109279859",
      "id" : 109279859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26178199795",
  "text" : "RT @JackHersey: Discovered I was one infinitely small part of an infinitely large multiverse of mind-expanding realities and possibiliti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "25869213980",
    "text" : "Discovered I was one infinitely small part of an infinitely large multiverse of mind-expanding realities and possibilities. Didn't like it.",
    "id" : 25869213980,
    "created_at" : "2010-09-29 09:57:58 +0000",
    "user" : {
      "name" : "Jack Hersey",
      "screen_name" : "JackHersey",
      "protected" : false,
      "id_str" : "109279859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660969609\/jacktweet3_normal.jpg",
      "id" : 109279859,
      "verified" : false
    }
  },
  "id" : 26178199795,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26179036381",
  "text" : "Coffee tastes like cigarette butts this am... Yuck!",
  "id" : 26179036381,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26184479282",
  "geo" : { },
  "id_str" : "26186401992",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 wootwoot! ((highfive)) : )",
  "id" : 26186401992,
  "in_reply_to_status_id" : 26184479282,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26186702872",
  "text" : "Lots of secrets to be revealed.. The world is changing, transforming.",
  "id" : 26186702872,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bag And The Crow",
      "screen_name" : "TheBagAndTheCrw",
      "indices" : [ 3, 19 ],
      "id_str" : "118204178",
      "id" : 118204178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26192073340",
  "text" : "RT @TheBagAndTheCrw: If you like free stuff, be sure to sign up for our newsletter. Details coming very soon...... http:\/\/fb.me\/IRxHLpQc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26183291649",
    "text" : "If you like free stuff, be sure to sign up for our newsletter. Details coming very soon...... http:\/\/fb.me\/IRxHLpQc",
    "id" : 26183291649,
    "created_at" : "2010-10-02 15:25:15 +0000",
    "user" : {
      "name" : "The Bag And The Crow",
      "screen_name" : "TheBagAndTheCrw",
      "protected" : false,
      "id_str" : "118204178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1901157664\/TheBagAndTheCrowLogoAndSignatureCharacter_normal.jpg",
      "id" : 118204178,
      "verified" : false
    }
  },
  "id" : 26192073340,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26197716380",
  "text" : "RT @knittyflitty: I spent some time by my husband's grave today. He doesn't know, he thinks I'm digging a pond...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26120856131",
    "text" : "I spent some time by my husband's grave today. He doesn't know, he thinks I'm digging a pond...",
    "id" : 26120856131,
    "created_at" : "2010-10-01 22:30:53 +0000",
    "user" : {
      "name" : "Flawsome",
      "screen_name" : "ChafyMcStretchy",
      "protected" : false,
      "id_str" : "24713993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734413191774646272\/_ibPRZKQ_normal.jpg",
      "id" : 24713993,
      "verified" : false
    }
  },
  "id" : 26197716380,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26213564538",
  "text" : "RT @hauntedcomputer: The Red Church now #354...couple hundred slots and I can give this Kindle 3 away! http:\/\/amzn.to\/d0Lsa6 #kindle #bo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "books",
        "indices" : [ 112, 118 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26210925442",
    "text" : "The Red Church now #354...couple hundred slots and I can give this Kindle 3 away! http:\/\/amzn.to\/d0Lsa6 #kindle #books #ebooks plz RT",
    "id" : 26210925442,
    "created_at" : "2010-10-02 22:09:05 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 26213564538,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 3, 18 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26214014297",
  "text" : "RT @JonathanElliot: There's some really interesting discussion going on here http:\/\/bit.ly\/9kGOQg  - thankyou all",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26213004846",
    "text" : "There's some really interesting discussion going on here http:\/\/bit.ly\/9kGOQg  - thankyou all",
    "id" : 26213004846,
    "created_at" : "2010-10-02 22:44:00 +0000",
    "user" : {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "protected" : false,
      "id_str" : "30825946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1534911961\/black_square_normal.jpg",
      "id" : 30825946,
      "verified" : false
    }
  },
  "id" : 26214014297,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26217117194",
  "text" : "@ReformedBuddha curious, why?",
  "id" : 26217117194,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 0, 15 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26217610506",
  "text" : "@ReformedBuddha I've read maybe 3 of his books. I enjoy reading about life after death, quantum type stuff.",
  "id" : 26217610506,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ripley in CT",
      "screen_name" : "RipleyInCT",
      "indices" : [ 3, 14 ],
      "id_str" : "152844169",
      "id" : 152844169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26217652627",
  "text" : "RT @RipleyInCT: Dear gay kids: Please stop killing yourselves. The bigots don't matter. THEY are the freaks, not YOU. We love you. #Hope ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hopeline",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26217072047",
    "text" : "Dear gay kids: Please stop killing yourselves. The bigots don't matter. THEY are the freaks, not YOU. We love you. #Hopeline 1-800-784-2433",
    "id" : 26217072047,
    "created_at" : "2010-10-02 23:46:12 +0000",
    "user" : {
      "name" : "Ripley in CT",
      "screen_name" : "RipleyInCT",
      "protected" : false,
      "id_str" : "152844169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680550954203152384\/Gri4rRpz_normal.jpg",
      "id" : 152844169,
      "verified" : false
    }
  },
  "id" : 26217652627,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26217831830",
  "text" : "I come home to no mail, no email & no @ replies. Geez, really feeling loved here! ((rolling eyes))",
  "id" : 26217831830,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26217866336",
  "text" : "I can be very immature.. Sigh.",
  "id" : 26217866336,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]