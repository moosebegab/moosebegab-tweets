Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/YGILvSz0",
      "expanded_url" : "http:\/\/bit.ly\/RvEo6Q",
      "display_url" : "bit.ly\/RvEo6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "241715633434271745",
  "text" : "\u201CThe interests of PE firms and their investors do not coincide with the companies that have been taken over,\u201D http:\/\/t.co\/YGILvSz0",
  "id" : 241715633434271745,
  "created_at" : "2012-09-01 01:54:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 16, 30 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241698022566797313",
  "geo" : { },
  "id_str" : "241706697700290560",
  "in_reply_to_user_id" : 28863804,
  "text" : "thanks for link @Wylieknowords this is very interesting article..",
  "id" : 241706697700290560,
  "in_reply_to_status_id" : 241698022566797313,
  "created_at" : "2012-09-01 01:19:02 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "Rolling Stone",
      "screen_name" : "RollingStone",
      "indices" : [ 91, 104 ],
      "id_str" : "14780915",
      "id" : 14780915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/QdnoVCUL",
      "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/greed-and-debt-the-true-story-of-mitt-romney-and-bain-capital-20120829",
      "display_url" : "rollingstone.com\/politics\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241705525916610560",
  "text" : "RT @Wylieknowords: The True Story of Mitt Romney and Bain Capital http:\/\/t.co\/QdnoVCUL via @rollingstone",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rolling Stone",
        "screen_name" : "RollingStone",
        "indices" : [ 72, 85 ],
        "id_str" : "14780915",
        "id" : 14780915
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/QdnoVCUL",
        "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/greed-and-debt-the-true-story-of-mitt-romney-and-bain-capital-20120829",
        "display_url" : "rollingstone.com\/politics\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241698022566797313",
    "text" : "The True Story of Mitt Romney and Bain Capital http:\/\/t.co\/QdnoVCUL via @rollingstone",
    "id" : 241698022566797313,
    "created_at" : "2012-09-01 00:44:33 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 241705525916610560,
  "created_at" : "2012-09-01 01:14:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241683475122487298",
  "text" : "RT @sparklekaz: You are not here accidentally. You are here meaningfully. There is a purpose behind you. The whole intends to do somethi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241677626928947200",
    "text" : "You are not here accidentally. You are here meaningfully. There is a purpose behind you. The whole intends to do something through you. Osho",
    "id" : 241677626928947200,
    "created_at" : "2012-08-31 23:23:31 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 241683475122487298,
  "created_at" : "2012-08-31 23:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "starZship",
      "screen_name" : "starZship",
      "indices" : [ 3, 13 ],
      "id_str" : "14724790",
      "id" : 14724790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241683024033509378",
  "text" : "RT @starZship: War is hell. RT @_AntiWar_ War causes addiction; soldiers suffering post-traumatic stress often ... develop drinking or d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241678642420256768",
    "text" : "War is hell. RT @_AntiWar_ War causes addiction; soldiers suffering post-traumatic stress often ... develop drinking or drug addictions.",
    "id" : 241678642420256768,
    "created_at" : "2012-08-31 23:27:33 +0000",
    "user" : {
      "name" : "starZship",
      "screen_name" : "starZship",
      "protected" : false,
      "id_str" : "14724790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544741042453377026\/I3yAMHCc_normal.png",
      "id" : 14724790,
      "verified" : false
    }
  },
  "id" : 241683024033509378,
  "created_at" : "2012-08-31 23:44:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TGFBook",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241682643794669569",
  "text" : "RT @alanhdawe: During this lifetime, I express myself as I feel at the time. I do the best I can in every moment. #TGFBook Follow The Go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241679776098709504",
    "text" : "During this lifetime, I express myself as I feel at the time. I do the best I can in every moment. #TGFBook Follow The God Franchise serial.",
    "id" : 241679776098709504,
    "created_at" : "2012-08-31 23:32:03 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 241682643794669569,
  "created_at" : "2012-08-31 23:43:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "indices" : [ 3, 19 ],
      "id_str" : "29251361",
      "id" : 29251361
    }, {
      "name" : "DARREN HARDY",
      "screen_name" : "DARRENHARDY",
      "indices" : [ 58, 70 ],
      "id_str" : "18949053",
      "id" : 18949053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241682605374840833",
  "text" : "RT @WorldOfJoeRiggs: Supremacy? What about equality? wtf \"@DARRENHARDY: How does America and YOU regain supremacy in the productive worl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DARREN HARDY",
        "screen_name" : "DARRENHARDY",
        "indices" : [ 37, 49 ],
        "id_str" : "18949053",
        "id" : 18949053
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241679865202483200",
    "text" : "Supremacy? What about equality? wtf \"@DARRENHARDY: How does America and YOU regain supremacy in the productive world? I have the solution.\"",
    "id" : 241679865202483200,
    "created_at" : "2012-08-31 23:32:24 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 241682605374840833,
  "created_at" : "2012-08-31 23:43:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "indices" : [ 3, 19 ],
      "id_str" : "29251361",
      "id" : 29251361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241682475414331392",
  "text" : "RT @WorldOfJoeRiggs: I'm an American, I love my country. But all this talk of \"Supremacy\" and Mitt's \"need an American\" bullshit reminds ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241680777430056960",
    "text" : "I'm an American, I love my country. But all this talk of \"Supremacy\" and Mitt's \"need an American\" bullshit reminds me of Nazi propaganda.",
    "id" : 241680777430056960,
    "created_at" : "2012-08-31 23:36:02 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 241682475414331392,
  "created_at" : "2012-08-31 23:42:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241660233020227584",
  "text" : "RT @Buddhaworld: what the hell am i doing here, by the way where the hell am i anyway?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241659697617305600",
    "text" : "what the hell am i doing here, by the way where the hell am i anyway?",
    "id" : 241659697617305600,
    "created_at" : "2012-08-31 22:12:16 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 241660233020227584,
  "created_at" : "2012-08-31 22:14:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241657689862713344",
  "text" : "@SocialistXian yay! : ) we had a terrifying 2 hours yesterday when our modem  got wonky..lol",
  "id" : 241657689862713344,
  "created_at" : "2012-08-31 22:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Wildlife",
      "screen_name" : "NWF",
      "indices" : [ 3, 7 ],
      "id_str" : "3554721",
      "id" : 3554721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/Xyxpxjmq",
      "expanded_url" : "http:\/\/goo.gl\/WDwVt",
      "display_url" : "goo.gl\/WDwVt"
    } ]
  },
  "geo" : { },
  "id_str" : "241642639806578689",
  "text" : "RT @NWF: Learn how to certify your yard as an NWF wildlife habitat:  http:\/\/t.co\/Xyxpxjmq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/Xyxpxjmq",
        "expanded_url" : "http:\/\/goo.gl\/WDwVt",
        "display_url" : "goo.gl\/WDwVt"
      } ]
    },
    "geo" : { },
    "id_str" : "241641605327638529",
    "text" : "Learn how to certify your yard as an NWF wildlife habitat:  http:\/\/t.co\/Xyxpxjmq",
    "id" : 241641605327638529,
    "created_at" : "2012-08-31 21:00:22 +0000",
    "user" : {
      "name" : "National Wildlife",
      "screen_name" : "NWF",
      "protected" : false,
      "id_str" : "3554721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748899615097978880\/oDEbWwlK_normal.jpg",
      "id" : 3554721,
      "verified" : true
    }
  },
  "id" : 241642639806578689,
  "created_at" : "2012-08-31 21:04:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "voting",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241639881888116736",
  "text" : "RT @Buddhaworld: #voting in the usa is like \" i made a mistake 4 years ago and i am willing to do the same this time\". Volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "voting",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241632113475059712",
    "text" : "#voting in the usa is like \" i made a mistake 4 years ago and i am willing to do the same this time\". Volko.",
    "id" : 241632113475059712,
    "created_at" : "2012-08-31 20:22:39 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 241639881888116736,
  "created_at" : "2012-08-31 20:53:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/hiJe5cN2",
      "expanded_url" : "http:\/\/bit.ly\/OGyqDE",
      "display_url" : "bit.ly\/OGyqDE"
    } ]
  },
  "geo" : { },
  "id_str" : "241619576864010242",
  "text" : "\u201CNew Hampshire sheriff candidate Frank Szabo promises to use \"deadly force\" to stop abortions\u201D http:\/\/t.co\/hiJe5cN2",
  "id" : 241619576864010242,
  "created_at" : "2012-08-31 19:32:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/MNR447rE",
      "expanded_url" : "http:\/\/www.care2.com\/causes\/scientists-proclaim-animal-and-human-consciousness-the-same.html",
      "display_url" : "care2.com\/causes\/scienti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241564799799005184",
  "text" : "cool beans! : ) &gt;&gt; Scientists Proclaim Animal and Human Consciousness the Same http:\/\/t.co\/MNR447rE",
  "id" : 241564799799005184,
  "created_at" : "2012-08-31 15:55:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 3, 13 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241558110345498625",
  "text" : "RT @MakeUseOf: Tell us what gadget you'll buy with $100 &amp; one of you will win it! What are you waiting for? The sky ($100) is the limit!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sendible.com\" rel=\"nofollow\"\u003ESendible\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241557252710989825",
    "text" : "Tell us what gadget you'll buy with $100 &amp; one of you will win it! What are you waiting for? The sky ($100) is the limit!",
    "id" : 241557252710989825,
    "created_at" : "2012-08-31 15:25:11 +0000",
    "user" : {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "protected" : false,
      "id_str" : "63043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771290297255006208\/qJzhURwu_normal.jpg",
      "id" : 63043,
      "verified" : true
    }
  },
  "id" : 241558110345498625,
  "created_at" : "2012-08-31 15:28:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/5AeN12YP",
      "expanded_url" : "http:\/\/amzn.to\/ONN2PR",
      "display_url" : "amzn.to\/ONN2PR"
    } ]
  },
  "geo" : { },
  "id_str" : "241550244108705794",
  "text" : "finished Psychic Readings With The Thinkers Of Heaven by John McGinnis and Martha McGinnis http:\/\/t.co\/5AeN12YP #Kindle",
  "id" : 241550244108705794,
  "created_at" : "2012-08-31 14:57:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric J. Gates",
      "screen_name" : "eThrillerWriter",
      "indices" : [ 3, 19 ],
      "id_str" : "450852338",
      "id" : 450852338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Kzs0P8j7",
      "expanded_url" : "http:\/\/www.theage.com.au\/technology\/sci-tech\/bionic-eye-goes-live-in-world-first-by-australian-researchers-20120830-251nu.html",
      "display_url" : "theage.com.au\/technology\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241546786093793280",
  "text" : "RT @eThrillerWriter: Bionic eyes:  http:\/\/t.co\/Kzs0P8j7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http:\/\/t.co\/Kzs0P8j7",
        "expanded_url" : "http:\/\/www.theage.com.au\/technology\/sci-tech\/bionic-eye-goes-live-in-world-first-by-australian-researchers-20120830-251nu.html",
        "display_url" : "theage.com.au\/technology\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241544246207840257",
    "text" : "Bionic eyes:  http:\/\/t.co\/Kzs0P8j7",
    "id" : 241544246207840257,
    "created_at" : "2012-08-31 14:33:30 +0000",
    "user" : {
      "name" : "Eric J. Gates",
      "screen_name" : "eThrillerWriter",
      "protected" : false,
      "id_str" : "450852338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687284639975747584\/7CUI2jvN_normal.jpg",
      "id" : 450852338,
      "verified" : false
    }
  },
  "id" : 241546786093793280,
  "created_at" : "2012-08-31 14:43:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Me, My Shelf and I",
      "screen_name" : "MyShelfAndI",
      "indices" : [ 3, 15 ],
      "id_str" : "260300375",
      "id" : 260300375
    }, {
      "name" : "Gretchen McNeil",
      "screen_name" : "GretchenMcNeil",
      "indices" : [ 58, 73 ],
      "id_str" : "14734870",
      "id" : 14734870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241545523235016705",
  "text" : "RT @MyShelfAndI: I'm giving away my coveted ARC of TEN by @gretchenmcneil - hurry up and enter before I change my mind and keep it! http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gretchen McNeil",
        "screen_name" : "GretchenMcNeil",
        "indices" : [ 41, 56 ],
        "id_str" : "14734870",
        "id" : 14734870
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/tDNUOp1q",
        "expanded_url" : "http:\/\/www.memyshelfandi.com\/2012\/08\/ten-tour-giveaway.html",
        "display_url" : "memyshelfandi.com\/2012\/08\/ten-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241538625043582977",
    "text" : "I'm giving away my coveted ARC of TEN by @gretchenmcneil - hurry up and enter before I change my mind and keep it! http:\/\/t.co\/tDNUOp1q",
    "id" : 241538625043582977,
    "created_at" : "2012-08-31 14:11:10 +0000",
    "user" : {
      "name" : "Me, My Shelf and I",
      "screen_name" : "MyShelfAndI",
      "protected" : false,
      "id_str" : "260300375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452999018432307200\/eTcdPB6I_normal.jpeg",
      "id" : 260300375,
      "verified" : false
    }
  },
  "id" : 241545523235016705,
  "created_at" : "2012-08-31 14:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241542856274243584",
  "text" : "all this political stuff is messing w my aura.. need to focus on something else!",
  "id" : 241542856274243584,
  "created_at" : "2012-08-31 14:27:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 46, 59 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/kkG3grud",
      "expanded_url" : "http:\/\/bookwi.se\/artemis-fowl-is-free\/",
      "display_url" : "bookwi.se\/artemis-fowl-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241526901729001472",
  "text" : "Artemis Fowl is Free http:\/\/t.co\/kkG3grud via @adamrshields",
  "id" : 241526901729001472,
  "created_at" : "2012-08-31 13:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241350413763346433",
  "text" : "RT @ZachsMind: I'm with Republicans on the idea that we have too many laws, but step away when, in the same blasted breath, they tell ot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241349070298443777",
    "text" : "I'm with Republicans on the idea that we have too many laws, but step away when, in the same blasted breath, they tell others how to live.",
    "id" : 241349070298443777,
    "created_at" : "2012-08-31 01:37:57 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 241350413763346433,
  "created_at" : "2012-08-31 01:43:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Oarvu7XQ",
      "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/2012\/06\/bringnickhome.html?spref=tw",
      "display_url" : "thesimpleboxcar.com\/2012\/06\/bringn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241253066572177408",
  "text" : "RT @AniKnits: For the new followers who don't know why my son is in foster care. http:\/\/t.co\/Oarvu7XQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/Oarvu7XQ",
        "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/2012\/06\/bringnickhome.html?spref=tw",
        "display_url" : "thesimpleboxcar.com\/2012\/06\/bringn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241251464796860416",
    "text" : "For the new followers who don't know why my son is in foster care. http:\/\/t.co\/Oarvu7XQ",
    "id" : 241251464796860416,
    "created_at" : "2012-08-30 19:10:06 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 241253066572177408,
  "created_at" : "2012-08-30 19:16:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241199212581236737",
  "text" : "just drew a lion.. it was pitiful. lol",
  "id" : 241199212581236737,
  "created_at" : "2012-08-30 15:42:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241181944229007361",
  "text" : "RT @ducksandclucks: There's a little Cooper's hawk on the fence in the middle of this photo and he's driving my flock bonkers. T http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/GwBw71eP",
        "expanded_url" : "http:\/\/instagr.am\/p\/O9KXFbhH-n\/",
        "display_url" : "instagr.am\/p\/O9KXFbhH-n\/"
      } ]
    },
    "geo" : { },
    "id_str" : "241181498072506368",
    "text" : "There's a little Cooper's hawk on the fence in the middle of this photo and he's driving my flock bonkers. T http:\/\/t.co\/GwBw71eP",
    "id" : 241181498072506368,
    "created_at" : "2012-08-30 14:32:04 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 241181944229007361,
  "created_at" : "2012-08-30 14:33:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "violence",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/GRDN6iEm",
      "expanded_url" : "http:\/\/protectthepolls.com\/",
      "display_url" : "protectthepolls.com"
    } ]
  },
  "geo" : { },
  "id_str" : "241175307116224512",
  "text" : "umm.. is this for real? &gt;&gt; http:\/\/t.co\/GRDN6iEm #violence",
  "id" : 241175307116224512,
  "created_at" : "2012-08-30 14:07:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Candlesmoke",
      "screen_name" : "JosephMagnuson",
      "indices" : [ 3, 18 ],
      "id_str" : "216402323",
      "id" : 216402323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241173853110407168",
  "text" : "RT @JosephMagnuson: I'm pro-choice, pro-spirituality, pro-LGBT rights, pro-civil rights, tree hugging nature worshiper. I am not sorry & ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241170064773091330",
    "text" : "I'm pro-choice, pro-spirituality, pro-LGBT rights, pro-civil rights, tree hugging nature worshiper. I am not sorry &amp; will discuss if needed.",
    "id" : 241170064773091330,
    "created_at" : "2012-08-30 13:46:38 +0000",
    "user" : {
      "name" : "Joseph Candlesmoke",
      "screen_name" : "JosephMagnuson",
      "protected" : false,
      "id_str" : "216402323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798185648322703360\/_fA5r_9z_normal.jpg",
      "id" : 216402323,
      "verified" : false
    }
  },
  "id" : 241173853110407168,
  "created_at" : "2012-08-30 14:01:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rima Regas, Blog#42",
      "screen_name" : "Rima_Regas",
      "indices" : [ 3, 14 ],
      "id_str" : "18597764",
      "id" : 18597764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "Tax",
      "indices" : [ 48, 52 ]
    }, {
      "text" : "privacy",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "vagina",
      "indices" : [ 94, 101 ]
    }, {
      "text" : "Facebook",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241172153297432577",
  "text" : "RT @Rima_Regas: Why does Mitt #Romney think his #Tax history deserves more #privacy than your #vagina? Found on #Facebook http:\/\/t.co\/Z4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Romney",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "Tax",
        "indices" : [ 32, 36 ]
      }, {
        "text" : "privacy",
        "indices" : [ 59, 67 ]
      }, {
        "text" : "vagina",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "Facebook",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/Z4De8cWC",
        "expanded_url" : "http:\/\/twitpic.com\/ap2pma",
        "display_url" : "twitpic.com\/ap2pma"
      } ]
    },
    "geo" : { },
    "id_str" : "240982068148961281",
    "text" : "Why does Mitt #Romney think his #Tax history deserves more #privacy than your #vagina? Found on #Facebook http:\/\/t.co\/Z4De8cWC",
    "id" : 240982068148961281,
    "created_at" : "2012-08-30 01:19:36 +0000",
    "user" : {
      "name" : "Rima Regas, Blog#42",
      "screen_name" : "Rima_Regas",
      "protected" : false,
      "id_str" : "18597764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671089061541580800\/0NnXhqsG_normal.jpg",
      "id" : 18597764,
      "verified" : false
    }
  },
  "id" : 241172153297432577,
  "created_at" : "2012-08-30 13:54:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Green",
      "screen_name" : "ideawoman10",
      "indices" : [ 3, 15 ],
      "id_str" : "97750537",
      "id" : 97750537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241171939878662144",
  "text" : "RT @ideawoman10: If hard work made U rich, slaves would have been the richest.Pleeze no more rich,right-wing white man lecturing black p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "240912902553493506",
    "text" : "If hard work made U rich, slaves would have been the richest.Pleeze no more rich,right-wing white man lecturing black people abt \"hard work\"",
    "id" : 240912902553493506,
    "created_at" : "2012-08-29 20:44:46 +0000",
    "user" : {
      "name" : "Donna Green",
      "screen_name" : "ideawoman10",
      "protected" : false,
      "id_str" : "97750537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846321014\/Donna_normal.jpg",
      "id" : 97750537,
      "verified" : false
    }
  },
  "id" : 241171939878662144,
  "created_at" : "2012-08-30 13:54:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "indices" : [ 3, 15 ],
      "id_str" : "19791234",
      "id" : 19791234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/z88Q3aqw",
      "expanded_url" : "http:\/\/owl.li\/dkAh7",
      "display_url" : "owl.li\/dkAh7"
    } ]
  },
  "geo" : { },
  "id_str" : "240952169296183296",
  "text" : "RT @Emperor_Bob: On Mitt Romney, Bain Capital and Private Equity | Matt Taibbi | Rolling Stone http:\/\/t.co\/z88Q3aqw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/z88Q3aqw",
        "expanded_url" : "http:\/\/owl.li\/dkAh7",
        "display_url" : "owl.li\/dkAh7"
      } ]
    },
    "geo" : { },
    "id_str" : "240949500749955072",
    "text" : "On Mitt Romney, Bain Capital and Private Equity | Matt Taibbi | Rolling Stone http:\/\/t.co\/z88Q3aqw",
    "id" : 240949500749955072,
    "created_at" : "2012-08-29 23:10:12 +0000",
    "user" : {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "protected" : false,
      "id_str" : "19791234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3352084632\/6ebf06ce559f48c77c691cb928fc62ab_normal.png",
      "id" : 19791234,
      "verified" : false
    }
  },
  "id" : 240952169296183296,
  "created_at" : "2012-08-29 23:20:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Sacerdot\u0646s",
      "screen_name" : "Sacerdotus",
      "indices" : [ 40, 51 ],
      "id_str" : "40597139",
      "id" : 40597139
    }, {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 52, 64 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    }, {
      "name" : "Bronx Bomber",
      "screen_name" : "Bronxbomber777",
      "indices" : [ 74, 89 ],
      "id_str" : "40597623",
      "id" : 40597623
    }, {
      "name" : "Rosa Rubicondior",
      "screen_name" : "RosaRubicondior",
      "indices" : [ 90, 106 ],
      "id_str" : "139121990",
      "id" : 139121990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240949847455318016",
  "geo" : { },
  "id_str" : "240951443299901440",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind ((highfive)) ba da bing! ; ) @Sacerdotus @embreeology @jaxzohn @Bronxbomber777 @RosaRubicondior",
  "id" : 240951443299901440,
  "in_reply_to_status_id" : 240949847455318016,
  "created_at" : "2012-08-29 23:17:55 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/Qy4eUYpC",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-9i",
      "display_url" : "wp.me\/pzgRU-9i"
    } ]
  },
  "geo" : { },
  "id_str" : "240938688941539328",
  "text" : "RT @ZachsMind: Rock You Like A Hurricane http:\/\/t.co\/Qy4eUYpC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/Qy4eUYpC",
        "expanded_url" : "http:\/\/wp.me\/pzgRU-9i",
        "display_url" : "wp.me\/pzgRU-9i"
      } ]
    },
    "geo" : { },
    "id_str" : "240930453551464448",
    "text" : "Rock You Like A Hurricane http:\/\/t.co\/Qy4eUYpC",
    "id" : 240930453551464448,
    "created_at" : "2012-08-29 21:54:31 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 240938688941539328,
  "created_at" : "2012-08-29 22:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/fO8eRtsB",
      "expanded_url" : "http:\/\/bit.ly\/O2LsbD",
      "display_url" : "bit.ly\/O2LsbD"
    } ]
  },
  "geo" : { },
  "id_str" : "240805693354041344",
  "text" : "\u201C...as the Romney's. They live in an America so different that I feel like I'm watching them via satellite.\u201D http:\/\/t.co\/fO8eRtsB",
  "id" : 240805693354041344,
  "created_at" : "2012-08-29 13:38:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 125, 135 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/YY2ouWwV",
      "expanded_url" : "http:\/\/shar.es\/7lBfj",
      "display_url" : "shar.es\/7lBfj"
    } ]
  },
  "geo" : { },
  "id_str" : "240573004436869121",
  "text" : "Romney says putting his money in Switzerland and the Cayman Islands wasn't about reducing his taxes http:\/\/t.co\/YY2ouWwV via @sharethis",
  "id" : 240573004436869121,
  "created_at" : "2012-08-28 22:14:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nexus",
      "screen_name" : "googlenexus",
      "indices" : [ 11, 23 ],
      "id_str" : "207773069",
      "id" : 207773069
    }, {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 31, 41 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/qxi06eHR",
      "expanded_url" : "http:\/\/www.makeuseof.com\/tag\/google-nexus-7-16gb-android-tablet-review-and-giveaway\/",
      "display_url" : "makeuseof.com\/tag\/google-nex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240481498883584001",
  "text" : "WIN a 16GB @googlenexus 7 from @makeuseof! Read our review and join the contest! http:\/\/t.co\/qxi06eHR",
  "id" : 240481498883584001,
  "created_at" : "2012-08-28 16:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239879677353807872",
  "geo" : { },
  "id_str" : "239887783873880064",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin ((hugs))",
  "id" : 239887783873880064,
  "in_reply_to_status_id" : 239879677353807872,
  "created_at" : "2012-08-27 00:51:19 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239886806668177408",
  "text" : "@Tideliar awww... sweet!",
  "id" : 239886806668177408,
  "created_at" : "2012-08-27 00:47:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Worona",
      "screen_name" : "SLWorona",
      "indices" : [ 3, 12 ],
      "id_str" : "109585567",
      "id" : 109585567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239760776431284224",
  "text" : "RT @SLWorona: First-hand account of how it feels when the TSA occupying army chats you up about where you're flying and why. http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/qKcOW4Gq",
        "expanded_url" : "http:\/\/bit.ly\/MTVQp9",
        "display_url" : "bit.ly\/MTVQp9"
      } ]
    },
    "geo" : { },
    "id_str" : "239730586267303936",
    "text" : "First-hand account of how it feels when the TSA occupying army chats you up about where you're flying and why. http:\/\/t.co\/qKcOW4Gq",
    "id" : 239730586267303936,
    "created_at" : "2012-08-26 14:26:40 +0000",
    "user" : {
      "name" : "Steve Worona",
      "screen_name" : "SLWorona",
      "protected" : false,
      "id_str" : "109585567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3109321983\/49ad7f4bda64ad4fe3ccb5036d57709d_normal.jpeg",
      "id" : 109585567,
      "verified" : false
    }
  },
  "id" : 239760776431284224,
  "created_at" : "2012-08-26 16:26:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239740935733407744",
  "text" : "RT @LukeRomyn: Someone asked me for advice. My advice was to ask someone else.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239738226871529474",
    "text" : "Someone asked me for advice. My advice was to ask someone else.",
    "id" : 239738226871529474,
    "created_at" : "2012-08-26 14:57:02 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 239740935733407744,
  "created_at" : "2012-08-26 15:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239740900891312129",
  "text" : "RT @TheGoldenMirror: Don\u2019t compare your progress with that of others. We all need our own time to travel our own distance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239738297042219008",
    "text" : "Don\u2019t compare your progress with that of others. We all need our own time to travel our own distance.",
    "id" : 239738297042219008,
    "created_at" : "2012-08-26 14:57:18 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 239740900891312129,
  "created_at" : "2012-08-26 15:07:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239732754873475072",
  "text" : ". @Skeptical_Lady labels are generalities.. could say same for christian or any group.. love the feral cats metaphor..lol",
  "id" : 239732754873475072,
  "created_at" : "2012-08-26 14:35:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239731054943014912",
  "text" : "@SamsaricWarrior love the pics you posted of you and fam. cant believe school is starting up soon..ugh! nobody happy! lol",
  "id" : 239731054943014912,
  "created_at" : "2012-08-26 14:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239726953970675712",
  "text" : "it's my mommy's birthday today. happy birthday in heaven, mother! i love you! \u2665",
  "id" : 239726953970675712,
  "created_at" : "2012-08-26 14:12:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/x8UILqNr",
      "expanded_url" : "http:\/\/po.st\/SYTx2o\/",
      "display_url" : "po.st\/SYTx2o\/"
    } ]
  },
  "geo" : { },
  "id_str" : "239547010271817728",
  "text" : "Good movie! .. Fido (2006) - IMDb - http:\/\/t.co\/x8UILqNr",
  "id" : 239547010271817728,
  "created_at" : "2012-08-26 02:17:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 50, 60 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialcommentary",
      "indices" : [ 61, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/uLMauzeA",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-92",
      "display_url" : "wp.me\/pzgRU-92"
    } ]
  },
  "geo" : { },
  "id_str" : "239408503721168896",
  "text" : "Lance Armstrong In Exile http:\/\/t.co\/uLMauzeA via @ZachsMind #socialcommentary",
  "id" : 239408503721168896,
  "created_at" : "2012-08-25 17:06:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 2, 12 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238979290505555968",
  "geo" : { },
  "id_str" : "239152016100843520",
  "in_reply_to_user_id" : 48215218,
  "text" : ". @bend_time hey sweets.. just been busy on websites. had to switch hosts.. all is fine here. ((hugs))",
  "id" : 239152016100843520,
  "in_reply_to_status_id" : 238979290505555968,
  "created_at" : "2012-08-25 00:07:38 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 3, 16 ],
      "id_str" : "145890580",
      "id" : 145890580
    }, {
      "name" : "DKNY",
      "screen_name" : "dkny",
      "indices" : [ 71, 76 ],
      "id_str" : "28635233",
      "id" : 28635233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238812894739980288",
  "text" : "RT @AmyRBromberg: I have a secret to tell you...it's for every day. RT @dkny: chocolate is the answer for today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DKNY",
        "screen_name" : "dkny",
        "indices" : [ 53, 58 ],
        "id_str" : "28635233",
        "id" : 28635233
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238806553984110593",
    "text" : "I have a secret to tell you...it's for every day. RT @dkny: chocolate is the answer for today.",
    "id" : 238806553984110593,
    "created_at" : "2012-08-24 01:14:53 +0000",
    "user" : {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "protected" : false,
      "id_str" : "145890580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754371483720376320\/lPjb2W1B_normal.jpg",
      "id" : 145890580,
      "verified" : false
    }
  },
  "id" : 238812894739980288,
  "created_at" : "2012-08-24 01:40:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 6, 16 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialcommentary",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238437051148681219",
  "text" : "wow.. @zachsmind is on a roll lately.. so many great blog posts! #socialcommentary",
  "id" : 238437051148681219,
  "created_at" : "2012-08-23 00:46:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 53, 63 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/M9LVmWsG",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-8B",
      "display_url" : "wp.me\/pzgRU-8B"
    } ]
  },
  "geo" : { },
  "id_str" : "238435794853961728",
  "text" : "Let Me Be Perfectly Clear.. http:\/\/t.co\/M9LVmWsG via @ZachsMind",
  "id" : 238435794853961728,
  "created_at" : "2012-08-23 00:41:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherlock ",
      "screen_name" : "Tripster_",
      "indices" : [ 3, 13 ],
      "id_str" : "747382766",
      "id" : 747382766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238373067880005634",
  "text" : "RT @Tripster_: precisely. that's just what I was thinking. Whoever you are. whatever.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238372277031424001",
    "text" : "precisely. that's just what I was thinking. Whoever you are. whatever.",
    "id" : 238372277031424001,
    "created_at" : "2012-08-22 20:29:14 +0000",
    "user" : {
      "name" : "Sherlock ",
      "screen_name" : "Tripster_",
      "protected" : false,
      "id_str" : "747382766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2485672747\/az50b6ecipierf0r2pvo_normal.gif",
      "id" : 747382766,
      "verified" : false
    }
  },
  "id" : 238373067880005634,
  "created_at" : "2012-08-22 20:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238370361106894848",
  "text" : "people are naked everyday.. in fact we are born that way.. get over it!!",
  "id" : 238370361106894848,
  "created_at" : "2012-08-22 20:21:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238362645697282049",
  "text" : "categories and tags, oh my! lol",
  "id" : 238362645697282049,
  "created_at" : "2012-08-22 19:50:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 35, 45 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/ftfAZUCg",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-8r",
      "display_url" : "wp.me\/pzgRU-8r"
    } ]
  },
  "geo" : { },
  "id_str" : "238309896427294721",
  "text" : "Misspoken http:\/\/t.co\/ftfAZUCg via @ZachsMind",
  "id" : 238309896427294721,
  "created_at" : "2012-08-22 16:21:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nofilter",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/5kEas0nF",
      "expanded_url" : "http:\/\/instagr.am\/p\/OogrMEBH8u\/",
      "display_url" : "instagr.am\/p\/OogrMEBH8u\/"
    } ]
  },
  "geo" : { },
  "id_str" : "238280553755987968",
  "text" : "RT @ducksandclucks: Simon, meet opossum. #nofilter http:\/\/t.co\/5kEas0nF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nofilter",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/5kEas0nF",
        "expanded_url" : "http:\/\/instagr.am\/p\/OogrMEBH8u\/",
        "display_url" : "instagr.am\/p\/OogrMEBH8u\/"
      } ]
    },
    "geo" : { },
    "id_str" : "238274846054813697",
    "text" : "Simon, meet opossum. #nofilter http:\/\/t.co\/5kEas0nF",
    "id" : 238274846054813697,
    "created_at" : "2012-08-22 14:02:04 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 238280553755987968,
  "created_at" : "2012-08-22 14:24:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238280444334972928",
  "text" : "RT @ducksandclucks: Little opossum in the yard this morning. Seems a little young to be on his own but he found cat kibble and h http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/cDA9wUuf",
        "expanded_url" : "http:\/\/instagr.am\/p\/Oog1IDBH80\/",
        "display_url" : "instagr.am\/p\/Oog1IDBH80\/"
      } ]
    },
    "geo" : { },
    "id_str" : "238275331197382656",
    "text" : "Little opossum in the yard this morning. Seems a little young to be on his own but he found cat kibble and h http:\/\/t.co\/cDA9wUuf",
    "id" : 238275331197382656,
    "created_at" : "2012-08-22 14:04:00 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 238280444334972928,
  "created_at" : "2012-08-22 14:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238278837232861184",
  "text" : "RT @TheGoldenMirror: Those who let themselves be provoked are not their own masters.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238277702359072768",
    "text" : "Those who let themselves be provoked are not their own masters.",
    "id" : 238277702359072768,
    "created_at" : "2012-08-22 14:13:25 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 238278837232861184,
  "created_at" : "2012-08-22 14:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Z3F3fHxm",
      "expanded_url" : "http:\/\/lobrc.net",
      "display_url" : "lobrc.net"
    }, {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/PHKDD6Jl",
      "expanded_url" : "http:\/\/www.lobrc.net\/2012\/08\/wheres-my-pound\/",
      "display_url" : "lobrc.net\/2012\/08\/wheres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238255797707079680",
  "text" : "Riddle: Where\u2019s my pound? | http:\/\/t.co\/Z3F3fHxm http:\/\/t.co\/PHKDD6Jl",
  "id" : 238255797707079680,
  "created_at" : "2012-08-22 12:46:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238078401469108225",
  "geo" : { },
  "id_str" : "238080674865745920",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms ((hugs))",
  "id" : 238080674865745920,
  "in_reply_to_status_id" : 238078401469108225,
  "created_at" : "2012-08-22 01:10:30 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 63, 73 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/u7ksrUVS",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-8i",
      "display_url" : "wp.me\/pzgRU-8i"
    } ]
  },
  "geo" : { },
  "id_str" : "237886984666902528",
  "text" : "Belief makes an ass out of you and me http:\/\/t.co\/u7ksrUVS via @ZachsMind",
  "id" : 237886984666902528,
  "created_at" : "2012-08-21 12:20:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheila",
      "screen_name" : "Sheila_Mac420",
      "indices" : [ 3, 17 ],
      "id_str" : "31329800",
      "id" : 31329800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237884995178483712",
  "text" : "RT @Sheila_Mac420: Twitter has many different flavors of crazy, the key is to find the taste you like best.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236281487857684480",
    "text" : "Twitter has many different flavors of crazy, the key is to find the taste you like best.",
    "id" : 236281487857684480,
    "created_at" : "2012-08-17 02:01:11 +0000",
    "user" : {
      "name" : "Sheila",
      "screen_name" : "Sheila_Mac420",
      "protected" : false,
      "id_str" : "31329800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2051866233\/GUITAR_normal.jpg",
      "id" : 31329800,
      "verified" : false
    }
  },
  "id" : 237884995178483712,
  "created_at" : "2012-08-21 12:12:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237687877000110080",
  "geo" : { },
  "id_str" : "237695547404845057",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem jeepers! not nice at all! ((hugs))",
  "id" : 237695547404845057,
  "in_reply_to_status_id" : 237687877000110080,
  "created_at" : "2012-08-20 23:40:09 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maddow",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237694817864404992",
  "text" : "RT @Destroyer0919: If a fertilised egg is a person, and the mother dies during childbirth, is the baby charged with murder? #Maddow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Maddow",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "235543030969548800",
    "text" : "If a fertilised egg is a person, and the mother dies during childbirth, is the baby charged with murder? #Maddow",
    "id" : 235543030969548800,
    "created_at" : "2012-08-15 01:06:49 +0000",
    "user" : {
      "name" : "Brandon Thomas",
      "screen_name" : "Brandon0919",
      "protected" : false,
      "id_str" : "63731881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784159052733386752\/TCSeo5qS_normal.jpg",
      "id" : 63731881,
      "verified" : false
    }
  },
  "id" : 237694817864404992,
  "created_at" : "2012-08-20 23:37:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237561468202151940",
  "text" : "RT @mbekezm: Obama and Romney election apps suck up personal data, research finds: Millions of US voters could be ... http:\/\/t.co\/bPD2rX ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "techworld",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/bPD2rXeh",
        "expanded_url" : "http:\/\/bit.ly\/SIr8gq",
        "display_url" : "bit.ly\/SIr8gq"
      } ]
    },
    "geo" : { },
    "id_str" : "237560634655514624",
    "text" : "Obama and Romney election apps suck up personal data, research finds: Millions of US voters could be ... http:\/\/t.co\/bPD2rXeh #techworld",
    "id" : 237560634655514624,
    "created_at" : "2012-08-20 14:44:03 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 237561468202151940,
  "created_at" : "2012-08-20 14:47:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236840413032484865",
  "text" : "@statue_dog great job! : )",
  "id" : 236840413032484865,
  "created_at" : "2012-08-18 15:02:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Nathan Phelps",
      "screen_name" : "n8phelps",
      "indices" : [ 51, 60 ],
      "id_str" : "23073327",
      "id" : 23073327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236839373306466304",
  "geo" : { },
  "id_str" : "236840110539284480",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny to hate anything is a waste of energy @n8phelps",
  "id" : 236840110539284480,
  "in_reply_to_status_id" : 236839373306466304,
  "created_at" : "2012-08-18 15:00:57 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All Above",
      "screen_name" : "DyingAmerican",
      "indices" : [ 3, 17 ],
      "id_str" : "138511761",
      "id" : 138511761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236631707082686465",
  "text" : "RT @DyingAmerican: Validated by a fan base is so many's sad life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236624931180392448",
    "text" : "Validated by a fan base is so many's sad life.",
    "id" : 236624931180392448,
    "created_at" : "2012-08-18 00:45:54 +0000",
    "user" : {
      "name" : "All Above",
      "screen_name" : "DyingAmerican",
      "protected" : false,
      "id_str" : "138511761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452842680309919744\/bld-YIHN_normal.png",
      "id" : 138511761,
      "verified" : false
    }
  },
  "id" : 236631707082686465,
  "created_at" : "2012-08-18 01:12:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236627680076890112",
  "geo" : { },
  "id_str" : "236631548957429760",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin so, so true. something I am still learning...",
  "id" : 236631548957429760,
  "in_reply_to_status_id" : 236627680076890112,
  "created_at" : "2012-08-18 01:12:12 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236630423655047168",
  "text" : "watching \"beyond scared straight\" interesting how girls are noted for \"promiscuity\" but not the boys.",
  "id" : 236630423655047168,
  "created_at" : "2012-08-18 01:07:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 3, 12 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236603473205002240",
  "text" : "RT @thislife: Enhance your Timeline by adding Notes &amp; Milestones! Just \"drop a pin\" on the ribbon &amp; get started telling YOUR sto ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236600080671584256",
    "text" : "Enhance your Timeline by adding Notes &amp; Milestones! Just \"drop a pin\" on the ribbon &amp; get started telling YOUR story! Happy weekend!",
    "id" : 236600080671584256,
    "created_at" : "2012-08-17 23:07:09 +0000",
    "user" : {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "protected" : false,
      "id_str" : "15474394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488837647981240321\/X8WiCtaq_normal.jpeg",
      "id" : 15474394,
      "verified" : false
    }
  },
  "id" : 236603473205002240,
  "created_at" : "2012-08-17 23:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236591740918824960",
  "text" : "RT @SangyeH: If we can't discuss Romney's tax returns, RomneyCare or his business record, the only thing left is what color socks he pre ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236587413936414720",
    "text" : "If we can't discuss Romney's tax returns, RomneyCare or his business record, the only thing left is what color socks he prefers.",
    "id" : 236587413936414720,
    "created_at" : "2012-08-17 22:16:49 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 236591740918824960,
  "created_at" : "2012-08-17 22:34:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/M06Ymb1B",
      "expanded_url" : "http:\/\/bit.ly\/RWXAhB",
      "display_url" : "bit.ly\/RWXAhB"
    } ]
  },
  "geo" : { },
  "id_str" : "236571082100981760",
  "text" : "RT @aliceinthewater: More Solid Advice From Pat Robertson: Be Careful About Adopting Children\nhttp:\/\/t.co\/M06Ymb1B #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 94, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/M06Ymb1B",
        "expanded_url" : "http:\/\/bit.ly\/RWXAhB",
        "display_url" : "bit.ly\/RWXAhB"
      } ]
    },
    "geo" : { },
    "id_str" : "236568934189527042",
    "text" : "More Solid Advice From Pat Robertson: Be Careful About Adopting Children\nhttp:\/\/t.co\/M06Ymb1B #lam",
    "id" : 236568934189527042,
    "created_at" : "2012-08-17 21:03:23 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 236571082100981760,
  "created_at" : "2012-08-17 21:11:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236570481434693632",
  "text" : "RT @myfallingbranch: Quinoa- a seed, in the grain category cooks up fluffy like rice. It\u2019s got a delicious, nutty flavor and is 16.2 per ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222657537542062080",
    "text" : "Quinoa- a seed, in the grain category cooks up fluffy like rice. It\u2019s got a delicious, nutty flavor and is 16.2 percent protein. Just saying",
    "id" : 222657537542062080,
    "created_at" : "2012-07-10 11:44:28 +0000",
    "user" : {
      "name" : "fallingbranch",
      "screen_name" : "_fallingbranch",
      "protected" : false,
      "id_str" : "120296552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780254043297968128\/lofZPoCB_normal.jpg",
      "id" : 120296552,
      "verified" : false
    }
  },
  "id" : 236570481434693632,
  "created_at" : "2012-08-17 21:09:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Phelps",
      "screen_name" : "n8phelps",
      "indices" : [ 3, 12 ],
      "id_str" : "23073327",
      "id" : 23073327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236550034773127168",
  "text" : "RT @n8phelps: When a belief system (read religion) introduces threats or exclusion, it stops being a search for truth, and becomes a mec ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236545073439965184",
    "text" : "When a belief system (read religion) introduces threats or exclusion, it stops being a search for truth, and becomes a mechanism of control.",
    "id" : 236545073439965184,
    "created_at" : "2012-08-17 19:28:34 +0000",
    "user" : {
      "name" : "Nathan Phelps",
      "screen_name" : "n8phelps",
      "protected" : false,
      "id_str" : "23073327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705599011839840256\/3jX-4sgW_normal.jpg",
      "id" : 23073327,
      "verified" : false
    }
  },
  "id" : 236550034773127168,
  "created_at" : "2012-08-17 19:48:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "nature",
      "indices" : [ 85, 92 ]
    }, {
      "text" : "birding",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/Vf0UCefc",
      "expanded_url" : "http:\/\/ow.ly\/d1L9j",
      "display_url" : "ow.ly\/d1L9j"
    } ]
  },
  "geo" : { },
  "id_str" : "236542474238185472",
  "text" : "RT @KerriFar: Eye to Eye with \"my little chickadee\" ~ http:\/\/t.co\/Vf0UCefc  ~ #birds #nature #birding",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 64, 70 ]
      }, {
        "text" : "nature",
        "indices" : [ 71, 78 ]
      }, {
        "text" : "birding",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/Vf0UCefc",
        "expanded_url" : "http:\/\/ow.ly\/d1L9j",
        "display_url" : "ow.ly\/d1L9j"
      } ]
    },
    "geo" : { },
    "id_str" : "236541686224912384",
    "text" : "Eye to Eye with \"my little chickadee\" ~ http:\/\/t.co\/Vf0UCefc  ~ #birds #nature #birding",
    "id" : 236541686224912384,
    "created_at" : "2012-08-17 19:15:07 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 236542474238185472,
  "created_at" : "2012-08-17 19:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236541965645275136",
  "text" : "@SamsaricWarrior aww.. looks like a keeshond...",
  "id" : 236541965645275136,
  "created_at" : "2012-08-17 19:16:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StoryBundle",
      "screen_name" : "storybundle",
      "indices" : [ 3, 15 ],
      "id_str" : "468625550",
      "id" : 468625550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/yEh6lA2e",
      "expanded_url" : "http:\/\/storybundle.com\/contest",
      "display_url" : "storybundle.com\/contest"
    } ]
  },
  "geo" : { },
  "id_str" : "236538457915269120",
  "text" : "RT @storybundle: What's cooler than being a character in a book? Nothing! We're offering you that chance. Find out how: http:\/\/t.co\/yEh6lA2e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/yEh6lA2e",
        "expanded_url" : "http:\/\/storybundle.com\/contest",
        "display_url" : "storybundle.com\/contest"
      } ]
    },
    "geo" : { },
    "id_str" : "236537425898397696",
    "text" : "What's cooler than being a character in a book? Nothing! We're offering you that chance. Find out how: http:\/\/t.co\/yEh6lA2e",
    "id" : 236537425898397696,
    "created_at" : "2012-08-17 18:58:11 +0000",
    "user" : {
      "name" : "StoryBundle",
      "screen_name" : "storybundle",
      "protected" : false,
      "id_str" : "468625550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2482659291\/gmv2bdvtrhteql7ebgrh_normal.png",
      "id" : 468625550,
      "verified" : false
    }
  },
  "id" : 236538457915269120,
  "created_at" : "2012-08-17 19:02:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pippinsplugins",
      "screen_name" : "pippinsplugins",
      "indices" : [ 3, 18 ],
      "id_str" : "294079511",
      "id" : 294079511
    }, {
      "name" : "EasyDigitalDownloads",
      "screen_name" : "eddwp",
      "indices" : [ 59, 65 ],
      "id_str" : "592277187",
      "id" : 592277187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236531022433509376",
  "text" : "RT @pippinsplugins: The person who can help this user with @eddwp within the next two hours gets $100 sent to their PayPal tonight: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EasyDigitalDownloads",
        "screen_name" : "eddwp",
        "indices" : [ 39, 45 ],
        "id_str" : "592277187",
        "id" : 592277187
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/zIcsLIwS",
        "expanded_url" : "http:\/\/easydigitaldownloads.com\/support\/topic\/no-download-links\/page\/3\/#post-4079",
        "display_url" : "easydigitaldownloads.com\/support\/topic\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "236529562903773184",
    "text" : "The person who can help this user with @eddwp within the next two hours gets $100 sent to their PayPal tonight: http:\/\/t.co\/zIcsLIwS",
    "id" : 236529562903773184,
    "created_at" : "2012-08-17 18:26:56 +0000",
    "user" : {
      "name" : "Pippinsplugins",
      "screen_name" : "pippinsplugins",
      "protected" : false,
      "id_str" : "294079511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1341344778\/n82408466_32367502_3013-300x201_normal.jpg",
      "id" : 294079511,
      "verified" : false
    }
  },
  "id" : 236531022433509376,
  "created_at" : "2012-08-17 18:32:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/7uTMcjx9",
      "expanded_url" : "http:\/\/bit.ly\/NJMIkz",
      "display_url" : "bit.ly\/NJMIkz"
    } ]
  },
  "geo" : { },
  "id_str" : "236521829253120000",
  "text" : "\u201CI\u2019m an anarchist, too! And an atheist. Pretty much the same thing.\u201D\u201D http:\/\/t.co\/7uTMcjx9",
  "id" : 236521829253120000,
  "created_at" : "2012-08-17 17:56:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236501986051235840",
  "text" : "RT @AnAmericanMonk: No human is able to avoid the teacher called experience. It is up to us to take the class which may not be skipped?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236501575382757376",
    "text" : "No human is able to avoid the teacher called experience. It is up to us to take the class which may not be skipped?",
    "id" : 236501575382757376,
    "created_at" : "2012-08-17 16:35:44 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 236501986051235840,
  "created_at" : "2012-08-17 16:37:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "politics",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236500673766764544",
  "text" : "think about the MILLIONS of dollars spent on election.. kinda raises the stakes, eh? #politics",
  "id" : 236500673766764544,
  "created_at" : "2012-08-17 16:32:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236497365480124416",
  "text" : "RT @Wylieknowords: Mitt Romney: \"Believe in America\" That's his slogan? Dodging the draft--running to France Not Vietnam War,banking off ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236496180291444736",
    "text" : "Mitt Romney: \"Believe in America\" That's his slogan? Dodging the draft--running to France Not Vietnam War,banking offshore,outsourcing jobs.",
    "id" : 236496180291444736,
    "created_at" : "2012-08-17 16:14:17 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 236497365480124416,
  "created_at" : "2012-08-17 16:19:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236481632981360641",
  "text" : "RT @shanecrash: This pussy riot stuff is making me sick. Insane that the church can still do this people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236476827940573184",
    "text" : "This pussy riot stuff is making me sick. Insane that the church can still do this people.",
    "id" : 236476827940573184,
    "created_at" : "2012-08-17 14:57:23 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 236481632981360641,
  "created_at" : "2012-08-17 15:16:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/SvXQ5n4A",
      "expanded_url" : "http:\/\/appadvice.com\/appnn\/2012\/08\/mobile-payment-system-highlights-new-dunkin-donuts-app",
      "display_url" : "appadvice.com\/appnn\/2012\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236476588143812608",
  "text" : "Mobile Payment System Highlights New Dunkin' Donuts App -- AppAdvice http:\/\/t.co\/SvXQ5n4A",
  "id" : 236476588143812608,
  "created_at" : "2012-08-17 14:56:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236473009559461888",
  "text" : "RT @TyrusBooks: I think I want to start some online tithing project involving Twitter called - Twithing and it'll be to help others with ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236463041980551169",
    "text" : "I think I want to start some online tithing project involving Twitter called - Twithing and it'll be to help others with their bills.",
    "id" : 236463041980551169,
    "created_at" : "2012-08-17 14:02:37 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 236473009559461888,
  "created_at" : "2012-08-17 14:42:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/dbFDOI1R",
      "expanded_url" : "http:\/\/getapp.cc\/app\/509979894",
      "display_url" : "getapp.cc\/app\/509979894"
    } ]
  },
  "geo" : { },
  "id_str" : "236472821419745282",
  "text" : "RT @AppAdvice: Retweet now for your chance to win a copy of cute universal game SubCat HD (http:\/\/t.co\/dbFDOI1R) for an adventure under  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/dbFDOI1R",
        "expanded_url" : "http:\/\/getapp.cc\/app\/509979894",
        "display_url" : "getapp.cc\/app\/509979894"
      } ]
    },
    "geo" : { },
    "id_str" : "236463754529890306",
    "text" : "Retweet now for your chance to win a copy of cute universal game SubCat HD (http:\/\/t.co\/dbFDOI1R) for an adventure under the sea.",
    "id" : 236463754529890306,
    "created_at" : "2012-08-17 14:05:27 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 236472821419745282,
  "created_at" : "2012-08-17 14:41:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyme",
      "indices" : [ 10, 15 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/wV7yQ0lr",
      "expanded_url" : "http:\/\/j.mp\/Piznlq",
      "display_url" : "j.mp\/Piznlq"
    } ]
  },
  "geo" : { },
  "id_str" : "236469393356369920",
  "text" : "Life With #Lyme Disease http:\/\/t.co\/wV7yQ0lr - (sharing, have followers might be interested...) #chronicillness",
  "id" : 236469393356369920,
  "created_at" : "2012-08-17 14:27:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/K1KZD7LC",
      "expanded_url" : "http:\/\/www.kboards.blogspot.com\/2012\/08\/kindleboards-giveaway-kindle-fire-2.html",
      "display_url" : "kboards.blogspot.com\/2012\/08\/kindle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236147688226308096",
  "text" : "Enter to win the new Kindle Fire 2 from KindleBoards - the web's largest independent Kindle community!\n http:\/\/t.co\/K1KZD7LC",
  "id" : 236147688226308096,
  "created_at" : "2012-08-16 17:09:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/aic2fMc6",
      "expanded_url" : "http:\/\/huff.to\/S0m9vA",
      "display_url" : "huff.to\/S0m9vA"
    } ]
  },
  "geo" : { },
  "id_str" : "236141479574241280",
  "text" : "RT @HuffPostWeird: Is this the most disturbing movie of the year? http:\/\/t.co\/aic2fMc6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/aic2fMc6",
        "expanded_url" : "http:\/\/huff.to\/S0m9vA",
        "display_url" : "huff.to\/S0m9vA"
      } ]
    },
    "geo" : { },
    "id_str" : "236139391112839169",
    "text" : "Is this the most disturbing movie of the year? http:\/\/t.co\/aic2fMc6",
    "id" : 236139391112839169,
    "created_at" : "2012-08-16 16:36:32 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 236141479574241280,
  "created_at" : "2012-08-16 16:44:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 0, 9 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/QNYLyIyH",
      "expanded_url" : "http:\/\/abfabgab.thislife.com\/invite",
      "display_url" : "abfabgab.thislife.com\/invite"
    } ]
  },
  "geo" : { },
  "id_str" : "235800821592375296",
  "in_reply_to_user_id" : 15474394,
  "text" : "@ThisLife is the best place to organize your photos &amp; videos, safely, in the cloud. Sign up and get free space! http:\/\/t.co\/QNYLyIyH",
  "id" : 235800821592375296,
  "created_at" : "2012-08-15 18:11:11 +0000",
  "in_reply_to_screen_name" : "ThisLife",
  "in_reply_to_user_id_str" : "15474394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ER9y2o8j",
      "expanded_url" : "http:\/\/lnkd.in\/Fh-SXi",
      "display_url" : "lnkd.in\/Fh-SXi"
    } ]
  },
  "geo" : { },
  "id_str" : "235481699327299584",
  "text" : "RT @Alaskachic907: Alaska Outdoor Photography: Baby Moose http:\/\/t.co\/ER9y2o8j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/ER9y2o8j",
        "expanded_url" : "http:\/\/lnkd.in\/Fh-SXi",
        "display_url" : "lnkd.in\/Fh-SXi"
      } ]
    },
    "geo" : { },
    "id_str" : "235480293711171584",
    "text" : "Alaska Outdoor Photography: Baby Moose http:\/\/t.co\/ER9y2o8j",
    "id" : 235480293711171584,
    "created_at" : "2012-08-14 20:57:31 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 235481699327299584,
  "created_at" : "2012-08-14 21:03:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StoryBundle",
      "screen_name" : "storybundle",
      "indices" : [ 3, 15 ],
      "id_str" : "468625550",
      "id" : 468625550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ZwBJrAk4",
      "expanded_url" : "http:\/\/storybundle.com\/",
      "display_url" : "storybundle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "235438492975501312",
  "text" : "RT @storybundle: Pay what you want for 7 highly rated, quality ebooks &amp; support indie authors and charity! Win\/win. http:\/\/t.co\/ZwBJrAk4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/ZwBJrAk4",
        "expanded_url" : "http:\/\/storybundle.com\/",
        "display_url" : "storybundle.com"
      } ]
    },
    "geo" : { },
    "id_str" : "235390340012580865",
    "text" : "Pay what you want for 7 highly rated, quality ebooks &amp; support indie authors and charity! Win\/win. http:\/\/t.co\/ZwBJrAk4",
    "id" : 235390340012580865,
    "created_at" : "2012-08-14 15:00:05 +0000",
    "user" : {
      "name" : "StoryBundle",
      "screen_name" : "storybundle",
      "protected" : false,
      "id_str" : "468625550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2482659291\/gmv2bdvtrhteql7ebgrh_normal.png",
      "id" : 468625550,
      "verified" : false
    }
  },
  "id" : 235438492975501312,
  "created_at" : "2012-08-14 18:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 47, 57 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/Uo39Nucv",
      "expanded_url" : "http:\/\/shar.es\/vFnf4",
      "display_url" : "shar.es\/vFnf4"
    } ]
  },
  "geo" : { },
  "id_str" : "235122455700729858",
  "text" : "Cat Intrudes Hen Nest http:\/\/t.co\/Uo39Nucv via @sharethis",
  "id" : 235122455700729858,
  "created_at" : "2012-08-13 21:15:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drawsomething",
      "indices" : [ 3, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235107027343519744",
  "text" : "my #drawsomething lorax colors disappeared!!! argh!!!",
  "id" : 235107027343519744,
  "created_at" : "2012-08-13 20:14:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CollegeHumor",
      "screen_name" : "CollegeHumor",
      "indices" : [ 119, 132 ],
      "id_str" : "16825289",
      "id" : 16825289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/9Lz6EcCf",
      "expanded_url" : "http:\/\/su.pr\/1xXUqB",
      "display_url" : "su.pr\/1xXUqB"
    } ]
  },
  "geo" : { },
  "id_str" : "235038314397319171",
  "text" : "love all the smiles! &gt;&gt; Creepy Chatroulette Guy Does Call Me Maybe - CollegeHumor Video http:\/\/t.co\/9Lz6EcCf via @CollegeHumor",
  "id" : 235038314397319171,
  "created_at" : "2012-08-13 15:41:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vsauce",
      "screen_name" : "tweetsauce",
      "indices" : [ 3, 14 ],
      "id_str" : "395477244",
      "id" : 395477244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/LQHVSVfq",
      "expanded_url" : "http:\/\/ow.ly\/cVoTk",
      "display_url" : "ow.ly\/cVoTk"
    } ]
  },
  "geo" : { },
  "id_str" : "235000327756206081",
  "text" : "RT @tweetsauce: NASA has used less money in its ENTIRE EXISTENCE than the US military used in 2010 alone --&gt; http:\/\/t.co\/LQHVSVfq via ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Today I Learned",
        "screen_name" : "TodayILearnd",
        "indices" : [ 121, 134 ],
        "id_str" : "117269128",
        "id" : 117269128
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/LQHVSVfq",
        "expanded_url" : "http:\/\/ow.ly\/cVoTk",
        "display_url" : "ow.ly\/cVoTk"
      } ]
    },
    "geo" : { },
    "id_str" : "234946482065793024",
    "text" : "NASA has used less money in its ENTIRE EXISTENCE than the US military used in 2010 alone --&gt; http:\/\/t.co\/LQHVSVfq via @todayilearnd",
    "id" : 234946482065793024,
    "created_at" : "2012-08-13 09:36:21 +0000",
    "user" : {
      "name" : "Vsauce",
      "screen_name" : "tweetsauce",
      "protected" : false,
      "id_str" : "395477244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431436560009932800\/PqD9V8km_normal.png",
      "id" : 395477244,
      "verified" : true
    }
  },
  "id" : 235000327756206081,
  "created_at" : "2012-08-13 13:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/WbWGUCmA",
      "expanded_url" : "http:\/\/tl.gd\/iqetar",
      "display_url" : "tl.gd\/iqetar"
    } ]
  },
  "geo" : { },
  "id_str" : "234821805473423360",
  "text" : "pharmacy is a drug pusher...  (cont) http:\/\/t.co\/WbWGUCmA",
  "id" : 234821805473423360,
  "created_at" : "2012-08-13 01:20:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234796477237575680",
  "text" : "RT @alanhdawe: Our biggest constraint is our own Ego restricting us with preconceptions\/limitations. We can shake off these shackles if  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233999430871818240",
    "text" : "Our biggest constraint is our own Ego restricting us with preconceptions\/limitations. We can shake off these shackles if we desire. #TGFBook",
    "id" : 233999430871818240,
    "created_at" : "2012-08-10 18:53:06 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 234796477237575680,
  "created_at" : "2012-08-12 23:40:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wild Colorado",
      "screen_name" : "WildColorado",
      "indices" : [ 3, 16 ],
      "id_str" : "567554051",
      "id" : 567554051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/8zfxfiQo",
      "expanded_url" : "http:\/\/bit.ly\/Iw5Q4O",
      "display_url" : "bit.ly\/Iw5Q4O"
    }, {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/jQEGVBqe",
      "expanded_url" : "http:\/\/www.coloradowildlifephotography.com",
      "display_url" : "coloradowildlifephotography.com"
    } ]
  },
  "geo" : { },
  "id_str" : "234761299861590017",
  "text" : "RT @WildColorado: Bull Moose Cools Off in a Lake http:\/\/t.co\/8zfxfiQo   http:\/\/t.co\/jQEGVBqe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/8zfxfiQo",
        "expanded_url" : "http:\/\/bit.ly\/Iw5Q4O",
        "display_url" : "bit.ly\/Iw5Q4O"
      }, {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/jQEGVBqe",
        "expanded_url" : "http:\/\/www.coloradowildlifephotography.com",
        "display_url" : "coloradowildlifephotography.com"
      } ]
    },
    "geo" : { },
    "id_str" : "234759852193353729",
    "text" : "Bull Moose Cools Off in a Lake http:\/\/t.co\/8zfxfiQo   http:\/\/t.co\/jQEGVBqe",
    "id" : 234759852193353729,
    "created_at" : "2012-08-12 21:14:45 +0000",
    "user" : {
      "name" : "Wild Colorado",
      "screen_name" : "WildColorado",
      "protected" : false,
      "id_str" : "567554051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749336505240334336\/ds0F2Jqs_normal.jpg",
      "id" : 567554051,
      "verified" : false
    }
  },
  "id" : 234761299861590017,
  "created_at" : "2012-08-12 21:20:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ryan Gosling",
      "screen_name" : "PaulRyanGosling",
      "indices" : [ 3, 19 ],
      "id_str" : "751187245",
      "id" : 751187245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234747292643651584",
  "text" : "RT @PaulRyanGosling: Hey girl, don't let the personhood issue get you down. You still get to choose what to make for dinner tonight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234656758067511298",
    "text" : "Hey girl, don't let the personhood issue get you down. You still get to choose what to make for dinner tonight.",
    "id" : 234656758067511298,
    "created_at" : "2012-08-12 14:25:05 +0000",
    "user" : {
      "name" : "Paul Ryan Gosling",
      "screen_name" : "PaulRyanGosling",
      "protected" : false,
      "id_str" : "751187245",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2733207454\/263275f8be21f8c210f108670292cfe9_normal.jpeg",
      "id" : 751187245,
      "verified" : false
    }
  },
  "id" : 234747292643651584,
  "created_at" : "2012-08-12 20:24:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inclusion",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234689167072825344",
  "text" : "driving around yesterday, saw a church sign \"come in, you already belong\" : ) #inclusion",
  "id" : 234689167072825344,
  "created_at" : "2012-08-12 16:33:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noir Nation",
      "screen_name" : "NoirNation",
      "indices" : [ 3, 14 ],
      "id_str" : "251318767",
      "id" : 251318767
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lendink",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "twitmob",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "veterans",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/UKMGzxb4",
      "expanded_url" : "http:\/\/bit.ly\/QSAKI7",
      "display_url" : "bit.ly\/QSAKI7"
    } ]
  },
  "geo" : { },
  "id_str" : "234664957596282880",
  "text" : "RT @NoirNation: Disabled military veteran\u2019s eBook lending site shuttered by TwitMob: http:\/\/t.co\/UKMGzxb4  #lendink #twitmob #veterans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lendink",
        "indices" : [ 91, 99 ]
      }, {
        "text" : "twitmob",
        "indices" : [ 100, 108 ]
      }, {
        "text" : "veterans",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/UKMGzxb4",
        "expanded_url" : "http:\/\/bit.ly\/QSAKI7",
        "display_url" : "bit.ly\/QSAKI7"
      } ]
    },
    "geo" : { },
    "id_str" : "234577942401933312",
    "text" : "Disabled military veteran\u2019s eBook lending site shuttered by TwitMob: http:\/\/t.co\/UKMGzxb4  #lendink #twitmob #veterans",
    "id" : 234577942401933312,
    "created_at" : "2012-08-12 09:11:54 +0000",
    "user" : {
      "name" : "Noir Nation",
      "screen_name" : "NoirNation",
      "protected" : false,
      "id_str" : "251318767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513817359081947136\/mMP1JJy1_normal.jpeg",
      "id" : 251318767,
      "verified" : false
    }
  },
  "id" : 234664957596282880,
  "created_at" : "2012-08-12 14:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "staugustinebeach",
      "indices" : [ 35, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/26ZMhFbb",
      "expanded_url" : "http:\/\/instagr.am\/p\/ONZwv6OuFk\/",
      "display_url" : "instagr.am\/p\/ONZwv6OuFk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "234462140843581441",
  "text" : "RT @CaroleODell: Room with a view. #staugustinebeach  http:\/\/t.co\/26ZMhFbb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "staugustinebeach",
        "indices" : [ 18, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/26ZMhFbb",
        "expanded_url" : "http:\/\/instagr.am\/p\/ONZwv6OuFk\/",
        "display_url" : "instagr.am\/p\/ONZwv6OuFk\/"
      } ]
    },
    "geo" : { },
    "id_str" : "234459809745883136",
    "text" : "Room with a view. #staugustinebeach  http:\/\/t.co\/26ZMhFbb",
    "id" : 234459809745883136,
    "created_at" : "2012-08-12 01:22:29 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 234462140843581441,
  "created_at" : "2012-08-12 01:31:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sunset",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "orlando",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/LAphe76G",
      "expanded_url" : "http:\/\/instagr.am\/p\/ONYyvjOuEp\/",
      "display_url" : "instagr.am\/p\/ONYyvjOuEp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "234458147312513024",
  "text" : "RT @CaroleODell: #sunset #orlando  http:\/\/t.co\/LAphe76G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sunset",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "orlando",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/LAphe76G",
        "expanded_url" : "http:\/\/instagr.am\/p\/ONYyvjOuEp\/",
        "display_url" : "instagr.am\/p\/ONYyvjOuEp\/"
      } ]
    },
    "geo" : { },
    "id_str" : "234457583996522496",
    "text" : "#sunset #orlando  http:\/\/t.co\/LAphe76G",
    "id" : 234457583996522496,
    "created_at" : "2012-08-12 01:13:38 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 234458147312513024,
  "created_at" : "2012-08-12 01:15:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234455271861276673",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny you are far too intelligent and loving to be catering to the whims of such people ((hugs))",
  "id" : 234455271861276673,
  "created_at" : "2012-08-12 01:04:27 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234359654124249088",
  "text" : "RT @AniKnits: In fact, the local friend who came to court with me was introduced to my blog by a twitter friend. So, who says you guys c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234358980296704000",
    "text" : "In fact, the local friend who came to court with me was introduced to my blog by a twitter friend. So, who says you guys can't help!",
    "id" : 234358980296704000,
    "created_at" : "2012-08-11 18:41:49 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 234359654124249088,
  "created_at" : "2012-08-11 18:44:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherlock ",
      "screen_name" : "Tripster_",
      "indices" : [ 3, 13 ],
      "id_str" : "747382766",
      "id" : 747382766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234354929811218432",
  "text" : "RT @Tripster_: I moved up to having ten followers - if this keeps up my ego will get too big for the planet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234354274396684288",
    "text" : "I moved up to having ten followers - if this keeps up my ego will get too big for the planet",
    "id" : 234354274396684288,
    "created_at" : "2012-08-11 18:23:07 +0000",
    "user" : {
      "name" : "Sherlock ",
      "screen_name" : "Tripster_",
      "protected" : false,
      "id_str" : "747382766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2485672747\/az50b6ecipierf0r2pvo_normal.gif",
      "id" : 747382766,
      "verified" : false
    }
  },
  "id" : 234354929811218432,
  "created_at" : "2012-08-11 18:25:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234289601353760768",
  "text" : "coffee did not please me.. bleh.",
  "id" : 234289601353760768,
  "created_at" : "2012-08-11 14:06:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234084080059301889",
  "text" : "this has been the summer from hell for poor hubby : ( if I didn't know better, I'd say he really pissed off someone upstairs o-O",
  "id" : 234084080059301889,
  "created_at" : "2012-08-11 00:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringNickHome",
      "indices" : [ 114, 128 ]
    }, {
      "text" : "unschool",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/ovR7ssaR",
      "expanded_url" : "http:\/\/thesimpleboxcar.com\/2012\/06\/bringn",
      "display_url" : "thesimpleboxcar.com\/2012\/06\/bringn"
    } ]
  },
  "geo" : { },
  "id_str" : "234063149794484224",
  "text" : "RT @AniKnits: This could happen to any family that goes against the mainstream: http:\/\/t.co\/ovR7ssaR\u2026 Please help #BringNickHome #unschool",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 100, 114 ]
      }, {
        "text" : "unschool",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/ovR7ssaR",
        "expanded_url" : "http:\/\/thesimpleboxcar.com\/2012\/06\/bringn",
        "display_url" : "thesimpleboxcar.com\/2012\/06\/bringn"
      } ]
    },
    "geo" : { },
    "id_str" : "234060916616998912",
    "text" : "This could happen to any family that goes against the mainstream: http:\/\/t.co\/ovR7ssaR\u2026 Please help #BringNickHome #unschool",
    "id" : 234060916616998912,
    "created_at" : "2012-08-10 22:57:25 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 234063149794484224,
  "created_at" : "2012-08-10 23:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/h87GzFZD",
      "expanded_url" : "http:\/\/www.cnn.com\/2012\/08\/10\/us\/mississippi-juvenile-justice\/index.html",
      "display_url" : "cnn.com\/2012\/08\/10\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "234025996116951040",
  "text" : "Feds: Mississippi county runs 'school-to-prison pipeline' http:\/\/t.co\/h87GzFZD #cnn",
  "id" : 234025996116951040,
  "created_at" : "2012-08-10 20:38:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Levy",
      "screen_name" : "MarianneLevy",
      "indices" : [ 3, 16 ],
      "id_str" : "67263530",
      "id" : 67263530
    }, {
      "name" : "Ben Cameron",
      "screen_name" : "ben_cameron",
      "indices" : [ 47, 59 ],
      "id_str" : "19707526",
      "id" : 19707526
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ben_cameron\/status\/233792971236069376\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/3I36Q7TR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az6Zd_nCUAAPrFt.jpg",
      "id_str" : "233792971240263680",
      "id" : 233792971240263680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az6Zd_nCUAAPrFt.jpg",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3I36Q7TR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233992966203658241",
  "text" : "RT @MarianneLevy: Oh GOD. *weeps and weeps* RT @ben_cameron: This seems to be breaking people's hearts.. http:\/\/t.co\/3I36Q7TR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Cameron",
        "screen_name" : "ben_cameron",
        "indices" : [ 29, 41 ],
        "id_str" : "19707526",
        "id" : 19707526
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ben_cameron\/status\/233792971236069376\/photo\/1",
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/3I36Q7TR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Az6Zd_nCUAAPrFt.jpg",
        "id_str" : "233792971240263680",
        "id" : 233792971240263680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az6Zd_nCUAAPrFt.jpg",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3I36Q7TR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233973684413550592",
    "text" : "Oh GOD. *weeps and weeps* RT @ben_cameron: This seems to be breaking people's hearts.. http:\/\/t.co\/3I36Q7TR",
    "id" : 233973684413550592,
    "created_at" : "2012-08-10 17:10:48 +0000",
    "user" : {
      "name" : "Marianne Levy",
      "screen_name" : "MarianneLevy",
      "protected" : false,
      "id_str" : "67263530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788297284068974592\/euZP7HIw_normal.jpg",
      "id" : 67263530,
      "verified" : false
    }
  },
  "id" : 233992966203658241,
  "created_at" : "2012-08-10 18:27:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233982978366246912",
  "text" : "RT @Jamiastar: Friend's 44 yo bil just died--hospital turned him away because he didn't have INSURANCE! Criminal, or should be. #singlep ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 113, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233982194811551744",
    "text" : "Friend's 44 yo bil just died--hospital turned him away because he didn't have INSURANCE! Criminal, or should be. #singlepayer for all! NOW!",
    "id" : 233982194811551744,
    "created_at" : "2012-08-10 17:44:37 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 233982978366246912,
  "created_at" : "2012-08-10 17:47:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EasyDigitalDownloads",
      "screen_name" : "eddwp",
      "indices" : [ 3, 9 ],
      "id_str" : "592277187",
      "id" : 592277187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233982841497726976",
  "text" : "RT @eddwp: If anyone is interested in assisting me with writing documentation for Easy Digital Downloads, just let me know! It's paid.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233982428170047488",
    "text" : "If anyone is interested in assisting me with writing documentation for Easy Digital Downloads, just let me know! It's paid.",
    "id" : 233982428170047488,
    "created_at" : "2012-08-10 17:45:32 +0000",
    "user" : {
      "name" : "EasyDigitalDownloads",
      "screen_name" : "eddwp",
      "protected" : false,
      "id_str" : "592277187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578989572752744448\/Wxzw1QUE_normal.png",
      "id" : 592277187,
      "verified" : false
    }
  },
  "id" : 233982841497726976,
  "created_at" : "2012-08-10 17:47:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "indices" : [ 3, 16 ],
      "id_str" : "36200541",
      "id" : 36200541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233980649910980608",
  "text" : "RT @SisterSorcha: Mystically Yours Metaphysical Home Parties\n\nBecoming an Mystically Yours Representative is an exciting way to (cont) h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/ThLLsj6r",
        "expanded_url" : "http:\/\/tl.gd\/ip81c5",
        "display_url" : "tl.gd\/ip81c5"
      } ]
    },
    "geo" : { },
    "id_str" : "233975251040604160",
    "text" : "Mystically Yours Metaphysical Home Parties\n\nBecoming an Mystically Yours Representative is an exciting way to (cont) http:\/\/t.co\/ThLLsj6r",
    "id" : 233975251040604160,
    "created_at" : "2012-08-10 17:17:01 +0000",
    "user" : {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "protected" : false,
      "id_str" : "36200541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791356505366863872\/Cf1sRt7f_normal.jpg",
      "id" : 36200541,
      "verified" : false
    }
  },
  "id" : 233980649910980608,
  "created_at" : "2012-08-10 17:38:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nuts.com",
      "screen_name" : "nuts",
      "indices" : [ 123, 128 ],
      "id_str" : "93506817",
      "id" : 93506817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/PMvQeC1e",
      "expanded_url" : "http:\/\/Nuts.com",
      "display_url" : "Nuts.com"
    }, {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/YrS0dftG",
      "expanded_url" : "http:\/\/nuts.com\/gifts\/nutsforbirds\/lovely-litas.html",
      "display_url" : "nuts.com\/gifts\/nutsforb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233973957433389056",
  "text" : "Nuts for Lovely Lita's Sheltering Tree Foundation \u2014 Nuts for Birds \u2014 Gifts \u2014 http:\/\/t.co\/PMvQeC1e http:\/\/t.co\/YrS0dftG via @nuts",
  "id" : 233973957433389056,
  "created_at" : "2012-08-10 17:11:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/wxLYFVUZ",
      "expanded_url" : "http:\/\/j.mp\/MjB6qw",
      "display_url" : "j.mp\/MjB6qw"
    } ]
  },
  "geo" : { },
  "id_str" : "233958990265061376",
  "text" : "footprints in the sand, part 1 http:\/\/t.co\/wxLYFVUZ",
  "id" : 233958990265061376,
  "created_at" : "2012-08-10 16:12:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233914941076291584",
  "geo" : { },
  "id_str" : "233917899092393985",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses me, either. asked hubby (ive nudged him) .. says he hasnt seen anything (but i dont think hes opened the app for awhile)",
  "id" : 233917899092393985,
  "in_reply_to_status_id" : 233914941076291584,
  "created_at" : "2012-08-10 13:29:07 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherlock ",
      "screen_name" : "Tripster_",
      "indices" : [ 0, 10 ],
      "id_str" : "747382766",
      "id" : 747382766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233915547916595200",
  "geo" : { },
  "id_str" : "233916917151301632",
  "in_reply_to_user_id" : 747382766,
  "text" : "@Tripster_ same old, same old..lol",
  "id" : 233916917151301632,
  "in_reply_to_status_id" : 233915547916595200,
  "created_at" : "2012-08-10 13:25:13 +0000",
  "in_reply_to_screen_name" : "Tripster_",
  "in_reply_to_user_id_str" : "747382766",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherlock ",
      "screen_name" : "Tripster_",
      "indices" : [ 0, 10 ],
      "id_str" : "747382766",
      "id" : 747382766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233643594047705088",
  "geo" : { },
  "id_str" : "233654117703225344",
  "in_reply_to_user_id" : 747382766,
  "text" : "@Tripster_ yay! welcome back! : )",
  "id" : 233654117703225344,
  "in_reply_to_status_id" : 233643594047705088,
  "created_at" : "2012-08-09 20:00:57 +0000",
  "in_reply_to_screen_name" : "Tripster_",
  "in_reply_to_user_id_str" : "747382766",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 3, 12 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LivradaGifts",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/WltTXY2K",
      "expanded_url" : "http:\/\/ow.ly\/i\/PNlj",
      "display_url" : "ow.ly\/i\/PNlj"
    } ]
  },
  "geo" : { },
  "id_str" : "233602602846285824",
  "text" : "RT @iLivrada: Bookworm? Join our reading\/book chat today at 2pm ET! Tweet #LivradaGifts to join + win a Kindle! http:\/\/t.co\/WltTXY2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LivradaGifts",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/WltTXY2K",
        "expanded_url" : "http:\/\/ow.ly\/i\/PNlj",
        "display_url" : "ow.ly\/i\/PNlj"
      } ]
    },
    "geo" : { },
    "id_str" : "233544627930669056",
    "text" : "Bookworm? Join our reading\/book chat today at 2pm ET! Tweet #LivradaGifts to join + win a Kindle! http:\/\/t.co\/WltTXY2K",
    "id" : 233544627930669056,
    "created_at" : "2012-08-09 12:45:53 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 233602602846285824,
  "created_at" : "2012-08-09 16:36:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 73, 86 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/MoYEulbP",
      "expanded_url" : "http:\/\/bookwi.se\/newly-married\/",
      "display_url" : "bookwi.se\/newly-married\/"
    } ]
  },
  "geo" : { },
  "id_str" : "233602326789750784",
  "text" : "Need Book Suggestions for Newly Married Couples http:\/\/t.co\/MoYEulbP via @adamrshields",
  "id" : 233602326789750784,
  "created_at" : "2012-08-09 16:35:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "drawsomething",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233601058323197953",
  "text" : "#kindlefire needs notification for #drawsomething app. im getting screen burn from leaving it open. o-O",
  "id" : 233601058323197953,
  "created_at" : "2012-08-09 16:30:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233298195428544513",
  "text" : "RT @worldtreeman: 'ladies and gentleman.....let us have an orderly exit from the matrix!'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233296884943441920",
    "text" : "'ladies and gentleman.....let us have an orderly exit from the matrix!'",
    "id" : 233296884943441920,
    "created_at" : "2012-08-08 20:21:26 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 233298195428544513,
  "created_at" : "2012-08-08 20:26:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233298166714359809",
  "text" : "RT @ShipsofSong: Perception is a choice. Your focus creates.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233296901708054528",
    "text" : "Perception is a choice. Your focus creates.",
    "id" : 233296901708054528,
    "created_at" : "2012-08-08 20:21:30 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 233298166714359809,
  "created_at" : "2012-08-08 20:26:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 2, 11 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233288081216790529",
  "geo" : { },
  "id_str" : "233297368370515968",
  "in_reply_to_user_id" : 215045056,
  "text" : ". @Pandeism yes, all of life.. is just degrees...",
  "id" : 233297368370515968,
  "in_reply_to_status_id" : 233288081216790529,
  "created_at" : "2012-08-08 20:23:21 +0000",
  "in_reply_to_screen_name" : "Pandeism",
  "in_reply_to_user_id_str" : "215045056",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/qaSRxnZ7",
      "expanded_url" : "http:\/\/fdl.me\/OUXaah",
      "display_url" : "fdl.me\/OUXaah"
    } ]
  },
  "geo" : { },
  "id_str" : "233296114785329153",
  "text" : "RT @Jamiastar: Facebook won't let you see ads about marijuana reform - sign our petition protesting this censorship http:\/\/t.co\/qaSRxnZ7 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Just Say Now",
        "screen_name" : "JustSayNow",
        "indices" : [ 126, 137 ],
        "id_str" : "166285648",
        "id" : 166285648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/qaSRxnZ7",
        "expanded_url" : "http:\/\/fdl.me\/OUXaah",
        "display_url" : "fdl.me\/OUXaah"
      } ]
    },
    "geo" : { },
    "id_str" : "233295779450728449",
    "text" : "Facebook won't let you see ads about marijuana reform - sign our petition protesting this censorship http:\/\/t.co\/qaSRxnZ7 via @JustSayNow",
    "id" : 233295779450728449,
    "created_at" : "2012-08-08 20:17:02 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 233296114785329153,
  "created_at" : "2012-08-08 20:18:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/IycX8VPe",
      "expanded_url" : "http:\/\/storybundle.com\/",
      "display_url" : "storybundle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "233248977020125185",
  "text" : "The Big Bang Bundle - StoryBundle http:\/\/t.co\/IycX8VPe",
  "id" : 233248977020125185,
  "created_at" : "2012-08-08 17:11:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/QYt070sC",
      "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2012\/08\/02\/mother-gets-50-hours-punishment-over-daughters-chalk-drawings\/#.UCKQ2Ectz9E.twitter",
      "display_url" : "rawstory.com\/rs\/2012\/08\/02\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233235233015738368",
  "text" : "Mother gets 50 hours punishment over daughter\u2019s chalk drawings | The Raw Story http:\/\/t.co\/QYt070sC",
  "id" : 233235233015738368,
  "created_at" : "2012-08-08 16:16:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233230924282724352",
  "text" : "my arm still hurts and this peach sucks...",
  "id" : 233230924282724352,
  "created_at" : "2012-08-08 15:59:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FreeAppADay",
      "screen_name" : "freeappaday",
      "indices" : [ 3, 15 ],
      "id_str" : "98252225",
      "id" : 98252225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233227461989646338",
  "text" : "RT @freeappaday: 100,000 Fb fans reached! RT for a chance to WIN 1 iPad,1 iPod Touch or 5 promo codes for your favorite app winners anno ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233226240553791488",
    "text" : "100,000 Fb fans reached! RT for a chance to WIN 1 iPad,1 iPod Touch or 5 promo codes for your favorite app winners announced Monday 6pm PST!",
    "id" : 233226240553791488,
    "created_at" : "2012-08-08 15:40:43 +0000",
    "user" : {
      "name" : "FreeAppADay",
      "screen_name" : "freeappaday",
      "protected" : false,
      "id_str" : "98252225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560963473497022466\/9lP-AliF_normal.png",
      "id" : 98252225,
      "verified" : true
    }
  },
  "id" : 233227461989646338,
  "created_at" : "2012-08-08 15:45:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 30, 40 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/P2rfEsVC",
      "expanded_url" : "http:\/\/wp.me\/szgRU-tang",
      "display_url" : "wp.me\/szgRU-tang"
    } ]
  },
  "geo" : { },
  "id_str" : "232971625631465472",
  "text" : "Tang http:\/\/t.co\/P2rfEsVC via @ZachsMind",
  "id" : 232971625631465472,
  "created_at" : "2012-08-07 22:48:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232867974015504384",
  "geo" : { },
  "id_str" : "232930256384823296",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses you know about the free lorax color pack for DS then...",
  "id" : 232930256384823296,
  "in_reply_to_status_id" : 232867974015504384,
  "created_at" : "2012-08-07 20:04:35 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Jordan Harris",
      "screen_name" : "ScottFilmCritic",
      "indices" : [ 3, 19 ],
      "id_str" : "93479887",
      "id" : 93479887
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ScottFilmCritic\/status\/232763289585733632\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/bltNnC3Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Azrw-ojCUAA7pPD.jpg",
      "id_str" : "232763289589927936",
      "id" : 232763289589927936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Azrw-ojCUAA7pPD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 267
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 267
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 267
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 267
      } ],
      "display_url" : "pic.twitter.com\/bltNnC3Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232921142384549889",
  "text" : "RT @ScottFilmCritic: I love this. A mother objects to the Google Doodle. http:\/\/t.co\/bltNnC3Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScottFilmCritic\/status\/232763289585733632\/photo\/1",
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/bltNnC3Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Azrw-ojCUAA7pPD.jpg",
        "id_str" : "232763289589927936",
        "id" : 232763289589927936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Azrw-ojCUAA7pPD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 267
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 267
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 267
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 267
        } ],
        "display_url" : "pic.twitter.com\/bltNnC3Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232763289585733632",
    "text" : "I love this. A mother objects to the Google Doodle. http:\/\/t.co\/bltNnC3Y",
    "id" : 232763289585733632,
    "created_at" : "2012-08-07 09:01:08 +0000",
    "user" : {
      "name" : "Scott Jordan Harris",
      "screen_name" : "ScottFilmCritic",
      "protected" : false,
      "id_str" : "93479887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686991768269750272\/nsgndqBC_normal.jpg",
      "id" : 93479887,
      "verified" : false
    }
  },
  "id" : 232921142384549889,
  "created_at" : "2012-08-07 19:28:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/559Xz9nq",
      "expanded_url" : "http:\/\/blog.showmenaturephotography.com\/10294\/blog\/fun-friday-you-tourists-are-boring-me\/#.UCD_EiX0AM8.twitter",
      "display_url" : "blog.showmenaturephotography.com\/10294\/blog\/fun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232804273312919552",
  "text" : "Fun Friday: \u201CYou Tourists are Boring Me!\u201D  http:\/\/t.co\/559Xz9nq",
  "id" : 232804273312919552,
  "created_at" : "2012-08-07 11:43:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232648653888704512",
  "geo" : { },
  "id_str" : "232649874066268161",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell i'm good. been busy playing w my websites so i've been quiet on twitter..lol",
  "id" : 232649874066268161,
  "in_reply_to_status_id" : 232648653888704512,
  "created_at" : "2012-08-07 01:30:27 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DrawSomething",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232648282856378368",
  "text" : "FYI: free Lorax color pack in the shop if you play #DrawSomething! (limited time offer)",
  "id" : 232648282856378368,
  "created_at" : "2012-08-07 01:24:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 74, 78 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/iXID8FGR",
      "expanded_url" : "http:\/\/amanpour.blogs.cnn.com\/2012\/08\/05\/11-year-old-girl-married-to-40-year-old-man\/",
      "display_url" : "amanpour.blogs.cnn.com\/2012\/08\/05\/11-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232544980827267072",
  "text" : "11-year-old girl married to 40-year-old man http:\/\/t.co\/iXID8FGR #cnn via @CNN",
  "id" : 232544980827267072,
  "created_at" : "2012-08-06 18:33:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232270440737955840",
  "text" : "RT @By_Bashar: There is nothing more satisfying then SNAPPING into the puzzle piece that you are ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232268863901929472",
    "text" : "There is nothing more satisfying then SNAPPING into the puzzle piece that you are ~ bashar",
    "id" : 232268863901929472,
    "created_at" : "2012-08-06 00:16:27 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 232270440737955840,
  "created_at" : "2012-08-06 00:22:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232267357945491456",
  "text" : "@SocialistXian yeah, he is a rather likable fellow, isn't he? : )",
  "id" : 232267357945491456,
  "created_at" : "2012-08-06 00:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "A. Sims",
      "screen_name" : "gundersmoot",
      "indices" : [ 84, 96 ],
      "id_str" : "45168246",
      "id" : 45168246
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 97, 110 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232130740987514880",
  "geo" : { },
  "id_str" : "232259983662784512",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia ive gotten more out of conversing on twitter than any therapy... ; ) @gundersmoot @SisterSadist",
  "id" : 232259983662784512,
  "in_reply_to_status_id" : 232130740987514880,
  "created_at" : "2012-08-05 23:41:09 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232259448075337728",
  "text" : "RT @By_Bashar: All events are neutral in that you apply the meaning - And then experience the result of that ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232253775744753664",
    "text" : "All events are neutral in that you apply the meaning - And then experience the result of that ~ bashar",
    "id" : 232253775744753664,
    "created_at" : "2012-08-05 23:16:29 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 232259448075337728,
  "created_at" : "2012-08-05 23:39:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232259150590136320",
  "text" : "RT @ZachsMind: we like to separate ourselves from them @SimmiPow but we can't. Every human being is equally capable of being like an ang ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232256765251698688",
    "text" : "we like to separate ourselves from them @SimmiPow but we can't. Every human being is equally capable of being like an angel or a monster.",
    "id" : 232256765251698688,
    "created_at" : "2012-08-05 23:28:22 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 232259150590136320,
  "created_at" : "2012-08-05 23:37:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.slices.me\" rel=\"nofollow\"\u003ESlices for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britni Vigil",
      "screen_name" : "BookNookClub",
      "indices" : [ 3, 16 ],
      "id_str" : "393733027",
      "id" : 393733027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231580125609721856",
  "text" : "RT @BookNookClub: I need to learn how to listen better, especially to the things that are unsaid.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231576028043153408",
    "text" : "I need to learn how to listen better, especially to the things that are unsaid.",
    "id" : 231576028043153408,
    "created_at" : "2012-08-04 02:23:22 +0000",
    "user" : {
      "name" : "Britni Vigil",
      "screen_name" : "BookNookClub",
      "protected" : false,
      "id_str" : "393733027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1595412121\/Profile_Pic_normal.jpg",
      "id" : 393733027,
      "verified" : false
    }
  },
  "id" : 231580125609721856,
  "created_at" : "2012-08-04 02:39:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/ypAtuLYh",
      "expanded_url" : "http:\/\/unicornbooty.com\/blog\/2012\/08\/03\/gay-man-banned-from-hospital-for-kissing-partner-goodbye\/",
      "display_url" : "unicornbooty.com\/blog\/2012\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231430796253200384",
  "text" : "Gay Man Banned from Hospital for Kissing Partner Goodbye http:\/\/t.co\/ypAtuLYh",
  "id" : 231430796253200384,
  "created_at" : "2012-08-03 16:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 71, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/94MC12yl",
      "expanded_url" : "http:\/\/bit.ly\/Qv9UEX",
      "display_url" : "bit.ly\/Qv9UEX"
    } ]
  },
  "geo" : { },
  "id_str" : "231422789884719105",
  "text" : "RT @aliceinthewater: Your daily AWWW: Speechless!\nhttp:\/\/t.co\/94MC12yl #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 50, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/94MC12yl",
        "expanded_url" : "http:\/\/bit.ly\/Qv9UEX",
        "display_url" : "bit.ly\/Qv9UEX"
      } ]
    },
    "geo" : { },
    "id_str" : "231420979216257026",
    "text" : "Your daily AWWW: Speechless!\nhttp:\/\/t.co\/94MC12yl #lam",
    "id" : 231420979216257026,
    "created_at" : "2012-08-03 16:07:15 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 231422789884719105,
  "created_at" : "2012-08-03 16:14:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/I2DXDp0b",
      "expanded_url" : "http:\/\/bit.ly\/RhTYbk",
      "display_url" : "bit.ly\/RhTYbk"
    } ]
  },
  "geo" : { },
  "id_str" : "231420749179666433",
  "text" : "Living alongside foxes (&amp; badgers) http:\/\/t.co\/I2DXDp0b",
  "id" : 231420749179666433,
  "created_at" : "2012-08-03 16:06:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/pC2eiHSR",
      "expanded_url" : "http:\/\/appadvice.com\/appnn\/2012\/08\/learn-to-code-killer-iphone-apps-right-from-your-browser-with-code-school-kickstarter-project",
      "display_url" : "appadvice.com\/appnn\/2012\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231415208801861633",
  "text" : "Learn To Code Killer iPhone Apps Right From Your Browser With Code School Kickstarter Project -- AppAdvice http:\/\/t.co\/pC2eiHSR",
  "id" : 231415208801861633,
  "created_at" : "2012-08-03 15:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231414291381768192",
  "text" : "after working w Bahng Mahng Ee at TKD wed, thu my already sore arm is painful... : (",
  "id" : 231414291381768192,
  "created_at" : "2012-08-03 15:40:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/AF67Olcb",
      "expanded_url" : "http:\/\/appadvice.com\/appnn\/2012\/08\/appfresh-daily-slices-for-twitter-my-disney-experience-swirl-running-dead-and-more",
      "display_url" : "appadvice.com\/appnn\/2012\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231413650982858754",
  "in_reply_to_user_id" : 63804234,
  "text" : "@peggysuecusses FYI: free today My Disney Experience iphone app http:\/\/t.co\/AF67Olcb",
  "id" : 231413650982858754,
  "created_at" : "2012-08-03 15:38:08 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 43, 53 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/FgA3EP9y",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-7V",
      "display_url" : "wp.me\/pzgRU-7V"
    } ]
  },
  "geo" : { },
  "id_str" : "231355667557007361",
  "text" : "Silencing Freedom http:\/\/t.co\/FgA3EP9y via @ZachsMind",
  "id" : 231355667557007361,
  "created_at" : "2012-08-03 11:47:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231041775538688002",
  "geo" : { },
  "id_str" : "231044630890827777",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench yay! got it.. and played my turn. woohoo!",
  "id" : 231044630890827777,
  "in_reply_to_status_id" : 231041775538688002,
  "created_at" : "2012-08-02 15:11:47 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giveaway of the Day",
      "screen_name" : "GiveawayotDay",
      "indices" : [ 3, 17 ],
      "id_str" : "29657655",
      "id" : 29657655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231044083433500672",
  "text" : "RT @GiveawayotDay: Free software #giveaway daily! Cleanse Uninstaller Pro will find and remove even the most stubborn software! http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaway",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/rEOiMPCl",
        "expanded_url" : "http:\/\/ow.ly\/cGce9",
        "display_url" : "ow.ly\/cGce9"
      } ]
    },
    "geo" : { },
    "id_str" : "230923065847083008",
    "text" : "Free software #giveaway daily! Cleanse Uninstaller Pro will find and remove even the most stubborn software! http:\/\/t.co\/rEOiMPCl",
    "id" : 230923065847083008,
    "created_at" : "2012-08-02 07:08:43 +0000",
    "user" : {
      "name" : "Giveaway of the Day",
      "screen_name" : "GiveawayotDay",
      "protected" : false,
      "id_str" : "29657655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3116787403\/f0cb617cd3e46723c3c6766e18956df2_normal.jpeg",
      "id" : 29657655,
      "verified" : false
    }
  },
  "id" : 231044083433500672,
  "created_at" : "2012-08-02 15:09:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231030135099359232",
  "text" : "RT @andrewtshaffer: Heard someone trot out the \"if gays marry, then people will marry horses next.\" We all know what that leads to: cent ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231029896800006145",
    "text" : "Heard someone trot out the \"if gays marry, then people will marry horses next.\" We all know what that leads to: centaurs.",
    "id" : 231029896800006145,
    "created_at" : "2012-08-02 14:13:14 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 231030135099359232,
  "created_at" : "2012-08-02 14:14:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231023068359843840",
  "geo" : { },
  "id_str" : "231027794388340736",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench ok.. i was able 2 delete game. i tried 2 create game w you but it says yr \"not accepting games w me right now, try later\"",
  "id" : 231027794388340736,
  "in_reply_to_status_id" : 231023068359843840,
  "created_at" : "2012-08-02 14:04:53 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231023856297578496",
  "text" : "RT @bend_time: if we are running short of money, dear pentagon, dear joint chiefs, lets quit fighting stupid wars (&amp; all war is stup ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "concept",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231018582132285440",
    "text" : "if we are running short of money, dear pentagon, dear joint chiefs, lets quit fighting stupid wars (&amp; all war is stupid). #concept",
    "id" : 231018582132285440,
    "created_at" : "2012-08-02 13:28:16 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 231023856297578496,
  "created_at" : "2012-08-02 13:49:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 3, 12 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/BBBYyCge",
      "expanded_url" : "http:\/\/ow.ly\/cGB0l",
      "display_url" : "ow.ly\/cGB0l"
    } ]
  },
  "geo" : { },
  "id_str" : "231023789197107200",
  "text" : "RT @iLivrada: Only 2 days left to enter! &amp; WIN an e-book gift card to keep + one to give: http:\/\/t.co\/BBBYyCge  #giveaway 6 titles t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaway",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/BBBYyCge",
        "expanded_url" : "http:\/\/ow.ly\/cGB0l",
        "display_url" : "ow.ly\/cGB0l"
      } ]
    },
    "geo" : { },
    "id_str" : "231018767373705216",
    "text" : "Only 2 days left to enter! &amp; WIN an e-book gift card to keep + one to give: http:\/\/t.co\/BBBYyCge  #giveaway 6 titles to choose from.",
    "id" : 231018767373705216,
    "created_at" : "2012-08-02 13:29:00 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 231023789197107200,
  "created_at" : "2012-08-02 13:48:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230856258121498624",
  "geo" : { },
  "id_str" : "231022788272599040",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench i tried but says we R already playing. it scrolled that name to top and says waiting 4 yrr move. wont let me do anything.",
  "id" : 231022788272599040,
  "in_reply_to_status_id" : 230856258121498624,
  "created_at" : "2012-08-02 13:44:59 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 41, 51 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/WsYJWDMp",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-7u",
      "display_url" : "wp.me\/pzgRU-7u"
    } ]
  },
  "geo" : { },
  "id_str" : "230829107208941569",
  "text" : "We Live In Fear http:\/\/t.co\/WsYJWDMp via @ZachsMind",
  "id" : 230829107208941569,
  "created_at" : "2012-08-02 00:55:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230737219810373633",
  "geo" : { },
  "id_str" : "230745655180660738",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench LOL.. i can guarantee mine are worse..hehe. If you ever want to play me.. im abfabgab on there.",
  "id" : 230745655180660738,
  "in_reply_to_status_id" : 230737219810373633,
  "created_at" : "2012-08-01 19:23:45 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drawsomething",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230736883620134912",
  "text" : "anyone out there play #drawsomething? im looking for 1-2 peeps to play against...",
  "id" : 230736883620134912,
  "created_at" : "2012-08-01 18:48:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/def_leppard\/status\/230667517662736384\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/IcNiuLBM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzN-4pvCMAEyjor.jpg",
      "id_str" : "230667517666930689",
      "id" : 230667517666930689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzN-4pvCMAEyjor.jpg",
      "sizes" : [ {
        "h" : 745,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IcNiuLBM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230698313618452480",
  "text" : "RT @def_leppard: Join us in wishing Joe Elliott a happy birthday! http:\/\/t.co\/IcNiuLBM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/def_leppard\/status\/230667517662736384\/photo\/1",
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/IcNiuLBM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AzN-4pvCMAEyjor.jpg",
        "id_str" : "230667517666930689",
        "id" : 230667517666930689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzN-4pvCMAEyjor.jpg",
        "sizes" : [ {
          "h" : 745,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IcNiuLBM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230667517662736384",
    "text" : "Join us in wishing Joe Elliott a happy birthday! http:\/\/t.co\/IcNiuLBM",
    "id" : 230667517662736384,
    "created_at" : "2012-08-01 14:13:17 +0000",
    "user" : {
      "name" : "Def Leppard",
      "screen_name" : "DefLeppard",
      "protected" : false,
      "id_str" : "21584475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1172588486\/logo_normal.gif",
      "id" : 21584475,
      "verified" : true
    }
  },
  "id" : 230698313618452480,
  "created_at" : "2012-08-01 16:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/iz83vI3w",
      "expanded_url" : "http:\/\/appadvice.com\/appnn\/2012\/07\/freedompops-case-transforms-the-ipod-touch-into-wimax-capable-handset",
      "display_url" : "appadvice.com\/appnn\/2012\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230643006838042624",
  "text" : "FreedomPop\u2019s Case Transforms The iPod Touch Into WiMax-Capable Handset -- AppAdvice http:\/\/t.co\/iz83vI3w",
  "id" : 230643006838042624,
  "created_at" : "2012-08-01 12:35:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]