Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/iNmxo600Zo",
      "expanded_url" : "https:\/\/twitter.com\/WanagiKangee\/status\/726577244018204672",
      "display_url" : "twitter.com\/WanagiKangee\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726585447430950912",
  "text" : "RT @AWorldOutOfMind: The Twilight Zone. https:\/\/t.co\/iNmxo600Zo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/iNmxo600Zo",
        "expanded_url" : "https:\/\/twitter.com\/WanagiKangee\/status\/726577244018204672",
        "display_url" : "twitter.com\/WanagiKangee\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726582587603427328",
    "text" : "The Twilight Zone. https:\/\/t.co\/iNmxo600Zo",
    "id" : 726582587603427328,
    "created_at" : "2016-05-01 01:22:42 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 726585447430950912,
  "created_at" : "2016-05-01 01:34:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Tullos",
      "screen_name" : "JTullosCBS19",
      "indices" : [ 3, 16 ],
      "id_str" : "3110698943",
      "id" : 3110698943
    }, {
      "name" : "Cleveland 19 News",
      "screen_name" : "cleveland19news",
      "indices" : [ 106, 122 ],
      "id_str" : "20535297",
      "id" : 20535297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726484092674531328",
  "text" : "RT @JTullosCBS19: This Dove getting Parma police protection after laying her 2 eggs in a cruiser last wk. @cleveland19news https:\/\/t.co\/XOK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cleveland 19 News",
        "screen_name" : "cleveland19news",
        "indices" : [ 88, 104 ],
        "id_str" : "20535297",
        "id" : 20535297
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JTullosCBS19\/status\/725356134270418949\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/XOKqVtNdtA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChD7jyWWIAAEQUY.jpg",
        "id_str" : "725356132236140544",
        "id" : 725356132236140544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChD7jyWWIAAEQUY.jpg",
        "sizes" : [ {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XOKqVtNdtA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725356134270418949",
    "text" : "This Dove getting Parma police protection after laying her 2 eggs in a cruiser last wk. @cleveland19news https:\/\/t.co\/XOKqVtNdtA",
    "id" : 725356134270418949,
    "created_at" : "2016-04-27 16:09:13 +0000",
    "user" : {
      "name" : "Julia Tullos",
      "screen_name" : "JTullosCBS19",
      "protected" : false,
      "id_str" : "3110698943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769719790785196032\/PnUSxHLb_normal.jpg",
      "id" : 3110698943,
      "verified" : false
    }
  },
  "id" : 726484092674531328,
  "created_at" : "2016-04-30 18:51:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726447714171555850",
  "text" : "any recommendations on activity trackers? been looking at striiv smart pedometer, fitbit zip, jawbone up move...",
  "id" : 726447714171555850,
  "created_at" : "2016-04-30 16:26:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/RY4s3L1SGl",
      "expanded_url" : "https:\/\/twitter.com\/CaroleODell\/status\/726424805021470720",
      "display_url" : "twitter.com\/CaroleODell\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726435942102405121",
  "text" : "I could deal with 3327 quite nicely.. (haven't looked at other pics yet.) Love the porch room. https:\/\/t.co\/RY4s3L1SGl",
  "id" : 726435942102405121,
  "created_at" : "2016-04-30 15:39:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2661\u2606Your Star\u2606\u2661",
      "screen_name" : "Estrella51Ahora",
      "indices" : [ 3, 19 ],
      "id_str" : "2575641482",
      "id" : 2575641482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Estrella51Ahora\/status\/726385340022292481\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/TkEOcRrFyz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChSjiTTUcAEH2Rd.jpg",
      "id_str" : "726385249605677057",
      "id" : 726385249605677057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChSjiTTUcAEH2Rd.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 296
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 296
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 296
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 296
      } ],
      "display_url" : "pic.twitter.com\/TkEOcRrFyz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726434947037290496",
  "text" : "RT @Estrella51Ahora: Don't touch!\uD83D\uDE4C He's mine!\uD83D\uDC36\uD83D\uDC95\uD83D\uDE04 https:\/\/t.co\/TkEOcRrFyz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Estrella51Ahora\/status\/726385340022292481\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/TkEOcRrFyz",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChSjiTTUcAEH2Rd.jpg",
        "id_str" : "726385249605677057",
        "id" : 726385249605677057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChSjiTTUcAEH2Rd.jpg",
        "sizes" : [ {
          "h" : 264,
          "resize" : "fit",
          "w" : 296
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 296
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 296
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 296
        } ],
        "display_url" : "pic.twitter.com\/TkEOcRrFyz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726385340022292481",
    "text" : "Don't touch!\uD83D\uDE4C He's mine!\uD83D\uDC36\uD83D\uDC95\uD83D\uDE04 https:\/\/t.co\/TkEOcRrFyz",
    "id" : 726385340022292481,
    "created_at" : "2016-04-30 12:18:55 +0000",
    "user" : {
      "name" : "\u2661\u2606Your Star\u2606\u2661",
      "screen_name" : "Estrella51Ahora",
      "protected" : false,
      "id_str" : "2575641482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528319002985369600\/3qjnD6Ph_normal.jpeg",
      "id" : 2575641482,
      "verified" : false
    }
  },
  "id" : 726434947037290496,
  "created_at" : "2016-04-30 15:36:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aliza_Beth",
      "screen_name" : "elizabeth12487",
      "indices" : [ 3, 18 ],
      "id_str" : "955558916",
      "id" : 955558916
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elizabeth12487\/status\/713854884362235905\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/vXxR1pQTA0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CegfOewWAAAeYQb.jpg",
      "id_str" : "713854874572685312",
      "id" : 713854874572685312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CegfOewWAAAeYQb.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/vXxR1pQTA0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726429302066171906",
  "text" : "RT @elizabeth12487: When dreamers unite.... https:\/\/t.co\/vXxR1pQTA0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elizabeth12487\/status\/713854884362235905\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/vXxR1pQTA0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CegfOewWAAAeYQb.jpg",
        "id_str" : "713854874572685312",
        "id" : 713854874572685312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CegfOewWAAAeYQb.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/vXxR1pQTA0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "713854884362235905",
    "text" : "When dreamers unite.... https:\/\/t.co\/vXxR1pQTA0",
    "id" : 713854884362235905,
    "created_at" : "2016-03-26 22:27:21 +0000",
    "user" : {
      "name" : "Aliza_Beth",
      "screen_name" : "elizabeth12487",
      "protected" : false,
      "id_str" : "955558916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758412384348344320\/hIuNQQ84_normal.jpg",
      "id" : 955558916,
      "verified" : false
    }
  },
  "id" : 726429302066171906,
  "created_at" : "2016-04-30 15:13:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726427826912661505",
  "text" : "the problem is.. ppl are arguing over different concepts of issues so there can be no resolution until that is realized.",
  "id" : 726427826912661505,
  "created_at" : "2016-04-30 15:07:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 105, 114 ]
    }, {
      "text" : "feedly",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/k1JcdzyDNP",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/04\/ken-ham-proves-yet-doesnt-believe-sufficiency-scripture\/",
      "display_url" : "brucegerencser.net\/2016\/04\/ken-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726184913238634496",
  "text" : "Ken Ham Proves Yet Again That He Doesn\u2019t Believe in the Sufficiency of Scripture https:\/\/t.co\/k1JcdzyDNP #religion #feedly",
  "id" : 726184913238634496,
  "created_at" : "2016-04-29 23:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725810411585605634",
  "text" : "excitement here.. red aussie wandered by. found owner quickly tho. a real sweetheart and our aussie liked her! they played.",
  "id" : 725810411585605634,
  "created_at" : "2016-04-28 22:14:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 3, 19 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725782017531584512",
  "text" : "RT @hilltopfarmgirl: Help! We've had a cancellation in June for our Bunkbarn, info on photo, could you all help us out please and share? ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/725767657706938369\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/BTzd75cx5d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJxvrAXEAAczbe.jpg",
        "id_str" : "725767553772097536",
        "id" : 725767553772097536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJxvrAXEAAczbe.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BTzd75cx5d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725767657706938369",
    "text" : "Help! We've had a cancellation in June for our Bunkbarn, info on photo, could you all help us out please and share? https:\/\/t.co\/BTzd75cx5d",
    "id" : 725767657706938369,
    "created_at" : "2016-04-28 19:24:28 +0000",
    "user" : {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "protected" : false,
      "id_str" : "457436503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3491566457\/61244b7682c638ad4b0a097321ae762e_normal.jpeg",
      "id" : 457436503,
      "verified" : false
    }
  },
  "id" : 725782017531584512,
  "created_at" : "2016-04-28 20:21:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cats",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Jp3uq9obmP",
      "expanded_url" : "http:\/\/go.shr.lc\/26xCn3Y",
      "display_url" : "go.shr.lc\/26xCn3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "725728738235813889",
  "text" : "soo cute!! &gt; A Little Spring Bird Watching With Shironeko - https:\/\/t.co\/Jp3uq9obmP #cats",
  "id" : 725728738235813889,
  "created_at" : "2016-04-28 16:49:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 48, 62 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/W5DlxCCq6y",
      "expanded_url" : "http:\/\/johnpavlovitz.com\/2016\/04\/28\/im-boycotting-fear\/",
      "display_url" : "johnpavlovitz.com\/2016\/04\/28\/im-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725697362501472257",
  "text" : "I'm Boycotting Fear https:\/\/t.co\/W5DlxCCq6y via @johnpavlovitz",
  "id" : 725697362501472257,
  "created_at" : "2016-04-28 14:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725471676662689792",
  "geo" : { },
  "id_str" : "725475148644663296",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe she's so beautiful. &lt;3",
  "id" : 725475148644663296,
  "in_reply_to_status_id" : 725471676662689792,
  "created_at" : "2016-04-28 00:02:08 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 3, 15 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/kXEdcmGDGF",
      "expanded_url" : "https:\/\/twitter.com\/elielcruz\/status\/725455533663215616",
      "display_url" : "twitter.com\/elielcruz\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725460199276949504",
  "text" : "RT @Hrothgar777: What the hell?  https:\/\/t.co\/kXEdcmGDGF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/kXEdcmGDGF",
        "expanded_url" : "https:\/\/twitter.com\/elielcruz\/status\/725455533663215616",
        "display_url" : "twitter.com\/elielcruz\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725456283189399552",
    "text" : "What the hell?  https:\/\/t.co\/kXEdcmGDGF",
    "id" : 725456283189399552,
    "created_at" : "2016-04-27 22:47:10 +0000",
    "user" : {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "protected" : false,
      "id_str" : "279783538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716784460700717057\/uqMbDmgI_normal.jpg",
      "id" : 279783538,
      "verified" : false
    }
  },
  "id" : 725460199276949504,
  "created_at" : "2016-04-27 23:02:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0950",
      "screen_name" : "beachippie",
      "indices" : [ 3, 14 ],
      "id_str" : "1140972691",
      "id" : 1140972691
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/beachippie\/status\/725185928206123008\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/4JX1txsAas",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChBgv9tWUAAsJ18.jpg",
      "id_str" : "725185917141536768",
      "id" : 725185917141536768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChBgv9tWUAAsJ18.jpg",
      "sizes" : [ {
        "h" : 635,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4JX1txsAas"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725307492788506624",
  "text" : "RT @beachippie: keep the peace, spread the love &amp; always be kind https:\/\/t.co\/4JX1txsAas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/beachippie\/status\/725185928206123008\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/4JX1txsAas",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChBgv9tWUAAsJ18.jpg",
        "id_str" : "725185917141536768",
        "id" : 725185917141536768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChBgv9tWUAAsJ18.jpg",
        "sizes" : [ {
          "h" : 635,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 635,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4JX1txsAas"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725185928206123008",
    "text" : "keep the peace, spread the love &amp; always be kind https:\/\/t.co\/4JX1txsAas",
    "id" : 725185928206123008,
    "created_at" : "2016-04-27 04:52:53 +0000",
    "user" : {
      "name" : "\u0950",
      "screen_name" : "beachippie",
      "protected" : false,
      "id_str" : "1140972691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777841597870252032\/IizWnotV_normal.jpg",
      "id" : 1140972691,
      "verified" : false
    }
  },
  "id" : 725307492788506624,
  "created_at" : "2016-04-27 12:55:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobooked",
      "screen_name" : "audiobooked",
      "indices" : [ 3, 15 ],
      "id_str" : "2797832461",
      "id" : 2797832461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725146221162168320",
  "text" : "RT @audiobooked: Build 25b (10.0.25b) should be out soon. Expect improvements on now playing\/library\/properties screen and popups.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725145853409681408",
    "text" : "Build 25b (10.0.25b) should be out soon. Expect improvements on now playing\/library\/properties screen and popups.",
    "id" : 725145853409681408,
    "created_at" : "2016-04-27 02:13:38 +0000",
    "user" : {
      "name" : "Audiobooked",
      "screen_name" : "audiobooked",
      "protected" : false,
      "id_str" : "2797832461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549989531525476352\/I9hyTetO_normal.png",
      "id" : 2797832461,
      "verified" : false
    }
  },
  "id" : 725146221162168320,
  "created_at" : "2016-04-27 02:15:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725109616401633281",
  "geo" : { },
  "id_str" : "725122048385794049",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe hello precious ((smooches))",
  "id" : 725122048385794049,
  "in_reply_to_status_id" : 725109616401633281,
  "created_at" : "2016-04-27 00:39:03 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/IAmRH3qTG8",
      "expanded_url" : "http:\/\/www.scarymommy.com\/texas-school-triples-recess-time-and-sees-immediate-positive-results-in-kids\/",
      "display_url" : "scarymommy.com\/texas-school-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725106479519375361",
  "text" : "RT @SpiritualNurse: Texas School Triples Recess Time And Sees Immediate Positive Results In Kids https:\/\/t.co\/IAmRH3qTG8 https:\/\/t.co\/JC8nm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/725106000768946176\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/JC8nm9tKyR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAYEK-WMAAhiD6.jpg",
        "id_str" : "725105999951048704",
        "id" : 725105999951048704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAYEK-WMAAhiD6.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JC8nm9tKyR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/IAmRH3qTG8",
        "expanded_url" : "http:\/\/www.scarymommy.com\/texas-school-triples-recess-time-and-sees-immediate-positive-results-in-kids\/",
        "display_url" : "scarymommy.com\/texas-school-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725106000768946176",
    "text" : "Texas School Triples Recess Time And Sees Immediate Positive Results In Kids https:\/\/t.co\/IAmRH3qTG8 https:\/\/t.co\/JC8nm9tKyR",
    "id" : 725106000768946176,
    "created_at" : "2016-04-26 23:35:17 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 725106479519375361,
  "created_at" : "2016-04-26 23:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merriam-Webster",
      "screen_name" : "MerriamWebster",
      "indices" : [ 3, 18 ],
      "id_str" : "97040343",
      "id" : 97040343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725104808844222464",
  "text" : "RT @MerriamWebster: People keep\n1) saying they don't know what 'genderqueer' means\n\nthen\n\n2) asking why we added it to the dictionary https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MerriamWebster\/status\/724645568014868480\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/wsGZ7Y6XB8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg51TcZW4AEHAEJ.jpg",
        "id_str" : "724645566953742337",
        "id" : 724645566953742337,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg51TcZW4AEHAEJ.jpg",
        "sizes" : [ {
          "h" : 488,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 756
        } ],
        "display_url" : "pic.twitter.com\/wsGZ7Y6XB8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724645568014868480",
    "text" : "People keep\n1) saying they don't know what 'genderqueer' means\n\nthen\n\n2) asking why we added it to the dictionary https:\/\/t.co\/wsGZ7Y6XB8",
    "id" : 724645568014868480,
    "created_at" : "2016-04-25 17:05:41 +0000",
    "user" : {
      "name" : "Merriam-Webster",
      "screen_name" : "MerriamWebster",
      "protected" : false,
      "id_str" : "97040343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677210982616195072\/DWj4oUuT_normal.png",
      "id" : 97040343,
      "verified" : true
    }
  },
  "id" : 725104808844222464,
  "created_at" : "2016-04-26 23:30:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725099708985827328",
  "geo" : { },
  "id_str" : "725104176930406402",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley yes, it does..lol",
  "id" : 725104176930406402,
  "in_reply_to_status_id" : 725099708985827328,
  "created_at" : "2016-04-26 23:28:02 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/725099708985827328\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/xxKQ0hSYAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChASVB-UcAAcHgz.jpg",
      "id_str" : "725099692523024384",
      "id" : 725099692523024384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChASVB-UcAAcHgz.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xxKQ0hSYAD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725104127613784065",
  "text" : "RT @ErinEFarley: A pig planter that looks like a moose with the succulents sticking out of its head. https:\/\/t.co\/xxKQ0hSYAD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/725099708985827328\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/xxKQ0hSYAD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChASVB-UcAAcHgz.jpg",
        "id_str" : "725099692523024384",
        "id" : 725099692523024384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChASVB-UcAAcHgz.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xxKQ0hSYAD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725099708985827328",
    "text" : "A pig planter that looks like a moose with the succulents sticking out of its head. https:\/\/t.co\/xxKQ0hSYAD",
    "id" : 725099708985827328,
    "created_at" : "2016-04-26 23:10:16 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 725104127613784065,
  "created_at" : "2016-04-26 23:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 107, 116 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725060051459817473",
  "text" : "RT @Interior: Meet Sparky, the tough bison that survived a lightning strike \u26A1\uFE0F\n\nFollow him on \"usinterior\" @snapchat today! https:\/\/t.co\/MS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 93, 102 ],
        "id_str" : "376502929",
        "id" : 376502929
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/725052485447094272\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/MSWWzVNhzE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg_nYtKWIAM8CQL.jpg",
        "id_str" : "725052476655804419",
        "id" : 725052476655804419,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg_nYtKWIAM8CQL.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/MSWWzVNhzE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725052485447094272",
    "text" : "Meet Sparky, the tough bison that survived a lightning strike \u26A1\uFE0F\n\nFollow him on \"usinterior\" @snapchat today! https:\/\/t.co\/MSWWzVNhzE",
    "id" : 725052485447094272,
    "created_at" : "2016-04-26 20:02:38 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 725060051459817473,
  "created_at" : "2016-04-26 20:32:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/UYN5QZNwf6",
      "expanded_url" : "http:\/\/www.theatlantic.com\/science\/archive\/2016\/04\/the-illusion-of-reality\/479559\/",
      "display_url" : "theatlantic.com\/science\/archiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725010504922595332",
  "text" : "The case against reality https:\/\/t.co\/UYN5QZNwf6",
  "id" : 725010504922595332,
  "created_at" : "2016-04-26 17:15:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/724959982312108032\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/kqLupK8eVh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-TQxeW4AECOw1.jpg",
      "id_str" : "724959981397794817",
      "id" : 724959981397794817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-TQxeW4AECOw1.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/kqLupK8eVh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724959982312108032",
  "text" : "me and my gal listening to \"Going Bovine\" audiobook last night https:\/\/t.co\/kqLupK8eVh",
  "id" : 724959982312108032,
  "created_at" : "2016-04-26 13:55:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724956006275506176",
  "text" : "RT @Interior: Who\u2019s ready for a party? This stink\u2019n cute skunk family at Necedah Wildlife Refuge in Wisconsin by Ariel Lepito https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Psjl0pmYjZ",
        "expanded_url" : "https:\/\/vine.co\/v\/eJTTYeTAjav",
        "display_url" : "vine.co\/v\/eJTTYeTAjav"
      } ]
    },
    "geo" : { },
    "id_str" : "724744082027872256",
    "text" : "Who\u2019s ready for a party? This stink\u2019n cute skunk family at Necedah Wildlife Refuge in Wisconsin by Ariel Lepito https:\/\/t.co\/Psjl0pmYjZ",
    "id" : 724744082027872256,
    "created_at" : "2016-04-25 23:37:08 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 724956006275506176,
  "created_at" : "2016-04-26 13:39:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724758754877693952",
  "text" : "RT @SouthYeoEast: Meg loves nothing better than mothering lambs. This one got left behind this morning as the ewes went out https:\/\/t.co\/Ir\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/724331385490661378\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/Ir3oiK2TOu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg1XgBPW4AIyAg6.jpg",
        "id_str" : "724331322676797442",
        "id" : 724331322676797442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg1XgBPW4AIyAg6.jpg",
        "sizes" : [ {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Ir3oiK2TOu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/724331385490661378\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/Ir3oiK2TOu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg1XjkjW4AAz2He.jpg",
        "id_str" : "724331383695532032",
        "id" : 724331383695532032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg1XjkjW4AAz2He.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 885,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 694
        } ],
        "display_url" : "pic.twitter.com\/Ir3oiK2TOu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724331385490661378",
    "text" : "Meg loves nothing better than mothering lambs. This one got left behind this morning as the ewes went out https:\/\/t.co\/Ir3oiK2TOu",
    "id" : 724331385490661378,
    "created_at" : "2016-04-24 20:17:14 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 724758754877693952,
  "created_at" : "2016-04-26 00:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adequately Adan",
      "screen_name" : "manicsocratic",
      "indices" : [ 3, 17 ],
      "id_str" : "16496165",
      "id" : 16496165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JnlnmkxqAQ",
      "expanded_url" : "https:\/\/twitter.com\/OrlandoWeekly\/status\/724666853205913600",
      "display_url" : "twitter.com\/OrlandoWeekly\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724737217504092161",
  "text" : "RT @manicsocratic: Yes. That trans-led brutal bathroom crime wave that's been plaguing our nation for decades.  https:\/\/t.co\/JnlnmkxqAQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/JnlnmkxqAQ",
        "expanded_url" : "https:\/\/twitter.com\/OrlandoWeekly\/status\/724666853205913600",
        "display_url" : "twitter.com\/OrlandoWeekly\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724715663500021760",
    "text" : "Yes. That trans-led brutal bathroom crime wave that's been plaguing our nation for decades.  https:\/\/t.co\/JnlnmkxqAQ",
    "id" : 724715663500021760,
    "created_at" : "2016-04-25 21:44:13 +0000",
    "user" : {
      "name" : "Adequately Adan",
      "screen_name" : "manicsocratic",
      "protected" : false,
      "id_str" : "16496165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673733262859046912\/C59SVzUb_normal.jpg",
      "id" : 16496165,
      "verified" : false
    }
  },
  "id" : 724737217504092161,
  "created_at" : "2016-04-25 23:09:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Naee9Ff9PW",
      "expanded_url" : "https:\/\/twitter.com\/AmericanFamAssc\/status\/724579587519172609",
      "display_url" : "twitter.com\/AmericanFamAss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724734620911210497",
  "text" : "RT @ZachsMind: i'm half tempted to photoshop this to show her using pepper spray on his face.  https:\/\/t.co\/Naee9Ff9PW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Naee9Ff9PW",
        "expanded_url" : "https:\/\/twitter.com\/AmericanFamAssc\/status\/724579587519172609",
        "display_url" : "twitter.com\/AmericanFamAss\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724716360341712896",
    "text" : "i'm half tempted to photoshop this to show her using pepper spray on his face.  https:\/\/t.co\/Naee9Ff9PW",
    "id" : 724716360341712896,
    "created_at" : "2016-04-25 21:46:59 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 724734620911210497,
  "created_at" : "2016-04-25 22:59:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "indices" : [ 3, 19 ],
      "id_str" : "111095506",
      "id" : 111095506
    }, {
      "name" : "People Magazine",
      "screen_name" : "people",
      "indices" : [ 103, 110 ],
      "id_str" : "25589776",
      "id" : 25589776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724705675054555136",
  "text" : "RT @BlackstoneAudio: \"de Waal's astonishing study of animal intelligence has the makings of a classic\" @people raves! Out in audio today. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "People Magazine",
        "screen_name" : "people",
        "indices" : [ 82, 89 ],
        "id_str" : "25589776",
        "id" : 25589776
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BlackstoneAudio\/status\/724672477683572736\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/PACY7RKE2x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg6NxqpUUAEUrSJ.jpg",
        "id_str" : "724672474453921793",
        "id" : 724672474453921793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg6NxqpUUAEUrSJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2400,
          "resize" : "fit",
          "w" : 2400
        } ],
        "display_url" : "pic.twitter.com\/PACY7RKE2x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724672477683572736",
    "text" : "\"de Waal's astonishing study of animal intelligence has the makings of a classic\" @people raves! Out in audio today. https:\/\/t.co\/PACY7RKE2x",
    "id" : 724672477683572736,
    "created_at" : "2016-04-25 18:52:37 +0000",
    "user" : {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "protected" : false,
      "id_str" : "111095506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556139629351403520\/J5Y-trdL_normal.jpeg",
      "id" : 111095506,
      "verified" : false
    }
  },
  "id" : 724705675054555136,
  "created_at" : "2016-04-25 21:04:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "indices" : [ 3, 17 ],
      "id_str" : "24798779",
      "id" : 24798779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/j2MVqNURXZ",
      "expanded_url" : "https:\/\/twitter.com\/mooretommyh\/status\/723577101396250624",
      "display_url" : "twitter.com\/mooretommyh\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724415661468975104",
  "text" : "RT @StrangerGirl2: Intersex children have various genders. Anatomy doesn't always determine gender.  https:\/\/t.co\/j2MVqNURXZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/j2MVqNURXZ",
        "expanded_url" : "https:\/\/twitter.com\/mooretommyh\/status\/723577101396250624",
        "display_url" : "twitter.com\/mooretommyh\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724120271448207360",
    "text" : "Intersex children have various genders. Anatomy doesn't always determine gender.  https:\/\/t.co\/j2MVqNURXZ",
    "id" : 724120271448207360,
    "created_at" : "2016-04-24 06:18:20 +0000",
    "user" : {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "protected" : false,
      "id_str" : "24798779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615547045726699520\/E413dZ19_normal.jpg",
      "id" : 24798779,
      "verified" : false
    }
  },
  "id" : 724415661468975104,
  "created_at" : "2016-04-25 01:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724389924909228033",
  "text" : "RT @_NealeDWalsch: You will return to Heaven whether you have loved God in the right way or not. There is no place else to go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724387505643130881",
    "text" : "You will return to Heaven whether you have loved God in the right way or not. There is no place else to go.",
    "id" : 724387505643130881,
    "created_at" : "2016-04-25 00:00:14 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 724389924909228033,
  "created_at" : "2016-04-25 00:09:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/TyAMXUKfwG",
      "expanded_url" : "https:\/\/twitter.com\/refugeingrief\/status\/724067888609505280",
      "display_url" : "twitter.com\/refugeingrief\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724281858243092485",
  "text" : "true... https:\/\/t.co\/TyAMXUKfwG",
  "id" : 724281858243092485,
  "created_at" : "2016-04-24 17:00:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 0, 14 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724279781295022081",
  "geo" : { },
  "id_str" : "724280611578482688",
  "in_reply_to_user_id" : 272369448,
  "text" : "@Swanwhisperer dont think I want to know what they're doing to them.. : (",
  "id" : 724280611578482688,
  "in_reply_to_status_id" : 724279781295022081,
  "created_at" : "2016-04-24 16:55:28 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/540169202683113473\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/3A4QsZFhaq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B38RBu3IcAAR2_V.jpg",
      "id_str" : "540169201764560896",
      "id" : 540169201764560896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B38RBu3IcAAR2_V.jpg",
      "sizes" : [ {
        "h" : 708,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3A4QsZFhaq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724273046354309126",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/3A4QsZFhaq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/540169202683113473\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/3A4QsZFhaq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B38RBu3IcAAR2_V.jpg",
        "id_str" : "540169201764560896",
        "id" : 540169201764560896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B38RBu3IcAAR2_V.jpg",
        "sizes" : [ {
          "h" : 708,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3A4QsZFhaq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724271737026785280",
    "text" : "https:\/\/t.co\/3A4QsZFhaq",
    "id" : 724271737026785280,
    "created_at" : "2016-04-24 16:20:13 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 724273046354309126,
  "created_at" : "2016-04-24 16:25:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diet",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724265149230661634",
  "text" : "i need to go on a liquid #diet.. any suggestions?",
  "id" : 724265149230661634,
  "created_at" : "2016-04-24 15:54:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724257758166564864",
  "text" : "8 gb on a phone.. i added sd card but most apps dont transfer. so really 16 gb should be minimum. gah.",
  "id" : 724257758166564864,
  "created_at" : "2016-04-24 15:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 6, 18 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idea",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724256380203442176",
  "text" : "since @audible_com created Clips.. what fun to have a clip as a ringtone? #idea",
  "id" : 724256380203442176,
  "created_at" : "2016-04-24 15:19:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/724233030479523840\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/HtQEA3p1At",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgz-C8mWYAA33X0.jpg",
      "id_str" : "724232966679977984",
      "id" : 724232966679977984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgz-C8mWYAA33X0.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HtQEA3p1At"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724234250975846401",
  "text" : "RT @Nigelstewart76: Baby Blackbird in my garden. https:\/\/t.co\/HtQEA3p1At",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/724233030479523840\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/HtQEA3p1At",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgz-C8mWYAA33X0.jpg",
        "id_str" : "724232966679977984",
        "id" : 724232966679977984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgz-C8mWYAA33X0.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/HtQEA3p1At"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724233030479523840",
    "text" : "Baby Blackbird in my garden. https:\/\/t.co\/HtQEA3p1At",
    "id" : 724233030479523840,
    "created_at" : "2016-04-24 13:46:24 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 724234250975846401,
  "created_at" : "2016-04-24 13:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Newman",
      "screen_name" : "donewman",
      "indices" : [ 3, 12 ],
      "id_str" : "1360176650",
      "id" : 1360176650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723990454090522624",
  "text" : "RT @donewman: GOP terrified of trans people in bathrooms, asks to forgive guy who actually assaulted kids in bathrooms. https:\/\/t.co\/r1z0Lu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/r1z0LuikNW",
        "expanded_url" : "https:\/\/twitter.com\/seanmcelwee\/status\/723735806091923456",
        "display_url" : "twitter.com\/seanmcelwee\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723917235295760384",
    "text" : "GOP terrified of trans people in bathrooms, asks to forgive guy who actually assaulted kids in bathrooms. https:\/\/t.co\/r1z0LuikNW",
    "id" : 723917235295760384,
    "created_at" : "2016-04-23 16:51:33 +0000",
    "user" : {
      "name" : "Doug Newman",
      "screen_name" : "donewman",
      "protected" : false,
      "id_str" : "1360176650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464714686697463808\/Nxy4XLN0_normal.jpeg",
      "id" : 1360176650,
      "verified" : false
    }
  },
  "id" : 723990454090522624,
  "created_at" : "2016-04-23 21:42:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "indices" : [ 3, 15 ],
      "id_str" : "318692762",
      "id" : 318692762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/7w56ycQcBM",
      "expanded_url" : "http:\/\/www.chicagotribune.com\/news\/local\/breaking\/ct-dennis-hastert-letters-met-20160422-story.html",
      "display_url" : "chicagotribune.com\/news\/local\/bre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723990360528158721",
  "text" : "RT @SeanMcElwee: Holy shit: rather than condemn a child molester, Republicans are asking for leniency. https:\/\/t.co\/7w56ycQcBM https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SeanMcElwee\/status\/723735806091923456\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/pxiTPlik9a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgs5326UkAAhTal.jpg",
        "id_str" : "723735796918816768",
        "id" : 723735796918816768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgs5326UkAAhTal.jpg",
        "sizes" : [ {
          "h" : 487,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 906,
          "resize" : "fit",
          "w" : 632
        }, {
          "h" : 906,
          "resize" : "fit",
          "w" : 632
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 860,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/pxiTPlik9a"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/7w56ycQcBM",
        "expanded_url" : "http:\/\/www.chicagotribune.com\/news\/local\/breaking\/ct-dennis-hastert-letters-met-20160422-story.html",
        "display_url" : "chicagotribune.com\/news\/local\/bre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723735806091923456",
    "text" : "Holy shit: rather than condemn a child molester, Republicans are asking for leniency. https:\/\/t.co\/7w56ycQcBM https:\/\/t.co\/pxiTPlik9a",
    "id" : 723735806091923456,
    "created_at" : "2016-04-23 04:50:37 +0000",
    "user" : {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "protected" : false,
      "id_str" : "318692762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697656193737748480\/Hc-WgXJw_normal.jpg",
      "id" : 318692762,
      "verified" : false
    }
  },
  "id" : 723990360528158721,
  "created_at" : "2016-04-23 21:42:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Doyle",
      "screen_name" : "ashkendo",
      "indices" : [ 3, 12 ],
      "id_str" : "11389802",
      "id" : 11389802
    }, {
      "name" : "Doug Newman",
      "screen_name" : "donewman",
      "indices" : [ 14, 23 ],
      "id_str" : "1360176650",
      "id" : 1360176650
    }, {
      "name" : "William Gibson",
      "screen_name" : "GreatDismal",
      "indices" : [ 24, 36 ],
      "id_str" : "28049003",
      "id" : 28049003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723989690639069185",
  "text" : "RT @ashkendo: @donewman @GreatDismal I guess this proves that, for them, being different is a bigger sin than being evil.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Doug Newman",
        "screen_name" : "donewman",
        "indices" : [ 0, 9 ],
        "id_str" : "1360176650",
        "id" : 1360176650
      }, {
        "name" : "William Gibson",
        "screen_name" : "GreatDismal",
        "indices" : [ 10, 22 ],
        "id_str" : "28049003",
        "id" : 28049003
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723917235295760384",
    "geo" : { },
    "id_str" : "723946425059577856",
    "in_reply_to_user_id" : 1360176650,
    "text" : "@donewman @GreatDismal I guess this proves that, for them, being different is a bigger sin than being evil.",
    "id" : 723946425059577856,
    "in_reply_to_status_id" : 723917235295760384,
    "created_at" : "2016-04-23 18:47:32 +0000",
    "in_reply_to_screen_name" : "donewman",
    "in_reply_to_user_id_str" : "1360176650",
    "user" : {
      "name" : "Ash Doyle",
      "screen_name" : "ashkendo",
      "protected" : false,
      "id_str" : "11389802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528589176522817536\/mGB6Ggbs_normal.jpeg",
      "id" : 11389802,
      "verified" : false
    }
  },
  "id" : 723989690639069185,
  "created_at" : "2016-04-23 21:39:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/AwqIVcrjYM",
      "expanded_url" : "https:\/\/youtu.be\/Ov-ocQpQtrw",
      "display_url" : "youtu.be\/Ov-ocQpQtrw"
    } ]
  },
  "geo" : { },
  "id_str" : "723982341329289218",
  "text" : "RT @onealexharms: This lil redneck keeid has all kinds of feels hearing this guy \uD83D\uDC9A https:\/\/t.co\/AwqIVcrjYM (warning: he ain't as kind as me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/AwqIVcrjYM",
        "expanded_url" : "https:\/\/youtu.be\/Ov-ocQpQtrw",
        "display_url" : "youtu.be\/Ov-ocQpQtrw"
      } ]
    },
    "geo" : { },
    "id_str" : "723981026536595456",
    "text" : "This lil redneck keeid has all kinds of feels hearing this guy \uD83D\uDC9A https:\/\/t.co\/AwqIVcrjYM (warning: he ain't as kind as me but he's awesome)",
    "id" : 723981026536595456,
    "created_at" : "2016-04-23 21:05:02 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 723982341329289218,
  "created_at" : "2016-04-23 21:10:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 35, 50 ]
    }, {
      "text" : "spoonie",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/P7M3GDxnKs",
      "expanded_url" : "https:\/\/twitter.com\/HypothyroidMom\/status\/723974421287940096",
      "display_url" : "twitter.com\/HypothyroidMom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723977700621312001",
  "text" : "cc: @JourneyTheHedgi \n\n#hashimotos #chronicillness #spoonie  https:\/\/t.co\/P7M3GDxnKs",
  "id" : 723977700621312001,
  "created_at" : "2016-04-23 20:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723974697986174976",
  "text" : "RT @TheGoldenMirror: Most of the time we are offended by things that aren't meant as an attack. Don't strike back at the other. Evaluate yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723971060769656833",
    "text" : "Most of the time we are offended by things that aren't meant as an attack. Don't strike back at the other. Evaluate your own interpretation.",
    "id" : 723971060769656833,
    "created_at" : "2016-04-23 20:25:26 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 723974697986174976,
  "created_at" : "2016-04-23 20:39:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Batten",
      "screen_name" : "brett_batten",
      "indices" : [ 0, 13 ],
      "id_str" : "490920590",
      "id" : 490920590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723954279497629696",
  "geo" : { },
  "id_str" : "723957115388346368",
  "in_reply_to_user_id" : 490920590,
  "text" : "@brett_batten i do believe god created everything. that wasnt best tweet to reply to. i made it confusing.",
  "id" : 723957115388346368,
  "in_reply_to_status_id" : 723954279497629696,
  "created_at" : "2016-04-23 19:30:01 +0000",
  "in_reply_to_screen_name" : "brett_batten",
  "in_reply_to_user_id_str" : "490920590",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Wl7WZxwMLi",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/723813825867309056",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723950750397812737",
  "text" : "Perfect would be boring.. and no growth. Soul can't evolve without resistance to make it stronger. https:\/\/t.co\/Wl7WZxwMLi",
  "id" : 723950750397812737,
  "created_at" : "2016-04-23 19:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anarchist",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "theist",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/hoD8mhfsFz",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/723815587521159168",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723950353666940929",
  "text" : "why pick on atheists? there are theists who dont believe in creationism, etc. like me. #anarchist #theist https:\/\/t.co\/hoD8mhfsFz",
  "id" : 723950353666940929,
  "created_at" : "2016-04-23 19:03:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bruce turnbull",
      "screen_name" : "turnie3",
      "indices" : [ 3, 11 ],
      "id_str" : "573511021",
      "id" : 573511021
    }, {
      "name" : "Ken Ham",
      "screen_name" : "aigkenham",
      "indices" : [ 13, 23 ],
      "id_str" : "212308700",
      "id" : 212308700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723948882267377665",
  "text" : "RT @turnie3: @aigkenham \nHow are poodles affected by sin and the curse  ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ken Ham",
        "screen_name" : "aigkenham",
        "indices" : [ 0, 10 ],
        "id_str" : "212308700",
        "id" : 212308700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723813596933791744",
    "geo" : { },
    "id_str" : "723845590359011328",
    "in_reply_to_user_id" : 212308700,
    "text" : "@aigkenham \nHow are poodles affected by sin and the curse  ?",
    "id" : 723845590359011328,
    "in_reply_to_status_id" : 723813596933791744,
    "created_at" : "2016-04-23 12:06:51 +0000",
    "in_reply_to_screen_name" : "aigkenham",
    "in_reply_to_user_id_str" : "212308700",
    "user" : {
      "name" : "bruce turnbull",
      "screen_name" : "turnie3",
      "protected" : false,
      "id_str" : "573511021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3759840137\/d31ff35994b4c7e09af663eb934286fd_normal.jpeg",
      "id" : 573511021,
      "verified" : false
    }
  },
  "id" : 723948882267377665,
  "created_at" : "2016-04-23 18:57:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/q5FI1pOsXT",
      "expanded_url" : "https:\/\/twitter.com\/AtheistRepublic\/status\/714546441088319490",
      "display_url" : "twitter.com\/AtheistRepubli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723929697348915201",
  "text" : "crap https:\/\/t.co\/q5FI1pOsXT",
  "id" : 723929697348915201,
  "created_at" : "2016-04-23 17:41:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toto Habschned",
      "screen_name" : "totohabschned",
      "indices" : [ 3, 17 ],
      "id_str" : "46611987",
      "id" : 46611987
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/totohabschned\/status\/723925847858634756\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/73FcJDhhDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgvmuQmWMAAXhhF.jpg",
      "id_str" : "723925847527272448",
      "id" : 723925847527272448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgvmuQmWMAAXhhF.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/73FcJDhhDA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/s8EXHgxzRY",
      "expanded_url" : "http:\/\/www.habschned.com\/witten-angekratzt\/",
      "display_url" : "habschned.com\/witten-angekra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723928281679028224",
  "text" : "RT @totohabschned: Witten angekratzt - https:\/\/t.co\/s8EXHgxzRY https:\/\/t.co\/73FcJDhhDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.habschned.com \" rel=\"nofollow\"\u003EHabschned.com Twitter Publish\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/totohabschned\/status\/723925847858634756\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/73FcJDhhDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgvmuQmWMAAXhhF.jpg",
        "id_str" : "723925847527272448",
        "id" : 723925847527272448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgvmuQmWMAAXhhF.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/73FcJDhhDA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/s8EXHgxzRY",
        "expanded_url" : "http:\/\/www.habschned.com\/witten-angekratzt\/",
        "display_url" : "habschned.com\/witten-angekra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723925847858634756",
    "text" : "Witten angekratzt - https:\/\/t.co\/s8EXHgxzRY https:\/\/t.co\/73FcJDhhDA",
    "id" : 723925847858634756,
    "created_at" : "2016-04-23 17:25:46 +0000",
    "user" : {
      "name" : "Toto Habschned",
      "screen_name" : "totohabschned",
      "protected" : false,
      "id_str" : "46611987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1863229368\/U1c8YuS7_normal",
      "id" : 46611987,
      "verified" : false
    }
  },
  "id" : 723928281679028224,
  "created_at" : "2016-04-23 17:35:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 3, 16 ],
      "id_str" : "457997266",
      "id" : 457997266
    }, {
      "name" : "Giveaway",
      "screen_name" : "giveaway",
      "indices" : [ 116, 125 ],
      "id_str" : "14180065",
      "id" : 14180065
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "bookgiveaway",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/AsFRx8Tguv",
      "expanded_url" : "http:\/\/audiobookreviewer.com\/giveaways\/",
      "display_url" : "audiobookreviewer.com\/giveaways\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723648632914870272",
  "text" : "RT @AudioBookRev: WOW! 22 different #audiobooks to #bookgiveaway. You have to enter to win. https:\/\/t.co\/AsFRx8Tguv @giveaway @bookgiveaway\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Giveaway",
        "screen_name" : "giveaway",
        "indices" : [ 98, 107 ],
        "id_str" : "14180065",
        "id" : 14180065
      }, {
        "name" : "Book Giveaways",
        "screen_name" : "bookgiveawaysRT",
        "indices" : [ 108, 124 ],
        "id_str" : "304358142",
        "id" : 304358142
      }, {
        "name" : "Giveaway Scoop",
        "screen_name" : "giveawayscoop",
        "indices" : [ 125, 139 ],
        "id_str" : "414302313",
        "id" : 414302313
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "audiobooks",
        "indices" : [ 18, 29 ]
      }, {
        "text" : "bookgiveaway",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/AsFRx8Tguv",
        "expanded_url" : "http:\/\/audiobookreviewer.com\/giveaways\/",
        "display_url" : "audiobookreviewer.com\/giveaways\/"
      } ]
    },
    "geo" : { },
    "id_str" : "723647464692051968",
    "text" : "WOW! 22 different #audiobooks to #bookgiveaway. You have to enter to win. https:\/\/t.co\/AsFRx8Tguv @giveaway @bookgiveawaysRT @giveawayscoop",
    "id" : 723647464692051968,
    "created_at" : "2016-04-22 22:59:34 +0000",
    "user" : {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "protected" : false,
      "id_str" : "457997266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740455024\/avatar_normal.png",
      "id" : 457997266,
      "verified" : false
    }
  },
  "id" : 723648632914870272,
  "created_at" : "2016-04-22 23:04:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723638010571558914",
  "text" : "meme on FB: liberals are moan about 1% oppressing 99% but fine with .03% (transgender) oppressing the 99.97%. GAHHHHH!!",
  "id" : 723638010571558914,
  "created_at" : "2016-04-22 22:22:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "indices" : [ 3, 14 ],
      "id_str" : "2700353103",
      "id" : 2700353103
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/723615384939667456\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/0mmewkcvV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrMWQyXEAA_dtC.jpg",
      "id_str" : "723615372981768192",
      "id" : 723615372981768192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrMWQyXEAA_dtC.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0mmewkcvV4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723634659595280385",
  "text" : "RT @jabinks846: Another lovely bird I saw today ...female blackcap https:\/\/t.co\/0mmewkcvV4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/723615384939667456\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/0mmewkcvV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrMWQyXEAA_dtC.jpg",
        "id_str" : "723615372981768192",
        "id" : 723615372981768192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrMWQyXEAA_dtC.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/0mmewkcvV4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723615384939667456",
    "text" : "Another lovely bird I saw today ...female blackcap https:\/\/t.co\/0mmewkcvV4",
    "id" : 723615384939667456,
    "created_at" : "2016-04-22 20:52:06 +0000",
    "user" : {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "protected" : false,
      "id_str" : "2700353103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735826657391595521\/n3KBNey9_normal.jpg",
      "id" : 2700353103,
      "verified" : false
    }
  },
  "id" : 723634659595280385,
  "created_at" : "2016-04-22 22:08:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/QnbQ6LRwqM",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/723459887116738561",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723585015444070401",
  "text" : "They are using empathy and compassion which I hold higher than any of God's rules in a book. https:\/\/t.co\/QnbQ6LRwqM",
  "id" : 723585015444070401,
  "created_at" : "2016-04-22 18:51:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Jz9jIpzSus",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/723275076938780672",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723584445928845312",
  "text" : "Target is a store for all humans. General etiquette applies.. not christian etiquette. https:\/\/t.co\/Jz9jIpzSus",
  "id" : 723584445928845312,
  "created_at" : "2016-04-22 18:49:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marty Strutt",
      "screen_name" : "countrydudeuk",
      "indices" : [ 3, 17 ],
      "id_str" : "1278602370",
      "id" : 1278602370
    }, {
      "name" : "Go Herdwick",
      "screen_name" : "goherdwick",
      "indices" : [ 28, 39 ],
      "id_str" : "4119830045",
      "id" : 4119830045
    }, {
      "name" : "LPC Furniture",
      "screen_name" : "LPCFurniture",
      "indices" : [ 40, 53 ],
      "id_str" : "369605654",
      "id" : 369605654
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/2BllE0gjbd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE5zpWkAAo5iM.jpg",
      "id_str" : "723536818797449216",
      "id" : 723536818797449216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE5zpWkAAo5iM.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 1730
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2BllE0gjbd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/2BllE0gjbd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE5m6WsAA-uM0.jpg",
      "id_str" : "723536815379099648",
      "id" : 723536815379099648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE5m6WsAA-uM0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 1730
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2BllE0gjbd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/2BllE0gjbd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE58KW0AAH9vh.jpg",
      "id_str" : "723536821083361280",
      "id" : 723536821083361280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE58KW0AAH9vh.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 1730
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2BllE0gjbd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/2BllE0gjbd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE56_WsAAVnk_.jpg",
      "id_str" : "723536820768780288",
      "id" : 723536820768780288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE56_WsAAVnk_.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 1956
      } ],
      "display_url" : "pic.twitter.com\/2BllE0gjbd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723573015561273344",
  "text" : "RT @countrydudeuk: Tim-Baa! @goherdwick @LPCFurniture https:\/\/t.co\/2BllE0gjbd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Go Herdwick",
        "screen_name" : "goherdwick",
        "indices" : [ 9, 20 ],
        "id_str" : "4119830045",
        "id" : 4119830045
      }, {
        "name" : "LPC Furniture",
        "screen_name" : "LPCFurniture",
        "indices" : [ 21, 34 ],
        "id_str" : "369605654",
        "id" : 369605654
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/2BllE0gjbd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE5zpWkAAo5iM.jpg",
        "id_str" : "723536818797449216",
        "id" : 723536818797449216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE5zpWkAAo5iM.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 1730
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2BllE0gjbd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/2BllE0gjbd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE5m6WsAA-uM0.jpg",
        "id_str" : "723536815379099648",
        "id" : 723536815379099648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE5m6WsAA-uM0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 1730
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2BllE0gjbd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/2BllE0gjbd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE58KW0AAH9vh.jpg",
        "id_str" : "723536821083361280",
        "id" : 723536821083361280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE58KW0AAH9vh.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 1730
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2BllE0gjbd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/countrydudeuk\/status\/723536822182248448\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/2BllE0gjbd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqE56_WsAAVnk_.jpg",
        "id_str" : "723536820768780288",
        "id" : 723536820768780288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqE56_WsAAVnk_.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 1956
        } ],
        "display_url" : "pic.twitter.com\/2BllE0gjbd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723536822182248448",
    "text" : "Tim-Baa! @goherdwick @LPCFurniture https:\/\/t.co\/2BllE0gjbd",
    "id" : 723536822182248448,
    "created_at" : "2016-04-22 15:39:55 +0000",
    "user" : {
      "name" : "Marty Strutt",
      "screen_name" : "countrydudeuk",
      "protected" : false,
      "id_str" : "1278602370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794670653769138176\/omb0mM3K_normal.jpg",
      "id" : 1278602370,
      "verified" : false
    }
  },
  "id" : 723573015561273344,
  "created_at" : "2016-04-22 18:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723526057605926912",
  "text" : "is it part of my neurosis.. am i coming apart at the seams? i dont like this person in her 5s (or at least direction)",
  "id" : 723526057605926912,
  "created_at" : "2016-04-22 14:57:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    }, {
      "name" : "Slashdot",
      "screen_name" : "slashdot",
      "indices" : [ 112, 121 ],
      "id_str" : "1068831",
      "id" : 1068831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723525413901885440",
  "text" : "RT @Charmantides: VC, Entrepreneur Says Basic Income Would Work Even If 90% People 'Smoked Pot' and Didn't Work @slashdot - https:\/\/t.co\/75\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/login.slashdot.org\/\" rel=\"nofollow\"\u003ESlashdot login\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slashdot",
        "screen_name" : "slashdot",
        "indices" : [ 94, 103 ],
        "id_str" : "1068831",
        "id" : 1068831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/75tGRoheTS",
        "expanded_url" : "http:\/\/rpx.me\/Eq4-l",
        "display_url" : "rpx.me\/Eq4-l"
      } ]
    },
    "geo" : { },
    "id_str" : "723485606882476032",
    "text" : "VC, Entrepreneur Says Basic Income Would Work Even If 90% People 'Smoked Pot' and Didn't Work @slashdot - https:\/\/t.co\/75tGRoheTS",
    "id" : 723485606882476032,
    "created_at" : "2016-04-22 12:16:25 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 723525413901885440,
  "created_at" : "2016-04-22 14:54:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723525112494981124",
  "text" : "on fringes of awareness, can feel my soul hardening. is this mid-life syndrome? can feel fear, paranoia creeping in. i dont understand.",
  "id" : 723525112494981124,
  "created_at" : "2016-04-22 14:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723337142546649088",
  "geo" : { },
  "id_str" : "723523127599345664",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 yay! ((fistbump))",
  "id" : 723523127599345664,
  "in_reply_to_status_id" : 723337142546649088,
  "created_at" : "2016-04-22 14:45:30 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723522976541478912",
  "text" : "RT @AndyBoxHill: Check out this monster speed merchant making a slow getaway having mugged me of 50p. It's a roman snail. Fab beasts\uD83D\uDE0A https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/723477227078332416\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/niOoCDV0Z5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgpOqi6XEAArl9u.jpg",
        "id_str" : "723477182979444736",
        "id" : 723477182979444736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgpOqi6XEAArl9u.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2166,
          "resize" : "fit",
          "w" : 1804
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1229,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/niOoCDV0Z5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723477227078332416",
    "text" : "Check out this monster speed merchant making a slow getaway having mugged me of 50p. It's a roman snail. Fab beasts\uD83D\uDE0A https:\/\/t.co\/niOoCDV0Z5",
    "id" : 723477227078332416,
    "created_at" : "2016-04-22 11:43:07 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 723522976541478912,
  "created_at" : "2016-04-22 14:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/periscope.tv\" rel=\"nofollow\"\u003EPeriscope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "indices" : [ 1, 11 ],
      "id_str" : "21124068",
      "id" : 21124068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Periscope",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/YqZeqogLqG",
      "expanded_url" : "https:\/\/www.periscope.tv\/w\/aego-jMwNzcyM3wxUkR4bHBwb2RXZ3hMzLnQEHQJshgpt1neZKf0i6Pa_RAS3mHdI3VwEJRFvvI=",
      "display_url" : "periscope.tv\/w\/aego-jMwNzcy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723328540557611008",
  "text" : ".@SPGiraffe on #Periscope: Steam Powered Giraffe Rehearsal - No Makeup https:\/\/t.co\/YqZeqogLqG",
  "id" : 723328540557611008,
  "created_at" : "2016-04-22 01:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James",
      "screen_name" : "bigbrez100",
      "indices" : [ 3, 14 ],
      "id_str" : "409679865",
      "id" : 409679865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723290530822672384",
  "text" : "RT @bigbrez100: I've finally reached that peaceful point where I just don't give a fuck anymore.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722997056109981696",
    "text" : "I've finally reached that peaceful point where I just don't give a fuck anymore.",
    "id" : 722997056109981696,
    "created_at" : "2016-04-21 03:55:05 +0000",
    "user" : {
      "name" : "James",
      "screen_name" : "bigbrez100",
      "protected" : false,
      "id_str" : "409679865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796722676245131264\/Nnpo98vO_normal.jpg",
      "id" : 409679865,
      "verified" : false
    }
  },
  "id" : 723290530822672384,
  "created_at" : "2016-04-21 23:21:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raw Story",
      "screen_name" : "RawStory",
      "indices" : [ 3, 12 ],
      "id_str" : "16041234",
      "id" : 16041234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/EX22WQ3mUo",
      "expanded_url" : "http:\/\/ow.ly\/4mXuby",
      "display_url" : "ow.ly\/4mXuby"
    } ]
  },
  "geo" : { },
  "id_str" : "723289543160504324",
  "text" : "RT @RawStory: Horses are being born without the ability to swallow \u2014 and fracking could be to blame https:\/\/t.co\/EX22WQ3mUo https:\/\/t.co\/xR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RawStory\/status\/723251832726937600\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/xRQkVfxHfG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgmBtaBWYAAtmp8.jpg",
        "id_str" : "723251832248754176",
        "id" : 723251832248754176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgmBtaBWYAAtmp8.jpg",
        "sizes" : [ {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/xRQkVfxHfG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/EX22WQ3mUo",
        "expanded_url" : "http:\/\/ow.ly\/4mXuby",
        "display_url" : "ow.ly\/4mXuby"
      } ]
    },
    "geo" : { },
    "id_str" : "723251832726937600",
    "text" : "Horses are being born without the ability to swallow \u2014 and fracking could be to blame https:\/\/t.co\/EX22WQ3mUo https:\/\/t.co\/xRQkVfxHfG",
    "id" : 723251832726937600,
    "created_at" : "2016-04-21 20:47:28 +0000",
    "user" : {
      "name" : "Raw Story",
      "screen_name" : "RawStory",
      "protected" : false,
      "id_str" : "16041234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511012709270183936\/wEVYV7Lf_normal.png",
      "id" : 16041234,
      "verified" : true
    }
  },
  "id" : 723289543160504324,
  "created_at" : "2016-04-21 23:17:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723272935667077120",
  "text" : "google maps on phone.. not good. cant save directions? have to go to map history to find. wth?",
  "id" : 723272935667077120,
  "created_at" : "2016-04-21 22:11:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723215194256773120",
  "geo" : { },
  "id_str" : "723218315091517440",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 ((hugs)) breathe!",
  "id" : 723218315091517440,
  "in_reply_to_status_id" : 723215194256773120,
  "created_at" : "2016-04-21 18:34:17 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723216411229720577",
  "text" : "good lord.. on my FB.. ppl saying obese ppl are selfish and trans ppl are pretending! GRRR!! WTF is wrong w ppl??",
  "id" : 723216411229720577,
  "created_at" : "2016-04-21 18:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/zMb27dtYY3",
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/722871042780233731",
      "display_url" : "twitter.com\/BuzzFeed\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722947112225284096",
  "text" : "bless them https:\/\/t.co\/zMb27dtYY3",
  "id" : 722947112225284096,
  "created_at" : "2016-04-21 00:36:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722897781518536704",
  "text" : "RT @ToadHollowPhoto: I just love these old Stave Churches, this one ensconced in a beautiful landscape! \"\u043E\u0441\u0435\u043D\u044C \u0432 \u041A\u0430\u0440\u0435\u043B\u0438\u0438\" by Ed Gordeev. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zXup7q79fg",
        "expanded_url" : "https:\/\/500px.com\/photo\/138078857\/%D0%BE%D1%81%D0%B5%D0%BD%D1%8C-%D0%B2-%D0%9A%D0%B0%D1%80%D0%B5%D0%BB%D0%B8%D0%B8-by-ed-gordeev?utm_medium=twitter&utm_campaign=nativeshare&utm_content=web&utm_source=500px",
        "display_url" : "500px.com\/photo\/13807885\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722897363472257024",
    "text" : "I just love these old Stave Churches, this one ensconced in a beautiful landscape! \"\u043E\u0441\u0435\u043D\u044C \u0432 \u041A\u0430\u0440\u0435\u043B\u0438\u0438\" by Ed Gordeev. https:\/\/t.co\/zXup7q79fg",
    "id" : 722897363472257024,
    "created_at" : "2016-04-20 21:18:56 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 722897781518536704,
  "created_at" : "2016-04-20 21:20:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/1uXyPEOTg7",
      "expanded_url" : "https:\/\/twitter.com\/I3ump\/status\/722803106036092929",
      "display_url" : "twitter.com\/I3ump\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722806779705307138",
  "text" : "i read tegmarks book about this.  a bit over my head but interesting. https:\/\/t.co\/1uXyPEOTg7",
  "id" : 722806779705307138,
  "created_at" : "2016-04-20 15:19:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/N1JFtd9qCF",
      "expanded_url" : "http:\/\/bit.ly\/1Ra7JZQ",
      "display_url" : "bit.ly\/1Ra7JZQ"
    } ]
  },
  "geo" : { },
  "id_str" : "722806352267968516",
  "text" : "RT @OMGFacts: These flowers blooming at Death Valley have people freaking out. https:\/\/t.co\/N1JFtd9qCF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/N1JFtd9qCF",
        "expanded_url" : "http:\/\/bit.ly\/1Ra7JZQ",
        "display_url" : "bit.ly\/1Ra7JZQ"
      } ]
    },
    "geo" : { },
    "id_str" : "722803353588277248",
    "text" : "These flowers blooming at Death Valley have people freaking out. https:\/\/t.co\/N1JFtd9qCF",
    "id" : 722803353588277248,
    "created_at" : "2016-04-20 15:05:23 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 722806352267968516,
  "created_at" : "2016-04-20 15:17:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/722680990452314112\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/lH4Bv1ozDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgd6dEIWcAIAYnd.jpg",
      "id_str" : "722680904959815682",
      "id" : 722680904959815682,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgd6dEIWcAIAYnd.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lH4Bv1ozDA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722804734143258624",
  "text" : "RT @1CatShepherd: The bliss of sun warming your body after a cold night https:\/\/t.co\/lH4Bv1ozDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/722680990452314112\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/lH4Bv1ozDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgd6dEIWcAIAYnd.jpg",
        "id_str" : "722680904959815682",
        "id" : 722680904959815682,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgd6dEIWcAIAYnd.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lH4Bv1ozDA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722680990452314112",
    "text" : "The bliss of sun warming your body after a cold night https:\/\/t.co\/lH4Bv1ozDA",
    "id" : 722680990452314112,
    "created_at" : "2016-04-20 06:59:09 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 722804734143258624,
  "created_at" : "2016-04-20 15:10:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/ZYDPGV8HbD",
      "expanded_url" : "https:\/\/twitter.com\/Colleges4Bernie\/status\/722780146936246273",
      "display_url" : "twitter.com\/Colleges4Berni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722786577789767681",
  "text" : "not giving up https:\/\/t.co\/ZYDPGV8HbD",
  "id" : 722786577789767681,
  "created_at" : "2016-04-20 13:58:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Rankin",
      "screen_name" : "Beathhigh",
      "indices" : [ 3, 13 ],
      "id_str" : "38466098",
      "id" : 38466098
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Beathhigh\/status\/722490404894064640\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/JrQPM0Vi9r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbNFheXEAA20Vq.jpg",
      "id_str" : "722490285008293888",
      "id" : 722490285008293888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbNFheXEAA20Vq.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JrQPM0Vi9r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722592743629975552",
  "text" : "RT @Beathhigh: Signposts of Edinburgh. No1 in an occasional series. https:\/\/t.co\/JrQPM0Vi9r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Beathhigh\/status\/722490404894064640\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/JrQPM0Vi9r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbNFheXEAA20Vq.jpg",
        "id_str" : "722490285008293888",
        "id" : 722490285008293888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbNFheXEAA20Vq.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JrQPM0Vi9r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722490404894064640",
    "text" : "Signposts of Edinburgh. No1 in an occasional series. https:\/\/t.co\/JrQPM0Vi9r",
    "id" : 722490404894064640,
    "created_at" : "2016-04-19 18:21:50 +0000",
    "user" : {
      "name" : "Ian Rankin",
      "screen_name" : "Beathhigh",
      "protected" : false,
      "id_str" : "38466098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772205246194053124\/iOA8u7dp_normal.jpg",
      "id" : 38466098,
      "verified" : true
    }
  },
  "id" : 722592743629975552,
  "created_at" : "2016-04-20 01:08:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/722570129079451648\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/hPUiwELD3T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgcVsy_XIAAMHcX.jpg",
      "id_str" : "722570124562210816",
      "id" : 722570124562210816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgcVsy_XIAAMHcX.jpg",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 375
      } ],
      "display_url" : "pic.twitter.com\/hPUiwELD3T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722589662011879425",
  "text" : "RT @ravenmaster1: Beautiful photo of Merlina, by Molly Michelin https:\/\/t.co\/hPUiwELD3T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/722570129079451648\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/hPUiwELD3T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgcVsy_XIAAMHcX.jpg",
        "id_str" : "722570124562210816",
        "id" : 722570124562210816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgcVsy_XIAAMHcX.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 375
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 375
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 375
        } ],
        "display_url" : "pic.twitter.com\/hPUiwELD3T"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722570129079451648",
    "text" : "Beautiful photo of Merlina, by Molly Michelin https:\/\/t.co\/hPUiwELD3T",
    "id" : 722570129079451648,
    "created_at" : "2016-04-19 23:38:38 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 722589662011879425,
  "created_at" : "2016-04-20 00:56:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722589416619958273",
  "text" : "RT @existentialcoms: Nietzsche: \"there is no truth, only interpretation\"\nMe: \"I interpret that to say there IS truth\"\nN: \"yeah, some interp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722582686364078081",
    "text" : "Nietzsche: \"there is no truth, only interpretation\"\nMe: \"I interpret that to say there IS truth\"\nN: \"yeah, some interpretations are stupid\"",
    "id" : 722582686364078081,
    "created_at" : "2016-04-20 00:28:32 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 722589416619958273,
  "created_at" : "2016-04-20 00:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722543149021835264",
  "text" : "RT @AWorldOutOfMind: Assume as Truth that all people have areas of self-blindness they are utterly unaware of. The Ego blinds us all. We se\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722537293681180673",
    "text" : "Assume as Truth that all people have areas of self-blindness they are utterly unaware of. The Ego blinds us all. We see it only in others.",
    "id" : 722537293681180673,
    "created_at" : "2016-04-19 21:28:09 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 722543149021835264,
  "created_at" : "2016-04-19 21:51:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 3, 19 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722492984852398084",
  "text" : "RT @simonwoodwrites: QUESTION: Can I use a legal pad for illegal purposes?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweue.com\" rel=\"nofollow\"\u003ETweue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722492488364257280",
    "text" : "QUESTION: Can I use a legal pad for illegal purposes?",
    "id" : 722492488364257280,
    "created_at" : "2016-04-19 18:30:07 +0000",
    "user" : {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "protected" : false,
      "id_str" : "30077179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786815188955570176\/XPC8uW7z_normal.jpg",
      "id" : 30077179,
      "verified" : false
    }
  },
  "id" : 722492984852398084,
  "created_at" : "2016-04-19 18:32:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722488556472692737",
  "text" : "just voted for 1st time. most excitement ive had in ages! lol",
  "id" : 722488556472692737,
  "created_at" : "2016-04-19 18:14:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/YnV77t1CBo",
      "expanded_url" : "https:\/\/twitter.com\/Hrothgar777\/status\/722475776377946113",
      "display_url" : "twitter.com\/Hrothgar777\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722488074043801601",
  "text" : "((head-to-desk))!! https:\/\/t.co\/YnV77t1CBo",
  "id" : 722488074043801601,
  "created_at" : "2016-04-19 18:12:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Mitchell",
      "screen_name" : "JackMitchellArt",
      "indices" : [ 3, 19 ],
      "id_str" : "706486961633148929",
      "id" : 706486961633148929
    }, {
      "name" : "RSPB",
      "screen_name" : "Natures_Voice",
      "indices" : [ 118, 132 ],
      "id_str" : "19255050",
      "id" : 19255050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722487482353389569",
  "text" : "RT @JackMitchellArt: Update on Cromarty Firth Swans, nesting commenced. 4 images with a final, \"That's close enough!\" @Natures_Voice https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RSPB",
        "screen_name" : "Natures_Voice",
        "indices" : [ 97, 111 ],
        "id_str" : "19255050",
        "id" : 19255050
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JackMitchellArt\/status\/722470207407726592\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/M2jdSEGBTd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cga60tmW8AArMqb.jpg",
        "id_str" : "722470204995989504",
        "id" : 722470204995989504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cga60tmW8AArMqb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/M2jdSEGBTd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JackMitchellArt\/status\/722470207407726592\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/M2jdSEGBTd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cga6wkHXEAAuX2n.jpg",
        "id_str" : "722470133730578432",
        "id" : 722470133730578432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cga6wkHXEAAuX2n.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/M2jdSEGBTd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JackMitchellArt\/status\/722470207407726592\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/M2jdSEGBTd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cga6tE9WEAIGT1R.jpg",
        "id_str" : "722470073827463170",
        "id" : 722470073827463170,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cga6tE9WEAIGT1R.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 933
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 933
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/M2jdSEGBTd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JackMitchellArt\/status\/722470207407726592\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/M2jdSEGBTd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cga6ujaWEAE0RWu.jpg",
        "id_str" : "722470099182030849",
        "id" : 722470099182030849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cga6ujaWEAE0RWu.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/M2jdSEGBTd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722470207407726592",
    "text" : "Update on Cromarty Firth Swans, nesting commenced. 4 images with a final, \"That's close enough!\" @Natures_Voice https:\/\/t.co\/M2jdSEGBTd",
    "id" : 722470207407726592,
    "created_at" : "2016-04-19 17:01:34 +0000",
    "user" : {
      "name" : "Jack Mitchell",
      "screen_name" : "JackMitchellArt",
      "protected" : false,
      "id_str" : "706486961633148929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717225005399023617\/tsKDEemj_normal.jpg",
      "id" : 706486961633148929,
      "verified" : false
    }
  },
  "id" : 722487482353389569,
  "created_at" : "2016-04-19 18:10:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722411114861080576",
  "text" : "RT @AndyBoxHill: Patience pays off. That duck nesting in my shed hatched ducklings. Think I can count 14 of the cute fluff - balls. \uD83D\uDE0A https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/722310117727666176\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/sKN8IVmyW1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgYpKsiWEAAg3lz.jpg",
        "id_str" : "722310053970186240",
        "id" : 722310053970186240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgYpKsiWEAAg3lz.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1349,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1349,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sKN8IVmyW1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/722310117727666176\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/sKN8IVmyW1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgYpL-iWQAA064g.jpg",
        "id_str" : "722310075981905920",
        "id" : 722310075981905920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgYpL-iWQAA064g.jpg",
        "sizes" : [ {
          "h" : 542,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1742,
          "resize" : "fit",
          "w" : 1092
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1634,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 957,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sKN8IVmyW1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722310117727666176",
    "text" : "Patience pays off. That duck nesting in my shed hatched ducklings. Think I can count 14 of the cute fluff - balls. \uD83D\uDE0A https:\/\/t.co\/sKN8IVmyW1",
    "id" : 722310117727666176,
    "created_at" : "2016-04-19 06:25:26 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 722411114861080576,
  "created_at" : "2016-04-19 13:06:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722229656301281280",
  "text" : "RT @johnpavlovitz: Before posting online rants, hateful memes, angry blogs, &amp; histrionics about \"homosexuality\". The more you know... https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/johnpavlovitz\/status\/722227482980663300\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/IVvR2c7dVW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgXeEWLWQAAUvyz.jpg",
        "id_str" : "722227481516851200",
        "id" : 722227481516851200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgXeEWLWQAAUvyz.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IVvR2c7dVW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722227482980663300",
    "text" : "Before posting online rants, hateful memes, angry blogs, &amp; histrionics about \"homosexuality\". The more you know... https:\/\/t.co\/IVvR2c7dVW",
    "id" : 722227482980663300,
    "created_at" : "2016-04-19 00:57:04 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 722229656301281280,
  "created_at" : "2016-04-19 01:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/722205129118756864\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/PwicMCCK1F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgXJsBgXEAAvxwV.jpg",
      "id_str" : "722205073418424320",
      "id" : 722205073418424320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgXJsBgXEAAvxwV.jpg",
      "sizes" : [ {
        "h" : 994,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1987,
        "resize" : "fit",
        "w" : 2047
      } ],
      "display_url" : "pic.twitter.com\/PwicMCCK1F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722226440973000704",
  "text" : "RT @newlandfarm: Longhorns, saving some for later https:\/\/t.co\/PwicMCCK1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/722205129118756864\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/PwicMCCK1F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgXJsBgXEAAvxwV.jpg",
        "id_str" : "722205073418424320",
        "id" : 722205073418424320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgXJsBgXEAAvxwV.jpg",
        "sizes" : [ {
          "h" : 994,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1987,
          "resize" : "fit",
          "w" : 2047
        } ],
        "display_url" : "pic.twitter.com\/PwicMCCK1F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722205129118756864",
    "text" : "Longhorns, saving some for later https:\/\/t.co\/PwicMCCK1F",
    "id" : 722205129118756864,
    "created_at" : "2016-04-18 23:28:15 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 722226440973000704,
  "created_at" : "2016-04-19 00:52:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/pPEzSQMAHG",
      "expanded_url" : "https:\/\/twitter.com\/BetteMidler\/status\/721452808273272832",
      "display_url" : "twitter.com\/BetteMidler\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722203177743949825",
  "text" : "no.. not really. im not suicidal but frankly I'll be happy when my time is up. https:\/\/t.co\/pPEzSQMAHG",
  "id" : 722203177743949825,
  "created_at" : "2016-04-18 23:20:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Kilvert",
      "screen_name" : "marykilvert",
      "indices" : [ 3, 15 ],
      "id_str" : "18938444",
      "id" : 18938444
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marykilvert\/status\/721104569367834624\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SFekicXEZX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf_7HbrW4AEXKQg.jpg",
      "id_str" : "720570570509836289",
      "id" : 720570570509836289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf_7HbrW4AEXKQg.jpg",
      "sizes" : [ {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SFekicXEZX"
    } ],
    "hashtags" : [ {
      "text" : "sheep",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722202132238217216",
  "text" : "RT @marykilvert: A new flock of my colourful sheep, each is finished with a distinctive hand-knitted jumper! #sheep https:\/\/t.co\/SFekicXEZX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marykilvert\/status\/721104569367834624\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/SFekicXEZX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf_7HbrW4AEXKQg.jpg",
        "id_str" : "720570570509836289",
        "id" : 720570570509836289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf_7HbrW4AEXKQg.jpg",
        "sizes" : [ {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SFekicXEZX"
      } ],
      "hashtags" : [ {
        "text" : "sheep",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721104569367834624",
    "text" : "A new flock of my colourful sheep, each is finished with a distinctive hand-knitted jumper! #sheep https:\/\/t.co\/SFekicXEZX",
    "id" : 721104569367834624,
    "created_at" : "2016-04-15 22:35:01 +0000",
    "user" : {
      "name" : "Mary Kilvert",
      "screen_name" : "marykilvert",
      "protected" : false,
      "id_str" : "18938444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517733343555641345\/3uXh9kc5_normal.jpeg",
      "id" : 18938444,
      "verified" : false
    }
  },
  "id" : 722202132238217216,
  "created_at" : "2016-04-18 23:16:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthanne Reid",
      "screen_name" : "RuthanneReid",
      "indices" : [ 3, 16 ],
      "id_str" : "18025985",
      "id" : 18025985
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RuthanneReid\/status\/721800513558155264\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/CfVHET53km",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRZvTXUkAANAmJ.jpg",
      "id_str" : "721800509472935936",
      "id" : 721800509472935936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRZvTXUkAANAmJ.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 1125
      } ],
      "display_url" : "pic.twitter.com\/CfVHET53km"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722201381038333952",
  "text" : "RT @RuthanneReid: This did not end as expected. https:\/\/t.co\/CfVHET53km",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RuthanneReid\/status\/721800513558155264\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/CfVHET53km",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRZvTXUkAANAmJ.jpg",
        "id_str" : "721800509472935936",
        "id" : 721800509472935936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRZvTXUkAANAmJ.jpg",
        "sizes" : [ {
          "h" : 492,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 1125
        } ],
        "display_url" : "pic.twitter.com\/CfVHET53km"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721800513558155264",
    "text" : "This did not end as expected. https:\/\/t.co\/CfVHET53km",
    "id" : 721800513558155264,
    "created_at" : "2016-04-17 20:40:27 +0000",
    "user" : {
      "name" : "Ruthanne Reid",
      "screen_name" : "RuthanneReid",
      "protected" : false,
      "id_str" : "18025985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799851005848342529\/ANcqWpwB_normal.jpg",
      "id" : 18025985,
      "verified" : false
    }
  },
  "id" : 722201381038333952,
  "created_at" : "2016-04-18 23:13:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The hungry farmer",
      "screen_name" : "jimlyons16",
      "indices" : [ 3, 14 ],
      "id_str" : "1568507966",
      "id" : 1568507966
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jimlyons16\/status\/722075940717752322\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/CL0B2PrSi2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVUPbHW4AAYvP8.jpg",
      "id_str" : "722075939216220160",
      "id" : 722075939216220160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVUPbHW4AAYvP8.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CL0B2PrSi2"
    } ],
    "hashtags" : [ {
      "text" : "sheep365",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722107071018221568",
  "text" : "RT @jimlyons16: This dry hogget filling up on flower power \uD83D\uDE03   \"#sheep365\" https:\/\/t.co\/CL0B2PrSi2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jimlyons16\/status\/722075940717752322\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/CL0B2PrSi2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVUPbHW4AAYvP8.jpg",
        "id_str" : "722075939216220160",
        "id" : 722075939216220160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVUPbHW4AAYvP8.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CL0B2PrSi2"
      } ],
      "hashtags" : [ {
        "text" : "sheep365",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722075940717752322",
    "text" : "This dry hogget filling up on flower power \uD83D\uDE03   \"#sheep365\" https:\/\/t.co\/CL0B2PrSi2",
    "id" : 722075940717752322,
    "created_at" : "2016-04-18 14:54:54 +0000",
    "user" : {
      "name" : "The hungry farmer",
      "screen_name" : "jimlyons16",
      "protected" : false,
      "id_str" : "1568507966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634472112556740608\/HRV_N_Ec_normal.jpg",
      "id" : 1568507966,
      "verified" : false
    }
  },
  "id" : 722107071018221568,
  "created_at" : "2016-04-18 16:58:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Renter",
      "screen_name" : "ElizabethRenter",
      "indices" : [ 3, 19 ],
      "id_str" : "48567055",
      "id" : 48567055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Data",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "Poverty",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/abSgGgn7iQ",
      "expanded_url" : "http:\/\/buff.ly\/1WAymaD",
      "display_url" : "buff.ly\/1WAymaD"
    } ]
  },
  "geo" : { },
  "id_str" : "722067573672644608",
  "text" : "RT @ElizabethRenter: The Difference Between the Rich and the Poor in 1 Graph https:\/\/t.co\/abSgGgn7iQ #Data #Poverty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Data",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "Poverty",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/abSgGgn7iQ",
        "expanded_url" : "http:\/\/buff.ly\/1WAymaD",
        "display_url" : "buff.ly\/1WAymaD"
      } ]
    },
    "geo" : { },
    "id_str" : "722032108445818880",
    "text" : "The Difference Between the Rich and the Poor in 1 Graph https:\/\/t.co\/abSgGgn7iQ #Data #Poverty",
    "id" : 722032108445818880,
    "created_at" : "2016-04-18 12:00:44 +0000",
    "user" : {
      "name" : "Elizabeth Renter",
      "screen_name" : "ElizabethRenter",
      "protected" : false,
      "id_str" : "48567055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788689773334495232\/REi3Jf4b_normal.jpg",
      "id" : 48567055,
      "verified" : true
    }
  },
  "id" : 722067573672644608,
  "created_at" : "2016-04-18 14:21:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Burton",
      "screen_name" : "AmitayusX",
      "indices" : [ 3, 13 ],
      "id_str" : "3283778658",
      "id" : 3283778658
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmitayusX\/status\/721866150179508226\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ELMki62fI7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgSVbroUsAAcmE9.jpg",
      "id_str" : "721866143086981120",
      "id" : 721866143086981120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgSVbroUsAAcmE9.jpg",
      "sizes" : [ {
        "h" : 395,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ELMki62fI7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721870629012643841",
  "text" : "RT @AmitayusX: https:\/\/t.co\/ELMki62fI7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmitayusX\/status\/721866150179508226\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/ELMki62fI7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgSVbroUsAAcmE9.jpg",
        "id_str" : "721866143086981120",
        "id" : 721866143086981120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgSVbroUsAAcmE9.jpg",
        "sizes" : [ {
          "h" : 395,
          "resize" : "fit",
          "w" : 356
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 356
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 356
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ELMki62fI7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721866150179508226",
    "text" : "https:\/\/t.co\/ELMki62fI7",
    "id" : 721866150179508226,
    "created_at" : "2016-04-18 01:01:16 +0000",
    "user" : {
      "name" : "Phil Burton",
      "screen_name" : "AmitayusX",
      "protected" : false,
      "id_str" : "3283778658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793404694114689024\/aRQWvLhF_normal.jpg",
      "id" : 3283778658,
      "verified" : false
    }
  },
  "id" : 721870629012643841,
  "created_at" : "2016-04-18 01:19:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721835511317405696",
  "text" : "maybe I AM depressed... huh.. nahh.. im just a boring screw-up. so tired of being me. there is no me to be.",
  "id" : 721835511317405696,
  "created_at" : "2016-04-17 22:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/721765335599341568\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/IysY1OUES4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgQ5sKcWcAEzPcK.jpg",
      "id_str" : "721765271166414849",
      "id" : 721765271166414849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgQ5sKcWcAEzPcK.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/IysY1OUES4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721777997003538432",
  "text" : "RT @Nigelstewart76: Dunnock collecting fur in my garden https:\/\/t.co\/IysY1OUES4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/721765335599341568\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/IysY1OUES4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgQ5sKcWcAEzPcK.jpg",
        "id_str" : "721765271166414849",
        "id" : 721765271166414849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgQ5sKcWcAEzPcK.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/IysY1OUES4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721765335599341568",
    "text" : "Dunnock collecting fur in my garden https:\/\/t.co\/IysY1OUES4",
    "id" : 721765335599341568,
    "created_at" : "2016-04-17 18:20:40 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 721777997003538432,
  "created_at" : "2016-04-17 19:10:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721709759158697985",
  "geo" : { },
  "id_str" : "721762090592182272",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides been there. vol for ring, multimedia, alarm. tried several apps (even those sep ring vol from not vol but no go.. gah.",
  "id" : 721762090592182272,
  "in_reply_to_status_id" : 721709759158697985,
  "created_at" : "2016-04-17 18:07:46 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "motoe2",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "volumeapps",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721708849271586816",
  "text" : "notification for emails is too loud and cant seem to change it.. arg. #android #motoe2 #volumeapps",
  "id" : 721708849271586816,
  "created_at" : "2016-04-17 14:36:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721527115884204032",
  "text" : "I finished listening to The Devil You Know (Unabridged) by Mike Carey, narrated by Michael Kramer on my Audible app.",
  "id" : 721527115884204032,
  "created_at" : "2016-04-17 02:34:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaylyn Ettinger",
      "screen_name" : "JaylynEttinger",
      "indices" : [ 3, 18 ],
      "id_str" : "393171004",
      "id" : 393171004
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JaylynEttinger\/status\/721347799636254720\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/3GlztA01wQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgK9_p2UEAAMsjJ.jpg",
      "id_str" : "721347791595769856",
      "id" : 721347791595769856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgK9_p2UEAAMsjJ.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3GlztA01wQ"
    } ],
    "hashtags" : [ {
      "text" : "highlandcattle",
      "indices" : [ 71, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721414733862158337",
  "text" : "RT @JaylynEttinger: Chatelaine. Some cows are born to walk the runway. #highlandcattle https:\/\/t.co\/3GlztA01wQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JaylynEttinger\/status\/721347799636254720\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/3GlztA01wQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgK9_p2UEAAMsjJ.jpg",
        "id_str" : "721347791595769856",
        "id" : 721347791595769856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgK9_p2UEAAMsjJ.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/3GlztA01wQ"
      } ],
      "hashtags" : [ {
        "text" : "highlandcattle",
        "indices" : [ 51, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721347799636254720",
    "text" : "Chatelaine. Some cows are born to walk the runway. #highlandcattle https:\/\/t.co\/3GlztA01wQ",
    "id" : 721347799636254720,
    "created_at" : "2016-04-16 14:41:32 +0000",
    "user" : {
      "name" : "Jaylyn Ettinger",
      "screen_name" : "JaylynEttinger",
      "protected" : false,
      "id_str" : "393171004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659842808619008002\/ije1xcE2_normal.jpg",
      "id" : 393171004,
      "verified" : false
    }
  },
  "id" : 721414733862158337,
  "created_at" : "2016-04-16 19:07:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/r9ugXppvoo",
      "expanded_url" : "https:\/\/youtu.be\/yq1axl-3K3M",
      "display_url" : "youtu.be\/yq1axl-3K3M"
    } ]
  },
  "geo" : { },
  "id_str" : "721331330299097089",
  "text" : "Your Shirt Is Green https:\/\/t.co\/r9ugXppvoo",
  "id" : 721331330299097089,
  "created_at" : "2016-04-16 13:36:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitehawk",
      "screen_name" : "Whitehawkbird",
      "indices" : [ 3, 17 ],
      "id_str" : "325176287",
      "id" : 325176287
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Whitehawkbird\/status\/721108090574217216\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/hntHQu83Jc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgHj_NDXEAAjcHr.jpg",
      "id_str" : "721108090331009024",
      "id" : 721108090331009024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgHj_NDXEAAjcHr.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/hntHQu83Jc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721124907745206272",
  "text" : "RT @Whitehawkbird: Blue Chaffinch, one of our targets in our Canary Islands Endemics Tour https:\/\/t.co\/hntHQu83Jc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Whitehawkbird\/status\/721108090574217216\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/hntHQu83Jc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgHj_NDXEAAjcHr.jpg",
        "id_str" : "721108090331009024",
        "id" : 721108090331009024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgHj_NDXEAAjcHr.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/hntHQu83Jc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721108090574217216",
    "text" : "Blue Chaffinch, one of our targets in our Canary Islands Endemics Tour https:\/\/t.co\/hntHQu83Jc",
    "id" : 721108090574217216,
    "created_at" : "2016-04-15 22:49:00 +0000",
    "user" : {
      "name" : "Whitehawk",
      "screen_name" : "Whitehawkbird",
      "protected" : false,
      "id_str" : "325176287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3758707020\/f09bfdb52edddd95d05379487109abfd_normal.jpeg",
      "id" : 325176287,
      "verified" : false
    }
  },
  "id" : 721124907745206272,
  "created_at" : "2016-04-15 23:55:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/720701123192098816\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/IvfiLNvaSY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgBx2VQWEAA9-k-.jpg",
      "id_str" : "720701118611853312",
      "id" : 720701118611853312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgBx2VQWEAA9-k-.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/IvfiLNvaSY"
    } ],
    "hashtags" : [ {
      "text" : "weather",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "ncwx",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720724763623178240",
  "text" : "RT @dwaynereaves: Sitting on the boat dock at Mayo lake in Person County on Tuesday. #weather #ncwx https:\/\/t.co\/IvfiLNvaSY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/720701123192098816\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/IvfiLNvaSY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgBx2VQWEAA9-k-.jpg",
        "id_str" : "720701118611853312",
        "id" : 720701118611853312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgBx2VQWEAA9-k-.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/IvfiLNvaSY"
      } ],
      "hashtags" : [ {
        "text" : "weather",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "ncwx",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720701123192098816",
    "text" : "Sitting on the boat dock at Mayo lake in Person County on Tuesday. #weather #ncwx https:\/\/t.co\/IvfiLNvaSY",
    "id" : 720701123192098816,
    "created_at" : "2016-04-14 19:51:52 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 720724763623178240,
  "created_at" : "2016-04-14 21:25:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720611808978071552",
  "text" : "RT @dhammagirl: Take a break from EVERYTHING  you believe in - conditioned thought, let go of all attachments, and see IF and HOW you survi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wakeup",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720563663233527808",
    "text" : "Take a break from EVERYTHING  you believe in - conditioned thought, let go of all attachments, and see IF and HOW you survive.\n\n#wakeup",
    "id" : 720563663233527808,
    "created_at" : "2016-04-14 10:45:39 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 720611808978071552,
  "created_at" : "2016-04-14 13:56:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "indices" : [ 3, 15 ],
      "id_str" : "2147864503",
      "id" : 2147864503
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720609191350702080",
  "text" : "RT @goodbirding: This pair of Mourning Doves are among the many birds that regularly visit my backyard water feature. #birding https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/720568564281929728\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/euqPBMEBCo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf_5ShoXEAAzROB.jpg",
        "id_str" : "720568562063183872",
        "id" : 720568562063183872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf_5ShoXEAAzROB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/euqPBMEBCo"
      } ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720568564281929728",
    "text" : "This pair of Mourning Doves are among the many birds that regularly visit my backyard water feature. #birding https:\/\/t.co\/euqPBMEBCo",
    "id" : 720568564281929728,
    "created_at" : "2016-04-14 11:05:07 +0000",
    "user" : {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "protected" : false,
      "id_str" : "2147864503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630185970\/5de84b9e4fc1f4fdba0d8f537c4d543e_normal.jpeg",
      "id" : 2147864503,
      "verified" : false
    }
  },
  "id" : 720609191350702080,
  "created_at" : "2016-04-14 13:46:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 28, 40 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720356006652280832",
  "text" : "previous RT reminds me that @mindymayhem hasnt tweeted since December. I hope shes ok. I miss her tweets.",
  "id" : 720356006652280832,
  "created_at" : "2016-04-13 21:00:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Gunn",
      "screen_name" : "JamesGunn",
      "indices" : [ 3, 13 ],
      "id_str" : "14982315",
      "id" : 14982315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/4deTT9YO6t",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEJCGw7ozfV\/",
      "display_url" : "instagram.com\/p\/BEJCGw7ozfV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "720354946625896448",
  "text" : "RT @JamesGunn: Have any of you seen or heard from Alison Wu (alisonwuwu)? My dear friend has disappeared since\u2026 https:\/\/t.co\/4deTT9YO6t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/4deTT9YO6t",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BEJCGw7ozfV\/",
        "display_url" : "instagram.com\/p\/BEJCGw7ozfV\/"
      } ]
    },
    "geo" : { },
    "id_str" : "720233436510720000",
    "text" : "Have any of you seen or heard from Alison Wu (alisonwuwu)? My dear friend has disappeared since\u2026 https:\/\/t.co\/4deTT9YO6t",
    "id" : 720233436510720000,
    "created_at" : "2016-04-13 12:53:27 +0000",
    "user" : {
      "name" : "James Gunn",
      "screen_name" : "JamesGunn",
      "protected" : false,
      "id_str" : "14982315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450338547187216384\/wl-PPXR0_normal.jpeg",
      "id" : 14982315,
      "verified" : true
    }
  },
  "id" : 720354946625896448,
  "created_at" : "2016-04-13 20:56:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/9B0SVDqyS7",
      "expanded_url" : "http:\/\/goo.gl\/pnoZus",
      "display_url" : "goo.gl\/pnoZus"
    } ]
  },
  "geo" : { },
  "id_str" : "720282512165974017",
  "text" : "RT @dailygalaxy: The Perseus Signal -- \"What We Found Could Not Be Explained by Known Physics\" (Most Liked)  https:\/\/t.co\/9B0SVDqyS7 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/720273321804169216\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/PEZ4XanC6k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7sxO5UMAAzPC3.jpg",
        "id_str" : "720273320982097920",
        "id" : 720273320982097920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7sxO5UMAAzPC3.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PEZ4XanC6k"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/9B0SVDqyS7",
        "expanded_url" : "http:\/\/goo.gl\/pnoZus",
        "display_url" : "goo.gl\/pnoZus"
      } ]
    },
    "geo" : { },
    "id_str" : "720273321804169216",
    "text" : "The Perseus Signal -- \"What We Found Could Not Be Explained by Known Physics\" (Most Liked)  https:\/\/t.co\/9B0SVDqyS7 https:\/\/t.co\/PEZ4XanC6k",
    "id" : 720273321804169216,
    "created_at" : "2016-04-13 15:31:56 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 720282512165974017,
  "created_at" : "2016-04-13 16:08:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501758894671413248\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/L7KJ8lkhnA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvabDlrIgAAzmx0.jpg",
      "id_str" : "501758894453325824",
      "id" : 501758894453325824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvabDlrIgAAzmx0.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      } ],
      "display_url" : "pic.twitter.com\/L7KJ8lkhnA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720268286596808709",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/L7KJ8lkhnA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501758894671413248\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/L7KJ8lkhnA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvabDlrIgAAzmx0.jpg",
        "id_str" : "501758894453325824",
        "id" : 501758894453325824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvabDlrIgAAzmx0.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        } ],
        "display_url" : "pic.twitter.com\/L7KJ8lkhnA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720252754468339715",
    "text" : "https:\/\/t.co\/L7KJ8lkhnA",
    "id" : 720252754468339715,
    "created_at" : "2016-04-13 14:10:12 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 720268286596808709,
  "created_at" : "2016-04-13 15:11:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/HLIJuja1Jp",
      "expanded_url" : "http:\/\/goo.gl\/fv1RCv",
      "display_url" : "goo.gl\/fv1RCv"
    } ]
  },
  "geo" : { },
  "id_str" : "720268039569039360",
  "text" : "RT @dailygalaxy: We're Close to Unlocking the Neutrino Enigma --\"Could Be Both Matter and Antimatter\" https:\/\/t.co\/HLIJuja1Jp https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/720259106074787840\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/f2IFkIFTPz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7f1vWVAAAP_Tn.jpg",
        "id_str" : "720259104762036224",
        "id" : 720259104762036224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7f1vWVAAAP_Tn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/f2IFkIFTPz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/HLIJuja1Jp",
        "expanded_url" : "http:\/\/goo.gl\/fv1RCv",
        "display_url" : "goo.gl\/fv1RCv"
      } ]
    },
    "geo" : { },
    "id_str" : "720259106074787840",
    "text" : "We're Close to Unlocking the Neutrino Enigma --\"Could Be Both Matter and Antimatter\" https:\/\/t.co\/HLIJuja1Jp https:\/\/t.co\/f2IFkIFTPz",
    "id" : 720259106074787840,
    "created_at" : "2016-04-13 14:35:27 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 720268039569039360,
  "created_at" : "2016-04-13 15:10:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/BRy7ysll3R",
      "expanded_url" : "https:\/\/twitter.com\/RyanHoliday\/status\/719958206462603264",
      "display_url" : "twitter.com\/RyanHoliday\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720259374736736256",
  "text" : "hmm.. interesting video... https:\/\/t.co\/BRy7ysll3R",
  "id" : 720259374736736256,
  "created_at" : "2016-04-13 14:36:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MU Music & Theater",
      "screen_name" : "MonmouthUMusic",
      "indices" : [ 3, 18 ],
      "id_str" : "2800428025",
      "id" : 2800428025
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MonmouthUMusic\/status\/718145147112988672\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/07xjY23Ure",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfddNJwXIAIoQfD.jpg",
      "id_str" : "718145146127327234",
      "id" : 718145146127327234,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfddNJwXIAIoQfD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1146,
        "resize" : "fit",
        "w" : 914
      }, {
        "h" : 1146,
        "resize" : "fit",
        "w" : 914
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/07xjY23Ure"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720257341501771776",
  "text" : "RT @MonmouthUMusic: Audition to be a part of an audiobook recorded by Blue Hawk Studio and Dean Kenneth Womack. https:\/\/t.co\/07xjY23Ure",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MonmouthUMusic\/status\/718145147112988672\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/07xjY23Ure",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfddNJwXIAIoQfD.jpg",
        "id_str" : "718145146127327234",
        "id" : 718145146127327234,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfddNJwXIAIoQfD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1146,
          "resize" : "fit",
          "w" : 914
        }, {
          "h" : 1146,
          "resize" : "fit",
          "w" : 914
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/07xjY23Ure"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718145147112988672",
    "text" : "Audition to be a part of an audiobook recorded by Blue Hawk Studio and Dean Kenneth Womack. https:\/\/t.co\/07xjY23Ure",
    "id" : 718145147112988672,
    "created_at" : "2016-04-07 18:35:20 +0000",
    "user" : {
      "name" : "MU Music & Theater",
      "screen_name" : "MonmouthUMusic",
      "protected" : false,
      "id_str" : "2800428025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755477152653508608\/v6ljqoIh_normal.jpg",
      "id" : 2800428025,
      "verified" : false
    }
  },
  "id" : 720257341501771776,
  "created_at" : "2016-04-13 14:28:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/720255718813773825\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/oKcU6EZNv2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7cwf4WEAAwtto.jpg",
      "id_str" : "720255716175515648",
      "id" : 720255716175515648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7cwf4WEAAwtto.jpg",
      "sizes" : [ {
        "h" : 823,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 636,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oKcU6EZNv2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/Rl2CHW0qfL",
      "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2016\/04\/ted-cruz-dildo-ban-sex-devices-texas?_ts=1460557316",
      "display_url" : "motherjones.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720255718813773825",
  "text" : "The Time Ted Cruz Defended a Ban on Dildos https:\/\/t.co\/Rl2CHW0qfL https:\/\/t.co\/oKcU6EZNv2",
  "id" : 720255718813773825,
  "created_at" : "2016-04-13 14:21:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/owIN61rSSJ",
      "expanded_url" : "https:\/\/twitter.com\/DavidCornDC\/status\/720228557369315328",
      "display_url" : "twitter.com\/DavidCornDC\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720254444445765632",
  "text" : "seriously?? o-O https:\/\/t.co\/owIN61rSSJ",
  "id" : 720254444445765632,
  "created_at" : "2016-04-13 14:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Freeman",
      "screen_name" : "DannyEFreeman",
      "indices" : [ 3, 17 ],
      "id_str" : "35221731",
      "id" : 35221731
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "indices" : [ 20, 34 ],
      "id_str" : "216776631",
      "id" : 216776631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandersStroll",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720033114836348929",
  "text" : "RT @DannyEFreeman: .@BernieSanders takes a #SandersStroll and tour of the grounds of FDR's House &amp; Library in Hyde Park, NY. https:\/\/t.co\/h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Sanders",
        "screen_name" : "BernieSanders",
        "indices" : [ 1, 15 ],
        "id_str" : "216776631",
        "id" : 216776631
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DannyEFreeman\/status\/720020232425881600\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/h4j0QAmW57",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf4GhjmW8AAgvoN.jpg",
        "id_str" : "720020163987435520",
        "id" : 720020163987435520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf4GhjmW8AAgvoN.jpg",
        "sizes" : [ {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/h4j0QAmW57"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/DannyEFreeman\/status\/720020232425881600\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/h4j0QAmW57",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf4GhlLWwAUN7kp.jpg",
        "id_str" : "720020164411047941",
        "id" : 720020164411047941,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf4GhlLWwAUN7kp.jpg",
        "sizes" : [ {
          "h" : 585,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/h4j0QAmW57"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/DannyEFreeman\/status\/720020232425881600\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/h4j0QAmW57",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf4GhmVXIAAtkWJ.jpg",
        "id_str" : "720020164721451008",
        "id" : 720020164721451008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf4GhmVXIAAtkWJ.jpg",
        "sizes" : [ {
          "h" : 319,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/h4j0QAmW57"
      } ],
      "hashtags" : [ {
        "text" : "SandersStroll",
        "indices" : [ 24, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720020232425881600",
    "text" : ".@BernieSanders takes a #SandersStroll and tour of the grounds of FDR's House &amp; Library in Hyde Park, NY. https:\/\/t.co\/h4j0QAmW57",
    "id" : 720020232425881600,
    "created_at" : "2016-04-12 22:46:15 +0000",
    "user" : {
      "name" : "Danny Freeman",
      "screen_name" : "DannyEFreeman",
      "protected" : false,
      "id_str" : "35221731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728337081651564545\/ke-rORt2_normal.jpg",
      "id" : 35221731,
      "verified" : false
    }
  },
  "id" : 720033114836348929,
  "created_at" : "2016-04-12 23:37:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "indices" : [ 3, 15 ],
      "id_str" : "1370358499",
      "id" : 1370358499
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/719768072660365313\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/S5Hsbnzx24",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf0hNJNXIAEIMS7.jpg",
      "id_str" : "719768025143123969",
      "id" : 719768025143123969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf0hNJNXIAEIMS7.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/S5Hsbnzx24"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719971108640919558",
  "text" : "RT @lisasardini: Pastoral in evening light https:\/\/t.co\/S5Hsbnzx24",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/719768072660365313\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/S5Hsbnzx24",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf0hNJNXIAEIMS7.jpg",
        "id_str" : "719768025143123969",
        "id" : 719768025143123969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf0hNJNXIAEIMS7.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/S5Hsbnzx24"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719768072660365313",
    "text" : "Pastoral in evening light https:\/\/t.co\/S5Hsbnzx24",
    "id" : 719768072660365313,
    "created_at" : "2016-04-12 06:04:15 +0000",
    "user" : {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "protected" : false,
      "id_str" : "1370358499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794929677102092289\/U4HUzkeG_normal.jpg",
      "id" : 1370358499,
      "verified" : false
    }
  },
  "id" : 719971108640919558,
  "created_at" : "2016-04-12 19:31:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/0OqTaBPpF1",
      "expanded_url" : "https:\/\/twitter.com\/Gregonimo\/status\/719899981428105217",
      "display_url" : "twitter.com\/Gregonimo\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719904551764172800",
  "text" : "o-O https:\/\/t.co\/0OqTaBPpF1",
  "id" : 719904551764172800,
  "created_at" : "2016-04-12 15:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719903541880623105",
  "text" : "RT @micahjmurray: How boring is your life (or how insecure your masculinity) for you to make a WHOLE FREAKING CONFERENCE just to say women\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CBMW16",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719888490146738176",
    "text" : "How boring is your life (or how insecure your masculinity) for you to make a WHOLE FREAKING CONFERENCE just to say women can't lead? #CBMW16",
    "id" : 719888490146738176,
    "created_at" : "2016-04-12 14:02:45 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 719903541880623105,
  "created_at" : "2016-04-12 15:02:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khaled Beydoun",
      "screen_name" : "KhaledBeydoun",
      "indices" : [ 3, 17 ],
      "id_str" : "2163076560",
      "id" : 2163076560
    }, {
      "name" : "Sarah Kendzior",
      "screen_name" : "sarahkendzior",
      "indices" : [ 39, 53 ],
      "id_str" : "47475039",
      "id" : 47475039
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KhaledBeydoun\/status\/712051820282167296\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/R9JYBW7XFC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeG3W4BW4AEgmum.jpg",
      "id_str" : "712051819724333057",
      "id" : 712051819724333057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeG3W4BW4AEgmum.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R9JYBW7XFC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719884597165731840",
  "text" : "RT @KhaledBeydoun: Powerful words from @sarahkendzior https:\/\/t.co\/R9JYBW7XFC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Kendzior",
        "screen_name" : "sarahkendzior",
        "indices" : [ 20, 34 ],
        "id_str" : "47475039",
        "id" : 47475039
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KhaledBeydoun\/status\/712051820282167296\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/R9JYBW7XFC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeG3W4BW4AEgmum.jpg",
        "id_str" : "712051819724333057",
        "id" : 712051819724333057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeG3W4BW4AEgmum.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/R9JYBW7XFC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712051820282167296",
    "text" : "Powerful words from @sarahkendzior https:\/\/t.co\/R9JYBW7XFC",
    "id" : 712051820282167296,
    "created_at" : "2016-03-21 23:02:37 +0000",
    "user" : {
      "name" : "Khaled Beydoun",
      "screen_name" : "KhaledBeydoun",
      "protected" : false,
      "id_str" : "2163076560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800931977989763072\/yZQ2A-wU_normal.jpg",
      "id" : 2163076560,
      "verified" : true
    }
  },
  "id" : 719884597165731840,
  "created_at" : "2016-04-12 13:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soul Anatomy",
      "screen_name" : "soulanatomymag",
      "indices" : [ 3, 18 ],
      "id_str" : "3295908479",
      "id" : 3295908479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719884495630024704",
  "text" : "RT @soulanatomymag: 'Constellations look like cells; veins in arms look like veins in leaves. Science does not threaten divinity, it is div\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715260579779194880",
    "text" : "'Constellations look like cells; veins in arms look like veins in leaves. Science does not threaten divinity, it is divinity.'",
    "id" : 715260579779194880,
    "created_at" : "2016-03-30 19:33:05 +0000",
    "user" : {
      "name" : "Soul Anatomy",
      "screen_name" : "soulanatomymag",
      "protected" : false,
      "id_str" : "3295908479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698183496515190784\/HCnXC4YX_normal.png",
      "id" : 3295908479,
      "verified" : false
    }
  },
  "id" : 719884495630024704,
  "created_at" : "2016-04-12 13:46:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tia Runion",
      "screen_name" : "tkrunion",
      "indices" : [ 3, 12 ],
      "id_str" : "237342698",
      "id" : 237342698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719884302876569601",
  "text" : "RT @tkrunion: The best conversations happen when you're comfortable enough to think out loud.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392186166625464320",
    "text" : "The best conversations happen when you're comfortable enough to think out loud.",
    "id" : 392186166625464320,
    "created_at" : "2013-10-21 07:10:43 +0000",
    "user" : {
      "name" : "Tia Runion",
      "screen_name" : "tkrunion",
      "protected" : false,
      "id_str" : "237342698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1956738579\/Photo_on_2011-03-15_at_18.57__2_normal.jpg",
      "id" : 237342698,
      "verified" : false
    }
  },
  "id" : 719884302876569601,
  "created_at" : "2016-04-12 13:46:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/x2c11zmCeS",
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/718411591549652993",
      "display_url" : "twitter.com\/nytimes\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719884210031443968",
  "text" : "how cool..lol https:\/\/t.co\/x2c11zmCeS",
  "id" : 719884210031443968,
  "created_at" : "2016-04-12 13:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ingrid Burrington",
      "screen_name" : "lifewinning",
      "indices" : [ 3, 15 ],
      "id_str" : "348082699",
      "id" : 348082699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719882652355018752",
  "text" : "RT @lifewinning: BREAKING: MOST ADULTS STILL LEARNING HOW TO BE HUMAN, FALTERING AND TERRIFIED, PROBABLY GONNA FUCK IT UP SOMETIMES",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "719718675591389184",
    "geo" : { },
    "id_str" : "719719836901908480",
    "in_reply_to_user_id" : 348082699,
    "text" : "BREAKING: MOST ADULTS STILL LEARNING HOW TO BE HUMAN, FALTERING AND TERRIFIED, PROBABLY GONNA FUCK IT UP SOMETIMES",
    "id" : 719719836901908480,
    "in_reply_to_status_id" : 719718675591389184,
    "created_at" : "2016-04-12 02:52:35 +0000",
    "in_reply_to_screen_name" : "lifewinning",
    "in_reply_to_user_id_str" : "348082699",
    "user" : {
      "name" : "Ingrid Burrington",
      "screen_name" : "lifewinning",
      "protected" : false,
      "id_str" : "348082699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1612672528\/netwk_normal.jpg",
      "id" : 348082699,
      "verified" : false
    }
  },
  "id" : 719882652355018752,
  "created_at" : "2016-04-12 13:39:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/SZxaoujbVk",
      "expanded_url" : "https:\/\/vine.co\/v\/iTP1td7X2Kw",
      "display_url" : "vine.co\/v\/iTP1td7X2Kw"
    } ]
  },
  "geo" : { },
  "id_str" : "719879643696914432",
  "text" : "RT @1CatShepherd: Bear &amp; his best buddy Ovenmitt having a cuddle while the human has lunch https:\/\/t.co\/SZxaoujbVk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/SZxaoujbVk",
        "expanded_url" : "https:\/\/vine.co\/v\/iTP1td7X2Kw",
        "display_url" : "vine.co\/v\/iTP1td7X2Kw"
      } ]
    },
    "geo" : { },
    "id_str" : "719872832021340160",
    "text" : "Bear &amp; his best buddy Ovenmitt having a cuddle while the human has lunch https:\/\/t.co\/SZxaoujbVk",
    "id" : 719872832021340160,
    "created_at" : "2016-04-12 13:00:32 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 719879643696914432,
  "created_at" : "2016-04-12 13:27:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/719552994434490368\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/XNLMWzMVWR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfxdosIWwAAWoJ-.jpg",
      "id_str" : "719552994094792704",
      "id" : 719552994094792704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfxdosIWwAAWoJ-.jpg",
      "sizes" : [ {
        "h" : 559,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/XNLMWzMVWR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719556208651288577",
  "text" : "RT @wildwitchyju: Coming across lots of wee winged ones nesting on the nursery. Robins nest. Bless. \uD83D\uDC96 https:\/\/t.co\/XNLMWzMVWR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/719552994434490368\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/XNLMWzMVWR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfxdosIWwAAWoJ-.jpg",
        "id_str" : "719552994094792704",
        "id" : 719552994094792704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfxdosIWwAAWoJ-.jpg",
        "sizes" : [ {
          "h" : 559,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/XNLMWzMVWR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719552994434490368",
    "text" : "Coming across lots of wee winged ones nesting on the nursery. Robins nest. Bless. \uD83D\uDC96 https:\/\/t.co\/XNLMWzMVWR",
    "id" : 719552994434490368,
    "created_at" : "2016-04-11 15:49:37 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 719556208651288577,
  "created_at" : "2016-04-11 16:02:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/719553835174334465\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ZCQ8YsKRLL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfxeZeQW8AAh7AH.jpg",
      "id_str" : "719553832183853056",
      "id" : 719553832183853056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfxeZeQW8AAh7AH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZCQ8YsKRLL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/A1sgLGlc8l",
      "expanded_url" : "https:\/\/www.facebook.com\/cwrescue\/posts\/10156694553740063?_ts=1460389976",
      "display_url" : "facebook.com\/cwrescue\/posts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719553835174334465",
  "text" : "Knitters and crocheters needed to help baby... https:\/\/t.co\/A1sgLGlc8l https:\/\/t.co\/ZCQ8YsKRLL",
  "id" : 719553835174334465,
  "created_at" : "2016-04-11 15:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719529140098113537",
  "text" : "RT @brainpicker: The White Cat and the Monk \u2014 a lovely 9th-century ode to the joy of uncompetitive purposefulness, newly illustrated https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/iCktRqVY2f",
        "expanded_url" : "https:\/\/www.brainpickings.org\/2016\/04\/11\/the-white-cat-and-the-monk\/",
        "display_url" : "brainpickings.org\/2016\/04\/11\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719495735461429250",
    "text" : "The White Cat and the Monk \u2014 a lovely 9th-century ode to the joy of uncompetitive purposefulness, newly illustrated https:\/\/t.co\/iCktRqVY2f",
    "id" : 719495735461429250,
    "created_at" : "2016-04-11 12:02:05 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 719529140098113537,
  "created_at" : "2016-04-11 14:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ChbHrWjPaj",
      "expanded_url" : "http:\/\/po.st\/yjQpqZ",
      "display_url" : "po.st\/yjQpqZ"
    } ]
  },
  "geo" : { },
  "id_str" : "719527039489941504",
  "text" : "only $15 million was given to investigate 9\/11. Compare that to the over $60 million that was spent inves... https:\/\/t.co\/ChbHrWjPaj",
  "id" : 719527039489941504,
  "created_at" : "2016-04-11 14:06:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/VLLV89ur4K",
      "expanded_url" : "http:\/\/flip.it\/XP5oi",
      "display_url" : "flip.it\/XP5oi"
    } ]
  },
  "geo" : { },
  "id_str" : "719526484344446976",
  "text" : "RT @5thdimdreamz: A Senator Just Went on 60 Minutes Claiming the 9\/11 Attackers \u201CHad Support from Within the US\u201D https:\/\/t.co\/VLLV89ur4K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/VLLV89ur4K",
        "expanded_url" : "http:\/\/flip.it\/XP5oi",
        "display_url" : "flip.it\/XP5oi"
      } ]
    },
    "geo" : { },
    "id_str" : "719414459643498497",
    "text" : "A Senator Just Went on 60 Minutes Claiming the 9\/11 Attackers \u201CHad Support from Within the US\u201D https:\/\/t.co\/VLLV89ur4K",
    "id" : 719414459643498497,
    "created_at" : "2016-04-11 06:39:07 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 719526484344446976,
  "created_at" : "2016-04-11 14:04:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "indices" : [ 3, 14 ],
      "id_str" : "417189310",
      "id" : 417189310
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DianeJReed\/status\/719513832759005184\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/GNDj8VscbJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfw6BMEUkAE48PR.jpg",
      "id_str" : "719513832566067201",
      "id" : 719513832566067201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfw6BMEUkAE48PR.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GNDj8VscbJ"
    } ],
    "hashtags" : [ {
      "text" : "step",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "believe",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "breakthrough",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719520498460319746",
  "text" : "RT @DianeJReed: Remember, all you have to do is take the next #step...\n\n#believe\n\n#breakthrough https:\/\/t.co\/GNDj8VscbJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DianeJReed\/status\/719513832759005184\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/GNDj8VscbJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfw6BMEUkAE48PR.jpg",
        "id_str" : "719513832566067201",
        "id" : 719513832566067201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfw6BMEUkAE48PR.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GNDj8VscbJ"
      } ],
      "hashtags" : [ {
        "text" : "step",
        "indices" : [ 46, 51 ]
      }, {
        "text" : "believe",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "breakthrough",
        "indices" : [ 66, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719513832759005184",
    "text" : "Remember, all you have to do is take the next #step...\n\n#believe\n\n#breakthrough https:\/\/t.co\/GNDj8VscbJ",
    "id" : 719513832759005184,
    "created_at" : "2016-04-11 13:14:00 +0000",
    "user" : {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "protected" : false,
      "id_str" : "417189310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695055759181160448\/du6nVVbQ_normal.jpg",
      "id" : 417189310,
      "verified" : false
    }
  },
  "id" : 719520498460319746,
  "created_at" : "2016-04-11 13:40:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Highland Cows",
      "screen_name" : "Highland_Cows",
      "indices" : [ 3, 17 ],
      "id_str" : "4713471382",
      "id" : 4713471382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Highland_Cows\/status\/719171329157677056\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/H6shPfCmvm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfsCg0BWwAE4wGS.jpg",
      "id_str" : "719171328239124481",
      "id" : 719171328239124481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfsCg0BWwAE4wGS.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/H6shPfCmvm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719186627931815938",
  "text" : "RT @Highland_Cows: What you looking at? https:\/\/t.co\/H6shPfCmvm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Highland_Cows\/status\/719171329157677056\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/H6shPfCmvm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfsCg0BWwAE4wGS.jpg",
        "id_str" : "719171328239124481",
        "id" : 719171328239124481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfsCg0BWwAE4wGS.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/H6shPfCmvm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719171329157677056",
    "text" : "What you looking at? https:\/\/t.co\/H6shPfCmvm",
    "id" : 719171329157677056,
    "created_at" : "2016-04-10 14:33:01 +0000",
    "user" : {
      "name" : "Highland Cows",
      "screen_name" : "Highland_Cows",
      "protected" : false,
      "id_str" : "4713471382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728252343079346178\/HIrhUjvN_normal.jpg",
      "id" : 4713471382,
      "verified" : false
    }
  },
  "id" : 719186627931815938,
  "created_at" : "2016-04-10 15:33:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 3, 12 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719186500177510400",
  "text" : "RT @Pontifex: It is important for a child to feel wanted. He or she is not an accessory or a solution to some personal need.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719178171405324290",
    "text" : "It is important for a child to feel wanted. He or she is not an accessory or a solution to some personal need.",
    "id" : 719178171405324290,
    "created_at" : "2016-04-10 15:00:12 +0000",
    "user" : {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "protected" : false,
      "id_str" : "500704345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507818066814590976\/KNG-IkT9_normal.jpeg",
      "id" : 500704345,
      "verified" : true
    }
  },
  "id" : 719186500177510400,
  "created_at" : "2016-04-10 15:33:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "indices" : [ 3, 14 ],
      "id_str" : "220895419",
      "id" : 220895419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/7faDo0eg5C",
      "expanded_url" : "http:\/\/ift.tt\/1RMD82U",
      "display_url" : "ift.tt\/1RMD82U"
    } ]
  },
  "geo" : { },
  "id_str" : "719186283726315520",
  "text" : "RT @WellPlated: Let there be brunch! Baked Peach French Toast\uD83C\uDF51 Easy and sweet, just as a Sunday morning sh\u2026 https:\/\/t.co\/7faDo0eg5C https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WellPlated\/status\/719183174371262464\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/OGcD1M2FBq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfsNSVuWQAIAwsd.jpg",
        "id_str" : "719183174216073218",
        "id" : 719183174216073218,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfsNSVuWQAIAwsd.jpg",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 832,
          "resize" : "fit",
          "w" : 706
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 832,
          "resize" : "fit",
          "w" : 706
        }, {
          "h" : 707,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OGcD1M2FBq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/7faDo0eg5C",
        "expanded_url" : "http:\/\/ift.tt\/1RMD82U",
        "display_url" : "ift.tt\/1RMD82U"
      } ]
    },
    "geo" : { },
    "id_str" : "719183174371262464",
    "text" : "Let there be brunch! Baked Peach French Toast\uD83C\uDF51 Easy and sweet, just as a Sunday morning sh\u2026 https:\/\/t.co\/7faDo0eg5C https:\/\/t.co\/OGcD1M2FBq",
    "id" : 719183174371262464,
    "created_at" : "2016-04-10 15:20:05 +0000",
    "user" : {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "protected" : false,
      "id_str" : "220895419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621711174824914944\/lOVoCMeS_normal.jpg",
      "id" : 220895419,
      "verified" : false
    }
  },
  "id" : 719186283726315520,
  "created_at" : "2016-04-10 15:32:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/DXAlGZkjke",
      "expanded_url" : "https:\/\/vine.co\/v\/hh2VJ6Qelqw",
      "display_url" : "vine.co\/v\/hh2VJ6Qelqw"
    } ]
  },
  "geo" : { },
  "id_str" : "719161198684610560",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDE3A\uD83C\uDF88\uD83D\uDC2F\uD83C\uDF52\uD83C\uDF1E\uD83D\uDC3E \"Hey ... Don't be a lazy boy ... You know what I need ... \" https:\/\/t.co\/DXAlGZkjke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/DXAlGZkjke",
        "expanded_url" : "https:\/\/vine.co\/v\/hh2VJ6Qelqw",
        "display_url" : "vine.co\/v\/hh2VJ6Qelqw"
      } ]
    },
    "geo" : { },
    "id_str" : "719107587204059136",
    "text" : "\uD83D\uDC3E\uD83D\uDE3A\uD83C\uDF88\uD83D\uDC2F\uD83C\uDF52\uD83C\uDF1E\uD83D\uDC3E \"Hey ... Don't be a lazy boy ... You know what I need ... \" https:\/\/t.co\/DXAlGZkjke",
    "id" : 719107587204059136,
    "created_at" : "2016-04-10 10:19:43 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 719161198684610560,
  "created_at" : "2016-04-10 13:52:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/wdcUNIL5A8",
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/719074020696727552",
      "display_url" : "twitter.com\/Swanwhisperer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719160431735136261",
  "text" : "beautiful shot! https:\/\/t.co\/wdcUNIL5A8",
  "id" : 719160431735136261,
  "created_at" : "2016-04-10 13:49:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/bdwXCtMPyC",
      "expanded_url" : "http:\/\/m.atchuup.com\/?p=16041",
      "display_url" : "m.atchuup.com\/?p=16041"
    } ]
  },
  "geo" : { },
  "id_str" : "719155726506160128",
  "text" : "I Wish This Australian Guy Is My Neighbour\u2026 He\u2019s A Riot!  https:\/\/t.co\/bdwXCtMPyC",
  "id" : 719155726506160128,
  "created_at" : "2016-04-10 13:31:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/RkOv59kSQq",
      "expanded_url" : "https:\/\/twitter.com\/AdamsFlaFan\/status\/718610975163838464",
      "display_url" : "twitter.com\/AdamsFlaFan\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718850118745722880",
  "text" : "my life went to hell after getting interested in politics.. sooo.. https:\/\/t.co\/RkOv59kSQq",
  "id" : 718850118745722880,
  "created_at" : "2016-04-09 17:16:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/HdOMeDryRi",
      "expanded_url" : "https:\/\/vine.co\/v\/iT7n05pEK9J",
      "display_url" : "vine.co\/v\/iT7n05pEK9J"
    } ]
  },
  "geo" : { },
  "id_str" : "718847993047343104",
  "text" : "RT @ravenmaster1: Raven cuddles https:\/\/t.co\/HdOMeDryRi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/HdOMeDryRi",
        "expanded_url" : "https:\/\/vine.co\/v\/iT7n05pEK9J",
        "display_url" : "vine.co\/v\/iT7n05pEK9J"
      } ]
    },
    "geo" : { },
    "id_str" : "718809843964973056",
    "text" : "Raven cuddles https:\/\/t.co\/HdOMeDryRi",
    "id" : 718809843964973056,
    "created_at" : "2016-04-09 14:36:36 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 718847993047343104,
  "created_at" : "2016-04-09 17:08:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718847424207433728",
  "text" : "RT @UnseelieMe: Also? Yes, I have been cow tipping. Its not as funny as you think. Dont do it. It terrorizes the cows &amp; they cant produce m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718841433810202624",
    "text" : "Also? Yes, I have been cow tipping. Its not as funny as you think. Dont do it. It terrorizes the cows &amp; they cant produce milk for days.",
    "id" : 718841433810202624,
    "created_at" : "2016-04-09 16:42:07 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 718847424207433728,
  "created_at" : "2016-04-09 17:05:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718785603479990272",
  "text" : "RT @AWorldOutOfMind: the open mind is open most importantly and above all else to the possibility that it can be wrong",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718612610703368192",
    "text" : "the open mind is open most importantly and above all else to the possibility that it can be wrong",
    "id" : 718612610703368192,
    "created_at" : "2016-04-09 01:32:52 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 718785603479990272,
  "created_at" : "2016-04-09 13:00:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718558470782509056",
  "geo" : { },
  "id_str" : "718582134370410500",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep heehee",
  "id" : 718582134370410500,
  "in_reply_to_status_id" : 718558470782509056,
  "created_at" : "2016-04-08 23:31:46 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718538324202373121",
  "geo" : { },
  "id_str" : "718550004550483968",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 love the other 2 watching through the door : )",
  "id" : 718550004550483968,
  "in_reply_to_status_id" : 718538324202373121,
  "created_at" : "2016-04-08 21:24:05 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CV2jQdtfK6",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/4\/8\/11385786\/clinton-sanders-supporters-beliefs?utm_campaign=vox&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "vox.com\/2016\/4\/8\/11385\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718430532435066880",
  "text" : "RT @voxdotcom: On Twitter, Bernie fans &amp; Hillary fans are at war. In the real world, it's much more peaceful. https:\/\/t.co\/CV2jQdtfK6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sbnation.com\" rel=\"nofollow\"\u003ESB Nation\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/CV2jQdtfK6",
        "expanded_url" : "http:\/\/www.vox.com\/2016\/4\/8\/11385786\/clinton-sanders-supporters-beliefs?utm_campaign=vox&utm_content=chorus&utm_medium=social&utm_source=twitter",
        "display_url" : "vox.com\/2016\/4\/8\/11385\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718423200770703360",
    "text" : "On Twitter, Bernie fans &amp; Hillary fans are at war. In the real world, it's much more peaceful. https:\/\/t.co\/CV2jQdtfK6",
    "id" : 718423200770703360,
    "created_at" : "2016-04-08 13:00:13 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 718430532435066880,
  "created_at" : "2016-04-08 13:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/718245027760185345\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/hLHwsUIGiM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfe4CeXWEAAJc3Q.jpg",
      "id_str" : "718245018239111168",
      "id" : 718245018239111168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfe4CeXWEAAJc3Q.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 456
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 456
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 456
      } ],
      "display_url" : "pic.twitter.com\/hLHwsUIGiM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718246184754749440",
  "text" : "RT @5thdimdreamz: https:\/\/t.co\/hLHwsUIGiM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/718245027760185345\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/hLHwsUIGiM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfe4CeXWEAAJc3Q.jpg",
        "id_str" : "718245018239111168",
        "id" : 718245018239111168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfe4CeXWEAAJc3Q.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 456
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 456
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 456
        } ],
        "display_url" : "pic.twitter.com\/hLHwsUIGiM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718245027760185345",
    "text" : "https:\/\/t.co\/hLHwsUIGiM",
    "id" : 718245027760185345,
    "created_at" : "2016-04-08 01:12:13 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 718246184754749440,
  "created_at" : "2016-04-08 01:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718222544462028803",
  "text" : "The evenings are tough.. I keep wanting to turn on light and check door.",
  "id" : 718222544462028803,
  "created_at" : "2016-04-07 23:42:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/718164056830513153\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/qgwCzXky7c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfduVBeUUAE-1CE.jpg",
      "id_str" : "718163973040787457",
      "id" : 718163973040787457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfduVBeUUAE-1CE.jpg",
      "sizes" : [ {
        "h" : 396,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1193,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1758
      } ],
      "display_url" : "pic.twitter.com\/qgwCzXky7c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718190363597541376",
  "text" : "RT @ErinEFarley: Highland coo on the TARDIS. \uD83D\uDC2E https:\/\/t.co\/qgwCzXky7c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/718164056830513153\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/qgwCzXky7c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfduVBeUUAE-1CE.jpg",
        "id_str" : "718163973040787457",
        "id" : 718163973040787457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfduVBeUUAE-1CE.jpg",
        "sizes" : [ {
          "h" : 396,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1193,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1758
        } ],
        "display_url" : "pic.twitter.com\/qgwCzXky7c"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718164056830513153",
    "text" : "Highland coo on the TARDIS. \uD83D\uDC2E https:\/\/t.co\/qgwCzXky7c",
    "id" : 718164056830513153,
    "created_at" : "2016-04-07 19:50:28 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 718190363597541376,
  "created_at" : "2016-04-07 21:35:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718123144054185985",
  "text" : "We're picking up Ashes' ashes today. He will finally be inside the house with us.",
  "id" : 718123144054185985,
  "created_at" : "2016-04-07 17:07:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "indices" : [ 3, 16 ],
      "id_str" : "530935629",
      "id" : 530935629
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/717922810635505664\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/am6GdCIUrR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfaS2XxUEAE7-GO.jpg",
      "id_str" : "717922653403615233",
      "id" : 717922653403615233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfaS2XxUEAE7-GO.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1245,
        "resize" : "fit",
        "w" : 928
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1245,
        "resize" : "fit",
        "w" : 928
      } ],
      "display_url" : "pic.twitter.com\/am6GdCIUrR"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/717922810635505664\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/am6GdCIUrR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfaS8G7UIAEmes3.jpg",
      "id_str" : "717922751961374721",
      "id" : 717922751961374721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfaS8G7UIAEmes3.jpg",
      "sizes" : [ {
        "h" : 1382,
        "resize" : "fit",
        "w" : 1036
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/am6GdCIUrR"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/717922810635505664\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/am6GdCIUrR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfaS_YyUIAAtcwU.jpg",
      "id_str" : "717922808295071744",
      "id" : 717922808295071744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfaS_YyUIAAtcwU.jpg",
      "sizes" : [ {
        "h" : 1382,
        "resize" : "fit",
        "w" : 1036
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/am6GdCIUrR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718117324784594949",
  "text" : "RT @melinawstaal: wild tom turkey in an oak tree https:\/\/t.co\/am6GdCIUrR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/717922810635505664\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/am6GdCIUrR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfaS2XxUEAE7-GO.jpg",
        "id_str" : "717922653403615233",
        "id" : 717922653403615233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfaS2XxUEAE7-GO.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1245,
          "resize" : "fit",
          "w" : 928
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 805,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1245,
          "resize" : "fit",
          "w" : 928
        } ],
        "display_url" : "pic.twitter.com\/am6GdCIUrR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/717922810635505664\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/am6GdCIUrR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfaS8G7UIAEmes3.jpg",
        "id_str" : "717922751961374721",
        "id" : 717922751961374721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfaS8G7UIAEmes3.jpg",
        "sizes" : [ {
          "h" : 1382,
          "resize" : "fit",
          "w" : 1036
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/am6GdCIUrR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/717922810635505664\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/am6GdCIUrR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfaS_YyUIAAtcwU.jpg",
        "id_str" : "717922808295071744",
        "id" : 717922808295071744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfaS_YyUIAAtcwU.jpg",
        "sizes" : [ {
          "h" : 1382,
          "resize" : "fit",
          "w" : 1036
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/am6GdCIUrR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717922810635505664",
    "text" : "wild tom turkey in an oak tree https:\/\/t.co\/am6GdCIUrR",
    "id" : 717922810635505664,
    "created_at" : "2016-04-07 03:51:51 +0000",
    "user" : {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "protected" : false,
      "id_str" : "530935629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638498065096151042\/DwWC834G_normal.jpg",
      "id" : 530935629,
      "verified" : false
    }
  },
  "id" : 718117324784594949,
  "created_at" : "2016-04-07 16:44:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "feedly",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/yPvekwBhqi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=5fj1fPgSn1E",
      "display_url" : "youtube.com\/watch?v=5fj1fP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718095810202873858",
  "text" : "Send In Your Audio Book Reviews, Get A Free Audio Book!! https:\/\/t.co\/yPvekwBhqi #audiobooks #feedly",
  "id" : 718095810202873858,
  "created_at" : "2016-04-07 15:19:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "indices" : [ 3, 15 ],
      "id_str" : "2147864503",
      "id" : 2147864503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/718036565725999104\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/YuexctFath",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfb6c46W8AAzZFW.jpg",
      "id_str" : "718036564832612352",
      "id" : 718036564832612352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfb6c46W8AAzZFW.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/YuexctFath"
    } ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718094386039504896",
  "text" : "RT @goodbirding: Male Red-bellied Woodpecker emerging from a tree cavity. #birding https:\/\/t.co\/YuexctFath",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/718036565725999104\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/YuexctFath",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfb6c46W8AAzZFW.jpg",
        "id_str" : "718036564832612352",
        "id" : 718036564832612352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfb6c46W8AAzZFW.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/YuexctFath"
      } ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718036565725999104",
    "text" : "Male Red-bellied Woodpecker emerging from a tree cavity. #birding https:\/\/t.co\/YuexctFath",
    "id" : 718036565725999104,
    "created_at" : "2016-04-07 11:23:52 +0000",
    "user" : {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "protected" : false,
      "id_str" : "2147864503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630185970\/5de84b9e4fc1f4fdba0d8f537c4d543e_normal.jpeg",
      "id" : 2147864503,
      "verified" : false
    }
  },
  "id" : 718094386039504896,
  "created_at" : "2016-04-07 15:13:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/WIQ1nxHpgI",
      "expanded_url" : "https:\/\/vote.berniesanders.com\/NY",
      "display_url" : "vote.berniesanders.com\/NY"
    } ]
  },
  "geo" : { },
  "id_str" : "718093844525531136",
  "text" : "Reminder to registered democrats, Primary is April 19. Vote for Bernie in New York! https:\/\/t.co\/WIQ1nxHpgI",
  "id" : 718093844525531136,
  "created_at" : "2016-04-07 15:11:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718029248141922304",
  "text" : "RT @Swanwhisperer: Meet Solo He must be one of Flash's Brood years ago , Hes very friendly and Likes to Sit next to me https:\/\/t.co\/KhCyZJf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/718021569235263488\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/KhCyZJfpuo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfbsz8mWwAApqu_.jpg",
        "id_str" : "718021567796658176",
        "id" : 718021567796658176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfbsz8mWwAApqu_.jpg",
        "sizes" : [ {
          "h" : 2592,
          "resize" : "fit",
          "w" : 1944
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KhCyZJfpuo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/718021569235263488\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/KhCyZJfpuo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfbsuy-WwAAHSwa.jpg",
        "id_str" : "718021479313620992",
        "id" : 718021479313620992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfbsuy-WwAAHSwa.jpg",
        "sizes" : [ {
          "h" : 371,
          "resize" : "fit",
          "w" : 763
        }, {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 763
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KhCyZJfpuo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/718021569235263488\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/KhCyZJfpuo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfbstsOWIAAeOIt.jpg",
        "id_str" : "718021460321771520",
        "id" : 718021460321771520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfbstsOWIAAeOIt.jpg",
        "sizes" : [ {
          "h" : 526,
          "resize" : "fit",
          "w" : 818
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 818
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KhCyZJfpuo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/718021569235263488\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/KhCyZJfpuo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfbsvJfW4AAUKa-.jpg",
        "id_str" : "718021485357621248",
        "id" : 718021485357621248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfbsvJfW4AAUKa-.jpg",
        "sizes" : [ {
          "h" : 537,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KhCyZJfpuo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718021569235263488",
    "text" : "Meet Solo He must be one of Flash's Brood years ago , Hes very friendly and Likes to Sit next to me https:\/\/t.co\/KhCyZJfpuo",
    "id" : 718021569235263488,
    "created_at" : "2016-04-07 10:24:16 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 718029248141922304,
  "created_at" : "2016-04-07 10:54:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/717656818277818368\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/oHDeOv0WFg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfWhEouWsAASOmu.jpg",
      "id_str" : "717656816658853888",
      "id" : 717656816658853888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfWhEouWsAASOmu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 574
      } ],
      "display_url" : "pic.twitter.com\/oHDeOv0WFg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717741949541814272",
  "text" : "RT @Swanwhisperer: Solos back playing with my bag straps https:\/\/t.co\/oHDeOv0WFg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/717656818277818368\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/oHDeOv0WFg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfWhEouWsAASOmu.jpg",
        "id_str" : "717656816658853888",
        "id" : 717656816658853888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfWhEouWsAASOmu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 574
        } ],
        "display_url" : "pic.twitter.com\/oHDeOv0WFg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717656818277818368",
    "text" : "Solos back playing with my bag straps https:\/\/t.co\/oHDeOv0WFg",
    "id" : 717656818277818368,
    "created_at" : "2016-04-06 10:14:53 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 717741949541814272,
  "created_at" : "2016-04-06 15:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noame",
      "screen_name" : "2noame",
      "indices" : [ 3, 10 ],
      "id_str" : "763407955471499264",
      "id" : 763407955471499264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717493292326367233",
  "text" : "RT @2noame: How do you \"protect\" those that believe marriage is between a man &amp; woman? Are they at risk? Do they need rainbow-proof vests?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mississippi",
        "indices" : [ 131, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717491091323248641",
    "text" : "How do you \"protect\" those that believe marriage is between a man &amp; woman? Are they at risk? Do they need rainbow-proof vests? #Mississippi",
    "id" : 717491091323248641,
    "created_at" : "2016-04-05 23:16:21 +0000",
    "user" : {
      "name" : "Scott Santens",
      "screen_name" : "scottsantens",
      "protected" : false,
      "id_str" : "14297863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728327801028239360\/QVZeVLgz_normal.jpg",
      "id" : 14297863,
      "verified" : true
    }
  },
  "id" : 717493292326367233,
  "created_at" : "2016-04-05 23:25:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717476995337158656",
  "text" : "RT @_NealeDWalsch: How may you seek the kingdom of heaven? By providing the kingdom of heaven, with all its blessings, to all those whose l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717472144217804804",
    "text" : "How may you seek the kingdom of heaven? By providing the kingdom of heaven, with all its blessings, to all those whose lives you touch.",
    "id" : 717472144217804804,
    "created_at" : "2016-04-05 22:01:03 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 717476995337158656,
  "created_at" : "2016-04-05 22:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717441291450236928",
  "text" : "DH handed the body over then gave him a pat. (he was wrapped in a blanket) He will be missed.",
  "id" : 717441291450236928,
  "created_at" : "2016-04-05 19:58:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717392336137895936",
  "text" : "Looking at getting my dear boy Ashes cremated. He was a stray but he was mine. &lt;3",
  "id" : 717392336137895936,
  "created_at" : "2016-04-05 16:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rip",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "brokenheart",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717364365360558080",
  "text" : "no reason to turn on porch light anymore as you won't be there waiting for dinner #rip #brokenheart",
  "id" : 717364365360558080,
  "created_at" : "2016-04-05 14:52:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717167801950146561",
  "text" : "Good night, my dear Ashes. I hope to see you at the Rainbow Bridge. I love you.",
  "id" : 717167801950146561,
  "created_at" : "2016-04-05 01:51:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "indices" : [ 3, 18 ],
      "id_str" : "2285980750",
      "id" : 2285980750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ariastarbright\/status\/717135943661170688\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/oIRU6zZaAD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfPHV1HWIAEGDs-.jpg",
      "id_str" : "717135943531110401",
      "id" : 717135943531110401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfPHV1HWIAEGDs-.jpg",
      "sizes" : [ {
        "h" : 557,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 542
      } ],
      "display_url" : "pic.twitter.com\/oIRU6zZaAD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717139392591167488",
  "text" : "RT @ariastarbright: There are people who could hear you speak a thousand words and still not understand you... https:\/\/t.co\/oIRU6zZaAD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ariastarbright\/status\/717135943661170688\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/oIRU6zZaAD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfPHV1HWIAEGDs-.jpg",
        "id_str" : "717135943531110401",
        "id" : 717135943531110401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfPHV1HWIAEGDs-.jpg",
        "sizes" : [ {
          "h" : 557,
          "resize" : "fit",
          "w" : 542
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 542
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 542
        } ],
        "display_url" : "pic.twitter.com\/oIRU6zZaAD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717135943661170688",
    "text" : "There are people who could hear you speak a thousand words and still not understand you... https:\/\/t.co\/oIRU6zZaAD",
    "id" : 717135943661170688,
    "created_at" : "2016-04-04 23:45:07 +0000",
    "user" : {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "protected" : false,
      "id_str" : "2285980750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486310212891340800\/3EUl8sBZ_normal.jpeg",
      "id" : 2285980750,
      "verified" : false
    }
  },
  "id" : 717139392591167488,
  "created_at" : "2016-04-04 23:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 0, 16 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717089982419181568",
  "geo" : { },
  "id_str" : "717099824382914560",
  "in_reply_to_user_id" : 292671486,
  "text" : "@proudliberalmom wtf? jzs.. what is wrong w ppl? ((hugs))",
  "id" : 717099824382914560,
  "in_reply_to_status_id" : 717089982419181568,
  "created_at" : "2016-04-04 21:21:35 +0000",
  "in_reply_to_screen_name" : "proudliberalmom",
  "in_reply_to_user_id_str" : "292671486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Read",
      "screen_name" : "JohnAaronRead",
      "indices" : [ 65, 79 ],
      "id_str" : "1040330642",
      "id" : 1040330642
    }, {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 81, 94 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 8, 14 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/bNagnnhauK",
      "expanded_url" : "http:\/\/audiobookreviewer.com\/reviews\/martian-conspiracy-john-read\/",
      "display_url" : "audiobookreviewer.com\/reviews\/martia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716982349859307520",
  "text" : "Win the #scifi #audiobook #giveaway of The Martian Conspiracy by @JohnAaronRead  @audiobookrev https:\/\/t.co\/bNagnnhauK",
  "id" : 716982349859307520,
  "created_at" : "2016-04-04 13:34:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/716711689018806272\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/NPpxFdf3oV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJFZGgWAAAhaXg.jpg",
      "id_str" : "716711588250648576",
      "id" : 716711588250648576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJFZGgWAAAhaXg.jpg",
      "sizes" : [ {
        "h" : 842,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 842,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NPpxFdf3oV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/716711689018806272\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/NPpxFdf3oV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJFcAmWQAI4DDn.jpg",
      "id_str" : "716711638204825602",
      "id" : 716711638204825602,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJFcAmWQAI4DDn.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NPpxFdf3oV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/716711689018806272\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/NPpxFdf3oV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJFe0tXEAAw59X.jpg",
      "id_str" : "716711686552621056",
      "id" : 716711686552621056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJFe0tXEAAw59X.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NPpxFdf3oV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716739338738995202",
  "text" : "RT @SouthYeoEast: Happy family adoption. Jacob ewe took Zwartbles triplet no questions asked. https:\/\/t.co\/NPpxFdf3oV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/716711689018806272\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/NPpxFdf3oV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJFZGgWAAAhaXg.jpg",
        "id_str" : "716711588250648576",
        "id" : 716711588250648576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJFZGgWAAAhaXg.jpg",
        "sizes" : [ {
          "h" : 842,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NPpxFdf3oV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/716711689018806272\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/NPpxFdf3oV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJFcAmWQAI4DDn.jpg",
        "id_str" : "716711638204825602",
        "id" : 716711638204825602,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJFcAmWQAI4DDn.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NPpxFdf3oV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/716711689018806272\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/NPpxFdf3oV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfJFe0tXEAAw59X.jpg",
        "id_str" : "716711686552621056",
        "id" : 716711686552621056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfJFe0tXEAAw59X.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NPpxFdf3oV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716711689018806272",
    "text" : "Happy family adoption. Jacob ewe took Zwartbles triplet no questions asked. https:\/\/t.co\/NPpxFdf3oV",
    "id" : 716711689018806272,
    "created_at" : "2016-04-03 19:39:17 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 716739338738995202,
  "created_at" : "2016-04-03 21:29:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716738987411513345",
  "text" : "i currently use nexus 7.2 for wifi text and web. 5 mp cam takes awful pics. there's no sd or sim slots and no multi-task.",
  "id" : 716738987411513345,
  "created_at" : "2016-04-03 21:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716738290347548672",
  "text" : "suggestions for #android phone (unlocked); less than $150? multi-tasking (apps). use for audiobooks, texting, pics. wifi for web.",
  "id" : 716738290347548672,
  "created_at" : "2016-04-03 21:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Swanwatch",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716723699978731520",
  "text" : "RT @Swanwhisperer: Any Mute Swan Building in Scotland area Please let me know Collecting Offical Sighting for my Project #Swanwatch https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/716693111347535873\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/AqEmHzILtL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfI0lhOW4AA3pfM.jpg",
        "id_str" : "716693109883723776",
        "id" : 716693109883723776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfI0lhOW4AA3pfM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 882,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 653
        } ],
        "display_url" : "pic.twitter.com\/AqEmHzILtL"
      } ],
      "hashtags" : [ {
        "text" : "Swanwatch",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716704541962551296",
    "text" : "Any Mute Swan Building in Scotland area Please let me know Collecting Offical Sighting for my Project #Swanwatch https:\/\/t.co\/AqEmHzILtL",
    "id" : 716704541962551296,
    "created_at" : "2016-04-03 19:10:53 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 716723699978731520,
  "created_at" : "2016-04-03 20:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716717356148473856",
  "geo" : { },
  "id_str" : "716723559893221377",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides darn.. you caught me. i really am quite nosy. :D",
  "id" : 716723559893221377,
  "in_reply_to_status_id" : 716717356148473856,
  "created_at" : "2016-04-03 20:26:27 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/KJ4Crhkguw",
      "expanded_url" : "https:\/\/twitter.com\/miss_sunkisst\/status\/716664984630112257",
      "display_url" : "twitter.com\/miss_sunkisst\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716688862232322048",
  "text" : "aww, precious! https:\/\/t.co\/KJ4Crhkguw",
  "id" : 716688862232322048,
  "created_at" : "2016-04-03 18:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/716626275918561280\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/29dThRjQyr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfH3zN7UsAQpC1y.jpg",
      "id_str" : "716626275012489220",
      "id" : 716626275012489220,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfH3zN7UsAQpC1y.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 1261
      } ],
      "display_url" : "pic.twitter.com\/29dThRjQyr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716676832175722496",
  "text" : "RT @ChippyCMunk: Chippy not impressed with this April snow https:\/\/t.co\/29dThRjQyr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/716626275918561280\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/29dThRjQyr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfH3zN7UsAQpC1y.jpg",
        "id_str" : "716626275012489220",
        "id" : 716626275012489220,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfH3zN7UsAQpC1y.jpg",
        "sizes" : [ {
          "h" : 643,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1261
        } ],
        "display_url" : "pic.twitter.com\/29dThRjQyr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716626275918561280",
    "text" : "Chippy not impressed with this April snow https:\/\/t.co\/29dThRjQyr",
    "id" : 716626275918561280,
    "created_at" : "2016-04-03 13:59:53 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 716676832175722496,
  "created_at" : "2016-04-03 17:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Fox",
      "screen_name" : "LisaFoxRomance",
      "indices" : [ 3, 18 ],
      "id_str" : "119273893",
      "id" : 119273893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716676802282930177",
  "text" : "RT @LisaFoxRomance: Why is there snow on my pretty green lawn? Who authorized this atrocity???",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716628705360146434",
    "text" : "Why is there snow on my pretty green lawn? Who authorized this atrocity???",
    "id" : 716628705360146434,
    "created_at" : "2016-04-03 14:09:32 +0000",
    "user" : {
      "name" : "Lisa Fox",
      "screen_name" : "LisaFoxRomance",
      "protected" : false,
      "id_str" : "119273893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862346428\/LF_logo_2_normal.JPG",
      "id" : 119273893,
      "verified" : false
    }
  },
  "id" : 716676802282930177,
  "created_at" : "2016-04-03 17:20:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "indices" : [ 3, 18 ],
      "id_str" : "24254537",
      "id" : 24254537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716676706585731072",
  "text" : "RT @GrumpyTheology: After pestering LGBTQ people to give him ONE Bible verse that supports us, he blocks those who respond w\/ several https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GrumpyTheology\/status\/716639085817950209\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/KpOWnsgX8p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfIDc1cWEAAaGi5.jpg",
        "id_str" : "716639084622516224",
        "id" : 716639084622516224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfIDc1cWEAAaGi5.jpg",
        "sizes" : [ {
          "h" : 70,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 141,
          "resize" : "crop",
          "w" : 141
        }, {
          "h" : 124,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 684
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 684
        } ],
        "display_url" : "pic.twitter.com\/KpOWnsgX8p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716639085817950209",
    "text" : "After pestering LGBTQ people to give him ONE Bible verse that supports us, he blocks those who respond w\/ several https:\/\/t.co\/KpOWnsgX8p",
    "id" : 716639085817950209,
    "created_at" : "2016-04-03 14:50:47 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 716676706585731072,
  "created_at" : "2016-04-03 17:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Digital Reader",
      "screen_name" : "inkbitspixels",
      "indices" : [ 3, 17 ],
      "id_str" : "2790546893",
      "id" : 2790546893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/5otsdttVg5",
      "expanded_url" : "http:\/\/ebookne.ws\/1X3PDac",
      "display_url" : "ebookne.ws\/1X3PDac"
    } ]
  },
  "geo" : { },
  "id_str" : "716640395430649856",
  "text" : "RT @inkbitspixels: This One Weird Trick Could Save Space on Your iDevice | The Digital Reader https:\/\/t.co\/5otsdttVg5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/5otsdttVg5",
        "expanded_url" : "http:\/\/ebookne.ws\/1X3PDac",
        "display_url" : "ebookne.ws\/1X3PDac"
      } ]
    },
    "geo" : { },
    "id_str" : "715962238092374017",
    "text" : "This One Weird Trick Could Save Space on Your iDevice | The Digital Reader https:\/\/t.co\/5otsdttVg5",
    "id" : 715962238092374017,
    "created_at" : "2016-04-01 18:01:14 +0000",
    "user" : {
      "name" : "The Digital Reader",
      "screen_name" : "inkbitspixels",
      "protected" : false,
      "id_str" : "2790546893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619304105715089408\/9PRPsrJn_normal.png",
      "id" : 2790546893,
      "verified" : false
    }
  },
  "id" : 716640395430649856,
  "created_at" : "2016-04-03 14:55:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Mataconis",
      "screen_name" : "dmataconis",
      "indices" : [ 3, 14 ],
      "id_str" : "14197312",
      "id" : 14197312
    }, {
      "name" : "Daniel Larison",
      "screen_name" : "DanielLarison",
      "indices" : [ 77, 91 ],
      "id_str" : "787922846",
      "id" : 787922846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JRhodesPianist\/status\/715603080734248960\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/eOHtvexdzn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5VMzGW8AAFRFd.jpg",
      "id_str" : "715603069162156032",
      "id" : 715603069162156032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5VMzGW8AAFRFd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eOHtvexdzn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716640142434443266",
  "text" : "RT @dmataconis: The story behind this sign has got to be pretty awesome (h\/t @DanielLarison) https:\/\/t.co\/eOHtvexdzn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Larison",
        "screen_name" : "DanielLarison",
        "indices" : [ 61, 75 ],
        "id_str" : "787922846",
        "id" : 787922846
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JRhodesPianist\/status\/715603080734248960\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/eOHtvexdzn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5VMzGW8AAFRFd.jpg",
        "id_str" : "715603069162156032",
        "id" : 715603069162156032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5VMzGW8AAFRFd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eOHtvexdzn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716087233812566017",
    "text" : "The story behind this sign has got to be pretty awesome (h\/t @DanielLarison) https:\/\/t.co\/eOHtvexdzn",
    "id" : 716087233812566017,
    "created_at" : "2016-04-02 02:17:55 +0000",
    "user" : {
      "name" : "Doug Mataconis",
      "screen_name" : "dmataconis",
      "protected" : false,
      "id_str" : "14197312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668918765665435652\/lKFJn0se_normal.png",
      "id" : 14197312,
      "verified" : false
    }
  },
  "id" : 716640142434443266,
  "created_at" : "2016-04-03 14:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shanna Germain",
      "screen_name" : "ShannaGermain",
      "indices" : [ 3, 17 ],
      "id_str" : "1439064992",
      "id" : 1439064992
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ShannaGermain\/status\/655945344715325440\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/KUejMivQj5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRpiwGuUEAAu1u3.jpg",
      "id_str" : "655945274313936896",
      "id" : 655945274313936896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRpiwGuUEAAu1u3.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/KUejMivQj5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716626978238021633",
  "text" : "RT @ShannaGermain: Do not teach the squirrels how to play RPGs. http:\/\/t.co\/KUejMivQj5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ShannaGermain\/status\/655945344715325440\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/KUejMivQj5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRpiwGuUEAAu1u3.jpg",
        "id_str" : "655945274313936896",
        "id" : 655945274313936896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRpiwGuUEAAu1u3.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/KUejMivQj5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655945344715325440",
    "text" : "Do not teach the squirrels how to play RPGs. http:\/\/t.co\/KUejMivQj5",
    "id" : 655945344715325440,
    "created_at" : "2015-10-19 03:15:31 +0000",
    "user" : {
      "name" : "Shanna Germain",
      "screen_name" : "ShannaGermain",
      "protected" : false,
      "id_str" : "1439064992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796580967804612608\/xvD4gNF3_normal.jpg",
      "id" : 1439064992,
      "verified" : false
    }
  },
  "id" : 716626978238021633,
  "created_at" : "2016-04-03 14:02:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/nx0fGDk6QP",
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/716601610680590336",
      "display_url" : "twitter.com\/Elverojaguar\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716624964795936768",
  "text" : "\"Treats, please.\" \"Me, too! Me, too!\" https:\/\/t.co\/nx0fGDk6QP",
  "id" : 716624964795936768,
  "created_at" : "2016-04-03 13:54:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lost Drawings",
      "screen_name" : "LostDrawings",
      "indices" : [ 3, 16 ],
      "id_str" : "53700596",
      "id" : 53700596
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LostDrawings\/status\/716383742844084225\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/T4jtVcBsDd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfEbN78UMAEomWk.jpg",
      "id_str" : "716383741971542017",
      "id" : 716383741971542017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfEbN78UMAEomWk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 988
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 988
      }, {
        "h" : 810,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T4jtVcBsDd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716413403624050688",
  "text" : "RT @LostDrawings: John Albert Bauer https:\/\/t.co\/T4jtVcBsDd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LostDrawings\/status\/716383742844084225\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/T4jtVcBsDd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfEbN78UMAEomWk.jpg",
        "id_str" : "716383741971542017",
        "id" : 716383741971542017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfEbN78UMAEomWk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 988
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 988
        }, {
          "h" : 810,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/T4jtVcBsDd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716383742844084225",
    "text" : "John Albert Bauer https:\/\/t.co\/T4jtVcBsDd",
    "id" : 716383742844084225,
    "created_at" : "2016-04-02 21:56:08 +0000",
    "user" : {
      "name" : "Lost Drawings",
      "screen_name" : "LostDrawings",
      "protected" : false,
      "id_str" : "53700596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2595012963\/o0y63xqs5rou1jpfdj05_normal.jpeg",
      "id" : 53700596,
      "verified" : false
    }
  },
  "id" : 716413403624050688,
  "created_at" : "2016-04-02 23:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716393138932334593",
  "text" : "i dont like the fives and i dont like myself. if it hasnt changed by now, will it ever? i still feel \"less than\"",
  "id" : 716393138932334593,
  "created_at" : "2016-04-02 22:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716391644707307522",
  "text" : "RT @johnpavlovitz: \"I thought I knew the grace of Christ. I had no clue.\"\n\nHow Love Wins: Moms of LGBTQ Children Share Their Stories... htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/NHnFX3kPuH",
        "expanded_url" : "http:\/\/johnpavlovitz.com\/2016\/04\/01\/love-wins-moms-lgbtq-children-share-stories-part-1\/?utm_campaign=coschedule&utm_source=twitter&utm_medium=johnpavlovitz&utm_content=How%20Love%20Wins%3A%20Moms%20of%20LGBTQ%20Children%20Share%20Their%20Stories%2C%20Part%201",
        "display_url" : "johnpavlovitz.com\/2016\/04\/01\/lov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716384746566234112",
    "text" : "\"I thought I knew the grace of Christ. I had no clue.\"\n\nHow Love Wins: Moms of LGBTQ Children Share Their Stories... https:\/\/t.co\/NHnFX3kPuH",
    "id" : 716384746566234112,
    "created_at" : "2016-04-02 22:00:08 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 716391644707307522,
  "created_at" : "2016-04-02 22:27:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/JDDDw7xkrH",
      "expanded_url" : "https:\/\/twitter.com\/UnseelieMe\/status\/716286562980536320",
      "display_url" : "twitter.com\/UnseelieMe\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716290514899836928",
  "text" : "i didnt realize how much anxiety DD endured from school. essentially becomes trauma. https:\/\/t.co\/JDDDw7xkrH",
  "id" : 716290514899836928,
  "created_at" : "2016-04-02 15:45:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716288480901464066",
  "text" : "anyone use mp3 players or sandisk clips for #audiobooks ? use my nexus 7.2 w bluetooth speaker. buttons wld be handy when interrupted.",
  "id" : 716288480901464066,
  "created_at" : "2016-04-02 15:37:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/PhPweopVAR",
      "expanded_url" : "https:\/\/youtu.be\/9VJ2iU4QVDw",
      "display_url" : "youtu.be\/9VJ2iU4QVDw"
    } ]
  },
  "geo" : { },
  "id_str" : "716280759548583940",
  "text" : "How To Make An Audio Book! https:\/\/t.co\/PhPweopVAR #audiobooks",
  "id" : 716280759548583940,
  "created_at" : "2016-04-02 15:06:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee",
      "screen_name" : "silent_musings",
      "indices" : [ 3, 18 ],
      "id_str" : "194678398",
      "id" : 194678398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716270918683770880",
  "text" : "RT @silent_musings: You can ask the universe for all the signs you want, but ultimately, we see what we want to see when we\u2019re ready to see\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35863802599837696",
    "text" : "You can ask the universe for all the signs you want, but ultimately, we see what we want to see when we\u2019re ready to see it",
    "id" : 35863802599837696,
    "created_at" : "2011-02-11 00:52:51 +0000",
    "user" : {
      "name" : "Lee",
      "screen_name" : "silent_musings",
      "protected" : false,
      "id_str" : "194678398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1130459246\/333_normal.JPG",
      "id" : 194678398,
      "verified" : false
    }
  },
  "id" : 716270918683770880,
  "created_at" : "2016-04-02 14:27:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/716264061550333952\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/U70ilnEZgp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfCuRacWIAAhP0e.jpg",
      "id_str" : "716263954931130368",
      "id" : 716263954931130368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfCuRacWIAAhP0e.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/U70ilnEZgp"
    } ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/npFni4PPoC",
      "expanded_url" : "http:\/\/facebook.com\/dwaynereavesphotography",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716268084449959936",
  "text" : "RT @dwaynereaves: Standing alone! Ya'll come check me out on Facebook. https:\/\/t.co\/npFni4PPoC #photography https:\/\/t.co\/U70ilnEZgp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/716264061550333952\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/U70ilnEZgp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfCuRacWIAAhP0e.jpg",
        "id_str" : "716263954931130368",
        "id" : 716263954931130368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfCuRacWIAAhP0e.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/U70ilnEZgp"
      } ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/npFni4PPoC",
        "expanded_url" : "http:\/\/facebook.com\/dwaynereavesphotography",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716264061550333952",
    "text" : "Standing alone! Ya'll come check me out on Facebook. https:\/\/t.co\/npFni4PPoC #photography https:\/\/t.co\/U70ilnEZgp",
    "id" : 716264061550333952,
    "created_at" : "2016-04-02 14:00:34 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 716268084449959936,
  "created_at" : "2016-04-02 14:16:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/PFnSWC80jl",
      "expanded_url" : "https:\/\/youtu.be\/xau8s_g-lQk",
      "display_url" : "youtu.be\/xau8s_g-lQk"
    } ]
  },
  "geo" : { },
  "id_str" : "716264902369943552",
  "text" : "nice &gt; David Beckham and James Corden's New Underwear Line https:\/\/t.co\/PFnSWC80jl",
  "id" : 716264902369943552,
  "created_at" : "2016-04-02 14:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716043169872408578",
  "text" : "getting a liver U\/S due to liver enzymes up even higher. most likely fatty liver, tho. bad cholesterol is good..lol.",
  "id" : 716043169872408578,
  "created_at" : "2016-04-01 23:22:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/716025331753287680\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/7DqwtQsJ27",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_VPpNUUAIW-HW.jpg",
      "id_str" : "716025330511663106",
      "id" : 716025330511663106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_VPpNUUAIW-HW.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/7DqwtQsJ27"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716025331753287680",
  "text" : "We're at Dairy Queen and I'm tweeting using Optimum WiFi! DD being silly. https:\/\/t.co\/7DqwtQsJ27",
  "id" : 716025331753287680,
  "created_at" : "2016-04-01 22:11:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/OwVRHJICEY",
      "expanded_url" : "https:\/\/twitter.com\/ArthritisAshley\/status\/715936103228944385",
      "display_url" : "twitter.com\/ArthritisAshle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715939798154944512",
  "text" : "shamefully, this inc. me as I let my ego get caught up in demonizing \"the other side\" .. gah. https:\/\/t.co\/OwVRHJICEY",
  "id" : 715939798154944512,
  "created_at" : "2016-04-01 16:32:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SimpleTruth",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715929961450893316",
  "text" : "RT @fairlyspiritual: Posts that decry what others do wrong get far more readers than posts that help people do things right. #SimpleTruth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SimpleTruth",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715909739935363072",
    "text" : "Posts that decry what others do wrong get far more readers than posts that help people do things right. #SimpleTruth",
    "id" : 715909739935363072,
    "created_at" : "2016-04-01 14:32:37 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 715929961450893316,
  "created_at" : "2016-04-01 15:52:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715698775285575681",
  "geo" : { },
  "id_str" : "715911391773908992",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH teehee",
  "id" : 715911391773908992,
  "in_reply_to_status_id" : 715698775285575681,
  "created_at" : "2016-04-01 14:39:11 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/FsT5ibcmKJ",
      "expanded_url" : "https:\/\/twitter.com\/DukeGreene\/status\/715718702839148544",
      "display_url" : "twitter.com\/DukeGreene\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715911111179108352",
  "text" : "ponders this... https:\/\/t.co\/FsT5ibcmKJ",
  "id" : 715911111179108352,
  "created_at" : "2016-04-01 14:38:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]