Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bambi L Albert",
      "screen_name" : "blamom",
      "indices" : [ 3, 10 ],
      "id_str" : "20839221",
      "id" : 20839221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Bn8g2PJYoU",
      "expanded_url" : "http:\/\/fb.me\/7RgaY1OeB",
      "display_url" : "fb.me\/7RgaY1OeB"
    } ]
  },
  "geo" : { },
  "id_str" : "771116825425874944",
  "text" : "RT @blamom: Multiple Sclerosis Is Actually Lyme Disease. Here\u2019s Why https:\/\/t.co\/Bn8g2PJYoU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/Bn8g2PJYoU",
        "expanded_url" : "http:\/\/fb.me\/7RgaY1OeB",
        "display_url" : "fb.me\/7RgaY1OeB"
      } ]
    },
    "geo" : { },
    "id_str" : "770963056880857088",
    "text" : "Multiple Sclerosis Is Actually Lyme Disease. Here\u2019s Why https:\/\/t.co\/Bn8g2PJYoU",
    "id" : 770963056880857088,
    "created_at" : "2016-08-31 12:34:51 +0000",
    "user" : {
      "name" : "Bambi L Albert",
      "screen_name" : "blamom",
      "protected" : false,
      "id_str" : "20839221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574910934881169410\/onaDy9Eh_normal.jpeg",
      "id" : 20839221,
      "verified" : false
    }
  },
  "id" : 771116825425874944,
  "created_at" : "2016-08-31 22:45:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christiana Ellis",
      "screen_name" : "christianaellis",
      "indices" : [ 3, 19 ],
      "id_str" : "794436",
      "id" : 794436
    }, {
      "name" : "Tee Morris",
      "screen_name" : "TeeMonster",
      "indices" : [ 44, 55 ],
      "id_str" : "7588872",
      "id" : 7588872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/e5eRgtDpcC",
      "expanded_url" : "http:\/\/www.tor.com\/2016\/08\/31\/sff-fiction-podcasts-you-should-be-listening-to\/",
      "display_url" : "tor.com\/2016\/08\/31\/sff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771095075669610497",
  "text" : "RT @christianaellis: Telling it like it is, @TeeMonster digs deeper about the history of podcast fiction. https:\/\/t.co\/e5eRgtDpcC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tee Morris",
        "screen_name" : "TeeMonster",
        "indices" : [ 23, 34 ],
        "id_str" : "7588872",
        "id" : 7588872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/e5eRgtDpcC",
        "expanded_url" : "http:\/\/www.tor.com\/2016\/08\/31\/sff-fiction-podcasts-you-should-be-listening-to\/",
        "display_url" : "tor.com\/2016\/08\/31\/sff\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771016758446682113",
    "text" : "Telling it like it is, @TeeMonster digs deeper about the history of podcast fiction. https:\/\/t.co\/e5eRgtDpcC",
    "id" : 771016758446682113,
    "created_at" : "2016-08-31 16:08:14 +0000",
    "user" : {
      "name" : "Christiana Ellis",
      "screen_name" : "christianaellis",
      "protected" : false,
      "id_str" : "794436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798917715020935168\/XPIr_3ob_normal.jpg",
      "id" : 794436,
      "verified" : false
    }
  },
  "id" : 771095075669610497,
  "created_at" : "2016-08-31 21:19:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Getchell",
      "screen_name" : "AudiotainmntNws",
      "indices" : [ 3, 19 ],
      "id_str" : "726884722404552704",
      "id" : 726884722404552704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/rL7tbOa37y",
      "expanded_url" : "http:\/\/austin.craigslist.org\/tlg\/5758804828.html",
      "display_url" : "austin.craigslist.org\/tlg\/5758804828\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771094885797466112",
  "text" : "RT @AudiotainmntNws: CASTING CALL: They will take satellite recordings if your not in the Austin area: https:\/\/t.co\/rL7tbOa37y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/rL7tbOa37y",
        "expanded_url" : "http:\/\/austin.craigslist.org\/tlg\/5758804828.html",
        "display_url" : "austin.craigslist.org\/tlg\/5758804828\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771076132212989953",
    "text" : "CASTING CALL: They will take satellite recordings if your not in the Austin area: https:\/\/t.co\/rL7tbOa37y",
    "id" : 771076132212989953,
    "created_at" : "2016-08-31 20:04:10 +0000",
    "user" : {
      "name" : "Pam Getchell",
      "screen_name" : "AudiotainmntNws",
      "protected" : false,
      "id_str" : "726884722404552704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759896030217326593\/-MLUFKkP_normal.jpg",
      "id" : 726884722404552704,
      "verified" : false
    }
  },
  "id" : 771094885797466112,
  "created_at" : "2016-08-31 21:18:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Pastures",
      "screen_name" : "HopePastures",
      "indices" : [ 3, 16 ],
      "id_str" : "617917883",
      "id" : 617917883
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/771067741558206465\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/d4oNMiG62g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNhAkdWcAABriS.jpg",
      "id_str" : "771066623625162752",
      "id" : 771066623625162752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNhAkdWcAABriS.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/d4oNMiG62g"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/771067741558206465\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/d4oNMiG62g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNhAnjW8AAd8kc.jpg",
      "id_str" : "771066624455667712",
      "id" : 771066624455667712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNhAnjW8AAd8kc.jpg",
      "sizes" : [ {
        "h" : 1507,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2896,
        "resize" : "fit",
        "w" : 3936
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 883,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/d4oNMiG62g"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/771067741558206465\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/d4oNMiG62g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNhGpMWEAAbFoa.jpg",
      "id_str" : "771066727975227392",
      "id" : 771066727975227392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNhGpMWEAAbFoa.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 513
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 513
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 513
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 513
      } ],
      "display_url" : "pic.twitter.com\/d4oNMiG62g"
    } ],
    "hashtags" : [ {
      "text" : "equestrianhour",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/xmP7hFiO50",
      "expanded_url" : "http:\/\/bit.ly\/2ccKAnJ",
      "display_url" : "bit.ly\/2ccKAnJ"
    } ]
  },
  "geo" : { },
  "id_str" : "771093732594749440",
  "text" : "RT @HopePastures: Why not rehome one of our knitted herd #equestrianhour https:\/\/t.co\/xmP7hFiO50 https:\/\/t.co\/d4oNMiG62g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/771067741558206465\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/d4oNMiG62g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNhAkdWcAABriS.jpg",
        "id_str" : "771066623625162752",
        "id" : 771066623625162752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNhAkdWcAABriS.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/d4oNMiG62g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/771067741558206465\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/d4oNMiG62g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNhAnjW8AAd8kc.jpg",
        "id_str" : "771066624455667712",
        "id" : 771066624455667712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNhAnjW8AAd8kc.jpg",
        "sizes" : [ {
          "h" : 1507,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2896,
          "resize" : "fit",
          "w" : 3936
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 883,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/d4oNMiG62g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/HopePastures\/status\/771067741558206465\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/d4oNMiG62g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNhGpMWEAAbFoa.jpg",
        "id_str" : "771066727975227392",
        "id" : 771066727975227392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNhGpMWEAAbFoa.jpg",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 513
        } ],
        "display_url" : "pic.twitter.com\/d4oNMiG62g"
      } ],
      "hashtags" : [ {
        "text" : "equestrianhour",
        "indices" : [ 39, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/xmP7hFiO50",
        "expanded_url" : "http:\/\/bit.ly\/2ccKAnJ",
        "display_url" : "bit.ly\/2ccKAnJ"
      } ]
    },
    "geo" : { },
    "id_str" : "771067741558206465",
    "text" : "Why not rehome one of our knitted herd #equestrianhour https:\/\/t.co\/xmP7hFiO50 https:\/\/t.co\/d4oNMiG62g",
    "id" : 771067741558206465,
    "created_at" : "2016-08-31 19:30:49 +0000",
    "user" : {
      "name" : "Hope Pastures",
      "screen_name" : "HopePastures",
      "protected" : false,
      "id_str" : "617917883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2340198212\/4xpqgnrt1uxlwp6mpcui_normal.jpeg",
      "id" : 617917883,
      "verified" : false
    }
  },
  "id" : 771093732594749440,
  "created_at" : "2016-08-31 21:14:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "indices" : [ 3, 16 ],
      "id_str" : "530935629",
      "id" : 530935629
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/770831972490813440\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/kSROeoNKu9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrKLjb-UIAEJeEw.jpg",
      "id_str" : "770831927154581505",
      "id" : 770831927154581505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrKLjb-UIAEJeEw.jpg",
      "sizes" : [ {
        "h" : 694,
        "resize" : "fit",
        "w" : 1370
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 1370
      } ],
      "display_url" : "pic.twitter.com\/kSROeoNKu9"
    } ],
    "hashtags" : [ {
      "text" : "runnerducks",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771093677460623360",
  "text" : "RT @melinawstaal: be safe, be well, good night.\n#runnerducks https:\/\/t.co\/kSROeoNKu9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/770831972490813440\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/kSROeoNKu9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrKLjb-UIAEJeEw.jpg",
        "id_str" : "770831927154581505",
        "id" : 770831927154581505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrKLjb-UIAEJeEw.jpg",
        "sizes" : [ {
          "h" : 694,
          "resize" : "fit",
          "w" : 1370
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 1370
        } ],
        "display_url" : "pic.twitter.com\/kSROeoNKu9"
      } ],
      "hashtags" : [ {
        "text" : "runnerducks",
        "indices" : [ 30, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770831972490813440",
    "text" : "be safe, be well, good night.\n#runnerducks https:\/\/t.co\/kSROeoNKu9",
    "id" : 770831972490813440,
    "created_at" : "2016-08-31 03:53:58 +0000",
    "user" : {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "protected" : false,
      "id_str" : "530935629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638498065096151042\/DwWC834G_normal.jpg",
      "id" : 530935629,
      "verified" : false
    }
  },
  "id" : 771093677460623360,
  "created_at" : "2016-08-31 21:13:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PsyPost.org",
      "screen_name" : "PsyPost",
      "indices" : [ 3, 11 ],
      "id_str" : "125512325",
      "id" : 125512325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/M7Le0T3I73",
      "expanded_url" : "https:\/\/www.psypost.org\/2016\/08\/people-with-alcohol-dependency-lack-important-enzyme-44692",
      "display_url" : "psypost.org\/2016\/08\/people\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771093388556926976",
  "text" : "RT @PsyPost: People with alcohol dependency lack important enzyme  https:\/\/t.co\/M7Le0T3I73",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/M7Le0T3I73",
        "expanded_url" : "https:\/\/www.psypost.org\/2016\/08\/people-with-alcohol-dependency-lack-important-enzyme-44692",
        "display_url" : "psypost.org\/2016\/08\/people\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771081435767771137",
    "text" : "People with alcohol dependency lack important enzyme  https:\/\/t.co\/M7Le0T3I73",
    "id" : 771081435767771137,
    "created_at" : "2016-08-31 20:25:14 +0000",
    "user" : {
      "name" : "PsyPost.org",
      "screen_name" : "PsyPost",
      "protected" : false,
      "id_str" : "125512325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594921277988573185\/-Yw8Om4W_normal.jpg",
      "id" : 125512325,
      "verified" : false
    }
  },
  "id" : 771093388556926976,
  "created_at" : "2016-08-31 21:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/771058875814600705\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jpJoYGjtPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNZ9VrWIAAW33t.jpg",
      "id_str" : "771058871536328704",
      "id" : 771058871536328704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNZ9VrWIAAW33t.jpg",
      "sizes" : [ {
        "h" : 556,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 946
      } ],
      "display_url" : "pic.twitter.com\/jpJoYGjtPZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/sU1pMviDU5",
      "expanded_url" : "http:\/\/ebooks.nypl.org\/7AE7E937-0D7E-4D20-B79B-ADEF5DC833BC\/10\/50\/en\/ContentDetails.htm?id=2B73C83A-D490-483D-BFAC-BD09EF4DE7A0&_ts=1472669733",
      "display_url" : "ebooks.nypl.org\/7AE7E937-0D7E-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771058875814600705",
  "text" : "What is wrong with this picture? &gt; The Werewolf's Guide to Life https:\/\/t.co\/sU1pMviDU5 https:\/\/t.co\/jpJoYGjtPZ",
  "id" : 771058875814600705,
  "created_at" : "2016-08-31 18:55:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "feedly",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/ZSzKV84dMF",
      "expanded_url" : "http:\/\/scripting.com\/2016\/08\/30\/podcastStandUpForAmerica.html",
      "display_url" : "scripting.com\/2016\/08\/30\/pod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771016464744710145",
  "text" : "Stay seated for America https:\/\/t.co\/ZSzKV84dMF #tech #feedly",
  "id" : 771016464744710145,
  "created_at" : "2016-08-31 16:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 82, 91 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770775580522516480",
  "text" : "took me a bit of a brain workout but got my twitter archive onto github thanks to @mhawksey blog post and video.",
  "id" : 770775580522516480,
  "created_at" : "2016-08-31 00:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PendantAudio.com",
      "screen_name" : "pendantweb",
      "indices" : [ 3, 14 ],
      "id_str" : "15181272",
      "id" : 15181272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/dXBxbQAE4r",
      "expanded_url" : "http:\/\/www.pendantaudio.com\/castingcalls",
      "display_url" : "pendantaudio.com\/castingcalls"
    } ]
  },
  "geo" : { },
  "id_str" : "770774580680097792",
  "text" : "RT @pendantweb: CASTING CALL: 7+ new roles for \u201CSeminar\u201D! Audition deadline ***SEPT 7***\nhttps:\/\/t.co\/dXBxbQAE4r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/dXBxbQAE4r",
        "expanded_url" : "http:\/\/www.pendantaudio.com\/castingcalls",
        "display_url" : "pendantaudio.com\/castingcalls"
      } ]
    },
    "geo" : { },
    "id_str" : "770699892041801728",
    "text" : "CASTING CALL: 7+ new roles for \u201CSeminar\u201D! Audition deadline ***SEPT 7***\nhttps:\/\/t.co\/dXBxbQAE4r",
    "id" : 770699892041801728,
    "created_at" : "2016-08-30 19:09:07 +0000",
    "user" : {
      "name" : "PendantAudio.com",
      "screen_name" : "pendantweb",
      "protected" : false,
      "id_str" : "15181272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793837369954709505\/6NyboC5B_normal.jpg",
      "id" : 15181272,
      "verified" : false
    }
  },
  "id" : 770774580680097792,
  "created_at" : "2016-08-31 00:05:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/770550382237933568\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/NNvP2k1sZo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrGLfPUWEAAoyM-.jpg",
      "id_str" : "770550380061134848",
      "id" : 770550380061134848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrGLfPUWEAAoyM-.jpg",
      "sizes" : [ {
        "h" : 395,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/NNvP2k1sZo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/BDflUzdu5p",
      "expanded_url" : "http:\/\/bit.ly\/2bbqOtt",
      "display_url" : "bit.ly\/2bbqOtt"
    } ]
  },
  "geo" : { },
  "id_str" : "770622831331794944",
  "text" : "RT @voxdotcom: 6 reasons why studying nutrition is so messy: https:\/\/t.co\/BDflUzdu5p https:\/\/t.co\/NNvP2k1sZo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/770550382237933568\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/NNvP2k1sZo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrGLfPUWEAAoyM-.jpg",
        "id_str" : "770550380061134848",
        "id" : 770550380061134848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrGLfPUWEAAoyM-.jpg",
        "sizes" : [ {
          "h" : 395,
          "resize" : "fit",
          "w" : 778
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 778
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 778
        } ],
        "display_url" : "pic.twitter.com\/NNvP2k1sZo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/BDflUzdu5p",
        "expanded_url" : "http:\/\/bit.ly\/2bbqOtt",
        "display_url" : "bit.ly\/2bbqOtt"
      } ]
    },
    "geo" : { },
    "id_str" : "770550382237933568",
    "text" : "6 reasons why studying nutrition is so messy: https:\/\/t.co\/BDflUzdu5p https:\/\/t.co\/NNvP2k1sZo",
    "id" : 770550382237933568,
    "created_at" : "2016-08-30 09:15:01 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 770622831331794944,
  "created_at" : "2016-08-30 14:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "indices" : [ 3, 19 ],
      "id_str" : "4218819269",
      "id" : 4218819269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/5uJYA0fOZF",
      "expanded_url" : "https:\/\/twitter.com\/AnAudiobookworm\/status\/767899341021335552",
      "display_url" : "twitter.com\/AnAudiobookwor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770440250086846464",
  "text" : "RT @AnAudiobookworm: Ending soon! https:\/\/t.co\/5uJYA0fOZF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/5uJYA0fOZF",
        "expanded_url" : "https:\/\/twitter.com\/AnAudiobookworm\/status\/767899341021335552",
        "display_url" : "twitter.com\/AnAudiobookwor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770397809107349504",
    "text" : "Ending soon! https:\/\/t.co\/5uJYA0fOZF",
    "id" : 770397809107349504,
    "created_at" : "2016-08-29 23:08:45 +0000",
    "user" : {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "protected" : false,
      "id_str" : "4218819269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690226493151117312\/IydgluWy_normal.jpg",
      "id" : 4218819269,
      "verified" : false
    }
  },
  "id" : 770440250086846464,
  "created_at" : "2016-08-30 01:57:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline",
      "screen_name" : "sketchingkari",
      "indices" : [ 3, 17 ],
      "id_str" : "20808845",
      "id" : 20808845
    }, {
      "name" : "SewandSo",
      "screen_name" : "sewandsouk",
      "indices" : [ 74, 85 ],
      "id_str" : "196976995",
      "id" : 196976995
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sketchingkari\/status\/770274131027845121\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TGq7Zd2o7g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrCQG1qW8AASeoO.jpg",
      "id_str" : "770273983438712832",
      "id" : 770273983438712832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrCQG1qW8AASeoO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 1272
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 1272
      } ],
      "display_url" : "pic.twitter.com\/TGq7Zd2o7g"
    } ],
    "hashtags" : [ {
      "text" : "Poldark",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "crossstitch",
      "indices" : [ 61, 73 ]
    }, {
      "text" : "handmade",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770317062296207360",
  "text" : "RT @sketchingkari: 162 hours later, he's finished!! #Poldark #crossstitch @sewandsouk #handmade https:\/\/t.co\/TGq7Zd2o7g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SewandSo",
        "screen_name" : "sewandsouk",
        "indices" : [ 55, 66 ],
        "id_str" : "196976995",
        "id" : 196976995
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sketchingkari\/status\/770274131027845121\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/TGq7Zd2o7g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrCQG1qW8AASeoO.jpg",
        "id_str" : "770273983438712832",
        "id" : 770273983438712832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrCQG1qW8AASeoO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 1272
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 1272
        } ],
        "display_url" : "pic.twitter.com\/TGq7Zd2o7g"
      } ],
      "hashtags" : [ {
        "text" : "Poldark",
        "indices" : [ 33, 41 ]
      }, {
        "text" : "crossstitch",
        "indices" : [ 42, 54 ]
      }, {
        "text" : "handmade",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770274131027845121",
    "text" : "162 hours later, he's finished!! #Poldark #crossstitch @sewandsouk #handmade https:\/\/t.co\/TGq7Zd2o7g",
    "id" : 770274131027845121,
    "created_at" : "2016-08-29 14:57:18 +0000",
    "user" : {
      "name" : "Caroline",
      "screen_name" : "sketchingkari",
      "protected" : false,
      "id_str" : "20808845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798850497775968256\/cSi0eYuy_normal.jpg",
      "id" : 20808845,
      "verified" : false
    }
  },
  "id" : 770317062296207360,
  "created_at" : "2016-08-29 17:47:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 3, 16 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/770257956147343360\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ivvWcry3VC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrCBhyLUsAAKLTG.jpg",
      "id_str" : "770257953685286912",
      "id" : 770257953685286912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrCBhyLUsAAKLTG.jpg",
      "sizes" : [ {
        "h" : 497,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/ivvWcry3VC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/7EpZl73INv",
      "expanded_url" : "http:\/\/bit.ly\/2bueZCj",
      "display_url" : "bit.ly\/2bueZCj"
    } ]
  },
  "geo" : { },
  "id_str" : "770303128520499200",
  "text" : "RT @mental_floss: Book-Themed Enamel Pins Are the Perfect Thing for Trendy Readers \u2014 https:\/\/t.co\/7EpZl73INv https:\/\/t.co\/ivvWcry3VC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/770257956147343360\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ivvWcry3VC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrCBhyLUsAAKLTG.jpg",
        "id_str" : "770257953685286912",
        "id" : 770257953685286912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrCBhyLUsAAKLTG.jpg",
        "sizes" : [ {
          "h" : 497,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/ivvWcry3VC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/7EpZl73INv",
        "expanded_url" : "http:\/\/bit.ly\/2bueZCj",
        "display_url" : "bit.ly\/2bueZCj"
      } ]
    },
    "geo" : { },
    "id_str" : "770257956147343360",
    "text" : "Book-Themed Enamel Pins Are the Perfect Thing for Trendy Readers \u2014 https:\/\/t.co\/7EpZl73INv https:\/\/t.co\/ivvWcry3VC",
    "id" : 770257956147343360,
    "created_at" : "2016-08-29 13:53:02 +0000",
    "user" : {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "protected" : false,
      "id_str" : "20065936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725736720327708672\/QHUualpe_normal.jpg",
      "id" : 20065936,
      "verified" : true
    }
  },
  "id" : 770303128520499200,
  "created_at" : "2016-08-29 16:52:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 4, 8 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/8Svv8XnIV9",
      "expanded_url" : "https:\/\/n.pr\/2bGNWPd",
      "display_url" : "n.pr\/2bGNWPd"
    } ]
  },
  "geo" : { },
  "id_str" : "770288181560434688",
  "text" : "Via @NPR: The Real Bob Ross: Meet The Meticulous Artist Behind Those Happy Trees https:\/\/t.co\/8Svv8XnIV9",
  "id" : 770288181560434688,
  "created_at" : "2016-08-29 15:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hateretha",
      "screen_name" : "Mrs_B055",
      "indices" : [ 3, 12 ],
      "id_str" : "633399721",
      "id" : 633399721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/S4wAz3VamP",
      "expanded_url" : "https:\/\/twitter.com\/Artists_Ali\/status\/769985540494069761",
      "display_url" : "twitter.com\/Artists_Ali\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770285228900421632",
  "text" : "RT @Mrs_B055: When??? Shit y'all systematically deny Blk women repro justice, so my fat black ass is screwed https:\/\/t.co\/S4wAz3VamP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/S4wAz3VamP",
        "expanded_url" : "https:\/\/twitter.com\/Artists_Ali\/status\/769985540494069761",
        "display_url" : "twitter.com\/Artists_Ali\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770280215817949184",
    "text" : "When??? Shit y'all systematically deny Blk women repro justice, so my fat black ass is screwed https:\/\/t.co\/S4wAz3VamP",
    "id" : 770280215817949184,
    "created_at" : "2016-08-29 15:21:29 +0000",
    "user" : {
      "name" : "Hateretha",
      "screen_name" : "Mrs_B055",
      "protected" : false,
      "id_str" : "633399721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800315545568608256\/xSHMzajg_normal.jpg",
      "id" : 633399721,
      "verified" : false
    }
  },
  "id" : 770285228900421632,
  "created_at" : "2016-08-29 15:41:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Mighty",
      "screen_name" : "TheMightySite",
      "indices" : [ 85, 99 ],
      "id_str" : "2269570470",
      "id" : 2269570470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/ntC6ZhQH6E",
      "expanded_url" : "http:\/\/sumo.ly\/jwlS",
      "display_url" : "sumo.ly\/jwlS"
    } ]
  },
  "geo" : { },
  "id_str" : "770274859276468224",
  "text" : "Comic Redesigns the Autism Spectrum to Crush Stereotypes https:\/\/t.co\/ntC6ZhQH6E via @themightysite",
  "id" : 770274859276468224,
  "created_at" : "2016-08-29 15:00:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "feedly",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/oWzi3bPAG1",
      "expanded_url" : "http:\/\/www.flyinginthespirit.cuttys.net\/2016\/08\/29\/how-the-traditional-doctrine-of-hell-undermines-christian-character\/",
      "display_url" : "flyinginthespirit.cuttys.net\/2016\/08\/29\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770271011434590208",
  "text" : "How the Traditional Doctrine of Hell Undermines Christian Character https:\/\/t.co\/oWzi3bPAG1 #religion #feedly",
  "id" : 770271011434590208,
  "created_at" : "2016-08-29 14:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/769974314867257344\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/CeGYcNTrrr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9_jmoWYAEtNHj.jpg",
      "id_str" : "769974310945579009",
      "id" : 769974310945579009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9_jmoWYAEtNHj.jpg",
      "sizes" : [ {
        "h" : 661,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CeGYcNTrrr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770061067309424640",
  "text" : "RT @SouthYeoEast: Curious Galloway youngsters lined up to see what we're doing. Guinness, Fiona Mae and Tansy https:\/\/t.co\/CeGYcNTrrr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/769974314867257344\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/CeGYcNTrrr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9_jmoWYAEtNHj.jpg",
        "id_str" : "769974310945579009",
        "id" : 769974310945579009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9_jmoWYAEtNHj.jpg",
        "sizes" : [ {
          "h" : 661,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CeGYcNTrrr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769974314867257344",
    "text" : "Curious Galloway youngsters lined up to see what we're doing. Guinness, Fiona Mae and Tansy https:\/\/t.co\/CeGYcNTrrr",
    "id" : 769974314867257344,
    "created_at" : "2016-08-28 19:05:56 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 770061067309424640,
  "created_at" : "2016-08-29 00:50:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FUS Madison",
      "screen_name" : "FUSmadison",
      "indices" : [ 3, 14 ],
      "id_str" : "601341224",
      "id" : 601341224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UU",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769993558472482816",
  "text" : "RT @FUSmadison: In Unitarian Universalism, there is no doctrine, no rule of God. We do take cookies and hot cocoa very seriously though. #UU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UU",
        "indices" : [ 121, 124 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "679334786725449728",
    "geo" : { },
    "id_str" : "679335113285595136",
    "in_reply_to_user_id" : 601341224,
    "text" : "In Unitarian Universalism, there is no doctrine, no rule of God. We do take cookies and hot cocoa very seriously though. #UU",
    "id" : 679335113285595136,
    "in_reply_to_status_id" : 679334786725449728,
    "created_at" : "2015-12-22 16:18:07 +0000",
    "in_reply_to_screen_name" : "FUSmadison",
    "in_reply_to_user_id_str" : "601341224",
    "user" : {
      "name" : "FUS Madison",
      "screen_name" : "FUSmadison",
      "protected" : false,
      "id_str" : "601341224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540990089417854976\/u327Cyqo_normal.png",
      "id" : 601341224,
      "verified" : false
    }
  },
  "id" : 769993558472482816,
  "created_at" : "2016-08-28 20:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turn Off the Lights",
      "screen_name" : "TurnOfftheLight",
      "indices" : [ 0, 16 ],
      "id_str" : "532339753",
      "id" : 532339753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769976985581920256",
  "geo" : { },
  "id_str" : "769981622305361920",
  "in_reply_to_user_id" : 532339753,
  "text" : "@TurnOfftheLight aha.. apparently that was the problem. now fixed. Thanks! : )",
  "id" : 769981622305361920,
  "in_reply_to_status_id" : 769976985581920256,
  "created_at" : "2016-08-28 19:34:58 +0000",
  "in_reply_to_screen_name" : "TurnOfftheLight",
  "in_reply_to_user_id_str" : "532339753",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turn Off the Lights",
      "screen_name" : "TurnOfftheLight",
      "indices" : [ 0, 16 ],
      "id_str" : "532339753",
      "id" : 532339753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769956851815448576",
  "geo" : { },
  "id_str" : "769974470081671169",
  "in_reply_to_user_id" : 532339753,
  "text" : "@TurnOfftheLight huh.. if incognito open with regular they both work. close incognito, reg tab does not work (add\/remove shows, not list)",
  "id" : 769974470081671169,
  "in_reply_to_status_id" : 769956851815448576,
  "created_at" : "2016-08-28 19:06:33 +0000",
  "in_reply_to_screen_name" : "TurnOfftheLight",
  "in_reply_to_user_id_str" : "532339753",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 33, 41 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945672552415238",
  "text" : "google chrome not working well w @twitter .. i have to use IE to add to my list",
  "id" : 769945672552415238,
  "created_at" : "2016-08-28 17:12:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 97, 106 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Z7f020ycyp",
      "expanded_url" : "https:\/\/mashe.hawksey.info\/2016\/08\/keeping-your-twitter-archive-fresh-and-freely-hosted-on-github-pages\/",
      "display_url" : "mashe.hawksey.info\/2016\/08\/keepin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769910872345108480",
  "text" : "Keeping your Twitter Archive fresh and freely hosted on Github Pages https:\/\/t.co\/Z7f020ycyp via @mhawksey",
  "id" : 769910872345108480,
  "created_at" : "2016-08-28 14:53:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmers Of The UK",
      "screen_name" : "FarmersOfTheUK",
      "indices" : [ 3, 18 ],
      "id_str" : "2276009684",
      "id" : 2276009684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769898444064493568",
  "text" : "RT @FarmersOfTheUK: It all continues up &amp; down the country &amp; world every day. It is lovely to take time to capture moments like this https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmersOfTheUK\/status\/769847361375989760\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/iMTwQ2k802",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq8LTYFXYAAu8yB.jpg",
        "id_str" : "769846488814018560",
        "id" : 769846488814018560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq8LTYFXYAAu8yB.jpg",
        "sizes" : [ {
          "h" : 528,
          "resize" : "fit",
          "w" : 887
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 887
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 887
        } ],
        "display_url" : "pic.twitter.com\/iMTwQ2k802"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769847361375989760",
    "text" : "It all continues up &amp; down the country &amp; world every day. It is lovely to take time to capture moments like this https:\/\/t.co\/iMTwQ2k802",
    "id" : 769847361375989760,
    "created_at" : "2016-08-28 10:41:28 +0000",
    "user" : {
      "name" : "Farmers Of The UK",
      "screen_name" : "FarmersOfTheUK",
      "protected" : false,
      "id_str" : "2276009684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800632571730214912\/h-qop8FT_normal.jpg",
      "id" : 2276009684,
      "verified" : false
    }
  },
  "id" : 769898444064493568,
  "created_at" : "2016-08-28 14:04:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zesty Science News",
      "screen_name" : "zesty_science",
      "indices" : [ 3, 17 ],
      "id_str" : "702953945669476352",
      "id" : 702953945669476352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zesty_science\/status\/769515943613595648\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/SZtC77uB8G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq3eq3BWAAAkFvN.jpg",
      "id_str" : "769515939255681024",
      "id" : 769515939255681024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq3eq3BWAAAkFvN.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/SZtC77uB8G"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/c7bSKtHm7Z",
      "expanded_url" : "https:\/\/www.newscientist.com\/article\/2102924-monster-slugs-are-devouring-defenceless-baby-birds-in-nests\/",
      "display_url" : "newscientist.com\/article\/210292\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769626035163832320",
  "text" : "RT @zesty_science: Monster slugs are devouring defenceless baby birds in nests https:\/\/t.co\/c7bSKtHm7Z https:\/\/t.co\/SZtC77uB8G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/zestynews.com\" rel=\"nofollow\"\u003EZesty Tweet Science\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zesty_science\/status\/769515943613595648\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/SZtC77uB8G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq3eq3BWAAAkFvN.jpg",
        "id_str" : "769515939255681024",
        "id" : 769515939255681024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq3eq3BWAAAkFvN.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/SZtC77uB8G"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/c7bSKtHm7Z",
        "expanded_url" : "https:\/\/www.newscientist.com\/article\/2102924-monster-slugs-are-devouring-defenceless-baby-birds-in-nests\/",
        "display_url" : "newscientist.com\/article\/210292\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769515943613595648",
    "text" : "Monster slugs are devouring defenceless baby birds in nests https:\/\/t.co\/c7bSKtHm7Z https:\/\/t.co\/SZtC77uB8G",
    "id" : 769515943613595648,
    "created_at" : "2016-08-27 12:44:32 +0000",
    "user" : {
      "name" : "Zesty Science News",
      "screen_name" : "zesty_science",
      "protected" : false,
      "id_str" : "702953945669476352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704008039381274624\/WGyt8fXl_normal.jpg",
      "id" : 702953945669476352,
      "verified" : false
    }
  },
  "id" : 769626035163832320,
  "created_at" : "2016-08-27 20:02:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769605468595621888",
  "text" : "i listen to audiobooks from audible and overdrive plus podcast episodes. i listen on diff apps on tablet or send to my sansa clip. #tech",
  "id" : 769605468595621888,
  "created_at" : "2016-08-27 18:40:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audio",
      "indices" : [ 55, 61 ]
    }, {
      "text" : "tech",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769604885293694976",
  "text" : "plus im annoyed cant have one program to deal with it. #audio #tech",
  "id" : 769604885293694976,
  "created_at" : "2016-08-27 18:37:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769604480807624705",
  "text" : "someone needs to make an audio manager for audiobooks, podcasts, etc. ive got files all over.",
  "id" : 769604480807624705,
  "created_at" : "2016-08-27 18:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Learning",
      "screen_name" : "MindFactBlowing",
      "indices" : [ 3, 19 ],
      "id_str" : "2524670036",
      "id" : 2524670036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769602694948552704",
  "text" : "RT @MindFactBlowing: Tip: If you ever want to call a family meeting, just turn off the WiFi router and wait in the room in which its located",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/kucukbeyin.com\/\" rel=\"nofollow\"\u003Eahsdfasdfaahsdf\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769591314195312640",
    "text" : "Tip: If you ever want to call a family meeting, just turn off the WiFi router and wait in the room in which its located",
    "id" : 769591314195312640,
    "created_at" : "2016-08-27 17:44:02 +0000",
    "user" : {
      "name" : "Learning",
      "screen_name" : "MindFactBlowing",
      "protected" : false,
      "id_str" : "2524670036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544621350820671489\/WuBClf8G_normal.jpeg",
      "id" : 2524670036,
      "verified" : false
    }
  },
  "id" : 769602694948552704,
  "created_at" : "2016-08-27 18:29:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769568698562519040",
  "geo" : { },
  "id_str" : "769570495595442176",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley heehee",
  "id" : 769570495595442176,
  "in_reply_to_status_id" : 769568698562519040,
  "created_at" : "2016-08-27 16:21:18 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "indices" : [ 3, 15 ],
      "id_str" : "519836839",
      "id" : 519836839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/769437363269271552\/video\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/JxpjsScp2A",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769437228707614720\/pu\/img\/wfSm8ByMxYUPxqXR.jpg",
      "id_str" : "769437228707614720",
      "id" : 769437228707614720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769437228707614720\/pu\/img\/wfSm8ByMxYUPxqXR.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JxpjsScp2A"
    } ],
    "hashtags" : [ {
      "text" : "sheep365",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769544983145840640",
  "text" : "RT @decisiveman: Ewe: \"Pay no attention son it's only a paparazzi- sorry, l mean farmarazzi\".\n#sheep365 https:\/\/t.co\/JxpjsScp2A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/769437363269271552\/video\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/JxpjsScp2A",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769437228707614720\/pu\/img\/wfSm8ByMxYUPxqXR.jpg",
        "id_str" : "769437228707614720",
        "id" : 769437228707614720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769437228707614720\/pu\/img\/wfSm8ByMxYUPxqXR.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JxpjsScp2A"
      } ],
      "hashtags" : [ {
        "text" : "sheep365",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769437363269271552",
    "text" : "Ewe: \"Pay no attention son it's only a paparazzi- sorry, l mean farmarazzi\".\n#sheep365 https:\/\/t.co\/JxpjsScp2A",
    "id" : 769437363269271552,
    "created_at" : "2016-08-27 07:32:17 +0000",
    "user" : {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "protected" : false,
      "id_str" : "519836839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706805650844585984\/Wyw3swZ9_normal.jpg",
      "id" : 519836839,
      "verified" : false
    }
  },
  "id" : 769544983145840640,
  "created_at" : "2016-08-27 14:39:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "average joe",
      "screen_name" : "1955_joe",
      "indices" : [ 3, 12 ],
      "id_str" : "554758945",
      "id" : 554758945
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1955_joe\/status\/769314015503912960\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/3qekbn78KJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0nAu9XYAAN8qZ.jpg",
      "id_str" : "769314004909121536",
      "id" : 769314004909121536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0nAu9XYAAN8qZ.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/3qekbn78KJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769332100021489664",
  "text" : "RT @1955_joe: https:\/\/t.co\/3qekbn78KJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1955_joe\/status\/769314015503912960\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/3qekbn78KJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0nAu9XYAAN8qZ.jpg",
        "id_str" : "769314004909121536",
        "id" : 769314004909121536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0nAu9XYAAN8qZ.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/3qekbn78KJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769314015503912960",
    "text" : "https:\/\/t.co\/3qekbn78KJ",
    "id" : 769314015503912960,
    "created_at" : "2016-08-26 23:22:09 +0000",
    "user" : {
      "name" : "average joe",
      "screen_name" : "1955_joe",
      "protected" : false,
      "id_str" : "554758945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702652829442375685\/0C9h7PxM_normal.jpg",
      "id" : 554758945,
      "verified" : false
    }
  },
  "id" : 769332100021489664,
  "created_at" : "2016-08-27 00:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/T7mUj1ctzb",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/769329120429928448",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769331778628808704",
  "text" : "much healthier for the soul, too! : ) https:\/\/t.co\/T7mUj1ctzb",
  "id" : 769331778628808704,
  "created_at" : "2016-08-27 00:32:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Bible",
      "screen_name" : "ohholybible",
      "indices" : [ 3, 15 ],
      "id_str" : "524460502",
      "id" : 524460502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769331544775352320",
  "text" : "RT @ohholybible: If you want to know where you'll be in 5 yrs listen to what you talk about most now. \"Your tongue is a rudder\" James 3:4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769324192441376768",
    "text" : "If you want to know where you'll be in 5 yrs listen to what you talk about most now. \"Your tongue is a rudder\" James 3:4",
    "id" : 769324192441376768,
    "created_at" : "2016-08-27 00:02:35 +0000",
    "user" : {
      "name" : "Holy Bible",
      "screen_name" : "ohholybible",
      "protected" : false,
      "id_str" : "524460502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436660006360870913\/jm550BsN_normal.jpeg",
      "id" : 524460502,
      "verified" : false
    }
  },
  "id" : 769331544775352320,
  "created_at" : "2016-08-27 00:31:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/EaMOJw2xyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqztq-AWEAAtYgV.jpg",
      "id_str" : "769250958828244992",
      "id" : 769250958828244992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqztq-AWEAAtYgV.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/EaMOJw2xyI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/EaMOJw2xyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqztq-HXYAAOTwK.jpg",
      "id_str" : "769250958857691136",
      "id" : 769250958857691136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqztq-HXYAAOTwK.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/EaMOJw2xyI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/EaMOJw2xyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqztq-SWEAAMzKO.jpg",
      "id_str" : "769250958903742464",
      "id" : 769250958903742464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqztq-SWEAAMzKO.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/EaMOJw2xyI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/EaMOJw2xyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqztrH_WIAAXJBu.jpg",
      "id_str" : "769250961508409344",
      "id" : 769250961508409344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqztrH_WIAAXJBu.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/EaMOJw2xyI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769275682534948864",
  "text" : "RT @newlandfarm: Watching! https:\/\/t.co\/EaMOJw2xyI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/EaMOJw2xyI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqztq-AWEAAtYgV.jpg",
        "id_str" : "769250958828244992",
        "id" : 769250958828244992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqztq-AWEAAtYgV.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/EaMOJw2xyI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/EaMOJw2xyI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqztq-HXYAAOTwK.jpg",
        "id_str" : "769250958857691136",
        "id" : 769250958857691136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqztq-HXYAAOTwK.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/EaMOJw2xyI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/EaMOJw2xyI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqztq-SWEAAMzKO.jpg",
        "id_str" : "769250958903742464",
        "id" : 769250958903742464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqztq-SWEAAMzKO.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/EaMOJw2xyI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769251508856745985\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/EaMOJw2xyI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqztrH_WIAAXJBu.jpg",
        "id_str" : "769250961508409344",
        "id" : 769250961508409344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqztrH_WIAAXJBu.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/EaMOJw2xyI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769251508856745985",
    "text" : "Watching! https:\/\/t.co\/EaMOJw2xyI",
    "id" : 769251508856745985,
    "created_at" : "2016-08-26 19:13:46 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 769275682534948864,
  "created_at" : "2016-08-26 20:49:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769275601677119488",
  "text" : "RT @SouthYeoEast: Meg's coat has become increasingly matted over the summer, so she went to be groomed today. Bit posh for a farm dog! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/769225390325989376\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/P6WgcJUPA0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqzWaeuWAAAyuIj.jpg",
        "id_str" : "769225386785898496",
        "id" : 769225386785898496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqzWaeuWAAAyuIj.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/P6WgcJUPA0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769225390325989376",
    "text" : "Meg's coat has become increasingly matted over the summer, so she went to be groomed today. Bit posh for a farm dog! https:\/\/t.co\/P6WgcJUPA0",
    "id" : 769225390325989376,
    "created_at" : "2016-08-26 17:29:59 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 769275601677119488,
  "created_at" : "2016-08-26 20:49:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fitstats_en_US",
      "indices" : [ 10, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/amWHMl3bLO",
      "expanded_url" : "http:\/\/www.fitbit.com\/user\/4QMNGS",
      "display_url" : "fitbit.com\/user\/4QMNGS"
    } ]
  },
  "geo" : { },
  "id_str" : "769271309515759616",
  "text" : "My fitbit #Fitstats_en_US for 8\/26\/2016: 4,111 steps and 1.6 miles traveled. https:\/\/t.co\/amWHMl3bLO",
  "id" : 769271309515759616,
  "created_at" : "2016-08-26 20:32:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "darth\u2122",
      "screen_name" : "darth",
      "indices" : [ 3, 9 ],
      "id_str" : "1337271",
      "id" : 1337271
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/darth\/status\/769181588231979009\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/6GxjhDgYIQ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CqyugMxUEAEp-ys.jpg",
      "id_str" : "769181504580620289",
      "id" : 769181504580620289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CqyugMxUEAEp-ys.jpg",
      "sizes" : [ {
        "h" : 194,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 306
      } ],
      "display_url" : "pic.twitter.com\/6GxjhDgYIQ"
    } ],
    "hashtags" : [ {
      "text" : "NationalDogDay",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769270627438104578",
  "text" : "RT @darth: reminder on #NationalDogDay that dogs are in fact magical creatures no i am serious https:\/\/t.co\/6GxjhDgYIQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/darth\/status\/769181588231979009\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/6GxjhDgYIQ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CqyugMxUEAEp-ys.jpg",
        "id_str" : "769181504580620289",
        "id" : 769181504580620289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CqyugMxUEAEp-ys.jpg",
        "sizes" : [ {
          "h" : 194,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/6GxjhDgYIQ"
      } ],
      "hashtags" : [ {
        "text" : "NationalDogDay",
        "indices" : [ 12, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769181588231979009",
    "text" : "reminder on #NationalDogDay that dogs are in fact magical creatures no i am serious https:\/\/t.co\/6GxjhDgYIQ",
    "id" : 769181588231979009,
    "created_at" : "2016-08-26 14:35:55 +0000",
    "user" : {
      "name" : "darth\u2122",
      "screen_name" : "darth",
      "protected" : false,
      "id_str" : "1337271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796252088514678784\/RFZa8BLY_normal.jpg",
      "id" : 1337271,
      "verified" : false
    }
  },
  "id" : 769270627438104578,
  "created_at" : "2016-08-26 20:29:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart A. Thompson",
      "screen_name" : "stuartathompson",
      "indices" : [ 3, 19 ],
      "id_str" : "68727303",
      "id" : 68727303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769270530897809408",
  "text" : "RT @stuartathompson: Washington State is killing 10% of its wolf population because 12 cows out of 29 million were killed by a pack https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/1ngZ1Qrfhr",
        "expanded_url" : "http:\/\/motherboard.vice.com\/read\/washington-state-is-killing-a-pack-of-endangered-wolves-to-keep-ranchers-happy",
        "display_url" : "motherboard.vice.com\/read\/washingto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768862131722649600",
    "text" : "Washington State is killing 10% of its wolf population because 12 cows out of 29 million were killed by a pack https:\/\/t.co\/1ngZ1Qrfhr",
    "id" : 768862131722649600,
    "created_at" : "2016-08-25 17:26:31 +0000",
    "user" : {
      "name" : "Stuart A. Thompson",
      "screen_name" : "stuartathompson",
      "protected" : false,
      "id_str" : "68727303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752498192336363520\/_Ucroz5t_normal.jpg",
      "id" : 68727303,
      "verified" : true
    }
  },
  "id" : 769270530897809408,
  "created_at" : "2016-08-26 20:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "indices" : [ 3, 19 ],
      "id_str" : "4218819269",
      "id" : 4218819269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/3ag2K25ebe",
      "expanded_url" : "http:\/\/theaudiobookworm.com\/goodies-giveaways\/",
      "display_url" : "theaudiobookworm.com\/goodies-giveaw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769218020266868736",
  "text" : "RT @AnAudiobookworm: The 500 Follower Frenzy Giveaway begins! \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89 \n\nWin one audiobook of YOUR choice\nhttps:\/\/t.co\/3ag2K25ebe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/3ag2K25ebe",
        "expanded_url" : "http:\/\/theaudiobookworm.com\/goodies-giveaways\/",
        "display_url" : "theaudiobookworm.com\/goodies-giveaw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767899341021335552",
    "text" : "The 500 Follower Frenzy Giveaway begins! \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89 \n\nWin one audiobook of YOUR choice\nhttps:\/\/t.co\/3ag2K25ebe",
    "id" : 767899341021335552,
    "created_at" : "2016-08-23 01:40:44 +0000",
    "user" : {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "protected" : false,
      "id_str" : "4218819269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690226493151117312\/IydgluWy_normal.jpg",
      "id" : 4218819269,
      "verified" : false
    }
  },
  "id" : 769218020266868736,
  "created_at" : "2016-08-26 17:00:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "indices" : [ 3, 18 ],
      "id_str" : "25056239",
      "id" : 25056239
    }, {
      "name" : "Barron's",
      "screen_name" : "barronsonline",
      "indices" : [ 87, 101 ],
      "id_str" : "20449296",
      "id" : 20449296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/WWJtjjcXtk",
      "expanded_url" : "http:\/\/on.barrons.com\/2ce8HGK",
      "display_url" : "on.barrons.com\/2ce8HGK"
    } ]
  },
  "geo" : { },
  "id_str" : "769215723516391424",
  "text" : "RT @foodawakenings: Mylan\u2019s EpiPen Fallout Benefits Adamis https:\/\/t.co\/WWJtjjcXtk via @barronsonline",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barron's",
        "screen_name" : "barronsonline",
        "indices" : [ 67, 81 ],
        "id_str" : "20449296",
        "id" : 20449296
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/WWJtjjcXtk",
        "expanded_url" : "http:\/\/on.barrons.com\/2ce8HGK",
        "display_url" : "on.barrons.com\/2ce8HGK"
      } ]
    },
    "geo" : { },
    "id_str" : "769215382271856640",
    "text" : "Mylan\u2019s EpiPen Fallout Benefits Adamis https:\/\/t.co\/WWJtjjcXtk via @barronsonline",
    "id" : 769215382271856640,
    "created_at" : "2016-08-26 16:50:13 +0000",
    "user" : {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "protected" : false,
      "id_str" : "25056239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684904916184256512\/Zr_EBvr0_normal.jpg",
      "id" : 25056239,
      "verified" : false
    }
  },
  "id" : 769215723516391424,
  "created_at" : "2016-08-26 16:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "canoneo",
      "screen_name" : "canoneodotcom",
      "indices" : [ 3, 17 ],
      "id_str" : "732648268002398209",
      "id" : 732648268002398209
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/canoneodotcom\/status\/767030450346921984\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ty1JTZ1nmS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqUKIOiW8AAcuSG.jpg",
      "id_str" : "767030447993974784",
      "id" : 767030447993974784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqUKIOiW8AAcuSG.jpg",
      "sizes" : [ {
        "h" : 493,
        "resize" : "fit",
        "w" : 722
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 722
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 722
      } ],
      "display_url" : "pic.twitter.com\/ty1JTZ1nmS"
    } ],
    "hashtags" : [ {
      "text" : "booklovers",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "books",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769214734331736066",
  "text" : "RT @canoneodotcom: For #booklovers: the periodical table of #books. https:\/\/t.co\/ty1JTZ1nmS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/canoneodotcom\/status\/767030450346921984\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/ty1JTZ1nmS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqUKIOiW8AAcuSG.jpg",
        "id_str" : "767030447993974784",
        "id" : 767030447993974784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqUKIOiW8AAcuSG.jpg",
        "sizes" : [ {
          "h" : 493,
          "resize" : "fit",
          "w" : 722
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 722
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 722
        } ],
        "display_url" : "pic.twitter.com\/ty1JTZ1nmS"
      } ],
      "hashtags" : [ {
        "text" : "booklovers",
        "indices" : [ 4, 15 ]
      }, {
        "text" : "books",
        "indices" : [ 41, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767030450346921984",
    "text" : "For #booklovers: the periodical table of #books. https:\/\/t.co\/ty1JTZ1nmS",
    "id" : 767030450346921984,
    "created_at" : "2016-08-20 16:08:04 +0000",
    "user" : {
      "name" : "canoneo",
      "screen_name" : "canoneodotcom",
      "protected" : false,
      "id_str" : "732648268002398209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732649573341114369\/LPMGwDzq_normal.jpg",
      "id" : 732648268002398209,
      "verified" : false
    }
  },
  "id" : 769214734331736066,
  "created_at" : "2016-08-26 16:47:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769166035458985984",
  "geo" : { },
  "id_str" : "769184403100672000",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre ive noticed with my (generic) effexor I feel diff when they change manufac. interesting.",
  "id" : 769184403100672000,
  "in_reply_to_status_id" : 769166035458985984,
  "created_at" : "2016-08-26 14:47:07 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauhla Whitaker",
      "screen_name" : "overtownfarm",
      "indices" : [ 0, 13 ],
      "id_str" : "52735496",
      "id" : 52735496
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 14, 26 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769167583899713536",
  "geo" : { },
  "id_str" : "769183526843330560",
  "in_reply_to_user_id" : 52735496,
  "text" : "@overtownfarm @ErinEFarley : ((",
  "id" : 769183526843330560,
  "in_reply_to_status_id" : 769167583899713536,
  "created_at" : "2016-08-26 14:43:38 +0000",
  "in_reply_to_screen_name" : "overtownfarm",
  "in_reply_to_user_id_str" : "52735496",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paula",
      "screen_name" : "DairyFarmher",
      "indices" : [ 3, 16 ],
      "id_str" : "2202345092",
      "id" : 2202345092
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DairyFarmher\/status\/769140660305879040\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TdHWXxKlPa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyIcj9XYAA6oki.jpg",
      "id_str" : "769139660643852288",
      "id" : 769139660643852288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyIcj9XYAA6oki.jpg",
      "sizes" : [ {
        "h" : 1359,
        "resize" : "fit",
        "w" : 1856
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 879,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1359,
        "resize" : "fit",
        "w" : 1856
      } ],
      "display_url" : "pic.twitter.com\/TdHWXxKlPa"
    } ],
    "hashtags" : [ {
      "text" : "calflove",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "farmlife",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769181465951297536",
  "text" : "RT @DairyFarmher: Those curious brown eyes just melt my heart...every time!\n#calflove #farmlife https:\/\/t.co\/TdHWXxKlPa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DairyFarmher\/status\/769140660305879040\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/TdHWXxKlPa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyIcj9XYAA6oki.jpg",
        "id_str" : "769139660643852288",
        "id" : 769139660643852288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyIcj9XYAA6oki.jpg",
        "sizes" : [ {
          "h" : 1359,
          "resize" : "fit",
          "w" : 1856
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 879,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1359,
          "resize" : "fit",
          "w" : 1856
        } ],
        "display_url" : "pic.twitter.com\/TdHWXxKlPa"
      } ],
      "hashtags" : [ {
        "text" : "calflove",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "farmlife",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769140660305879040",
    "text" : "Those curious brown eyes just melt my heart...every time!\n#calflove #farmlife https:\/\/t.co\/TdHWXxKlPa",
    "id" : 769140660305879040,
    "created_at" : "2016-08-26 11:53:18 +0000",
    "user" : {
      "name" : "Paula",
      "screen_name" : "DairyFarmher",
      "protected" : false,
      "id_str" : "2202345092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627463503411068928\/Z6jtiQKv_normal.jpg",
      "id" : 2202345092,
      "verified" : false
    }
  },
  "id" : 769181465951297536,
  "created_at" : "2016-08-26 14:35:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Beef Farmers",
      "screen_name" : "beef_farmers",
      "indices" : [ 38, 51 ],
      "id_str" : "3522296363",
      "id" : 3522296363
    }, {
      "name" : "The Collier's Miner",
      "screen_name" : "collierscheese",
      "indices" : [ 52, 67 ],
      "id_str" : "66693679",
      "id" : 66693679
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QlXvve4Yi5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPv0XYAAq4Bm.jpg",
      "id_str" : "769137241465774080",
      "id" : 769137241465774080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPv0XYAAq4Bm.jpg",
      "sizes" : [ {
        "h" : 864,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 864,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 864,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QlXvve4Yi5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QlXvve4Yi5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPwCWcAEIsN9.jpg",
      "id_str" : "769137241524432897",
      "id" : 769137241524432897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPwCWcAEIsN9.jpg",
      "sizes" : [ {
        "h" : 974,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 974,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 974,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/QlXvve4Yi5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QlXvve4Yi5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPwfWgAI7M-T.jpg",
      "id_str" : "769137241646071810",
      "id" : 769137241646071810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPwfWgAI7M-T.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 746
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 746
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 746
      } ],
      "display_url" : "pic.twitter.com\/QlXvve4Yi5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QlXvve4Yi5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPwrWcAABjHS.jpg",
      "id_str" : "769137241696399360",
      "id" : 769137241696399360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPwrWcAABjHS.jpg",
      "sizes" : [ {
        "h" : 704,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/QlXvve4Yi5"
    } ],
    "hashtags" : [ {
      "text" : "NationalDogDay",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769181417255436288",
  "text" : "RT @newlandfarm: #NationalDogDay Meg  @beef_farmers @collierscheese https:\/\/t.co\/QlXvve4Yi5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Beef Farmers",
        "screen_name" : "beef_farmers",
        "indices" : [ 21, 34 ],
        "id_str" : "3522296363",
        "id" : 3522296363
      }, {
        "name" : "The Collier's Miner",
        "screen_name" : "collierscheese",
        "indices" : [ 35, 50 ],
        "id_str" : "66693679",
        "id" : 66693679
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QlXvve4Yi5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPv0XYAAq4Bm.jpg",
        "id_str" : "769137241465774080",
        "id" : 769137241465774080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPv0XYAAq4Bm.jpg",
        "sizes" : [ {
          "h" : 864,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 864,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 864,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QlXvve4Yi5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QlXvve4Yi5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPwCWcAEIsN9.jpg",
        "id_str" : "769137241524432897",
        "id" : 769137241524432897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPwCWcAEIsN9.jpg",
        "sizes" : [ {
          "h" : 974,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 974,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 352
        }, {
          "h" : 974,
          "resize" : "fit",
          "w" : 504
        } ],
        "display_url" : "pic.twitter.com\/QlXvve4Yi5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QlXvve4Yi5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPwfWgAI7M-T.jpg",
        "id_str" : "769137241646071810",
        "id" : 769137241646071810,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPwfWgAI7M-T.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 746
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 746
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 746
        } ],
        "display_url" : "pic.twitter.com\/QlXvve4Yi5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/769137329596403712\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QlXvve4Yi5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyGPwrWcAABjHS.jpg",
        "id_str" : "769137241696399360",
        "id" : 769137241696399360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyGPwrWcAABjHS.jpg",
        "sizes" : [ {
          "h" : 704,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/QlXvve4Yi5"
      } ],
      "hashtags" : [ {
        "text" : "NationalDogDay",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "769137095977889792",
    "geo" : { },
    "id_str" : "769137329596403712",
    "in_reply_to_user_id" : 2259182801,
    "text" : "#NationalDogDay Meg  @beef_farmers @collierscheese https:\/\/t.co\/QlXvve4Yi5",
    "id" : 769137329596403712,
    "in_reply_to_status_id" : 769137095977889792,
    "created_at" : "2016-08-26 11:40:03 +0000",
    "in_reply_to_screen_name" : "newlandfarm",
    "in_reply_to_user_id_str" : "2259182801",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 769181417255436288,
  "created_at" : "2016-08-26 14:35:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC7 Eyewitness News",
      "screen_name" : "ABC7",
      "indices" : [ 3, 8 ],
      "id_str" : "16374678",
      "id" : 16374678
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalDogDay",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/BSxyetWIVm",
      "expanded_url" : "http:\/\/abc7.la\/2bm3Jok",
      "display_url" : "abc7.la\/2bm3Jok"
    }, {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/fIbmDHDeUE",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/111ed36e-e190-44a3-a0c7-a67e8317c7db",
      "display_url" : "amp.twimg.com\/v\/111ed36e-e19\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769181308425732096",
  "text" : "RT @ABC7: It\u2019s #NationalDogDay. Need we say more? \uD83D\uDC36 https:\/\/t.co\/BSxyetWIVm\nhttps:\/\/t.co\/fIbmDHDeUE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalDogDay",
        "indices" : [ 5, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/BSxyetWIVm",
        "expanded_url" : "http:\/\/abc7.la\/2bm3Jok",
        "display_url" : "abc7.la\/2bm3Jok"
      }, {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/fIbmDHDeUE",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/111ed36e-e190-44a3-a0c7-a67e8317c7db",
        "display_url" : "amp.twimg.com\/v\/111ed36e-e19\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769174313630965760",
    "text" : "It\u2019s #NationalDogDay. Need we say more? \uD83D\uDC36 https:\/\/t.co\/BSxyetWIVm\nhttps:\/\/t.co\/fIbmDHDeUE",
    "id" : 769174313630965760,
    "created_at" : "2016-08-26 14:07:01 +0000",
    "user" : {
      "name" : "ABC7 Eyewitness News",
      "screen_name" : "ABC7",
      "protected" : false,
      "id_str" : "16374678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779132668344578048\/CcU9lxvj_normal.jpg",
      "id" : 16374678,
      "verified" : true
    }
  },
  "id" : 769181308425732096,
  "created_at" : "2016-08-26 14:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Mertz",
      "screen_name" : "S3nt13ntB31ng",
      "indices" : [ 3, 17 ],
      "id_str" : "139207344",
      "id" : 139207344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shitMoronsSay",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/HhCeenZxxN",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/769143177341173760",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769181068914200576",
  "text" : "RT @S3nt13ntB31ng: #shitMoronsSay https:\/\/t.co\/HhCeenZxxN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shitMoronsSay",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/HhCeenZxxN",
        "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/769143177341173760",
        "display_url" : "twitter.com\/aigkenham\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769178289994919936",
    "text" : "#shitMoronsSay https:\/\/t.co\/HhCeenZxxN",
    "id" : 769178289994919936,
    "created_at" : "2016-08-26 14:22:49 +0000",
    "user" : {
      "name" : "Fred Mertz",
      "screen_name" : "S3nt13ntB31ng",
      "protected" : false,
      "id_str" : "139207344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743910890102218752\/1bTwJ1o9_normal.jpg",
      "id" : 139207344,
      "verified" : false
    }
  },
  "id" : 769181068914200576,
  "created_at" : "2016-08-26 14:33:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/9JoFdkqVWI",
      "expanded_url" : "http:\/\/bookwi.se\/audible-daily-deal-sale\/",
      "display_url" : "bookwi.se\/audible-daily-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769161557922213889",
  "text" : "RT @adamrshields: Audible has 200 audiobooks on sale (not just members) from $0.99 to $5.95. https:\/\/t.co\/9JoFdkqVWI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/9JoFdkqVWI",
        "expanded_url" : "http:\/\/bookwi.se\/audible-daily-deal-sale\/",
        "display_url" : "bookwi.se\/audible-daily-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769153383982739456",
    "text" : "Audible has 200 audiobooks on sale (not just members) from $0.99 to $5.95. https:\/\/t.co\/9JoFdkqVWI",
    "id" : 769153383982739456,
    "created_at" : "2016-08-26 12:43:51 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 769161557922213889,
  "created_at" : "2016-08-26 13:16:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bookish\u0B9A\u0BBE\u0BA8\u0BCD\u0BA4\u0BBF",
      "screen_name" : "k_santhi",
      "indices" : [ 3, 12 ],
      "id_str" : "344496766",
      "id" : 344496766
    }, {
      "name" : "Pallavi Kamat",
      "screen_name" : "Pallavisms",
      "indices" : [ 14, 25 ],
      "id_str" : "117701668",
      "id" : 117701668
    }, {
      "name" : "Victoria Twead",
      "screen_name" : "VictoriaTwead",
      "indices" : [ 26, 40 ],
      "id_str" : "37510594",
      "id" : 37510594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/aqHf3VDyrB",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/6978430-chickens-mules-and-two-old-fools",
      "display_url" : "goodreads.com\/book\/show\/6978\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768984199424532481",
  "text" : "RT @k_santhi: @Pallavisms @VictoriaTwead's https:\/\/t.co\/aqHf3VDyrB is a hilarious memoir! Eager to catch up on the rest of her adventures ;D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pallavi Kamat",
        "screen_name" : "Pallavisms",
        "indices" : [ 0, 11 ],
        "id_str" : "117701668",
        "id" : 117701668
      }, {
        "name" : "Victoria Twead",
        "screen_name" : "VictoriaTwead",
        "indices" : [ 12, 26 ],
        "id_str" : "37510594",
        "id" : 37510594
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/aqHf3VDyrB",
        "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/6978430-chickens-mules-and-two-old-fools",
        "display_url" : "goodreads.com\/book\/show\/6978\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "748372297640206337",
    "geo" : { },
    "id_str" : "748374501344292865",
    "in_reply_to_user_id" : 117701668,
    "text" : "@Pallavisms @VictoriaTwead's https:\/\/t.co\/aqHf3VDyrB is a hilarious memoir! Eager to catch up on the rest of her adventures ;D",
    "id" : 748374501344292865,
    "in_reply_to_status_id" : 748372297640206337,
    "created_at" : "2016-06-30 04:35:59 +0000",
    "in_reply_to_screen_name" : "Pallavisms",
    "in_reply_to_user_id_str" : "117701668",
    "user" : {
      "name" : "Bookish\u0B9A\u0BBE\u0BA8\u0BCD\u0BA4\u0BBF",
      "screen_name" : "k_santhi",
      "protected" : false,
      "id_str" : "344496766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782608962168381440\/7ZD6KaEx_normal.jpg",
      "id" : 344496766,
      "verified" : false
    }
  },
  "id" : 768984199424532481,
  "created_at" : "2016-08-26 01:31:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/768982021221736448\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/gyeMiaFvKF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqv5EnEUMAAzmbi.jpg",
      "id_str" : "768982018998677504",
      "id" : 768982018998677504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqv5EnEUMAAzmbi.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 452
      } ],
      "display_url" : "pic.twitter.com\/gyeMiaFvKF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768983874533818369",
  "text" : "RT @PinarAkal1: May you always walk in Beauty. \n\n~Ojibwa Prayer https:\/\/t.co\/gyeMiaFvKF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/768982021221736448\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/gyeMiaFvKF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqv5EnEUMAAzmbi.jpg",
        "id_str" : "768982018998677504",
        "id" : 768982018998677504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqv5EnEUMAAzmbi.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 452
        } ],
        "display_url" : "pic.twitter.com\/gyeMiaFvKF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768982021221736448",
    "text" : "May you always walk in Beauty. \n\n~Ojibwa Prayer https:\/\/t.co\/gyeMiaFvKF",
    "id" : 768982021221736448,
    "created_at" : "2016-08-26 01:22:55 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 768983874533818369,
  "created_at" : "2016-08-26 01:30:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Dolphin",
      "screen_name" : "CountrysideBen",
      "indices" : [ 3, 18 ],
      "id_str" : "1481822898",
      "id" : 1481822898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768983355258003456",
  "text" : "RT @CountrysideBen: Remember the leverets suckling? I'm finally getting the footage sorted! Love how they're disorientated afterwards :) ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CountrysideBen\/status\/768869164677226496\/video\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/j0s9lRJyn4",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/768867669651165184\/pu\/img\/wtbXR5X5gslOJCUS.jpg",
        "id_str" : "768867669651165184",
        "id" : 768867669651165184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/768867669651165184\/pu\/img\/wtbXR5X5gslOJCUS.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/j0s9lRJyn4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768869164677226496",
    "text" : "Remember the leverets suckling? I'm finally getting the footage sorted! Love how they're disorientated afterwards :) https:\/\/t.co\/j0s9lRJyn4",
    "id" : 768869164677226496,
    "created_at" : "2016-08-25 17:54:28 +0000",
    "user" : {
      "name" : "Ben Dolphin",
      "screen_name" : "CountrysideBen",
      "protected" : false,
      "id_str" : "1481822898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562647934815059968\/WtE9W2tz_normal.jpeg",
      "id" : 1481822898,
      "verified" : false
    }
  },
  "id" : 768983355258003456,
  "created_at" : "2016-08-26 01:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin M. Kruse",
      "screen_name" : "KevinMKruse",
      "indices" : [ 3, 15 ],
      "id_str" : "3060489838",
      "id" : 3060489838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768972862908669952",
  "text" : "RT @KevinMKruse: Coulter says Trump wasn't mocking a disabled reporter, but was simply \"doing a standard retard.\" Well, OK, then! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/JiKOjJMz9X",
        "expanded_url" : "https:\/\/twitter.com\/joannarothkopf\/status\/768935079158620160",
        "display_url" : "twitter.com\/joannarothkopf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768942661998813184",
    "text" : "Coulter says Trump wasn't mocking a disabled reporter, but was simply \"doing a standard retard.\" Well, OK, then! https:\/\/t.co\/JiKOjJMz9X",
    "id" : 768942661998813184,
    "created_at" : "2016-08-25 22:46:31 +0000",
    "user" : {
      "name" : "Kevin M. Kruse",
      "screen_name" : "KevinMKruse",
      "protected" : false,
      "id_str" : "3060489838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702198093974863873\/MOM1zrQx_normal.png",
      "id" : 3060489838,
      "verified" : true
    }
  },
  "id" : 768972862908669952,
  "created_at" : "2016-08-26 00:46:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John DesMarteau MD",
      "screen_name" : "JohnDesMarteau",
      "indices" : [ 3, 18 ],
      "id_str" : "16235283",
      "id" : 16235283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768945947808116737",
  "text" : "RT @JohnDesMarteau: As a physician I can buy the amount of epinephrine found in an EpiPen for $1.71 A syringe and needle would add less tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768681972700971008",
    "text" : "As a physician I can buy the amount of epinephrine found in an EpiPen for $1.71 A syringe and needle would add less than $1.00. EpiPen: $484",
    "id" : 768681972700971008,
    "created_at" : "2016-08-25 05:30:38 +0000",
    "user" : {
      "name" : "John DesMarteau MD",
      "screen_name" : "JohnDesMarteau",
      "protected" : false,
      "id_str" : "16235283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000629274422\/09cedd6f84c845aaf4d37f03eaeb6e42_normal.jpeg",
      "id" : 16235283,
      "verified" : false
    }
  },
  "id" : 768945947808116737,
  "created_at" : "2016-08-25 22:59:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 3, 14 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lifehacker\/status\/768885766101565443\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Iw7mXztbao",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CquhhwgW8AA_wNM.jpg",
      "id_str" : "768885762725179392",
      "id" : 768885762725179392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CquhhwgW8AA_wNM.jpg",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 903
      } ],
      "display_url" : "pic.twitter.com\/Iw7mXztbao"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QszeZG1CiW",
      "expanded_url" : "http:\/\/lifehac.kr\/wWsQ0jo",
      "display_url" : "lifehac.kr\/wWsQ0jo"
    } ]
  },
  "geo" : { },
  "id_str" : "768898602622029824",
  "text" : "RT @lifehacker: EpiPens are crazy expensive. The Adrenaclick is a cheaper alternative: https:\/\/t.co\/QszeZG1CiW https:\/\/t.co\/Iw7mXztbao",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lifehacker\/status\/768885766101565443\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/Iw7mXztbao",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CquhhwgW8AA_wNM.jpg",
        "id_str" : "768885762725179392",
        "id" : 768885762725179392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CquhhwgW8AA_wNM.jpg",
        "sizes" : [ {
          "h" : 508,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 903
        } ],
        "display_url" : "pic.twitter.com\/Iw7mXztbao"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/QszeZG1CiW",
        "expanded_url" : "http:\/\/lifehac.kr\/wWsQ0jo",
        "display_url" : "lifehac.kr\/wWsQ0jo"
      } ]
    },
    "geo" : { },
    "id_str" : "768885766101565443",
    "text" : "EpiPens are crazy expensive. The Adrenaclick is a cheaper alternative: https:\/\/t.co\/QszeZG1CiW https:\/\/t.co\/Iw7mXztbao",
    "id" : 768885766101565443,
    "created_at" : "2016-08-25 19:00:26 +0000",
    "user" : {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "protected" : false,
      "id_str" : "7144422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590971614545612800\/eV8h6rz7_normal.png",
      "id" : 7144422,
      "verified" : true
    }
  },
  "id" : 768898602622029824,
  "created_at" : "2016-08-25 19:51:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satan's Sweetie",
      "screen_name" : "Morrigan_Roars",
      "indices" : [ 3, 18 ],
      "id_str" : "21761679",
      "id" : 21761679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/5LGKhury2I",
      "expanded_url" : "https:\/\/twitter.com\/solsikke66\/status\/768889427439607808",
      "display_url" : "twitter.com\/solsikke66\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768897552783544320",
  "text" : "RT @Morrigan_Roars: Please be true, please be true, please be true, please be true https:\/\/t.co\/5LGKhury2I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/5LGKhury2I",
        "expanded_url" : "https:\/\/twitter.com\/solsikke66\/status\/768889427439607808",
        "display_url" : "twitter.com\/solsikke66\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768890526359777281",
    "text" : "Please be true, please be true, please be true, please be true https:\/\/t.co\/5LGKhury2I",
    "id" : 768890526359777281,
    "created_at" : "2016-08-25 19:19:21 +0000",
    "user" : {
      "name" : "Satan's Sweetie",
      "screen_name" : "Morrigan_Roars",
      "protected" : false,
      "id_str" : "21761679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792813947103707136\/6TuUTES__normal.jpg",
      "id" : 21761679,
      "verified" : false
    }
  },
  "id" : 768897552783544320,
  "created_at" : "2016-08-25 19:47:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/aERCLHE4JI",
      "expanded_url" : "https:\/\/twitter.com\/OFA\/status\/768893726366179328",
      "display_url" : "twitter.com\/OFA\/status\/768\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768896883175501827",
  "text" : "hey.. poughkeepsie.. thats near me.. https:\/\/t.co\/aERCLHE4JI",
  "id" : 768896883175501827,
  "created_at" : "2016-08-25 19:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Helene",
      "screen_name" : "AimeeHelene1",
      "indices" : [ 0, 13 ],
      "id_str" : "273672451",
      "id" : 273672451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768856351120384000",
  "geo" : { },
  "id_str" : "768869434446471169",
  "in_reply_to_user_id" : 273672451,
  "text" : "@AimeeHelene1 point taken.. also is there a check in that letter? thought there would be a check...",
  "id" : 768869434446471169,
  "in_reply_to_status_id" : 768856351120384000,
  "created_at" : "2016-08-25 17:55:32 +0000",
  "in_reply_to_screen_name" : "AimeeHelene1",
  "in_reply_to_user_id_str" : "273672451",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FYI",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/T5qb1QKfF0",
      "expanded_url" : "https:\/\/twitter.com\/AimeeHelene1\/status\/684349823424671744",
      "display_url" : "twitter.com\/AimeeHelene1\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768831209904476160",
  "text" : "i get this.. but there are ppl who have skin sensitivities who cant use deodorant. #FYI https:\/\/t.co\/T5qb1QKfF0",
  "id" : 768831209904476160,
  "created_at" : "2016-08-25 15:23:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.K. Rowling",
      "screen_name" : "jk_rowling",
      "indices" : [ 3, 14 ],
      "id_str" : "62513246",
      "id" : 62513246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768823802222391297",
  "text" : "RT @jk_rowling: So Sarkozy calls the burkini a 'provocation.' Whether women cover or uncover their bodies, seems we're always, always 'aski\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768765544564678657",
    "text" : "So Sarkozy calls the burkini a 'provocation.' Whether women cover or uncover their bodies, seems we're always, always 'asking for it.'",
    "id" : 768765544564678657,
    "created_at" : "2016-08-25 11:02:43 +0000",
    "user" : {
      "name" : "J.K. Rowling",
      "screen_name" : "jk_rowling",
      "protected" : false,
      "id_str" : "62513246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791672321111126016\/_TrjGklj_normal.jpg",
      "id" : 62513246,
      "verified" : true
    }
  },
  "id" : 768823802222391297,
  "created_at" : "2016-08-25 14:54:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adopt",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/EnaBQPUKqV",
      "expanded_url" : "http:\/\/ln.is\/www.upworthy.com\/Tyh6Q",
      "display_url" : "ln.is\/www.upworthy.c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768803399273885696",
  "text" : "RT @aliceinthewater: What it\u2019s like to adopt a dog, as told through a 14-part comic. https:\/\/t.co\/EnaBQPUKqV #adopt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003EPut your button on any page! \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "adopt",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/EnaBQPUKqV",
        "expanded_url" : "http:\/\/ln.is\/www.upworthy.com\/Tyh6Q",
        "display_url" : "ln.is\/www.upworthy.c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768792700518883329",
    "text" : "What it\u2019s like to adopt a dog, as told through a 14-part comic. https:\/\/t.co\/EnaBQPUKqV #adopt",
    "id" : 768792700518883329,
    "created_at" : "2016-08-25 12:50:37 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 768803399273885696,
  "created_at" : "2016-08-25 13:33:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RC deWinter",
      "screen_name" : "RCdeWinter",
      "indices" : [ 3, 14 ],
      "id_str" : "41207820",
      "id" : 41207820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RCdeWinter\/status\/768668086895607808\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/2IqMwqZGX6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqrbjQWWAAAx1zz.jpg",
      "id_str" : "768668085150679040",
      "id" : 768668085150679040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqrbjQWWAAAx1zz.jpg",
      "sizes" : [ {
        "h" : 475,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 506
      } ],
      "display_url" : "pic.twitter.com\/2IqMwqZGX6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768801776157855744",
  "text" : "RT @RCdeWinter: Try this. https:\/\/t.co\/2IqMwqZGX6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RCdeWinter\/status\/768668086895607808\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/2IqMwqZGX6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqrbjQWWAAAx1zz.jpg",
        "id_str" : "768668085150679040",
        "id" : 768668085150679040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqrbjQWWAAAx1zz.jpg",
        "sizes" : [ {
          "h" : 475,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 506
        } ],
        "display_url" : "pic.twitter.com\/2IqMwqZGX6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768668086895607808",
    "text" : "Try this. https:\/\/t.co\/2IqMwqZGX6",
    "id" : 768668086895607808,
    "created_at" : "2016-08-25 04:35:27 +0000",
    "user" : {
      "name" : "RC deWinter",
      "screen_name" : "RCdeWinter",
      "protected" : false,
      "id_str" : "41207820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784598106772037632\/hxSylEn7_normal.jpg",
      "id" : 41207820,
      "verified" : false
    }
  },
  "id" : 768801776157855744,
  "created_at" : "2016-08-25 13:26:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bearded J's Beard",
      "screen_name" : "Thatguy5487",
      "indices" : [ 3, 15 ],
      "id_str" : "3894401721",
      "id" : 3894401721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768801122328862720",
  "text" : "RT @Thatguy5487: I'm gonna be the old guy that yells at kids \"I REMEMBER WHEN WE HAD TO USE THE INTERNET THROUGH THE PHONE LINE!\"\n\nKid: wtf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719909355768975360",
    "text" : "I'm gonna be the old guy that yells at kids \"I REMEMBER WHEN WE HAD TO USE THE INTERNET THROUGH THE PHONE LINE!\"\n\nKid: wtf is a phone line?",
    "id" : 719909355768975360,
    "created_at" : "2016-04-12 15:25:40 +0000",
    "user" : {
      "name" : "Bearded J's Beard",
      "screen_name" : "Thatguy5487",
      "protected" : false,
      "id_str" : "3894401721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782795969255661568\/0_7FkknS_normal.jpg",
      "id" : 3894401721,
      "verified" : false
    }
  },
  "id" : 768801122328862720,
  "created_at" : "2016-08-25 13:24:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Selena Maranjian",
      "screen_name" : "SelenaMaranjian",
      "indices" : [ 3, 19 ],
      "id_str" : "20060120",
      "id" : 20060120
    }, {
      "name" : "PostSecret",
      "screen_name" : "postsecret",
      "indices" : [ 32, 43 ],
      "id_str" : "19299909",
      "id" : 19299909
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SelenaMaranjian\/status\/768644845246160897\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/Hxxnoycdfe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqfwfDHVUAAymng.jpg",
      "id_str" : "767846677692633088",
      "id" : 767846677692633088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqfwfDHVUAAymng.jpg",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 455
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 455
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 455
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 455
      } ],
      "display_url" : "pic.twitter.com\/Hxxnoycdfe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768801006356312065",
  "text" : "RT @SelenaMaranjian: Yup. (from @postsecret) https:\/\/t.co\/Hxxnoycdfe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PostSecret",
        "screen_name" : "postsecret",
        "indices" : [ 11, 22 ],
        "id_str" : "19299909",
        "id" : 19299909
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SelenaMaranjian\/status\/768644845246160897\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/Hxxnoycdfe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqfwfDHVUAAymng.jpg",
        "id_str" : "767846677692633088",
        "id" : 767846677692633088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqfwfDHVUAAymng.jpg",
        "sizes" : [ {
          "h" : 253,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 455
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 455
        } ],
        "display_url" : "pic.twitter.com\/Hxxnoycdfe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768644845246160897",
    "text" : "Yup. (from @postsecret) https:\/\/t.co\/Hxxnoycdfe",
    "id" : 768644845246160897,
    "created_at" : "2016-08-25 03:03:06 +0000",
    "user" : {
      "name" : "Selena Maranjian",
      "screen_name" : "SelenaMaranjian",
      "protected" : false,
      "id_str" : "20060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610260946444009472\/vjNQk1Iu_normal.jpg",
      "id" : 20060120,
      "verified" : false
    }
  },
  "id" : 768801006356312065,
  "created_at" : "2016-08-25 13:23:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Jack Sullivan Jr",
      "screen_name" : "JackSullivanJr",
      "indices" : [ 3, 18 ],
      "id_str" : "19138287",
      "id" : 19138287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768602376341184512",
  "text" : "RT @JackSullivanJr: The death penalty is a hollow instrument of punishment that carries no redemptive value and has no power to heal, uplif\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765788144222470144",
    "text" : "The death penalty is a hollow instrument of punishment that carries no redemptive value and has no power to heal, uplift or transform lives.",
    "id" : 765788144222470144,
    "created_at" : "2016-08-17 05:51:35 +0000",
    "user" : {
      "name" : "Dr Jack Sullivan Jr",
      "screen_name" : "JackSullivanJr",
      "protected" : false,
      "id_str" : "19138287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665033492846084096\/--PRXAAZ_normal.jpg",
      "id" : 19138287,
      "verified" : false
    }
  },
  "id" : 768602376341184512,
  "created_at" : "2016-08-25 00:14:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/768536028101677057\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/HcGkIwlSdj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqpjcPZWIAA4SSg.jpg",
      "id_str" : "768536023240417280",
      "id" : 768536023240417280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqpjcPZWIAA4SSg.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/HcGkIwlSdj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768544162375430144",
  "text" : "RT @dwaynereaves: Playing with butterflies! https:\/\/t.co\/HcGkIwlSdj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/768536028101677057\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/HcGkIwlSdj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqpjcPZWIAA4SSg.jpg",
        "id_str" : "768536023240417280",
        "id" : 768536023240417280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqpjcPZWIAA4SSg.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/HcGkIwlSdj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768536028101677057",
    "text" : "Playing with butterflies! https:\/\/t.co\/HcGkIwlSdj",
    "id" : 768536028101677057,
    "created_at" : "2016-08-24 19:50:42 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 768544162375430144,
  "created_at" : "2016-08-24 20:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "indices" : [ 3, 12 ],
      "id_str" : "75372132",
      "id" : 75372132
    }, {
      "name" : "John Krasinski",
      "screen_name" : "johnkrasinski",
      "indices" : [ 15, 29 ],
      "id_str" : "17844280",
      "id" : 17844280
    }, {
      "name" : "TVLine.com",
      "screen_name" : "TVLine",
      "indices" : [ 130, 137 ],
      "id_str" : "227347152",
      "id" : 227347152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/sWd5HnJ3jf",
      "expanded_url" : "http:\/\/ow.ly\/ux9g303t4PZ",
      "display_url" : "ow.ly\/ux9g303t4PZ"
    } ]
  },
  "geo" : { },
  "id_str" : "768504548541526017",
  "text" : "RT @PRHAudio: .@johnkrasinski is going to star in the upcoming Tom Clancy\u200B's JACK RYAN series at Amazon!  https:\/\/t.co\/sWd5HnJ3jf @TVLine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Krasinski",
        "screen_name" : "johnkrasinski",
        "indices" : [ 1, 15 ],
        "id_str" : "17844280",
        "id" : 17844280
      }, {
        "name" : "TVLine.com",
        "screen_name" : "TVLine",
        "indices" : [ 116, 123 ],
        "id_str" : "227347152",
        "id" : 227347152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/sWd5HnJ3jf",
        "expanded_url" : "http:\/\/ow.ly\/ux9g303t4PZ",
        "display_url" : "ow.ly\/ux9g303t4PZ"
      } ]
    },
    "geo" : { },
    "id_str" : "768423936841379840",
    "text" : ".@johnkrasinski is going to star in the upcoming Tom Clancy\u200B's JACK RYAN series at Amazon!  https:\/\/t.co\/sWd5HnJ3jf @TVLine",
    "id" : 768423936841379840,
    "created_at" : "2016-08-24 12:25:17 +0000",
    "user" : {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "protected" : false,
      "id_str" : "75372132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606215515279753216\/KBzpETdK_normal.jpg",
      "id" : 75372132,
      "verified" : false
    }
  },
  "id" : 768504548541526017,
  "created_at" : "2016-08-24 17:45:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/768292314145972224\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/zNtWW9R985",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqmFxvKUEAArZXU.jpg",
      "id_str" : "768292300963188736",
      "id" : 768292300963188736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqmFxvKUEAArZXU.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zNtWW9R985"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768447230781063168",
  "text" : "RT @ErinEFarley: Fall colors rock! https:\/\/t.co\/zNtWW9R985",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/768292314145972224\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/zNtWW9R985",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqmFxvKUEAArZXU.jpg",
        "id_str" : "768292300963188736",
        "id" : 768292300963188736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqmFxvKUEAArZXU.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/zNtWW9R985"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768292314145972224",
    "text" : "Fall colors rock! https:\/\/t.co\/zNtWW9R985",
    "id" : 768292314145972224,
    "created_at" : "2016-08-24 03:42:16 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 768447230781063168,
  "created_at" : "2016-08-24 13:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768446314766098432",
  "text" : "RT @aliceinthewater: Stop telling women what to wear. Why do I keep having to say this?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768417901850222592",
    "text" : "Stop telling women what to wear. Why do I keep having to say this?",
    "id" : 768417901850222592,
    "created_at" : "2016-08-24 12:01:18 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 768446314766098432,
  "created_at" : "2016-08-24 13:54:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b9AcE",
      "screen_name" : "b9AcE",
      "indices" : [ 3, 9 ],
      "id_str" : "20208431",
      "id" : 20208431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768446270352584704",
  "text" : "RT @b9AcE: 1:Siam just wore clothes, not burkini.\n2:French morality police fined her anyway.\n3:Citizens since &gt;3 generations. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/b9AcE\/status\/768315415814475776\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/yXebi3TCea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqmaVBRWAAAWcdh.jpg",
        "id_str" : "768314897352491008",
        "id" : 768314897352491008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqmaVBRWAAAWcdh.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2184,
          "resize" : "fit",
          "w" : 3276
        } ],
        "display_url" : "pic.twitter.com\/yXebi3TCea"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/b9AcE\/status\/768315415814475776\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/yXebi3TCea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqmaYMoWIAAeDzu.jpg",
        "id_str" : "768314951941365760",
        "id" : 768314951941365760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqmaYMoWIAAeDzu.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1747,
          "resize" : "fit",
          "w" : 2621
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/yXebi3TCea"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/b9AcE\/status\/768315415814475776\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/yXebi3TCea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqmaZnzWYAAuV_h.jpg",
        "id_str" : "768314976415145984",
        "id" : 768314976415145984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqmaZnzWYAAuV_h.jpg",
        "sizes" : [ {
          "h" : 3276,
          "resize" : "fit",
          "w" : 2184
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1365
        } ],
        "display_url" : "pic.twitter.com\/yXebi3TCea"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/b9AcE\/status\/768315415814475776\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/yXebi3TCea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqmaa0UWAAAJE0L.jpg",
        "id_str" : "768314996954628096",
        "id" : 768314996954628096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqmaa0UWAAAJE0L.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2184,
          "resize" : "fit",
          "w" : 3276
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/yXebi3TCea"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768315415814475776",
    "text" : "1:Siam just wore clothes, not burkini.\n2:French morality police fined her anyway.\n3:Citizens since &gt;3 generations. https:\/\/t.co\/yXebi3TCea",
    "id" : 768315415814475776,
    "created_at" : "2016-08-24 05:14:04 +0000",
    "user" : {
      "name" : "b9AcE",
      "screen_name" : "b9AcE",
      "protected" : false,
      "id_str" : "20208431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754232183502606338\/MmuHFI1j_normal.jpg",
      "id" : 20208431,
      "verified" : false
    }
  },
  "id" : 768446270352584704,
  "created_at" : "2016-08-24 13:54:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768446231131615232",
  "text" : "RT @aliceinthewater: The first picture I saw this morning was four white French cops forcing a women to strip in public. Straight up pisses\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768410251066351616",
    "text" : "The first picture I saw this morning was four white French cops forcing a women to strip in public. Straight up pisses me off.",
    "id" : 768410251066351616,
    "created_at" : "2016-08-24 11:30:54 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 768446231131615232,
  "created_at" : "2016-08-24 13:53:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768235190724366337",
  "geo" : { },
  "id_str" : "768236994413621248",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre oh dear..lol",
  "id" : 768236994413621248,
  "in_reply_to_status_id" : 768235190724366337,
  "created_at" : "2016-08-24 00:02:27 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 47, 62 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/55810vlDjF",
      "expanded_url" : "https:\/\/twitter.com\/OutsmartDisease\/status\/768205001185427456",
      "display_url" : "twitter.com\/OutsmartDiseas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768207458938527748",
  "text" : "or psychiatric.. and psych drugs pushed.. grr. #chronicillness #hashimotos https:\/\/t.co\/55810vlDjF",
  "id" : 768207458938527748,
  "created_at" : "2016-08-23 22:05:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indigo Black Jaguar",
      "screen_name" : "_BlackJaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "98409590",
      "id" : 98409590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768199430990364672",
  "text" : "RT @_BlackJaguar: I'm a big fan of watching people grow and becoming healthier and happier versions of themselves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743094169124638720",
    "text" : "I'm a big fan of watching people grow and becoming healthier and happier versions of themselves.",
    "id" : 743094169124638720,
    "created_at" : "2016-06-15 14:53:50 +0000",
    "user" : {
      "name" : "Indigo Black Jaguar",
      "screen_name" : "_BlackJaguar",
      "protected" : false,
      "id_str" : "98409590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753545087926304768\/kFJysKXJ_normal.jpg",
      "id" : 98409590,
      "verified" : false
    }
  },
  "id" : 768199430990364672,
  "created_at" : "2016-08-23 21:33:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Vines",
      "screen_name" : "VinesMatthew",
      "indices" : [ 3, 16 ],
      "id_str" : "296506338",
      "id" : 296506338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768198572235952130",
  "text" : "RT @VinesMatthew: This is a very touching story and video highlighting the power of community support for gay couples. https:\/\/t.co\/rpoKADN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/rpoKADNEnF",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/neighborhood-rainbow-flags-egging_us_57bc685fe4b00d9c3a1a0802?section=&",
        "display_url" : "huffingtonpost.com\/entry\/neighbor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768196300873486338",
    "text" : "This is a very touching story and video highlighting the power of community support for gay couples. https:\/\/t.co\/rpoKADNEnF",
    "id" : 768196300873486338,
    "created_at" : "2016-08-23 21:20:45 +0000",
    "user" : {
      "name" : "Matthew Vines",
      "screen_name" : "VinesMatthew",
      "protected" : false,
      "id_str" : "296506338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720763801700667392\/1RFJsamq_normal.jpg",
      "id" : 296506338,
      "verified" : true
    }
  },
  "id" : 768198572235952130,
  "created_at" : "2016-08-23 21:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Greenhouse",
      "screen_name" : "greenhousenyt",
      "indices" : [ 3, 17 ],
      "id_str" : "268476335",
      "id" : 268476335
    }, {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 114, 122 ],
      "id_str" : "15012486",
      "id" : 15012486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CBSNews\/status\/767846062681915392\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/bzchJEejAq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqfv7M5XgAE7NrR.jpg",
      "id_str" : "767846061843120129",
      "id" : 767846061843120129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqfv7M5XgAE7NrR.jpg",
      "sizes" : [ {
        "h" : 507,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 784
      } ],
      "display_url" : "pic.twitter.com\/bzchJEejAq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768198406573613056",
  "text" : "RT @greenhousenyt: This homework policy from a second grade teacher is inspired. \n\nhttps:\/\/t.co\/bzchJEejAq\n\n(from @CBSNews)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBS News",
        "screen_name" : "CBSNews",
        "indices" : [ 95, 103 ],
        "id_str" : "15012486",
        "id" : 15012486
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CBSNews\/status\/767846062681915392\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/bzchJEejAq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqfv7M5XgAE7NrR.jpg",
        "id_str" : "767846061843120129",
        "id" : 767846061843120129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqfv7M5XgAE7NrR.jpg",
        "sizes" : [ {
          "h" : 507,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 784
        } ],
        "display_url" : "pic.twitter.com\/bzchJEejAq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768107292076089344",
    "text" : "This homework policy from a second grade teacher is inspired. \n\nhttps:\/\/t.co\/bzchJEejAq\n\n(from @CBSNews)",
    "id" : 768107292076089344,
    "created_at" : "2016-08-23 15:27:03 +0000",
    "user" : {
      "name" : "Steven Greenhouse",
      "screen_name" : "greenhousenyt",
      "protected" : false,
      "id_str" : "268476335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787700102248947713\/5pAhmgOr_normal.jpg",
      "id" : 268476335,
      "verified" : false
    }
  },
  "id" : 768198406573613056,
  "created_at" : "2016-08-23 21:29:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lynn \uD83D\uDC9E",
      "screen_name" : "lynnellenbooth",
      "indices" : [ 3, 18 ],
      "id_str" : "407930141",
      "id" : 407930141
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lynnellenbooth\/status\/767730598169509888\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/Sbgx0SBd9e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeG57FXEAEFkIO.jpg",
      "id_str" : "767730591160799233",
      "id" : 767730591160799233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeG57FXEAEFkIO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 899
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 899
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 899
      } ],
      "display_url" : "pic.twitter.com\/Sbgx0SBd9e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768197312225107968",
  "text" : "RT @lynnellenbooth: Nicking the nuts \uD83D\uDE02 https:\/\/t.co\/Sbgx0SBd9e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lynnellenbooth\/status\/767730598169509888\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/Sbgx0SBd9e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeG57FXEAEFkIO.jpg",
        "id_str" : "767730591160799233",
        "id" : 767730591160799233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeG57FXEAEFkIO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 597
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 899
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 899
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 899
        } ],
        "display_url" : "pic.twitter.com\/Sbgx0SBd9e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767730598169509888",
    "text" : "Nicking the nuts \uD83D\uDE02 https:\/\/t.co\/Sbgx0SBd9e",
    "id" : 767730598169509888,
    "created_at" : "2016-08-22 14:30:13 +0000",
    "user" : {
      "name" : "lynn \uD83D\uDC9E",
      "screen_name" : "lynnellenbooth",
      "protected" : false,
      "id_str" : "407930141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792329373999300608\/DOqUoeda_normal.jpg",
      "id" : 407930141,
      "verified" : false
    }
  },
  "id" : 768197312225107968,
  "created_at" : "2016-08-23 21:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768197081106350080",
  "text" : "RT @Swanwhisperer: New hedgehog. In the garden just I've just weighed it was massive and very heavy , named knuckles 1,238kg. Released safe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768182673412153344",
    "text" : "New hedgehog. In the garden just I've just weighed it was massive and very heavy , named knuckles 1,238kg. Released safely went into ivy.",
    "id" : 768182673412153344,
    "created_at" : "2016-08-23 20:26:36 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 768197081106350080,
  "created_at" : "2016-08-23 21:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/768181612399833089\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/8on1Zj2bR5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqkhGoaWgAAs1Wr.jpg",
      "id_str" : "768181609254256640",
      "id" : 768181609254256640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqkhGoaWgAAs1Wr.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/8on1Zj2bR5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/aK2Wimx2Ir",
      "expanded_url" : "https:\/\/www.fitbit.com\/twitter\/auth_callback?oauth_token=d2sktAAAAAAAASEAAAABVrkPhxo&oauth_verifier=dQdfdzes04wA3DMw73hucDURyv2cZTDN&_ts=1471983737",
      "display_url" : "fitbit.com\/twitter\/auth_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768181612399833089",
  "text" : "Edit Profile - Share https:\/\/t.co\/aK2Wimx2Ir https:\/\/t.co\/8on1Zj2bR5",
  "id" : 768181612399833089,
  "created_at" : "2016-08-23 20:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/IwFdbF8GuR",
      "expanded_url" : "http:\/\/makezine.com\/2016\/08\/17\/3d-printed-spatial-reasoning-tools-visually-impaired\/",
      "display_url" : "makezine.com\/2016\/08\/17\/3d-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768163205868814336",
  "text" : "RT @ErinEFarley: Very cool!\n3D Print Your Own Tactile Measuring Tools for the Visually Impaired https:\/\/t.co\/IwFdbF8GuR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/IwFdbF8GuR",
        "expanded_url" : "http:\/\/makezine.com\/2016\/08\/17\/3d-printed-spatial-reasoning-tools-visually-impaired\/",
        "display_url" : "makezine.com\/2016\/08\/17\/3d-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768136696151977985",
    "text" : "Very cool!\n3D Print Your Own Tactile Measuring Tools for the Visually Impaired https:\/\/t.co\/IwFdbF8GuR",
    "id" : 768136696151977985,
    "created_at" : "2016-08-23 17:23:54 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 768163205868814336,
  "created_at" : "2016-08-23 19:09:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Adams",
      "screen_name" : "scientistjadams",
      "indices" : [ 3, 19 ],
      "id_str" : "28931314",
      "id" : 28931314
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "science",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "TEDtalks",
      "indices" : [ 121, 130 ]
    }, {
      "text" : "video",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768128920151556097",
  "text" : "RT @scientistjadams: A fun intro to the world of quantum biology. This is the kind of stuff I study :) #physics #science #TEDtalks #video h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "physics",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "science",
        "indices" : [ 91, 99 ]
      }, {
        "text" : "TEDtalks",
        "indices" : [ 100, 109 ]
      }, {
        "text" : "video",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/b15c3YVtVV",
        "expanded_url" : "http:\/\/www.ted.com\/talks\/jim_al_khalili_how_quantum_biology_might_explain_life_s_biggest_questions?utm_source=twitter.com&utm_medium=social&utm_campaign=tedspread",
        "display_url" : "ted.com\/talks\/jim_al_k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758178897204764672",
    "text" : "A fun intro to the world of quantum biology. This is the kind of stuff I study :) #physics #science #TEDtalks #video https:\/\/t.co\/b15c3YVtVV",
    "id" : 758178897204764672,
    "created_at" : "2016-07-27 05:55:10 +0000",
    "user" : {
      "name" : "Josh Adams",
      "screen_name" : "scientistjadams",
      "protected" : false,
      "id_str" : "28931314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745428581203902464\/dTy7naI__normal.jpg",
      "id" : 28931314,
      "verified" : false
    }
  },
  "id" : 768128920151556097,
  "created_at" : "2016-08-23 16:53:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence M. Krauss",
      "screen_name" : "LKrauss1",
      "indices" : [ 3, 12 ],
      "id_str" : "556151596",
      "id" : 556151596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768111692114898944",
  "text" : "RT @LKrauss1: excited about an announcement tomorrow that will make our immediate neighborhood in the galaxy more interesting! stay tuned.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768107795333865472",
    "text" : "excited about an announcement tomorrow that will make our immediate neighborhood in the galaxy more interesting! stay tuned.",
    "id" : 768107795333865472,
    "created_at" : "2016-08-23 15:29:03 +0000",
    "user" : {
      "name" : "Lawrence M. Krauss",
      "screen_name" : "LKrauss1",
      "protected" : false,
      "id_str" : "556151596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669621673075675136\/4G9EV1E7_normal.jpg",
      "id" : 556151596,
      "verified" : true
    }
  },
  "id" : 768111692114898944,
  "created_at" : "2016-08-23 15:44:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jpfoster65",
      "screen_name" : "jpfoster65",
      "indices" : [ 3, 14 ],
      "id_str" : "69058834",
      "id" : 69058834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768096358456762368",
  "text" : "RT @jpfoster65: Let's be clear. The Health Insurance industry does not provide care. It profits by brokering your access to care and pays C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768069739641970688",
    "text" : "Let's be clear. The Health Insurance industry does not provide care. It profits by brokering your access to care and pays Congress well too.",
    "id" : 768069739641970688,
    "created_at" : "2016-08-23 12:57:50 +0000",
    "user" : {
      "name" : "jpfoster65",
      "screen_name" : "jpfoster65",
      "protected" : false,
      "id_str" : "69058834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783653725294460928\/BgTIFpQm_normal.jpg",
      "id" : 69058834,
      "verified" : false
    }
  },
  "id" : 768096358456762368,
  "created_at" : "2016-08-23 14:43:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mercy\u2605Applewhite",
      "screen_name" : "MercytheMadman",
      "indices" : [ 3, 18 ],
      "id_str" : "726088480074268673",
      "id" : 726088480074268673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768095521345077248",
  "text" : "RT @MercytheMadman: Good morning, glorious people. Let's try our best to not suck today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768091492015411200",
    "text" : "Good morning, glorious people. Let's try our best to not suck today.",
    "id" : 768091492015411200,
    "created_at" : "2016-08-23 14:24:16 +0000",
    "user" : {
      "name" : "Mercy\u2605Applewhite",
      "screen_name" : "MercytheMadman",
      "protected" : false,
      "id_str" : "726088480074268673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801049421320290304\/Jxgvj2R0_normal.jpg",
      "id" : 726088480074268673,
      "verified" : false
    }
  },
  "id" : 768095521345077248,
  "created_at" : "2016-08-23 14:40:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767880700120956928",
  "text" : "RT @Swanwhisperer: Best swan rescue today m she was so noisy but soon calmed down , all the people in cars were like what is that. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/767746106595901440\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/efnrFhdxBo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeU8X0W8AAs7g1.jpg",
        "id_str" : "767746026396643328",
        "id" : 767746026396643328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeU8X0W8AAs7g1.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 686
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 456
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 686
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 686
        } ],
        "display_url" : "pic.twitter.com\/efnrFhdxBo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/767746106595901440\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/efnrFhdxBo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeU8Y0W8AErgWL.jpg",
        "id_str" : "767746026665078785",
        "id" : 767746026665078785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeU8Y0W8AErgWL.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 446
        } ],
        "display_url" : "pic.twitter.com\/efnrFhdxBo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767746106595901440",
    "text" : "Best swan rescue today m she was so noisy but soon calmed down , all the people in cars were like what is that. https:\/\/t.co\/efnrFhdxBo",
    "id" : 767746106595901440,
    "created_at" : "2016-08-22 15:31:50 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 767880700120956928,
  "created_at" : "2016-08-23 00:26:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SJ Drummond",
      "screen_name" : "S_JDrummond",
      "indices" : [ 3, 15 ],
      "id_str" : "222539778",
      "id" : 222539778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OsliebraeAyrshires",
      "indices" : [ 112, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767873109454184448",
  "text" : "RT @S_JDrummond: Stopped for a chat with Sally, she's a feisty madam,therefore obviously my most favourite cow. #OsliebraeAyrshires https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/S_JDrummond\/status\/767755778023428096\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/LhGbo7SGuM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqedxsNWcAAHkdV.jpg",
        "id_str" : "767755738496266240",
        "id" : 767755738496266240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqedxsNWcAAHkdV.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/LhGbo7SGuM"
      } ],
      "hashtags" : [ {
        "text" : "OsliebraeAyrshires",
        "indices" : [ 95, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767755778023428096",
    "text" : "Stopped for a chat with Sally, she's a feisty madam,therefore obviously my most favourite cow. #OsliebraeAyrshires https:\/\/t.co\/LhGbo7SGuM",
    "id" : 767755778023428096,
    "created_at" : "2016-08-22 16:10:16 +0000",
    "user" : {
      "name" : "SJ Drummond",
      "screen_name" : "S_JDrummond",
      "protected" : false,
      "id_str" : "222539778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782151465892667395\/1ckcX71g_normal.jpg",
      "id" : 222539778,
      "verified" : false
    }
  },
  "id" : 767873109454184448,
  "created_at" : "2016-08-22 23:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmers Of The UK",
      "screen_name" : "FarmersOfTheUK",
      "indices" : [ 3, 18 ],
      "id_str" : "2276009684",
      "id" : 2276009684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767873075522174977",
  "text" : "RT @FarmersOfTheUK: When youre out and about every day its good to be able to capture such moments, thank goodness for smart phones https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmersOfTheUK\/status\/767787967154880512\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/u5logDLHsZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqe6yIsWAAAFkTZ.jpg",
        "id_str" : "767787631979659264",
        "id" : 767787631979659264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqe6yIsWAAAFkTZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/u5logDLHsZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767787967154880512",
    "text" : "When youre out and about every day its good to be able to capture such moments, thank goodness for smart phones https:\/\/t.co\/u5logDLHsZ",
    "id" : 767787967154880512,
    "created_at" : "2016-08-22 18:18:10 +0000",
    "user" : {
      "name" : "Farmers Of The UK",
      "screen_name" : "FarmersOfTheUK",
      "protected" : false,
      "id_str" : "2276009684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800632571730214912\/h-qop8FT_normal.jpg",
      "id" : 2276009684,
      "verified" : false
    }
  },
  "id" : 767873075522174977,
  "created_at" : "2016-08-22 23:56:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((OhNoSheTwitnt)))",
      "screen_name" : "OhNoSheTwitnt",
      "indices" : [ 3, 17 ],
      "id_str" : "149249831",
      "id" : 149249831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767748111414521856",
  "text" : "RT @OhNoSheTwitnt: The fact that \"White Lives Matter\" is even a thing just proves that too many white people don't understand what \"Black L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "767503146298073088",
    "geo" : { },
    "id_str" : "767663324377022464",
    "in_reply_to_user_id" : 149249831,
    "text" : "The fact that \"White Lives Matter\" is even a thing just proves that too many white people don't understand what \"Black Lives Matter\" means.",
    "id" : 767663324377022464,
    "in_reply_to_status_id" : 767503146298073088,
    "created_at" : "2016-08-22 10:02:53 +0000",
    "in_reply_to_screen_name" : "OhNoSheTwitnt",
    "in_reply_to_user_id_str" : "149249831",
    "user" : {
      "name" : "(((OhNoSheTwitnt)))",
      "screen_name" : "OhNoSheTwitnt",
      "protected" : false,
      "id_str" : "149249831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796342355280465920\/ibvQ8Vtb_normal.jpg",
      "id" : 149249831,
      "verified" : false
    }
  },
  "id" : 767748111414521856,
  "created_at" : "2016-08-22 15:39:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Banks",
      "screen_name" : "KelseyBanks",
      "indices" : [ 3, 15 ],
      "id_str" : "16990814",
      "id" : 16990814
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KelseyBanks\/status\/767744100082847744\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/hdrSMTk3li",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeTKNgWAAAb8VV.jpg",
      "id_str" : "767744065123254272",
      "id" : 767744065123254272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeTKNgWAAAb8VV.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/hdrSMTk3li"
    } ],
    "hashtags" : [ {
      "text" : "LaurelLeaFarms",
      "indices" : [ 62, 77 ]
    }, {
      "text" : "OntAg",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767747782023245824",
  "text" : "RT @KelseyBanks: Very cool sight to come out to this morning! #LaurelLeaFarms #OntAg https:\/\/t.co\/hdrSMTk3li",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KelseyBanks\/status\/767744100082847744\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/hdrSMTk3li",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeTKNgWAAAb8VV.jpg",
        "id_str" : "767744065123254272",
        "id" : 767744065123254272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeTKNgWAAAb8VV.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/hdrSMTk3li"
      } ],
      "hashtags" : [ {
        "text" : "LaurelLeaFarms",
        "indices" : [ 45, 60 ]
      }, {
        "text" : "OntAg",
        "indices" : [ 61, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767744100082847744",
    "text" : "Very cool sight to come out to this morning! #LaurelLeaFarms #OntAg https:\/\/t.co\/hdrSMTk3li",
    "id" : 767744100082847744,
    "created_at" : "2016-08-22 15:23:52 +0000",
    "user" : {
      "name" : "Kelsey Banks",
      "screen_name" : "KelseyBanks",
      "protected" : false,
      "id_str" : "16990814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784973566244708352\/hSsuZk-K_normal.jpg",
      "id" : 16990814,
      "verified" : false
    }
  },
  "id" : 767747782023245824,
  "created_at" : "2016-08-22 15:38:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paizo Inc.",
      "screen_name" : "paizo",
      "indices" : [ 3, 9 ],
      "id_str" : "16162631",
      "id" : 16162631
    }, {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 15, 27 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767456479536353281",
  "text" : "RT @paizo: The @audible_com sale ends on Sunday\u2014learn more about Salim, the planes, and the godless realm of Rahadoum! https:\/\/t.co\/geMKx9r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audible",
        "screen_name" : "audible_com",
        "indices" : [ 4, 16 ],
        "id_str" : "21001534",
        "id" : 21001534
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/geMKx9rYg5",
        "expanded_url" : "https:\/\/twitter.com\/jameslsutter\/status\/766018167453868032",
        "display_url" : "twitter.com\/jameslsutter\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767073760209833985",
    "text" : "The @audible_com sale ends on Sunday\u2014learn more about Salim, the planes, and the godless realm of Rahadoum! https:\/\/t.co\/geMKx9rYg5",
    "id" : 767073760209833985,
    "created_at" : "2016-08-20 19:00:10 +0000",
    "user" : {
      "name" : "Paizo Inc.",
      "screen_name" : "paizo",
      "protected" : false,
      "id_str" : "16162631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585550186887413762\/lh441jRw_normal.jpg",
      "id" : 16162631,
      "verified" : false
    }
  },
  "id" : 767456479536353281,
  "created_at" : "2016-08-21 20:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifeand",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "feedly",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/kuTHeUwiHZ",
      "expanded_url" : "http:\/\/thedancingdonkey.blogspot.com\/2016\/08\/stable-relations.html",
      "display_url" : "thedancingdonkey.blogspot.com\/2016\/08\/stable\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767371309395374080",
  "text" : "Stable Relations https:\/\/t.co\/kuTHeUwiHZ #lifeand stuff #feedly",
  "id" : 767371309395374080,
  "created_at" : "2016-08-21 14:42:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767128449475571712",
  "text" : "did anyone miss me? back home again. catsitter (DH's sis) kept cats very happy.",
  "id" : 767128449475571712,
  "created_at" : "2016-08-20 22:37:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Animal News",
      "screen_name" : "WorldAnimalNews",
      "indices" : [ 3, 19 ],
      "id_str" : "1532591052",
      "id" : 1532591052
    }, {
      "name" : "World Animal News",
      "screen_name" : "WorldAnimalNews",
      "indices" : [ 121, 137 ],
      "id_str" : "1532591052",
      "id" : 1532591052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767127925602848768",
  "text" : "RT @WorldAnimalNews: A swan practicing for the 2020 Olympics soccer team. We must admit that this is pretty incredible\u26BD\uFE0F\uD83D\uDC9E@worldanimalnews h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "World Animal News",
        "screen_name" : "WorldAnimalNews",
        "indices" : [ 100, 116 ],
        "id_str" : "1532591052",
        "id" : 1532591052
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WorldAnimalNews\/status\/767049311855063040\/video\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/VVf66yDCBX",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/767048924465025024\/pu\/img\/r3aeidBN_z2UQ6he.jpg",
        "id_str" : "767048924465025024",
        "id" : 767048924465025024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/767048924465025024\/pu\/img\/r3aeidBN_z2UQ6he.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VVf66yDCBX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767049311855063040",
    "text" : "A swan practicing for the 2020 Olympics soccer team. We must admit that this is pretty incredible\u26BD\uFE0F\uD83D\uDC9E@worldanimalnews https:\/\/t.co\/VVf66yDCBX",
    "id" : 767049311855063040,
    "created_at" : "2016-08-20 17:23:01 +0000",
    "user" : {
      "name" : "World Animal News",
      "screen_name" : "WorldAnimalNews",
      "protected" : false,
      "id_str" : "1532591052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707468471542669312\/GZVMuR-e_normal.jpg",
      "id" : 1532591052,
      "verified" : false
    }
  },
  "id" : 767127925602848768,
  "created_at" : "2016-08-20 22:35:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/766740618857021440\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/9TJJCEYpfl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQCaCsWAAEqkWz.jpg",
      "id_str" : "766740482982543361",
      "id" : 766740482982543361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQCaCsWAAEqkWz.jpg",
      "sizes" : [ {
        "h" : 572,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 1307
      }, {
        "h" : 1010,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 1307
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/9TJJCEYpfl"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/766740618857021440\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/9TJJCEYpfl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQCaCxWgAInE9T.jpg",
      "id_str" : "766740483003547650",
      "id" : 766740483003547650,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQCaCxWgAInE9T.jpg",
      "sizes" : [ {
        "h" : 932,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1312,
        "resize" : "fit",
        "w" : 1690
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1312,
        "resize" : "fit",
        "w" : 1690
      } ],
      "display_url" : "pic.twitter.com\/9TJJCEYpfl"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/766740618857021440\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/9TJJCEYpfl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQCaITWAAAnJK7.jpg",
      "id_str" : "766740484488298496",
      "id" : 766740484488298496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQCaITWAAAnJK7.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9TJJCEYpfl"
    } ],
    "hashtags" : [ {
      "text" : "WeeHairyCoos",
      "indices" : [ 29, 42 ]
    }, {
      "text" : "Highlands",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766794932103290881",
  "text" : "RT @newlandfarm: Windy Morag #WeeHairyCoos #Highlands https:\/\/t.co\/9TJJCEYpfl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/766740618857021440\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/9TJJCEYpfl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQCaCsWAAEqkWz.jpg",
        "id_str" : "766740482982543361",
        "id" : 766740482982543361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQCaCsWAAEqkWz.jpg",
        "sizes" : [ {
          "h" : 572,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 1307
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 1307
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/9TJJCEYpfl"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/766740618857021440\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/9TJJCEYpfl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQCaCxWgAInE9T.jpg",
        "id_str" : "766740483003547650",
        "id" : 766740483003547650,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQCaCxWgAInE9T.jpg",
        "sizes" : [ {
          "h" : 932,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1312,
          "resize" : "fit",
          "w" : 1690
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1312,
          "resize" : "fit",
          "w" : 1690
        } ],
        "display_url" : "pic.twitter.com\/9TJJCEYpfl"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/766740618857021440\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/9TJJCEYpfl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQCaITWAAAnJK7.jpg",
        "id_str" : "766740484488298496",
        "id" : 766740484488298496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQCaITWAAAnJK7.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9TJJCEYpfl"
      } ],
      "hashtags" : [ {
        "text" : "WeeHairyCoos",
        "indices" : [ 12, 25 ]
      }, {
        "text" : "Highlands",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766740618857021440",
    "text" : "Windy Morag #WeeHairyCoos #Highlands https:\/\/t.co\/9TJJCEYpfl",
    "id" : 766740618857021440,
    "created_at" : "2016-08-19 20:56:23 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 766794932103290881,
  "created_at" : "2016-08-20 00:32:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/766683627249889281\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/qz8feYFWeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPOsRnXYAA7xj0.jpg",
      "id_str" : "766683621621194752",
      "id" : 766683621621194752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPOsRnXYAA7xj0.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/qz8feYFWeU"
    } ],
    "hashtags" : [ {
      "text" : "WorldPhotographyDay",
      "indices" : [ 18, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/HYRFoJ4la7",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766705261839060992",
  "text" : "RT @dwaynereaves: #WorldPhotographyDay  https:\/\/t.co\/HYRFoJ4la7 https:\/\/t.co\/qz8feYFWeU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/766683627249889281\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/qz8feYFWeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPOsRnXYAA7xj0.jpg",
        "id_str" : "766683621621194752",
        "id" : 766683621621194752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPOsRnXYAA7xj0.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/qz8feYFWeU"
      } ],
      "hashtags" : [ {
        "text" : "WorldPhotographyDay",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/HYRFoJ4la7",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766683627249889281",
    "text" : "#WorldPhotographyDay  https:\/\/t.co\/HYRFoJ4la7 https:\/\/t.co\/qz8feYFWeU",
    "id" : 766683627249889281,
    "created_at" : "2016-08-19 17:09:55 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 766705261839060992,
  "created_at" : "2016-08-19 18:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766665978272940032",
  "text" : "Poor DH has been sitting on beach alone all week. Sun too bright for me and I burned even with sunscreen.",
  "id" : 766665978272940032,
  "created_at" : "2016-08-19 15:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/766644404182540288\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/OXtHbllFsm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOrA1cW8AA1KYu.jpg",
      "id_str" : "766644392417488896",
      "id" : 766644392417488896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOrA1cW8AA1KYu.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/OXtHbllFsm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/1GIfZDqSBj",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/1149140925159729\/?type=3&theater",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766665161386106880",
  "text" : "RT @dwaynereaves: Using the least to get the best. https:\/\/t.co\/1GIfZDqSBj https:\/\/t.co\/OXtHbllFsm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/766644404182540288\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/OXtHbllFsm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOrA1cW8AA1KYu.jpg",
        "id_str" : "766644392417488896",
        "id" : 766644392417488896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOrA1cW8AA1KYu.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/OXtHbllFsm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/1GIfZDqSBj",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/1149140925159729\/?type=3&theater",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766644404182540288",
    "text" : "Using the least to get the best. https:\/\/t.co\/1GIfZDqSBj https:\/\/t.co\/OXtHbllFsm",
    "id" : 766644404182540288,
    "created_at" : "2016-08-19 14:34:04 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 766665161386106880,
  "created_at" : "2016-08-19 15:56:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766632506498117632",
  "text" : "RT @onealexharms: Remember card catalogs &amp; not having a cell phone (or computer!)? Do you ever think \"holy shit, what just happened?!?!?!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766445081394044929",
    "text" : "Remember card catalogs &amp; not having a cell phone (or computer!)? Do you ever think \"holy shit, what just happened?!?!?!\"",
    "id" : 766445081394044929,
    "created_at" : "2016-08-19 01:22:01 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 766632506498117632,
  "created_at" : "2016-08-19 13:46:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766461259298373632",
  "geo" : { },
  "id_str" : "766632402236104705",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time grrr. they don't rush for older ppl. my mom needed neuro who didn't come for hours. should have sued. bastard.",
  "id" : 766632402236104705,
  "in_reply_to_status_id" : 766461259298373632,
  "created_at" : "2016-08-19 13:46:22 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Far Side",
      "screen_name" : "The_Far_Side_",
      "indices" : [ 3, 17 ],
      "id_str" : "860512033",
      "id" : 860512033
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/The_Far_Side_\/status\/766610028493144064\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/TA4jTmn78g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOLwMoWEAQ6I04.jpg",
      "id_str" : "766610021723541508",
      "id" : 766610021723541508,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOLwMoWEAQ6I04.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 529
      } ],
      "display_url" : "pic.twitter.com\/TA4jTmn78g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766631116468084736",
  "text" : "RT @The_Far_Side_: https:\/\/t.co\/TA4jTmn78g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/The_Far_Side_\/status\/766610028493144064\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/TA4jTmn78g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOLwMoWEAQ6I04.jpg",
        "id_str" : "766610021723541508",
        "id" : 766610021723541508,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOLwMoWEAQ6I04.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 529
        } ],
        "display_url" : "pic.twitter.com\/TA4jTmn78g"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766610028493144064",
    "text" : "https:\/\/t.co\/TA4jTmn78g",
    "id" : 766610028493144064,
    "created_at" : "2016-08-19 12:17:28 +0000",
    "user" : {
      "name" : "The Far Side",
      "screen_name" : "The_Far_Side_",
      "protected" : false,
      "id_str" : "860512033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2678217475\/189814fcc380c2f108cb810a2ff970d3_normal.jpeg",
      "id" : 860512033,
      "verified" : false
    }
  },
  "id" : 766631116468084736,
  "created_at" : "2016-08-19 13:41:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766630546130800640",
  "text" : "RT @BeasBookNook: Claude says, \"Take me home mama. I don't like this place.\" Happily, it was a short visit &amp; he got an A+ from the vet http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BeasBookNook\/status\/766627972505866240\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Aiu3JeUuCy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOcEI0XEAEG4yG.jpg",
        "id_str" : "766627956483624961",
        "id" : 766627956483624961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOcEI0XEAEG4yG.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Aiu3JeUuCy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766627972505866240",
    "text" : "Claude says, \"Take me home mama. I don't like this place.\" Happily, it was a short visit &amp; he got an A+ from the vet https:\/\/t.co\/Aiu3JeUuCy",
    "id" : 766627972505866240,
    "created_at" : "2016-08-19 13:28:46 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 766630546130800640,
  "created_at" : "2016-08-19 13:39:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Metal Cats",
      "screen_name" : "evilbmcats",
      "indices" : [ 3, 14 ],
      "id_str" : "2336573456",
      "id" : 2336573456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766630233625821185",
  "text" : "RT @evilbmcats: What is old shall replace what is new, and once again the ancient ones shall rule upon the face of the earth. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/evilbmcats\/status\/766626794036264960\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/4zH8oSKDE3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMa23TUEAAMAFm.jpg",
        "id_str" : "766485891443331072",
        "id" : 766485891443331072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMa23TUEAAMAFm.jpg",
        "sizes" : [ {
          "h" : 505,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 877
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 877
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 877
        } ],
        "display_url" : "pic.twitter.com\/4zH8oSKDE3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766626794036264960",
    "text" : "What is old shall replace what is new, and once again the ancient ones shall rule upon the face of the earth. https:\/\/t.co\/4zH8oSKDE3",
    "id" : 766626794036264960,
    "created_at" : "2016-08-19 13:24:05 +0000",
    "user" : {
      "name" : "Black Metal Cats",
      "screen_name" : "evilbmcats",
      "protected" : false,
      "id_str" : "2336573456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691394350006177793\/dV2zgoWt_normal.jpg",
      "id" : 2336573456,
      "verified" : false
    }
  },
  "id" : 766630233625821185,
  "created_at" : "2016-08-19 13:37:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "feedly",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/UhEggMQ2N9",
      "expanded_url" : "http:\/\/scripting.com\/2016\/08\/18\/bodyShamingIsWrong.html",
      "display_url" : "scripting.com\/2016\/08\/18\/bod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766629291002068992",
  "text" : "Body shaming is wrong https:\/\/t.co\/UhEggMQ2N9 #tech #feedly",
  "id" : 766629291002068992,
  "created_at" : "2016-08-19 13:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/766367225259421700\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/qFieIlNXbQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKu7awWEAEKIeC.jpg",
      "id_str" : "766367222424014849",
      "id" : 766367222424014849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKu7awWEAEKIeC.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/qFieIlNXbQ"
    } ],
    "hashtags" : [ {
      "text" : "BFF",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766367225259421700",
  "text" : "Two special gals hanging out #BFF https:\/\/t.co\/qFieIlNXbQ",
  "id" : 766367225259421700,
  "created_at" : "2016-08-18 20:12:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hanson",
      "screen_name" : "jtotheizzoe",
      "indices" : [ 3, 15 ],
      "id_str" : "26099938",
      "id" : 26099938
    }, {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 22, 27 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/0LxJT5sBNx",
      "expanded_url" : "https:\/\/twitter.com\/RebeccaASherman\/status\/766272555493621760",
      "display_url" : "twitter.com\/RebeccaASherma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766363014811488260",
  "text" : "RT @jtotheizzoe: Hey, @TIME\u2026 um, you might want to maybe fix this and apologize  https:\/\/t.co\/0LxJT5sBNx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TIME",
        "screen_name" : "TIME",
        "indices" : [ 5, 10 ],
        "id_str" : "14293310",
        "id" : 14293310
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/0LxJT5sBNx",
        "expanded_url" : "https:\/\/twitter.com\/RebeccaASherman\/status\/766272555493621760",
        "display_url" : "twitter.com\/RebeccaASherma\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766312118492684288",
    "text" : "Hey, @TIME\u2026 um, you might want to maybe fix this and apologize  https:\/\/t.co\/0LxJT5sBNx",
    "id" : 766312118492684288,
    "created_at" : "2016-08-18 16:33:41 +0000",
    "user" : {
      "name" : "Joe Hanson",
      "screen_name" : "jtotheizzoe",
      "protected" : false,
      "id_str" : "26099938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684812926205562880\/hDwHS2bt_normal.jpg",
      "id" : 26099938,
      "verified" : true
    }
  },
  "id" : 766363014811488260,
  "created_at" : "2016-08-18 19:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Heath",
      "screen_name" : "TedHeath4",
      "indices" : [ 3, 13 ],
      "id_str" : "1145714328",
      "id" : 1145714328
    }, {
      "name" : "Mark T. Bertolini",
      "screen_name" : "mtbert",
      "indices" : [ 15, 22 ],
      "id_str" : "71049139",
      "id" : 71049139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766270044376559616",
  "text" : "RT @TedHeath4: @mtbert No merger, no Obamacare? The customer you really care about is your shareholder. Health care is too important. Singl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark T. Bertolini",
        "screen_name" : "mtbert",
        "indices" : [ 0, 7 ],
        "id_str" : "71049139",
        "id" : 71049139
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765946340316774400",
    "in_reply_to_user_id" : 71049139,
    "text" : "@mtbert No merger, no Obamacare? The customer you really care about is your shareholder. Health care is too important. Single Payer!!!!!",
    "id" : 765946340316774400,
    "created_at" : "2016-08-17 16:20:12 +0000",
    "in_reply_to_screen_name" : "mtbert",
    "in_reply_to_user_id_str" : "71049139",
    "user" : {
      "name" : "Ted Heath",
      "screen_name" : "TedHeath4",
      "protected" : false,
      "id_str" : "1145714328",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_3_normal.png",
      "id" : 1145714328,
      "verified" : false
    }
  },
  "id" : 766270044376559616,
  "created_at" : "2016-08-18 13:46:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766269942807273473",
  "text" : "RT @AllOnMedicare: Aetna doesn't provide care. It just pushes paper. It's an investment bank with premiums to invest. #SinglePayer  https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ZTnAnDvaOJ",
        "expanded_url" : "https:\/\/twitter.com\/sethapol\/status\/766009602987200512",
        "display_url" : "twitter.com\/sethapol\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766267902878224384",
    "text" : "Aetna doesn't provide care. It just pushes paper. It's an investment bank with premiums to invest. #SinglePayer  https:\/\/t.co\/ZTnAnDvaOJ",
    "id" : 766267902878224384,
    "created_at" : "2016-08-18 13:37:59 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 766269942807273473,
  "created_at" : "2016-08-18 13:46:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 3, 14 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/766252690921979905\/video\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/dkZlFc4mAq",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/766252610315837440\/pu\/img\/E1tMzVLOGZq9_63Z.jpg",
      "id_str" : "766252610315837440",
      "id" : 766252610315837440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/766252610315837440\/pu\/img\/E1tMzVLOGZq9_63Z.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dkZlFc4mAq"
    } ],
    "hashtags" : [ {
      "text" : "Farm24",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766268560809271296",
  "text" : "RT @PVickerton: Five mins catching and moving this little un out of the way of the plough..\n\n#Farm24 https:\/\/t.co\/dkZlFc4mAq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/766252690921979905\/video\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/dkZlFc4mAq",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/766252610315837440\/pu\/img\/E1tMzVLOGZq9_63Z.jpg",
        "id_str" : "766252610315837440",
        "id" : 766252610315837440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/766252610315837440\/pu\/img\/E1tMzVLOGZq9_63Z.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dkZlFc4mAq"
      } ],
      "hashtags" : [ {
        "text" : "Farm24",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766252690921979905",
    "text" : "Five mins catching and moving this little un out of the way of the plough..\n\n#Farm24 https:\/\/t.co\/dkZlFc4mAq",
    "id" : 766252690921979905,
    "created_at" : "2016-08-18 12:37:32 +0000",
    "user" : {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "protected" : false,
      "id_str" : "1046103560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773840339463438336\/-PvOKg0h_normal.jpg",
      "id" : 1046103560,
      "verified" : false
    }
  },
  "id" : 766268560809271296,
  "created_at" : "2016-08-18 13:40:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766267642462298112",
  "text" : "Fan club in Plymouth yesterday tired out pup. One guy even yelled out \"I love your dog!\" from passing car..lol",
  "id" : 766267642462298112,
  "created_at" : "2016-08-18 13:36:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Sutcliffe",
      "screen_name" : "ChasSutcliffe",
      "indices" : [ 3, 17 ],
      "id_str" : "51045839",
      "id" : 51045839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Farm24",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766076554585772032",
  "text" : "RT @ChasSutcliffe: #Farm24 hello again! A year ago I had an orphan calf I was bottle feeding &amp; his friend was in all the pictures! \uD83D\uDC02\uD83C\uDF7C\uD83D\uDE00 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChasSutcliffe\/status\/766047176959164416\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/ZIWEk48gIy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqGLq70WgAEVYJ6.jpg",
        "id_str" : "766046981357731841",
        "id" : 766046981357731841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqGLq70WgAEVYJ6.jpg",
        "sizes" : [ {
          "h" : 679,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1158,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1158,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ZIWEk48gIy"
      } ],
      "hashtags" : [ {
        "text" : "Farm24",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766047176959164416",
    "text" : "#Farm24 hello again! A year ago I had an orphan calf I was bottle feeding &amp; his friend was in all the pictures! \uD83D\uDC02\uD83C\uDF7C\uD83D\uDE00 https:\/\/t.co\/ZIWEk48gIy",
    "id" : 766047176959164416,
    "created_at" : "2016-08-17 23:00:54 +0000",
    "user" : {
      "name" : "Charlie Sutcliffe",
      "screen_name" : "ChasSutcliffe",
      "protected" : false,
      "id_str" : "51045839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556915520935456768\/4zFyjb09_normal.png",
      "id" : 51045839,
      "verified" : false
    }
  },
  "id" : 766076554585772032,
  "created_at" : "2016-08-18 00:57:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Labelle",
      "screen_name" : "katewrites4u",
      "indices" : [ 3, 16 ],
      "id_str" : "749690558449197056",
      "id" : 749690558449197056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765725102365433856",
  "text" : "RT @katewrites4u: Saw a shrink for severe depression\/anxiety; Told me Ill feel better if I lose weight after I disclosed my eating disorder\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fatsidestories",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765633054400544770",
    "text" : "Saw a shrink for severe depression\/anxiety; Told me Ill feel better if I lose weight after I disclosed my eating disorder #fatsidestories",
    "id" : 765633054400544770,
    "created_at" : "2016-08-16 19:35:19 +0000",
    "user" : {
      "name" : "Catherine Labelle",
      "screen_name" : "katewrites4u",
      "protected" : false,
      "id_str" : "749690558449197056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780600665232015360\/RGNmSaZU_normal.jpg",
      "id" : 749690558449197056,
      "verified" : false
    }
  },
  "id" : 765725102365433856,
  "created_at" : "2016-08-17 01:41:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TwellMdc\/status\/765652044963311618\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/6NElI6QyRM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAkaVsXgAAKuLn.jpg",
      "id_str" : "765651971571417088",
      "id" : 765651971571417088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAkaVsXgAAKuLn.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2730,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6NElI6QyRM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765724101944217600",
  "text" : "RT @TwellMdc: Another lovely sunset this evening. View from Mermaid's Pool, looking towards Cheshire.. https:\/\/t.co\/6NElI6QyRM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TwellMdc\/status\/765652044963311618\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/6NElI6QyRM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAkaVsXgAAKuLn.jpg",
        "id_str" : "765651971571417088",
        "id" : 765651971571417088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAkaVsXgAAKuLn.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2730,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/6NElI6QyRM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765652044963311618",
    "text" : "Another lovely sunset this evening. View from Mermaid's Pool, looking towards Cheshire.. https:\/\/t.co\/6NElI6QyRM",
    "id" : 765652044963311618,
    "created_at" : "2016-08-16 20:50:47 +0000",
    "user" : {
      "name" : "Mike Critchlow",
      "screen_name" : "MikeCritchlow",
      "protected" : false,
      "id_str" : "4701506809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798583527939993600\/-QS8TMLI_normal.jpg",
      "id" : 4701506809,
      "verified" : false
    }
  },
  "id" : 765724101944217600,
  "created_at" : "2016-08-17 01:37:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765711921039323137",
  "geo" : { },
  "id_str" : "765723661127020545",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre oh dear. Hope it clears up quickly! ((hugs))",
  "id" : 765723661127020545,
  "in_reply_to_status_id" : 765711921039323137,
  "created_at" : "2016-08-17 01:35:21 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765679260015165441",
  "text" : "RT @AnnotatedBible: I'm trying to get all of us to open our minds and think about things from different perspectives instead of being stuck\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765618492171182080",
    "text" : "I'm trying to get all of us to open our minds and think about things from different perspectives instead of being stuck in our ruts.",
    "id" : 765618492171182080,
    "created_at" : "2016-08-16 18:37:27 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 765679260015165441,
  "created_at" : "2016-08-16 22:38:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/765667282081251328\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HJqsiCp52E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAyHrnXYAAAMWY.jpg",
      "id_str" : "765667044201291776",
      "id" : 765667044201291776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAyHrnXYAAAMWY.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HJqsiCp52E"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/765667282081251328\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HJqsiCp52E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAyHrnWAAAMI13.jpg",
      "id_str" : "765667044201201664",
      "id" : 765667044201201664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAyHrnWAAAMI13.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HJqsiCp52E"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/765667282081251328\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HJqsiCp52E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAyHrlWgAA9rdu.jpg",
      "id_str" : "765667044192845824",
      "id" : 765667044192845824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAyHrlWgAA9rdu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HJqsiCp52E"
    } ],
    "hashtags" : [ {
      "text" : "teamStripe",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765678452104105984",
  "text" : "RT @newlandfarm: Swanthorpe Quirrel settling in #teamStripe https:\/\/t.co\/HJqsiCp52E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/765667282081251328\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/HJqsiCp52E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAyHrnXYAAAMWY.jpg",
        "id_str" : "765667044201291776",
        "id" : 765667044201291776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAyHrnXYAAAMWY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HJqsiCp52E"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/765667282081251328\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/HJqsiCp52E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAyHrnWAAAMI13.jpg",
        "id_str" : "765667044201201664",
        "id" : 765667044201201664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAyHrnWAAAMI13.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HJqsiCp52E"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/765667282081251328\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/HJqsiCp52E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAyHrlWgAA9rdu.jpg",
        "id_str" : "765667044192845824",
        "id" : 765667044192845824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAyHrlWgAA9rdu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HJqsiCp52E"
      } ],
      "hashtags" : [ {
        "text" : "teamStripe",
        "indices" : [ 31, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765667282081251328",
    "text" : "Swanthorpe Quirrel settling in #teamStripe https:\/\/t.co\/HJqsiCp52E",
    "id" : 765667282081251328,
    "created_at" : "2016-08-16 21:51:20 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 765678452104105984,
  "created_at" : "2016-08-16 22:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765678241273315328",
  "text" : "RT @AnnotatedBible: I don't see how there ever could have been a time when it was morally good to kill gay people, like Leviticus 20:13 com\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765673758262632449",
    "text" : "I don't see how there ever could have been a time when it was morally good to kill gay people, like Leviticus 20:13 commands.",
    "id" : 765673758262632449,
    "created_at" : "2016-08-16 22:17:04 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 765678241273315328,
  "created_at" : "2016-08-16 22:34:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cilla",
      "screen_name" : "BlueGumFarmTV",
      "indices" : [ 3, 17 ],
      "id_str" : "2284250370",
      "id" : 2284250370
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BlueGumFarmTV\/status\/765447148100055040\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/io85UQLPTy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp9qH7eWcAApzCK.jpg",
      "id_str" : "765447146132893696",
      "id" : 765447146132893696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp9qH7eWcAApzCK.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/io85UQLPTy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765678184180449282",
  "text" : "RT @BlueGumFarmTV: Gift wrapped!! \uD83D\uDE0D\uD83D\uDC2E\uD83D\uDE0D https:\/\/t.co\/io85UQLPTy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BlueGumFarmTV\/status\/765447148100055040\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/io85UQLPTy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp9qH7eWcAApzCK.jpg",
        "id_str" : "765447146132893696",
        "id" : 765447146132893696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp9qH7eWcAApzCK.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/io85UQLPTy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765447148100055040",
    "text" : "Gift wrapped!! \uD83D\uDE0D\uD83D\uDC2E\uD83D\uDE0D https:\/\/t.co\/io85UQLPTy",
    "id" : 765447148100055040,
    "created_at" : "2016-08-16 07:16:36 +0000",
    "user" : {
      "name" : "Cilla",
      "screen_name" : "BlueGumFarmTV",
      "protected" : false,
      "id_str" : "2284250370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664704726294904832\/cONFfdkJ_normal.jpg",
      "id" : 2284250370,
      "verified" : false
    }
  },
  "id" : 765678184180449282,
  "created_at" : "2016-08-16 22:34:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sloan",
      "screen_name" : "JASloan_Farm",
      "indices" : [ 3, 16 ],
      "id_str" : "2536661517",
      "id" : 2536661517
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JASloan_Farm\/status\/763776857590394880\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/x7XwYh7jHJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpl6_T3WYAATuHn.jpg",
      "id_str" : "763776839898783744",
      "id" : 763776839898783744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpl6_T3WYAATuHn.jpg",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/x7XwYh7jHJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765561192144330752",
  "text" : "RT @JASloan_Farm: ShorthornX bull calf. https:\/\/t.co\/x7XwYh7jHJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JASloan_Farm\/status\/763776857590394880\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/x7XwYh7jHJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpl6_T3WYAATuHn.jpg",
        "id_str" : "763776839898783744",
        "id" : 763776839898783744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpl6_T3WYAATuHn.jpg",
        "sizes" : [ {
          "h" : 481,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/x7XwYh7jHJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763776857590394880",
    "text" : "ShorthornX bull calf. https:\/\/t.co\/x7XwYh7jHJ",
    "id" : 763776857590394880,
    "created_at" : "2016-08-11 16:39:27 +0000",
    "user" : {
      "name" : "Jonathan Sloan",
      "screen_name" : "JASloan_Farm",
      "protected" : false,
      "id_str" : "2536661517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779359180272627712\/_hHg-xzE_normal.jpg",
      "id" : 2536661517,
      "verified" : false
    }
  },
  "id" : 765561192144330752,
  "created_at" : "2016-08-16 14:49:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ligonier Ministries",
      "screen_name" : "Ligonier",
      "indices" : [ 9, 18 ],
      "id_str" : "15936009",
      "id" : 15936009
    }, {
      "name" : "R.C. Sproul",
      "screen_name" : "RCSproul",
      "indices" : [ 105, 114 ],
      "id_str" : "90649593",
      "id" : 90649593
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Ligonier\/status\/765549958200078343\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/T9wSrweNKa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CplpjTfXYAAUoYx.jpg",
      "id_str" : "763757667064176640",
      "id" : 763757667064176640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplpjTfXYAAUoYx.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1350,
        "resize" : "fit",
        "w" : 1350
      }, {
        "h" : 1350,
        "resize" : "fit",
        "w" : 1350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/T9wSrweNKa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765561002159210496",
  "text" : "Puke! RT @Ligonier: It's because God is good that there is such a place as hell where He punishes evil. \u2014@RCSproul https:\/\/t.co\/T9wSrweNKa",
  "id" : 765561002159210496,
  "created_at" : "2016-08-16 14:49:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765560823720837121",
  "text" : "RT @AnnotatedBible: Sounds very abusive. If a human parent tortured his disobedient child in fire to show \"love\" we would arrest him. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/LtspJvgYgR",
        "expanded_url" : "https:\/\/twitter.com\/ligonier\/status\/765549958200078343",
        "display_url" : "twitter.com\/ligonier\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765550459272638465",
    "text" : "Sounds very abusive. If a human parent tortured his disobedient child in fire to show \"love\" we would arrest him. https:\/\/t.co\/LtspJvgYgR",
    "id" : 765550459272638465,
    "created_at" : "2016-08-16 14:07:07 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 765560823720837121,
  "created_at" : "2016-08-16 14:48:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765379777943445504",
  "geo" : { },
  "id_str" : "765544467734597632",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves tee hee : )",
  "id" : 765544467734597632,
  "in_reply_to_status_id" : 765379777943445504,
  "created_at" : "2016-08-16 13:43:18 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765544031476678656",
  "text" : "RT @dwaynereaves: I have a whole lot of silent friends here on twitter that I wish would go like my facebook page and be silent there. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HYRFoJ4la7",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765379777943445504",
    "text" : "I have a whole lot of silent friends here on twitter that I wish would go like my facebook page and be silent there. https:\/\/t.co\/HYRFoJ4la7",
    "id" : 765379777943445504,
    "created_at" : "2016-08-16 02:48:53 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 765544031476678656,
  "created_at" : "2016-08-16 13:41:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/765535836523884544\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/NERuDNMNGM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp-6yMuWcAAYx3B.jpg",
      "id_str" : "765535833248133120",
      "id" : 765535833248133120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp-6yMuWcAAYx3B.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/NERuDNMNGM"
    } ],
    "hashtags" : [ {
      "text" : "Hull",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "MA",
      "indices" : [ 49, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765535836523884544",
  "text" : "Today's view. my kind of day.. hidden sun. #Hull #MA https:\/\/t.co\/NERuDNMNGM",
  "id" : 765535836523884544,
  "created_at" : "2016-08-16 13:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Fine Art America",
      "screen_name" : "FineArtAmerica",
      "indices" : [ 95, 110 ],
      "id_str" : "16828262",
      "id" : 16828262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/765297937773568000\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/hFPESwbeRP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7iau1UIAAHOy3.jpg",
      "id_str" : "765297935575687168",
      "id" : 765297935575687168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7iau1UIAAHOy3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hFPESwbeRP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/kzoNfnQeUD",
      "expanded_url" : "http:\/\/fineartamerica.com\/featured\/come-sit-a-while-with-me-dwayne-reaves.html",
      "display_url" : "fineartamerica.com\/featured\/come-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765327071702810624",
  "text" : "RT @dwaynereaves: New artwork for sale! - \"Come sit a while with me\" - https:\/\/t.co\/kzoNfnQeUD @fineartamerica https:\/\/t.co\/hFPESwbeRP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/fineartamerica.com\" rel=\"nofollow\"\u003EFine Art America\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fine Art America",
        "screen_name" : "FineArtAmerica",
        "indices" : [ 77, 92 ],
        "id_str" : "16828262",
        "id" : 16828262
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/765297937773568000\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/hFPESwbeRP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7iau1UIAAHOy3.jpg",
        "id_str" : "765297935575687168",
        "id" : 765297935575687168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7iau1UIAAHOy3.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hFPESwbeRP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/kzoNfnQeUD",
        "expanded_url" : "http:\/\/fineartamerica.com\/featured\/come-sit-a-while-with-me-dwayne-reaves.html",
        "display_url" : "fineartamerica.com\/featured\/come-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765297937773568000",
    "text" : "New artwork for sale! - \"Come sit a while with me\" - https:\/\/t.co\/kzoNfnQeUD @fineartamerica https:\/\/t.co\/hFPESwbeRP",
    "id" : 765297937773568000,
    "created_at" : "2016-08-15 21:23:41 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 765327071702810624,
  "created_at" : "2016-08-15 23:19:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/9BFL12Nc6q",
      "expanded_url" : "https:\/\/vine.co\/v\/5hj2YLgPJzL",
      "display_url" : "vine.co\/v\/5hj2YLgPJzL"
    } ]
  },
  "geo" : { },
  "id_str" : "765326702369181697",
  "text" : "RT @1CatShepherd: Ok think I'm done here..... ewes all counted time for bed https:\/\/t.co\/9BFL12Nc6q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/9BFL12Nc6q",
        "expanded_url" : "https:\/\/vine.co\/v\/5hj2YLgPJzL",
        "display_url" : "vine.co\/v\/5hj2YLgPJzL"
      } ]
    },
    "geo" : { },
    "id_str" : "765285031489204225",
    "text" : "Ok think I'm done here..... ewes all counted time for bed https:\/\/t.co\/9BFL12Nc6q",
    "id" : 765285031489204225,
    "created_at" : "2016-08-15 20:32:24 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 765326702369181697,
  "created_at" : "2016-08-15 23:17:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWorldOutOfMind\/status\/475075804259713024\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/kHaxCLpCeF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpfO7QfIUAA6_dC.jpg",
      "id_str" : "475075803144015872",
      "id" : 475075803144015872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpfO7QfIUAA6_dC.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 650
      } ],
      "display_url" : "pic.twitter.com\/kHaxCLpCeF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765274244234313728",
  "text" : "RT @AWorldOutOfMind: Bovine Astrophysicist Kneel in the Grass Bison http:\/\/t.co\/kHaxCLpCeF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWorldOutOfMind\/status\/475075804259713024\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/kHaxCLpCeF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpfO7QfIUAA6_dC.jpg",
        "id_str" : "475075803144015872",
        "id" : 475075803144015872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpfO7QfIUAA6_dC.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/kHaxCLpCeF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475075804259713024",
    "text" : "Bovine Astrophysicist Kneel in the Grass Bison http:\/\/t.co\/kHaxCLpCeF",
    "id" : 475075804259713024,
    "created_at" : "2014-06-07 00:44:32 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 765274244234313728,
  "created_at" : "2016-08-15 19:49:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart petch",
      "screen_name" : "thelightoutside",
      "indices" : [ 3, 19 ],
      "id_str" : "703687800",
      "id" : 703687800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765273093371748352",
  "text" : "RT @thelightoutside: Semi-decent Snaizeholme snaps. No way representative of full experience! Many chasing round trunks, burying nuts etc h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/thelightoutside\/status\/765271669678178304\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xkwrboDmNR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7JzyvXgAAQcNC.jpg",
        "id_str" : "765270878330519552",
        "id" : 765270878330519552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7JzyvXgAAQcNC.jpg",
        "sizes" : [ {
          "h" : 684,
          "resize" : "fit",
          "w" : 1026
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1026
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1026
        } ],
        "display_url" : "pic.twitter.com\/xkwrboDmNR"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/thelightoutside\/status\/765271669678178304\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xkwrboDmNR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7J-ayWIAAMoNx.jpg",
        "id_str" : "765271060879122432",
        "id" : 765271060879122432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7J-ayWIAAMoNx.jpg",
        "sizes" : [ {
          "h" : 535,
          "resize" : "fit",
          "w" : 952
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 952
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 952
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/xkwrboDmNR"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/thelightoutside\/status\/765271669678178304\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xkwrboDmNR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7KK4dWYAAcMKj.jpg",
        "id_str" : "765271275002552320",
        "id" : 765271275002552320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7KK4dWYAAcMKj.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 547
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 547
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 547
        } ],
        "display_url" : "pic.twitter.com\/xkwrboDmNR"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/thelightoutside\/status\/765271669678178304\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xkwrboDmNR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp7KMhhXEAAN7_D.jpg",
        "id_str" : "765271303205097472",
        "id" : 765271303205097472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp7KMhhXEAAN7_D.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 698,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 698,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 698,
          "resize" : "fit",
          "w" : 465
        } ],
        "display_url" : "pic.twitter.com\/xkwrboDmNR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "765260899796054017",
    "geo" : { },
    "id_str" : "765271669678178304",
    "in_reply_to_user_id" : 703687800,
    "text" : "Semi-decent Snaizeholme snaps. No way representative of full experience! Many chasing round trunks, burying nuts etc https:\/\/t.co\/xkwrboDmNR",
    "id" : 765271669678178304,
    "in_reply_to_status_id" : 765260899796054017,
    "created_at" : "2016-08-15 19:39:18 +0000",
    "in_reply_to_screen_name" : "thelightoutside",
    "in_reply_to_user_id_str" : "703687800",
    "user" : {
      "name" : "stuart petch",
      "screen_name" : "thelightoutside",
      "protected" : false,
      "id_str" : "703687800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749635913815392256\/l203QrUF_normal.jpg",
      "id" : 703687800,
      "verified" : false
    }
  },
  "id" : 765273093371748352,
  "created_at" : "2016-08-15 19:44:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765272924140007425",
  "text" : "RT @BrianRathbone: I'm going to develop auto-correct for geeks, where it assumes you are making D&amp;D references.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765271901627379712",
    "text" : "I'm going to develop auto-correct for geeks, where it assumes you are making D&amp;D references.",
    "id" : 765271901627379712,
    "created_at" : "2016-08-15 19:40:14 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 765272924140007425,
  "created_at" : "2016-08-15 19:44:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/WzV5S4m9Fk",
      "expanded_url" : "https:\/\/twitter.com\/aaronexdee\/status\/764970088965505024",
      "display_url" : "twitter.com\/aaronexdee\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764974487997648896",
  "text" : "RT @Irish_Atheist: You need to learn about singular and plural nouns. Gays are not the Borg. https:\/\/t.co\/WzV5S4m9Fk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/WzV5S4m9Fk",
        "expanded_url" : "https:\/\/twitter.com\/aaronexdee\/status\/764970088965505024",
        "display_url" : "twitter.com\/aaronexdee\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764971153731510272",
    "text" : "You need to learn about singular and plural nouns. Gays are not the Borg. https:\/\/t.co\/WzV5S4m9Fk",
    "id" : 764971153731510272,
    "created_at" : "2016-08-14 23:45:10 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 764974487997648896,
  "created_at" : "2016-08-14 23:58:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Jensen",
      "screen_name" : "LukeFJensen",
      "indices" : [ 3, 15 ],
      "id_str" : "30059925",
      "id" : 30059925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764904223872061440",
  "text" : "RT @LukeFJensen: Listening to an audiobook about the Higgs Boson that quotes a section of Miracles by Insane Clown Posse. Guys...THE NARRAT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764528560404955136",
    "text" : "Listening to an audiobook about the Higgs Boson that quotes a section of Miracles by Insane Clown Posse. Guys...THE NARRATOR RAPS A VERSE!",
    "id" : 764528560404955136,
    "created_at" : "2016-08-13 18:26:27 +0000",
    "user" : {
      "name" : "Luke Jensen",
      "screen_name" : "LukeFJensen",
      "protected" : false,
      "id_str" : "30059925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769675109678223362\/zc0I1Drr_normal.jpg",
      "id" : 30059925,
      "verified" : false
    }
  },
  "id" : 764904223872061440,
  "created_at" : "2016-08-14 19:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AudibleAsks",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764904000844132357",
  "text" : "RT @audible_com: #AudibleAsks: do you like to jump around between multiple audiobooks? Or are you a monogamous listener? https:\/\/t.co\/UmGmW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AudibleAsks",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/UmGmWSEiki",
        "expanded_url" : "https:\/\/twitter.com\/ReadItForward\/status\/763082449001680900",
        "display_url" : "twitter.com\/ReadItForward\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764869193300926464",
    "text" : "#AudibleAsks: do you like to jump around between multiple audiobooks? Or are you a monogamous listener? https:\/\/t.co\/UmGmWSEiki",
    "id" : 764869193300926464,
    "created_at" : "2016-08-14 17:00:00 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 764904000844132357,
  "created_at" : "2016-08-14 19:18:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Santens",
      "screen_name" : "scottsantens",
      "indices" : [ 3, 16 ],
      "id_str" : "14297863",
      "id" : 14297863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basicincome",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764902885989777408",
  "text" : "RT @scottsantens: You can like my Facebook page to have my #basicincome writings appear in your News feed over there. https:\/\/t.co\/YJJNxmvf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/harutweet.com\" rel=\"nofollow\"\u003EHaruTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "basicincome",
        "indices" : [ 41, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/YJJNxmvftp",
        "expanded_url" : "https:\/\/www.facebook.com\/scottsantens",
        "display_url" : "facebook.com\/scottsantens"
      } ]
    },
    "geo" : { },
    "id_str" : "764899505439289345",
    "text" : "You can like my Facebook page to have my #basicincome writings appear in your News feed over there. https:\/\/t.co\/YJJNxmvftp",
    "id" : 764899505439289345,
    "created_at" : "2016-08-14 19:00:27 +0000",
    "user" : {
      "name" : "Scott Santens",
      "screen_name" : "scottsantens",
      "protected" : false,
      "id_str" : "14297863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728327801028239360\/QVZeVLgz_normal.jpg",
      "id" : 14297863,
      "verified" : true
    }
  },
  "id" : 764902885989777408,
  "created_at" : "2016-08-14 19:13:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bitch Code \uD83D\uDC85\uD83C\uDFFB",
      "screen_name" : "TheTumblrPosts",
      "indices" : [ 3, 18 ],
      "id_str" : "798234950",
      "id" : 798234950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764886076368547840",
  "text" : "RT @TheTumblrPosts: i love twitter because everyone is real af, instagram is like \"look how great my life is\" while twitters like \"I want t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764476968742096896",
    "text" : "i love twitter because everyone is real af, instagram is like \"look how great my life is\" while twitters like \"I want to die, here's a meme\"",
    "id" : 764476968742096896,
    "created_at" : "2016-08-13 15:01:27 +0000",
    "user" : {
      "name" : "Bitch Code \uD83D\uDC85\uD83C\uDFFB",
      "screen_name" : "TheTumblrPosts",
      "protected" : false,
      "id_str" : "798234950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731175022920904704\/VdCK_Ge3_normal.jpg",
      "id" : 798234950,
      "verified" : false
    }
  },
  "id" : 764886076368547840,
  "created_at" : "2016-08-14 18:07:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/wCyJ7VTY3b",
      "expanded_url" : "http:\/\/leafcrunch.tumblr.com\/post\/119490479379\/sun-and-time-leafcrunch-my-neighbourhood-has",
      "display_url" : "leafcrunch.tumblr.com\/post\/119490479\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764869213689446400",
  "text" : "knife sharpening truck https:\/\/t.co\/wCyJ7VTY3b",
  "id" : 764869213689446400,
  "created_at" : "2016-08-14 17:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/2vKupKVP4x",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx2AjMYrX",
      "display_url" : "tmblr.co\/Zp3-jx2AjMYrX"
    } ]
  },
  "geo" : { },
  "id_str" : "764867936540618752",
  "text" : "\uD83D\uDCF9 Knife sharpening truck!! https:\/\/t.co\/2vKupKVP4x",
  "id" : 764867936540618752,
  "created_at" : "2016-08-14 16:55:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammi",
      "screen_name" : "sammilynn_m",
      "indices" : [ 34, 46 ],
      "id_str" : "350977771",
      "id" : 350977771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/TRi012LfAj",
      "expanded_url" : "https:\/\/vine.co\/v\/hhD5e6VT7wx",
      "display_url" : "vine.co\/v\/hhD5e6VT7wx"
    } ]
  },
  "geo" : { },
  "id_str" : "764867934300807168",
  "text" : "Knife sharpening truck!! (Vine by @sammilynn_m) https:\/\/t.co\/TRi012LfAj",
  "id" : 764867934300807168,
  "created_at" : "2016-08-14 16:55:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/727682264696524800\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/PqW8AS8mR3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chk_GEvWMAEn4Kk.jpg",
      "id_str" : "727682188381138945",
      "id" : 727682188381138945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chk_GEvWMAEn4Kk.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PqW8AS8mR3"
    } ],
    "hashtags" : [ {
      "text" : "Escapees",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764858525524852737",
  "text" : "RT @newlandfarm: Not sure if he's exploring or sleeping #Escapees https:\/\/t.co\/PqW8AS8mR3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/727682264696524800\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/PqW8AS8mR3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Chk_GEvWMAEn4Kk.jpg",
        "id_str" : "727682188381138945",
        "id" : 727682188381138945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chk_GEvWMAEn4Kk.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PqW8AS8mR3"
      } ],
      "hashtags" : [ {
        "text" : "Escapees",
        "indices" : [ 39, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727682264696524800",
    "text" : "Not sure if he's exploring or sleeping #Escapees https:\/\/t.co\/PqW8AS8mR3",
    "id" : 727682264696524800,
    "created_at" : "2016-05-04 02:12:26 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 764858525524852737,
  "created_at" : "2016-08-14 16:17:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/764801864412106753\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/d1hWvQaWaU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp0fPRNW8AAwUrS.jpg",
      "id_str" : "764801858900783104",
      "id" : 764801858900783104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp0fPRNW8AAwUrS.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/d1hWvQaWaU"
    } ],
    "hashtags" : [ {
      "text" : "Hull",
      "indices" : [ 36, 41 ]
    }, {
      "text" : "MA",
      "indices" : [ 42, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764801864412106753",
  "text" : "My view this am. Yoga on the beach. #Hull #MA https:\/\/t.co\/d1hWvQaWaU",
  "id" : 764801864412106753,
  "created_at" : "2016-08-14 12:32:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/764601889732366336\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/HymwtIGYxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpxpXTLXgAAau24.jpg",
      "id_str" : "764601885752000512",
      "id" : 764601885752000512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpxpXTLXgAAau24.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/HymwtIGYxj"
    } ],
    "hashtags" : [ {
      "text" : "BFF",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764601889732366336",
  "text" : "My girls (ok, only 1 is mine mine) #BFF https:\/\/t.co\/HymwtIGYxj",
  "id" : 764601889732366336,
  "created_at" : "2016-08-13 23:17:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/764597138303094790\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/EnjBhMGVP0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpxlCc9WYAA-2eY.jpg",
      "id_str" : "764597129553797120",
      "id" : 764597129553797120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpxlCc9WYAA-2eY.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/EnjBhMGVP0"
    } ],
    "hashtags" : [ {
      "text" : "Hull",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "MA",
      "indices" : [ 27, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764597138303094790",
  "text" : "My view for the week #Hull #MA https:\/\/t.co\/EnjBhMGVP0",
  "id" : 764597138303094790,
  "created_at" : "2016-08-13 22:58:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 3, 17 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/mFfszkU2j1",
      "expanded_url" : "http:\/\/laughingsquid.com\/polish-photographer-bravely-crawls-through-thick-coastal-mud-to-save-a-dying-white-tailed-eagle\/",
      "display_url" : "laughingsquid.com\/polish-photogr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764262758632349696",
  "text" : "RT @LaughingSquid: Photographer Bravely Crawls Through Thick Coastal Mud to Save a Dying White Tailed Eagle https:\/\/t.co\/mFfszkU2j1 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaughingSquid\/status\/764114978714574848\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/idmVv06DlJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpquhXmWEAAE2dM.jpg",
        "id_str" : "764114975086481408",
        "id" : 764114975086481408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpquhXmWEAAE2dM.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/idmVv06DlJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/mFfszkU2j1",
        "expanded_url" : "http:\/\/laughingsquid.com\/polish-photographer-bravely-crawls-through-thick-coastal-mud-to-save-a-dying-white-tailed-eagle\/",
        "display_url" : "laughingsquid.com\/polish-photogr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764114978714574848",
    "text" : "Photographer Bravely Crawls Through Thick Coastal Mud to Save a Dying White Tailed Eagle https:\/\/t.co\/mFfszkU2j1 https:\/\/t.co\/idmVv06DlJ",
    "id" : 764114978714574848,
    "created_at" : "2016-08-12 15:03:02 +0000",
    "user" : {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "protected" : false,
      "id_str" : "2172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418456260971732992\/By5KkDKn_normal.jpeg",
      "id" : 2172,
      "verified" : true
    }
  },
  "id" : 764262758632349696,
  "created_at" : "2016-08-13 00:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "RedWineMonk",
      "indices" : [ 3, 15 ],
      "id_str" : "124465060",
      "id" : 124465060
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RedWineMonk\/status\/764246329463808004\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/INHSkwpFJ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpsl-GXXYAE5As4.jpg",
      "id_str" : "764246310560161793",
      "id" : 764246310560161793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpsl-GXXYAE5As4.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/INHSkwpFJ1"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764258108264898560",
  "text" : "RT @RedWineMonk: Good night and sweet dreams\n#birds https:\/\/t.co\/INHSkwpFJ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RedWineMonk\/status\/764246329463808004\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/INHSkwpFJ1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpsl-GXXYAE5As4.jpg",
        "id_str" : "764246310560161793",
        "id" : 764246310560161793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpsl-GXXYAE5As4.jpg",
        "sizes" : [ {
          "h" : 1100,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/INHSkwpFJ1"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 28, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764246329463808004",
    "text" : "Good night and sweet dreams\n#birds https:\/\/t.co\/INHSkwpFJ1",
    "id" : 764246329463808004,
    "created_at" : "2016-08-12 23:44:58 +0000",
    "user" : {
      "name" : "Daniel",
      "screen_name" : "RedWineMonk",
      "protected" : false,
      "id_str" : "124465060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697879998175309830\/YkwzLVNt_normal.jpg",
      "id" : 124465060,
      "verified" : false
    }
  },
  "id" : 764258108264898560,
  "created_at" : "2016-08-13 00:31:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "indices" : [ 3, 15 ],
      "id_str" : "27531390",
      "id" : 27531390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/GpOxPAObQO",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/08\/12\/how-a-digital-only-smartphone.html",
      "display_url" : "boingboing.net\/2016\/08\/12\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764257713559920640",
  "text" : "RT @grumpygamer: Make no mistake: Apple removing the headphone jack is all about audio DRM: https:\/\/t.co\/GpOxPAObQO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/GpOxPAObQO",
        "expanded_url" : "http:\/\/boingboing.net\/2016\/08\/12\/how-a-digital-only-smartphone.html",
        "display_url" : "boingboing.net\/2016\/08\/12\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764188614439768064",
    "text" : "Make no mistake: Apple removing the headphone jack is all about audio DRM: https:\/\/t.co\/GpOxPAObQO",
    "id" : 764188614439768064,
    "created_at" : "2016-08-12 19:55:38 +0000",
    "user" : {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "protected" : false,
      "id_str" : "27531390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536643530001616896\/qqYjCBrM_normal.png",
      "id" : 27531390,
      "verified" : true
    }
  },
  "id" : 764257713559920640,
  "created_at" : "2016-08-13 00:30:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Marks",
      "screen_name" : "slijepcevicdr",
      "indices" : [ 3, 17 ],
      "id_str" : "3361432131",
      "id" : 3361432131
    }, {
      "name" : "DobleVB",
      "screen_name" : "DobleVB",
      "indices" : [ 19, 27 ],
      "id_str" : "565859934",
      "id" : 565859934
    }, {
      "name" : "ZAGATO",
      "screen_name" : "esnbill",
      "indices" : [ 28, 36 ],
      "id_str" : "2439452128",
      "id" : 2439452128
    }, {
      "name" : "Trees etc.",
      "screen_name" : "arborsmarty",
      "indices" : [ 37, 49 ],
      "id_str" : "628270697",
      "id" : 628270697
    }, {
      "name" : "james rees",
      "screen_name" : "jrees04",
      "indices" : [ 50, 58 ],
      "id_str" : "541903575",
      "id" : 541903575
    }, {
      "name" : "AMOUNARBOL",
      "screen_name" : "AMOUNARBOL",
      "indices" : [ 59, 70 ],
      "id_str" : "620393340",
      "id" : 620393340
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slijepcevicdr\/status\/764169493304205312\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/zcXgHHyveY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CprgBqIXgAUHXf6.jpg",
      "id_str" : "764169405886595077",
      "id" : 764169405886595077,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprgBqIXgAUHXf6.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zcXgHHyveY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764225121376698368",
  "text" : "RT @slijepcevicdr: @DobleVB @esnbill @arborsmarty @jrees04 @AMOUNARBOL https:\/\/t.co\/zcXgHHyveY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DobleVB",
        "screen_name" : "DobleVB",
        "indices" : [ 0, 8 ],
        "id_str" : "565859934",
        "id" : 565859934
      }, {
        "name" : "ZAGATO",
        "screen_name" : "esnbill",
        "indices" : [ 9, 17 ],
        "id_str" : "2439452128",
        "id" : 2439452128
      }, {
        "name" : "Trees etc.",
        "screen_name" : "arborsmarty",
        "indices" : [ 18, 30 ],
        "id_str" : "628270697",
        "id" : 628270697
      }, {
        "name" : "james rees",
        "screen_name" : "jrees04",
        "indices" : [ 31, 39 ],
        "id_str" : "541903575",
        "id" : 541903575
      }, {
        "name" : "AMOUNARBOL",
        "screen_name" : "AMOUNARBOL",
        "indices" : [ 40, 51 ],
        "id_str" : "620393340",
        "id" : 620393340
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slijepcevicdr\/status\/764169493304205312\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/zcXgHHyveY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CprgBqIXgAUHXf6.jpg",
        "id_str" : "764169405886595077",
        "id" : 764169405886595077,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprgBqIXgAUHXf6.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zcXgHHyveY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "764127353844994048",
    "geo" : { },
    "id_str" : "764169493304205312",
    "in_reply_to_user_id" : 565859934,
    "text" : "@DobleVB @esnbill @arborsmarty @jrees04 @AMOUNARBOL https:\/\/t.co\/zcXgHHyveY",
    "id" : 764169493304205312,
    "in_reply_to_status_id" : 764127353844994048,
    "created_at" : "2016-08-12 18:39:39 +0000",
    "in_reply_to_screen_name" : "DobleVB",
    "in_reply_to_user_id_str" : "565859934",
    "user" : {
      "name" : "Karl Marks",
      "screen_name" : "slijepcevicdr",
      "protected" : false,
      "id_str" : "3361432131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763260499106619392\/H_gqCh93_normal.jpg",
      "id" : 3361432131,
      "verified" : false
    }
  },
  "id" : 764225121376698368,
  "created_at" : "2016-08-12 22:20:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Royal Cornwall Show",
      "screen_name" : "RoyalCornwall",
      "indices" : [ 109, 123 ],
      "id_str" : "238133491",
      "id" : 238133491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIPThundercloud",
      "indices" : [ 65, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/KlgAxutHTJ",
      "expanded_url" : "https:\/\/www.facebook.com\/TraditionalShorthorns\/posts\/890898674350054",
      "display_url" : "facebook.com\/TraditionalSho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764218929980010496",
  "text" : "RT @newlandfarm: Heard the news the BigMan passed away this week #RIPThundercloud \n\nhttps:\/\/t.co\/KlgAxutHTJ\n\n@RoyalCornwall 2012 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Royal Cornwall Show",
        "screen_name" : "RoyalCornwall",
        "indices" : [ 92, 106 ],
        "id_str" : "238133491",
        "id" : 238133491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/764183902298763265\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/T1dymF4ekt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CprtMuQWAAEe0wm.jpg",
        "id_str" : "764183889623515137",
        "id" : 764183889623515137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprtMuQWAAEe0wm.jpg",
        "sizes" : [ {
          "h" : 786,
          "resize" : "fit",
          "w" : 719
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 622
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 719
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 719
        } ],
        "display_url" : "pic.twitter.com\/T1dymF4ekt"
      } ],
      "hashtags" : [ {
        "text" : "RIPThundercloud",
        "indices" : [ 48, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/KlgAxutHTJ",
        "expanded_url" : "https:\/\/www.facebook.com\/TraditionalShorthorns\/posts\/890898674350054",
        "display_url" : "facebook.com\/TraditionalSho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764183902298763265",
    "text" : "Heard the news the BigMan passed away this week #RIPThundercloud \n\nhttps:\/\/t.co\/KlgAxutHTJ\n\n@RoyalCornwall 2012 https:\/\/t.co\/T1dymF4ekt",
    "id" : 764183902298763265,
    "created_at" : "2016-08-12 19:36:54 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 764218929980010496,
  "created_at" : "2016-08-12 21:56:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vera Burnayev",
      "screen_name" : "LotusOak",
      "indices" : [ 3, 12 ],
      "id_str" : "424711422",
      "id" : 424711422
    }, {
      "name" : "Doc Bastard",
      "screen_name" : "DocBastard",
      "indices" : [ 15, 26 ],
      "id_str" : "468669904",
      "id" : 468669904
    }, {
      "name" : "Nate Kimble",
      "screen_name" : "Avmech1",
      "indices" : [ 27, 35 ],
      "id_str" : "314331534",
      "id" : 314331534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Measles",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "Mumps",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/98z1O9DNGA",
      "expanded_url" : "http:\/\/www.atherosclerosis-journal.com\/article\/S0021-9150(15)01380-5\/abstract",
      "display_url" : "atherosclerosis-journal.com\/article\/S0021-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764218892705263616",
  "text" : "RT @LotusOak: .@DocBastard @Avmech1\n3) #Measles &amp; #Mumps Lower Risks of Mortality from Atherosclerosis\nhttps:\/\/t.co\/98z1O9DNGA https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Doc Bastard",
        "screen_name" : "DocBastard",
        "indices" : [ 1, 12 ],
        "id_str" : "468669904",
        "id" : 468669904
      }, {
        "name" : "Nate Kimble",
        "screen_name" : "Avmech1",
        "indices" : [ 13, 21 ],
        "id_str" : "314331534",
        "id" : 314331534
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LotusOak\/status\/764196419435696129\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/A9yU46PsfL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpr4kiFXYAE-ffx.jpg",
        "id_str" : "764196393301008385",
        "id" : 764196393301008385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpr4kiFXYAE-ffx.jpg",
        "sizes" : [ {
          "h" : 292,
          "resize" : "fit",
          "w" : 355
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 355
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 355
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 355
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/A9yU46PsfL"
      } ],
      "hashtags" : [ {
        "text" : "Measles",
        "indices" : [ 25, 33 ]
      }, {
        "text" : "Mumps",
        "indices" : [ 40, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/98z1O9DNGA",
        "expanded_url" : "http:\/\/www.atherosclerosis-journal.com\/article\/S0021-9150(15)01380-5\/abstract",
        "display_url" : "atherosclerosis-journal.com\/article\/S0021-\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "764126433975369729",
    "geo" : { },
    "id_str" : "764196419435696129",
    "in_reply_to_user_id" : 468669904,
    "text" : ".@DocBastard @Avmech1\n3) #Measles &amp; #Mumps Lower Risks of Mortality from Atherosclerosis\nhttps:\/\/t.co\/98z1O9DNGA https:\/\/t.co\/A9yU46PsfL",
    "id" : 764196419435696129,
    "in_reply_to_status_id" : 764126433975369729,
    "created_at" : "2016-08-12 20:26:39 +0000",
    "in_reply_to_screen_name" : "DocBastard",
    "in_reply_to_user_id_str" : "468669904",
    "user" : {
      "name" : "Vera Burnayev",
      "screen_name" : "LotusOak",
      "protected" : false,
      "id_str" : "424711422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1665249764\/Lotus_800_normal.jpg",
      "id" : 424711422,
      "verified" : false
    }
  },
  "id" : 764218892705263616,
  "created_at" : "2016-08-12 21:55:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalby Shop",
      "screen_name" : "DalbyShop",
      "indices" : [ 3, 13 ],
      "id_str" : "3073705627",
      "id" : 3073705627
    }, {
      "name" : "Dalby Forest",
      "screen_name" : "Dalby_Forest",
      "indices" : [ 59, 72 ],
      "id_str" : "2285236141",
      "id" : 2285236141
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DalbyShop\/status\/764099328029765634\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/IuJrua0UqK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpqgSWrXEAUdOwv.jpg",
      "id_str" : "764099323978256389",
      "id" : 764099323978256389,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpqgSWrXEAUdOwv.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/IuJrua0UqK"
    } ],
    "hashtags" : [ {
      "text" : "Yorkshire",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764156372606980096",
  "text" : "RT @DalbyShop: Lovely #Yorkshire Sticker Book now in stock @Dalby_Forest shop, hours of entertainment and fun https:\/\/t.co\/IuJrua0UqK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dalby Forest",
        "screen_name" : "Dalby_Forest",
        "indices" : [ 44, 57 ],
        "id_str" : "2285236141",
        "id" : 2285236141
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DalbyShop\/status\/764099328029765634\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/IuJrua0UqK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpqgSWrXEAUdOwv.jpg",
        "id_str" : "764099323978256389",
        "id" : 764099323978256389,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpqgSWrXEAUdOwv.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/IuJrua0UqK"
      } ],
      "hashtags" : [ {
        "text" : "Yorkshire",
        "indices" : [ 7, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764099328029765634",
    "text" : "Lovely #Yorkshire Sticker Book now in stock @Dalby_Forest shop, hours of entertainment and fun https:\/\/t.co\/IuJrua0UqK",
    "id" : 764099328029765634,
    "created_at" : "2016-08-12 14:00:50 +0000",
    "user" : {
      "name" : "Dalby Shop",
      "screen_name" : "DalbyShop",
      "protected" : false,
      "id_str" : "3073705627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575746635193516032\/HeIB9yyc_normal.jpeg",
      "id" : 3073705627,
      "verified" : false
    }
  },
  "id" : 764156372606980096,
  "created_at" : "2016-08-12 17:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ailsa Black Art",
      "screen_name" : "AilsaBlack",
      "indices" : [ 3, 14 ],
      "id_str" : "246222302",
      "id" : 246222302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "competition",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/f4OLQicPNK",
      "expanded_url" : "https:\/\/www.facebook.com\/ailsablackart\/",
      "display_url" : "facebook.com\/ailsablackart\/"
    } ]
  },
  "geo" : { },
  "id_str" : "764107520575213568",
  "text" : "RT @AilsaBlack: It's a #competition sign up to my mailing list for a chance to win 1 of 3 packs of 20 cards https:\/\/t.co\/f4OLQicPNK https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AilsaBlack\/status\/764062673331826688\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FB1cGp4alx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpp-qwlXEAAzNX2.jpg",
        "id_str" : "764062359853928448",
        "id" : 764062359853928448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpp-qwlXEAAzNX2.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FB1cGp4alx"
      } ],
      "hashtags" : [ {
        "text" : "competition",
        "indices" : [ 7, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/f4OLQicPNK",
        "expanded_url" : "https:\/\/www.facebook.com\/ailsablackart\/",
        "display_url" : "facebook.com\/ailsablackart\/"
      } ]
    },
    "geo" : { },
    "id_str" : "764062673331826688",
    "text" : "It's a #competition sign up to my mailing list for a chance to win 1 of 3 packs of 20 cards https:\/\/t.co\/f4OLQicPNK https:\/\/t.co\/FB1cGp4alx",
    "id" : 764062673331826688,
    "created_at" : "2016-08-12 11:35:11 +0000",
    "user" : {
      "name" : "Ailsa Black Art",
      "screen_name" : "AilsaBlack",
      "protected" : false,
      "id_str" : "246222302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460478141341761539\/sfrDF_oS_normal.jpeg",
      "id" : 246222302,
      "verified" : false
    }
  },
  "id" : 764107520575213568,
  "created_at" : "2016-08-12 14:33:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Deep Vault",
      "screen_name" : "thedeepvault",
      "indices" : [ 3, 16 ],
      "id_str" : "751397090861907969",
      "id" : 751397090861907969
    }, {
      "name" : "Archive 81",
      "screen_name" : "Archive81",
      "indices" : [ 39, 49 ],
      "id_str" : "4222298591",
      "id" : 4222298591
    }, {
      "name" : "The Deep Vault",
      "screen_name" : "thedeepvault",
      "indices" : [ 56, 69 ],
      "id_str" : "751397090861907969",
      "id" : 751397090861907969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ZLNW7532zV",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/podcast\/the-deep-vault\/id1140488963?mt=2",
      "display_url" : "itunes.apple.com\/us\/podcast\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763880089910145024",
  "text" : "RT @thedeepvault: From the creators of @Archive81 comes @thedeepvault. Listen to the trailer and subscribe now: https:\/\/t.co\/ZLNW7532zV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Archive 81",
        "screen_name" : "Archive81",
        "indices" : [ 21, 31 ],
        "id_str" : "4222298591",
        "id" : 4222298591
      }, {
        "name" : "The Deep Vault",
        "screen_name" : "thedeepvault",
        "indices" : [ 38, 51 ],
        "id_str" : "751397090861907969",
        "id" : 751397090861907969
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ZLNW7532zV",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/podcast\/the-deep-vault\/id1140488963?mt=2",
        "display_url" : "itunes.apple.com\/us\/podcast\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763222827868839936",
    "text" : "From the creators of @Archive81 comes @thedeepvault. Listen to the trailer and subscribe now: https:\/\/t.co\/ZLNW7532zV",
    "id" : 763222827868839936,
    "created_at" : "2016-08-10 03:57:56 +0000",
    "user" : {
      "name" : "The Deep Vault",
      "screen_name" : "thedeepvault",
      "protected" : false,
      "id_str" : "751397090861907969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758095194298417152\/kNODRayY_normal.jpg",
      "id" : 751397090861907969,
      "verified" : false
    }
  },
  "id" : 763880089910145024,
  "created_at" : "2016-08-11 23:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/763735949260034048\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/kPlsFR91fo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CplVuMUWgAAI_qJ.jpg",
      "id_str" : "763735863884939264",
      "id" : 763735863884939264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplVuMUWgAAI_qJ.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/kPlsFR91fo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/763735949260034048\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/kPlsFR91fo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CplVxVKXgAAxtgQ.jpg",
      "id_str" : "763735917798588416",
      "id" : 763735917798588416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplVxVKXgAAxtgQ.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/kPlsFR91fo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763871131044544513",
  "text" : "RT @Nigelstewart76: Young Robin and young House sparrow in my garden https:\/\/t.co\/kPlsFR91fo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/763735949260034048\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/kPlsFR91fo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CplVuMUWgAAI_qJ.jpg",
        "id_str" : "763735863884939264",
        "id" : 763735863884939264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplVuMUWgAAI_qJ.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/kPlsFR91fo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/763735949260034048\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/kPlsFR91fo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CplVxVKXgAAxtgQ.jpg",
        "id_str" : "763735917798588416",
        "id" : 763735917798588416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplVxVKXgAAxtgQ.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/kPlsFR91fo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763735949260034048",
    "text" : "Young Robin and young House sparrow in my garden https:\/\/t.co\/kPlsFR91fo",
    "id" : 763735949260034048,
    "created_at" : "2016-08-11 13:56:54 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 763871131044544513,
  "created_at" : "2016-08-11 22:54:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "sensitivesoul",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763869775915278337",
  "text" : "todays psych appt provoked a meltdown after. my poor sweet cupcake. : ( #chronicillness #hashimotos #sensitivesoul",
  "id" : 763869775915278337,
  "created_at" : "2016-08-11 22:48:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/763807617273700352\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/51kNlLarlH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpmW-hRWgAE1qgp.jpg",
      "id_str" : "763807612643213313",
      "id" : 763807612643213313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpmW-hRWgAE1qgp.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/51kNlLarlH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/HYRFoJ4la7",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763816120759484416",
  "text" : "RT @dwaynereaves: Come join me on Facebook for more of my photos. Have a great day. https:\/\/t.co\/HYRFoJ4la7 https:\/\/t.co\/51kNlLarlH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/763807617273700352\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/51kNlLarlH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpmW-hRWgAE1qgp.jpg",
        "id_str" : "763807612643213313",
        "id" : 763807612643213313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpmW-hRWgAE1qgp.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1066
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1066
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/51kNlLarlH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/HYRFoJ4la7",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763807617273700352",
    "text" : "Come join me on Facebook for more of my photos. Have a great day. https:\/\/t.co\/HYRFoJ4la7 https:\/\/t.co\/51kNlLarlH",
    "id" : 763807617273700352,
    "created_at" : "2016-08-11 18:41:41 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 763816120759484416,
  "created_at" : "2016-08-11 19:15:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/aliceinthewater\/status\/763743444338475009\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fckAPV3pJi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CplcmzXVIAAvNCa.jpg",
      "id_str" : "763743433508855808",
      "id" : 763743433508855808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplcmzXVIAAvNCa.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/fckAPV3pJi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763767609506537472",
  "text" : "RT @aliceinthewater: I shall wear a light jacket because there will be gays about https:\/\/t.co\/fckAPV3pJi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aliceinthewater\/status\/763743444338475009\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/fckAPV3pJi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CplcmzXVIAAvNCa.jpg",
        "id_str" : "763743433508855808",
        "id" : 763743433508855808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplcmzXVIAAvNCa.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/fckAPV3pJi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763743444338475009",
    "text" : "I shall wear a light jacket because there will be gays about https:\/\/t.co\/fckAPV3pJi",
    "id" : 763743444338475009,
    "created_at" : "2016-08-11 14:26:41 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 763767609506537472,
  "created_at" : "2016-08-11 16:02:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mean Fat Girl",
      "screen_name" : "Artists_Ali",
      "indices" : [ 0, 12 ],
      "id_str" : "31624328",
      "id" : 31624328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763555577050066944",
  "geo" : { },
  "id_str" : "763556805939228672",
  "in_reply_to_user_id" : 31624328,
  "text" : "@Artists_Ali smoochable belleh! : )",
  "id" : 763556805939228672,
  "in_reply_to_status_id" : 763555577050066944,
  "created_at" : "2016-08-11 02:05:03 +0000",
  "in_reply_to_screen_name" : "Artists_Ali",
  "in_reply_to_user_id_str" : "31624328",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lornaslaces",
      "screen_name" : "lornaslaces",
      "indices" : [ 3, 15 ],
      "id_str" : "17542720",
      "id" : 17542720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763544032819703808",
  "text" : "RT @lornaslaces: Thinking about Olympic knitting? I just finished Adrienne Krey's Necklace Cowl in String Quintet color Rings. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lornaslaces\/status\/758333021929877505\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/7Rw0jb2pj5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYjzpOVMAAlJmA.jpg",
        "id_str" : "758332957404770304",
        "id" : 758332957404770304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYjzpOVMAAlJmA.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/7Rw0jb2pj5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758333021929877505",
    "text" : "Thinking about Olympic knitting? I just finished Adrienne Krey's Necklace Cowl in String Quintet color Rings. https:\/\/t.co\/7Rw0jb2pj5",
    "id" : 758333021929877505,
    "created_at" : "2016-07-27 16:07:36 +0000",
    "user" : {
      "name" : "lornaslaces",
      "screen_name" : "lornaslaces",
      "protected" : false,
      "id_str" : "17542720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641665383217233922\/Us6XC-yb_normal.jpg",
      "id" : 17542720,
      "verified" : false
    }
  },
  "id" : 763544032819703808,
  "created_at" : "2016-08-11 01:14:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/krva0uTE9B",
      "expanded_url" : "https:\/\/twitter.com\/Squirrely007\/status\/763539430934212608",
      "display_url" : "twitter.com\/Squirrely007\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763543261000699904",
  "text" : "just.. wow.. why did they even have a small child there? jeezzzzz.. poor kiddo. https:\/\/t.co\/krva0uTE9B",
  "id" : 763543261000699904,
  "created_at" : "2016-08-11 01:11:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "indices" : [ 3, 18 ],
      "id_str" : "27268080",
      "id" : 27268080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763541205204471809",
  "text" : "RT @StarStuff_ivan: An atom is 99.999999999% empty space\nthe entire human race could fit in the volume of a sugar cube https:\/\/t.co\/L509j5M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff_ivan\/status\/763515161521029120\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/L509j5MBHt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpiLA0KW8AMYIlJ.jpg",
        "id_str" : "763512982957649923",
        "id" : 763512982957649923,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpiLA0KW8AMYIlJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/L509j5MBHt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763515161521029120",
    "text" : "An atom is 99.999999999% empty space\nthe entire human race could fit in the volume of a sugar cube https:\/\/t.co\/L509j5MBHt",
    "id" : 763515161521029120,
    "created_at" : "2016-08-10 23:19:34 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 763541205204471809,
  "created_at" : "2016-08-11 01:03:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763524642329944064",
  "geo" : { },
  "id_str" : "763537781540941824",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley really love that color combo",
  "id" : 763537781540941824,
  "in_reply_to_status_id" : 763524642329944064,
  "created_at" : "2016-08-11 00:49:27 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/x0a3fPCKjf",
      "expanded_url" : "https:\/\/twitter.com\/richarddoetsch\/status\/763510649351729152",
      "display_url" : "twitter.com\/richarddoetsch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763511671440703489",
  "text" : "ignoring it usually works for me... https:\/\/t.co\/x0a3fPCKjf",
  "id" : 763511671440703489,
  "created_at" : "2016-08-10 23:05:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/763480502812631040\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/2loUweanfq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cphtd5zVIAAcnzr.jpg",
      "id_str" : "763480497339047936",
      "id" : 763480497339047936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cphtd5zVIAAcnzr.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/2loUweanfq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Lsv9w2njb6",
      "expanded_url" : "http:\/\/goo.gl\/L5vQAa",
      "display_url" : "goo.gl\/L5vQAa"
    } ]
  },
  "geo" : { },
  "id_str" : "763494123953352705",
  "text" : "RT @openculture: Artist Draws Nine Portraits on LSD During 1950s Research Experiment https:\/\/t.co\/Lsv9w2njb6 https:\/\/t.co\/2loUweanfq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/763480502812631040\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/2loUweanfq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cphtd5zVIAAcnzr.jpg",
        "id_str" : "763480497339047936",
        "id" : 763480497339047936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cphtd5zVIAAcnzr.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/2loUweanfq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/Lsv9w2njb6",
        "expanded_url" : "http:\/\/goo.gl\/L5vQAa",
        "display_url" : "goo.gl\/L5vQAa"
      } ]
    },
    "geo" : { },
    "id_str" : "763480502812631040",
    "text" : "Artist Draws Nine Portraits on LSD During 1950s Research Experiment https:\/\/t.co\/Lsv9w2njb6 https:\/\/t.co\/2loUweanfq",
    "id" : 763480502812631040,
    "created_at" : "2016-08-10 21:01:51 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74425623\/open_culture_white_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 763494123953352705,
  "created_at" : "2016-08-10 21:55:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/wYsxDcNVFZ",
      "expanded_url" : "https:\/\/twitter.com\/abc15\/status\/763429974074331137",
      "display_url" : "twitter.com\/abc15\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763442023655407616",
  "text" : "RT @MimiMadeira1: We need more judges like this one https:\/\/t.co\/wYsxDcNVFZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/wYsxDcNVFZ",
        "expanded_url" : "https:\/\/twitter.com\/abc15\/status\/763429974074331137",
        "display_url" : "twitter.com\/abc15\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763431357292818432",
    "text" : "We need more judges like this one https:\/\/t.co\/wYsxDcNVFZ",
    "id" : 763431357292818432,
    "created_at" : "2016-08-10 17:46:34 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 763442023655407616,
  "created_at" : "2016-08-10 18:28:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763412428805771264",
  "geo" : { },
  "id_str" : "763441329011585024",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe (((hugs))) thx 4 update!",
  "id" : 763441329011585024,
  "in_reply_to_status_id" : 763412428805771264,
  "created_at" : "2016-08-10 18:26:11 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norm Clark",
      "screen_name" : "Normsmusic",
      "indices" : [ 3, 14 ],
      "id_str" : "20852175",
      "id" : 20852175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763440715271725057",
  "text" : "RT @Normsmusic: If you read Jason's entire link here (Recommend) he does a great job in describing the what &amp; why of \"Just Joking\" https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/P2hf1wfW9o",
        "expanded_url" : "https:\/\/twitter.com\/5thCircAppeals\/status\/763098172633657344",
        "display_url" : "twitter.com\/5thCircAppeals\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763421126294855680",
    "text" : "If you read Jason's entire link here (Recommend) he does a great job in describing the what &amp; why of \"Just Joking\" https:\/\/t.co\/P2hf1wfW9o",
    "id" : 763421126294855680,
    "created_at" : "2016-08-10 17:05:54 +0000",
    "user" : {
      "name" : "Norm Clark",
      "screen_name" : "Normsmusic",
      "protected" : false,
      "id_str" : "20852175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571160298993770497\/VmzDv-FJ_normal.jpeg",
      "id" : 20852175,
      "verified" : false
    }
  },
  "id" : 763440715271725057,
  "created_at" : "2016-08-10 18:23:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    }, {
      "name" : "OfficialSwanwatchUk",
      "screen_name" : "SwanwatchUk",
      "indices" : [ 33, 45 ],
      "id_str" : "756088705501237248",
      "id" : 756088705501237248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763408122622926848",
  "text" : "RT @Swanwhisperer: HEY! Official @SwanwatchUk Cygnets Seasonal country Count 2016 is in 22 days Thurday 1st September at 5.00PM UK TIME htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OfficialSwanwatchUk",
        "screen_name" : "SwanwatchUk",
        "indices" : [ 14, 26 ],
        "id_str" : "756088705501237248",
        "id" : 756088705501237248
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/763310802019446784\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/dCMvDVTnbH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpfS28kWAAAJ49E.jpg",
        "id_str" : "763310503275921408",
        "id" : 763310503275921408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpfS28kWAAAJ49E.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/dCMvDVTnbH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763310802019446784",
    "text" : "HEY! Official @SwanwatchUk Cygnets Seasonal country Count 2016 is in 22 days Thurday 1st September at 5.00PM UK TIME https:\/\/t.co\/dCMvDVTnbH",
    "id" : 763310802019446784,
    "created_at" : "2016-08-10 09:47:31 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 763408122622926848,
  "created_at" : "2016-08-10 16:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763371161925234688",
  "geo" : { },
  "id_str" : "763407186173259778",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous wth you do that for? gah. feel better soon.",
  "id" : 763407186173259778,
  "in_reply_to_status_id" : 763371161925234688,
  "created_at" : "2016-08-10 16:10:31 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "indices" : [ 3, 14 ],
      "id_str" : "2815401127",
      "id" : 2815401127
    }, {
      "name" : "The Milk Story",
      "screen_name" : "KoeOpAvontuur",
      "indices" : [ 41, 55 ],
      "id_str" : "391567080",
      "id" : 391567080
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 56, 68 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 69, 81 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Eva R\u00FCger",
      "screen_name" : "agrivision_er",
      "indices" : [ 82, 96 ],
      "id_str" : "719164404231749633",
      "id" : 719164404231749633
    }, {
      "name" : "Adrian Clark",
      "screen_name" : "adrianjcl123",
      "indices" : [ 97, 110 ],
      "id_str" : "1038309122",
      "id" : 1038309122
    }, {
      "name" : "Sony UK",
      "screen_name" : "SonyUK",
      "indices" : [ 111, 118 ],
      "id_str" : "17804411",
      "id" : 17804411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763405276393402370",
  "text" : "RT @gertvanden: Beach babe (Netherlands) @KoeOpAvontuur @newlandfarm @ErinEFarley @agrivision_er @adrianjcl123 @SonyUK https:\/\/t.co\/Zm9uFkn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Milk Story",
        "screen_name" : "KoeOpAvontuur",
        "indices" : [ 25, 39 ],
        "id_str" : "391567080",
        "id" : 391567080
      }, {
        "name" : "Newland Farm",
        "screen_name" : "newlandfarm",
        "indices" : [ 40, 52 ],
        "id_str" : "2259182801",
        "id" : 2259182801
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 53, 65 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      }, {
        "name" : "Eva R\u00FCger",
        "screen_name" : "agrivision_er",
        "indices" : [ 66, 80 ],
        "id_str" : "719164404231749633",
        "id" : 719164404231749633
      }, {
        "name" : "Adrian Clark",
        "screen_name" : "adrianjcl123",
        "indices" : [ 81, 94 ],
        "id_str" : "1038309122",
        "id" : 1038309122
      }, {
        "name" : "Sony UK",
        "screen_name" : "SonyUK",
        "indices" : [ 95, 102 ],
        "id_str" : "17804411",
        "id" : 17804411
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/763330968505741312\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/Zm9uFkn2Su",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpflONGXgAAMkIq.jpg",
        "id_str" : "763330694059884544",
        "id" : 763330694059884544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpflONGXgAAMkIq.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/Zm9uFkn2Su"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763330968505741312",
    "text" : "Beach babe (Netherlands) @KoeOpAvontuur @newlandfarm @ErinEFarley @agrivision_er @adrianjcl123 @SonyUK https:\/\/t.co\/Zm9uFkn2Su",
    "id" : 763330968505741312,
    "created_at" : "2016-08-10 11:07:39 +0000",
    "user" : {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "protected" : false,
      "id_str" : "2815401127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635003322211147776\/tdmuR7zK_normal.jpg",
      "id" : 2815401127,
      "verified" : false
    }
  },
  "id" : 763405276393402370,
  "created_at" : "2016-08-10 16:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roselyne B\u00E9auce",
      "screen_name" : "mobielemondzorg",
      "indices" : [ 3, 19 ],
      "id_str" : "1565284458",
      "id" : 1565284458
    }, {
      "name" : "Healthline",
      "screen_name" : "Healthline",
      "indices" : [ 98, 109 ],
      "id_str" : "14985126",
      "id" : 14985126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Cru9Kd4cyg",
      "expanded_url" : "http:\/\/www.healthline.com\/health-news\/dentists-will-soon-print-antibacterial-3d-teeth-011316",
      "display_url" : "healthline.com\/health-news\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763405089792991232",
  "text" : "RT @mobielemondzorg: Dentists Will Soon Print Antibacterial 3-D Teeth https:\/\/t.co\/Cru9Kd4cyg via @healthline",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Healthline",
        "screen_name" : "Healthline",
        "indices" : [ 77, 88 ],
        "id_str" : "14985126",
        "id" : 14985126
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/Cru9Kd4cyg",
        "expanded_url" : "http:\/\/www.healthline.com\/health-news\/dentists-will-soon-print-antibacterial-3d-teeth-011316",
        "display_url" : "healthline.com\/health-news\/de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762966326927327232",
    "text" : "Dentists Will Soon Print Antibacterial 3-D Teeth https:\/\/t.co\/Cru9Kd4cyg via @healthline",
    "id" : 762966326927327232,
    "created_at" : "2016-08-09 10:58:42 +0000",
    "user" : {
      "name" : "Roselyne B\u00E9auce",
      "screen_name" : "mobielemondzorg",
      "protected" : false,
      "id_str" : "1565284458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735000443789545472\/9N5ms2K9_normal.jpg",
      "id" : 1565284458,
      "verified" : false
    }
  },
  "id" : 763405089792991232,
  "created_at" : "2016-08-10 16:02:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "clicks n' whistles",
      "screen_name" : "oceanCRIES",
      "indices" : [ 3, 14 ],
      "id_str" : "422305556",
      "id" : 422305556
    }, {
      "name" : "One Green Planet",
      "screen_name" : "OneGreenPlanet",
      "indices" : [ 120, 135 ],
      "id_str" : "134555743",
      "id" : 134555743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dolphin",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "iPad",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/zD4gyKXUpA",
      "expanded_url" : "http:\/\/www.onegreenplanet.org\/news\/dolphin-grabs-an-ipad\/",
      "display_url" : "onegreenplanet.org\/news\/dolphin-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763404477252640770",
  "text" : "RT @oceanCRIES: Why This Video of a #Dolphin Grabbing a Woman\u2019s #iPad is NOT Funny nor Cute https:\/\/t.co\/zD4gyKXUpA via @OneGreenPlanet\n#Do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One Green Planet",
        "screen_name" : "OneGreenPlanet",
        "indices" : [ 104, 119 ],
        "id_str" : "134555743",
        "id" : 134555743
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dolphin",
        "indices" : [ 20, 28 ]
      }, {
        "text" : "iPad",
        "indices" : [ 48, 53 ]
      }, {
        "text" : "DontGoToSeaWorld",
        "indices" : [ 120, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/zD4gyKXUpA",
        "expanded_url" : "http:\/\/www.onegreenplanet.org\/news\/dolphin-grabs-an-ipad\/",
        "display_url" : "onegreenplanet.org\/news\/dolphin-g\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "762838063605125122",
    "geo" : { },
    "id_str" : "763395161879609344",
    "in_reply_to_user_id" : 422305556,
    "text" : "Why This Video of a #Dolphin Grabbing a Woman\u2019s #iPad is NOT Funny nor Cute https:\/\/t.co\/zD4gyKXUpA via @OneGreenPlanet\n#DontGoToSeaWorld",
    "id" : 763395161879609344,
    "in_reply_to_status_id" : 762838063605125122,
    "created_at" : "2016-08-10 15:22:44 +0000",
    "in_reply_to_screen_name" : "oceanCRIES",
    "in_reply_to_user_id_str" : "422305556",
    "user" : {
      "name" : "clicks n' whistles",
      "screen_name" : "oceanCRIES",
      "protected" : false,
      "id_str" : "422305556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1659891932\/floating_normal.jpg",
      "id" : 422305556,
      "verified" : false
    }
  },
  "id" : 763404477252640770,
  "created_at" : "2016-08-10 15:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maura quint",
      "screen_name" : "behindyourback",
      "indices" : [ 3, 18 ],
      "id_str" : "31455711",
      "id" : 31455711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/MnmUOzmXBs",
      "expanded_url" : "https:\/\/twitter.com\/bradheath\/status\/763380063765233669",
      "display_url" : "twitter.com\/bradheath\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763404416695369728",
  "text" : "RT @behindyourback: this will sadly not be surprising to sexual assault victims anywhere in the US https:\/\/t.co\/MnmUOzmXBs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/MnmUOzmXBs",
        "expanded_url" : "https:\/\/twitter.com\/bradheath\/status\/763380063765233669",
        "display_url" : "twitter.com\/bradheath\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763395176186478592",
    "text" : "this will sadly not be surprising to sexual assault victims anywhere in the US https:\/\/t.co\/MnmUOzmXBs",
    "id" : 763395176186478592,
    "created_at" : "2016-08-10 15:22:47 +0000",
    "user" : {
      "name" : "maura quint",
      "screen_name" : "behindyourback",
      "protected" : false,
      "id_str" : "31455711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617123223101018113\/rRf4L1ai_normal.jpg",
      "id" : 31455711,
      "verified" : true
    }
  },
  "id" : 763404416695369728,
  "created_at" : "2016-08-10 15:59:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad R. Turner \uD83D\uDE80",
      "screen_name" : "joinchadnow",
      "indices" : [ 3, 15 ],
      "id_str" : "3239767856",
      "id" : 3239767856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantumphysics",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763363263975481344",
  "text" : "RT @joinchadnow: The reason why a scientist gets stuck on #quantumphysics is there's no money in telling the world that only personal exper\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quantumphysics",
        "indices" : [ 41, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763226976639447040",
    "text" : "The reason why a scientist gets stuck on #quantumphysics is there's no money in telling the world that only personal experience matters.",
    "id" : 763226976639447040,
    "created_at" : "2016-08-10 04:14:25 +0000",
    "user" : {
      "name" : "Chad R. Turner \uD83D\uDE80",
      "screen_name" : "joinchadnow",
      "protected" : false,
      "id_str" : "3239767856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713637446563532800\/HmGTeZTd_normal.jpg",
      "id" : 3239767856,
      "verified" : false
    }
  },
  "id" : 763363263975481344,
  "created_at" : "2016-08-10 13:15:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason P. Steed",
      "screen_name" : "5thCircAppeals",
      "indices" : [ 54, 69 ],
      "id_str" : "154286132",
      "id" : 154286132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/WnXJyk7SBJ",
      "expanded_url" : "https:\/\/storify.com\/5thCircAppeals\/on-trump-just-joking",
      "display_url" : "storify.com\/5thCircAppeals\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763169308411297796",
  "text" : "Trump &amp; \"Just Joking\" https:\/\/t.co\/WnXJyk7SBJ via @5thcircappeals",
  "id" : 763169308411297796,
  "created_at" : "2016-08-10 00:25:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dorothy Ponton",
      "screen_name" : "PontDD",
      "indices" : [ 83, 90 ],
      "id_str" : "57739700",
      "id" : 57739700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/WMt4lRieEY",
      "expanded_url" : "https:\/\/storify.com\/AskDoctorPonton\/here-s-the-thing-about-just-joking-by",
      "display_url" : "storify.com\/AskDoctorPonto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763168948145750016",
  "text" : "Here's the thing about \"just joking\" by Jason P. Steed https:\/\/t.co\/WMt4lRieEY via @pontdd",
  "id" : 763168948145750016,
  "created_at" : "2016-08-10 00:23:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason P. Steed",
      "screen_name" : "5thCircAppeals",
      "indices" : [ 3, 18 ],
      "id_str" : "154286132",
      "id" : 154286132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763167493473046528",
  "text" : "RT @5thCircAppeals: 6. IOW, we use humor to bring people into - or keep them out of - our social groups. This is what humor *does.* What it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "763099907913764864",
    "geo" : { },
    "id_str" : "763100639094112256",
    "in_reply_to_user_id" : 154286132,
    "text" : "6. IOW, we use humor to bring people into - or keep them out of - our social groups. This is what humor *does.* What it's for.",
    "id" : 763100639094112256,
    "in_reply_to_status_id" : 763099907913764864,
    "created_at" : "2016-08-09 19:52:24 +0000",
    "in_reply_to_screen_name" : "5thCircAppeals",
    "in_reply_to_user_id_str" : "154286132",
    "user" : {
      "name" : "Jason P. Steed",
      "screen_name" : "5thCircAppeals",
      "protected" : false,
      "id_str" : "154286132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794248480671703040\/ygXGsCoU_normal.jpg",
      "id" : 154286132,
      "verified" : false
    }
  },
  "id" : 763167493473046528,
  "created_at" : "2016-08-10 00:18:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Duca",
      "screen_name" : "laurenduca",
      "indices" : [ 3, 14 ],
      "id_str" : "289342771",
      "id" : 289342771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/mXeNSj3bQy",
      "expanded_url" : "https:\/\/twitter.com\/5thcircappeals\/status\/763098172633657344",
      "display_url" : "twitter.com\/5thcircappeals\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763167213838794752",
  "text" : "RT @laurenduca: Important thread on Trump's second amendment \"joke.\" \uD83D\uDC47 https:\/\/t.co\/mXeNSj3bQy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/mXeNSj3bQy",
        "expanded_url" : "https:\/\/twitter.com\/5thcircappeals\/status\/763098172633657344",
        "display_url" : "twitter.com\/5thcircappeals\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763133369588649984",
    "text" : "Important thread on Trump's second amendment \"joke.\" \uD83D\uDC47 https:\/\/t.co\/mXeNSj3bQy",
    "id" : 763133369588649984,
    "created_at" : "2016-08-09 22:02:28 +0000",
    "user" : {
      "name" : "Lauren Duca",
      "screen_name" : "laurenduca",
      "protected" : false,
      "id_str" : "289342771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729070169021161472\/60VSpTLf_normal.jpg",
      "id" : 289342771,
      "verified" : true
    }
  },
  "id" : 763167213838794752,
  "created_at" : "2016-08-10 00:16:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763141020066390016",
  "geo" : { },
  "id_str" : "763148437986697216",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides im feeling better since sat night. think it was virus. DD is ok atm. seems like you've made a new friend? : )",
  "id" : 763148437986697216,
  "in_reply_to_status_id" : 763141020066390016,
  "created_at" : "2016-08-09 23:02:20 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763139610323156992",
  "geo" : { },
  "id_str" : "763146900346396675",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe i was thinking arm not teeth.. i hope it goes smoothly and you get good pain meds.",
  "id" : 763146900346396675,
  "in_reply_to_status_id" : 763139610323156992,
  "created_at" : "2016-08-09 22:56:14 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763090532021182464",
  "geo" : { },
  "id_str" : "763139038224211968",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe bone graft? wishing you an uneventful recovery. ((hugs))",
  "id" : 763139038224211968,
  "in_reply_to_status_id" : 763090532021182464,
  "created_at" : "2016-08-09 22:24:59 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763129925935267840",
  "text" : "RT @AnnotatedBible: To those who claim EVERYTHING is God's will:\n\nJesus said those who do God's will are saved.\n\nIs EVERYONE saved then?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763103943354257408",
    "text" : "To those who claim EVERYTHING is God's will:\n\nJesus said those who do God's will are saved.\n\nIs EVERYONE saved then?",
    "id" : 763103943354257408,
    "created_at" : "2016-08-09 20:05:32 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 763129925935267840,
  "created_at" : "2016-08-09 21:48:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BetaList",
      "screen_name" : "BetaList",
      "indices" : [ 88, 97 ],
      "id_str" : "212711552",
      "id" : 212711552
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BetaList\/status\/762999902498676736\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/q5pDWGBrH3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpa4XZGWIAANORS.jpg",
      "id_str" : "762999898899881984",
      "id" : 762999898899881984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpa4XZGWIAANORS.jpg",
      "sizes" : [ {
        "h" : 791,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1517
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1517
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/q5pDWGBrH3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/yZr8G23qXc",
      "expanded_url" : "http:\/\/btl.st\/2aILb4n",
      "display_url" : "btl.st\/2aILb4n"
    } ]
  },
  "geo" : { },
  "id_str" : "763120640157184002",
  "text" : "Flanity: Topic based social network https:\/\/t.co\/q5pDWGBrH3 https:\/\/t.co\/yZr8G23qXc via @BetaList",
  "id" : 763120640157184002,
  "created_at" : "2016-08-09 21:11:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dice ",
      "screen_name" : "DiceMore",
      "indices" : [ 3, 12 ],
      "id_str" : "4802111977",
      "id" : 4802111977
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 118, 126 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/SC1JxzxOpa",
      "expanded_url" : "https:\/\/youtu.be\/CC0kjpxx1jI",
      "display_url" : "youtu.be\/CC0kjpxx1jI"
    } ]
  },
  "geo" : { },
  "id_str" : "763052643640020992",
  "text" : "RT @DiceMore: Atheists on Air: Beyond the Trailer Park Ep. 79: Ex-Scientologist Pete G... https:\/\/t.co\/SC1JxzxOpa via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 104, 112 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/SC1JxzxOpa",
        "expanded_url" : "https:\/\/youtu.be\/CC0kjpxx1jI",
        "display_url" : "youtu.be\/CC0kjpxx1jI"
      } ]
    },
    "geo" : { },
    "id_str" : "763014640901185536",
    "text" : "Atheists on Air: Beyond the Trailer Park Ep. 79: Ex-Scientologist Pete G... https:\/\/t.co\/SC1JxzxOpa via @YouTube",
    "id" : 763014640901185536,
    "created_at" : "2016-08-09 14:10:41 +0000",
    "user" : {
      "name" : "Dice ",
      "screen_name" : "DiceMore",
      "protected" : false,
      "id_str" : "4802111977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705842045470920706\/H2xxYs6w_normal.jpg",
      "id" : 4802111977,
      "verified" : false
    }
  },
  "id" : 763052643640020992,
  "created_at" : "2016-08-09 16:41:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "indices" : [ 3, 12 ],
      "id_str" : "75372132",
      "id" : 75372132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalBookLoversDay",
      "indices" : [ 20, 42 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763049038006611968",
  "text" : "RT @PRHAudio: Happy #NationalBookLoversDay! RT for a chance to WIN a FREE #audiobook tote bag w\/ other goodies. For US only. https:\/\/t.co\/z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PRHAudio\/status\/763030316546154496\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/z9E1E0119g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpbTx4NXgAEJIBD.jpg",
        "id_str" : "763030040741380097",
        "id" : 763030040741380097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpbTx4NXgAEJIBD.jpg",
        "sizes" : [ {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/z9E1E0119g"
      } ],
      "hashtags" : [ {
        "text" : "NationalBookLoversDay",
        "indices" : [ 6, 28 ]
      }, {
        "text" : "audiobook",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763030316546154496",
    "text" : "Happy #NationalBookLoversDay! RT for a chance to WIN a FREE #audiobook tote bag w\/ other goodies. For US only. https:\/\/t.co\/z9E1E0119g",
    "id" : 763030316546154496,
    "created_at" : "2016-08-09 15:12:58 +0000",
    "user" : {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "protected" : false,
      "id_str" : "75372132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606215515279753216\/KBzpETdK_normal.jpg",
      "id" : 75372132,
      "verified" : false
    }
  },
  "id" : 763049038006611968,
  "created_at" : "2016-08-09 16:27:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Y0fjBHxMLo",
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/762871303854432256",
      "display_url" : "twitter.com\/ErinEFarley\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763048074755317760",
  "text" : "ohh pretty! https:\/\/t.co\/Y0fjBHxMLo",
  "id" : 763048074755317760,
  "created_at" : "2016-08-09 16:23:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762963078187196416",
  "geo" : { },
  "id_str" : "763047306975449088",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ugh. im lucky in that DDs awake when I am. restless during night then sleeps til noon. she sleeps more than awake generally.",
  "id" : 763047306975449088,
  "in_reply_to_status_id" : 762963078187196416,
  "created_at" : "2016-08-09 16:20:29 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762989799963713536",
  "geo" : { },
  "id_str" : "763045048925712384",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre ummm.. hmm..",
  "id" : 763045048925712384,
  "in_reply_to_status_id" : 762989799963713536,
  "created_at" : "2016-08-09 16:11:31 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Economic Forum",
      "screen_name" : "wef",
      "indices" : [ 3, 7 ],
      "id_str" : "5120691",
      "id" : 5120691
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wef\/status\/763009951216304128\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ITix7e2JHp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpbBgVgW8AA3dTQ.jpg",
      "id_str" : "763009948158717952",
      "id" : 763009948158717952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpbBgVgW8AA3dTQ.jpg",
      "sizes" : [ {
        "h" : 190,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/ITix7e2JHp"
    } ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/qtecwOCicO",
      "expanded_url" : "http:\/\/wef.ch\/2aIrhpT",
      "display_url" : "wef.ch\/2aIrhpT"
    } ]
  },
  "geo" : { },
  "id_str" : "763044047921483776",
  "text" : "RT @wef: Scientists can now create liquid fuel from solar #energy https:\/\/t.co\/qtecwOCicO https:\/\/t.co\/ITix7e2JHp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wef\/status\/763009951216304128\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ITix7e2JHp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpbBgVgW8AA3dTQ.jpg",
        "id_str" : "763009948158717952",
        "id" : 763009948158717952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpbBgVgW8AA3dTQ.jpg",
        "sizes" : [ {
          "h" : 190,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/ITix7e2JHp"
      } ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 49, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/qtecwOCicO",
        "expanded_url" : "http:\/\/wef.ch\/2aIrhpT",
        "display_url" : "wef.ch\/2aIrhpT"
      } ]
    },
    "geo" : { },
    "id_str" : "763009951216304128",
    "text" : "Scientists can now create liquid fuel from solar #energy https:\/\/t.co\/qtecwOCicO https:\/\/t.co\/ITix7e2JHp",
    "id" : 763009951216304128,
    "created_at" : "2016-08-09 13:52:03 +0000",
    "user" : {
      "name" : "World Economic Forum",
      "screen_name" : "wef",
      "protected" : false,
      "id_str" : "5120691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565498192171507712\/r2Hb2gvX_normal.png",
      "id" : 5120691,
      "verified" : true
    }
  },
  "id" : 763044047921483776,
  "created_at" : "2016-08-09 16:07:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Cooper",
      "screen_name" : "sound_coop",
      "indices" : [ 3, 14 ],
      "id_str" : "194522832",
      "id" : 194522832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sound_coop\/status\/762801614080073728\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/mbSdhfzeJ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpYEBYnXYAItUNO.jpg",
      "id_str" : "762801608719818754",
      "id" : 762801608719818754,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpYEBYnXYAItUNO.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/mbSdhfzeJ4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763032533818802176",
  "text" : "RT @sound_coop: With those glasses?\nI'm pretty sure he can. https:\/\/t.co\/mbSdhfzeJ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sound_coop\/status\/762801614080073728\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/mbSdhfzeJ4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpYEBYnXYAItUNO.jpg",
        "id_str" : "762801608719818754",
        "id" : 762801608719818754,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpYEBYnXYAItUNO.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/mbSdhfzeJ4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762801614080073728",
    "text" : "With those glasses?\nI'm pretty sure he can. https:\/\/t.co\/mbSdhfzeJ4",
    "id" : 762801614080073728,
    "created_at" : "2016-08-09 00:04:11 +0000",
    "user" : {
      "name" : "Paul Cooper",
      "screen_name" : "sound_coop",
      "protected" : false,
      "id_str" : "194522832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789761651650224128\/9qH27SDG_normal.jpg",
      "id" : 194522832,
      "verified" : false
    }
  },
  "id" : 763032533818802176,
  "created_at" : "2016-08-09 15:21:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adnan Al-Daini",
      "screen_name" : "respect65",
      "indices" : [ 3, 13 ],
      "id_str" : "221710101",
      "id" : 221710101
    }, {
      "name" : "The Labour Party",
      "screen_name" : "UKLabour",
      "indices" : [ 121, 130 ],
      "id_str" : "14291684",
      "id" : 14291684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basicincome",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763032297117540352",
  "text" : "RT @respect65: The necessities of life R basic human rights; let us grant them 2 every citizen by adopting #basicincome  @UKLabour\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Labour Party",
        "screen_name" : "UKLabour",
        "indices" : [ 106, 115 ],
        "id_str" : "14291684",
        "id" : 14291684
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "basicincome",
        "indices" : [ 92, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/NgQFpPJ9SA",
        "expanded_url" : "http:\/\/www.huffingtonpost.co.uk\/adnan-aldaini\/basic-income_b_9320320.html?utm_hp_ref=uk-conservative-party",
        "display_url" : "huffingtonpost.co.uk\/adnan-aldaini\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763015959519035393",
    "text" : "The necessities of life R basic human rights; let us grant them 2 every citizen by adopting #basicincome  @UKLabour\nhttps:\/\/t.co\/NgQFpPJ9SA",
    "id" : 763015959519035393,
    "created_at" : "2016-08-09 14:15:55 +0000",
    "user" : {
      "name" : "Adnan Al-Daini",
      "screen_name" : "respect65",
      "protected" : false,
      "id_str" : "221710101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1401774761\/img006_normal.jpg",
      "id" : 221710101,
      "verified" : false
    }
  },
  "id" : 763032297117540352,
  "created_at" : "2016-08-09 15:20:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carli Velocci",
      "screen_name" : "velocciraptor",
      "indices" : [ 3, 17 ],
      "id_str" : "206713027",
      "id" : 206713027
    }, {
      "name" : "Javy Gwaltney",
      "screen_name" : "HurdyIV",
      "indices" : [ 25, 33 ],
      "id_str" : "2342834784",
      "id" : 2342834784
    }, {
      "name" : "austin walker",
      "screen_name" : "austin_walker",
      "indices" : [ 34, 48 ],
      "id_str" : "18758101",
      "id" : 18758101
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/velocciraptor\/status\/761988558731157504\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/zmn5jZ0uVb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMgiDnVYAArnJ_.jpg",
      "id_str" : "761988531413671936",
      "id" : 761988531413671936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMgiDnVYAArnJ_.jpg",
      "sizes" : [ {
        "h" : 444,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 523
      } ],
      "display_url" : "pic.twitter.com\/zmn5jZ0uVb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762455044419575808",
  "text" : "RT @velocciraptor: Wait, @HurdyIV @austin_walker it's actually amazing https:\/\/t.co\/zmn5jZ0uVb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Javy Gwaltney",
        "screen_name" : "HurdyIV",
        "indices" : [ 6, 14 ],
        "id_str" : "2342834784",
        "id" : 2342834784
      }, {
        "name" : "austin walker",
        "screen_name" : "austin_walker",
        "indices" : [ 15, 29 ],
        "id_str" : "18758101",
        "id" : 18758101
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/velocciraptor\/status\/761988558731157504\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/zmn5jZ0uVb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMgiDnVYAArnJ_.jpg",
        "id_str" : "761988531413671936",
        "id" : 761988531413671936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMgiDnVYAArnJ_.jpg",
        "sizes" : [ {
          "h" : 444,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 523
        } ],
        "display_url" : "pic.twitter.com\/zmn5jZ0uVb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761975269242572800",
    "geo" : { },
    "id_str" : "761988558731157504",
    "in_reply_to_user_id" : 2342834784,
    "text" : "Wait, @HurdyIV @austin_walker it's actually amazing https:\/\/t.co\/zmn5jZ0uVb",
    "id" : 761988558731157504,
    "in_reply_to_status_id" : 761975269242572800,
    "created_at" : "2016-08-06 18:13:24 +0000",
    "in_reply_to_screen_name" : "HurdyIV",
    "in_reply_to_user_id_str" : "2342834784",
    "user" : {
      "name" : "Carli Velocci",
      "screen_name" : "velocciraptor",
      "protected" : false,
      "id_str" : "206713027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782272881015205892\/OgWRrY8r_normal.jpg",
      "id" : 206713027,
      "verified" : true
    }
  },
  "id" : 762455044419575808,
  "created_at" : "2016-08-08 01:07:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Skelton",
      "screen_name" : "pskeltonphoto",
      "indices" : [ 3, 17 ],
      "id_str" : "349829126",
      "id" : 349829126
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Clare",
      "indices" : [ 73, 79 ]
    }, {
      "text" : "Ireland",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762389963367444481",
  "text" : "RT @pskeltonphoto: The Wildatlanticway lived up to its name in Fanore Co #Clare today amazing waves but no sunshine #Ireland https:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pskeltonphoto\/status\/762329643282235392\/video\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/BSXSWg85ew",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/762329345415344132\/pu\/img\/ugZu4A5HK9Zfevbm.jpg",
        "id_str" : "762329345415344132",
        "id" : 762329345415344132,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/762329345415344132\/pu\/img\/ugZu4A5HK9Zfevbm.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BSXSWg85ew"
      } ],
      "hashtags" : [ {
        "text" : "Clare",
        "indices" : [ 54, 60 ]
      }, {
        "text" : "Ireland",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762329643282235392",
    "text" : "The Wildatlanticway lived up to its name in Fanore Co #Clare today amazing waves but no sunshine #Ireland https:\/\/t.co\/BSXSWg85ew",
    "id" : 762329643282235392,
    "created_at" : "2016-08-07 16:48:45 +0000",
    "user" : {
      "name" : "Peter Skelton",
      "screen_name" : "pskeltonphoto",
      "protected" : false,
      "id_str" : "349829126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1586962700\/DSCF1618_normal.JPG",
      "id" : 349829126,
      "verified" : false
    }
  },
  "id" : 762389963367444481,
  "created_at" : "2016-08-07 20:48:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "indices" : [ 3, 14 ],
      "id_str" : "2441608651",
      "id" : 2441608651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/761903089683095552\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/downjD4vNk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpLRX2iVYAARS3F.jpg",
      "id_str" : "761901494685753344",
      "id" : 761901494685753344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpLRX2iVYAARS3F.jpg",
      "sizes" : [ {
        "h" : 858,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1465,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1560,
        "resize" : "fit",
        "w" : 2181
      } ],
      "display_url" : "pic.twitter.com\/downjD4vNk"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 40, 46 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762388037296881664",
  "text" : "RT @mido3bitte: 'is there any insects?' #birds #wildlife https:\/\/t.co\/downjD4vNk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/761903089683095552\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/downjD4vNk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpLRX2iVYAARS3F.jpg",
        "id_str" : "761901494685753344",
        "id" : 761901494685753344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpLRX2iVYAARS3F.jpg",
        "sizes" : [ {
          "h" : 858,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1465,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1560,
          "resize" : "fit",
          "w" : 2181
        } ],
        "display_url" : "pic.twitter.com\/downjD4vNk"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 24, 30 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761903089683095552",
    "text" : "'is there any insects?' #birds #wildlife https:\/\/t.co\/downjD4vNk",
    "id" : 761903089683095552,
    "created_at" : "2016-08-06 12:33:46 +0000",
    "user" : {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "protected" : false,
      "id_str" : "2441608651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746727881498206208\/tfRux6Hm_normal.jpg",
      "id" : 2441608651,
      "verified" : false
    }
  },
  "id" : 762388037296881664,
  "created_at" : "2016-08-07 20:40:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Crouch",
      "screen_name" : "ahc",
      "indices" : [ 3, 7 ],
      "id_str" : "3937661",
      "id" : 3937661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762323097907331072",
  "text" : "RT @ahc: Seriously: pay minimal attention to the stupid stuff, and pay maximal attention to the best, and you will be enormously encouraged.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "758392070298038272",
    "geo" : { },
    "id_str" : "758392333373149184",
    "in_reply_to_user_id" : 3937661,
    "text" : "Seriously: pay minimal attention to the stupid stuff, and pay maximal attention to the best, and you will be enormously encouraged.",
    "id" : 758392333373149184,
    "in_reply_to_status_id" : 758392070298038272,
    "created_at" : "2016-07-27 20:03:17 +0000",
    "in_reply_to_screen_name" : "ahc",
    "in_reply_to_user_id_str" : "3937661",
    "user" : {
      "name" : "Andy Crouch",
      "screen_name" : "ahc",
      "protected" : false,
      "id_str" : "3937661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/117704823\/toocoolt_normal.jpg",
      "id" : 3937661,
      "verified" : false
    }
  },
  "id" : 762323097907331072,
  "created_at" : "2016-08-07 16:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/finchapp.info\" rel=\"nofollow\"\u003EFinch App for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762321565363085312",
  "text" : "Possibly bad peanuts had me in the tub all night. #sick",
  "id" : 762321565363085312,
  "created_at" : "2016-08-07 16:16:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bible",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762044906747600896",
  "text" : "RT @AnnotatedBible: Luke 6:32-37 is quite possibly the greatest passage in the entire #Bible.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bible",
        "indices" : [ 66, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762044659661025280",
    "text" : "Luke 6:32-37 is quite possibly the greatest passage in the entire #Bible.",
    "id" : 762044659661025280,
    "created_at" : "2016-08-06 21:56:19 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 762044906747600896,
  "created_at" : "2016-08-06 21:57:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762044493088653313",
  "text" : "RT @AnnotatedBible: How does God hate people according to you, at the same time He loves the world and loves His ENEMIES? (Luke 6:32-37) ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/op8cLZPGWh",
        "expanded_url" : "https:\/\/twitter.com\/tnamyx\/status\/762029958810206208",
        "display_url" : "twitter.com\/tnamyx\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762041031122640897",
    "text" : "How does God hate people according to you, at the same time He loves the world and loves His ENEMIES? (Luke 6:32-37) https:\/\/t.co\/op8cLZPGWh",
    "id" : 762041031122640897,
    "created_at" : "2016-08-06 21:41:54 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 762044493088653313,
  "created_at" : "2016-08-06 21:55:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDWG",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762024354091761664",
  "text" : "RT @CamoDave_: Located both fledged Collared Dove chicks this afternoon in the #CDWG, they were sat near each other in the tree 6\/8 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/761992760257814528\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Nv5gy2b8Ho",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMkB-tWcAAjkHL.jpg",
        "id_str" : "761992378387427328",
        "id" : 761992378387427328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMkB-tWcAAjkHL.jpg",
        "sizes" : [ {
          "h" : 505,
          "resize" : "fit",
          "w" : 668
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 668
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 668
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 668
        } ],
        "display_url" : "pic.twitter.com\/Nv5gy2b8Ho"
      } ],
      "hashtags" : [ {
        "text" : "CDWG",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761992760257814528",
    "text" : "Located both fledged Collared Dove chicks this afternoon in the #CDWG, they were sat near each other in the tree 6\/8 https:\/\/t.co\/Nv5gy2b8Ho",
    "id" : 761992760257814528,
    "created_at" : "2016-08-06 18:30:05 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 762024354091761664,
  "created_at" : "2016-08-06 20:35:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "indices" : [ 3, 19 ],
      "id_str" : "364856414",
      "id" : 364856414
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/761982111825825792\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/blKTeoXqsR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMadf2XYAAGhSm.jpg",
      "id_str" : "761981856023797760",
      "id" : 761981856023797760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMadf2XYAAGhSm.jpg",
      "sizes" : [ {
        "h" : 441,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1328,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2656,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/blKTeoXqsR"
    } ],
    "hashtags" : [ {
      "text" : "Caturday",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "CatsOfTwitter",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762024295958712320",
  "text" : "RT @ThomMoorePhotos: Someone seems unimpressed with the authenticity of her new toy mouse. #Caturday #CatsOfTwitter https:\/\/t.co\/blKTeoXqsR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/761982111825825792\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/blKTeoXqsR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMadf2XYAAGhSm.jpg",
        "id_str" : "761981856023797760",
        "id" : 761981856023797760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMadf2XYAAGhSm.jpg",
        "sizes" : [ {
          "h" : 441,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1328,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2656,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/blKTeoXqsR"
      } ],
      "hashtags" : [ {
        "text" : "Caturday",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "CatsOfTwitter",
        "indices" : [ 80, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761982111825825792",
    "text" : "Someone seems unimpressed with the authenticity of her new toy mouse. #Caturday #CatsOfTwitter https:\/\/t.co\/blKTeoXqsR",
    "id" : 761982111825825792,
    "created_at" : "2016-08-06 17:47:47 +0000",
    "user" : {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "protected" : false,
      "id_str" : "364856414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770204744543563776\/cS24tsF9_normal.jpg",
      "id" : 364856414,
      "verified" : false
    }
  },
  "id" : 762024295958712320,
  "created_at" : "2016-08-06 20:35:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/762021446394712065\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/hsJiBJmsZ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpM-dxdW8AEM0Wn.jpg",
      "id_str" : "762021443169349633",
      "id" : 762021443169349633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpM-dxdW8AEM0Wn.jpg",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/hsJiBJmsZ3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/IMDmKgjLn9",
      "expanded_url" : "http:\/\/nymag.com\/scienceofus\/2016\/08\/a-very-weird-explanation-for-car-sickness.html?_ts=1470515039",
      "display_url" : "nymag.com\/scienceofus\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762021446394712065",
  "text" : "This Is a Very Odd Explanation for Carsickness -- Science of Us https:\/\/t.co\/IMDmKgjLn9 https:\/\/t.co\/hsJiBJmsZ3",
  "id" : 762021446394712065,
  "created_at" : "2016-08-06 20:24:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Khoo",
      "screen_name" : "jonk",
      "indices" : [ 3, 8 ],
      "id_str" : "840581",
      "id" : 840581
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jonk\/status\/761945280472190976\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Lg7A5SdKKu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpL5L88UkAEfl2l.jpg",
      "id_str" : "761945270712045569",
      "id" : 761945270712045569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpL5L88UkAEfl2l.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Lg7A5SdKKu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761965487228063744",
  "text" : "RT @jonk: Wait a minute, what would you have used this for before?! https:\/\/t.co\/Lg7A5SdKKu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonk\/status\/761945280472190976\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Lg7A5SdKKu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpL5L88UkAEfl2l.jpg",
        "id_str" : "761945270712045569",
        "id" : 761945270712045569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpL5L88UkAEfl2l.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/Lg7A5SdKKu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761945280472190976",
    "text" : "Wait a minute, what would you have used this for before?! https:\/\/t.co\/Lg7A5SdKKu",
    "id" : 761945280472190976,
    "created_at" : "2016-08-06 15:21:25 +0000",
    "user" : {
      "name" : "Jonathan Khoo",
      "screen_name" : "jonk",
      "protected" : false,
      "id_str" : "840581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741644254653599744\/5-Cbj4_k_normal.jpg",
      "id" : 840581,
      "verified" : false
    }
  },
  "id" : 761965487228063744,
  "created_at" : "2016-08-06 16:41:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "BrainsLoveVideogames",
      "screen_name" : "SamsaraKush",
      "indices" : [ 118, 130 ],
      "id_str" : "610058444",
      "id" : 610058444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyme",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "ID",
      "indices" : [ 66, 69 ]
    }, {
      "text" : "LymeDisease",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "Science",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/1M2w1b05wV",
      "expanded_url" : "http:\/\/paper.li\/AlisynGayle\/1420049487?edition_id=1123bea0-5bf1-11e6-acd6-0cc47a0d1609",
      "display_url" : "paper.li\/AlisynGayle\/14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761965073065730048",
  "text" : "RT @AlisynGayle: The #Lyme Pulse is out! \nhttps:\/\/t.co\/1M2w1b05wV #ID #LymeDisease #Science &amp; more! w\/features by @SamsaraKush @ColorMeLyme\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BrainsLoveVideogames",
        "screen_name" : "SamsaraKush",
        "indices" : [ 101, 113 ],
        "id_str" : "610058444",
        "id" : 610058444
      }, {
        "name" : "TerryMay_ColorMeLyme",
        "screen_name" : "ColorMeLyme_net",
        "indices" : [ 114, 130 ],
        "id_str" : "34753499",
        "id" : 34753499
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lyme",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "ID",
        "indices" : [ 49, 52 ]
      }, {
        "text" : "LymeDisease",
        "indices" : [ 53, 65 ]
      }, {
        "text" : "Science",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/1M2w1b05wV",
        "expanded_url" : "http:\/\/paper.li\/AlisynGayle\/1420049487?edition_id=1123bea0-5bf1-11e6-acd6-0cc47a0d1609",
        "display_url" : "paper.li\/AlisynGayle\/14\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761959024430575616",
    "text" : "The #Lyme Pulse is out! \nhttps:\/\/t.co\/1M2w1b05wV #ID #LymeDisease #Science &amp; more! w\/features by @SamsaraKush @ColorMeLyme_net",
    "id" : 761959024430575616,
    "created_at" : "2016-08-06 16:16:02 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 761965073065730048,
  "created_at" : "2016-08-06 16:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmy Bengtson",
      "screen_name" : "EmmyA2",
      "indices" : [ 3, 10 ],
      "id_str" : "48807945",
      "id" : 48807945
    }, {
      "name" : "Rob Flaherty",
      "screen_name" : "Rob_Flaherty",
      "indices" : [ 113, 126 ],
      "id_str" : "24613245",
      "id" : 24613245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761964332175519745",
  "text" : "RT @EmmyA2: here's a bear who won't let go of the ranger who saved him from a forest fire, have a great day (h\/t @Rob_Flaherty) https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Flaherty",
        "screen_name" : "Rob_Flaherty",
        "indices" : [ 101, 114 ],
        "id_str" : "24613245",
        "id" : 24613245
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EmmyA2\/status\/761615792391778305\/video\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/z8ftqkEgtU",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761615376446808064\/pu\/img\/JxBVxKqHQb18PlXS.jpg",
        "id_str" : "761615376446808064",
        "id" : 761615376446808064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761615376446808064\/pu\/img\/JxBVxKqHQb18PlXS.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/z8ftqkEgtU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761615792391778305",
    "text" : "here's a bear who won't let go of the ranger who saved him from a forest fire, have a great day (h\/t @Rob_Flaherty) https:\/\/t.co\/z8ftqkEgtU",
    "id" : 761615792391778305,
    "created_at" : "2016-08-05 17:32:09 +0000",
    "user" : {
      "name" : "Emmy Bengtson",
      "screen_name" : "EmmyA2",
      "protected" : false,
      "id_str" : "48807945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775200754600644608\/pRuqyAQL_normal.jpg",
      "id" : 48807945,
      "verified" : false
    }
  },
  "id" : 761964332175519745,
  "created_at" : "2016-08-06 16:37:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "indices" : [ 3, 17 ],
      "id_str" : "751200954",
      "id" : 751200954
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/761901967169978368\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/8fzh4QBsmt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpLRzP3WYAI0F3h.jpg",
      "id_str" : "761901965341253634",
      "id" : 761901965341253634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpLRzP3WYAI0F3h.jpg",
      "sizes" : [ {
        "h" : 507,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8fzh4QBsmt"
    } ],
    "hashtags" : [ {
      "text" : "teamdairy",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "feedafarmer",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761964208124755968",
  "text" : "RT @fionagraham13: Chocolate and caramel cake to keep the wheels turning #teamdairy #feedafarmer https:\/\/t.co\/8fzh4QBsmt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/761901967169978368\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/8fzh4QBsmt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpLRzP3WYAI0F3h.jpg",
        "id_str" : "761901965341253634",
        "id" : 761901965341253634,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpLRzP3WYAI0F3h.jpg",
        "sizes" : [ {
          "h" : 507,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8fzh4QBsmt"
      } ],
      "hashtags" : [ {
        "text" : "teamdairy",
        "indices" : [ 54, 64 ]
      }, {
        "text" : "feedafarmer",
        "indices" : [ 65, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761901967169978368",
    "text" : "Chocolate and caramel cake to keep the wheels turning #teamdairy #feedafarmer https:\/\/t.co\/8fzh4QBsmt",
    "id" : 761901967169978368,
    "created_at" : "2016-08-06 12:29:19 +0000",
    "user" : {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "protected" : false,
      "id_str" : "751200954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775421774179819520\/KBk03QHm_normal.jpg",
      "id" : 751200954,
      "verified" : false
    }
  },
  "id" : 761964208124755968,
  "created_at" : "2016-08-06 16:36:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colossal",
      "screen_name" : "Colossal",
      "indices" : [ 3, 12 ],
      "id_str" : "203063180",
      "id" : 203063180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/kzjBiB42QP",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2016\/08\/wooden-puzzle-book",
      "display_url" : "thisiscolossal.com\/2016\/08\/wooden\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761724849660235776",
  "text" : "RT @Colossal: This Amazing Wooden Book Is a Series of Puzzles That Have to Be Solved to Continue Reading https:\/\/t.co\/kzjBiB42QP https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Colossal\/status\/761657952755257344\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/uAZsdNAPfZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHzm_tWcAEF4lN.jpg",
        "id_str" : "761657663264550913",
        "id" : 761657663264550913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHzm_tWcAEF4lN.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/uAZsdNAPfZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Colossal\/status\/761657952755257344\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/uAZsdNAPfZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHzr3TWAAACzut.jpg",
        "id_str" : "761657746907332608",
        "id" : 761657746907332608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHzr3TWAAACzut.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/uAZsdNAPfZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Colossal\/status\/761657952755257344\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/uAZsdNAPfZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHzs3JWEAA9eny.jpg",
        "id_str" : "761657764045262848",
        "id" : 761657764045262848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHzs3JWEAA9eny.jpg",
        "sizes" : [ {
          "h" : 617,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/uAZsdNAPfZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Colossal\/status\/761657952755257344\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/uAZsdNAPfZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHzt57WcAAY3sZ.jpg",
        "id_str" : "761657781971742720",
        "id" : 761657781971742720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHzt57WcAAY3sZ.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 890
        } ],
        "display_url" : "pic.twitter.com\/uAZsdNAPfZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/kzjBiB42QP",
        "expanded_url" : "http:\/\/www.thisiscolossal.com\/2016\/08\/wooden-puzzle-book",
        "display_url" : "thisiscolossal.com\/2016\/08\/wooden\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761657952755257344",
    "text" : "This Amazing Wooden Book Is a Series of Puzzles That Have to Be Solved to Continue Reading https:\/\/t.co\/kzjBiB42QP https:\/\/t.co\/uAZsdNAPfZ",
    "id" : 761657952755257344,
    "created_at" : "2016-08-05 20:19:41 +0000",
    "user" : {
      "name" : "Colossal",
      "screen_name" : "Colossal",
      "protected" : false,
      "id_str" : "203063180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659542971306545152\/cNdbVSnJ_normal.jpg",
      "id" : 203063180,
      "verified" : false
    }
  },
  "id" : 761724849660235776,
  "created_at" : "2016-08-06 00:45:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761720601681747968",
  "geo" : { },
  "id_str" : "761723530757242884",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves nice one, Dwayne! I can smell the wet road, wet grass.",
  "id" : 761723530757242884,
  "in_reply_to_status_id" : 761720601681747968,
  "created_at" : "2016-08-06 00:40:16 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/761720601681747968\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/7rwLd7tqYv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpIs2M_XYAIKhPG.jpg",
      "id_str" : "761720596690591746",
      "id" : 761720596690591746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpIs2M_XYAIKhPG.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/7rwLd7tqYv"
    } ],
    "hashtags" : [ {
      "text" : "weather",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "ncwx",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761723158198153216",
  "text" : "RT @dwaynereaves: After the Rain! Taken this evening in Person County. #weather #ncwx https:\/\/t.co\/7rwLd7tqYv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/761720601681747968\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/7rwLd7tqYv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpIs2M_XYAIKhPG.jpg",
        "id_str" : "761720596690591746",
        "id" : 761720596690591746,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpIs2M_XYAIKhPG.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/7rwLd7tqYv"
      } ],
      "hashtags" : [ {
        "text" : "weather",
        "indices" : [ 53, 61 ]
      }, {
        "text" : "ncwx",
        "indices" : [ 62, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761720601681747968",
    "text" : "After the Rain! Taken this evening in Person County. #weather #ncwx https:\/\/t.co\/7rwLd7tqYv",
    "id" : 761720601681747968,
    "created_at" : "2016-08-06 00:28:38 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 761723158198153216,
  "created_at" : "2016-08-06 00:38:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761693917469442048",
  "geo" : { },
  "id_str" : "761722645293494272",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms LOLOL",
  "id" : 761722645293494272,
  "in_reply_to_status_id" : 761693917469442048,
  "created_at" : "2016-08-06 00:36:45 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761637953919672320",
  "geo" : { },
  "id_str" : "761638741647720448",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe maybe a bug scared her?",
  "id" : 761638741647720448,
  "in_reply_to_status_id" : 761637953919672320,
  "created_at" : "2016-08-05 19:03:21 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Viswanadham D",
      "screen_name" : "visu_bio",
      "indices" : [ 3, 12 ],
      "id_str" : "72235489",
      "id" : 72235489
    }, {
      "name" : "Melinda Gates",
      "screen_name" : "melindagates",
      "indices" : [ 64, 77 ],
      "id_str" : "161801527",
      "id" : 161801527
    }, {
      "name" : "Madhu Pai",
      "screen_name" : "paimadhu",
      "indices" : [ 101, 110 ],
      "id_str" : "3419251203",
      "id" : 3419251203
    }, {
      "name" : "anil gupta",
      "screen_name" : "anilgb",
      "indices" : [ 111, 118 ],
      "id_str" : "45914458",
      "id" : 45914458
    }, {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 123, 130 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BMGF",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "Grandchallenge",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761575943064416256",
  "text" : "RT @visu_bio: Why The World Needs An Essential Diagnostics List @melindagates #BMGF #Grandchallenge  @paimadhu @anilgb via @forbes https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melinda Gates",
        "screen_name" : "melindagates",
        "indices" : [ 50, 63 ],
        "id_str" : "161801527",
        "id" : 161801527
      }, {
        "name" : "Madhu Pai",
        "screen_name" : "paimadhu",
        "indices" : [ 87, 96 ],
        "id_str" : "3419251203",
        "id" : 3419251203
      }, {
        "name" : "anil gupta",
        "screen_name" : "anilgb",
        "indices" : [ 97, 104 ],
        "id_str" : "45914458",
        "id" : 45914458
      }, {
        "name" : "Forbes",
        "screen_name" : "Forbes",
        "indices" : [ 109, 116 ],
        "id_str" : "91478624",
        "id" : 91478624
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BMGF",
        "indices" : [ 64, 69 ]
      }, {
        "text" : "Grandchallenge",
        "indices" : [ 70, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/L9xlbxUJB1",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/sciencebiz\/2016\/08\/04\/why-the-world-needs-an-essential-diagnostics-list\/#162ffc7479cd",
        "display_url" : "forbes.com\/sites\/scienceb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761322532771340289",
    "text" : "Why The World Needs An Essential Diagnostics List @melindagates #BMGF #Grandchallenge  @paimadhu @anilgb via @forbes https:\/\/t.co\/L9xlbxUJB1",
    "id" : 761322532771340289,
    "created_at" : "2016-08-04 22:06:51 +0000",
    "user" : {
      "name" : "Dr Viswanadham D",
      "screen_name" : "visu_bio",
      "protected" : false,
      "id_str" : "72235489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689239154404773888\/wHw87k4o_normal.jpg",
      "id" : 72235489,
      "verified" : false
    }
  },
  "id" : 761575943064416256,
  "created_at" : "2016-08-05 14:53:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Charmantides\/status\/761524525481721856\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/CsIgaiWNKf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpF6gx9WEAA7NXZ.jpg",
      "id_str" : "761524515587362816",
      "id" : 761524515587362816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpF6gx9WEAA7NXZ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/CsIgaiWNKf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761575172428161025",
  "text" : "RT @Charmantides: Art https:\/\/t.co\/CsIgaiWNKf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Charmantides\/status\/761524525481721856\/photo\/1",
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/CsIgaiWNKf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpF6gx9WEAA7NXZ.jpg",
        "id_str" : "761524515587362816",
        "id" : 761524515587362816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpF6gx9WEAA7NXZ.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/CsIgaiWNKf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761524525481721856",
    "text" : "Art https:\/\/t.co\/CsIgaiWNKf",
    "id" : 761524525481721856,
    "created_at" : "2016-08-05 11:29:29 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 761575172428161025,
  "created_at" : "2016-08-05 14:50:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761551156640448512",
  "geo" : { },
  "id_str" : "761574640930152448",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe NOOOOOOOO...!!",
  "id" : 761574640930152448,
  "in_reply_to_status_id" : 761551156640448512,
  "created_at" : "2016-08-05 14:48:38 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farms Of The World",
      "screen_name" : "FarmsOfTheWorld",
      "indices" : [ 3, 19 ],
      "id_str" : "4474023375",
      "id" : 4474023375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761574475238346752",
  "text" : "RT @FarmsOfTheWorld: Good mornin! Alwayw trying to surprise them in the fog, but they find me moving the fence every time https:\/\/t.co\/Qhfg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmsOfTheWorld\/status\/761403341792481282\/video\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/Qhfgs2g7jh",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761402054191484930\/pu\/img\/2vMurHJ-fWK5JwtI.jpg",
        "id_str" : "761402054191484930",
        "id" : 761402054191484930,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761402054191484930\/pu\/img\/2vMurHJ-fWK5JwtI.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Qhfgs2g7jh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761403341792481282",
    "text" : "Good mornin! Alwayw trying to surprise them in the fog, but they find me moving the fence every time https:\/\/t.co\/Qhfgs2g7jh",
    "id" : 761403341792481282,
    "created_at" : "2016-08-05 03:27:57 +0000",
    "user" : {
      "name" : "Farms Of The World",
      "screen_name" : "FarmsOfTheWorld",
      "protected" : false,
      "id_str" : "4474023375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798075678981816320\/QZeENBzh_normal.jpg",
      "id" : 4474023375,
      "verified" : false
    }
  },
  "id" : 761574475238346752,
  "created_at" : "2016-08-05 14:47:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "indices" : [ 3, 17 ],
      "id_str" : "751200954",
      "id" : 751200954
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/761400026635571200\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/qvgPPvK7cz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpEJSYuWAAA-BbT.jpg",
      "id_str" : "761400023481450496",
      "id" : 761400023481450496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpEJSYuWAAA-BbT.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 3114,
        "resize" : "fit",
        "w" : 3114
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qvgPPvK7cz"
    } ],
    "hashtags" : [ {
      "text" : "teamdairy",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "clubhectare",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761574311366889472",
  "text" : "RT @fionagraham13: Good morning all #teamdairy #clubhectare \nHope the day is kind to you! https:\/\/t.co\/qvgPPvK7cz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/761400026635571200\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/qvgPPvK7cz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpEJSYuWAAA-BbT.jpg",
        "id_str" : "761400023481450496",
        "id" : 761400023481450496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpEJSYuWAAA-BbT.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 3114,
          "resize" : "fit",
          "w" : 3114
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/qvgPPvK7cz"
      } ],
      "hashtags" : [ {
        "text" : "teamdairy",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "clubhectare",
        "indices" : [ 28, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761400026635571200",
    "text" : "Good morning all #teamdairy #clubhectare \nHope the day is kind to you! https:\/\/t.co\/qvgPPvK7cz",
    "id" : 761400026635571200,
    "created_at" : "2016-08-05 03:14:47 +0000",
    "user" : {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "protected" : false,
      "id_str" : "751200954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775421774179819520\/KBk03QHm_normal.jpg",
      "id" : 751200954,
      "verified" : false
    }
  },
  "id" : 761574311366889472,
  "created_at" : "2016-08-05 14:47:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/761549885342683136\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/9XtgtTYPLo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpGRjF3WcAAM2vR.jpg",
      "id_str" : "761549844058107904",
      "id" : 761549844058107904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpGRjF3WcAAM2vR.jpg",
      "sizes" : [ {
        "h" : 524,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1578,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1578,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 925,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/9XtgtTYPLo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761573553816862720",
  "text" : "RT @ZwartblesIE: Aaaaaa gwan give us a scratch on the head https:\/\/t.co\/9XtgtTYPLo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/761549885342683136\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/9XtgtTYPLo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpGRjF3WcAAM2vR.jpg",
        "id_str" : "761549844058107904",
        "id" : 761549844058107904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpGRjF3WcAAM2vR.jpg",
        "sizes" : [ {
          "h" : 524,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1578,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1578,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 925,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/9XtgtTYPLo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761549885342683136",
    "text" : "Aaaaaa gwan give us a scratch on the head https:\/\/t.co\/9XtgtTYPLo",
    "id" : 761549885342683136,
    "created_at" : "2016-08-05 13:10:16 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 761573553816862720,
  "created_at" : "2016-08-05 14:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maddy 'MIDI' Myers",
      "screen_name" : "MIDImyers",
      "indices" : [ 3, 13 ],
      "id_str" : "185609783",
      "id" : 185609783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761362628774092800",
  "text" : "RT @MIDImyers: the police can get facebook to shut down ur account if they want. like, say, if u post video of police altercations. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9RzQVjGpUH",
        "expanded_url" : "http:\/\/www.themarysue.com\/facebook-police-overreach\/",
        "display_url" : "themarysue.com\/facebook-polic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761274982370516992",
    "text" : "the police can get facebook to shut down ur account if they want. like, say, if u post video of police altercations. https:\/\/t.co\/9RzQVjGpUH",
    "id" : 761274982370516992,
    "created_at" : "2016-08-04 18:57:54 +0000",
    "user" : {
      "name" : "Maddy 'MIDI' Myers",
      "screen_name" : "MIDImyers",
      "protected" : false,
      "id_str" : "185609783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792187825026375681\/C3SqWWfT_normal.jpg",
      "id" : 185609783,
      "verified" : false
    }
  },
  "id" : 761362628774092800,
  "created_at" : "2016-08-05 00:46:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/761004607015231490\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/GbamrCnbkK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co-hm6EWYAAsAuw.jpg",
      "id_str" : "761004551843504128",
      "id" : 761004551843504128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co-hm6EWYAAsAuw.jpg",
      "sizes" : [ {
        "h" : 696,
        "resize" : "fit",
        "w" : 928
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 928
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 928
      } ],
      "display_url" : "pic.twitter.com\/GbamrCnbkK"
    } ],
    "hashtags" : [ {
      "text" : "FireIsland",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761307379812229125",
  "text" : "RT @CatskillCritter: Sunset this evening over the Great South Bay, splendors of #FireIsland . . . https:\/\/t.co\/GbamrCnbkK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/761004607015231490\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/GbamrCnbkK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co-hm6EWYAAsAuw.jpg",
        "id_str" : "761004551843504128",
        "id" : 761004551843504128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co-hm6EWYAAsAuw.jpg",
        "sizes" : [ {
          "h" : 696,
          "resize" : "fit",
          "w" : 928
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 928
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 928
        } ],
        "display_url" : "pic.twitter.com\/GbamrCnbkK"
      } ],
      "hashtags" : [ {
        "text" : "FireIsland",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761004607015231490",
    "text" : "Sunset this evening over the Great South Bay, splendors of #FireIsland . . . https:\/\/t.co\/GbamrCnbkK",
    "id" : 761004607015231490,
    "created_at" : "2016-08-04 01:03:31 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 761307379812229125,
  "created_at" : "2016-08-04 21:06:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "indices" : [ 3, 14 ],
      "id_str" : "2815401127",
      "id" : 2815401127
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 22, 34 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Adrian Clark",
      "screen_name" : "adrianjcl123",
      "indices" : [ 35, 48 ],
      "id_str" : "1038309122",
      "id" : 1038309122
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 49, 61 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "The Milk Story",
      "screen_name" : "KoeOpAvontuur",
      "indices" : [ 62, 76 ],
      "id_str" : "391567080",
      "id" : 391567080
    }, {
      "name" : "Sony UK",
      "screen_name" : "SonyUK",
      "indices" : [ 77, 84 ],
      "id_str" : "17804411",
      "id" : 17804411
    }, {
      "name" : "Sony Nederland",
      "screen_name" : "SonyNederland",
      "indices" : [ 85, 99 ],
      "id_str" : "19760341",
      "id" : 19760341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/761258715882352640\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ZonLnn0Jcm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCIpTfWcAAwFdB.jpg",
      "id_str" : "761258580213395456",
      "id" : 761258580213395456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCIpTfWcAAwFdB.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1020
      } ],
      "display_url" : "pic.twitter.com\/ZonLnn0Jcm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761273748259561472",
  "text" : "RT @gertvanden: Tasty @newlandfarm @adrianjcl123 @ErinEFarley @KoeOpAvontuur @SonyUK @SonyNederland https:\/\/t.co\/ZonLnn0Jcm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newland Farm",
        "screen_name" : "newlandfarm",
        "indices" : [ 6, 18 ],
        "id_str" : "2259182801",
        "id" : 2259182801
      }, {
        "name" : "Adrian Clark",
        "screen_name" : "adrianjcl123",
        "indices" : [ 19, 32 ],
        "id_str" : "1038309122",
        "id" : 1038309122
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 33, 45 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      }, {
        "name" : "The Milk Story",
        "screen_name" : "KoeOpAvontuur",
        "indices" : [ 46, 60 ],
        "id_str" : "391567080",
        "id" : 391567080
      }, {
        "name" : "Sony UK",
        "screen_name" : "SonyUK",
        "indices" : [ 61, 68 ],
        "id_str" : "17804411",
        "id" : 17804411
      }, {
        "name" : "Sony Nederland",
        "screen_name" : "SonyNederland",
        "indices" : [ 69, 83 ],
        "id_str" : "19760341",
        "id" : 19760341
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/761258715882352640\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/ZonLnn0Jcm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCIpTfWcAAwFdB.jpg",
        "id_str" : "761258580213395456",
        "id" : 761258580213395456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCIpTfWcAAwFdB.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/ZonLnn0Jcm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761258715882352640",
    "text" : "Tasty @newlandfarm @adrianjcl123 @ErinEFarley @KoeOpAvontuur @SonyUK @SonyNederland https:\/\/t.co\/ZonLnn0Jcm",
    "id" : 761258715882352640,
    "created_at" : "2016-08-04 17:53:16 +0000",
    "user" : {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "protected" : false,
      "id_str" : "2815401127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635003322211147776\/tdmuR7zK_normal.jpg",
      "id" : 2815401127,
      "verified" : false
    }
  },
  "id" : 761273748259561472,
  "created_at" : "2016-08-04 18:53:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KatrinEagle",
      "screen_name" : "katrineagle",
      "indices" : [ 3, 15 ],
      "id_str" : "2453633443",
      "id" : 2453633443
    }, {
      "name" : "British Wool",
      "screen_name" : "BritishWool",
      "indices" : [ 17, 29 ],
      "id_str" : "431509598",
      "id" : 431509598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/clMccHhsrl",
      "expanded_url" : "http:\/\/www.katrineagle.com",
      "display_url" : "katrineagle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "761244005724200961",
  "text" : "RT @katrineagle: @BritishWool do you like my British breeds coasters? Just launched at special intro price on https:\/\/t.co\/clMccHhsrl https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "British Wool",
        "screen_name" : "BritishWool",
        "indices" : [ 0, 12 ],
        "id_str" : "431509598",
        "id" : 431509598
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/katrineagle\/status\/760813350481788928\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7HVEwg6gey",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co7zn76WYAAjArC.jpg",
        "id_str" : "760813254495068160",
        "id" : 760813254495068160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co7zn76WYAAjArC.jpg",
        "sizes" : [ {
          "h" : 1521,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 891,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2424,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/7HVEwg6gey"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/clMccHhsrl",
        "expanded_url" : "http:\/\/www.katrineagle.com",
        "display_url" : "katrineagle.com"
      } ]
    },
    "geo" : { },
    "id_str" : "760813350481788928",
    "in_reply_to_user_id" : 431509598,
    "text" : "@BritishWool do you like my British breeds coasters? Just launched at special intro price on https:\/\/t.co\/clMccHhsrl https:\/\/t.co\/7HVEwg6gey",
    "id" : 760813350481788928,
    "created_at" : "2016-08-03 12:23:32 +0000",
    "in_reply_to_screen_name" : "BritishWool",
    "in_reply_to_user_id_str" : "431509598",
    "user" : {
      "name" : "KatrinEagle",
      "screen_name" : "katrineagle",
      "protected" : false,
      "id_str" : "2453633443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588097553293541376\/EF65okjN_normal.png",
      "id" : 2453633443,
      "verified" : false
    }
  },
  "id" : 761244005724200961,
  "created_at" : "2016-08-04 16:54:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cornship Enterprise",
      "screen_name" : "KemmerenPete",
      "indices" : [ 3, 16 ],
      "id_str" : "2743996235",
      "id" : 2743996235
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KemmerenPete\/status\/761177100376158208\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/hZBzAgPLaw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpA-e3qUMAAhwKj.jpg",
      "id_str" : "761177037084045312",
      "id" : 761177037084045312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpA-e3qUMAAhwKj.jpg",
      "sizes" : [ {
        "h" : 968,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1160,
        "resize" : "fit",
        "w" : 1438
      }, {
        "h" : 549,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1160,
        "resize" : "fit",
        "w" : 1438
      } ],
      "display_url" : "pic.twitter.com\/hZBzAgPLaw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761237450375168000",
  "text" : "RT @KemmerenPete: I told her a joke, she thought it was funny. https:\/\/t.co\/hZBzAgPLaw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KemmerenPete\/status\/761177100376158208\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/hZBzAgPLaw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpA-e3qUMAAhwKj.jpg",
        "id_str" : "761177037084045312",
        "id" : 761177037084045312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpA-e3qUMAAhwKj.jpg",
        "sizes" : [ {
          "h" : 968,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1160,
          "resize" : "fit",
          "w" : 1438
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1160,
          "resize" : "fit",
          "w" : 1438
        } ],
        "display_url" : "pic.twitter.com\/hZBzAgPLaw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761177100376158208",
    "text" : "I told her a joke, she thought it was funny. https:\/\/t.co\/hZBzAgPLaw",
    "id" : 761177100376158208,
    "created_at" : "2016-08-04 12:28:57 +0000",
    "user" : {
      "name" : "Cornship Enterprise",
      "screen_name" : "KemmerenPete",
      "protected" : false,
      "id_str" : "2743996235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792766342936027136\/hvnCekw5_normal.jpg",
      "id" : 2743996235,
      "verified" : false
    }
  },
  "id" : 761237450375168000,
  "created_at" : "2016-08-04 16:28:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/IYQWWHh3KU",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/761217134332608513",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761227644738371584",
  "text" : "LOL.. yes, visit Dwayne's page for great nature pics to soothe your soul. : ) officially endorsed by me! https:\/\/t.co\/IYQWWHh3KU",
  "id" : 761227644738371584,
  "created_at" : "2016-08-04 15:49:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761209734586249216",
  "text" : "RT @AnnotatedBible: But if you're using Leviticus, Leviticus condemns eating pork and lobster as an abomination also. https:\/\/t.co\/p03vqKSs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/p03vqKSsFX",
        "expanded_url" : "https:\/\/twitter.com\/franklin_graham\/status\/760913155320983553",
        "display_url" : "twitter.com\/franklin_graha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761193716727951360",
    "text" : "But if you're using Leviticus, Leviticus condemns eating pork and lobster as an abomination also. https:\/\/t.co\/p03vqKSsFX",
    "id" : 761193716727951360,
    "created_at" : "2016-08-04 13:34:59 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 761209734586249216,
  "created_at" : "2016-08-04 14:38:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761209071102025729",
  "text" : "RT @ZachsMind: If we dismiss disparate views as \"evil\" and don't try to understand opposing povs, we will continue to make the same past mi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761196682784550913",
    "text" : "If we dismiss disparate views as \"evil\" and don't try to understand opposing povs, we will continue to make the same past mistakes.",
    "id" : 761196682784550913,
    "created_at" : "2016-08-04 13:46:46 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 761209071102025729,
  "created_at" : "2016-08-04 14:35:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.producthunt.com\" rel=\"nofollow\"\u003EProduct Hunt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Molyneux",
      "screen_name" : "PeterMollynew",
      "indices" : [ 85, 99 ],
      "id_str" : "2437455690",
      "id" : 2437455690
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/761200987004600321\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/416veRmAyk",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpBUQ1GWIAAhi1A.jpg",
      "id_str" : "761200985133948928",
      "id" : 761200985133948928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpBUQ1GWIAAhi1A.jpg",
      "sizes" : [ {
        "h" : 80,
        "resize" : "fit",
        "w" : 80
      }, {
        "h" : 80,
        "resize" : "fit",
        "w" : 80
      }, {
        "h" : 80,
        "resize" : "crop",
        "w" : 80
      }, {
        "h" : 80,
        "resize" : "fit",
        "w" : 80
      }, {
        "h" : 80,
        "resize" : "fit",
        "w" : 80
      } ],
      "display_url" : "pic.twitter.com\/416veRmAyk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/EOkjpXWWHc",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/oneview-calendar-2",
      "display_url" : "producthunt.com\/tech\/oneview-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761200987004600321",
  "text" : "OneView Calendar: The clearest calendar app in the world https:\/\/t.co\/EOkjpXWWHc via @petermollynew https:\/\/t.co\/416veRmAyk",
  "id" : 761200987004600321,
  "created_at" : "2016-08-04 14:03:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "indices" : [ 3, 14 ],
      "id_str" : "1922414958",
      "id" : 1922414958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChronicIllness",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/g5jFl0qdBX",
      "expanded_url" : "http:\/\/the-life-of-an-insomniac.blogspot.com\/2016\/08\/im-falling-to-pieces.html",
      "display_url" : "the-life-of-an-insomniac.blogspot.com\/2016\/08\/im-fal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761007325670932480",
  "text" : "RT @LonnieRhea: Grieving for your past is part of living with a #ChronicIllness. My daughter shares her feelings: https:\/\/t.co\/g5jFl0qdBX #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChronicIllness",
        "indices" : [ 48, 63 ]
      }, {
        "text" : "Breakeven",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/g5jFl0qdBX",
        "expanded_url" : "http:\/\/the-life-of-an-insomniac.blogspot.com\/2016\/08\/im-falling-to-pieces.html",
        "display_url" : "the-life-of-an-insomniac.blogspot.com\/2016\/08\/im-fal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760526527746351105",
    "text" : "Grieving for your past is part of living with a #ChronicIllness. My daughter shares her feelings: https:\/\/t.co\/g5jFl0qdBX #Breakeven",
    "id" : 760526527746351105,
    "created_at" : "2016-08-02 17:23:48 +0000",
    "user" : {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "protected" : false,
      "id_str" : "1922414958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738411243678007297\/OesFzoaA_normal.jpg",
      "id" : 1922414958,
      "verified" : false
    }
  },
  "id" : 761007325670932480,
  "created_at" : "2016-08-04 01:14:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ceelle Ann",
      "screen_name" : "ceelle1",
      "indices" : [ 3, 11 ],
      "id_str" : "162514206",
      "id" : 162514206
    }, {
      "name" : "(((sfpelosi)))",
      "screen_name" : "sfpelosi",
      "indices" : [ 13, 22 ],
      "id_str" : "15446551",
      "id" : 15446551
    }, {
      "name" : "SFGate",
      "screen_name" : "SFGate",
      "indices" : [ 23, 30 ],
      "id_str" : "36511031",
      "id" : 36511031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760988770728550400",
  "text" : "RT @ceelle1: @sfpelosi @SFGate What? Meaning get over racism? Ignore it?  Accept it?  No, Eastwood.  Just no.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((sfpelosi)))",
        "screen_name" : "sfpelosi",
        "indices" : [ 0, 9 ],
        "id_str" : "15446551",
        "id" : 15446551
      }, {
        "name" : "SFGate",
        "screen_name" : "SFGate",
        "indices" : [ 10, 17 ],
        "id_str" : "36511031",
        "id" : 36511031
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760974708405698561",
    "geo" : { },
    "id_str" : "760975655928377345",
    "in_reply_to_user_id" : 15446551,
    "text" : "@sfpelosi @SFGate What? Meaning get over racism? Ignore it?  Accept it?  No, Eastwood.  Just no.",
    "id" : 760975655928377345,
    "in_reply_to_status_id" : 760974708405698561,
    "created_at" : "2016-08-03 23:08:29 +0000",
    "in_reply_to_screen_name" : "sfpelosi",
    "in_reply_to_user_id_str" : "15446551",
    "user" : {
      "name" : "Ceelle Ann",
      "screen_name" : "ceelle1",
      "protected" : false,
      "id_str" : "162514206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797453244695838721\/XuanKSXS_normal.jpg",
      "id" : 162514206,
      "verified" : false
    }
  },
  "id" : 760988770728550400,
  "created_at" : "2016-08-04 00:00:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/IZ1XkHloju",
      "expanded_url" : "https:\/\/twitter.com\/sagetastik\/status\/760954897000984576",
      "display_url" : "twitter.com\/sagetastik\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760988498837012480",
  "text" : "WTH? https:\/\/t.co\/IZ1XkHloju",
  "id" : 760988498837012480,
  "created_at" : "2016-08-03 23:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradd Jaffy",
      "screen_name" : "BraddJaffy",
      "indices" : [ 3, 14 ],
      "id_str" : "299802277",
      "id" : 299802277
    }, {
      "name" : "John Noonan",
      "screen_name" : "noonanjo",
      "indices" : [ 79, 88 ],
      "id_str" : "61122731",
      "id" : 61122731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760963922371510272",
  "text" : "RT @BraddJaffy: Read this Tweetstorm from Jeb Bush's national security adviser @noonanjo on Trump\/nukes \n(h\/t everyone) https:\/\/t.co\/Fr6qVA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Noonan",
        "screen_name" : "noonanjo",
        "indices" : [ 63, 72 ],
        "id_str" : "61122731",
        "id" : 61122731
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BraddJaffy\/status\/760882567490904064\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/Fr6qVA46wW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8yozLVUAQ5EPA.jpg",
        "id_str" : "760882538562801668",
        "id" : 760882538562801668,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8yozLVUAQ5EPA.jpg",
        "sizes" : [ {
          "h" : 689,
          "resize" : "fit",
          "w" : 1075
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 1075
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 1075
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Fr6qVA46wW"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BraddJaffy\/status\/760882567490904064\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/Fr6qVA46wW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8yoxyUkAA_Ahg.jpg",
        "id_str" : "760882538189459456",
        "id" : 760882538189459456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8yoxyUkAA_Ahg.jpg",
        "sizes" : [ {
          "h" : 657,
          "resize" : "fit",
          "w" : 1071
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 657,
          "resize" : "fit",
          "w" : 1071
        }, {
          "h" : 657,
          "resize" : "fit",
          "w" : 1071
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Fr6qVA46wW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760882567490904064",
    "text" : "Read this Tweetstorm from Jeb Bush's national security adviser @noonanjo on Trump\/nukes \n(h\/t everyone) https:\/\/t.co\/Fr6qVA46wW",
    "id" : 760882567490904064,
    "created_at" : "2016-08-03 16:58:35 +0000",
    "user" : {
      "name" : "Bradd Jaffy",
      "screen_name" : "BraddJaffy",
      "protected" : false,
      "id_str" : "299802277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742877908860035072\/zo99SwhU_normal.jpg",
      "id" : 299802277,
      "verified" : true
    }
  },
  "id" : 760963922371510272,
  "created_at" : "2016-08-03 22:21:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Common Girl \uD83D\uDC85\uD83C\uDFFB",
      "screen_name" : "FIirtationship",
      "indices" : [ 3, 18 ],
      "id_str" : "416983726",
      "id" : 416983726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/MZrrAUr9h7",
      "expanded_url" : "https:\/\/twitter.com\/COLDGAMEKELV\/status\/760488963308003328\/video\/1",
      "display_url" : "twitter.com\/COLDGAMEKELV\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760924071714496512",
  "text" : "RT @FIirtationship: this video is the best thing I've seen today https:\/\/t.co\/MZrrAUr9h7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/MZrrAUr9h7",
        "expanded_url" : "https:\/\/twitter.com\/COLDGAMEKELV\/status\/760488963308003328\/video\/1",
        "display_url" : "twitter.com\/COLDGAMEKELV\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760630531687976961",
    "text" : "this video is the best thing I've seen today https:\/\/t.co\/MZrrAUr9h7",
    "id" : 760630531687976961,
    "created_at" : "2016-08-03 00:17:05 +0000",
    "user" : {
      "name" : "Common Girl \uD83D\uDC85\uD83C\uDFFB",
      "screen_name" : "FIirtationship",
      "protected" : false,
      "id_str" : "416983726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778614179460624384\/NazpGVBR_normal.jpg",
      "id" : 416983726,
      "verified" : false
    }
  },
  "id" : 760924071714496512,
  "created_at" : "2016-08-03 19:43:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "indices" : [ 3, 12 ],
      "id_str" : "12642282",
      "id" : 12642282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760903565477019649",
  "text" : "RT @dasparky: Question: if a U.S. Presidential candidate decided to step down, would his\/her VP running mate take the spot &amp; run for prez?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760900346105372672",
    "text" : "Question: if a U.S. Presidential candidate decided to step down, would his\/her VP running mate take the spot &amp; run for prez? Or what else?",
    "id" : 760900346105372672,
    "created_at" : "2016-08-03 18:09:14 +0000",
    "user" : {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "protected" : false,
      "id_str" : "12642282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650055629004902400\/VG1lD7ep_normal.png",
      "id" : 12642282,
      "verified" : false
    }
  },
  "id" : 760903565477019649,
  "created_at" : "2016-08-03 18:22:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Som Wildlife Trust",
      "screen_name" : "SomersetWT",
      "indices" : [ 89, 100 ],
      "id_str" : "168624201",
      "id" : 168624201
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 101, 113 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/760837967929806849\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/y9VMLrBcXM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8J_h4WgAAdJPz.jpg",
      "id_str" : "760837849080037376",
      "id" : 760837849080037376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8J_h4WgAAdJPz.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y9VMLrBcXM"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/760837967929806849\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/y9VMLrBcXM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8J_iCXEAEB2t-.jpg",
      "id_str" : "760837849122017281",
      "id" : 760837849122017281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8J_iCXEAEB2t-.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/y9VMLrBcXM"
    } ],
    "hashtags" : [ {
      "text" : "KnitForNature",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760841905479397376",
  "text" : "RT @newlandfarm: Sorry it took so long, finally dropped off the #KnitForNature Hedgepigs @SomersetWT @ErinEFarley https:\/\/t.co\/y9VMLrBcXM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Som Wildlife Trust",
        "screen_name" : "SomersetWT",
        "indices" : [ 72, 83 ],
        "id_str" : "168624201",
        "id" : 168624201
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 84, 96 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/760837967929806849\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/y9VMLrBcXM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8J_h4WgAAdJPz.jpg",
        "id_str" : "760837849080037376",
        "id" : 760837849080037376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8J_h4WgAAdJPz.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/y9VMLrBcXM"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/760837967929806849\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/y9VMLrBcXM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8J_iCXEAEB2t-.jpg",
        "id_str" : "760837849122017281",
        "id" : 760837849122017281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8J_iCXEAEB2t-.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/y9VMLrBcXM"
      } ],
      "hashtags" : [ {
        "text" : "KnitForNature",
        "indices" : [ 47, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760837967929806849",
    "text" : "Sorry it took so long, finally dropped off the #KnitForNature Hedgepigs @SomersetWT @ErinEFarley https:\/\/t.co\/y9VMLrBcXM",
    "id" : 760837967929806849,
    "created_at" : "2016-08-03 14:01:21 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 760841905479397376,
  "created_at" : "2016-08-03 14:17:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony\u2122",
      "screen_name" : "tsm560",
      "indices" : [ 3, 10 ],
      "id_str" : "19950847",
      "id" : 19950847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760841526037536771",
  "text" : "RT @tsm560: I try to focus only on the good but I get distracted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760830178012475392",
    "text" : "I try to focus only on the good but I get distracted.",
    "id" : 760830178012475392,
    "created_at" : "2016-08-03 13:30:24 +0000",
    "user" : {
      "name" : "Tony\u2122",
      "screen_name" : "tsm560",
      "protected" : false,
      "id_str" : "19950847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763481446589739008\/wwgRUMr0_normal.jpg",
      "id" : 19950847,
      "verified" : false
    }
  },
  "id" : 760841526037536771,
  "created_at" : "2016-08-03 14:15:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "indices" : [ 115, 127 ],
      "id_str" : "18761076",
      "id" : 18761076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/CecPbNnRJ6",
      "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/Android\/Don%27t+Trick+Me\/news.asp?c=70894",
      "display_url" : "pocketgamer.co.uk\/r\/Android\/Don%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760839508816343040",
  "text" : "[Update] Deceptive puzzler Don't Trick Me coming to the App Store and Google Play soon https:\/\/t.co\/CecPbNnRJ6 via @PocketGamer",
  "id" : 760839508816343040,
  "created_at" : "2016-08-03 14:07:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Rushing",
      "screen_name" : "Steven_Rushing",
      "indices" : [ 3, 18 ],
      "id_str" : "25450901",
      "id" : 25450901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/UGA1vKxTOr",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BBlShD-OJaf\/",
      "display_url" : "instagram.com\/p\/BBlShD-OJaf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "760832968583774208",
  "text" : "RT @Steven_Rushing: Suffer with me \uD83D\uDE0F https:\/\/t.co\/UGA1vKxTOr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/UGA1vKxTOr",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BBlShD-OJaf\/",
        "display_url" : "instagram.com\/p\/BBlShD-OJaf\/"
      } ]
    },
    "geo" : { },
    "id_str" : "697188573385093120",
    "text" : "Suffer with me \uD83D\uDE0F https:\/\/t.co\/UGA1vKxTOr",
    "id" : 697188573385093120,
    "created_at" : "2016-02-09 22:41:23 +0000",
    "user" : {
      "name" : "Steven Rushing",
      "screen_name" : "Steven_Rushing",
      "protected" : false,
      "id_str" : "25450901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772467892872998913\/CqZt_-Qy_normal.jpg",
      "id" : 25450901,
      "verified" : false
    }
  },
  "id" : 760832968583774208,
  "created_at" : "2016-08-03 13:41:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Rushing",
      "screen_name" : "Steven_Rushing",
      "indices" : [ 3, 18 ],
      "id_str" : "25450901",
      "id" : 25450901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/47AsyGeDSZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BCS42rZOJUD\/",
      "display_url" : "instagram.com\/p\/BCS42rZOJUD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "760832562931589121",
  "text" : "RT @Steven_Rushing: I finished seven damn books in their universe, now what do I do?! https:\/\/t.co\/47AsyGeDSZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/47AsyGeDSZ",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BCS42rZOJUD\/",
        "display_url" : "instagram.com\/p\/BCS42rZOJUD\/"
      } ]
    },
    "geo" : { },
    "id_str" : "703606066978762753",
    "text" : "I finished seven damn books in their universe, now what do I do?! https:\/\/t.co\/47AsyGeDSZ",
    "id" : 703606066978762753,
    "created_at" : "2016-02-27 15:42:13 +0000",
    "user" : {
      "name" : "Steven Rushing",
      "screen_name" : "Steven_Rushing",
      "protected" : false,
      "id_str" : "25450901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772467892872998913\/CqZt_-Qy_normal.jpg",
      "id" : 25450901,
      "verified" : false
    }
  },
  "id" : 760832562931589121,
  "created_at" : "2016-08-03 13:39:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storytelling",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760831903335350272",
  "text" : "RT @deonnakelli: Today, I ask people to talk to me about the first time they realized they were white. #storytelling creative conversations\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "storytelling",
        "indices" : [ 86, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760826642528862208",
    "text" : "Today, I ask people to talk to me about the first time they realized they were white. #storytelling creative conversations about race.",
    "id" : 760826642528862208,
    "created_at" : "2016-08-03 13:16:21 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 760831903335350272,
  "created_at" : "2016-08-03 13:37:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gae-Lynn Woods",
      "screen_name" : "gaelynnwoods",
      "indices" : [ 3, 16 ],
      "id_str" : "46946560",
      "id" : 46946560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gaelynnwoods\/status\/747165302031454208\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/auBggDO08u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl520CiVEAEUtED.jpg",
      "id_str" : "747165224596213761",
      "id" : 747165224596213761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl520CiVEAEUtED.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/auBggDO08u"
    } ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "quotes",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "dreaming",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760831267705348096",
  "text" : "RT @gaelynnwoods: \"Reading is dreaming with open eyes.\" YoYo #books #quotes #dreaming https:\/\/t.co\/auBggDO08u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.gremlinsocial.com\" rel=\"nofollow\"\u003EGremlin Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gaelynnwoods\/status\/747165302031454208\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/auBggDO08u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl520CiVEAEUtED.jpg",
        "id_str" : "747165224596213761",
        "id" : 747165224596213761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl520CiVEAEUtED.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/auBggDO08u"
      } ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 43, 49 ]
      }, {
        "text" : "quotes",
        "indices" : [ 50, 57 ]
      }, {
        "text" : "dreaming",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760827061053247489",
    "text" : "\"Reading is dreaming with open eyes.\" YoYo #books #quotes #dreaming https:\/\/t.co\/auBggDO08u",
    "id" : 760827061053247489,
    "created_at" : "2016-08-03 13:18:01 +0000",
    "user" : {
      "name" : "Gae-Lynn Woods",
      "screen_name" : "gaelynnwoods",
      "protected" : false,
      "id_str" : "46946560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709072859528691712\/fvU_Cyve_normal.jpg",
      "id" : 46946560,
      "verified" : false
    }
  },
  "id" : 760831267705348096,
  "created_at" : "2016-08-03 13:34:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "indices" : [ 3, 15 ],
      "id_str" : "18761076",
      "id" : 18761076
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PocketGamer\/status\/760828468900794368\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tx6Yy2WHYP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8BdX_WcAAQo_A.jpg",
      "id_str" : "760828466216464384",
      "id" : 760828466216464384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8BdX_WcAAQo_A.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/tx6Yy2WHYP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/K5BRtgxF4P",
      "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/Android\/Don%27t+Starve\/news.asp?c=70922",
      "display_url" : "pocketgamer.co.uk\/r\/Android\/Don%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760830771561172993",
  "text" : "RT @PocketGamer: Klei now looking for Android beta testers for Don't Starve: Pocket Edition:\nhttps:\/\/t.co\/K5BRtgxF4P https:\/\/t.co\/tx6Yy2WHYP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PocketGamer\/status\/760828468900794368\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/tx6Yy2WHYP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8BdX_WcAAQo_A.jpg",
        "id_str" : "760828466216464384",
        "id" : 760828466216464384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8BdX_WcAAQo_A.jpg",
        "sizes" : [ {
          "h" : 424,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/tx6Yy2WHYP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/K5BRtgxF4P",
        "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/Android\/Don%27t+Starve\/news.asp?c=70922",
        "display_url" : "pocketgamer.co.uk\/r\/Android\/Don%\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760828468900794368",
    "text" : "Klei now looking for Android beta testers for Don't Starve: Pocket Edition:\nhttps:\/\/t.co\/K5BRtgxF4P https:\/\/t.co\/tx6Yy2WHYP",
    "id" : 760828468900794368,
    "created_at" : "2016-08-03 13:23:37 +0000",
    "user" : {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "protected" : false,
      "id_str" : "18761076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479184281449660417\/JEbx7R5G_normal.jpeg",
      "id" : 18761076,
      "verified" : false
    }
  },
  "id" : 760830771561172993,
  "created_at" : "2016-08-03 13:32:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Munson",
      "screen_name" : "Shxperienced",
      "indices" : [ 3, 16 ],
      "id_str" : "2339605226",
      "id" : 2339605226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760829590428418048",
  "text" : "RT @Shxperienced: This captures something about the Trump-baby story that was making me uneasy but that I couldn't put my finger on. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Shxperienced\/status\/760641861551874048\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/QmOyG4wat8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co5XrKfXEAAWhTT.jpg",
        "id_str" : "760641786134073344",
        "id" : 760641786134073344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co5XrKfXEAAWhTT.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 623
        }, {
          "h" : 1122,
          "resize" : "fit",
          "w" : 1028
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1122,
          "resize" : "fit",
          "w" : 1028
        }, {
          "h" : 1122,
          "resize" : "fit",
          "w" : 1028
        } ],
        "display_url" : "pic.twitter.com\/QmOyG4wat8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760641861551874048",
    "text" : "This captures something about the Trump-baby story that was making me uneasy but that I couldn't put my finger on. https:\/\/t.co\/QmOyG4wat8",
    "id" : 760641861551874048,
    "created_at" : "2016-08-03 01:02:06 +0000",
    "user" : {
      "name" : "Rebecca Munson",
      "screen_name" : "Shxperienced",
      "protected" : false,
      "id_str" : "2339605226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760268471624163328\/M08IiD5-_normal.jpg",
      "id" : 2339605226,
      "verified" : false
    }
  },
  "id" : 760829590428418048,
  "created_at" : "2016-08-03 13:28:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A King",
      "screen_name" : "BerniceKing",
      "indices" : [ 3, 15 ],
      "id_str" : "54617733",
      "id" : 54617733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760637308307697664",
  "text" : "RT @BerniceKing: The question is simple. The answer is clear. Are black lives treated more callously &amp; violently than white lives in the U.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KorrynGaines",
        "indices" : [ 130, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760538180906954753",
    "text" : "The question is simple. The answer is clear. Are black lives treated more callously &amp; violently than white lives in the U.S.? #KorrynGaines",
    "id" : 760538180906954753,
    "created_at" : "2016-08-02 18:10:07 +0000",
    "user" : {
      "name" : "Be A King",
      "screen_name" : "BerniceKing",
      "protected" : false,
      "id_str" : "54617733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747222048674570240\/yLROOX6u_normal.jpg",
      "id" : 54617733,
      "verified" : true
    }
  },
  "id" : 760637308307697664,
  "created_at" : "2016-08-03 00:44:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LukeRomyn\/status\/760540765680459776\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/3r0aoLaoCH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co37y2mWEAABqeP.jpg",
      "id_str" : "760540763163856896",
      "id" : 760540763163856896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co37y2mWEAABqeP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/3r0aoLaoCH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760543049197953024",
  "text" : "RT @LukeRomyn: The magic of books. https:\/\/t.co\/3r0aoLaoCH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LukeRomyn\/status\/760540765680459776\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/3r0aoLaoCH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co37y2mWEAABqeP.jpg",
        "id_str" : "760540763163856896",
        "id" : 760540763163856896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co37y2mWEAABqeP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/3r0aoLaoCH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760540765680459776",
    "text" : "The magic of books. https:\/\/t.co\/3r0aoLaoCH",
    "id" : 760540765680459776,
    "created_at" : "2016-08-02 18:20:23 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 760543049197953024,
  "created_at" : "2016-08-02 18:29:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker Molloy",
      "screen_name" : "ParkerMolloy",
      "indices" : [ 3, 16 ],
      "id_str" : "634734888",
      "id" : 634734888
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ParkerMolloy\/status\/760540911671447552\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Oz6E737eAv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co376q-VYAAyiMv.jpg",
      "id_str" : "760540897482203136",
      "id" : 760540897482203136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co376q-VYAAyiMv.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 621
      } ],
      "display_url" : "pic.twitter.com\/Oz6E737eAv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760542815063539713",
  "text" : "RT @ParkerMolloy: This is still one of my all-time favorite Twitter interactions. https:\/\/t.co\/Oz6E737eAv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ParkerMolloy\/status\/760540911671447552\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/Oz6E737eAv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co376q-VYAAyiMv.jpg",
        "id_str" : "760540897482203136",
        "id" : 760540897482203136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co376q-VYAAyiMv.jpg",
        "sizes" : [ {
          "h" : 420,
          "resize" : "fit",
          "w" : 621
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 621
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 621
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 621
        } ],
        "display_url" : "pic.twitter.com\/Oz6E737eAv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760540911671447552",
    "text" : "This is still one of my all-time favorite Twitter interactions. https:\/\/t.co\/Oz6E737eAv",
    "id" : 760540911671447552,
    "created_at" : "2016-08-02 18:20:58 +0000",
    "user" : {
      "name" : "Parker Molloy",
      "screen_name" : "ParkerMolloy",
      "protected" : false,
      "id_str" : "634734888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797413266544885760\/1DUbSMok_normal.jpg",
      "id" : 634734888,
      "verified" : true
    }
  },
  "id" : 760542815063539713,
  "created_at" : "2016-08-02 18:28:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Elverojaguar\/status\/760517818718781441\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/nzAsdQpAUG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3m5BxW8AAk7ig.jpg",
      "id_str" : "760517779497873408",
      "id" : 760517779497873408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3m5BxW8AAk7ig.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nzAsdQpAUG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760521602425585664",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83C\uDF88\uD83D\uDE3D\u2764\uFE0F https:\/\/t.co\/nzAsdQpAUG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Elverojaguar\/status\/760517818718781441\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/nzAsdQpAUG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3m5BxW8AAk7ig.jpg",
        "id_str" : "760517779497873408",
        "id" : 760517779497873408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3m5BxW8AAk7ig.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/nzAsdQpAUG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760517818718781441",
    "text" : "\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83C\uDF88\uD83D\uDE3D\u2764\uFE0F https:\/\/t.co\/nzAsdQpAUG",
    "id" : 760517818718781441,
    "created_at" : "2016-08-02 16:49:12 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 760521602425585664,
  "created_at" : "2016-08-02 17:04:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/KyL8WmmVgG",
      "expanded_url" : "https:\/\/twitter.com\/Brosner85\/status\/760515959052496900",
      "display_url" : "twitter.com\/Brosner85\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760521434724794368",
  "text" : "RT @rjmedwed: There\u2019s such a thing as too cheesy?\n\n https:\/\/t.co\/KyL8WmmVgG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/KyL8WmmVgG",
        "expanded_url" : "https:\/\/twitter.com\/Brosner85\/status\/760515959052496900",
        "display_url" : "twitter.com\/Brosner85\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760518039645384704",
    "text" : "There\u2019s such a thing as too cheesy?\n\n https:\/\/t.co\/KyL8WmmVgG",
    "id" : 760518039645384704,
    "created_at" : "2016-08-02 16:50:05 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 760521434724794368,
  "created_at" : "2016-08-02 17:03:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KerriFar\/status\/722492425130872832\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Im4i1NH4Cn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbPCEdWEAACQEH.jpg",
      "id_str" : "722492424703053824",
      "id" : 722492424703053824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbPCEdWEAACQEH.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Im4i1NH4Cn"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 91, 97 ]
    }, {
      "text" : "nature",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/QTWBG2ozHn",
      "expanded_url" : "http:\/\/goo.gl\/G4a3QB",
      "display_url" : "goo.gl\/G4a3QB"
    } ]
  },
  "geo" : { },
  "id_str" : "760520402351169536",
  "text" : "RT @KerriFar: Because......Sometimes you feel like a nut .... ~  https:\/\/t.co\/QTWBG2ozHn ~ #birds #nature ~ https:\/\/t.co\/Im4i1NH4Cn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KerriFar\/status\/722492425130872832\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/Im4i1NH4Cn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbPCEdWEAACQEH.jpg",
        "id_str" : "722492424703053824",
        "id" : 722492424703053824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbPCEdWEAACQEH.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Im4i1NH4Cn"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 77, 83 ]
      }, {
        "text" : "nature",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/QTWBG2ozHn",
        "expanded_url" : "http:\/\/goo.gl\/G4a3QB",
        "display_url" : "goo.gl\/G4a3QB"
      } ]
    },
    "geo" : { },
    "id_str" : "760518176815849475",
    "text" : "Because......Sometimes you feel like a nut .... ~  https:\/\/t.co\/QTWBG2ozHn ~ #birds #nature ~ https:\/\/t.co\/Im4i1NH4Cn",
    "id" : 760518176815849475,
    "created_at" : "2016-08-02 16:50:37 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 760520402351169536,
  "created_at" : "2016-08-02 16:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ZEDVEeBBdc",
      "expanded_url" : "https:\/\/twitter.com\/Tim_Bousquet\/status\/760518360312401921",
      "display_url" : "twitter.com\/Tim_Bousquet\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760520007700873216",
  "text" : "RT @PisseArtiste: This is the longest train wreck in the history of everything. https:\/\/t.co\/ZEDVEeBBdc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/ZEDVEeBBdc",
        "expanded_url" : "https:\/\/twitter.com\/Tim_Bousquet\/status\/760518360312401921",
        "display_url" : "twitter.com\/Tim_Bousquet\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760518679796736000",
    "text" : "This is the longest train wreck in the history of everything. https:\/\/t.co\/ZEDVEeBBdc",
    "id" : 760518679796736000,
    "created_at" : "2016-08-02 16:52:37 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 760520007700873216,
  "created_at" : "2016-08-02 16:57:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 85, 98 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/etFnQJrfSA",
      "expanded_url" : "https:\/\/audiobookreviewer.com\/reviews\/user-submitted\/guest-review-balance-devine-book-1-m-r-forbes\/",
      "display_url" : "audiobookreviewer.com\/reviews\/user-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760510778894090240",
  "text" : "Guest Review: Balance (The Devine Book 1) by M.R. Forbes https:\/\/t.co\/etFnQJrfSA via @AudioBookRev",
  "id" : 760510778894090240,
  "created_at" : "2016-08-02 16:21:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 108, 121 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/1BkuvbcSWJ",
      "expanded_url" : "https:\/\/audiobookreviewer.com\/reviews\/user-submitted\/guest-review-devils-detective-thomas-fool-book-1-simon-kurt-unsworth\/",
      "display_url" : "audiobookreviewer.com\/reviews\/user-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760510514036412416",
  "text" : "Guest Review: The Devil's Detective (Thomas Fool Book 1) by Simon Kurt Unsworth https:\/\/t.co\/1BkuvbcSWJ via @AudioBookRev",
  "id" : 760510514036412416,
  "created_at" : "2016-08-02 16:20:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 89, 102 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/dc21bCwqH7",
      "expanded_url" : "https:\/\/audiobookreviewer.com\/blog\/horror-scifi-thriller-audiobook-release-day-august-2-2016\/",
      "display_url" : "audiobookreviewer.com\/blog\/horror-sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760509979937935365",
  "text" : "Horror, SciFi, Thriller Audiobook Release Day August 2, 2016 https:\/\/t.co\/dc21bCwqH7 via @AudioBookRev",
  "id" : 760509979937935365,
  "created_at" : "2016-08-02 16:18:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.producthunt.com\" rel=\"nofollow\"\u003EProduct Hunt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Singer",
      "screen_name" : "jsngr",
      "indices" : [ 74, 80 ],
      "id_str" : "35623579",
      "id" : 35623579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/760509296006291456\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/fhfqu3MKU8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3fLDnWcAA51wm.jpg",
      "id_str" : "760509293137391616",
      "id" : 760509293137391616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3fLDnWcAA51wm.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/fhfqu3MKU8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/gvPBAZGzQY",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/wonder-8",
      "display_url" : "producthunt.com\/tech\/wonder-8"
    } ]
  },
  "geo" : { },
  "id_str" : "760509296006291456",
  "text" : "Wonder: Remember the things you easily forget https:\/\/t.co\/gvPBAZGzQY via @jsngr https:\/\/t.co\/fhfqu3MKU8",
  "id" : 760509296006291456,
  "created_at" : "2016-08-02 16:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/fT723NZYY4",
      "expanded_url" : "http:\/\/www.habschned.com\/gartenzwerge\/",
      "display_url" : "habschned.com\/gartenzwerge\/"
    } ]
  },
  "geo" : { },
  "id_str" : "760505650019524608",
  "text" : "really creepy gnomes! &gt; Gartenzwerge\u2026 - https:\/\/t.co\/fT723NZYY4",
  "id" : 760505650019524608,
  "created_at" : "2016-08-02 16:00:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760504390725857280",
  "text" : "so angry! tried to save money but ended up buying item for double price becuz acct went in hole. gah. im usu good about checking it. sigh.",
  "id" : 760504390725857280,
  "created_at" : "2016-08-02 15:55:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi",
      "screen_name" : "HeidiStea",
      "indices" : [ 3, 13 ],
      "id_str" : "1395923928",
      "id" : 1395923928
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/760488724589412353\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/cv9IYXd2xZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3MdSNXEAAvfUi.jpg",
      "id_str" : "760488715571630080",
      "id" : 760488715571630080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3MdSNXEAAvfUi.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      } ],
      "display_url" : "pic.twitter.com\/cv9IYXd2xZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/760488724589412353\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/cv9IYXd2xZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3MdSMXgAAoF9G.jpg",
      "id_str" : "760488715567464448",
      "id" : 760488715567464448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3MdSMXgAAoF9G.jpg",
      "sizes" : [ {
        "h" : 418,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 605
      } ],
      "display_url" : "pic.twitter.com\/cv9IYXd2xZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/760488724589412353\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/cv9IYXd2xZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3MdSQWIAAFW2w.jpg",
      "id_str" : "760488715584151552",
      "id" : 760488715584151552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3MdSQWIAAFW2w.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 605
      } ],
      "display_url" : "pic.twitter.com\/cv9IYXd2xZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760501520219697152",
  "text" : "RT @HeidiStea: Some of my favourite washroom doors! Much better than the ordinary.. \uD83D\uDE02\uD83D\uDE02 https:\/\/t.co\/cv9IYXd2xZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/760488724589412353\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/cv9IYXd2xZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3MdSNXEAAvfUi.jpg",
        "id_str" : "760488715571630080",
        "id" : 760488715571630080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3MdSNXEAAvfUi.jpg",
        "sizes" : [ {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        } ],
        "display_url" : "pic.twitter.com\/cv9IYXd2xZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/760488724589412353\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/cv9IYXd2xZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3MdSMXgAAoF9G.jpg",
        "id_str" : "760488715567464448",
        "id" : 760488715567464448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3MdSMXgAAoF9G.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 605
        } ],
        "display_url" : "pic.twitter.com\/cv9IYXd2xZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/760488724589412353\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/cv9IYXd2xZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3MdSQWIAAFW2w.jpg",
        "id_str" : "760488715584151552",
        "id" : 760488715584151552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3MdSQWIAAFW2w.jpg",
        "sizes" : [ {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 605
        } ],
        "display_url" : "pic.twitter.com\/cv9IYXd2xZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760488724589412353",
    "text" : "Some of my favourite washroom doors! Much better than the ordinary.. \uD83D\uDE02\uD83D\uDE02 https:\/\/t.co\/cv9IYXd2xZ",
    "id" : 760488724589412353,
    "created_at" : "2016-08-02 14:53:35 +0000",
    "user" : {
      "name" : "Heidi",
      "screen_name" : "HeidiStea",
      "protected" : false,
      "id_str" : "1395923928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799076389865537546\/QxnMNM-8_normal.jpg",
      "id" : 1395923928,
      "verified" : false
    }
  },
  "id" : 760501520219697152,
  "created_at" : "2016-08-02 15:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David A. Graham",
      "screen_name" : "GrahamDavidA",
      "indices" : [ 3, 16 ],
      "id_str" : "46955476",
      "id" : 46955476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/GZFLnDjBoX",
      "expanded_url" : "https:\/\/twitter.com\/sahilkapur\/status\/760483979380330497",
      "display_url" : "twitter.com\/sahilkapur\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760500792755355648",
  "text" : "RT @GrahamDavidA: Another name for a fund where citizens contribute for public works projects is \"taxation\" https:\/\/t.co\/GZFLnDjBoX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/GZFLnDjBoX",
        "expanded_url" : "https:\/\/twitter.com\/sahilkapur\/status\/760483979380330497",
        "display_url" : "twitter.com\/sahilkapur\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760493100196323328",
    "text" : "Another name for a fund where citizens contribute for public works projects is \"taxation\" https:\/\/t.co\/GZFLnDjBoX",
    "id" : 760493100196323328,
    "created_at" : "2016-08-02 15:10:59 +0000",
    "user" : {
      "name" : "David A. Graham",
      "screen_name" : "GrahamDavidA",
      "protected" : false,
      "id_str" : "46955476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522799754778931200\/72hRBE0y_normal.jpeg",
      "id" : 46955476,
      "verified" : true
    }
  },
  "id" : 760500792755355648,
  "created_at" : "2016-08-02 15:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revelist",
      "screen_name" : "heyrevelist",
      "indices" : [ 87, 99 ],
      "id_str" : "3846617902",
      "id" : 3846617902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/5svZglmqNV",
      "expanded_url" : "http:\/\/www.revelist.com\/hair\/older-women-cool-hair\/774",
      "display_url" : "revelist.com\/hair\/older-wom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760493892009590789",
  "text" : "14 older women with cool hair who will totally inspire you https:\/\/t.co\/5svZglmqNV via @HeyRevelist",
  "id" : 760493892009590789,
  "created_at" : "2016-08-02 15:14:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    }, {
      "name" : "ACLU National",
      "screen_name" : "ACLU",
      "indices" : [ 27, 32 ],
      "id_str" : "13393052",
      "id" : 13393052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/KEYOYl6cZe",
      "expanded_url" : "http:\/\/shop.aclu.org\/product\/ACLU-Pocket-Constitution-of-the-United-States?a=twtconstkhikha",
      "display_url" : "shop.aclu.org\/product\/ACLU-P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760489511046504452",
  "text" : "RT @Snowden: Since Friday, @ACLU has given away 80,000 pocket copies of the Constitution. Got yours?  https:\/\/t.co\/KEYOYl6cZe https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ACLU National",
        "screen_name" : "ACLU",
        "indices" : [ 14, 19 ],
        "id_str" : "13393052",
        "id" : 13393052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/KEYOYl6cZe",
        "expanded_url" : "http:\/\/shop.aclu.org\/product\/ACLU-Pocket-Constitution-of-the-United-States?a=twtconstkhikha",
        "display_url" : "shop.aclu.org\/product\/ACLU-P\u2026"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/VHtM4gJLcR",
        "expanded_url" : "https:\/\/twitter.com\/ACLU\/status\/759860835493801984",
        "display_url" : "twitter.com\/ACLU\/status\/75\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760468670283776000",
    "text" : "Since Friday, @ACLU has given away 80,000 pocket copies of the Constitution. Got yours?  https:\/\/t.co\/KEYOYl6cZe https:\/\/t.co\/VHtM4gJLcR",
    "id" : 760468670283776000,
    "created_at" : "2016-08-02 13:33:54 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 760489511046504452,
  "created_at" : "2016-08-02 14:56:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EmilyBaah",
      "screen_name" : "EmilyBaah",
      "indices" : [ 3, 13 ],
      "id_str" : "22180969",
      "id" : 22180969
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/wa8yefaCtV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy4oudWIAANQJb.jpg",
      "id_str" : "760185446924165120",
      "id" : 760185446924165120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy4oudWIAANQJb.jpg",
      "sizes" : [ {
        "h" : 821,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 821,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 821,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/wa8yefaCtV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/wa8yefaCtV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy4yVUXgAABDPa.jpg",
      "id_str" : "760185611974311936",
      "id" : 760185611974311936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy4yVUXgAABDPa.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wa8yefaCtV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/wa8yefaCtV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy41pAWgAEfEZf.jpg",
      "id_str" : "760185668798676993",
      "id" : 760185668798676993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy41pAWgAEfEZf.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/wa8yefaCtV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/wa8yefaCtV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy5QO6WEAE9W2l.jpg",
      "id_str" : "760186125650628609",
      "id" : 760186125650628609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy5QO6WEAE9W2l.jpg",
      "sizes" : [ {
        "h" : 740,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wa8yefaCtV"
    } ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "sheepcat",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760217128549113856",
  "text" : "RT @EmilyBaah: As promised, cat on a bale 2016. You're welcome. \n#farm365 #sheepcat https:\/\/t.co\/wa8yefaCtV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wa8yefaCtV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy4oudWIAANQJb.jpg",
        "id_str" : "760185446924165120",
        "id" : 760185446924165120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy4oudWIAANQJb.jpg",
        "sizes" : [ {
          "h" : 821,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 821,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/wa8yefaCtV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wa8yefaCtV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy4yVUXgAABDPa.jpg",
        "id_str" : "760185611974311936",
        "id" : 760185611974311936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy4yVUXgAABDPa.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wa8yefaCtV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wa8yefaCtV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy41pAWgAEfEZf.jpg",
        "id_str" : "760185668798676993",
        "id" : 760185668798676993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy41pAWgAEfEZf.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/wa8yefaCtV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/760186255724470272\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wa8yefaCtV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coy5QO6WEAE9W2l.jpg",
        "id_str" : "760186125650628609",
        "id" : 760186125650628609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coy5QO6WEAE9W2l.jpg",
        "sizes" : [ {
          "h" : 740,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wa8yefaCtV"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 50, 58 ]
      }, {
        "text" : "sheepcat",
        "indices" : [ 59, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760186255724470272",
    "text" : "As promised, cat on a bale 2016. You're welcome. \n#farm365 #sheepcat https:\/\/t.co\/wa8yefaCtV",
    "id" : 760186255724470272,
    "created_at" : "2016-08-01 18:51:41 +0000",
    "user" : {
      "name" : "EmilyBaah",
      "screen_name" : "EmilyBaah",
      "protected" : false,
      "id_str" : "22180969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792438768246620160\/0ES1rhAt_normal.jpg",
      "id" : 22180969,
      "verified" : false
    }
  },
  "id" : 760217128549113856,
  "created_at" : "2016-08-01 20:54:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thecrazysheeplady",
      "screen_name" : "crazysheeplady",
      "indices" : [ 3, 18 ],
      "id_str" : "20524646",
      "id" : 20524646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/TYinZUO9vX",
      "expanded_url" : "http:\/\/ift.tt\/2aMjd3X",
      "display_url" : "ift.tt\/2aMjd3X"
    } ]
  },
  "geo" : { },
  "id_str" : "760200846349131777",
  "text" : "RT @crazysheeplady: Comby's helping in the Wool House this afternoon. Also known as trying to keep him from be\u2026 https:\/\/t.co\/TYinZUO9vX htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crazysheeplady\/status\/760172083271917570\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/a0p6DbiDR3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoyserfXEAQ2laH.jpg",
        "id_str" : "760172080189083652",
        "id" : 760172080189083652,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoyserfXEAQ2laH.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/a0p6DbiDR3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/TYinZUO9vX",
        "expanded_url" : "http:\/\/ift.tt\/2aMjd3X",
        "display_url" : "ift.tt\/2aMjd3X"
      } ]
    },
    "geo" : { },
    "id_str" : "760172083271917570",
    "text" : "Comby's helping in the Wool House this afternoon. Also known as trying to keep him from be\u2026 https:\/\/t.co\/TYinZUO9vX https:\/\/t.co\/a0p6DbiDR3",
    "id" : 760172083271917570,
    "created_at" : "2016-08-01 17:55:22 +0000",
    "user" : {
      "name" : "thecrazysheeplady",
      "screen_name" : "crazysheeplady",
      "protected" : false,
      "id_str" : "20524646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77050420\/me_and_punkin_small_normal.jpg",
      "id" : 20524646,
      "verified" : false
    }
  },
  "id" : 760200846349131777,
  "created_at" : "2016-08-01 19:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760164753411112960",
  "text" : "sometimes I forget she really doesnt feel good and doesnt have stamina for regular things. its frustrating for all of us. #chronicillness",
  "id" : 760164753411112960,
  "created_at" : "2016-08-01 17:26:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760164197858701313",
  "text" : "well meaning ppl dont understand. she was always different. now even more so. we week to week at our own pace. #chronicillness",
  "id" : 760164197858701313,
  "created_at" : "2016-08-01 17:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760163414475939840",
  "text" : "I have a child w invisible #chronicillness .. it changed her. she was already behind peers in life.. now not on the track period.",
  "id" : 760163414475939840,
  "created_at" : "2016-08-01 17:20:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Constitution",
      "indices" : [ 32, 45 ]
    }, {
      "text" : "POCKETRIGHTS",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UeQWImW9Nu",
      "expanded_url" : "https:\/\/shop.aclu.org\/product\/ACLU-Pocket-Constitution-of-the-United-States?a=emlconstkhikha?emsrc=Nat_Appeal_AutologinEnabled&emissue=elections&emtype=FreeConstitutionMarketing&ms=eml_160729_elections_FreeConstitutionMarketing&__af=8BzDwMm2DIaUB2D%2FXqe6dERw1JVezrzMbuE1XD1hInBnvqVg2A%2Fio4LVdOk%2FXG01aPdGjBiuImMqLN8INyPBcZ04CKggJaFJR0xEFcsBWs%2FoaN9TW2HfzhD1bKkypVwwUHhXlrWuqU7mMbe2b98Mev6%2FGACTDXMDTs3%2FA2jPQhj5MLGT5Aa2eZrjjno541hWQX3R0S7flLqqFqbUeXAt3AKpDT4s%2BlF3moA6f9tyKgSVZ9vIIGXCFhmCtHQPr7bw",
      "display_url" : "shop.aclu.org\/product\/ACLU-P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760127736505626624",
  "text" : "RT @JamiaStarheart: ACLU Pocket #Constitution of the United States FREE, including shipping w\/code: #POCKETRIGHTS  https:\/\/t.co\/UeQWImW9Nu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Constitution",
        "indices" : [ 12, 25 ]
      }, {
        "text" : "POCKETRIGHTS",
        "indices" : [ 80, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/UeQWImW9Nu",
        "expanded_url" : "https:\/\/shop.aclu.org\/product\/ACLU-Pocket-Constitution-of-the-United-States?a=emlconstkhikha?emsrc=Nat_Appeal_AutologinEnabled&emissue=elections&emtype=FreeConstitutionMarketing&ms=eml_160729_elections_FreeConstitutionMarketing&__af=8BzDwMm2DIaUB2D%2FXqe6dERw1JVezrzMbuE1XD1hInBnvqVg2A%2Fio4LVdOk%2FXG01aPdGjBiuImMqLN8INyPBcZ04CKggJaFJR0xEFcsBWs%2FoaN9TW2HfzhD1bKkypVwwUHhXlrWuqU7mMbe2b98Mev6%2FGACTDXMDTs3%2FA2jPQhj5MLGT5Aa2eZrjjno541hWQX3R0S7flLqqFqbUeXAt3AKpDT4s%2BlF3moA6f9tyKgSVZ9vIIGXCFhmCtHQPr7bw",
        "display_url" : "shop.aclu.org\/product\/ACLU-P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760123577895092225",
    "text" : "ACLU Pocket #Constitution of the United States FREE, including shipping w\/code: #POCKETRIGHTS  https:\/\/t.co\/UeQWImW9Nu",
    "id" : 760123577895092225,
    "created_at" : "2016-08-01 14:42:38 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 760127736505626624,
  "created_at" : "2016-08-01 14:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mic",
      "screen_name" : "mic",
      "indices" : [ 3, 7 ],
      "id_str" : "139909832",
      "id" : 139909832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mic\/status\/760123136054595584\/video\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/PgwzEl9WrW",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760122885398732800\/pu\/img\/OKPEV1VgBO9Dfj99.jpg",
      "id_str" : "760122885398732800",
      "id" : 760122885398732800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760122885398732800\/pu\/img\/OKPEV1VgBO9Dfj99.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PgwzEl9WrW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760127594851368960",
  "text" : "RT @mic: A defendant was denied pants and feminine hygiene products for three days. This judge was not having it. https:\/\/t.co\/PgwzEl9WrW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mic\/status\/760123136054595584\/video\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/PgwzEl9WrW",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760122885398732800\/pu\/img\/OKPEV1VgBO9Dfj99.jpg",
        "id_str" : "760122885398732800",
        "id" : 760122885398732800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760122885398732800\/pu\/img\/OKPEV1VgBO9Dfj99.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PgwzEl9WrW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760123136054595584",
    "text" : "A defendant was denied pants and feminine hygiene products for three days. This judge was not having it. https:\/\/t.co\/PgwzEl9WrW",
    "id" : 760123136054595584,
    "created_at" : "2016-08-01 14:40:52 +0000",
    "user" : {
      "name" : "Mic",
      "screen_name" : "mic",
      "protected" : false,
      "id_str" : "139909832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800724913648603140\/M7di-DhA_normal.jpg",
      "id" : 139909832,
      "verified" : true
    }
  },
  "id" : 760127594851368960,
  "created_at" : "2016-08-01 14:58:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Book Guys Podcast",
      "screen_name" : "BookGuys",
      "indices" : [ 3, 12 ],
      "id_str" : "426221730",
      "id" : 426221730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/xHIJWoakhz",
      "expanded_url" : "http:\/\/traffic.libsyn.com\/paulthebookguy\/WEEKLYTOP5_June31_2016.mp3",
      "display_url" : "traffic.libsyn.com\/paulthebookguy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760112163172261888",
  "text" : "RT @BookGuys: Weekly Top 5 - New Audiobook Releases https:\/\/t.co\/xHIJWoakhz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/libsyn.com\/3\/\" rel=\"nofollow\"\u003ELibsyn On-Publish\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/xHIJWoakhz",
        "expanded_url" : "http:\/\/traffic.libsyn.com\/paulthebookguy\/WEEKLYTOP5_June31_2016.mp3",
        "display_url" : "traffic.libsyn.com\/paulthebookguy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759929838933344256",
    "text" : "Weekly Top 5 - New Audiobook Releases https:\/\/t.co\/xHIJWoakhz",
    "id" : 759929838933344256,
    "created_at" : "2016-08-01 01:52:47 +0000",
    "user" : {
      "name" : "Book Guys Podcast",
      "screen_name" : "BookGuys",
      "protected" : false,
      "id_str" : "426221730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755662445969047554\/XJaBb3O-_normal.jpg",
      "id" : 426221730,
      "verified" : false
    }
  },
  "id" : 760112163172261888,
  "created_at" : "2016-08-01 13:57:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Norton",
      "screen_name" : "dnorton",
      "indices" : [ 3, 11 ],
      "id_str" : "668523",
      "id" : 668523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Mz2ew5StAC",
      "expanded_url" : "https:\/\/apple.news\/AjIJ0lQKfTWmds92MX3yc9Q",
      "display_url" : "apple.news\/AjIJ0lQKfTWmds\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760107271464554496",
  "text" : "RT @dnorton: Obama to Leave the White House a Nerdier Place Than He Found It - The New York Times https:\/\/t.co\/Mz2ew5StAC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/Mz2ew5StAC",
        "expanded_url" : "https:\/\/apple.news\/AjIJ0lQKfTWmds92MX3yc9Q",
        "display_url" : "apple.news\/AjIJ0lQKfTWmds\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759924113951563776",
    "text" : "Obama to Leave the White House a Nerdier Place Than He Found It - The New York Times https:\/\/t.co\/Mz2ew5StAC",
    "id" : 759924113951563776,
    "created_at" : "2016-08-01 01:30:02 +0000",
    "user" : {
      "name" : "Daniel Norton",
      "screen_name" : "dnorton",
      "protected" : false,
      "id_str" : "668523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2610640060\/usa6o1qwb5cj94bbj4zu_normal.jpeg",
      "id" : 668523,
      "verified" : false
    }
  },
  "id" : 760107271464554496,
  "created_at" : "2016-08-01 13:37:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jameson Voss MD MPH",
      "screen_name" : "JamesonVoss",
      "indices" : [ 3, 15 ],
      "id_str" : "525984544",
      "id" : 525984544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/i4yAHsFhgZ",
      "expanded_url" : "http:\/\/press.endocrine.org\/doi\/10.1210\/en.2016-1102",
      "display_url" : "press.endocrine.org\/doi\/10.1210\/en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760106289083056128",
  "text" : "RT @JamesonVoss: an example of how sometimes physiology beats physics (ie thermodynamics) in obesity https:\/\/t.co\/i4yAHsFhgZ mice gained we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/i4yAHsFhgZ",
        "expanded_url" : "http:\/\/press.endocrine.org\/doi\/10.1210\/en.2016-1102",
        "display_url" : "press.endocrine.org\/doi\/10.1210\/en\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759215029346508800",
    "text" : "an example of how sometimes physiology beats physics (ie thermodynamics) in obesity https:\/\/t.co\/i4yAHsFhgZ mice gained weight w\/less food",
    "id" : 759215029346508800,
    "created_at" : "2016-07-30 02:32:23 +0000",
    "user" : {
      "name" : "Jameson Voss MD MPH",
      "screen_name" : "JamesonVoss",
      "protected" : false,
      "id_str" : "525984544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728024767341723648\/yKY_GpQR_normal.jpg",
      "id" : 525984544,
      "verified" : false
    }
  },
  "id" : 760106289083056128,
  "created_at" : "2016-08-01 13:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]