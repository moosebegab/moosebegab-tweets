Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patty",
      "screen_name" : "steeler14527",
      "indices" : [ 3, 16 ],
      "id_str" : "260996844",
      "id" : 260996844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmartNews",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/zhyLOg8ly3",
      "expanded_url" : "http:\/\/smar.ws\/EHIz2",
      "display_url" : "smar.ws\/EHIz2"
    } ]
  },
  "geo" : { },
  "id_str" : "782035581983481859",
  "text" : "RT @steeler14527: Last Frog Of His Kind Dies Alone https:\/\/t.co\/zhyLOg8ly3 #SmartNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.smartnews.com\/\" rel=\"nofollow\"\u003ESmartNews | \u30B9\u30DE\u30FC\u30C8\u30CB\u30E5\u30FC\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmartNews",
        "indices" : [ 57, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/zhyLOg8ly3",
        "expanded_url" : "http:\/\/smar.ws\/EHIz2",
        "display_url" : "smar.ws\/EHIz2"
      } ]
    },
    "geo" : { },
    "id_str" : "781660916727230464",
    "text" : "Last Frog Of His Kind Dies Alone https:\/\/t.co\/zhyLOg8ly3 #SmartNews",
    "id" : 781660916727230464,
    "created_at" : "2016-09-30 01:04:19 +0000",
    "user" : {
      "name" : "Patty",
      "screen_name" : "steeler14527",
      "protected" : false,
      "id_str" : "260996844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739581505308135424\/OuCF9auM_normal.jpg",
      "id" : 260996844,
      "verified" : false
    }
  },
  "id" : 782035581983481859,
  "created_at" : "2016-10-01 01:53:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/63vP27QkR9",
      "expanded_url" : "https:\/\/twitter.com\/pmclellan\/status\/762924387024642049",
      "display_url" : "twitter.com\/pmclellan\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781984182478180352",
  "text" : "precious!! https:\/\/t.co\/63vP27QkR9",
  "id" : 781984182478180352,
  "created_at" : "2016-09-30 22:28:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781978927334064128",
  "text" : "as much as I dislike the man, I can understand how that would hurt.",
  "id" : 781978927334064128,
  "created_at" : "2016-09-30 22:07:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elections",
      "indices" : [ 75, 85 ]
    }, {
      "text" : "trump",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/xY8nZQBTfS",
      "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/frontline\/film\/the-choice-2016\/",
      "display_url" : "pbs.org\/wgbh\/frontline\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781978465503473664",
  "text" : "this explains it (1st 5 mins) &gt; The Choice 2016 https:\/\/t.co\/xY8nZQBTfS #elections #trump",
  "id" : 781978465503473664,
  "created_at" : "2016-09-30 22:06:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hypothyroid Mom",
      "screen_name" : "HypothyroidMom",
      "indices" : [ 3, 18 ],
      "id_str" : "842279588",
      "id" : 842279588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HypothyroidMom\/status\/781965037133062144\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/8385E5IptM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtoZDJfW8AU31O8.jpg",
      "id_str" : "781965027179950085",
      "id" : 781965027179950085,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtoZDJfW8AU31O8.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8385E5IptM"
    } ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/hZGD0l2eML",
      "expanded_url" : "http:\/\/bit.ly\/2cHCJOf",
      "display_url" : "bit.ly\/2cHCJOf"
    } ]
  },
  "geo" : { },
  "id_str" : "781966701760045056",
  "text" : "RT @HypothyroidMom: We need #thyroid research. Please take this short survey: https:\/\/t.co\/hZGD0l2eML https:\/\/t.co\/8385E5IptM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HypothyroidMom\/status\/781965037133062144\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/8385E5IptM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtoZDJfW8AU31O8.jpg",
        "id_str" : "781965027179950085",
        "id" : 781965027179950085,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtoZDJfW8AU31O8.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8385E5IptM"
      } ],
      "hashtags" : [ {
        "text" : "thyroid",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/hZGD0l2eML",
        "expanded_url" : "http:\/\/bit.ly\/2cHCJOf",
        "display_url" : "bit.ly\/2cHCJOf"
      } ]
    },
    "geo" : { },
    "id_str" : "781965037133062144",
    "text" : "We need #thyroid research. Please take this short survey: https:\/\/t.co\/hZGD0l2eML https:\/\/t.co\/8385E5IptM",
    "id" : 781965037133062144,
    "created_at" : "2016-09-30 21:12:47 +0000",
    "user" : {
      "name" : "Hypothyroid Mom",
      "screen_name" : "HypothyroidMom",
      "protected" : false,
      "id_str" : "842279588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541722388522479618\/RzaTcO_g_normal.jpeg",
      "id" : 842279588,
      "verified" : false
    }
  },
  "id" : 781966701760045056,
  "created_at" : "2016-09-30 21:19:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Foley",
      "screen_name" : "elisefoley",
      "indices" : [ 3, 14 ],
      "id_str" : "142721190",
      "id" : 142721190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elisefoley\/status\/781540425022763010\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/mORnjwfSzD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtiW3U0XEAAHczT.jpg",
      "id_str" : "781540412574076928",
      "id" : 781540412574076928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtiW3U0XEAAHczT.jpg",
      "sizes" : [ {
        "h" : 365,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 715
      } ],
      "display_url" : "pic.twitter.com\/mORnjwfSzD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/l3zp9EnOWD",
      "expanded_url" : "http:\/\/thecut.io\/2cErZ7A",
      "display_url" : "thecut.io\/2cErZ7A"
    } ]
  },
  "geo" : { },
  "id_str" : "781963372157960196",
  "text" : "RT @elisefoley: What i\u2019s like to be a female reporter covering Donald Trump https:\/\/t.co\/l3zp9EnOWD https:\/\/t.co\/mORnjwfSzD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elisefoley\/status\/781540425022763010\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/mORnjwfSzD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtiW3U0XEAAHczT.jpg",
        "id_str" : "781540412574076928",
        "id" : 781540412574076928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtiW3U0XEAAHczT.jpg",
        "sizes" : [ {
          "h" : 365,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 715
        } ],
        "display_url" : "pic.twitter.com\/mORnjwfSzD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/l3zp9EnOWD",
        "expanded_url" : "http:\/\/thecut.io\/2cErZ7A",
        "display_url" : "thecut.io\/2cErZ7A"
      } ]
    },
    "geo" : { },
    "id_str" : "781540425022763010",
    "text" : "What i\u2019s like to be a female reporter covering Donald Trump https:\/\/t.co\/l3zp9EnOWD https:\/\/t.co\/mORnjwfSzD",
    "id" : 781540425022763010,
    "created_at" : "2016-09-29 17:05:32 +0000",
    "user" : {
      "name" : "Elise Foley",
      "screen_name" : "elisefoley",
      "protected" : false,
      "id_str" : "142721190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793131960264777728\/m6JLtPOu_normal.jpg",
      "id" : 142721190,
      "verified" : true
    }
  },
  "id" : 781963372157960196,
  "created_at" : "2016-09-30 21:06:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781963155652182016",
  "text" : "RT @AWorldOutOfMind: Trump's an insane fascist\n-Are you trying to scare me?\nOf course I'm trying to scare you! Did you miss the part about\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781960629250908164",
    "text" : "Trump's an insane fascist\n-Are you trying to scare me?\nOf course I'm trying to scare you! Did you miss the part about \"insane fascist?!\"",
    "id" : 781960629250908164,
    "created_at" : "2016-09-30 20:55:16 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 781963155652182016,
  "created_at" : "2016-09-30 21:05:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781952847307046912",
  "text" : "shes tried a few meds so far w no effect or bad effect. abilify brought on episode. zyprexa=hunger,weightgain.",
  "id" : 781952847307046912,
  "created_at" : "2016-09-30 20:24:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781951352595439616",
  "text" : "therapy isnt helping her. she likes therapist but feels he isnt getting it. shes very depressed.",
  "id" : 781951352595439616,
  "created_at" : "2016-09-30 20:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/DBJgfJPxuG",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx2Cn3kcK",
      "display_url" : "tmblr.co\/Zp3-jx2Cn3kcK"
    } ]
  },
  "geo" : { },
  "id_str" : "781869673566638082",
  "text" : "Mike Pence Tells Wrongfully Convicted Man He Won't Act On Pardon Request - After waiting more than two... https:\/\/t.co\/DBJgfJPxuG",
  "id" : 781869673566638082,
  "created_at" : "2016-09-30 14:53:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/5Hhqd6CJxW",
      "expanded_url" : "https:\/\/twitter.com\/xkcdComic\/status\/781839324664832000",
      "display_url" : "twitter.com\/xkcdComic\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781868438268547072",
  "text" : "cute! https:\/\/t.co\/5Hhqd6CJxW",
  "id" : 781868438268547072,
  "created_at" : "2016-09-30 14:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESA Rosetta Mission",
      "screen_name" : "ESA_Rosetta",
      "indices" : [ 3, 15 ],
      "id_str" : "253536357",
      "id" : 253536357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "67P",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "CometLanding",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "MissionComplete",
      "indices" : [ 89, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/yiSnxDrnba",
      "expanded_url" : "http:\/\/ow.ly\/lbmc304IADE",
      "display_url" : "ow.ly\/lbmc304IADE"
    } ]
  },
  "geo" : { },
  "id_str" : "781867474170019840",
  "text" : "RT @ESA_Rosetta: From #67P with love: a last image, taken 51 metres before #CometLanding #MissionComplete https:\/\/t.co\/yiSnxDrnba https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ESA_Rosetta\/status\/781825922647355392\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/MNuz622tNJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtmaiDqXYAAyrY3.jpg",
        "id_str" : "781825920214720512",
        "id" : 781825920214720512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtmaiDqXYAAyrY3.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/MNuz622tNJ"
      } ],
      "hashtags" : [ {
        "text" : "67P",
        "indices" : [ 5, 9 ]
      }, {
        "text" : "CometLanding",
        "indices" : [ 58, 71 ]
      }, {
        "text" : "MissionComplete",
        "indices" : [ 72, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/yiSnxDrnba",
        "expanded_url" : "http:\/\/ow.ly\/lbmc304IADE",
        "display_url" : "ow.ly\/lbmc304IADE"
      } ]
    },
    "geo" : { },
    "id_str" : "781825922647355392",
    "text" : "From #67P with love: a last image, taken 51 metres before #CometLanding #MissionComplete https:\/\/t.co\/yiSnxDrnba https:\/\/t.co\/MNuz622tNJ",
    "id" : 781825922647355392,
    "created_at" : "2016-09-30 12:00:00 +0000",
    "user" : {
      "name" : "ESA Rosetta Mission",
      "screen_name" : "ESA_Rosetta",
      "protected" : false,
      "id_str" : "253536357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000850926297\/a6286c08618d966740207142a62eda84_normal.png",
      "id" : 253536357,
      "verified" : true
    }
  },
  "id" : 781867474170019840,
  "created_at" : "2016-09-30 14:45:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781866242848198656",
  "text" : "RT @AllOnMedicare: Many Europeans spend more in a year on coffee than they ever will on out-of-pocket health care expenses. #NationalCoffee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dashboard.twitter.com\" rel=\"nofollow\"\u003ETwitter Dashboard for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalCoffeeDay",
        "indices" : [ 105, 123 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781533181036072960",
    "text" : "Many Europeans spend more in a year on coffee than they ever will on out-of-pocket health care expenses. #NationalCoffeeDay #SinglePayer",
    "id" : 781533181036072960,
    "created_at" : "2016-09-29 16:36:45 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 781866242848198656,
  "created_at" : "2016-09-30 14:40:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Harper",
      "screen_name" : "IcarusPundit",
      "indices" : [ 3, 16 ],
      "id_str" : "218205069",
      "id" : 218205069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781865935414169600",
  "text" : "RT @IcarusPundit: Friend: Busy day today?\n\nMe: Wasn\u2019t supposed to be but now I\u2019ve got to watch porn so I can keep current with the weekend\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781841888206741505",
    "text" : "Friend: Busy day today?\n\nMe: Wasn\u2019t supposed to be but now I\u2019ve got to watch porn so I can keep current with the weekend news cycle.",
    "id" : 781841888206741505,
    "created_at" : "2016-09-30 13:03:26 +0000",
    "user" : {
      "name" : "Charlie Harper",
      "screen_name" : "IcarusPundit",
      "protected" : false,
      "id_str" : "218205069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634461484978835456\/7s6HXbkH_normal.jpg",
      "id" : 218205069,
      "verified" : false
    }
  },
  "id" : 781865935414169600,
  "created_at" : "2016-09-30 14:39:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/CUd6oAjFXm",
      "expanded_url" : "http:\/\/www.cnn.com\/2016\/09\/30\/health\/rosetta-landing-comet-philae\/index.html",
      "display_url" : "cnn.com\/2016\/09\/30\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781865851335172096",
  "text" : "RT @VirgoJohnny: RIP Rosetta.  - https:\/\/t.co\/CUd6oAjFXm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/CUd6oAjFXm",
        "expanded_url" : "http:\/\/www.cnn.com\/2016\/09\/30\/health\/rosetta-landing-comet-philae\/index.html",
        "display_url" : "cnn.com\/2016\/09\/30\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781863027721240576",
    "text" : "RIP Rosetta.  - https:\/\/t.co\/CUd6oAjFXm",
    "id" : 781863027721240576,
    "created_at" : "2016-09-30 14:27:26 +0000",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 781865851335172096,
  "created_at" : "2016-09-30 14:38:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Passananti",
      "screen_name" : "MariPassananti",
      "indices" : [ 3, 18 ],
      "id_str" : "736857433",
      "id" : 736857433
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/RFnV5qopV5",
      "expanded_url" : "https:\/\/twitter.com\/B2PSeattle\/status\/781318059604733952",
      "display_url" : "twitter.com\/B2PSeattle\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781850603911835648",
  "text" : "RT @MariPassananti: Banning #books is never the answer. Such backward thinking. https:\/\/t.co\/RFnV5qopV5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 8, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/RFnV5qopV5",
        "expanded_url" : "https:\/\/twitter.com\/B2PSeattle\/status\/781318059604733952",
        "display_url" : "twitter.com\/B2PSeattle\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781485284802203648",
    "text" : "Banning #books is never the answer. Such backward thinking. https:\/\/t.co\/RFnV5qopV5",
    "id" : 781485284802203648,
    "created_at" : "2016-09-29 13:26:25 +0000",
    "user" : {
      "name" : "Mari Passananti",
      "screen_name" : "MariPassananti",
      "protected" : false,
      "id_str" : "736857433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2479228501\/2q22sszaq8nlfbviz8pl_normal.jpeg",
      "id" : 736857433,
      "verified" : false
    }
  },
  "id" : 781850603911835648,
  "created_at" : "2016-09-30 13:38:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@AdamsFlaFan",
      "screen_name" : "AdamsFlaFan",
      "indices" : [ 3, 15 ],
      "id_str" : "87957969",
      "id" : 87957969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/lQJ11k3u87",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/donald-trump-is-triggering-domestic-violence-survivors-with-textbook-abusive-behavior_us_57ed0bafe4b082aad9b959fa?ncid=engmodushpmg00000004",
      "display_url" : "huffingtonpost.com\/entry\/donald-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781849151172640769",
  "text" : "RT @AdamsFlaFan: Women who've survived abusive relationships find Trump\u2019s behavior scarily familiar https:\/\/t.co\/lQJ11k3u87 via @HuffPostWo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPostWomen",
        "screen_name" : "HuffPostWomen",
        "indices" : [ 111, 125 ],
        "id_str" : "309978842",
        "id" : 309978842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/lQJ11k3u87",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/donald-trump-is-triggering-domestic-violence-survivors-with-textbook-abusive-behavior_us_57ed0bafe4b082aad9b959fa?ncid=engmodushpmg00000004",
        "display_url" : "huffingtonpost.com\/entry\/donald-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781634922767343616",
    "text" : "Women who've survived abusive relationships find Trump\u2019s behavior scarily familiar https:\/\/t.co\/lQJ11k3u87 via @HuffPostWomen",
    "id" : 781634922767343616,
    "created_at" : "2016-09-29 23:21:02 +0000",
    "user" : {
      "name" : "@AdamsFlaFan",
      "screen_name" : "AdamsFlaFan",
      "protected" : false,
      "id_str" : "87957969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796463382484439042\/vEsf2tlG_normal.jpg",
      "id" : 87957969,
      "verified" : false
    }
  },
  "id" : 781849151172640769,
  "created_at" : "2016-09-30 13:32:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Ingraham",
      "screen_name" : "_cingraham",
      "indices" : [ 3, 14 ],
      "id_str" : "452521774",
      "id" : 452521774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/zSoIzXkNXx",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonk\/wp\/2016\/09\/27\/lawmakers-slam-obama-administrations-hasty-decision-to-ban-another-plant\/",
      "display_url" : "washingtonpost.com\/news\/wonk\/wp\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781847605051523076",
  "text" : "RT @_cingraham: This plant could lead to the \"holy grail\" of safe pain medicine. On Friday, the DEA will ban it. https:\/\/t.co\/zSoIzXkNXx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/zSoIzXkNXx",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonk\/wp\/2016\/09\/27\/lawmakers-slam-obama-administrations-hasty-decision-to-ban-another-plant\/",
        "display_url" : "washingtonpost.com\/news\/wonk\/wp\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780866706742714368",
    "text" : "This plant could lead to the \"holy grail\" of safe pain medicine. On Friday, the DEA will ban it. https:\/\/t.co\/zSoIzXkNXx",
    "id" : 780866706742714368,
    "created_at" : "2016-09-27 20:28:25 +0000",
    "user" : {
      "name" : "Christopher Ingraham",
      "screen_name" : "_cingraham",
      "protected" : false,
      "id_str" : "452521774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693120393368989696\/ozYOn95v_normal.jpg",
      "id" : 452521774,
      "verified" : true
    }
  },
  "id" : 781847605051523076,
  "created_at" : "2016-09-30 13:26:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heykim",
      "screen_name" : "heykim",
      "indices" : [ 3, 10 ],
      "id_str" : "7144882",
      "id" : 7144882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowTwitterHasChangedMyLife",
      "indices" : [ 12, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781664577746563072",
  "text" : "RT @heykim: #HowTwitterHasChangedMyLife ? I hear what people think all OVER the world, not just what is in my little corner of the world.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HowTwitterHasChangedMyLife",
        "indices" : [ 0, 27 ]
      }, {
        "text" : "NewsRealTime",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781618124126687232",
    "text" : "#HowTwitterHasChangedMyLife ? I hear what people think all OVER the world, not just what is in my little corner of the world. \n#NewsRealTime",
    "id" : 781618124126687232,
    "created_at" : "2016-09-29 22:14:17 +0000",
    "user" : {
      "name" : "heykim",
      "screen_name" : "heykim",
      "protected" : false,
      "id_str" : "7144882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581713764325593088\/WcQJ6lOJ_normal.jpg",
      "id" : 7144882,
      "verified" : false
    }
  },
  "id" : 781664577746563072,
  "created_at" : "2016-09-30 01:18:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madam Butterfly.",
      "screen_name" : "michellecheatle",
      "indices" : [ 3, 19 ],
      "id_str" : "462146942",
      "id" : 462146942
    }, {
      "name" : "Hypothyroid Mom",
      "screen_name" : "HypothyroidMom",
      "indices" : [ 94, 109 ],
      "id_str" : "842279588",
      "id" : 842279588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/rj3rmCPP1Y",
      "expanded_url" : "http:\/\/hypothyroidmom.com\/guilt-the-worst-symptom-of-chronic-illness\/",
      "display_url" : "hypothyroidmom.com\/guilt-the-wors\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781641504293064704",
  "text" : "RT @michellecheatle: Guilt: The Worst Symptom of Chronic Illness https:\/\/t.co\/rj3rmCPP1Y via @@Hypothyroidmom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hypothyroid Mom",
        "screen_name" : "HypothyroidMom",
        "indices" : [ 73, 88 ],
        "id_str" : "842279588",
        "id" : 842279588
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/rj3rmCPP1Y",
        "expanded_url" : "http:\/\/hypothyroidmom.com\/guilt-the-worst-symptom-of-chronic-illness\/",
        "display_url" : "hypothyroidmom.com\/guilt-the-wors\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781611007479341060",
    "text" : "Guilt: The Worst Symptom of Chronic Illness https:\/\/t.co\/rj3rmCPP1Y via @@Hypothyroidmom",
    "id" : 781611007479341060,
    "created_at" : "2016-09-29 21:46:00 +0000",
    "user" : {
      "name" : "Madam Butterfly.",
      "screen_name" : "michellecheatle",
      "protected" : false,
      "id_str" : "462146942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717294204699996160\/8aX0Fape_normal.jpg",
      "id" : 462146942,
      "verified" : false
    }
  },
  "id" : 781641504293064704,
  "created_at" : "2016-09-29 23:47:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trump",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781639348949254144",
  "text" : "RT @JeffreyGuterman: As I've tweeted in the past few minutes, I attribute #Trump's issue largely to an emotional problem described here: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Trump",
        "indices" : [ 53, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3l9h0Q7QDm",
        "expanded_url" : "http:\/\/bit.ly\/TrumpIsWounded",
        "display_url" : "bit.ly\/TrumpIsWounded"
      }, {
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/iKqu42aC9Q",
        "expanded_url" : "https:\/\/twitter.com\/MarshallLocke\/status\/781636180945231872",
        "display_url" : "twitter.com\/MarshallLocke\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781637346299084800",
    "text" : "As I've tweeted in the past few minutes, I attribute #Trump's issue largely to an emotional problem described here: https:\/\/t.co\/3l9h0Q7QDm https:\/\/t.co\/iKqu42aC9Q",
    "id" : 781637346299084800,
    "created_at" : "2016-09-29 23:30:40 +0000",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 781639348949254144,
  "created_at" : "2016-09-29 23:38:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Hennessy",
      "screen_name" : "LSHennessy",
      "indices" : [ 3, 14 ],
      "id_str" : "404042233",
      "id" : 404042233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trump",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781617623171731456",
  "text" : "RT @LSHennessy: Richard Rorty predicting #Trump in his 1998 book, Achieving Our Country. Message for the Left? Smug name calling not enough\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LSHennessy\/status\/780769586769567745\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/dRnwVJv0Rd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXZyMFUMAA0t31.jpg",
        "id_str" : "780769566678855680",
        "id" : 780769566678855680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXZyMFUMAA0t31.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 746
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 746
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 746
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/dRnwVJv0Rd"
      } ],
      "hashtags" : [ {
        "text" : "Trump",
        "indices" : [ 25, 31 ]
      }, {
        "text" : "USElection",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780769586769567745",
    "text" : "Richard Rorty predicting #Trump in his 1998 book, Achieving Our Country. Message for the Left? Smug name calling not enough. #USElection https:\/\/t.co\/dRnwVJv0Rd",
    "id" : 780769586769567745,
    "created_at" : "2016-09-27 14:02:30 +0000",
    "user" : {
      "name" : "Luke Hennessy",
      "screen_name" : "LSHennessy",
      "protected" : false,
      "id_str" : "404042233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793074203964518400\/yuNQlZbq_normal.jpg",
      "id" : 404042233,
      "verified" : false
    }
  },
  "id" : 781617623171731456,
  "created_at" : "2016-09-29 22:12:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle DeRusha",
      "screen_name" : "MichelleDeRusha",
      "indices" : [ 3, 19 ],
      "id_str" : "103839698",
      "id" : 103839698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/DzZrtInCWz",
      "expanded_url" : "http:\/\/ift.tt\/2cB7gfU",
      "display_url" : "ift.tt\/2cB7gfU"
    } ]
  },
  "geo" : { },
  "id_str" : "781615471539912704",
  "text" : "RT @MichelleDeRusha: Kinda loving this guy, gotta say. \n\nhttps:\/\/t.co\/DzZrtInCWz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/DzZrtInCWz",
        "expanded_url" : "http:\/\/ift.tt\/2cB7gfU",
        "display_url" : "ift.tt\/2cB7gfU"
      } ]
    },
    "geo" : { },
    "id_str" : "781614177764999168",
    "text" : "Kinda loving this guy, gotta say. \n\nhttps:\/\/t.co\/DzZrtInCWz",
    "id" : 781614177764999168,
    "created_at" : "2016-09-29 21:58:36 +0000",
    "user" : {
      "name" : "Michelle DeRusha",
      "screen_name" : "MichelleDeRusha",
      "protected" : false,
      "id_str" : "103839698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762694805079990274\/e0BiRgdw_normal.jpg",
      "id" : 103839698,
      "verified" : false
    }
  },
  "id" : 781615471539912704,
  "created_at" : "2016-09-29 22:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerard Bernacchia",
      "screen_name" : "gbernacchia1",
      "indices" : [ 3, 16 ],
      "id_str" : "3110841867",
      "id" : 3110841867
    }, {
      "name" : "The Southport Globe",
      "screen_name" : "southportglobe",
      "indices" : [ 18, 33 ],
      "id_str" : "47830370",
      "id" : 47830370
    }, {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 34, 48 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gbernacchia1\/status\/781582268930424832\/video\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/n0c01itcOo",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/781582221643747333\/pu\/img\/Kd-UIX3Lkr_pHRXU.jpg",
      "id_str" : "781582221643747333",
      "id" : 781582221643747333,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/781582221643747333\/pu\/img\/Kd-UIX3Lkr_pHRXU.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n0c01itcOo"
    } ],
    "hashtags" : [ {
      "text" : "SouthportCT",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781614999164837888",
  "text" : "RT @gbernacchia1: @southportglobe @Swanwhisperer The #SouthportCT swans back in action! https:\/\/t.co\/n0c01itcOo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Southport Globe",
        "screen_name" : "southportglobe",
        "indices" : [ 0, 15 ],
        "id_str" : "47830370",
        "id" : 47830370
      }, {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 16, 30 ],
        "id_str" : "272369448",
        "id" : 272369448
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gbernacchia1\/status\/781582268930424832\/video\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/n0c01itcOo",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/781582221643747333\/pu\/img\/Kd-UIX3Lkr_pHRXU.jpg",
        "id_str" : "781582221643747333",
        "id" : 781582221643747333,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/781582221643747333\/pu\/img\/Kd-UIX3Lkr_pHRXU.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/n0c01itcOo"
      } ],
      "hashtags" : [ {
        "text" : "SouthportCT",
        "indices" : [ 35, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781582268930424832",
    "in_reply_to_user_id" : 47830370,
    "text" : "@southportglobe @Swanwhisperer The #SouthportCT swans back in action! https:\/\/t.co\/n0c01itcOo",
    "id" : 781582268930424832,
    "created_at" : "2016-09-29 19:51:48 +0000",
    "in_reply_to_screen_name" : "southportglobe",
    "in_reply_to_user_id_str" : "47830370",
    "user" : {
      "name" : "Gerard Bernacchia",
      "screen_name" : "gbernacchia1",
      "protected" : false,
      "id_str" : "3110841867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607354643539095553\/NrVSEO2x_normal.jpg",
      "id" : 3110841867,
      "verified" : false
    }
  },
  "id" : 781614999164837888,
  "created_at" : "2016-09-29 22:01:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ListenTo",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "ethics",
      "indices" : [ 45, 52 ]
    }, {
      "text" : "think",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/85G87jJmzt",
      "expanded_url" : "https:\/\/anchor.fm\/w\/A1A15B",
      "display_url" : "anchor.fm\/w\/A1A15B"
    } ]
  },
  "geo" : { },
  "id_str" : "781597818624610305",
  "text" : "#ListenTo \"Hulk Hogan, ethics and alignment. #ethics #think\" \u2693 https:\/\/t.co\/85G87jJmzt",
  "id" : 781597818624610305,
  "created_at" : "2016-09-29 20:53:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 3, 18 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781587932541030400",
  "text" : "RT @ThatOtherChris: Trump's new attack on Hillary is \"Follow the money.\" Probably not something you want to bring up when you refuse to rel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TaxReturns",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781587508316561409",
    "text" : "Trump's new attack on Hillary is \"Follow the money.\" Probably not something you want to bring up when you refuse to release your #TaxReturns",
    "id" : 781587508316561409,
    "created_at" : "2016-09-29 20:12:37 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "protected" : false,
      "id_str" : "466879335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000251177786\/3835313b348120cb52a53973e58d692a_normal.jpeg",
      "id" : 466879335,
      "verified" : false
    }
  },
  "id" : 781587932541030400,
  "created_at" : "2016-09-29 20:14:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781587704811253766",
  "text" : "finished The Secret History by Donna Tartt last night. was so good. #audiobook",
  "id" : 781587704811253766,
  "created_at" : "2016-09-29 20:13:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "indices" : [ 3, 18 ],
      "id_str" : "32522055",
      "id" : 32522055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverTrump",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781575747857244162",
  "text" : "RT @Kris_Sacrebleu: The answer Trump gave in the debate to a question about how we should deal with cyber security threats \uD83D\uDE33 #NeverTrump ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kris_Sacrebleu\/status\/781554915424350208\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/i0j0LqNglq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtikDHYVMAAz30W.jpg",
        "id_str" : "781554908776443904",
        "id" : 781554908776443904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtikDHYVMAAz30W.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/i0j0LqNglq"
      } ],
      "hashtags" : [ {
        "text" : "NeverTrump",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781554915424350208",
    "text" : "The answer Trump gave in the debate to a question about how we should deal with cyber security threats \uD83D\uDE33 #NeverTrump https:\/\/t.co\/i0j0LqNglq",
    "id" : 781554915424350208,
    "created_at" : "2016-09-29 18:03:07 +0000",
    "user" : {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "protected" : false,
      "id_str" : "32522055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797097618245459968\/x-mwuPEt_normal.jpg",
      "id" : 32522055,
      "verified" : false
    }
  },
  "id" : 781575747857244162,
  "created_at" : "2016-09-29 19:25:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/781575096410447872\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/QbKuGo8irX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cti2aBTW8AABvjl.jpg",
      "id_str" : "781575093491265536",
      "id" : 781575093491265536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cti2aBTW8AABvjl.jpg",
      "sizes" : [ {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/QbKuGo8irX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/H8E3MqrARj",
      "expanded_url" : "https:\/\/dhillonauthor.wordpress.com\/2016\/08\/29\/210?_ts=1475176994",
      "display_url" : "dhillonauthor.wordpress.com\/2016\/08\/29\/210\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781575096410447872",
  "text" : "Truth and Our Packages of Deception https:\/\/t.co\/H8E3MqrARj https:\/\/t.co\/QbKuGo8irX",
  "id" : 781575096410447872,
  "created_at" : "2016-09-29 19:23:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/eeubWfwzdT",
      "expanded_url" : "https:\/\/dhillonauthor.wordpress.com\/2016\/08\/29\/210\/",
      "display_url" : "dhillonauthor.wordpress.com\/2016\/08\/29\/210\/"
    } ]
  },
  "geo" : { },
  "id_str" : "781574766197141504",
  "text" : "explains how I feel re: election.. &gt; Truth and Our Packages of Deception https:\/\/t.co\/eeubWfwzdT",
  "id" : 781574766197141504,
  "created_at" : "2016-09-29 19:21:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thyroid & Hashimotos",
      "screen_name" : "OutsmartDisease",
      "indices" : [ 3, 19 ],
      "id_str" : "254768478",
      "id" : 254768478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "hormones",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3e4QbS5dac",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BK8zpT6DLGF\/",
      "display_url" : "instagram.com\/p\/BK8zpT6DLGF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "781574485950562304",
  "text" : "RT @OutsmartDisease: Sorry my #thyroid #hormones make me psychotic... Many of today\u2019s common mental problems can be\u2026 https:\/\/t.co\/3e4QbS5dac",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thyroid",
        "indices" : [ 9, 17 ]
      }, {
        "text" : "hormones",
        "indices" : [ 18, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/3e4QbS5dac",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BK8zpT6DLGF\/",
        "display_url" : "instagram.com\/p\/BK8zpT6DLGF\/"
      } ]
    },
    "geo" : { },
    "id_str" : "781563172662763520",
    "text" : "Sorry my #thyroid #hormones make me psychotic... Many of today\u2019s common mental problems can be\u2026 https:\/\/t.co\/3e4QbS5dac",
    "id" : 781563172662763520,
    "created_at" : "2016-09-29 18:35:55 +0000",
    "user" : {
      "name" : "Thyroid & Hashimotos",
      "screen_name" : "OutsmartDisease",
      "protected" : false,
      "id_str" : "254768478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611733876688314368\/Sg41xZSU_normal.jpg",
      "id" : 254768478,
      "verified" : false
    }
  },
  "id" : 781574485950562304,
  "created_at" : "2016-09-29 19:20:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/93ZkBk6rYg",
      "expanded_url" : "http:\/\/on.natgeo.com\/2didqmS",
      "display_url" : "on.natgeo.com\/2didqmS"
    } ]
  },
  "geo" : { },
  "id_str" : "781569245905883137",
  "text" : "RT @NatGeo: Enchanting photos capture the sense that something magical is just a step away\nhttps:\/\/t.co\/93ZkBk6rYg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/93ZkBk6rYg",
        "expanded_url" : "http:\/\/on.natgeo.com\/2didqmS",
        "display_url" : "on.natgeo.com\/2didqmS"
      } ]
    },
    "geo" : { },
    "id_str" : "779749781434425344",
    "text" : "Enchanting photos capture the sense that something magical is just a step away\nhttps:\/\/t.co\/93ZkBk6rYg",
    "id" : 779749781434425344,
    "created_at" : "2016-09-24 18:30:09 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 781569245905883137,
  "created_at" : "2016-09-29 19:00:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Bach",
      "screen_name" : "sebastianbach",
      "indices" : [ 3, 17 ],
      "id_str" : "17450410",
      "id" : 17450410
    }, {
      "name" : "HarperCollins",
      "screen_name" : "HarperCollins",
      "indices" : [ 75, 89 ],
      "id_str" : "46696817",
      "id" : 46696817
    }, {
      "name" : "Dey Street Books",
      "screen_name" : "deystreet",
      "indices" : [ 90, 100 ],
      "id_str" : "22185670",
      "id" : 22185670
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "18andLIFEonSkidRow",
      "indices" : [ 36, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781564875357192192",
  "text" : "RT @sebastianbach: Get ready Planet #18andLIFEonSkidRow IN STORES DEC 6 on @HarperCollins @deystreet Recording Audio Book Now! Trying not t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HarperCollins",
        "screen_name" : "HarperCollins",
        "indices" : [ 56, 70 ],
        "id_str" : "46696817",
        "id" : 46696817
      }, {
        "name" : "Dey Street Books",
        "screen_name" : "deystreet",
        "indices" : [ 71, 81 ],
        "id_str" : "22185670",
        "id" : 22185670
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sebastianbach\/status\/780846501299793920\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/ijMswevSqP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtYfuZHUkAAqYcQ.jpg",
        "id_str" : "780846467271397376",
        "id" : 780846467271397376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtYfuZHUkAAqYcQ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/ijMswevSqP"
      } ],
      "hashtags" : [ {
        "text" : "18andLIFEonSkidRow",
        "indices" : [ 17, 36 ]
      }, {
        "text" : "Rock",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "Bio",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780846501299793920",
    "text" : "Get ready Planet #18andLIFEonSkidRow IN STORES DEC 6 on @HarperCollins @deystreet Recording Audio Book Now! Trying not to \uD83D\uDE02!! #Rock #Bio \u270C\uFE0F\uFE0F https:\/\/t.co\/ijMswevSqP",
    "id" : 780846501299793920,
    "created_at" : "2016-09-27 19:08:07 +0000",
    "user" : {
      "name" : "Sebastian Bach",
      "screen_name" : "sebastianbach",
      "protected" : false,
      "id_str" : "17450410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742272380215689217\/BtP8vWXA_normal.jpg",
      "id" : 17450410,
      "verified" : true
    }
  },
  "id" : 781564875357192192,
  "created_at" : "2016-09-29 18:42:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "indices" : [ 3, 16 ],
      "id_str" : "84714448",
      "id" : 84714448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781564452852424704",
  "text" : "RT @Thinking_mom: USA has FORGOTTEN and DENIED we are all CITIZENS first. Civilians, soldiers, police, students, black people. ALL CITIZENS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781564161780224000",
    "text" : "USA has FORGOTTEN and DENIED we are all CITIZENS first. Civilians, soldiers, police, students, black people. ALL CITIZENS. CITIZENS y'all.",
    "id" : 781564161780224000,
    "created_at" : "2016-09-29 18:39:51 +0000",
    "user" : {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "protected" : false,
      "id_str" : "84714448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792761883749154816\/N4CNeldE_normal.jpg",
      "id" : 84714448,
      "verified" : false
    }
  },
  "id" : 781564452852424704,
  "created_at" : "2016-09-29 18:41:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seeprevioustweet",
      "indices" : [ 39, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781564312049618944",
  "text" : "wouldnt mind that on Hillary as well.. #seeprevioustweet",
  "id" : 781564312049618944,
  "created_at" : "2016-09-29 18:40:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "indices" : [ 3, 16 ],
      "id_str" : "84714448",
      "id" : 84714448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781563812931629057",
  "text" : "RT @Thinking_mom: Family Sues After 7-Year-Old Gets Handcuffed At School For Crying.\/ Demilitarize the schools &amp; the police. https:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/1nV2q8cmc1",
        "expanded_url" : "http:\/\/m.huffpost.com\/us\/entry\/us_57d9b706e4b04a1497b23f1b",
        "display_url" : "m.huffpost.com\/us\/entry\/us_57\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781562491000225793",
    "text" : "Family Sues After 7-Year-Old Gets Handcuffed At School For Crying.\/ Demilitarize the schools &amp; the police. https:\/\/t.co\/1nV2q8cmc1?",
    "id" : 781562491000225793,
    "created_at" : "2016-09-29 18:33:13 +0000",
    "user" : {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "protected" : false,
      "id_str" : "84714448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792761883749154816\/N4CNeldE_normal.jpg",
      "id" : 84714448,
      "verified" : false
    }
  },
  "id" : 781563812931629057,
  "created_at" : "2016-09-29 18:38:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Griffin",
      "screen_name" : "kylegriffin1",
      "indices" : [ 0, 13 ],
      "id_str" : "32871086",
      "id" : 32871086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781251501947748352",
  "geo" : { },
  "id_str" : "781563700255854592",
  "in_reply_to_user_id" : 32871086,
  "text" : "@kylegriffin1 someone should make a website with all these quotes as well as links to all things he did say but then denied, etc.",
  "id" : 781563700255854592,
  "in_reply_to_status_id" : 781251501947748352,
  "created_at" : "2016-09-29 18:38:01 +0000",
  "in_reply_to_screen_name" : "kylegriffin1",
  "in_reply_to_user_id_str" : "32871086",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "relombardo",
      "screen_name" : "relombardo3",
      "indices" : [ 3, 15 ],
      "id_str" : "3220025137",
      "id" : 3220025137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoDAPL",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781560683242655744",
  "text" : "RT @relombardo3: How Could This Ever Be Okay?\nThey Want To Put One Of These In An American River\n18 Million People Drink From.\n#NoDAPL #Rez\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/relombardo3\/status\/779177804147544064\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/9gPuEMj7Z0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtAyFEHUsAASdIN.jpg",
        "id_str" : "779177798120288256",
        "id" : 779177798120288256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtAyFEHUsAASdIN.jpg",
        "sizes" : [ {
          "h" : 648,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/9gPuEMj7Z0"
      } ],
      "hashtags" : [ {
        "text" : "NoDAPL",
        "indices" : [ 110, 117 ]
      }, {
        "text" : "RezpectOurWater",
        "indices" : [ 118, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779177804147544064",
    "text" : "How Could This Ever Be Okay?\nThey Want To Put One Of These In An American River\n18 Million People Drink From.\n#NoDAPL #RezpectOurWater \uD83C\uDF32\uD83D\uDC3B\uD83C\uDF33\uD83D\uDC34\uD83D\uDCA7 https:\/\/t.co\/9gPuEMj7Z0",
    "id" : 779177804147544064,
    "created_at" : "2016-09-23 04:37:19 +0000",
    "user" : {
      "name" : "relombardo",
      "screen_name" : "relombardo3",
      "protected" : false,
      "id_str" : "3220025137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797688829985464321\/rCjx0xn2_normal.jpg",
      "id" : 3220025137,
      "verified" : false
    }
  },
  "id" : 781560683242655744,
  "created_at" : "2016-09-29 18:26:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/FxpgN5VFuH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LJSH6Ru1xRk&feature=share",
      "display_url" : "youtube.com\/watch?v=LJSH6R\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781560421044092928",
  "text" : "RT @neiltyson: Evidence that internet Cats are rapidly achieving cosmic consciousness, soon to become our Overlords: https:\/\/t.co\/FxpgN5VFuH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/FxpgN5VFuH",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LJSH6Ru1xRk&feature=share",
        "display_url" : "youtube.com\/watch?v=LJSH6R\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781423019218567169",
    "text" : "Evidence that internet Cats are rapidly achieving cosmic consciousness, soon to become our Overlords: https:\/\/t.co\/FxpgN5VFuH",
    "id" : 781423019218567169,
    "created_at" : "2016-09-29 09:19:00 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 781560421044092928,
  "created_at" : "2016-09-29 18:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 3, 14 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/OIfgsd2uII",
      "expanded_url" : "https:\/\/twitter.com\/Alltech\/status\/781501295077298177",
      "display_url" : "twitter.com\/Alltech\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781553795394330624",
  "text" : "RT @PVickerton: Interesting point..... https:\/\/t.co\/OIfgsd2uII",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/OIfgsd2uII",
        "expanded_url" : "https:\/\/twitter.com\/Alltech\/status\/781501295077298177",
        "display_url" : "twitter.com\/Alltech\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781529569094471680",
    "text" : "Interesting point..... https:\/\/t.co\/OIfgsd2uII",
    "id" : 781529569094471680,
    "created_at" : "2016-09-29 16:22:24 +0000",
    "user" : {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "protected" : false,
      "id_str" : "1046103560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773840339463438336\/-PvOKg0h_normal.jpg",
      "id" : 1046103560,
      "verified" : false
    }
  },
  "id" : 781553795394330624,
  "created_at" : "2016-09-29 17:58:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paula",
      "screen_name" : "DairyFarmher",
      "indices" : [ 3, 16 ],
      "id_str" : "2202345092",
      "id" : 2202345092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "backscratchers",
      "indices" : [ 54, 69 ]
    }, {
      "text" : "pamperedcalf",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "farmlife",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/YTLYjpRi4N",
      "expanded_url" : "https:\/\/twitter.com\/BrubakerDan\/status\/781491814759075841",
      "display_url" : "twitter.com\/BrubakerDan\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781552950611247105",
  "text" : "RT @DairyFarmher: I love these little calf brushes...\n#backscratchers #pamperedcalf #farmlife https:\/\/t.co\/YTLYjpRi4N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "backscratchers",
        "indices" : [ 36, 51 ]
      }, {
        "text" : "pamperedcalf",
        "indices" : [ 52, 65 ]
      }, {
        "text" : "farmlife",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/YTLYjpRi4N",
        "expanded_url" : "https:\/\/twitter.com\/BrubakerDan\/status\/781491814759075841",
        "display_url" : "twitter.com\/BrubakerDan\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781493855946436608",
    "text" : "I love these little calf brushes...\n#backscratchers #pamperedcalf #farmlife https:\/\/t.co\/YTLYjpRi4N",
    "id" : 781493855946436608,
    "created_at" : "2016-09-29 14:00:29 +0000",
    "user" : {
      "name" : "Paula",
      "screen_name" : "DairyFarmher",
      "protected" : false,
      "id_str" : "2202345092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627463503411068928\/Z6jtiQKv_normal.jpg",
      "id" : 2202345092,
      "verified" : false
    }
  },
  "id" : 781552950611247105,
  "created_at" : "2016-09-29 17:55:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "feedly",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/hPOsjkdjrA",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/yo-america-maine-already-tried-the-whole-trump-thing-it-didnt-work\/",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781545971851358208",
  "text" : "Yo, America: Maine Already Tried The Whole Trump Thing. It Didn\u2019t Work. https:\/\/t.co\/hPOsjkdjrA #religion #feedly",
  "id" : 781545971851358208,
  "created_at" : "2016-09-29 17:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 112, 121 ]
    }, {
      "text" : "feedly",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/8Pq6oEGZ1f",
      "expanded_url" : "https:\/\/brucegerencser.net\/2016\/09\/liar-liar-pants-fire-ken-ham-lies-secularists-wanting-ban-christianity\/",
      "display_url" : "brucegerencser.net\/2016\/09\/liar-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781545548629307393",
  "text" : "Liar, Liar, Pants on Fire: Ken Ham Lies About Secularists Wanting to \u2018Ban\u2019 Christianity https:\/\/t.co\/8Pq6oEGZ1f #religion #feedly",
  "id" : 781545548629307393,
  "created_at" : "2016-09-29 17:25:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Dworkin",
      "screen_name" : "DemFromCT",
      "indices" : [ 107, 117 ],
      "id_str" : "19087651",
      "id" : 19087651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/3gHG2HWFyV",
      "expanded_url" : "https:\/\/storify.com\/DemFromCT\/arielle-brousse-on-donald-trump-atlantic-city-and-",
      "display_url" : "storify.com\/DemFromCT\/arie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781532453727039488",
  "text" : "Arielle Brousse on Donald Trump and the price extracted by a deadbeat employer https:\/\/t.co\/3gHG2HWFyV via @demfromct",
  "id" : 781532453727039488,
  "created_at" : "2016-09-29 16:33:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/9kTzTcWr4l",
      "expanded_url" : "https:\/\/twitter.com\/LeilaniMunter\/status\/781256978270187520",
      "display_url" : "twitter.com\/LeilaniMunter\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781531615608594432",
  "text" : "why does this make me so sad? https:\/\/t.co\/9kTzTcWr4l",
  "id" : 781531615608594432,
  "created_at" : "2016-09-29 16:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Beverly",
      "screen_name" : "jaredbeverly",
      "indices" : [ 3, 16 ],
      "id_str" : "20893330",
      "id" : 20893330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781527355877650432",
  "text" : "RT @jaredbeverly: The Hebrew Bible blogosphere is really freaking out about the ESV Permanent Text's weird translation of Gen 3:16.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780843782820466693",
    "text" : "The Hebrew Bible blogosphere is really freaking out about the ESV Permanent Text's weird translation of Gen 3:16.",
    "id" : 780843782820466693,
    "created_at" : "2016-09-27 18:57:19 +0000",
    "user" : {
      "name" : "Jared Beverly",
      "screen_name" : "jaredbeverly",
      "protected" : false,
      "id_str" : "20893330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614460342588956672\/hfK9Rr1Q_normal.jpg",
      "id" : 20893330,
      "verified" : false
    }
  },
  "id" : 781527355877650432,
  "created_at" : "2016-09-29 16:13:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Alsup",
      "screen_name" : "WendyAlsup",
      "indices" : [ 3, 14 ],
      "id_str" : "418049696",
      "id" : 418049696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781527287686631424",
  "text" : "RT @WendyAlsup: We have intimate knowledge of how misreading Scripture affects the lives of women we disciple. On recent ESV changes https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1PLEXiKQQL",
        "expanded_url" : "http:\/\/theologyforwomen.org\/2016\/09\/toward-better-reading-reflections-permanent-changes-text-genesis-316-esv.html",
        "display_url" : "theologyforwomen.org\/2016\/09\/toward\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780535561127813120",
    "text" : "We have intimate knowledge of how misreading Scripture affects the lives of women we disciple. On recent ESV changes https:\/\/t.co\/1PLEXiKQQL",
    "id" : 780535561127813120,
    "created_at" : "2016-09-26 22:32:34 +0000",
    "user" : {
      "name" : "Wendy Alsup",
      "screen_name" : "WendyAlsup",
      "protected" : false,
      "id_str" : "418049696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677290344862474240\/Y3w91UEV_normal.jpg",
      "id" : 418049696,
      "verified" : false
    }
  },
  "id" : 781527287686631424,
  "created_at" : "2016-09-29 16:13:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaudete Theology",
      "screen_name" : "VictoriaGaile",
      "indices" : [ 3, 17 ],
      "id_str" : "1118366714",
      "id" : 1118366714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781526418580705280",
  "text" : "RT @VictoriaGaile: For, Against, or Absent? Gen 3:16 &amp; the Case of the Missing Desire\nor,\nThe controversial ESV translation&amp;the Vulgate\nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/uRxamPCdTN",
        "expanded_url" : "https:\/\/bltnotjustasandwich.com\/2016\/09\/27\/for-against-or-absent-gen-316-and-the-case-of-the-missing-desire\/",
        "display_url" : "bltnotjustasandwich.com\/2016\/09\/27\/for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780959570575368192",
    "text" : "For, Against, or Absent? Gen 3:16 &amp; the Case of the Missing Desire\nor,\nThe controversial ESV translation&amp;the Vulgate\nhttps:\/\/t.co\/uRxamPCdTN",
    "id" : 780959570575368192,
    "created_at" : "2016-09-28 02:37:25 +0000",
    "user" : {
      "name" : "Gaudete Theology",
      "screen_name" : "VictoriaGaile",
      "protected" : false,
      "id_str" : "1118366714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538558983783464960\/ayPUg5W__normal.png",
      "id" : 1118366714,
      "verified" : false
    }
  },
  "id" : 781526418580705280,
  "created_at" : "2016-09-29 16:09:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Wooten",
      "screen_name" : "QuakerKathleen",
      "indices" : [ 3, 18 ],
      "id_str" : "149359194",
      "id" : 149359194
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/QuakerKathleen\/status\/781263135479066624\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/4edmo9fEU3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctearh1WgAEhH64.jpg",
      "id_str" : "781263132979265537",
      "id" : 781263132979265537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctearh1WgAEhH64.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/4edmo9fEU3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/DHQZxaMK0w",
      "expanded_url" : "http:\/\/ift.tt\/2db114V",
      "display_url" : "ift.tt\/2db114V"
    } ]
  },
  "geo" : { },
  "id_str" : "781269323906158592",
  "text" : "RT @QuakerKathleen: https:\/\/t.co\/DHQZxaMK0w https:\/\/t.co\/4edmo9fEU3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/QuakerKathleen\/status\/781263135479066624\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/4edmo9fEU3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctearh1WgAEhH64.jpg",
        "id_str" : "781263132979265537",
        "id" : 781263132979265537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctearh1WgAEhH64.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4edmo9fEU3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/DHQZxaMK0w",
        "expanded_url" : "http:\/\/ift.tt\/2db114V",
        "display_url" : "ift.tt\/2db114V"
      } ]
    },
    "geo" : { },
    "id_str" : "781263135479066624",
    "text" : "https:\/\/t.co\/DHQZxaMK0w https:\/\/t.co\/4edmo9fEU3",
    "id" : 781263135479066624,
    "created_at" : "2016-09-28 22:43:41 +0000",
    "user" : {
      "name" : "Kathleen Wooten",
      "screen_name" : "QuakerKathleen",
      "protected" : false,
      "id_str" : "149359194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786649375812517888\/goyy1ufQ_normal.jpg",
      "id" : 149359194,
      "verified" : false
    }
  },
  "id" : 781269323906158592,
  "created_at" : "2016-09-28 23:08:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baby Animal",
      "screen_name" : "babyaniimal",
      "indices" : [ 3, 15 ],
      "id_str" : "3980906953",
      "id" : 3980906953
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/watchmewhile\/status\/769610840488157184\/video\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/cJCpvFXgDz",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769610457791492096\/pu\/img\/OxPws70RLidSEW0p.jpg",
      "id_str" : "769610457791492096",
      "id" : 769610457791492096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769610457791492096\/pu\/img\/OxPws70RLidSEW0p.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cJCpvFXgDz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781268725177679874",
  "text" : "RT @babyaniimal: Watch these Rats Play Basketball.. its so damn Cute.... \uD83D\uDE0D\uD83D\uDE18\uD83D\uDC01\uD83C\uDFC0 https:\/\/t.co\/cJCpvFXgDz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/watchmewhile\/status\/769610840488157184\/video\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/cJCpvFXgDz",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769610457791492096\/pu\/img\/OxPws70RLidSEW0p.jpg",
        "id_str" : "769610457791492096",
        "id" : 769610457791492096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/769610457791492096\/pu\/img\/OxPws70RLidSEW0p.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cJCpvFXgDz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780746916967518210",
    "text" : "Watch these Rats Play Basketball.. its so damn Cute.... \uD83D\uDE0D\uD83D\uDE18\uD83D\uDC01\uD83C\uDFC0 https:\/\/t.co\/cJCpvFXgDz",
    "id" : 780746916967518210,
    "created_at" : "2016-09-27 12:32:25 +0000",
    "user" : {
      "name" : "Baby Animal",
      "screen_name" : "babyaniimal",
      "protected" : false,
      "id_str" : "3980906953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775573291763240960\/_NmQ88-g_normal.jpg",
      "id" : 3980906953,
      "verified" : false
    }
  },
  "id" : 781268725177679874,
  "created_at" : "2016-09-28 23:05:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McKay Coppins",
      "screen_name" : "mckaycoppins",
      "indices" : [ 3, 16 ],
      "id_str" : "21431618",
      "id" : 21431618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781267856679923717",
  "text" : "RT @mckaycoppins: Eric Trump commends his father for the \"courage\" it took not to mention Bill Clinton's infidelity during the debate. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/frKO76KTf8",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/christophermassie\/eric-trump-it-took-courage-for-my-dad-to-not-mention-bill-cl?utm_term=.wymYwAVEy#.egkEbdDpG",
        "display_url" : "buzzfeed.com\/christophermas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781162059341914112",
    "text" : "Eric Trump commends his father for the \"courage\" it took not to mention Bill Clinton's infidelity during the debate. https:\/\/t.co\/frKO76KTf8",
    "id" : 781162059341914112,
    "created_at" : "2016-09-28 16:02:02 +0000",
    "user" : {
      "name" : "McKay Coppins",
      "screen_name" : "mckaycoppins",
      "protected" : false,
      "id_str" : "21431618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762141316671270912\/YTzkq7jG_normal.jpg",
      "id" : 21431618,
      "verified" : true
    }
  },
  "id" : 781267856679923717,
  "created_at" : "2016-09-28 23:02:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeet Heer",
      "screen_name" : "HeerJeet",
      "indices" : [ 3, 12 ],
      "id_str" : "604940737",
      "id" : 604940737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781259626968940546",
  "text" : "RT @HeerJeet: A bit worrying if you are agonistic, atheist, Muslim, Hindu, Jew, Buddhist, Sikh, or even, God forbid, a liberal Christian. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/LNeVFORkFK",
        "expanded_url" : "https:\/\/twitter.com\/jameshohmann\/status\/781236370194984960",
        "display_url" : "twitter.com\/jameshohmann\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781244457874132993",
    "text" : "A bit worrying if you are agonistic, atheist, Muslim, Hindu, Jew, Buddhist, Sikh, or even, God forbid, a liberal Christian. https:\/\/t.co\/LNeVFORkFK",
    "id" : 781244457874132993,
    "created_at" : "2016-09-28 21:29:28 +0000",
    "user" : {
      "name" : "Jeet Heer",
      "screen_name" : "HeerJeet",
      "protected" : false,
      "id_str" : "604940737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771802394195668992\/sdiSWCGC_normal.jpg",
      "id" : 604940737,
      "verified" : true
    }
  },
  "id" : 781259626968940546,
  "created_at" : "2016-09-28 22:29:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    }, {
      "name" : "Jordan VandeGiessen",
      "screen_name" : "JordanVandeGie1",
      "indices" : [ 15, 31 ],
      "id_str" : "3262628426",
      "id" : 3262628426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781246188267925504",
  "geo" : { },
  "id_str" : "781247370721886208",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist @JordanVandeGie1 but xtians see it as a choice, not part of who you are.. thats the thing.",
  "id" : 781247370721886208,
  "in_reply_to_status_id" : 781246188267925504,
  "created_at" : "2016-09-28 21:41:02 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenda Hadenfeldt",
      "screen_name" : "BrendaJH1",
      "indices" : [ 3, 13 ],
      "id_str" : "514801532",
      "id" : 514801532
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BrendaJH1\/status\/780944588311703552\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/3zda5ar5aa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZ41MRUEAA_hZR.jpg",
      "id_str" : "780944440617603072",
      "id" : 780944440617603072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZ41MRUEAA_hZR.jpg",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 1374
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 1374
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3zda5ar5aa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/o95hXNSqE6",
      "expanded_url" : "http:\/\/azc.cc\/2diKeew",
      "display_url" : "azc.cc\/2diKeew"
    } ]
  },
  "geo" : { },
  "id_str" : "781246234011074560",
  "text" : "RT @BrendaJH1: From the Arizona Republic endorsement. https:\/\/t.co\/o95hXNSqE6 https:\/\/t.co\/3zda5ar5aa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrendaJH1\/status\/780944588311703552\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/3zda5ar5aa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZ41MRUEAA_hZR.jpg",
        "id_str" : "780944440617603072",
        "id" : 780944440617603072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZ41MRUEAA_hZR.jpg",
        "sizes" : [ {
          "h" : 189,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 1374
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 1374
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/3zda5ar5aa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/o95hXNSqE6",
        "expanded_url" : "http:\/\/azc.cc\/2diKeew",
        "display_url" : "azc.cc\/2diKeew"
      } ]
    },
    "in_reply_to_status_id_str" : "780944052329910272",
    "geo" : { },
    "id_str" : "780944588311703552",
    "in_reply_to_user_id" : 514801532,
    "text" : "From the Arizona Republic endorsement. https:\/\/t.co\/o95hXNSqE6 https:\/\/t.co\/3zda5ar5aa",
    "id" : 780944588311703552,
    "in_reply_to_status_id" : 780944052329910272,
    "created_at" : "2016-09-28 01:37:53 +0000",
    "in_reply_to_screen_name" : "BrendaJH1",
    "in_reply_to_user_id_str" : "514801532",
    "user" : {
      "name" : "Brenda Hadenfeldt",
      "screen_name" : "BrendaJH1",
      "protected" : false,
      "id_str" : "514801532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1873102428\/6247581224_9683431b97_o_normal.jpg",
      "id" : 514801532,
      "verified" : false
    }
  },
  "id" : 781246234011074560,
  "created_at" : "2016-09-28 21:36:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781246106286100480",
  "text" : "RT @ZachsMind: Rich ppl warning of a real estate bubble are inventing prophecy. They want desperate ppl to respond so they can profit from\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781245591774859264",
    "text" : "Rich ppl warning of a real estate bubble are inventing prophecy. They want desperate ppl to respond so they can profit from others' failure.",
    "id" : 781245591774859264,
    "created_at" : "2016-09-28 21:33:58 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 781246106286100480,
  "created_at" : "2016-09-28 21:36:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "indices" : [ 3, 18 ],
      "id_str" : "201574313",
      "id" : 201574313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781203151621939200",
  "text" : "RT @TheInsaneRobin: This never would have happened to me because I'm white. He called the cops asking for help and got treated like a crimi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781109354116284416",
    "geo" : { },
    "id_str" : "781110483042627584",
    "in_reply_to_user_id" : 201574313,
    "text" : "This never would have happened to me because I'm white. He called the cops asking for help and got treated like a criminal.",
    "id" : 781110483042627584,
    "in_reply_to_status_id" : 781109354116284416,
    "created_at" : "2016-09-28 12:37:06 +0000",
    "in_reply_to_screen_name" : "TheInsaneRobin",
    "in_reply_to_user_id_str" : "201574313",
    "user" : {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "protected" : false,
      "id_str" : "201574313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785505299792859136\/VDG0NzyF_normal.jpg",
      "id" : 201574313,
      "verified" : false
    }
  },
  "id" : 781203151621939200,
  "created_at" : "2016-09-28 18:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "indices" : [ 3, 18 ],
      "id_str" : "201574313",
      "id" : 201574313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781203093308469248",
  "text" : "RT @TheInsaneRobin: They then allow him to go get his car and the window is broken in. It was exactly where the app said.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781109354116284416",
    "geo" : { },
    "id_str" : "781110345712672768",
    "in_reply_to_user_id" : 201574313,
    "text" : "They then allow him to go get his car and the window is broken in. It was exactly where the app said.",
    "id" : 781110345712672768,
    "in_reply_to_status_id" : 781109354116284416,
    "created_at" : "2016-09-28 12:36:33 +0000",
    "in_reply_to_screen_name" : "TheInsaneRobin",
    "in_reply_to_user_id_str" : "201574313",
    "user" : {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "protected" : false,
      "id_str" : "201574313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785505299792859136\/VDG0NzyF_normal.jpg",
      "id" : 201574313,
      "verified" : false
    }
  },
  "id" : 781203093308469248,
  "created_at" : "2016-09-28 18:45:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "indices" : [ 3, 18 ],
      "id_str" : "201574313",
      "id" : 201574313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781203050061033472",
  "text" : "RT @TheInsaneRobin: They process him and take his fingerprints. He gets to call his mom and she raises hell. After a long time they let him\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781109354116284416",
    "geo" : { },
    "id_str" : "781110142725152768",
    "in_reply_to_user_id" : 201574313,
    "text" : "They process him and take his fingerprints. He gets to call his mom and she raises hell. After a long time they let him go.",
    "id" : 781110142725152768,
    "in_reply_to_status_id" : 781109354116284416,
    "created_at" : "2016-09-28 12:35:45 +0000",
    "in_reply_to_screen_name" : "TheInsaneRobin",
    "in_reply_to_user_id_str" : "201574313",
    "user" : {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "protected" : false,
      "id_str" : "201574313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785505299792859136\/VDG0NzyF_normal.jpg",
      "id" : 201574313,
      "verified" : false
    }
  },
  "id" : 781203050061033472,
  "created_at" : "2016-09-28 18:44:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "indices" : [ 3, 18 ],
      "id_str" : "201574313",
      "id" : 201574313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781203001805529088",
  "text" : "RT @TheInsaneRobin: He shows them on his phone exactly where his car is. They don't believe him so they put him in the squad car and take h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781109354116284416",
    "geo" : { },
    "id_str" : "781109935912476672",
    "in_reply_to_user_id" : 201574313,
    "text" : "He shows them on his phone exactly where his car is. They don't believe him so they put him in the squad car and take him in.",
    "id" : 781109935912476672,
    "in_reply_to_status_id" : 781109354116284416,
    "created_at" : "2016-09-28 12:34:55 +0000",
    "in_reply_to_screen_name" : "TheInsaneRobin",
    "in_reply_to_user_id_str" : "201574313",
    "user" : {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "protected" : false,
      "id_str" : "201574313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785505299792859136\/VDG0NzyF_normal.jpg",
      "id" : 201574313,
      "verified" : false
    }
  },
  "id" : 781203001805529088,
  "created_at" : "2016-09-28 18:44:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "indices" : [ 3, 18 ],
      "id_str" : "201574313",
      "id" : 201574313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781202964195205120",
  "text" : "RT @TheInsaneRobin: Cops arrive and immediately frisk him. They ask him if he's on drugs. He tries to tell them that he just wants his car\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781109550174830592",
    "geo" : { },
    "id_str" : "781109720681701376",
    "in_reply_to_user_id" : 201574313,
    "text" : "Cops arrive and immediately frisk him. They ask him if he's on drugs. He tries to tell them that he just wants his car back.",
    "id" : 781109720681701376,
    "in_reply_to_status_id" : 781109550174830592,
    "created_at" : "2016-09-28 12:34:04 +0000",
    "in_reply_to_screen_name" : "TheInsaneRobin",
    "in_reply_to_user_id_str" : "201574313",
    "user" : {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "protected" : false,
      "id_str" : "201574313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785505299792859136\/VDG0NzyF_normal.jpg",
      "id" : 201574313,
      "verified" : false
    }
  },
  "id" : 781202964195205120,
  "created_at" : "2016-09-28 18:44:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "indices" : [ 3, 18 ],
      "id_str" : "201574313",
      "id" : 201574313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781202926945665024",
  "text" : "RT @TheInsaneRobin: Groceries in hand he checks his LoJack app first and can see that its moving down the road.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781109354116284416",
    "geo" : { },
    "id_str" : "781109550174830592",
    "in_reply_to_user_id" : 201574313,
    "text" : "Groceries in hand he checks his LoJack app first and can see that its moving down the road.",
    "id" : 781109550174830592,
    "in_reply_to_status_id" : 781109354116284416,
    "created_at" : "2016-09-28 12:33:23 +0000",
    "in_reply_to_screen_name" : "TheInsaneRobin",
    "in_reply_to_user_id_str" : "201574313",
    "user" : {
      "name" : "Vote Nerd Party",
      "screen_name" : "TheInsaneRobin",
      "protected" : false,
      "id_str" : "201574313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785505299792859136\/VDG0NzyF_normal.jpg",
      "id" : 201574313,
      "verified" : false
    }
  },
  "id" : 781202926945665024,
  "created_at" : "2016-09-28 18:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cocky McSwagsalot",
      "screen_name" : "MoreAndAgain",
      "indices" : [ 3, 16 ],
      "id_str" : "18302204",
      "id" : 18302204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/wuxqPHpwSb",
      "expanded_url" : "https:\/\/twitter.com\/TheInsaneRobin\/status\/781109354116284416",
      "display_url" : "twitter.com\/TheInsaneRobin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781202535243808768",
  "text" : "RT @MoreAndAgain: This thread is infuriating. https:\/\/t.co\/wuxqPHpwSb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/wuxqPHpwSb",
        "expanded_url" : "https:\/\/twitter.com\/TheInsaneRobin\/status\/781109354116284416",
        "display_url" : "twitter.com\/TheInsaneRobin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781191860295462912",
    "text" : "This thread is infuriating. https:\/\/t.co\/wuxqPHpwSb",
    "id" : 781191860295462912,
    "created_at" : "2016-09-28 18:00:27 +0000",
    "user" : {
      "name" : "Cocky McSwagsalot",
      "screen_name" : "MoreAndAgain",
      "protected" : false,
      "id_str" : "18302204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727579390155096068\/VtUtDLCb_normal.jpg",
      "id" : 18302204,
      "verified" : false
    }
  },
  "id" : 781202535243808768,
  "created_at" : "2016-09-28 18:42:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johanna Basford",
      "screen_name" : "johannabasford",
      "indices" : [ 3, 18 ],
      "id_str" : "19408741",
      "id" : 19408741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781159090940702720",
  "text" : "RT @johannabasford: Flip through of Johanna's Christmas Thursday 29th September 5pm UK time on Facebook live. Here's a sneaky peek in the m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/johannabasford\/status\/780358501965103104\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/gctWFL6tCp",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780358277301432320\/pu\/img\/qlC0LtNEri6KBgDK.jpg",
        "id_str" : "780358277301432320",
        "id" : 780358277301432320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780358277301432320\/pu\/img\/qlC0LtNEri6KBgDK.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/gctWFL6tCp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780358501965103104",
    "text" : "Flip through of Johanna's Christmas Thursday 29th September 5pm UK time on Facebook live. Here's a sneaky peek in the meantime! \uD83D\uDE09 https:\/\/t.co\/gctWFL6tCp",
    "id" : 780358501965103104,
    "created_at" : "2016-09-26 10:48:59 +0000",
    "user" : {
      "name" : "Johanna Basford",
      "screen_name" : "johannabasford",
      "protected" : false,
      "id_str" : "19408741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648595135538819072\/sUnDDyKP_normal.jpg",
      "id" : 19408741,
      "verified" : true
    }
  },
  "id" : 781159090940702720,
  "created_at" : "2016-09-28 15:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 3, 13 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781157986509217792",
  "text" : "RT @ShaunKing: Dear Rudy Giuliani,\n\nYour 2nd wife learned you were divorcing her when you announced it at a press conference.\n\nPlease stop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781116947907969024",
    "geo" : { },
    "id_str" : "781117207778656256",
    "in_reply_to_user_id" : 755113,
    "text" : "Dear Rudy Giuliani,\n\nYour 2nd wife learned you were divorcing her when you announced it at a press conference.\n\nPlease stop faking morality.",
    "id" : 781117207778656256,
    "in_reply_to_status_id" : 781116947907969024,
    "created_at" : "2016-09-28 13:03:49 +0000",
    "in_reply_to_screen_name" : "ShaunKing",
    "in_reply_to_user_id_str" : "755113",
    "user" : {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "protected" : false,
      "id_str" : "755113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690138574050705408\/HkB9XCu4_normal.jpg",
      "id" : 755113,
      "verified" : true
    }
  },
  "id" : 781157986509217792,
  "created_at" : "2016-09-28 15:45:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 107, 112 ]
    }, {
      "text" : "feedly",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/d2bcY9xI79",
      "expanded_url" : "https:\/\/twitter.com\/gov",
      "display_url" : "twitter.com\/gov"
    } ]
  },
  "geo" : { },
  "id_str" : "781131982520672256",
  "text" : "Twitter Government Bot \u2014 Send a DM for personalized voter registration information https:\/\/t.co\/d2bcY9xI79 #tech #feedly",
  "id" : 781131982520672256,
  "created_at" : "2016-09-28 14:02:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Milan",
      "screen_name" : "courtneymilan",
      "indices" : [ 3, 17 ],
      "id_str" : "17116809",
      "id" : 17116809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacklivesmatter",
      "indices" : [ 27, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781129001507094528",
  "text" : "RT @courtneymilan: We need #blacklivesmatter because some people think \"he made gun hands accidentally while having a seizure\" justifies de\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blacklivesmatter",
        "indices" : [ 8, 25 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781126015510650880",
    "geo" : { },
    "id_str" : "781126493413908480",
    "in_reply_to_user_id" : 17116809,
    "text" : "We need #blacklivesmatter because some people think \"he made gun hands accidentally while having a seizure\" justifies deadly force.",
    "id" : 781126493413908480,
    "in_reply_to_status_id" : 781126015510650880,
    "created_at" : "2016-09-28 13:40:43 +0000",
    "in_reply_to_screen_name" : "courtneymilan",
    "in_reply_to_user_id_str" : "17116809",
    "user" : {
      "name" : "Courtney Milan",
      "screen_name" : "courtneymilan",
      "protected" : false,
      "id_str" : "17116809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618131798350901248\/RyDQXA9M_normal.jpg",
      "id" : 17116809,
      "verified" : false
    }
  },
  "id" : 781129001507094528,
  "created_at" : "2016-09-28 13:50:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/780998228351352833\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/SE71ZC2a3p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctapt5oWIAEKD8J.jpg",
      "id_str" : "780998191424610305",
      "id" : 780998191424610305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctapt5oWIAEKD8J.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/SE71ZC2a3p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781126921547554816",
  "text" : "RT @missmuckyduck: Morning tweeters.\nHappy hump day. \uD83D\uDE0A xx \uD83D\uDC99 https:\/\/t.co\/SE71ZC2a3p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/780998228351352833\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/SE71ZC2a3p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctapt5oWIAEKD8J.jpg",
        "id_str" : "780998191424610305",
        "id" : 780998191424610305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctapt5oWIAEKD8J.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/SE71ZC2a3p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780998228351352833",
    "text" : "Morning tweeters.\nHappy hump day. \uD83D\uDE0A xx \uD83D\uDC99 https:\/\/t.co\/SE71ZC2a3p",
    "id" : 780998228351352833,
    "created_at" : "2016-09-28 05:11:02 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 781126921547554816,
  "created_at" : "2016-09-28 13:42:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781111803317223424",
  "geo" : { },
  "id_str" : "781126812311154689",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 any Black Parade in there?",
  "id" : 781126812311154689,
  "in_reply_to_status_id" : 781111803317223424,
  "created_at" : "2016-09-28 13:41:59 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780986514780160000",
  "geo" : { },
  "id_str" : "781125939182858241",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind true",
  "id" : 781125939182858241,
  "in_reply_to_status_id" : 780986514780160000,
  "created_at" : "2016-09-28 13:38:31 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigi",
      "screen_name" : "GigiSantasSocks",
      "indices" : [ 3, 19 ],
      "id_str" : "308098576",
      "id" : 308098576
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GigiSantasSocks\/status\/780921505484079104\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/6tjPHA0lup",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZj-BzW8AAW-V3.jpg",
      "id_str" : "780921502682247168",
      "id" : 780921502682247168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZj-BzW8AAW-V3.jpg",
      "sizes" : [ {
        "h" : 309,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 930,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1313,
        "resize" : "fit",
        "w" : 2890
      } ],
      "display_url" : "pic.twitter.com\/6tjPHA0lup"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781124925172092928",
  "text" : "RT @GigiSantasSocks: Trying to photograph flying cats https:\/\/t.co\/6tjPHA0lup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GigiSantasSocks\/status\/780921505484079104\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/6tjPHA0lup",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZj-BzW8AAW-V3.jpg",
        "id_str" : "780921502682247168",
        "id" : 780921502682247168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZj-BzW8AAW-V3.jpg",
        "sizes" : [ {
          "h" : 309,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 930,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1313,
          "resize" : "fit",
          "w" : 2890
        } ],
        "display_url" : "pic.twitter.com\/6tjPHA0lup"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780921505484079104",
    "text" : "Trying to photograph flying cats https:\/\/t.co\/6tjPHA0lup",
    "id" : 780921505484079104,
    "created_at" : "2016-09-28 00:06:10 +0000",
    "user" : {
      "name" : "Gigi",
      "screen_name" : "GigiSantasSocks",
      "protected" : false,
      "id_str" : "308098576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700973518087962624\/w4a6ZEXv_normal.jpg",
      "id" : 308098576,
      "verified" : false
    }
  },
  "id" : 781124925172092928,
  "created_at" : "2016-09-28 13:34:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "indices" : [ 3, 18 ],
      "id_str" : "1972360812",
      "id" : 1972360812
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/781107463206473728\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/cMi8hEo7dF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtcNFXoUIAAXEf-.jpg",
      "id_str" : "781107446265683968",
      "id" : 781107446265683968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtcNFXoUIAAXEf-.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/cMi8hEo7dF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781124881362616320",
  "text" : "RT @CityStitchette: Sneak peek - the meticulous blocking by a test knitter of my new shawl design, coming soon. https:\/\/t.co\/cMi8hEo7dF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/781107463206473728\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/cMi8hEo7dF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtcNFXoUIAAXEf-.jpg",
        "id_str" : "781107446265683968",
        "id" : 781107446265683968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtcNFXoUIAAXEf-.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/cMi8hEo7dF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781107463206473728",
    "text" : "Sneak peek - the meticulous blocking by a test knitter of my new shawl design, coming soon. https:\/\/t.co\/cMi8hEo7dF",
    "id" : 781107463206473728,
    "created_at" : "2016-09-28 12:25:06 +0000",
    "user" : {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "protected" : false,
      "id_str" : "1972360812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765660039294152704\/LtNgIXNF_normal.jpg",
      "id" : 1972360812,
      "verified" : false
    }
  },
  "id" : 781124881362616320,
  "created_at" : "2016-09-28 13:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780947893339521024",
  "text" : "RT @SenSanders: How did we have so much money available to go to war in Iraq, but somehow Republicans won\u2019t send money to Flint? https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dashboard.twitter.com\" rel=\"nofollow\"\u003ETwitter Business Experience\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SenSanders\/status\/780880286527713280\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/H3oOqrCv0P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtY-eGFWgAQh_K-.jpg",
        "id_str" : "780880272145416196",
        "id" : 780880272145416196,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtY-eGFWgAQh_K-.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/H3oOqrCv0P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780880286527713280",
    "text" : "How did we have so much money available to go to war in Iraq, but somehow Republicans won\u2019t send money to Flint? https:\/\/t.co\/H3oOqrCv0P",
    "id" : 780880286527713280,
    "created_at" : "2016-09-27 21:22:23 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 780947893339521024,
  "created_at" : "2016-09-28 01:51:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Life",
      "screen_name" : "fabulousanimals",
      "indices" : [ 3, 19 ],
      "id_str" : "558446365",
      "id" : 558446365
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fabulousanimals\/status\/780941601094897666\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/fbTrM5uTyP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZ2PvFW8AA6fyn.jpg",
      "id_str" : "780941598104416256",
      "id" : 780941598104416256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZ2PvFW8AA6fyn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fbTrM5uTyP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780944548117811200",
  "text" : "RT @fabulousanimals: A tired pink flamingo. https:\/\/t.co\/fbTrM5uTyP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fabulousanimals\/status\/780941601094897666\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/fbTrM5uTyP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZ2PvFW8AA6fyn.jpg",
        "id_str" : "780941598104416256",
        "id" : 780941598104416256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZ2PvFW8AA6fyn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fbTrM5uTyP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780941601094897666",
    "text" : "A tired pink flamingo. https:\/\/t.co\/fbTrM5uTyP",
    "id" : 780941601094897666,
    "created_at" : "2016-09-28 01:26:01 +0000",
    "user" : {
      "name" : "Animal Life",
      "screen_name" : "fabulousanimals",
      "protected" : false,
      "id_str" : "558446365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3315780973\/f771546322a54648fb557f2808b39694_normal.jpeg",
      "id" : 558446365,
      "verified" : false
    }
  },
  "id" : 780944548117811200,
  "created_at" : "2016-09-28 01:37:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PocahontasB Wolf",
      "screen_name" : "OleHippieChick",
      "indices" : [ 3, 18 ],
      "id_str" : "256510253",
      "id" : 256510253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trump",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "stiffing",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/S1GYeVjl5M",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2016\/9\/27\/1574954\/-Trump-defends-stiffing-thousands-of-people-who-built-his-unbelievable-company",
      "display_url" : "dailykos.com\/story\/2016\/9\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780944016791724032",
  "text" : "RT @OleHippieChick: #Trump defends #stiffing thousands of people who built his 'unbelievable company' https:\/\/t.co\/S1GYeVjl5M Thanks. Come\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Trump",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "stiffing",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "Chapter11",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/S1GYeVjl5M",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2016\/9\/27\/1574954\/-Trump-defends-stiffing-thousands-of-people-who-built-his-unbelievable-company",
        "display_url" : "dailykos.com\/story\/2016\/9\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780942849001021441",
    "text" : "#Trump defends #stiffing thousands of people who built his 'unbelievable company' https:\/\/t.co\/S1GYeVjl5M Thanks. Come with me to #Chapter11",
    "id" : 780942849001021441,
    "created_at" : "2016-09-28 01:30:59 +0000",
    "user" : {
      "name" : "PocahontasB Wolf",
      "screen_name" : "OleHippieChick",
      "protected" : false,
      "id_str" : "256510253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1727544047\/Jump__you_fuckers__normal.jpg",
      "id" : 256510253,
      "verified" : false
    }
  },
  "id" : 780944016791724032,
  "created_at" : "2016-09-28 01:35:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/780943361385439232\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/T1dEHspoEB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZ316cVMAAptZP.jpg",
      "id_str" : "780943353500217344",
      "id" : 780943353500217344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZ316cVMAAptZP.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/T1dEHspoEB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780943564037586944",
  "text" : "RT @5thdimdreamz: https:\/\/t.co\/T1dEHspoEB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/780943361385439232\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/T1dEHspoEB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZ316cVMAAptZP.jpg",
        "id_str" : "780943353500217344",
        "id" : 780943353500217344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZ316cVMAAptZP.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/T1dEHspoEB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780943361385439232",
    "text" : "https:\/\/t.co\/T1dEHspoEB",
    "id" : 780943361385439232,
    "created_at" : "2016-09-28 01:33:01 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 780943564037586944,
  "created_at" : "2016-09-28 01:33:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/BpBud7nCG5",
      "expanded_url" : "https:\/\/twitter.com\/nbcsandiego\/status\/780893771676393472",
      "display_url" : "twitter.com\/nbcsandiego\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780942036023275520",
  "text" : "what reason could they have for taking cell phones?? https:\/\/t.co\/BpBud7nCG5",
  "id" : 780942036023275520,
  "created_at" : "2016-09-28 01:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carissa B Hessick",
      "screen_name" : "CBHessick",
      "indices" : [ 3, 13 ],
      "id_str" : "3097134196",
      "id" : 3097134196
    }, {
      "name" : "Brandon Garrett",
      "screen_name" : "brandonlgarrett",
      "indices" : [ 107, 123 ],
      "id_str" : "2300581274",
      "id" : 2300581274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780941545398730752",
  "text" : "RT @CBHessick: A reminder that wrongful convictions can result from plea bargaining as well as trials. h\/t @brandonlgarrett \nhttps:\/\/t.co\/X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brandon Garrett",
        "screen_name" : "brandonlgarrett",
        "indices" : [ 92, 108 ],
        "id_str" : "2300581274",
        "id" : 2300581274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/XJZz53mItj",
        "expanded_url" : "http:\/\/pilotonline.com\/news\/local\/crime\/members-of-norfolk-four-convicted-in-rape-murder-are-innocent\/article_6f6c5818-1770-5e6b-8b60-b76a5afb05ae.html",
        "display_url" : "pilotonline.com\/news\/local\/cri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780805960977657856",
    "text" : "A reminder that wrongful convictions can result from plea bargaining as well as trials. h\/t @brandonlgarrett \nhttps:\/\/t.co\/XJZz53mItj",
    "id" : 780805960977657856,
    "created_at" : "2016-09-27 16:27:02 +0000",
    "user" : {
      "name" : "Carissa B Hessick",
      "screen_name" : "CBHessick",
      "protected" : false,
      "id_str" : "3097134196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776546324565073920\/lwOfEOEk_normal.jpg",
      "id" : 3097134196,
      "verified" : false
    }
  },
  "id" : 780941545398730752,
  "created_at" : "2016-09-28 01:25:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Survivor Coach",
      "screen_name" : "survivorcoach16",
      "indices" : [ 3, 19 ],
      "id_str" : "732738690779222017",
      "id" : 732738690779222017
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/survivorcoach16\/status\/780865515724038144\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ZkTBoO58JK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtYxC28UEAA5qjj.jpg",
      "id_str" : "780865510573346816",
      "id" : 780865510573346816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtYxC28UEAA5qjj.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 253
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 253
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 253
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 253
      } ],
      "display_url" : "pic.twitter.com\/ZkTBoO58JK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780891434476003328",
  "text" : "RT @survivorcoach16: https:\/\/t.co\/ZkTBoO58JK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/survivorcoach16\/status\/780865515724038144\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/ZkTBoO58JK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtYxC28UEAA5qjj.jpg",
        "id_str" : "780865510573346816",
        "id" : 780865510573346816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtYxC28UEAA5qjj.jpg",
        "sizes" : [ {
          "h" : 380,
          "resize" : "fit",
          "w" : 253
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 253
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 253
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 253
        } ],
        "display_url" : "pic.twitter.com\/ZkTBoO58JK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780865515724038144",
    "text" : "https:\/\/t.co\/ZkTBoO58JK",
    "id" : 780865515724038144,
    "created_at" : "2016-09-27 20:23:41 +0000",
    "user" : {
      "name" : "The Survivor Coach",
      "screen_name" : "survivorcoach16",
      "protected" : false,
      "id_str" : "732738690779222017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732740904709038080\/DNyNoVER_normal.jpg",
      "id" : 732738690779222017,
      "verified" : false
    }
  },
  "id" : 780891434476003328,
  "created_at" : "2016-09-27 22:06:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "indices" : [ 3, 18 ],
      "id_str" : "27268080",
      "id" : 27268080
    }, {
      "name" : "ScienceAlert",
      "screen_name" : "ScienceAlert",
      "indices" : [ 101, 114 ],
      "id_str" : "60813201",
      "id" : 60813201
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StarStuff_ivan\/status\/780885649951862784\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/p8d6h5RUz9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZDXCoVMAAwOOm.jpg",
      "id_str" : "780885648517443584",
      "id" : 780885648517443584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZDXCoVMAAwOOm.jpg",
      "sizes" : [ {
        "h" : 415,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/p8d6h5RUz9"
    } ],
    "hashtags" : [ {
      "text" : "via",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/W1poZL57df",
      "expanded_url" : "http:\/\/www.sciencealert.com\/time-might-only-exist-in-your-head-say-physicists",
      "display_url" : "sciencealert.com\/time-might-onl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780888992036319232",
  "text" : "RT @StarStuff_ivan: Time might only exist in your head, say physicists  https:\/\/t.co\/W1poZL57df #via @ScienceAlert https:\/\/t.co\/p8d6h5RUz9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitshot.com\" rel=\"nofollow\"\u003ETwitshot.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ScienceAlert",
        "screen_name" : "ScienceAlert",
        "indices" : [ 81, 94 ],
        "id_str" : "60813201",
        "id" : 60813201
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StarStuff_ivan\/status\/780885649951862784\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/p8d6h5RUz9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtZDXCoVMAAwOOm.jpg",
        "id_str" : "780885648517443584",
        "id" : 780885648517443584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtZDXCoVMAAwOOm.jpg",
        "sizes" : [ {
          "h" : 415,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/p8d6h5RUz9"
      } ],
      "hashtags" : [ {
        "text" : "via",
        "indices" : [ 76, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/W1poZL57df",
        "expanded_url" : "http:\/\/www.sciencealert.com\/time-might-only-exist-in-your-head-say-physicists",
        "display_url" : "sciencealert.com\/time-might-onl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780885649951862784",
    "text" : "Time might only exist in your head, say physicists  https:\/\/t.co\/W1poZL57df #via @ScienceAlert https:\/\/t.co\/p8d6h5RUz9",
    "id" : 780885649951862784,
    "created_at" : "2016-09-27 21:43:41 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 780888992036319232,
  "created_at" : "2016-09-27 21:56:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780888050301800448",
  "text" : "RT @wilw: Chris Christie, on MSNBC, just said that we shouldn't believe fact-checkers, because \"they have an agenda.\" Yes. It is to check f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780604796101271552",
    "text" : "Chris Christie, on MSNBC, just said that we shouldn't believe fact-checkers, because \"they have an agenda.\" Yes. It is to check facts, dude.",
    "id" : 780604796101271552,
    "created_at" : "2016-09-27 03:07:40 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503013851631616\/55p1uw70_normal.jpg",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 780888050301800448,
  "created_at" : "2016-09-27 21:53:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "indices" : [ 3, 15 ],
      "id_str" : "519836839",
      "id" : 519836839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Grampians",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "farm365",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780887824614711296",
  "text" : "RT @decisiveman: It's a beautiful start to the day at Glenlee Farm #Grampians. The calm before the storm perhaps. #farm365 https:\/\/t.co\/tro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/780869102600531968\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/troBzqWQDQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtY0SYzVMAAd_RO.jpg",
        "id_str" : "780869075895398400",
        "id" : 780869075895398400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtY0SYzVMAAd_RO.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1138,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1138,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/troBzqWQDQ"
      } ],
      "hashtags" : [ {
        "text" : "Grampians",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "farm365",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780869102600531968",
    "text" : "It's a beautiful start to the day at Glenlee Farm #Grampians. The calm before the storm perhaps. #farm365 https:\/\/t.co\/troBzqWQDQ",
    "id" : 780869102600531968,
    "created_at" : "2016-09-27 20:37:56 +0000",
    "user" : {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "protected" : false,
      "id_str" : "519836839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706805650844585984\/Wyw3swZ9_normal.jpg",
      "id" : 519836839,
      "verified" : false
    }
  },
  "id" : 780887824614711296,
  "created_at" : "2016-09-27 21:52:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 0, 16 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780882922114981888",
  "geo" : { },
  "id_str" : "780887784714371073",
  "in_reply_to_user_id" : 24233147,
  "text" : "@fairlyspiritual well, if they cant relate to those views, it makes sense. like i can only handle some conservatism...",
  "id" : 780887784714371073,
  "in_reply_to_status_id" : 780882922114981888,
  "created_at" : "2016-09-27 21:52:10 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780873815324753920",
  "text" : "also.. self-preservation is very strong instinct not just life\/death but way of life which explains a lot.",
  "id" : 780873815324753920,
  "created_at" : "2016-09-27 20:56:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780873374692155392",
  "text" : "we all have diff perceptions based on our perspectives in life. each view is valid based on that.",
  "id" : 780873374692155392,
  "created_at" : "2016-09-27 20:54:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780873047410667521",
  "text" : "there are some trump supporters i def do not like becuz their views, behavior. there are some whom i like becuz same.",
  "id" : 780873047410667521,
  "created_at" : "2016-09-27 20:53:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780872620040478721",
  "text" : "i dont like trump but i know we all like whom we like for various reasons, come to conclusions from where we are.",
  "id" : 780872620040478721,
  "created_at" : "2016-09-27 20:51:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Lown",
      "screen_name" : "JLownLaw",
      "indices" : [ 3, 12 ],
      "id_str" : "21707139",
      "id" : 21707139
    }, {
      "name" : "Sally Albright",
      "screen_name" : "SallyAlbright",
      "indices" : [ 14, 28 ],
      "id_str" : "11395432",
      "id" : 11395432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780871640079036416",
  "text" : "RT @JLownLaw: @SallyAlbright True. For some, it is disinformation about her. Others are cynical; distrust the system, institutions. Hard to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sally Albright",
        "screen_name" : "SallyAlbright",
        "indices" : [ 0, 14 ],
        "id_str" : "11395432",
        "id" : 11395432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "780861871859589120",
    "geo" : { },
    "id_str" : "780869353084510208",
    "in_reply_to_user_id" : 11395432,
    "text" : "@SallyAlbright True. For some, it is disinformation about her. Others are cynical; distrust the system, institutions. Hard to undo.",
    "id" : 780869353084510208,
    "in_reply_to_status_id" : 780861871859589120,
    "created_at" : "2016-09-27 20:38:56 +0000",
    "in_reply_to_screen_name" : "SallyAlbright",
    "in_reply_to_user_id_str" : "11395432",
    "user" : {
      "name" : "Jo Lown",
      "screen_name" : "JLownLaw",
      "protected" : false,
      "id_str" : "21707139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582649565414875138\/cVk5GAJa_normal.jpg",
      "id" : 21707139,
      "verified" : false
    }
  },
  "id" : 780871640079036416,
  "created_at" : "2016-09-27 20:48:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All* Above All",
      "screen_name" : "AllAboveAll",
      "indices" : [ 3, 15 ],
      "id_str" : "1390186333",
      "id" : 1390186333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/tQMh52sCYa",
      "expanded_url" : "http:\/\/bit.ly\/2d6Wp1l",
      "display_url" : "bit.ly\/2d6Wp1l"
    } ]
  },
  "geo" : { },
  "id_str" : "780864379910848517",
  "text" : "RT @AllAboveAll: \"It\u2019s time to end Hyde...Health insurance should not be based on which state you live in.\" https:\/\/t.co\/tQMh52sCYa @reprod\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ReproDocs",
        "screen_name" : "reprodocs",
        "indices" : [ 115, 125 ],
        "id_str" : "56788628",
        "id" : 56788628
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeBoldEndHyde",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/tQMh52sCYa",
        "expanded_url" : "http:\/\/bit.ly\/2d6Wp1l",
        "display_url" : "bit.ly\/2d6Wp1l"
      } ]
    },
    "geo" : { },
    "id_str" : "780859752200962049",
    "text" : "\"It\u2019s time to end Hyde...Health insurance should not be based on which state you live in.\" https:\/\/t.co\/tQMh52sCYa @reprodocs #BeBoldEndHyde",
    "id" : 780859752200962049,
    "created_at" : "2016-09-27 20:00:47 +0000",
    "user" : {
      "name" : "All* Above All",
      "screen_name" : "AllAboveAll",
      "protected" : false,
      "id_str" : "1390186333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788033149146103808\/2suXYAuL_normal.jpg",
      "id" : 1390186333,
      "verified" : false
    }
  },
  "id" : 780864379910848517,
  "created_at" : "2016-09-27 20:19:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Haggerty",
      "screen_name" : "manymanywords",
      "indices" : [ 0, 14 ],
      "id_str" : "92095451",
      "id" : 92095451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780775011082760192",
  "geo" : { },
  "id_str" : "780825044243087360",
  "in_reply_to_user_id" : 92095451,
  "text" : "@manymanywords someone needs to storify the thread",
  "id" : 780825044243087360,
  "in_reply_to_status_id" : 780775011082760192,
  "created_at" : "2016-09-27 17:42:52 +0000",
  "in_reply_to_screen_name" : "manymanywords",
  "in_reply_to_user_id_str" : "92095451",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Haggerty",
      "screen_name" : "manymanywords",
      "indices" : [ 3, 17 ],
      "id_str" : "92095451",
      "id" : 92095451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780824041200508928",
  "text" : "RT @manymanywords: If you missed whole thread last night (as I did), it's worth reading now. I hope the people who need to see this do. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/cMdWr7al9x",
        "expanded_url" : "https:\/\/twitter.com\/thewordunheard\/status\/780604752593903616",
        "display_url" : "twitter.com\/thewordunheard\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780775011082760192",
    "text" : "If you missed whole thread last night (as I did), it's worth reading now. I hope the people who need to see this do. https:\/\/t.co\/cMdWr7al9x",
    "id" : 780775011082760192,
    "created_at" : "2016-09-27 14:24:03 +0000",
    "user" : {
      "name" : "Meredith Haggerty",
      "screen_name" : "manymanywords",
      "protected" : false,
      "id_str" : "92095451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478719765020561408\/ll8-rD4i_normal.png",
      "id" : 92095451,
      "verified" : true
    }
  },
  "id" : 780824041200508928,
  "created_at" : "2016-09-27 17:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K Dub-ya",
      "screen_name" : "kahuna278",
      "indices" : [ 3, 13 ],
      "id_str" : "91025286",
      "id" : 91025286
    }, {
      "name" : "Arielle Brousse",
      "screen_name" : "thewordunheard",
      "indices" : [ 15, 30 ],
      "id_str" : "17513071",
      "id" : 17513071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780823871893172225",
  "text" : "RT @kahuna278: @thewordunheard This story needs to be hard loud &amp; clear by the electorate. The idea that he give a damn about normal workin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arielle Brousse",
        "screen_name" : "thewordunheard",
        "indices" : [ 0, 15 ],
        "id_str" : "17513071",
        "id" : 17513071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "780604752593903616",
    "geo" : { },
    "id_str" : "780619890772307968",
    "in_reply_to_user_id" : 17513071,
    "text" : "@thewordunheard This story needs to be hard loud &amp; clear by the electorate. The idea that he give a damn about normal working people is BS!!",
    "id" : 780619890772307968,
    "in_reply_to_status_id" : 780604752593903616,
    "created_at" : "2016-09-27 04:07:39 +0000",
    "in_reply_to_screen_name" : "thewordunheard",
    "in_reply_to_user_id_str" : "17513071",
    "user" : {
      "name" : "K Dub-ya",
      "screen_name" : "kahuna278",
      "protected" : false,
      "id_str" : "91025286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559019423600623616\/C6g8xuip_normal.png",
      "id" : 91025286,
      "verified" : false
    }
  },
  "id" : 780823871893172225,
  "created_at" : "2016-09-27 17:38:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielle Brousse",
      "screen_name" : "thewordunheard",
      "indices" : [ 3, 18 ],
      "id_str" : "17513071",
      "id" : 17513071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780823805522477056",
  "text" : "RT @thewordunheard: These stakes are personal to me. Trust me: I have seen firsthand the damage he can do in a home community. A nation wou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "780608734334779393",
    "geo" : { },
    "id_str" : "780609882416447488",
    "in_reply_to_user_id" : 17513071,
    "text" : "These stakes are personal to me. Trust me: I have seen firsthand the damage he can do in a home community. A nation would be catastrophe.",
    "id" : 780609882416447488,
    "in_reply_to_status_id" : 780608734334779393,
    "created_at" : "2016-09-27 03:27:53 +0000",
    "in_reply_to_screen_name" : "thewordunheard",
    "in_reply_to_user_id_str" : "17513071",
    "user" : {
      "name" : "Arielle Brousse",
      "screen_name" : "thewordunheard",
      "protected" : false,
      "id_str" : "17513071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514823147078447105\/8hWsVmnr_normal.jpeg",
      "id" : 17513071,
      "verified" : false
    }
  },
  "id" : 780823805522477056,
  "created_at" : "2016-09-27 17:37:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Los Angeles Times",
      "screen_name" : "latimes",
      "indices" : [ 3, 11 ],
      "id_str" : "16664681",
      "id" : 16664681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/1IUTpzGp5z",
      "expanded_url" : "http:\/\/lat.ms\/2d3lbSk",
      "display_url" : "lat.ms\/2d3lbSk"
    } ]
  },
  "geo" : { },
  "id_str" : "780823131707539457",
  "text" : "RT @latimes: It's been 2 years since 43 Mexican students disappeared and we still don't know what happened https:\/\/t.co\/1IUTpzGp5z https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/latimes\/status\/780780118545432576\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/fXNOnaQP71",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXjYG9W8AA57fG.jpg",
        "id_str" : "780780113742983168",
        "id" : 780780113742983168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXjYG9W8AA57fG.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/fXNOnaQP71"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/1IUTpzGp5z",
        "expanded_url" : "http:\/\/lat.ms\/2d3lbSk",
        "display_url" : "lat.ms\/2d3lbSk"
      } ]
    },
    "geo" : { },
    "id_str" : "780780118545432576",
    "text" : "It's been 2 years since 43 Mexican students disappeared and we still don't know what happened https:\/\/t.co\/1IUTpzGp5z https:\/\/t.co\/fXNOnaQP71",
    "id" : 780780118545432576,
    "created_at" : "2016-09-27 14:44:21 +0000",
    "user" : {
      "name" : "Los Angeles Times",
      "screen_name" : "latimes",
      "protected" : false,
      "id_str" : "16664681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546329819919560704\/XMWy2Z50_normal.jpeg",
      "id" : 16664681,
      "verified" : true
    }
  },
  "id" : 780823131707539457,
  "created_at" : "2016-09-27 17:35:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 3, 12 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/doctorow\/status\/780781083717541888\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/OjBgS5489g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXkLxJVYAA8aOY.jpg",
      "id_str" : "780781001240829952",
      "id" : 780781001240829952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXkLxJVYAA8aOY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OjBgS5489g"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/doctorow\/status\/780781083717541888\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/OjBgS5489g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXkMO4VIAIdFko.jpg",
      "id_str" : "780781009222574082",
      "id" : 780781009222574082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXkMO4VIAIdFko.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OjBgS5489g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/DEHAWtC1ac",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/09\/27\/lawn-jawas-with-solar-charged.html",
      "display_url" : "boingboing.net\/2016\/09\/27\/law\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780822146834690048",
  "text" : "RT @doctorow: Lawn Jawas with solar-charged light-up eyes\nhttps:\/\/t.co\/DEHAWtC1ac https:\/\/t.co\/OjBgS5489g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/doctorow\/status\/780781083717541888\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/OjBgS5489g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXkLxJVYAA8aOY.jpg",
        "id_str" : "780781001240829952",
        "id" : 780781001240829952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXkLxJVYAA8aOY.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OjBgS5489g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/doctorow\/status\/780781083717541888\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/OjBgS5489g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXkMO4VIAIdFko.jpg",
        "id_str" : "780781009222574082",
        "id" : 780781009222574082,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXkMO4VIAIdFko.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OjBgS5489g"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/DEHAWtC1ac",
        "expanded_url" : "http:\/\/boingboing.net\/2016\/09\/27\/lawn-jawas-with-solar-charged.html",
        "display_url" : "boingboing.net\/2016\/09\/27\/law\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780781083717541888",
    "text" : "Lawn Jawas with solar-charged light-up eyes\nhttps:\/\/t.co\/DEHAWtC1ac https:\/\/t.co\/OjBgS5489g",
    "id" : 780781083717541888,
    "created_at" : "2016-09-27 14:48:11 +0000",
    "user" : {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "protected" : false,
      "id_str" : "2729061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675023052812378112\/Ly7VsGa6_normal.jpg",
      "id" : 2729061,
      "verified" : true
    }
  },
  "id" : 780822146834690048,
  "created_at" : "2016-09-27 17:31:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    }, {
      "name" : "Leith Honda",
      "screen_name" : "LeithHonda",
      "indices" : [ 11, 22 ],
      "id_str" : "65375299",
      "id" : 65375299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780822004643557380",
  "text" : "RT @5x5: . @leithhonda believes if a couple buys a car, all communications\/service go under the man\u2019s name. It is MY car &amp; they refused to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leith Honda",
        "screen_name" : "LeithHonda",
        "indices" : [ 2, 13 ],
        "id_str" : "65375299",
        "id" : 65375299
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780799329690869761",
    "text" : ". @leithhonda believes if a couple buys a car, all communications\/service go under the man\u2019s name. It is MY car &amp; they refused to change it.",
    "id" : 780799329690869761,
    "created_at" : "2016-09-27 16:00:41 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 780822004643557380,
  "created_at" : "2016-09-27 17:30:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "feedly",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/12BqeVNZGi",
      "expanded_url" : "https:\/\/ilmk.wordpress.com\/2016\/09\/27\/utopia-is-banned-in-texas-prisons-its-banned-books-week\/",
      "display_url" : "ilmk.wordpress.com\/2016\/09\/27\/uto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780795837370761216",
  "text" : "Utopia is banned in Texas prisons? It\u2019s Banned Books Week https:\/\/t.co\/12BqeVNZGi #books #feedly",
  "id" : 780795837370761216,
  "created_at" : "2016-09-27 15:46:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACLU-North Carolina",
      "screen_name" : "ACLU_NC",
      "indices" : [ 3, 11 ],
      "id_str" : "376403191",
      "id" : 376403191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KeithLamontScott",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780782251869138944",
  "text" : "RT @ACLU_NC: ICYMI: Charlotte officer didn\u2019t activate body camera until after fatal police shooting of #KeithLamontScott https:\/\/t.co\/wwjF7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KeithLamontScott",
        "indices" : [ 90, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/wwjF7zVP9R",
        "expanded_url" : "http:\/\/www.charlotteobserver.com\/news\/special-reports\/charlotte-shooting-protests\/article104228581.html",
        "display_url" : "charlotteobserver.com\/news\/special-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780764071989829632",
    "text" : "ICYMI: Charlotte officer didn\u2019t activate body camera until after fatal police shooting of #KeithLamontScott https:\/\/t.co\/wwjF7zVP9R",
    "id" : 780764071989829632,
    "created_at" : "2016-09-27 13:40:35 +0000",
    "user" : {
      "name" : "ACLU-North Carolina",
      "screen_name" : "ACLU_NC",
      "protected" : false,
      "id_str" : "376403191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713435522132119552\/bINAThYI_normal.jpg",
      "id" : 376403191,
      "verified" : false
    }
  },
  "id" : 780782251869138944,
  "created_at" : "2016-09-27 14:52:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mara Wilson",
      "screen_name" : "MaraWilson",
      "indices" : [ 3, 14 ],
      "id_str" : "386056280",
      "id" : 386056280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780781965737951232",
  "text" : "RT @MaraWilson: I forgot that when you check in to a flight on a Canadian airline, they ask you if have ANTLERS in your bag",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780454922001055745",
    "text" : "I forgot that when you check in to a flight on a Canadian airline, they ask you if have ANTLERS in your bag",
    "id" : 780454922001055745,
    "created_at" : "2016-09-26 17:12:08 +0000",
    "user" : {
      "name" : "Mara Wilson",
      "screen_name" : "MaraWilson",
      "protected" : false,
      "id_str" : "386056280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3379635204\/9ac0e9d772744fe2fe68e852ada4fb57_normal.jpeg",
      "id" : 386056280,
      "verified" : true
    }
  },
  "id" : 780781965737951232,
  "created_at" : "2016-09-27 14:51:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Major Garrett",
      "screen_name" : "MajorCBS",
      "indices" : [ 3, 12 ],
      "id_str" : "46176168",
      "id" : 46176168
    }, {
      "name" : "FOX & Friends",
      "screen_name" : "foxandfriends",
      "indices" : [ 17, 31 ],
      "id_str" : "15513604",
      "id" : 15513604
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 32, 48 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 63, 71 ],
      "id_str" : "15012486",
      "id" : 15012486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780781808325648384",
  "text" : "RT @MajorCBS: On @foxandfriends @realDonaldTrump said he won a @CBSNews post-debate poll. We did not conduct a post-debate poll.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FOX & Friends",
        "screen_name" : "foxandfriends",
        "indices" : [ 3, 17 ],
        "id_str" : "15513604",
        "id" : 15513604
      }, {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 18, 34 ],
        "id_str" : "25073877",
        "id" : 25073877
      }, {
        "name" : "CBS News",
        "screen_name" : "CBSNews",
        "indices" : [ 49, 57 ],
        "id_str" : "15012486",
        "id" : 15012486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780747025398763520",
    "text" : "On @foxandfriends @realDonaldTrump said he won a @CBSNews post-debate poll. We did not conduct a post-debate poll.",
    "id" : 780747025398763520,
    "created_at" : "2016-09-27 12:32:51 +0000",
    "user" : {
      "name" : "Major Garrett",
      "screen_name" : "MajorCBS",
      "protected" : false,
      "id_str" : "46176168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/290433926\/cartoonmajorcrop_normal.jpg",
      "id" : 46176168,
      "verified" : true
    }
  },
  "id" : 780781808325648384,
  "created_at" : "2016-09-27 14:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780598257261109248",
  "geo" : { },
  "id_str" : "780599024613199879",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH \"please proceed, governor\"",
  "id" : 780599024613199879,
  "in_reply_to_status_id" : 780598257261109248,
  "created_at" : "2016-09-27 02:44:44 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "indices" : [ 3, 15 ],
      "id_str" : "4207961",
      "id" : 4207961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/s7qwLSqm6D",
      "expanded_url" : "https:\/\/twitter.com\/jonfavs\/status\/780582947774566400",
      "display_url" : "twitter.com\/jonfavs\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780593301992906753",
  "text" : "RT @chrislhayes: Indeed he did. https:\/\/t.co\/s7qwLSqm6D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/s7qwLSqm6D",
        "expanded_url" : "https:\/\/twitter.com\/jonfavs\/status\/780582947774566400",
        "display_url" : "twitter.com\/jonfavs\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780583970572566528",
    "text" : "Indeed he did. https:\/\/t.co\/s7qwLSqm6D",
    "id" : 780583970572566528,
    "created_at" : "2016-09-27 01:44:55 +0000",
    "user" : {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "protected" : false,
      "id_str" : "4207961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499446228\/MSNBC_Headshot_normal.jpg",
      "id" : 4207961,
      "verified" : true
    }
  },
  "id" : 780593301992906753,
  "created_at" : "2016-09-27 02:22:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Debates2016",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780590036177850371",
  "text" : "RT @ZachsMind: \"I settled with no admission of guilt.\" So he shut out blacks, was not held accountable &amp; is proud of it. #Debates2016 #deba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debates2016",
        "indices" : [ 110, 122 ]
      }, {
        "text" : "debatenight",
        "indices" : [ 123, 135 ]
      }, {
        "text" : "debates",
        "indices" : [ 136, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780589592273563651",
    "text" : "\"I settled with no admission of guilt.\" So he shut out blacks, was not held accountable &amp; is proud of it. #Debates2016 #debatenight #debates",
    "id" : 780589592273563651,
    "created_at" : "2016-09-27 02:07:16 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 780590036177850371,
  "created_at" : "2016-09-27 02:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50\uFE0F Barbi \u2B50\uFE0F",
      "screen_name" : "sum1star",
      "indices" : [ 3, 12 ],
      "id_str" : "32156954",
      "id" : 32156954
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 18, 34 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/5NA0reD9vy",
      "expanded_url" : "https:\/\/twitter.com\/realdonaldtrump\/status\/265895292191248385",
      "display_url" : "twitter.com\/realdonaldtrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780585476415717376",
  "text" : "RT @sum1star: Hey @realDonaldTrump Yeah, you did say this. https:\/\/t.co\/5NA0reD9vy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 4, 20 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/5NA0reD9vy",
        "expanded_url" : "https:\/\/twitter.com\/realdonaldtrump\/status\/265895292191248385",
        "display_url" : "twitter.com\/realdonaldtrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780584400098516992",
    "text" : "Hey @realDonaldTrump Yeah, you did say this. https:\/\/t.co\/5NA0reD9vy",
    "id" : 780584400098516992,
    "created_at" : "2016-09-27 01:46:38 +0000",
    "user" : {
      "name" : "\u2B50\uFE0F Barbi \u2B50\uFE0F",
      "screen_name" : "sum1star",
      "protected" : false,
      "id_str" : "32156954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665934848834469888\/XCgK6B-U_normal.jpg",
      "id" : 32156954,
      "verified" : false
    }
  },
  "id" : 780585476415717376,
  "created_at" : "2016-09-27 01:50:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780572535440216064",
  "geo" : { },
  "id_str" : "780583488718266369",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep teehee",
  "id" : 780583488718266369,
  "in_reply_to_status_id" : 780572535440216064,
  "created_at" : "2016-09-27 01:43:00 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780582749769965569",
  "text" : "&lt;3 hearting so many of y'all tweets tonight...",
  "id" : 780582749769965569,
  "created_at" : "2016-09-27 01:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "indices" : [ 3, 15 ],
      "id_str" : "4207961",
      "id" : 4207961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/BD1z7ZndcR",
      "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/418542137899491328",
      "display_url" : "twitter.com\/realDonaldTrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780582199703793664",
  "text" : "RT @chrislhayes: This one too https:\/\/t.co\/BD1z7ZndcR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/BD1z7ZndcR",
        "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/418542137899491328",
        "display_url" : "twitter.com\/realDonaldTrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780577291210555393",
    "text" : "This one too https:\/\/t.co\/BD1z7ZndcR",
    "id" : 780577291210555393,
    "created_at" : "2016-09-27 01:18:23 +0000",
    "user" : {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "protected" : false,
      "id_str" : "4207961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499446228\/MSNBC_Headshot_normal.jpg",
      "id" : 4207961,
      "verified" : true
    }
  },
  "id" : 780582199703793664,
  "created_at" : "2016-09-27 01:37:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fusion",
      "screen_name" : "Fusion",
      "indices" : [ 3, 10 ],
      "id_str" : "121817564",
      "id" : 121817564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780581295739006976",
  "text" : "RT @Fusion: \"Donald thinks that climate change is a hoax, perpetrated by the Chinese...\" \u2013Hillary\n\n\"I did not say that.\" \u2013Trump #debatenigh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fusion\/status\/780578419893374977\/photo\/1",
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/LH4ahZZ79D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtUr4EkVYAA4el_.jpg",
        "id_str" : "780578352717455360",
        "id" : 780578352717455360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtUr4EkVYAA4el_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 633
        } ],
        "display_url" : "pic.twitter.com\/LH4ahZZ79D"
      } ],
      "hashtags" : [ {
        "text" : "debatenight",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "780576971667349506",
    "geo" : { },
    "id_str" : "780578419893374977",
    "in_reply_to_user_id" : 121817564,
    "text" : "\"Donald thinks that climate change is a hoax, perpetrated by the Chinese...\" \u2013Hillary\n\n\"I did not say that.\" \u2013Trump #debatenight https:\/\/t.co\/LH4ahZZ79D",
    "id" : 780578419893374977,
    "in_reply_to_status_id" : 780576971667349506,
    "created_at" : "2016-09-27 01:22:52 +0000",
    "in_reply_to_screen_name" : "Fusion",
    "in_reply_to_user_id_str" : "121817564",
    "user" : {
      "name" : "Fusion",
      "screen_name" : "Fusion",
      "protected" : false,
      "id_str" : "121817564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738697994216710145\/LcfV6jBt_normal.jpg",
      "id" : 121817564,
      "verified" : true
    }
  },
  "id" : 780581295739006976,
  "created_at" : "2016-09-27 01:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Addams",
      "screen_name" : "JaneAddamsUp",
      "indices" : [ 3, 16 ],
      "id_str" : "780557285059768320",
      "id" : 780557285059768320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780579543669174273",
  "text" : "RT @JaneAddamsUp: Does someone have Lester locked in a closet? #debates He said, screw it, I am going to the bar!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 45, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780578831866351617",
    "text" : "Does someone have Lester locked in a closet? #debates He said, screw it, I am going to the bar!",
    "id" : 780578831866351617,
    "created_at" : "2016-09-27 01:24:30 +0000",
    "user" : {
      "name" : "Jane Addams",
      "screen_name" : "JaneAddamsUp",
      "protected" : false,
      "id_str" : "780557285059768320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780562868529876992\/x__LbX_J_normal.jpg",
      "id" : 780557285059768320,
      "verified" : false
    }
  },
  "id" : 780579543669174273,
  "created_at" : "2016-09-27 01:27:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunty",
      "screen_name" : "HuntyZeddV",
      "indices" : [ 3, 14 ],
      "id_str" : "81989312",
      "id" : 81989312
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 17, 33 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Debates",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780578039436640256",
  "text" : "RT @HuntyZeddV: .@realDonaldTrump It doesn't matter what energy you support when our world is destroyed. #Debates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 1, 17 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debates",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780577593716150275",
    "text" : ".@realDonaldTrump It doesn't matter what energy you support when our world is destroyed. #Debates",
    "id" : 780577593716150275,
    "created_at" : "2016-09-27 01:19:35 +0000",
    "user" : {
      "name" : "Hunty",
      "screen_name" : "HuntyZeddV",
      "protected" : false,
      "id_str" : "81989312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542065418089684992\/9AukuR8z_normal.jpeg",
      "id" : 81989312,
      "verified" : false
    }
  },
  "id" : 780578039436640256,
  "created_at" : "2016-09-27 01:21:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elsa Waithe",
      "screen_name" : "elsajustelsa",
      "indices" : [ 3, 16 ],
      "id_str" : "2490904690",
      "id" : 2490904690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Debates",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780576772224061440",
  "text" : "RT @elsajustelsa: Hil ask him about where his jobs go? His clothes are foreign made.  #Debates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debates",
        "indices" : [ 68, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780576042046160898",
    "text" : "Hil ask him about where his jobs go? His clothes are foreign made.  #Debates",
    "id" : 780576042046160898,
    "created_at" : "2016-09-27 01:13:25 +0000",
    "user" : {
      "name" : "Elsa Waithe",
      "screen_name" : "elsajustelsa",
      "protected" : false,
      "id_str" : "2490904690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756001451520897027\/MxyIv0on_normal.jpg",
      "id" : 2490904690,
      "verified" : false
    }
  },
  "id" : 780576772224061440,
  "created_at" : "2016-09-27 01:16:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780557788502233088",
  "geo" : { },
  "id_str" : "780566838031900673",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 teeheehee!",
  "id" : 780566838031900673,
  "in_reply_to_status_id" : 780557788502233088,
  "created_at" : "2016-09-27 00:36:51 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "indices" : [ 3, 15 ],
      "id_str" : "4207961",
      "id" : 4207961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/Ma70g7kjrx",
      "expanded_url" : "https:\/\/twitter.com\/kenvogel\/status\/780532591992594432",
      "display_url" : "twitter.com\/kenvogel\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780554166489972736",
  "text" : "RT @chrislhayes: This. Is. Nuts. https:\/\/t.co\/Ma70g7kjrx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/Ma70g7kjrx",
        "expanded_url" : "https:\/\/twitter.com\/kenvogel\/status\/780532591992594432",
        "display_url" : "twitter.com\/kenvogel\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780550274297593856",
    "text" : "This. Is. Nuts. https:\/\/t.co\/Ma70g7kjrx",
    "id" : 780550274297593856,
    "created_at" : "2016-09-26 23:31:01 +0000",
    "user" : {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "protected" : false,
      "id_str" : "4207961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499446228\/MSNBC_Headshot_normal.jpg",
      "id" : 4207961,
      "verified" : true
    }
  },
  "id" : 780554166489972736,
  "created_at" : "2016-09-26 23:46:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780547348623613952",
  "geo" : { },
  "id_str" : "780549371154862080",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind exactly, zach!",
  "id" : 780549371154862080,
  "in_reply_to_status_id" : 780547348623613952,
  "created_at" : "2016-09-26 23:27:26 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Sharp",
      "screen_name" : "DanSharpIBD",
      "indices" : [ 3, 15 ],
      "id_str" : "2905850416",
      "id" : 2905850416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/7Wn3NtzpQS",
      "expanded_url" : "https:\/\/www.statnews.com\/2016\/09\/21\/chronic-fatigue-syndrome-pace-trial\/",
      "display_url" : "statnews.com\/2016\/09\/21\/chr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780525944230543361",
  "text" : "RT @DanSharpIBD: Bad science, lack of accessibility &amp; accountability, greed, ego, can do so much harm to patients.\nhttps:\/\/t.co\/7Wn3NtzpQS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Rehmeyer",
        "screen_name" : "julierehmeyer",
        "indices" : [ 130, 144 ],
        "id_str" : "78729132",
        "id" : 78729132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/7Wn3NtzpQS",
        "expanded_url" : "https:\/\/www.statnews.com\/2016\/09\/21\/chronic-fatigue-syndrome-pace-trial\/",
        "display_url" : "statnews.com\/2016\/09\/21\/chr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780460004696621056",
    "text" : "Bad science, lack of accessibility &amp; accountability, greed, ego, can do so much harm to patients.\nhttps:\/\/t.co\/7Wn3NtzpQS via @julierehmeyer",
    "id" : 780460004696621056,
    "created_at" : "2016-09-26 17:32:20 +0000",
    "user" : {
      "name" : "Dan Sharp",
      "screen_name" : "DanSharpIBD",
      "protected" : false,
      "id_str" : "2905850416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751175281621164033\/3CcpgSvY_normal.jpg",
      "id" : 2905850416,
      "verified" : false
    }
  },
  "id" : 780525944230543361,
  "created_at" : "2016-09-26 21:54:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 86, 93 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/gg2vIwHsz2",
      "expanded_url" : "http:\/\/www.recode.net\/2016\/9\/26\/13053966\/presidential-debate-2016-trump-clinton-television-streaming?utm_campaign=www.recode.net&utm_content=entry&utm_medium=social&utm_source=twitter",
      "display_url" : "recode.net\/2016\/9\/26\/1305\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780476691005247488",
  "text" : "Presidential debate 2016: How to watch and stream tonight https:\/\/t.co\/gg2vIwHsz2 via @Recode",
  "id" : 780476691005247488,
  "created_at" : "2016-09-26 18:38:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/QfKzVMvsLr",
      "expanded_url" : "http:\/\/www.washingtonsblog.com\/2013\/02\/gun-control-was-historically-about-represssing-blacks.html",
      "display_url" : "washingtonsblog.com\/2013\/02\/gun-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780471427325657088",
  "text" : "Gun Control Was \u2013 Historically \u2013 About Repressing Blacks  https:\/\/t.co\/QfKzVMvsLr",
  "id" : 780471427325657088,
  "created_at" : "2016-09-26 18:17:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/4DyHATFvhi",
      "expanded_url" : "https:\/\/twitter.com\/gaycivilrights\/status\/780432747001180160",
      "display_url" : "twitter.com\/gaycivilrights\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780450751923519503",
  "text" : "roll my eyes so hard.. https:\/\/t.co\/4DyHATFvhi",
  "id" : 780450751923519503,
  "created_at" : "2016-09-26 16:55:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "claire chapman",
      "screen_name" : "claire1000001",
      "indices" : [ 3, 17 ],
      "id_str" : "58575176",
      "id" : 58575176
    }, {
      "name" : "BBC Weather",
      "screen_name" : "bbcweather",
      "indices" : [ 119, 130 ],
      "id_str" : "142614009",
      "id" : 142614009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mondaymotivation",
      "indices" : [ 101, 118 ]
    }, {
      "text" : "monday",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780450109322620928",
  "text" : "RT @claire1000001: Good morning, have a great week \uD83D\uDE0A\uD83C\uDF42\uD83C\uDF42 -Red sky in the morning, shepherd's warning?  #mondaymotivation @bbcweather #monday\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Weather",
        "screen_name" : "bbcweather",
        "indices" : [ 100, 111 ],
        "id_str" : "142614009",
        "id" : 142614009
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/claire1000001\/status\/780284502316908544\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/jTkeZLvJfV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtQgm_dXEAAwr2P.jpg",
        "id_str" : "780284489683636224",
        "id" : 780284489683636224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtQgm_dXEAAwr2P.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/jTkeZLvJfV"
      } ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 82, 99 ]
      }, {
        "text" : "monday",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780284502316908544",
    "text" : "Good morning, have a great week \uD83D\uDE0A\uD83C\uDF42\uD83C\uDF42 -Red sky in the morning, shepherd's warning?  #mondaymotivation @bbcweather #monday https:\/\/t.co\/jTkeZLvJfV",
    "id" : 780284502316908544,
    "created_at" : "2016-09-26 05:54:56 +0000",
    "user" : {
      "name" : "claire chapman",
      "screen_name" : "claire1000001",
      "protected" : false,
      "id_str" : "58575176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506728985641111552\/w3nowR7M_normal.jpeg",
      "id" : 58575176,
      "verified" : false
    }
  },
  "id" : 780450109322620928,
  "created_at" : "2016-09-26 16:53:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bottlerocket",
      "screen_name" : "bottlerocket13",
      "indices" : [ 3, 18 ],
      "id_str" : "72075547",
      "id" : 72075547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780450006352486400",
  "text" : "RT @bottlerocket13: My daughter brings a checklist to stores now and just makes random checks. It makes everyone uncomfortable. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bottlerocket13\/status\/780103250460696576\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/UgHJ4eIDSc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtN7w0EWgAM3x81.jpg",
        "id_str" : "780103239006060547",
        "id" : 780103239006060547,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtN7w0EWgAM3x81.jpg",
        "sizes" : [ {
          "h" : 1814,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1063,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 602,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1814,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/UgHJ4eIDSc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/bottlerocket13\/status\/780103250460696576\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/UgHJ4eIDSc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtN7w0DXEAAiTui.jpg",
        "id_str" : "780103239001903104",
        "id" : 780103239001903104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtN7w0DXEAAiTui.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2002
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1173
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 665
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2002
        } ],
        "display_url" : "pic.twitter.com\/UgHJ4eIDSc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780103250460696576",
    "text" : "My daughter brings a checklist to stores now and just makes random checks. It makes everyone uncomfortable. https:\/\/t.co\/UgHJ4eIDSc",
    "id" : 780103250460696576,
    "created_at" : "2016-09-25 17:54:43 +0000",
    "user" : {
      "name" : "Bottlerocket",
      "screen_name" : "bottlerocket13",
      "protected" : false,
      "id_str" : "72075547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783866127977971713\/vFtMjbwo_normal.jpg",
      "id" : 72075547,
      "verified" : true
    }
  },
  "id" : 780450006352486400,
  "created_at" : "2016-09-26 16:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780444770141437956",
  "text" : "i dont know if her talk therapy is helping. i dont know if she needs another med besides ativan. idontknowidontknow.",
  "id" : 780444770141437956,
  "created_at" : "2016-09-26 16:31:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NICA infusion access",
      "screen_name" : "infusioncenter",
      "indices" : [ 3, 18 ],
      "id_str" : "463158123",
      "id" : 463158123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780444145877934080",
  "text" : "RT @infusioncenter: If Medicare \"experiment\" moves forward, doctors won't be able to afford to administer biologics in their offices. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/CqWHaVhHq9",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce54b5ddp\/24gz2",
        "display_url" : "cards.twitter.com\/cards\/18ce54b5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766651648169115648",
    "text" : "If Medicare \"experiment\" moves forward, doctors won't be able to afford to administer biologics in their offices. https:\/\/t.co\/CqWHaVhHq9",
    "id" : 766651648169115648,
    "created_at" : "2016-08-19 15:02:51 +0000",
    "user" : {
      "name" : "NICA infusion access",
      "screen_name" : "infusioncenter",
      "protected" : false,
      "id_str" : "463158123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794236343261937664\/xDUj6BRO_normal.jpg",
      "id" : 463158123,
      "verified" : false
    }
  },
  "id" : 780444145877934080,
  "created_at" : "2016-09-26 16:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aspergers",
      "indices" : [ 121, 131 ]
    }, {
      "text" : "NVLD",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780443891875078145",
  "text" : "sooo angry w myself.. and the school. she flopped about like a dying fish grades 6-12.. I failed her. Do you understand? #aspergers #NVLD",
  "id" : 780443891875078145,
  "created_at" : "2016-09-26 16:28:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArtistLike",
      "screen_name" : "Artistlike",
      "indices" : [ 3, 14 ],
      "id_str" : "29303902",
      "id" : 29303902
    }, {
      "name" : "Mimi Eastman",
      "screen_name" : "marianklb",
      "indices" : [ 121, 131 ],
      "id_str" : "3068650193",
      "id" : 3068650193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780430813515149312",
  "text" : "RT @Artistlike: WOW from a 1986 Lyme vaccine patent. \"Chronic forms...are associated w\/ persistence of spirochetes.\" Thx @marianklb https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mimi Eastman",
        "screen_name" : "marianklb",
        "indices" : [ 105, 115 ],
        "id_str" : "3068650193",
        "id" : 3068650193
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Artistlike\/status\/780208437854556160\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/MUmHU9XDqR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtPbbuEXgAAnJIa.jpg",
        "id_str" : "780208429734526976",
        "id" : 780208429734526976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtPbbuEXgAAnJIa.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/MUmHU9XDqR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Artistlike\/status\/780208437854556160\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/MUmHU9XDqR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtPbbuJWgAAelql.jpg",
        "id_str" : "780208429755432960",
        "id" : 780208429755432960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtPbbuJWgAAelql.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/MUmHU9XDqR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fdpZaCmi2X",
        "expanded_url" : "https:\/\/www.google.com\/patents\/US4721617",
        "display_url" : "google.com\/patents\/US4721\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780208437854556160",
    "text" : "WOW from a 1986 Lyme vaccine patent. \"Chronic forms...are associated w\/ persistence of spirochetes.\" Thx @marianklb https:\/\/t.co\/fdpZaCmi2X https:\/\/t.co\/MUmHU9XDqR",
    "id" : 780208437854556160,
    "created_at" : "2016-09-26 00:52:41 +0000",
    "user" : {
      "name" : "ArtistLike",
      "screen_name" : "Artistlike",
      "protected" : false,
      "id_str" : "29303902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796290757141340160\/mW9SNFCE_normal.jpg",
      "id" : 29303902,
      "verified" : false
    }
  },
  "id" : 780430813515149312,
  "created_at" : "2016-09-26 15:36:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MoonAngelWings",
      "screen_name" : "MoonAngelWings",
      "indices" : [ 3, 18 ],
      "id_str" : "36297832",
      "id" : 36297832
    }, {
      "name" : "PoliticusUSA",
      "screen_name" : "politicususa",
      "indices" : [ 103, 116 ],
      "id_str" : "14792049",
      "id" : 14792049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LpnzrzSJaj",
      "expanded_url" : "http:\/\/www.politicususa.com\/2016\/05\/13\/paul-ryan-plans-starve-unemployed-americans-23-billion-food-stamp-cut.html",
      "display_url" : "politicususa.com\/2016\/05\/13\/pau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780430519288889344",
  "text" : "RT @MoonAngelWings: Paul Ryan Plans To Starve Unemployed Americans With $23 Billion Food Stamp Cut via @politicususa https:\/\/t.co\/LpnzrzSJaj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PoliticusUSA",
        "screen_name" : "politicususa",
        "indices" : [ 83, 96 ],
        "id_str" : "14792049",
        "id" : 14792049
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/LpnzrzSJaj",
        "expanded_url" : "http:\/\/www.politicususa.com\/2016\/05\/13\/paul-ryan-plans-starve-unemployed-americans-23-billion-food-stamp-cut.html",
        "display_url" : "politicususa.com\/2016\/05\/13\/pau\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780244071797301248",
    "text" : "Paul Ryan Plans To Starve Unemployed Americans With $23 Billion Food Stamp Cut via @politicususa https:\/\/t.co\/LpnzrzSJaj",
    "id" : 780244071797301248,
    "created_at" : "2016-09-26 03:14:17 +0000",
    "user" : {
      "name" : "MoonAngelWings",
      "screen_name" : "MoonAngelWings",
      "protected" : false,
      "id_str" : "36297832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276277395\/ee2367249c5f45f677ba409b4b37926e_normal.png",
      "id" : 36297832,
      "verified" : false
    }
  },
  "id" : 780430519288889344,
  "created_at" : "2016-09-26 15:35:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780408374672318464",
  "geo" : { },
  "id_str" : "780427994657611776",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley heehee!",
  "id" : 780427994657611776,
  "in_reply_to_status_id" : 780408374672318464,
  "created_at" : "2016-09-26 15:25:08 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780414875797368834",
  "geo" : { },
  "id_str" : "780427533728776192",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater that must have been distressing yet funny. poor kitty.",
  "id" : 780427533728776192,
  "in_reply_to_status_id" : 780414875797368834,
  "created_at" : "2016-09-26 15:23:18 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shootmenow",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780427067271835649",
  "text" : "looking over old school records ive received.. i can see i failed my daughter. also, the school failed her. #shootmenow",
  "id" : 780427067271835649,
  "created_at" : "2016-09-26 15:21:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YorkshireShepherdess",
      "screen_name" : "AmandaOwen8",
      "indices" : [ 3, 15 ],
      "id_str" : "497353176",
      "id" : 497353176
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmandaOwen8\/status\/780141102330511361\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/RdK3E4zAyM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtOeMnYW8AEEKff.jpg",
      "id_str" : "780141100031995905",
      "id" : 780141100031995905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtOeMnYW8AEEKff.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RdK3E4zAyM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780169386875289600",
  "text" : "RT @AmandaOwen8: A rainbow.\uD83C\uDF08\nMake mine a double.\uD83C\uDF08\uD83C\uDF08 https:\/\/t.co\/RdK3E4zAyM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmandaOwen8\/status\/780141102330511361\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/RdK3E4zAyM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtOeMnYW8AEEKff.jpg",
        "id_str" : "780141100031995905",
        "id" : 780141100031995905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtOeMnYW8AEEKff.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RdK3E4zAyM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780141102330511361",
    "text" : "A rainbow.\uD83C\uDF08\nMake mine a double.\uD83C\uDF08\uD83C\uDF08 https:\/\/t.co\/RdK3E4zAyM",
    "id" : 780141102330511361,
    "created_at" : "2016-09-25 20:25:07 +0000",
    "user" : {
      "name" : "YorkshireShepherdess",
      "screen_name" : "AmandaOwen8",
      "protected" : false,
      "id_str" : "497353176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537020732405211136\/lcQtvBOf_normal.jpeg",
      "id" : 497353176,
      "verified" : false
    }
  },
  "id" : 780169386875289600,
  "created_at" : "2016-09-25 22:17:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780163276659384320",
  "text" : "RT @ZachsMind: We're not serious about solving poverty or homelessness or equality or any of this shit. why are we fooling ourselves? for w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780154835307859969",
    "text" : "We're not serious about solving poverty or homelessness or equality or any of this shit. why are we fooling ourselves? for what purpose?",
    "id" : 780154835307859969,
    "created_at" : "2016-09-25 21:19:41 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 780163276659384320,
  "created_at" : "2016-09-25 21:53:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780162196097667072",
  "text" : "RT @ZachsMind: Why can't we just work towards ensuring basic necessities are met for all? Food, water, clothing, shelter, health. We make t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780155303580962816",
    "text" : "Why can't we just work towards ensuring basic necessities are met for all? Food, water, clothing, shelter, health. We make this difficult.",
    "id" : 780155303580962816,
    "created_at" : "2016-09-25 21:21:33 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 780162196097667072,
  "created_at" : "2016-09-25 21:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riley & Max",
      "screen_name" : "Riley_Max15",
      "indices" : [ 3, 15 ],
      "id_str" : "4867283272",
      "id" : 4867283272
    }, {
      "name" : "Bed Bath & Beyond",
      "screen_name" : "BedBathBeyond",
      "indices" : [ 45, 59 ],
      "id_str" : "372817561",
      "id" : 372817561
    }, {
      "name" : "Cats of Instagram",
      "screen_name" : "catsofinstagram",
      "indices" : [ 95, 111 ],
      "id_str" : "354133033",
      "id" : 354133033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bedbathandbeyond",
      "indices" : [ 60, 77 ]
    }, {
      "text" : "catsofinstagram",
      "indices" : [ 78, 94 ]
    }, {
      "text" : "sundayfunday",
      "indices" : [ 112, 125 ]
    }, {
      "text" : "cute",
      "indices" : [ 126, 131 ]
    }, {
      "text" : "cats",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780138513425629184",
  "text" : "RT @Riley_Max15: Dinner time for the kitties @BedBathBeyond #bedbathandbeyond #catsofinstagram @catsofinstagram #sundayfunday #cute #cats #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bed Bath & Beyond",
        "screen_name" : "BedBathBeyond",
        "indices" : [ 28, 42 ],
        "id_str" : "372817561",
        "id" : 372817561
      }, {
        "name" : "Cats of Instagram",
        "screen_name" : "catsofinstagram",
        "indices" : [ 78, 94 ],
        "id_str" : "354133033",
        "id" : 354133033
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Riley_Max15\/status\/780064508031201284\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/dZZsyyhdXM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNYhM2WcAA80JD.jpg",
        "id_str" : "780064487873343488",
        "id" : 780064487873343488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNYhM2WcAA80JD.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/dZZsyyhdXM"
      } ],
      "hashtags" : [ {
        "text" : "bedbathandbeyond",
        "indices" : [ 43, 60 ]
      }, {
        "text" : "catsofinstagram",
        "indices" : [ 61, 77 ]
      }, {
        "text" : "sundayfunday",
        "indices" : [ 95, 108 ]
      }, {
        "text" : "cute",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "cats",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "love",
        "indices" : [ 121, 126 ]
      }, {
        "text" : "family",
        "indices" : [ 127, 134 ]
      }, {
        "text" : "lol",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780064508031201284",
    "text" : "Dinner time for the kitties @BedBathBeyond #bedbathandbeyond #catsofinstagram @catsofinstagram #sundayfunday #cute #cats #love #family #lol https:\/\/t.co\/dZZsyyhdXM",
    "id" : 780064508031201284,
    "created_at" : "2016-09-25 15:20:46 +0000",
    "user" : {
      "name" : "Riley & Max",
      "screen_name" : "Riley_Max15",
      "protected" : false,
      "id_str" : "4867283272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693887456190578690\/rUH04dvV_normal.jpg",
      "id" : 4867283272,
      "verified" : false
    }
  },
  "id" : 780138513425629184,
  "created_at" : "2016-09-25 20:14:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Independent",
      "screen_name" : "Independent",
      "indices" : [ 3, 15 ],
      "id_str" : "16973333",
      "id" : 16973333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/UHOBe4aCPn",
      "expanded_url" : "http:\/\/ind.pn\/2cw4zkA",
      "display_url" : "ind.pn\/2cw4zkA"
    } ]
  },
  "geo" : { },
  "id_str" : "780081099506679809",
  "text" : "RT @Independent: China has officially started looking for aliens using the world's biggest telescope https:\/\/t.co\/UHOBe4aCPn https:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Independent\/status\/780057109568389120\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/cAfRSGOwHZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNRsggWEAA_8ek.jpg",
        "id_str" : "780056985546919936",
        "id" : 780056985546919936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNRsggWEAA_8ek.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1026,
          "resize" : "fit",
          "w" : 1368
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1026,
          "resize" : "fit",
          "w" : 1368
        } ],
        "display_url" : "pic.twitter.com\/cAfRSGOwHZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/UHOBe4aCPn",
        "expanded_url" : "http:\/\/ind.pn\/2cw4zkA",
        "display_url" : "ind.pn\/2cw4zkA"
      } ]
    },
    "geo" : { },
    "id_str" : "780057109568389120",
    "text" : "China has officially started looking for aliens using the world's biggest telescope https:\/\/t.co\/UHOBe4aCPn https:\/\/t.co\/cAfRSGOwHZ",
    "id" : 780057109568389120,
    "created_at" : "2016-09-25 14:51:22 +0000",
    "user" : {
      "name" : "The Independent",
      "screen_name" : "Independent",
      "protected" : false,
      "id_str" : "16973333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583628771972018176\/ztJn926g_normal.png",
      "id" : 16973333,
      "verified" : true
    }
  },
  "id" : 780081099506679809,
  "created_at" : "2016-09-25 16:26:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer",
      "screen_name" : "HeSlimedMeRay",
      "indices" : [ 3, 17 ],
      "id_str" : "388034870",
      "id" : 388034870
    }, {
      "name" : "Rockin The Border",
      "screen_name" : "irolands",
      "indices" : [ 19, 28 ],
      "id_str" : "269796453",
      "id" : 269796453
    }, {
      "name" : "\u0391\u03C4\u03B7\u03B5\u03B9s\u03C4 \u0395ng\u03B9n\u03B5\u03B5r",
      "screen_name" : "AtheistEngineer",
      "indices" : [ 29, 45 ],
      "id_str" : "2707065429",
      "id" : 2707065429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780080924344066048",
  "text" : "RT @HeSlimedMeRay: @irolands @AtheistEngineer Yup. I was asked to stop attending Sunday school...asked too many questions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rockin The Border",
        "screen_name" : "irolands",
        "indices" : [ 0, 9 ],
        "id_str" : "269796453",
        "id" : 269796453
      }, {
        "name" : "\u0391\u03C4\u03B7\u03B5\u03B9s\u03C4 \u0395ng\u03B9n\u03B5\u03B5r",
        "screen_name" : "AtheistEngineer",
        "indices" : [ 10, 26 ],
        "id_str" : "2707065429",
        "id" : 2707065429
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "780044022194708485",
    "geo" : { },
    "id_str" : "780044545245401088",
    "in_reply_to_user_id" : 269796453,
    "text" : "@irolands @AtheistEngineer Yup. I was asked to stop attending Sunday school...asked too many questions.",
    "id" : 780044545245401088,
    "in_reply_to_status_id" : 780044022194708485,
    "created_at" : "2016-09-25 14:01:26 +0000",
    "in_reply_to_screen_name" : "irolands",
    "in_reply_to_user_id_str" : "269796453",
    "user" : {
      "name" : "Jennifer",
      "screen_name" : "HeSlimedMeRay",
      "protected" : false,
      "id_str" : "388034870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365475922329600\/7id8gABC_normal.jpg",
      "id" : 388034870,
      "verified" : false
    }
  },
  "id" : 780080924344066048,
  "created_at" : "2016-09-25 16:26:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Khan",
      "screen_name" : "Khanoisseur",
      "indices" : [ 3, 15 ],
      "id_str" : "373564351",
      "id" : 373564351
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Khanoisseur\/status\/776652759902789632\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/l4ojim2JyC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Csc5kQTVUAAxVb4.jpg",
      "id_str" : "776652755758829568",
      "id" : 776652755758829568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csc5kQTVUAAxVb4.jpg",
      "sizes" : [ {
        "h" : 152,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 606
      } ],
      "display_url" : "pic.twitter.com\/l4ojim2JyC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780080545069948929",
  "text" : "RT @Khanoisseur: This was Trump's response when asked how he plans to replace Obamacare \n\nUnfu*^%#%believable https:\/\/t.co\/l4ojim2JyC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Khanoisseur\/status\/776652759902789632\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/l4ojim2JyC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Csc5kQTVUAAxVb4.jpg",
        "id_str" : "776652755758829568",
        "id" : 776652755758829568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csc5kQTVUAAxVb4.jpg",
        "sizes" : [ {
          "h" : 152,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 606
        } ],
        "display_url" : "pic.twitter.com\/l4ojim2JyC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "759173829277122560",
    "geo" : { },
    "id_str" : "776652759902789632",
    "in_reply_to_user_id" : 373564351,
    "text" : "This was Trump's response when asked how he plans to replace Obamacare \n\nUnfu*^%#%believable https:\/\/t.co\/l4ojim2JyC",
    "id" : 776652759902789632,
    "in_reply_to_status_id" : 759173829277122560,
    "created_at" : "2016-09-16 05:23:42 +0000",
    "in_reply_to_screen_name" : "Khanoisseur",
    "in_reply_to_user_id_str" : "373564351",
    "user" : {
      "name" : "Adam Khan",
      "screen_name" : "Khanoisseur",
      "protected" : false,
      "id_str" : "373564351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767965928445227008\/SQYnBzP0_normal.jpg",
      "id" : 373564351,
      "verified" : false
    }
  },
  "id" : 780080545069948929,
  "created_at" : "2016-09-25 16:24:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Stiles",
      "screen_name" : "GregMTBusiness",
      "indices" : [ 3, 18 ],
      "id_str" : "110453333",
      "id" : 110453333
    }, {
      "name" : "Christianity Today",
      "screen_name" : "CTmagazine",
      "indices" : [ 123, 134 ],
      "id_str" : "15027207",
      "id" : 15027207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/9VqCh2UWZX",
      "expanded_url" : "http:\/\/www.christianitytoday.com\/gleanings\/2016\/september\/after-tweaking-29-verses-bible-esv-english-standard-version.html?visit_source=twitter",
      "display_url" : "christianitytoday.com\/gleanings\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780079948052697088",
  "text" : "RT @GregMTBusiness: After Tweaking 29 Verses, Bible Translation Becomes Unchanging Word of God https:\/\/t.co\/9VqCh2UWZX via @ctmagazine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christianity Today",
        "screen_name" : "CTmagazine",
        "indices" : [ 103, 114 ],
        "id_str" : "15027207",
        "id" : 15027207
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/9VqCh2UWZX",
        "expanded_url" : "http:\/\/www.christianitytoday.com\/gleanings\/2016\/september\/after-tweaking-29-verses-bible-esv-english-standard-version.html?visit_source=twitter",
        "display_url" : "christianitytoday.com\/gleanings\/2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776098037680574465",
    "text" : "After Tweaking 29 Verses, Bible Translation Becomes Unchanging Word of God https:\/\/t.co\/9VqCh2UWZX via @ctmagazine",
    "id" : 776098037680574465,
    "created_at" : "2016-09-14 16:39:26 +0000",
    "user" : {
      "name" : "Greg Stiles",
      "screen_name" : "GregMTBusiness",
      "protected" : false,
      "id_str" : "110453333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449728467467132928\/IPdp_YCS_normal.jpeg",
      "id" : 110453333,
      "verified" : false
    }
  },
  "id" : 780079948052697088,
  "created_at" : "2016-09-25 16:22:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Morgan",
      "screen_name" : "RachelMorganMFL",
      "indices" : [ 3, 19 ],
      "id_str" : "1151684730",
      "id" : 1151684730
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RachelMorganMFL\/status\/780064387637866496\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/AL7SdYlcgp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNYa8JWIAAVIoC.jpg",
      "id_str" : "780064380310396928",
      "id" : 780064380310396928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNYa8JWIAAVIoC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/AL7SdYlcgp"
    } ],
    "hashtags" : [ {
      "text" : "knowyourshit",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780078674536239104",
  "text" : "RT @RachelMorganMFL: #knowyourshit https:\/\/t.co\/AL7SdYlcgp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RachelMorganMFL\/status\/780064387637866496\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/AL7SdYlcgp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNYa8JWIAAVIoC.jpg",
        "id_str" : "780064380310396928",
        "id" : 780064380310396928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNYa8JWIAAVIoC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/AL7SdYlcgp"
      } ],
      "hashtags" : [ {
        "text" : "knowyourshit",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780064387637866496",
    "text" : "#knowyourshit https:\/\/t.co\/AL7SdYlcgp",
    "id" : 780064387637866496,
    "created_at" : "2016-09-25 15:20:17 +0000",
    "user" : {
      "name" : "Rachel Morgan",
      "screen_name" : "RachelMorganMFL",
      "protected" : false,
      "id_str" : "1151684730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800847669375762432\/i0IBWVmY_normal.jpg",
      "id" : 1151684730,
      "verified" : false
    }
  },
  "id" : 780078674536239104,
  "created_at" : "2016-09-25 16:17:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779989776413945856",
  "geo" : { },
  "id_str" : "780078093750992900",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides what a pain. So glad I got away from iTunes.",
  "id" : 780078093750992900,
  "in_reply_to_status_id" : 779989776413945856,
  "created_at" : "2016-09-25 16:14:45 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "indices" : [ 3, 15 ],
      "id_str" : "2147864503",
      "id" : 2147864503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/779281713360998400\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/2SMCjysVcH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtCQeHyWAAAy2Jn.jpg",
      "id_str" : "779281582695776256",
      "id" : 779281582695776256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtCQeHyWAAAy2Jn.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/2SMCjysVcH"
    } ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779870294076948480",
  "text" : "RT @goodbirding: Black Swallowtail Butterfly nectaring on a New England Aster. #nature. https:\/\/t.co\/2SMCjysVcH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/779281713360998400\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/2SMCjysVcH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtCQeHyWAAAy2Jn.jpg",
        "id_str" : "779281582695776256",
        "id" : 779281582695776256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtCQeHyWAAAy2Jn.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/2SMCjysVcH"
      } ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 62, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779281713360998400",
    "text" : "Black Swallowtail Butterfly nectaring on a New England Aster. #nature. https:\/\/t.co\/2SMCjysVcH",
    "id" : 779281713360998400,
    "created_at" : "2016-09-23 11:30:13 +0000",
    "user" : {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "protected" : false,
      "id_str" : "2147864503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630185970\/5de84b9e4fc1f4fdba0d8f537c4d543e_normal.jpeg",
      "id" : 2147864503,
      "verified" : false
    }
  },
  "id" : 779870294076948480,
  "created_at" : "2016-09-25 02:29:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779858061490024448",
  "text" : "RT @BrianRathbone: There are times when unexpected change can be extremely unpleasant and yet somehow bring about positive change. #HangInT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HangInThere",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779856879468044288",
    "text" : "There are times when unexpected change can be extremely unpleasant and yet somehow bring about positive change. #HangInThere",
    "id" : 779856879468044288,
    "created_at" : "2016-09-25 01:35:43 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 779858061490024448,
  "created_at" : "2016-09-25 01:40:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Weinstein",
      "screen_name" : "Joshstrangehill",
      "indices" : [ 3, 19 ],
      "id_str" : "1611098694",
      "id" : 1611098694
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joshstrangehill\/status\/779743629103419392\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Ew4hTZoPJq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtI0skgVIAACQnM.jpg",
      "id_str" : "779743625806684160",
      "id" : 779743625806684160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtI0skgVIAACQnM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 380
      } ],
      "display_url" : "pic.twitter.com\/Ew4hTZoPJq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779844142763507713",
  "text" : "RT @Joshstrangehill: I like the motto of this old candy company https:\/\/t.co\/Ew4hTZoPJq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joshstrangehill\/status\/779743629103419392\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/Ew4hTZoPJq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtI0skgVIAACQnM.jpg",
        "id_str" : "779743625806684160",
        "id" : 779743625806684160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtI0skgVIAACQnM.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 380
        } ],
        "display_url" : "pic.twitter.com\/Ew4hTZoPJq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779743629103419392",
    "text" : "I like the motto of this old candy company https:\/\/t.co\/Ew4hTZoPJq",
    "id" : 779743629103419392,
    "created_at" : "2016-09-24 18:05:42 +0000",
    "user" : {
      "name" : "Josh Weinstein",
      "screen_name" : "Joshstrangehill",
      "protected" : false,
      "id_str" : "1611098694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000168285219\/10cafea472ca3702e15c98dd2e387e05_normal.jpeg",
      "id" : 1611098694,
      "verified" : true
    }
  },
  "id" : 779844142763507713,
  "created_at" : "2016-09-25 00:45:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "indices" : [ 3, 12 ],
      "id_str" : "47791514",
      "id" : 47791514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779842715051843584",
  "text" : "RT @Lymenews: Interview with Dr. Corson, a top ILADS physician. She started learning about Lyme when her son almost died from it. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lymenews\/status\/779803099556900865\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/Cp6FXd0m0p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJqyQmWgAA1Ryi.jpg",
        "id_str" : "779803097170345984",
        "id" : 779803097170345984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJqyQmWgAA1Ryi.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 674
        } ],
        "display_url" : "pic.twitter.com\/Cp6FXd0m0p"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/NdTzKGI5P6",
        "expanded_url" : "http:\/\/buff.ly\/2d8JigA",
        "display_url" : "buff.ly\/2d8JigA"
      } ]
    },
    "geo" : { },
    "id_str" : "779803099556900865",
    "text" : "Interview with Dr. Corson, a top ILADS physician. She started learning about Lyme when her son almost died from it. https:\/\/t.co\/NdTzKGI5P6 https:\/\/t.co\/Cp6FXd0m0p",
    "id" : 779803099556900865,
    "created_at" : "2016-09-24 22:02:01 +0000",
    "user" : {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "protected" : false,
      "id_str" : "47791514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585121378396811264\/cBO4OfUQ_normal.jpg",
      "id" : 47791514,
      "verified" : false
    }
  },
  "id" : 779842715051843584,
  "created_at" : "2016-09-25 00:39:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Sparks",
      "screen_name" : "NateSparks130",
      "indices" : [ 3, 17 ],
      "id_str" : "3374392409",
      "id" : 3374392409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779839356009910273",
  "text" : "RT @NateSparks130: Because nothing cures depression like being told how evil you are?\n\nLet me guess, Schizophrenia is really demon possessi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/538Lf6linM",
        "expanded_url" : "https:\/\/twitter.com\/NoutheticC\/status\/776953726351409152",
        "display_url" : "twitter.com\/NoutheticC\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779824556978630656",
    "text" : "Because nothing cures depression like being told how evil you are?\n\nLet me guess, Schizophrenia is really demon possession, right? https:\/\/t.co\/538Lf6linM",
    "id" : 779824556978630656,
    "created_at" : "2016-09-24 23:27:17 +0000",
    "user" : {
      "name" : "Nate Sparks",
      "screen_name" : "NateSparks130",
      "protected" : false,
      "id_str" : "3374392409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779738157646512128\/zYHFg4In_normal.jpg",
      "id" : 3374392409,
      "verified" : false
    }
  },
  "id" : 779839356009910273,
  "created_at" : "2016-09-25 00:26:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "indices" : [ 3, 12 ],
      "id_str" : "11575102",
      "id" : 11575102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KeithLamontScott",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779839048709963776",
  "text" : "RT @tifotter: And all you were doing was sitting in your truck, minding your own fucking business. #KeithLamontScott",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KeithLamontScott",
        "indices" : [ 85, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779837720763830273",
    "text" : "And all you were doing was sitting in your truck, minding your own fucking business. #KeithLamontScott",
    "id" : 779837720763830273,
    "created_at" : "2016-09-25 00:19:35 +0000",
    "user" : {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "protected" : false,
      "id_str" : "11575102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579777071850737664\/0bwnd0kt_normal.jpg",
      "id" : 11575102,
      "verified" : false
    }
  },
  "id" : 779839048709963776,
  "created_at" : "2016-09-25 00:24:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Yang",
      "screen_name" : "originalspin",
      "indices" : [ 3, 16 ],
      "id_str" : "14278608",
      "id" : 14278608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779839023728758784",
  "text" : "RT @originalspin: He had no gun. He made no aggressive moves. He seemed confused and scared. And he was shot in cold blood by cops terrifie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/JEqeOVq2jL",
        "expanded_url" : "https:\/\/twitter.com\/trueblacknews\/status\/779834853713932288",
        "display_url" : "twitter.com\/trueblacknews\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779836611336949760",
    "text" : "He had no gun. He made no aggressive moves. He seemed confused and scared. And he was shot in cold blood by cops terrified of his blackness. https:\/\/t.co\/JEqeOVq2jL",
    "id" : 779836611336949760,
    "created_at" : "2016-09-25 00:15:11 +0000",
    "user" : {
      "name" : "Jeff Yang",
      "screen_name" : "originalspin",
      "protected" : false,
      "id_str" : "14278608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763664980826689537\/EM1ycZor_normal.jpg",
      "id" : 14278608,
      "verified" : true
    }
  },
  "id" : 779839023728758784,
  "created_at" : "2016-09-25 00:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shadowvane Podcast",
      "screen_name" : "ShadowvaneCast",
      "indices" : [ 3, 18 ],
      "id_str" : "2647739072",
      "id" : 2647739072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/dSCPI1gwQv",
      "expanded_url" : "http:\/\/www.clammr.com\/app\/clammr\/237395",
      "display_url" : "clammr.com\/app\/clammr\/237\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779838421481160704",
  "text" : "RT @ShadowvaneCast: Haven't heard Episode 1 of 1692? Need to re-listen before we release Episode 2? Check us out! https:\/\/t.co\/dSCPI1gwQv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/dSCPI1gwQv",
        "expanded_url" : "http:\/\/www.clammr.com\/app\/clammr\/237395",
        "display_url" : "clammr.com\/app\/clammr\/237\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779797226746966016",
    "text" : "Haven't heard Episode 1 of 1692? Need to re-listen before we release Episode 2? Check us out! https:\/\/t.co\/dSCPI1gwQv",
    "id" : 779797226746966016,
    "created_at" : "2016-09-24 21:38:41 +0000",
    "user" : {
      "name" : "Shadowvane Podcast",
      "screen_name" : "ShadowvaneCast",
      "protected" : false,
      "id_str" : "2647739072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772828348636655616\/kaaUvVrS_normal.jpg",
      "id" : 2647739072,
      "verified" : false
    }
  },
  "id" : 779838421481160704,
  "created_at" : "2016-09-25 00:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Swaine",
      "screen_name" : "jonswaine",
      "indices" : [ 3, 13 ],
      "id_str" : "19817778",
      "id" : 19817778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/HPSo9miCc2",
      "expanded_url" : "https:\/\/twitter.com\/CWatkinsTV\/status\/779812861556232193",
      "display_url" : "twitter.com\/CWatkinsTV\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779827049682833412",
  "text" : "RT @jonswaine: Dashcam video shows that Keith Scott was shot while slowly backing away with his hands at his sides https:\/\/t.co\/HPSo9miCc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/HPSo9miCc2",
        "expanded_url" : "https:\/\/twitter.com\/CWatkinsTV\/status\/779812861556232193",
        "display_url" : "twitter.com\/CWatkinsTV\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779817769386840064",
    "text" : "Dashcam video shows that Keith Scott was shot while slowly backing away with his hands at his sides https:\/\/t.co\/HPSo9miCc2",
    "id" : 779817769386840064,
    "created_at" : "2016-09-24 23:00:19 +0000",
    "user" : {
      "name" : "Jon Swaine",
      "screen_name" : "jonswaine",
      "protected" : false,
      "id_str" : "19817778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523120150669586432\/AS14NZtS_normal.jpeg",
      "id" : 19817778,
      "verified" : true
    }
  },
  "id" : 779827049682833412,
  "created_at" : "2016-09-24 23:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rambeling",
      "screen_name" : "Rambeling",
      "indices" : [ 3, 13 ],
      "id_str" : "359618413",
      "id" : 359618413
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 78, 82 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlueLivesMurder",
      "indices" : [ 95, 111 ]
    }, {
      "text" : "CharlotteProtest",
      "indices" : [ 112, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779826099064823808",
  "text" : "RT @Rambeling: Having a TBI does not mean you're \"mentally deranged,\" asshole @CNN commentator #BlueLivesMurder #CharlotteProtest",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 63, 67 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlueLivesMurder",
        "indices" : [ 80, 96 ]
      }, {
        "text" : "CharlotteProtest",
        "indices" : [ 97, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779824405325176832",
    "text" : "Having a TBI does not mean you're \"mentally deranged,\" asshole @CNN commentator #BlueLivesMurder #CharlotteProtest",
    "id" : 779824405325176832,
    "created_at" : "2016-09-24 23:26:41 +0000",
    "user" : {
      "name" : "Rambeling",
      "screen_name" : "Rambeling",
      "protected" : false,
      "id_str" : "359618413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790327337724284928\/wJmeuCFH_normal.jpg",
      "id" : 359618413,
      "verified" : false
    }
  },
  "id" : 779826099064823808,
  "created_at" : "2016-09-24 23:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KeithLamontScott",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779818088015552512",
  "text" : "RT @tchop__StL: Wait. Wasn't the story that they didn't see the gun until #KeithLamontScott went back into his truck and got it after initi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tchop__StL\/status\/779813739235307520\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/FLgez5N0FY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJ0beKWYAAQBPj.jpg",
        "id_str" : "779813700790280192",
        "id" : 779813700790280192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJ0beKWYAAQBPj.jpg",
        "sizes" : [ {
          "h" : 481,
          "resize" : "fit",
          "w" : 361
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 361
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 361
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 361
        } ],
        "display_url" : "pic.twitter.com\/FLgez5N0FY"
      } ],
      "hashtags" : [ {
        "text" : "KeithLamontScott",
        "indices" : [ 58, 75 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779812687412858880",
    "geo" : { },
    "id_str" : "779813739235307520",
    "in_reply_to_user_id" : 9112032,
    "text" : "Wait. Wasn't the story that they didn't see the gun until #KeithLamontScott went back into his truck and got it after initial confrontation? https:\/\/t.co\/FLgez5N0FY",
    "id" : 779813739235307520,
    "in_reply_to_status_id" : 779812687412858880,
    "created_at" : "2016-09-24 22:44:18 +0000",
    "in_reply_to_screen_name" : "tchopstl_",
    "in_reply_to_user_id_str" : "9112032",
    "user" : {
      "name" : "TC",
      "screen_name" : "tchopstl_",
      "protected" : false,
      "id_str" : "9112032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616609311050080256\/L0t3dno6_normal.jpg",
      "id" : 9112032,
      "verified" : false
    }
  },
  "id" : 779818088015552512,
  "created_at" : "2016-09-24 23:01:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/779720717319438340\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/jD2aWZRRW0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIftlKWIAAfVIG.jpg",
      "id_str" : "779720553418596352",
      "id" : 779720553418596352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIftlKWIAAfVIG.jpg",
      "sizes" : [ {
        "h" : 836,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1653
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1653
      } ],
      "display_url" : "pic.twitter.com\/jD2aWZRRW0"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/779720717319438340\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/jD2aWZRRW0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIftlWWYAAkfs_.jpg",
      "id_str" : "779720553468944384",
      "id" : 779720553468944384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIftlWWYAAkfs_.jpg",
      "sizes" : [ {
        "h" : 808,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1188,
        "resize" : "fit",
        "w" : 1764
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1188,
        "resize" : "fit",
        "w" : 1764
      } ],
      "display_url" : "pic.twitter.com\/jD2aWZRRW0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779795126986141701",
  "text" : "RT @newlandfarm: Elf and his ladies - love is being a scratching post! https:\/\/t.co\/jD2aWZRRW0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/779720717319438340\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/jD2aWZRRW0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIftlKWIAAfVIG.jpg",
        "id_str" : "779720553418596352",
        "id" : 779720553418596352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIftlKWIAAfVIG.jpg",
        "sizes" : [ {
          "h" : 836,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1653
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1653
        } ],
        "display_url" : "pic.twitter.com\/jD2aWZRRW0"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/779720717319438340\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/jD2aWZRRW0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIftlWWYAAkfs_.jpg",
        "id_str" : "779720553468944384",
        "id" : 779720553468944384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIftlWWYAAkfs_.jpg",
        "sizes" : [ {
          "h" : 808,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1188,
          "resize" : "fit",
          "w" : 1764
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1188,
          "resize" : "fit",
          "w" : 1764
        } ],
        "display_url" : "pic.twitter.com\/jD2aWZRRW0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779720717319438340",
    "text" : "Elf and his ladies - love is being a scratching post! https:\/\/t.co\/jD2aWZRRW0",
    "id" : 779720717319438340,
    "created_at" : "2016-09-24 16:34:40 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 779795126986141701,
  "created_at" : "2016-09-24 21:30:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/LNvLAtZieG",
      "expanded_url" : "https:\/\/twitter.com\/mama4obama1\/status\/779783732295266308",
      "display_url" : "twitter.com\/mama4obama1\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779789753734561793",
  "text" : "RT @deray: and the story changes again. https:\/\/t.co\/LNvLAtZieG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/LNvLAtZieG",
        "expanded_url" : "https:\/\/twitter.com\/mama4obama1\/status\/779783732295266308",
        "display_url" : "twitter.com\/mama4obama1\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779784907560067072",
    "text" : "and the story changes again. https:\/\/t.co\/LNvLAtZieG",
    "id" : 779784907560067072,
    "created_at" : "2016-09-24 20:49:44 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 779789753734561793,
  "created_at" : "2016-09-24 21:08:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779786934793142273\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/etPimqVpCO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJcDifWIAErN-b.jpg",
      "id_str" : "779786901356158977",
      "id" : 779786901356158977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJcDifWIAErN-b.jpg",
      "sizes" : [ {
        "h" : 1728,
        "resize" : "fit",
        "w" : 2304
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/etPimqVpCO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779789605042286592",
  "text" : "RT @wildwitchyju: https:\/\/t.co\/etPimqVpCO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779786934793142273\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/etPimqVpCO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJcDifWIAErN-b.jpg",
        "id_str" : "779786901356158977",
        "id" : 779786901356158977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJcDifWIAErN-b.jpg",
        "sizes" : [ {
          "h" : 1728,
          "resize" : "fit",
          "w" : 2304
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/etPimqVpCO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779786934793142273",
    "text" : "https:\/\/t.co\/etPimqVpCO",
    "id" : 779786934793142273,
    "created_at" : "2016-09-24 20:57:47 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 779789605042286592,
  "created_at" : "2016-09-24 21:08:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bree Newsome",
      "screen_name" : "BreeNewsome",
      "indices" : [ 3, 15 ],
      "id_str" : "110326494",
      "id" : 110326494
    }, {
      "name" : "CMPD News",
      "screen_name" : "CMPD",
      "indices" : [ 18, 23 ],
      "id_str" : "348056993",
      "id" : 348056993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779789364356407298",
  "text" : "RT @BreeNewsome: .@CMPD Do you make any provision whatsoever for members of community who are deaf, have disabilities or mental health issu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CMPD News",
        "screen_name" : "CMPD",
        "indices" : [ 1, 6 ],
        "id_str" : "348056993",
        "id" : 348056993
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/pOr9iLqbnK",
        "expanded_url" : "https:\/\/twitter.com\/CWatkinsTV\/status\/779786073291579394",
        "display_url" : "twitter.com\/CWatkinsTV\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779786483704164352",
    "text" : ".@CMPD Do you make any provision whatsoever for members of community who are deaf, have disabilities or mental health issues? \uD83E\uDD14 https:\/\/t.co\/pOr9iLqbnK",
    "id" : 779786483704164352,
    "created_at" : "2016-09-24 20:56:00 +0000",
    "user" : {
      "name" : "Bree Newsome",
      "screen_name" : "BreeNewsome",
      "protected" : false,
      "id_str" : "110326494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596751599554428928\/lxl1GrH8_normal.jpg",
      "id" : 110326494,
      "verified" : true
    }
  },
  "id" : 779789364356407298,
  "created_at" : "2016-09-24 21:07:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/tagSv6Rx93",
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779784688881831936",
      "display_url" : "twitter.com\/wildwitchyju\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779789216779739136",
  "text" : "peekaboo, I see you! : ) https:\/\/t.co\/tagSv6Rx93",
  "id" : 779789216779739136,
  "created_at" : "2016-09-24 21:06:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim Haramein",
      "screen_name" : "NassimHaramein",
      "indices" : [ 3, 18 ],
      "id_str" : "21821924",
      "id" : 21821924
    }, {
      "name" : "Connected Universe",
      "screen_name" : "ConnectdUnivrse",
      "indices" : [ 46, 62 ],
      "id_str" : "2827388530",
      "id" : 2827388530
    }, {
      "name" : "Patrick Stewart",
      "screen_name" : "SirPatStew",
      "indices" : [ 72, 83 ],
      "id_str" : "602317143",
      "id" : 602317143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779787466253463552",
  "text" : "RT @NassimHaramein: Watch the new trailer for @ConnectdUnivrse film ft. @SirPatStew &amp; get your tix to the premier in LA on Monday! \u2013&gt;  http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Connected Universe",
        "screen_name" : "ConnectdUnivrse",
        "indices" : [ 26, 42 ],
        "id_str" : "2827388530",
        "id" : 2827388530
      }, {
        "name" : "Patrick Stewart",
        "screen_name" : "SirPatStew",
        "indices" : [ 52, 63 ],
        "id_str" : "602317143",
        "id" : 602317143
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NassimHaramein\/status\/779781313989533696\/photo\/1",
        "indices" : [ 146, 169 ],
        "url" : "https:\/\/t.co\/hkEWw9FmU1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJW9BZVYAEvwdm.jpg",
        "id_str" : "779781291835219969",
        "id" : 779781291835219969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJW9BZVYAEvwdm.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/hkEWw9FmU1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/Flsxq0ziCN",
        "expanded_url" : "http:\/\/getconnected.resonance.is",
        "display_url" : "getconnected.resonance.is"
      } ]
    },
    "geo" : { },
    "id_str" : "779781313989533696",
    "text" : "Watch the new trailer for @ConnectdUnivrse film ft. @SirPatStew &amp; get your tix to the premier in LA on Monday! \u2013&gt;  https:\/\/t.co\/Flsxq0ziCN https:\/\/t.co\/hkEWw9FmU1",
    "id" : 779781313989533696,
    "created_at" : "2016-09-24 20:35:27 +0000",
    "user" : {
      "name" : "Nassim Haramein",
      "screen_name" : "NassimHaramein",
      "protected" : false,
      "id_str" : "21821924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2429905981\/z7lrxoa4ujpurojzt4mu_normal.jpeg",
      "id" : 21821924,
      "verified" : false
    }
  },
  "id" : 779787466253463552,
  "created_at" : "2016-09-24 20:59:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779785089425215488\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/obGSzeZoMJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJaXAgXEAIXnYL.jpg",
      "id_str" : "779785036807737346",
      "id" : 779785036807737346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJaXAgXEAIXnYL.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 2304
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/obGSzeZoMJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779787238808903684",
  "text" : "RT @wildwitchyju: https:\/\/t.co\/obGSzeZoMJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779785089425215488\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/obGSzeZoMJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJaXAgXEAIXnYL.jpg",
        "id_str" : "779785036807737346",
        "id" : 779785036807737346,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJaXAgXEAIXnYL.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1728,
          "resize" : "fit",
          "w" : 2304
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/obGSzeZoMJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779785089425215488",
    "text" : "https:\/\/t.co\/obGSzeZoMJ",
    "id" : 779785089425215488,
    "created_at" : "2016-09-24 20:50:27 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 779787238808903684,
  "created_at" : "2016-09-24 20:59:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779785435757289472\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/hMVZfOBrWc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJarDvXEAAig6h.jpg",
      "id_str" : "779785381273341952",
      "id" : 779785381273341952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJarDvXEAAig6h.jpg",
      "sizes" : [ {
        "h" : 552,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1663,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2178,
        "resize" : "fit",
        "w" : 2683
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 974,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/hMVZfOBrWc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779787078079016960",
  "text" : "RT @wildwitchyju: https:\/\/t.co\/hMVZfOBrWc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/779785435757289472\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/hMVZfOBrWc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJarDvXEAAig6h.jpg",
        "id_str" : "779785381273341952",
        "id" : 779785381273341952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJarDvXEAAig6h.jpg",
        "sizes" : [ {
          "h" : 552,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1663,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2178,
          "resize" : "fit",
          "w" : 2683
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 974,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/hMVZfOBrWc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779785435757289472",
    "text" : "https:\/\/t.co\/hMVZfOBrWc",
    "id" : 779785435757289472,
    "created_at" : "2016-09-24 20:51:50 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 779787078079016960,
  "created_at" : "2016-09-24 20:58:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rambeling",
      "screen_name" : "Rambeling",
      "indices" : [ 3, 13 ],
      "id_str" : "359618413",
      "id" : 359618413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/A6Wnrl0yr9",
      "expanded_url" : "https:\/\/twitter.com\/wcnc\/status\/779782147414556676",
      "display_url" : "twitter.com\/wcnc\/status\/77\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779786633331740672",
  "text" : "RT @Rambeling: \uD83E\uDD14So, tampered evidence then? B\/c we already saw diversions from narrative in wife's video https:\/\/t.co\/A6Wnrl0yr9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/A6Wnrl0yr9",
        "expanded_url" : "https:\/\/twitter.com\/wcnc\/status\/779782147414556676",
        "display_url" : "twitter.com\/wcnc\/status\/77\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779785725436911616",
    "text" : "\uD83E\uDD14So, tampered evidence then? B\/c we already saw diversions from narrative in wife's video https:\/\/t.co\/A6Wnrl0yr9",
    "id" : 779785725436911616,
    "created_at" : "2016-09-24 20:52:59 +0000",
    "user" : {
      "name" : "Rambeling",
      "screen_name" : "Rambeling",
      "protected" : false,
      "id_str" : "359618413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790327337724284928\/wJmeuCFH_normal.jpg",
      "id" : 359618413,
      "verified" : false
    }
  },
  "id" : 779786633331740672,
  "created_at" : "2016-09-24 20:56:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David M. Perry",
      "screen_name" : "Lollardfish",
      "indices" : [ 3, 15 ],
      "id_str" : "108094234",
      "id" : 108094234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779774228350382080",
  "text" : "RT @Lollardfish: Autism Speaks is a problem.\n\nThe lack of awareness of a MAJOR disability rights discourse, driven by self advocates, might\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779712918829031424",
    "geo" : { },
    "id_str" : "779713154339237888",
    "in_reply_to_user_id" : 108094234,
    "text" : "Autism Speaks is a problem.\n\nThe lack of awareness of a MAJOR disability rights discourse, driven by self advocates, might be a bigger one.",
    "id" : 779713154339237888,
    "in_reply_to_status_id" : 779712918829031424,
    "created_at" : "2016-09-24 16:04:37 +0000",
    "in_reply_to_screen_name" : "Lollardfish",
    "in_reply_to_user_id_str" : "108094234",
    "user" : {
      "name" : "David M. Perry",
      "screen_name" : "Lollardfish",
      "protected" : false,
      "id_str" : "108094234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342950681\/782b24838dc7f5c22e405997772590e2_normal.png",
      "id" : 108094234,
      "verified" : true
    }
  },
  "id" : 779774228350382080,
  "created_at" : "2016-09-24 20:07:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "feedly",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "android",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/nWHtHcWUeR",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/4cebd51bec154c\/77086?app_id=339",
      "display_url" : "producthunt.com\/r\/4cebd51bec15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779761541377843200",
  "text" : "Whileaway - Never miss a tweet from your favorite tweeters. https:\/\/t.co\/nWHtHcWUeR #tech #feedly #android",
  "id" : 779761541377843200,
  "created_at" : "2016-09-24 19:16:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "feedly",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/S4ABGR1jDH",
      "expanded_url" : "http:\/\/scripting.com\/2016\/09\/23\/otherBlogsLikeScriptingNews.html",
      "display_url" : "scripting.com\/2016\/09\/23\/oth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779760617678921729",
  "text" : "Other blogs like Scripting News? https:\/\/t.co\/S4ABGR1jDH #tech #feedly",
  "id" : 779760617678921729,
  "created_at" : "2016-09-24 19:13:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The QI Elves",
      "screen_name" : "qikipedia",
      "indices" : [ 3, 13 ],
      "id_str" : "22151193",
      "id" : 22151193
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/qikipedia\/status\/779591338589237249\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/y8Jzqo5IxK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtGlIMNUMAE8bXq.jpg",
      "id_str" : "779585770646417409",
      "id" : 779585770646417409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtGlIMNUMAE8bXq.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 647
      } ],
      "display_url" : "pic.twitter.com\/y8Jzqo5IxK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779729725409427456",
  "text" : "RT @qikipedia: The ancient Egyptians had a hieroglyphic that meant \"meteorite\". https:\/\/t.co\/y8Jzqo5IxK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/qikipedia\/status\/779591338589237249\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/y8Jzqo5IxK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtGlIMNUMAE8bXq.jpg",
        "id_str" : "779585770646417409",
        "id" : 779585770646417409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtGlIMNUMAE8bXq.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 647
        } ],
        "display_url" : "pic.twitter.com\/y8Jzqo5IxK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779591338589237249",
    "text" : "The ancient Egyptians had a hieroglyphic that meant \"meteorite\". https:\/\/t.co\/y8Jzqo5IxK",
    "id" : 779591338589237249,
    "created_at" : "2016-09-24 08:00:33 +0000",
    "user" : {
      "name" : "The QI Elves",
      "screen_name" : "qikipedia",
      "protected" : false,
      "id_str" : "22151193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549435855962513408\/RAEeXuVF_normal.png",
      "id" : 22151193,
      "verified" : true
    }
  },
  "id" : 779729725409427456,
  "created_at" : "2016-09-24 17:10:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/2KMoO9P8QE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMx7WAAAoKfi.jpg",
      "id_str" : "779699099188723712",
      "id" : 779699099188723712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMx7WAAAoKfi.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/2KMoO9P8QE"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/2KMoO9P8QE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMx7WIAEnH3J.jpg",
      "id_str" : "779699099188731905",
      "id" : 779699099188731905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMx7WIAEnH3J.jpg",
      "sizes" : [ {
        "h" : 1553,
        "resize" : "fit",
        "w" : 1553
      }, {
        "h" : 1553,
        "resize" : "fit",
        "w" : 1553
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/2KMoO9P8QE"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/2KMoO9P8QE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMx6WgAQmCbY.jpg",
      "id_str" : "779699099184562180",
      "id" : 779699099184562180,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMx6WgAQmCbY.jpg",
      "sizes" : [ {
        "h" : 1756,
        "resize" : "fit",
        "w" : 1756
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1756,
        "resize" : "fit",
        "w" : 1756
      } ],
      "display_url" : "pic.twitter.com\/2KMoO9P8QE"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/2KMoO9P8QE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMyCWgAALP3r.jpg",
      "id_str" : "779699099218116608",
      "id" : 779699099218116608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMyCWgAALP3r.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1674,
        "resize" : "fit",
        "w" : 1674
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1674,
        "resize" : "fit",
        "w" : 1674
      } ],
      "display_url" : "pic.twitter.com\/2KMoO9P8QE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779728255863681024",
  "text" : "RT @ErinEFarley: Different flutterbys, froggie still here, and a lizard! https:\/\/t.co\/2KMoO9P8QE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/2KMoO9P8QE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMx7WAAAoKfi.jpg",
        "id_str" : "779699099188723712",
        "id" : 779699099188723712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMx7WAAAoKfi.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/2KMoO9P8QE"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/2KMoO9P8QE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMx7WIAEnH3J.jpg",
        "id_str" : "779699099188731905",
        "id" : 779699099188731905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMx7WIAEnH3J.jpg",
        "sizes" : [ {
          "h" : 1553,
          "resize" : "fit",
          "w" : 1553
        }, {
          "h" : 1553,
          "resize" : "fit",
          "w" : 1553
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/2KMoO9P8QE"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/2KMoO9P8QE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMx6WgAQmCbY.jpg",
        "id_str" : "779699099184562180",
        "id" : 779699099184562180,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMx6WgAQmCbY.jpg",
        "sizes" : [ {
          "h" : 1756,
          "resize" : "fit",
          "w" : 1756
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1756,
          "resize" : "fit",
          "w" : 1756
        } ],
        "display_url" : "pic.twitter.com\/2KMoO9P8QE"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/779699109246726144\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/2KMoO9P8QE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIMMyCWgAALP3r.jpg",
        "id_str" : "779699099218116608",
        "id" : 779699099218116608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIMMyCWgAALP3r.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1674,
          "resize" : "fit",
          "w" : 1674
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1674,
          "resize" : "fit",
          "w" : 1674
        } ],
        "display_url" : "pic.twitter.com\/2KMoO9P8QE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779699109246726144",
    "text" : "Different flutterbys, froggie still here, and a lizard! https:\/\/t.co\/2KMoO9P8QE",
    "id" : 779699109246726144,
    "created_at" : "2016-09-24 15:08:48 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 779728255863681024,
  "created_at" : "2016-09-24 17:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Promised Land Farm",
      "screen_name" : "Promised_land_",
      "indices" : [ 3, 18 ],
      "id_str" : "2305258952",
      "id" : 2305258952
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Promised_land_\/status\/779712830127874049\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/vVV4a0q7v4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYlJWWYAAcDDz.jpg",
      "id_str" : "779712711932403712",
      "id" : 779712711932403712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYlJWWYAAcDDz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 827
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1411
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1411
      } ],
      "display_url" : "pic.twitter.com\/vVV4a0q7v4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Promised_land_\/status\/779712830127874049\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/vVV4a0q7v4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYocJWEAEgDOL.jpg",
      "id_str" : "779712768517738497",
      "id" : 779712768517738497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYocJWEAEgDOL.jpg",
      "sizes" : [ {
        "h" : 1325,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1325,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/vVV4a0q7v4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Promised_land_\/status\/779712830127874049\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/vVV4a0q7v4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYq1VWYAAbMw4.jpg",
      "id_str" : "779712809638715392",
      "id" : 779712809638715392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYq1VWYAAbMw4.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/vVV4a0q7v4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779727975809945601",
  "text" : "RT @Promised_land_: Found this funky guy today. Pale tussock moth?? Anybody good at caterpillars? https:\/\/t.co\/vVV4a0q7v4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Promised_land_\/status\/779712830127874049\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/vVV4a0q7v4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYlJWWYAAcDDz.jpg",
        "id_str" : "779712711932403712",
        "id" : 779712711932403712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYlJWWYAAcDDz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 827
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1411
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1411
        } ],
        "display_url" : "pic.twitter.com\/vVV4a0q7v4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Promised_land_\/status\/779712830127874049\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/vVV4a0q7v4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYocJWEAEgDOL.jpg",
        "id_str" : "779712768517738497",
        "id" : 779712768517738497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYocJWEAEgDOL.jpg",
        "sizes" : [ {
          "h" : 1325,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1325,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/vVV4a0q7v4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Promised_land_\/status\/779712830127874049\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/vVV4a0q7v4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYq1VWYAAbMw4.jpg",
        "id_str" : "779712809638715392",
        "id" : 779712809638715392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYq1VWYAAbMw4.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/vVV4a0q7v4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779712830127874049",
    "text" : "Found this funky guy today. Pale tussock moth?? Anybody good at caterpillars? https:\/\/t.co\/vVV4a0q7v4",
    "id" : 779712830127874049,
    "created_at" : "2016-09-24 16:03:19 +0000",
    "user" : {
      "name" : "Promised Land Farm",
      "screen_name" : "Promised_land_",
      "protected" : false,
      "id_str" : "2305258952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426072019600306177\/3iEPF1Vu_normal.jpeg",
      "id" : 2305258952,
      "verified" : false
    }
  },
  "id" : 779727975809945601,
  "created_at" : "2016-09-24 17:03:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778722293929304064",
  "geo" : { },
  "id_str" : "779727723526782976",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides did you get this sorted out?",
  "id" : 779727723526782976,
  "in_reply_to_status_id" : 778722293929304064,
  "created_at" : "2016-09-24 17:02:30 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779351919118655488",
  "geo" : { },
  "id_str" : "779727314401783809",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides daughter is frustrated w feeling ill and getting depressed. Docs think it psychological. gah.",
  "id" : 779727314401783809,
  "in_reply_to_status_id" : 779351919118655488,
  "created_at" : "2016-09-24 17:00:53 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/aIER2zbt2j",
      "expanded_url" : "http:\/\/eepurl.com\/cgPP1P",
      "display_url" : "eepurl.com\/cgPP1P"
    } ]
  },
  "geo" : { },
  "id_str" : "779356296441192448",
  "text" : "\uD83D\uDE4C\u00A0Litsy for Android is here!\u00A0\uD83D\uDE4C: https:\/\/t.co\/aIER2zbt2j",
  "id" : 779356296441192448,
  "created_at" : "2016-09-23 16:26:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Parkhomenko",
      "screen_name" : "AdamParkhomenko",
      "indices" : [ 3, 19 ],
      "id_str" : "18382184",
      "id" : 18382184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340641759293440",
  "text" : "RT @AdamParkhomenko: Is this the president we want for our daughters? Ask yourself that and then RT this and share it far and wide. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HillaryClinton\/status\/779288660067823616\/video\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/86FzaeISxu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtCSNOoWYAAG96x.jpg",
        "id_str" : "779283252062351360",
        "id" : 779283252062351360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtCSNOoWYAAG96x.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/86FzaeISxu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779315954413146112",
    "text" : "Is this the president we want for our daughters? Ask yourself that and then RT this and share it far and wide. https:\/\/t.co\/86FzaeISxu",
    "id" : 779315954413146112,
    "created_at" : "2016-09-23 13:46:17 +0000",
    "user" : {
      "name" : "Adam Parkhomenko",
      "screen_name" : "AdamParkhomenko",
      "protected" : false,
      "id_str" : "18382184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801133710749921281\/GRtfGBxq_normal.jpg",
      "id" : 18382184,
      "verified" : true
    }
  },
  "id" : 779340641759293440,
  "created_at" : "2016-09-23 15:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    }, {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 117, 125 ],
      "id_str" : "15012486",
      "id" : 15012486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "individualizedmedicine",
      "indices" : [ 65, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/vGuEFMwHyx",
      "expanded_url" : "http:\/\/bit.ly\/2crbUlq",
      "display_url" : "bit.ly\/2crbUlq"
    } ]
  },
  "geo" : { },
  "id_str" : "779339829154832386",
  "text" : "RT @MayoClinic: \"Sixth sense\" study highlights the importance of #individualizedmedicine https:\/\/t.co\/vGuEFMwHyx via @CBSNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBS News",
        "screen_name" : "CBSNews",
        "indices" : [ 101, 109 ],
        "id_str" : "15012486",
        "id" : 15012486
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "individualizedmedicine",
        "indices" : [ 49, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/vGuEFMwHyx",
        "expanded_url" : "http:\/\/bit.ly\/2crbUlq",
        "display_url" : "bit.ly\/2crbUlq"
      } ]
    },
    "geo" : { },
    "id_str" : "779279896786984960",
    "text" : "\"Sixth sense\" study highlights the importance of #individualizedmedicine https:\/\/t.co\/vGuEFMwHyx via @CBSNews",
    "id" : 779279896786984960,
    "created_at" : "2016-09-23 11:23:00 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 779339829154832386,
  "created_at" : "2016-09-23 15:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "feedly",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/9pD2vCqIlR",
      "expanded_url" : "http:\/\/birdnote.org\/show\/ravens-and-crows-who-who",
      "display_url" : "birdnote.org\/show\/ravens-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779322696819732480",
  "text" : "Ravens and Crows - Who Is Who https:\/\/t.co\/9pD2vCqIlR #podcasts #feedly",
  "id" : 779322696819732480,
  "created_at" : "2016-09-23 14:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/779321661334155264\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/dlmlePpELL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC0612WIAASpMJ.png",
      "id_str" : "779321658515529728",
      "id" : 779321658515529728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC0612WIAASpMJ.png",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      } ],
      "display_url" : "pic.twitter.com\/dlmlePpELL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/8qynuG8DnG",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/podcasts\/comments\/53v2hp\/the_big_list_of_true_crime_podcasts?_ts=1474639737",
      "display_url" : "reddit.com\/r\/podcasts\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779321661334155264",
  "text" : "The Big List of True Crime Podcasts : https:\/\/t.co\/8qynuG8DnG https:\/\/t.co\/dlmlePpELL",
  "id" : 779321661334155264,
  "created_at" : "2016-09-23 14:08:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolina Bama",
      "screen_name" : "Awkward_Duck",
      "indices" : [ 3, 16 ],
      "id_str" : "278901890",
      "id" : 278901890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/s5Xr1DJIFf",
      "expanded_url" : "https:\/\/twitter.com\/awkward_duck\/status\/779125144295923712",
      "display_url" : "twitter.com\/awkward_duck\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779131845967486976",
  "text" : "RT @Awkward_Duck: Help me signal boost this folks!!!  https:\/\/t.co\/s5Xr1DJIFf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/s5Xr1DJIFf",
        "expanded_url" : "https:\/\/twitter.com\/awkward_duck\/status\/779125144295923712",
        "display_url" : "twitter.com\/awkward_duck\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779125644672143360",
    "text" : "Help me signal boost this folks!!!  https:\/\/t.co\/s5Xr1DJIFf",
    "id" : 779125644672143360,
    "created_at" : "2016-09-23 01:10:03 +0000",
    "user" : {
      "name" : "Carolina Bama",
      "screen_name" : "Awkward_Duck",
      "protected" : false,
      "id_str" : "278901890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783383760838406150\/0V7unT9V_normal.jpg",
      "id" : 278901890,
      "verified" : false
    }
  },
  "id" : 779131845967486976,
  "created_at" : "2016-09-23 01:34:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779129172694274049",
  "text" : "RT @derekrootboy: This program taught me even fish create art. And that birds have soulmates Life Story, 5. Courtship: https:\/\/t.co\/5qot5Xt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC iPlayer",
        "screen_name" : "BBCiPlayer",
        "indices" : [ 129, 140 ],
        "id_str" : "17793580",
        "id" : 17793580
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/5qot5XtTl7",
        "expanded_url" : "http:\/\/bbc.in\/1qBXIb9",
        "display_url" : "bbc.in\/1qBXIb9"
      } ]
    },
    "geo" : { },
    "id_str" : "779128105797640192",
    "text" : "This program taught me even fish create art. And that birds have soulmates Life Story, 5. Courtship: https:\/\/t.co\/5qot5XtTl7 via @bbciplayer",
    "id" : 779128105797640192,
    "created_at" : "2016-09-23 01:19:50 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 779129172694274049,
  "created_at" : "2016-09-23 01:24:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779115934803955712",
  "text" : "RT @ABC: Police in Charlotte say the man shot in the head during last night's protests near a downtown hotel has died. https:\/\/t.co\/44mSQcU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/779111390334316544\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/Afo7uyQsiJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs_1rjzXgAAiZmu.jpg",
        "id_str" : "779111389252255744",
        "id" : 779111389252255744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs_1rjzXgAAiZmu.jpg",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 916
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 916
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 916
        } ],
        "display_url" : "pic.twitter.com\/Afo7uyQsiJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/44mSQcU6QP",
        "expanded_url" : "http:\/\/abcn.ws\/2ddDHCV",
        "display_url" : "abcn.ws\/2ddDHCV"
      } ]
    },
    "geo" : { },
    "id_str" : "779111390334316544",
    "text" : "Police in Charlotte say the man shot in the head during last night's protests near a downtown hotel has died. https:\/\/t.co\/44mSQcU6QP https:\/\/t.co\/Afo7uyQsiJ",
    "id" : 779111390334316544,
    "created_at" : "2016-09-23 00:13:25 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658688193651277824\/Kv_cNNub_normal.png",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 779115934803955712,
  "created_at" : "2016-09-23 00:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Farmer",
      "screen_name" : "ModFarm",
      "indices" : [ 3, 11 ],
      "id_str" : "944467345",
      "id" : 944467345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/794psYcUn8",
      "expanded_url" : "https:\/\/twitter.com\/whitneyarner\/status\/779065747490369536",
      "display_url" : "twitter.com\/whitneyarner\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779089869238898688",
  "text" : "RT @ModFarm: \uD83D\uDE01\uD83D\uDC4D(we need a bison emoji) https:\/\/t.co\/794psYcUn8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/794psYcUn8",
        "expanded_url" : "https:\/\/twitter.com\/whitneyarner\/status\/779065747490369536",
        "display_url" : "twitter.com\/whitneyarner\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779066574665687040",
    "text" : "\uD83D\uDE01\uD83D\uDC4D(we need a bison emoji) https:\/\/t.co\/794psYcUn8",
    "id" : 779066574665687040,
    "created_at" : "2016-09-22 21:15:20 +0000",
    "user" : {
      "name" : "Modern Farmer",
      "screen_name" : "ModFarm",
      "protected" : false,
      "id_str" : "944467345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556999293949575168\/hRwKSplY_normal.jpeg",
      "id" : 944467345,
      "verified" : true
    }
  },
  "id" : 779089869238898688,
  "created_at" : "2016-09-22 22:47:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Ihnatko",
      "screen_name" : "Ihnatko",
      "indices" : [ 3, 11 ],
      "id_str" : "1835411",
      "id" : 1835411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779089653915906049",
  "text" : "RT @Ihnatko: (The fact that she sounded like Mrs. Slocombe of \u201CAre You Being Served?\u201D talking about her cat didn\u2019t help me regain my compos\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779064976136925184",
    "text" : "(The fact that she sounded like Mrs. Slocombe of \u201CAre You Being Served?\u201D talking about her cat didn\u2019t help me regain my composure.)",
    "id" : 779064976136925184,
    "created_at" : "2016-09-22 21:08:59 +0000",
    "user" : {
      "name" : "Andy Ihnatko",
      "screen_name" : "Ihnatko",
      "protected" : false,
      "id_str" : "1835411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1180961056\/Self-Portrait-2010-Porch-_Final_-_Cutout_-Avatar_normal.jpg",
      "id" : 1835411,
      "verified" : true
    }
  },
  "id" : 779089653915906049,
  "created_at" : "2016-09-22 22:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/rE2pfVSHPN",
      "expanded_url" : "https:\/\/twitter.com\/Ihnatko\/status\/779063187782131713",
      "display_url" : "twitter.com\/Ihnatko\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779089626992607236",
  "text" : "RT @Matth3ous: \uD83D\uDE02 https:\/\/t.co\/rE2pfVSHPN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 2, 25 ],
        "url" : "https:\/\/t.co\/rE2pfVSHPN",
        "expanded_url" : "https:\/\/twitter.com\/Ihnatko\/status\/779063187782131713",
        "display_url" : "twitter.com\/Ihnatko\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779063620525326336",
    "text" : "\uD83D\uDE02 https:\/\/t.co\/rE2pfVSHPN",
    "id" : 779063620525326336,
    "created_at" : "2016-09-22 21:03:36 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 779089626992607236,
  "created_at" : "2016-09-22 22:46:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "indices" : [ 3, 15 ],
      "id_str" : "519836839",
      "id" : 519836839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wallabies",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779089284942991360",
  "text" : "RT @decisiveman: Our gardener has returned to trim &amp; shape the various succulents &amp; grasses. #Wallabies have a calming effect on all specie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/decisiveman\/status\/779039734907609088\/photo\/1",
        "indices" : [ 149, 172 ],
        "url" : "https:\/\/t.co\/UXQk1OIwxL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-0e9TUIAAOEtR.jpg",
        "id_str" : "779039704503033856",
        "id" : 779039704503033856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-0e9TUIAAOEtR.jpg",
        "sizes" : [ {
          "h" : 589,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1651,
          "resize" : "fit",
          "w" : 1905
        }, {
          "h" : 1651,
          "resize" : "fit",
          "w" : 1905
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1040,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/UXQk1OIwxL"
      } ],
      "hashtags" : [ {
        "text" : "Wallabies",
        "indices" : [ 84, 94 ]
      }, {
        "text" : "bluedogs",
        "indices" : [ 139, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779039734907609088",
    "text" : "Our gardener has returned to trim &amp; shape the various succulents &amp; grasses. #Wallabies have a calming effect on all species except #bluedogs https:\/\/t.co\/UXQk1OIwxL",
    "id" : 779039734907609088,
    "created_at" : "2016-09-22 19:28:41 +0000",
    "user" : {
      "name" : "Glenlee Farm",
      "screen_name" : "decisiveman",
      "protected" : false,
      "id_str" : "519836839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706805650844585984\/Wyw3swZ9_normal.jpg",
      "id" : 519836839,
      "verified" : false
    }
  },
  "id" : 779089284942991360,
  "created_at" : "2016-09-22 22:45:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/778962976967499776\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/tqsxLlk9Z8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9ur14UIAEtthc.jpg",
      "id_str" : "778962960035094529",
      "id" : 778962960035094529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9ur14UIAEtthc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1715,
        "resize" : "fit",
        "w" : 1725
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1193,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1715,
        "resize" : "fit",
        "w" : 1725
      } ],
      "display_url" : "pic.twitter.com\/tqsxLlk9Z8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/778962976967499776\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/tqsxLlk9Z8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9ur5OVUAIVgAK.jpg",
      "id_str" : "778962960932753410",
      "id" : 778962960932753410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9ur5OVUAIVgAK.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/tqsxLlk9Z8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779066149631881216",
  "text" : "RT @ErinEFarley: Butterflies and frog. Must be doing something right. https:\/\/t.co\/tqsxLlk9Z8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/778962976967499776\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/tqsxLlk9Z8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9ur14UIAEtthc.jpg",
        "id_str" : "778962960035094529",
        "id" : 778962960035094529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9ur14UIAEtthc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1715,
          "resize" : "fit",
          "w" : 1725
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1193,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1715,
          "resize" : "fit",
          "w" : 1725
        } ],
        "display_url" : "pic.twitter.com\/tqsxLlk9Z8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/778962976967499776\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/tqsxLlk9Z8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9ur5OVUAIVgAK.jpg",
        "id_str" : "778962960932753410",
        "id" : 778962960932753410,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9ur5OVUAIVgAK.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/tqsxLlk9Z8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778962976967499776",
    "text" : "Butterflies and frog. Must be doing something right. https:\/\/t.co\/tqsxLlk9Z8",
    "id" : 778962976967499776,
    "created_at" : "2016-09-22 14:23:40 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 779066149631881216,
  "created_at" : "2016-09-22 21:13:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/MzLSjC8r1b",
      "expanded_url" : "https:\/\/twitter.com\/nbcnews\/status\/778968585121046529",
      "display_url" : "twitter.com\/nbcnews\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779065957901885441",
  "text" : "RT @deray: They were \"certain\" last night that officers weren't involved. &amp; look at how the story has now shifted. https:\/\/t.co\/MzLSjC8r1b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/MzLSjC8r1b",
        "expanded_url" : "https:\/\/twitter.com\/nbcnews\/status\/778968585121046529",
        "display_url" : "twitter.com\/nbcnews\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778974073418231808",
    "text" : "They were \"certain\" last night that officers weren't involved. &amp; look at how the story has now shifted. https:\/\/t.co\/MzLSjC8r1b",
    "id" : 778974073418231808,
    "created_at" : "2016-09-22 15:07:46 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 779065957901885441,
  "created_at" : "2016-09-22 21:12:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.",
      "screen_name" : "thejadabradshaw",
      "indices" : [ 3, 19 ],
      "id_str" : "21121725",
      "id" : 21121725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/WjFC1wCCp9",
      "expanded_url" : "https:\/\/twitter.com\/abc\/status\/778712072511066114",
      "display_url" : "twitter.com\/abc\/status\/778\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779065808366530560",
  "text" : "RT @thejadabradshaw: Here we go. Here the fuck we go. https:\/\/t.co\/WjFC1wCCp9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/WjFC1wCCp9",
        "expanded_url" : "https:\/\/twitter.com\/abc\/status\/778712072511066114",
        "display_url" : "twitter.com\/abc\/status\/778\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778816981365428225",
    "text" : "Here we go. Here the fuck we go. https:\/\/t.co\/WjFC1wCCp9",
    "id" : 778816981365428225,
    "created_at" : "2016-09-22 04:43:32 +0000",
    "user" : {
      "name" : "J.",
      "screen_name" : "thejadabradshaw",
      "protected" : false,
      "id_str" : "21121725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786320703670792192\/x9_SG3y-_normal.jpg",
      "id" : 21121725,
      "verified" : false
    }
  },
  "id" : 779065808366530560,
  "created_at" : "2016-09-22 21:12:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778983297871384576",
  "text" : "this dredges up old self worth issues, brings up uncomfortable feelings.",
  "id" : 778983297871384576,
  "created_at" : "2016-09-22 15:44:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778982851983343616",
  "text" : "DH found old letter from K teacher about DD.. as a mom I didnt do enough to get her the resources she needed for school years.",
  "id" : 778982851983343616,
  "created_at" : "2016-09-22 15:42:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778722293929304064",
  "geo" : { },
  "id_str" : "778970381063483392",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides i cant believe with all the internet, theres no answer. gah.",
  "id" : 778970381063483392,
  "in_reply_to_status_id" : 778722293929304064,
  "created_at" : "2016-09-22 14:53:06 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheila English",
      "screen_name" : "english_sheila",
      "indices" : [ 3, 18 ],
      "id_str" : "1370207605",
      "id" : 1370207605
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/english_sheila\/status\/778736669541269505\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1DnqxF76ws",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6g1qNUIAA4EBY.jpg",
      "id_str" : "778736629305319424",
      "id" : 778736629305319424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6g1qNUIAA4EBY.jpg",
      "sizes" : [ {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1530,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1530,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1DnqxF76ws"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778967006641025025",
  "text" : "RT @english_sheila: Look at these stamps on some mail I received today. There's a cat in a cone! https:\/\/t.co\/1DnqxF76ws",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/english_sheila\/status\/778736669541269505\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/1DnqxF76ws",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6g1qNUIAA4EBY.jpg",
        "id_str" : "778736629305319424",
        "id" : 778736629305319424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6g1qNUIAA4EBY.jpg",
        "sizes" : [ {
          "h" : 896,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1530,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1530,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1DnqxF76ws"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778736669541269505",
    "text" : "Look at these stamps on some mail I received today. There's a cat in a cone! https:\/\/t.co\/1DnqxF76ws",
    "id" : 778736669541269505,
    "created_at" : "2016-09-21 23:24:24 +0000",
    "user" : {
      "name" : "Sheila English",
      "screen_name" : "english_sheila",
      "protected" : false,
      "id_str" : "1370207605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624836099685355520\/wMf8zkzz_normal.jpg",
      "id" : 1370207605,
      "verified" : false
    }
  },
  "id" : 778967006641025025,
  "created_at" : "2016-09-22 14:39:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/778752467148374016\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/093CfjJs3f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6udyqUMAAaHH7.jpg",
      "id_str" : "778751612420370432",
      "id" : 778751612420370432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6udyqUMAAaHH7.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/093CfjJs3f"
    } ],
    "hashtags" : [ {
      "text" : "sunset",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "weather",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "ncwx",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778753121178836992",
  "text" : "RT @dwaynereaves: Just didn't seem real to me, but it was. 09\/21\/2016 #sunset #weather #ncwx https:\/\/t.co\/093CfjJs3f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/778752467148374016\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/093CfjJs3f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6udyqUMAAaHH7.jpg",
        "id_str" : "778751612420370432",
        "id" : 778751612420370432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6udyqUMAAaHH7.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/093CfjJs3f"
      } ],
      "hashtags" : [ {
        "text" : "sunset",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "weather",
        "indices" : [ 60, 68 ]
      }, {
        "text" : "ncwx",
        "indices" : [ 69, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778752467148374016",
    "text" : "Just didn't seem real to me, but it was. 09\/21\/2016 #sunset #weather #ncwx https:\/\/t.co\/093CfjJs3f",
    "id" : 778752467148374016,
    "created_at" : "2016-09-22 00:27:11 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 778753121178836992,
  "created_at" : "2016-09-22 00:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/778717408705990656\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/rO1D05TuT5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6PWm6UMAElplN.jpg",
      "id_str" : "778717404146708481",
      "id" : 778717404146708481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6PWm6UMAElplN.jpg",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/rO1D05TuT5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/CvbQ2nyiS3",
      "expanded_url" : "http:\/\/apple.stackexchange.com\/questions\/32505\/is-there-a-fast-way-to-export-podcast-urls-from-itunes?_ts=1474495668",
      "display_url" : "apple.stackexchange.com\/questions\/3250\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778717408705990656",
  "in_reply_to_user_id" : 257273626,
  "text" : "@charmantides any option for export playlist? &gt; export podcast URLs from iTunes? https:\/\/t.co\/CvbQ2nyiS3 https:\/\/t.co\/rO1D05TuT5",
  "id" : 778717408705990656,
  "created_at" : "2016-09-21 22:07:52 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 0, 5 ]
    }, {
      "text" : "itunes",
      "indices" : [ 6, 13 ]
    }, {
      "text" : "itunes12",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "OPML",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/Ao2CHDr6ZI",
      "expanded_url" : "https:\/\/twitter.com\/Charmantides\/status\/778681721478709248",
      "display_url" : "twitter.com\/Charmantides\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778713909276520453",
  "text" : "#tech #itunes #itunes12 #OPML https:\/\/t.co\/Ao2CHDr6ZI",
  "id" : 778713909276520453,
  "created_at" : "2016-09-21 21:53:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/fZ9Bi8t8wx",
      "expanded_url" : "https:\/\/discussions.apple.com\/thread\/6878653?start=0&tstart=0",
      "display_url" : "discussions.apple.com\/thread\/6878653\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "778681721478709248",
  "geo" : { },
  "id_str" : "778704290068115456",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides https:\/\/t.co\/fZ9Bi8t8wx &lt;- does that help? (use \"save as\" txt then change to opml)",
  "id" : 778704290068115456,
  "in_reply_to_status_id" : 778681721478709248,
  "created_at" : "2016-09-21 21:15:45 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "indices" : [ 50, 62 ],
      "id_str" : "2233154425",
      "id" : 2233154425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "112263onhulu",
      "indices" : [ 65, 78 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "StephenKingDay",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/NSaeye8EVL",
      "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
      "display_url" : "bit.ly\/1X8y8YB"
    } ]
  },
  "geo" : { },
  "id_str" : "778649211940311040",
  "text" : "RT @SimonAudio: Follow &amp; RT to #win a copy of @StephenKing's #112263onhulu! #Sweeps rules https:\/\/t.co\/NSaeye8EVL #StephenKingDay https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen King",
        "screen_name" : "StephenKing",
        "indices" : [ 34, 46 ],
        "id_str" : "2233154425",
        "id" : 2233154425
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SimonAudio\/status\/778647834358910976\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/1ZmPcDLbxp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5QE9IW8AAKVKx.jpg",
        "id_str" : "778647831640993792",
        "id" : 778647831640993792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5QE9IW8AAKVKx.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/1ZmPcDLbxp"
      } ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "112263onhulu",
        "indices" : [ 49, 62 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 64, 71 ]
      }, {
        "text" : "StephenKingDay",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/NSaeye8EVL",
        "expanded_url" : "https:\/\/bit.ly\/1X8y8YB",
        "display_url" : "bit.ly\/1X8y8YB"
      } ]
    },
    "geo" : { },
    "id_str" : "778647834358910976",
    "text" : "Follow &amp; RT to #win a copy of @StephenKing's #112263onhulu! #Sweeps rules https:\/\/t.co\/NSaeye8EVL #StephenKingDay https:\/\/t.co\/1ZmPcDLbxp",
    "id" : 778647834358910976,
    "created_at" : "2016-09-21 17:31:24 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 778649211940311040,
  "created_at" : "2016-09-21 17:36:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Plotz",
      "screen_name" : "davidplotz",
      "indices" : [ 3, 14 ],
      "id_str" : "36171004",
      "id" : 36171004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/A4EDswphib",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/objects-of-intrigue-rocket-cats",
      "display_url" : "atlasobscura.com\/articles\/objec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778606418832351233",
  "text" : "RT @davidplotz: I never, ever get tired of this: The 16th-century manuscript showing cats with jetpacks. https:\/\/t.co\/A4EDswphib https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/davidplotz\/status\/778594632116690944\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/FNCjcPLdin",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs4fkQhXYAAs7qS.jpg",
        "id_str" : "778594493352337408",
        "id" : 778594493352337408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs4fkQhXYAAs7qS.jpg",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 727
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 727
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 727
        } ],
        "display_url" : "pic.twitter.com\/FNCjcPLdin"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/A4EDswphib",
        "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/objects-of-intrigue-rocket-cats",
        "display_url" : "atlasobscura.com\/articles\/objec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778594632116690944",
    "text" : "I never, ever get tired of this: The 16th-century manuscript showing cats with jetpacks. https:\/\/t.co\/A4EDswphib https:\/\/t.co\/FNCjcPLdin",
    "id" : 778594632116690944,
    "created_at" : "2016-09-21 14:00:00 +0000",
    "user" : {
      "name" : "David Plotz",
      "screen_name" : "davidplotz",
      "protected" : false,
      "id_str" : "36171004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796485865363140608\/zPhMByZo_normal.jpg",
      "id" : 36171004,
      "verified" : true
    }
  },
  "id" : 778606418832351233,
  "created_at" : "2016-09-21 14:46:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie",
      "screen_name" : "connietn06",
      "indices" : [ 3, 14 ],
      "id_str" : "763103294856294400",
      "id" : 763103294856294400
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/connietn06\/status\/778222650862735360\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/OIfQRKPgvK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CszNUKdWYAAOt9B.jpg",
      "id_str" : "778222581916786688",
      "id" : 778222581916786688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CszNUKdWYAAOt9B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2506,
        "resize" : "fit",
        "w" : 2510
      }, {
        "h" : 2045,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1198,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/OIfQRKPgvK"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778605359103639553",
  "text" : "RT @connietn06: Quite the surprise! A wild turkey in the yard! #birds #birdwatching https:\/\/t.co\/OIfQRKPgvK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/connietn06\/status\/778222650862735360\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/OIfQRKPgvK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CszNUKdWYAAOt9B.jpg",
        "id_str" : "778222581916786688",
        "id" : 778222581916786688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CszNUKdWYAAOt9B.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2506,
          "resize" : "fit",
          "w" : 2510
        }, {
          "h" : 2045,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1198,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/OIfQRKPgvK"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 47, 53 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 54, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778222650862735360",
    "text" : "Quite the surprise! A wild turkey in the yard! #birds #birdwatching https:\/\/t.co\/OIfQRKPgvK",
    "id" : 778222650862735360,
    "created_at" : "2016-09-20 13:21:53 +0000",
    "user" : {
      "name" : "Connie",
      "screen_name" : "connietn06",
      "protected" : false,
      "id_str" : "763103294856294400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769190699396919296\/UEUkP-Ax_normal.jpg",
      "id" : 763103294856294400,
      "verified" : false
    }
  },
  "id" : 778605359103639553,
  "created_at" : "2016-09-21 14:42:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandi Miller",
      "screen_name" : "BrandiNico",
      "indices" : [ 3, 14 ],
      "id_str" : "273820928",
      "id" : 273820928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778605108162654209",
  "text" : "RT @BrandiNico: The reality that people are obsessed with \"the facts\" but hail a legal system that acquits police on the basis of them FEEL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778396775157673985",
    "text" : "The reality that people are obsessed with \"the facts\" but hail a legal system that acquits police on the basis of them FEELING threatened\uD83E\uDD14",
    "id" : 778396775157673985,
    "created_at" : "2016-09-21 00:53:47 +0000",
    "user" : {
      "name" : "Brandi Miller",
      "screen_name" : "BrandiNico",
      "protected" : false,
      "id_str" : "273820928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765358829248753667\/vzZk_u2X_normal.jpg",
      "id" : 273820928,
      "verified" : false
    }
  },
  "id" : 778605108162654209,
  "created_at" : "2016-09-21 14:41:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Santens",
      "screen_name" : "scottsantens",
      "indices" : [ 3, 16 ],
      "id_str" : "14297863",
      "id" : 14297863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/MFzTawAgAU",
      "expanded_url" : "http:\/\/www.commondreams.org\/news\/2016\/08\/31\/debtors-prison-kids-poor-children-incarcerated-when-families-cant-pay-juvenile-court",
      "display_url" : "commondreams.org\/news\/2016\/08\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778605090072567808",
  "text" : "RT @scottsantens: We've built a debtor's prison system, and if that's not bad enough, it's even true for kids. https:\/\/t.co\/MFzTawAgAU #bas\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "basicincome",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/MFzTawAgAU",
        "expanded_url" : "http:\/\/www.commondreams.org\/news\/2016\/08\/31\/debtors-prison-kids-poor-children-incarcerated-when-families-cant-pay-juvenile-court",
        "display_url" : "commondreams.org\/news\/2016\/08\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778598032157704192",
    "text" : "We've built a debtor's prison system, and if that's not bad enough, it's even true for kids. https:\/\/t.co\/MFzTawAgAU #basicincome",
    "id" : 778598032157704192,
    "created_at" : "2016-09-21 14:13:31 +0000",
    "user" : {
      "name" : "Scott Santens",
      "screen_name" : "scottsantens",
      "protected" : false,
      "id_str" : "14297863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728327801028239360\/QVZeVLgz_normal.jpg",
      "id" : 14297863,
      "verified" : true
    }
  },
  "id" : 778605090072567808,
  "created_at" : "2016-09-21 14:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoeMyGod",
      "screen_name" : "JoeMyGod",
      "indices" : [ 3, 12 ],
      "id_str" : "16490790",
      "id" : 16490790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/hiMZjEr7oc",
      "expanded_url" : "http:\/\/PutinTrump.org",
      "display_url" : "PutinTrump.org"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Z3RykFBlIi",
      "expanded_url" : "http:\/\/www.joemygod.com\/2016\/09\/21\/putintrump-org-new-site-launches-expose-financial-ties-trump-putin-russian-oligarchs\/",
      "display_url" : "joemygod.com\/2016\/09\/21\/put\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778604417092378624",
  "text" : "RT @JoeMyGod: https:\/\/t.co\/hiMZjEr7oc: New Site Launches To Expose Financial Ties Between ... - https:\/\/t.co\/Z3RykFBlIi https:\/\/t.co\/47P4rb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.joemygod.com\" rel=\"nofollow\"\u003EJMG Auto Posting\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoeMyGod\/status\/778585336377028608\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/47P4rbz5xc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs4XPJCVIAAg160.jpg",
        "id_str" : "778585334472843264",
        "id" : 778585334472843264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs4XPJCVIAAg160.jpg",
        "sizes" : [ {
          "h" : 493,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/47P4rbz5xc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/hiMZjEr7oc",
        "expanded_url" : "http:\/\/PutinTrump.org",
        "display_url" : "PutinTrump.org"
      }, {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Z3RykFBlIi",
        "expanded_url" : "http:\/\/www.joemygod.com\/2016\/09\/21\/putintrump-org-new-site-launches-expose-financial-ties-trump-putin-russian-oligarchs\/",
        "display_url" : "joemygod.com\/2016\/09\/21\/put\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778585336377028608",
    "text" : "https:\/\/t.co\/hiMZjEr7oc: New Site Launches To Expose Financial Ties Between ... - https:\/\/t.co\/Z3RykFBlIi https:\/\/t.co\/47P4rbz5xc",
    "id" : 778585336377028608,
    "created_at" : "2016-09-21 13:23:04 +0000",
    "user" : {
      "name" : "JoeMyGod",
      "screen_name" : "JoeMyGod",
      "protected" : false,
      "id_str" : "16490790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792362976707739650\/q0pyaGnk_normal.jpg",
      "id" : 16490790,
      "verified" : true
    }
  },
  "id" : 778604417092378624,
  "created_at" : "2016-09-21 14:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDWG",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/gYhJNm1t0g",
      "expanded_url" : "http:\/\/camodave.co.uk",
      "display_url" : "camodave.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "778368248567963648",
  "text" : "RT @CamoDave_: LIVE cam NOW Collared Dove sat on nest incubating her 2 eggs in the #CDWG 20\/9\/16 https:\/\/t.co\/gYhJNm1t0g https:\/\/t.co\/Ne6Nb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/778335867979067395\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/Ne6NbzksoQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs00G_MWcAAVMdS.jpg",
        "id_str" : "778335605252059136",
        "id" : 778335605252059136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs00G_MWcAAVMdS.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 506
        } ],
        "display_url" : "pic.twitter.com\/Ne6NbzksoQ"
      } ],
      "hashtags" : [ {
        "text" : "CDWG",
        "indices" : [ 68, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/gYhJNm1t0g",
        "expanded_url" : "http:\/\/camodave.co.uk",
        "display_url" : "camodave.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "778335867979067395",
    "text" : "LIVE cam NOW Collared Dove sat on nest incubating her 2 eggs in the #CDWG 20\/9\/16 https:\/\/t.co\/gYhJNm1t0g https:\/\/t.co\/Ne6NbzksoQ",
    "id" : 778335867979067395,
    "created_at" : "2016-09-20 20:51:46 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 778368248567963648,
  "created_at" : "2016-09-20 23:00:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "indices" : [ 58, 70 ],
      "id_str" : "2233154425",
      "id" : 2233154425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StephenKingDay",
      "indices" : [ 28, 43 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778320815414738944",
  "text" : "RT @SimonAudio: Tomorrow is #StephenKingDay! To celebrate @StephenKing's birthday, we'll be posting #audiobook excerpts, interviews, &amp; audi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen King",
        "screen_name" : "StephenKing",
        "indices" : [ 42, 54 ],
        "id_str" : "2233154425",
        "id" : 2233154425
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StephenKingDay",
        "indices" : [ 12, 27 ]
      }, {
        "text" : "audiobook",
        "indices" : [ 84, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778315544579739648",
    "text" : "Tomorrow is #StephenKingDay! To celebrate @StephenKing's birthday, we'll be posting #audiobook excerpts, interviews, &amp; audio giveaways!",
    "id" : 778315544579739648,
    "created_at" : "2016-09-20 19:31:00 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 778320815414738944,
  "created_at" : "2016-09-20 19:51:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon",
      "screen_name" : "theevilwriter",
      "indices" : [ 3, 17 ],
      "id_str" : "367548578",
      "id" : 367548578
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/theevilwriter\/status\/777708401505792000\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/N44JwpbR5L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Csr5b_pXYAUXgs6.jpg",
      "id_str" : "777708145011548165",
      "id" : 777708145011548165,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csr5b_pXYAUXgs6.jpg",
      "sizes" : [ {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      } ],
      "display_url" : "pic.twitter.com\/N44JwpbR5L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778318303160897536",
  "text" : "RT @theevilwriter: \"Try counting sheep,\" they said. \n\"It'll help you fall asleep,\" they said. https:\/\/t.co\/N44JwpbR5L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/theevilwriter\/status\/777708401505792000\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/N44JwpbR5L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Csr5b_pXYAUXgs6.jpg",
        "id_str" : "777708145011548165",
        "id" : 777708145011548165,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csr5b_pXYAUXgs6.jpg",
        "sizes" : [ {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/N44JwpbR5L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777708401505792000",
    "text" : "\"Try counting sheep,\" they said. \n\"It'll help you fall asleep,\" they said. https:\/\/t.co\/N44JwpbR5L",
    "id" : 777708401505792000,
    "created_at" : "2016-09-19 03:18:26 +0000",
    "user" : {
      "name" : "Shannon",
      "screen_name" : "theevilwriter",
      "protected" : false,
      "id_str" : "367548578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715008545029234689\/jzi_6EHY_normal.jpg",
      "id" : 367548578,
      "verified" : false
    }
  },
  "id" : 778318303160897536,
  "created_at" : "2016-09-20 19:41:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revd Dr Geoff Morgan",
      "screen_name" : "chapdzef",
      "indices" : [ 3, 12 ],
      "id_str" : "1469265734",
      "id" : 1469265734
    }, {
      "name" : "OfficialSwanwatchUk",
      "screen_name" : "SwanwatchUk",
      "indices" : [ 88, 100 ],
      "id_str" : "756088705501237248",
      "id" : 756088705501237248
    }, {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 101, 115 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chapdzef\/status\/778316279195308032\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2Ug2Aq76oy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs0ih5qXgAALAZg.jpg",
      "id_str" : "778316276414513152",
      "id" : 778316276414513152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs0ih5qXgAALAZg.jpg",
      "sizes" : [ {
        "h" : 676,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1018,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1018,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1018,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2Ug2Aq76oy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778317988634263552",
  "text" : "RT @chapdzef: Our necks make a \u2764\uFE0F4 statistician &amp; carer, Ryan. U were magnifcygnet! @SwanwatchUk @Swanwhisperer https:\/\/t.co\/2Ug2Aq76oy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OfficialSwanwatchUk",
        "screen_name" : "SwanwatchUk",
        "indices" : [ 74, 86 ],
        "id_str" : "756088705501237248",
        "id" : 756088705501237248
      }, {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 87, 101 ],
        "id_str" : "272369448",
        "id" : 272369448
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chapdzef\/status\/778316279195308032\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/2Ug2Aq76oy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs0ih5qXgAALAZg.jpg",
        "id_str" : "778316276414513152",
        "id" : 778316276414513152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs0ih5qXgAALAZg.jpg",
        "sizes" : [ {
          "h" : 676,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1018,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1018,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1018,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2Ug2Aq76oy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778316279195308032",
    "text" : "Our necks make a \u2764\uFE0F4 statistician &amp; carer, Ryan. U were magnifcygnet! @SwanwatchUk @Swanwhisperer https:\/\/t.co\/2Ug2Aq76oy",
    "id" : 778316279195308032,
    "created_at" : "2016-09-20 19:33:56 +0000",
    "user" : {
      "name" : "Revd Dr Geoff Morgan",
      "screen_name" : "chapdzef",
      "protected" : false,
      "id_str" : "1469265734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3740479638\/cc0b0bc9caabd1c0e8f176e7b16fb3b7_normal.jpeg",
      "id" : 1469265734,
      "verified" : false
    }
  },
  "id" : 778317988634263552,
  "created_at" : "2016-09-20 19:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Crow",
      "screen_name" : "Russellcrowuk",
      "indices" : [ 3, 17 ],
      "id_str" : "777519596660264960",
      "id" : 777519596660264960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Crow",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "Corvid",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "Birds",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778269070646972418",
  "text" : "RT @Russellcrowuk: Just chilling on the door too rainy outside.  A good look out! #Crow #Corvid #Birds hope you having a lovely day! https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Russellcrowuk\/status\/777809002105372672\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/9glIi0nyx0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CstVKfKWgAA0Wzi.jpg",
        "id_str" : "777808999303512064",
        "id" : 777808999303512064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CstVKfKWgAA0Wzi.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 374
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 528
        } ],
        "display_url" : "pic.twitter.com\/9glIi0nyx0"
      } ],
      "hashtags" : [ {
        "text" : "Crow",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "Corvid",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "Birds",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777809002105372672",
    "text" : "Just chilling on the door too rainy outside.  A good look out! #Crow #Corvid #Birds hope you having a lovely day! https:\/\/t.co\/9glIi0nyx0",
    "id" : 777809002105372672,
    "created_at" : "2016-09-19 09:58:11 +0000",
    "user" : {
      "name" : "Russell Crow",
      "screen_name" : "Russellcrowuk",
      "protected" : false,
      "id_str" : "777519596660264960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777522029834694656\/gvs2166C_normal.jpg",
      "id" : 777519596660264960,
      "verified" : false
    }
  },
  "id" : 778269070646972418,
  "created_at" : "2016-09-20 16:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778239918468235265",
  "geo" : { },
  "id_str" : "778252130478153728",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oh dear. feel better soon.",
  "id" : 778252130478153728,
  "in_reply_to_status_id" : 778239918468235265,
  "created_at" : "2016-09-20 15:19:01 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ilivewithseriouspokemonfan",
      "indices" : [ 70, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/bQpXNbZYjt",
      "expanded_url" : "https:\/\/twitter.com\/JourneyTheHedgi\/status\/778228838685896704",
      "display_url" : "twitter.com\/JourneyTheHedg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778235661962899456",
  "text" : "somebody hide me... or im gonna have to listen to all day rant.. ack! #ilivewithseriouspokemonfan https:\/\/t.co\/bQpXNbZYjt",
  "id" : 778235661962899456,
  "created_at" : "2016-09-20 14:13:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Highland Cows",
      "screen_name" : "Highland_Cows",
      "indices" : [ 3, 17 ],
      "id_str" : "4713471382",
      "id" : 4713471382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Highland_Cows\/status\/778105909377630208\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ZVckPCZ4vj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsxjLz8W8AEDse_.jpg",
      "id_str" : "778105890201333761",
      "id" : 778105890201333761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsxjLz8W8AEDse_.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ZVckPCZ4vj"
    } ],
    "hashtags" : [ {
      "text" : "TongueOutCoosday",
      "indices" : [ 38, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778235045198921728",
  "text" : "RT @Highland_Cows: Have an astounding #TongueOutCoosday \uD83D\uDC45\uD83D\uDC2E https:\/\/t.co\/ZVckPCZ4vj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Highland_Cows\/status\/778105909377630208\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/ZVckPCZ4vj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsxjLz8W8AEDse_.jpg",
        "id_str" : "778105890201333761",
        "id" : 778105890201333761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsxjLz8W8AEDse_.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ZVckPCZ4vj"
      } ],
      "hashtags" : [ {
        "text" : "TongueOutCoosday",
        "indices" : [ 19, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778105909377630208",
    "text" : "Have an astounding #TongueOutCoosday \uD83D\uDC45\uD83D\uDC2E https:\/\/t.co\/ZVckPCZ4vj",
    "id" : 778105909377630208,
    "created_at" : "2016-09-20 05:37:59 +0000",
    "user" : {
      "name" : "Highland Cows",
      "screen_name" : "Highland_Cows",
      "protected" : false,
      "id_str" : "4713471382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728252343079346178\/HIrhUjvN_normal.jpg",
      "id" : 4713471382,
      "verified" : false
    }
  },
  "id" : 778235045198921728,
  "created_at" : "2016-09-20 14:11:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EmilyBaah",
      "screen_name" : "EmilyBaah",
      "indices" : [ 3, 13 ],
      "id_str" : "22180969",
      "id" : 22180969
    }, {
      "name" : "TongueOutCoosday",
      "screen_name" : "tongueoutcoos",
      "indices" : [ 33, 47 ],
      "id_str" : "4783458341",
      "id" : 4783458341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/778158462794686465\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/XAGphgyZ48",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsyS8WCW8AAZeZ3.jpg",
      "id_str" : "778158401033531392",
      "id" : 778158401033531392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsyS8WCW8AAZeZ3.jpg",
      "sizes" : [ {
        "h" : 1219,
        "resize" : "fit",
        "w" : 1939
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1219,
        "resize" : "fit",
        "w" : 1939
      } ],
      "display_url" : "pic.twitter.com\/XAGphgyZ48"
    } ],
    "hashtags" : [ {
      "text" : "tongueoutcoosday",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778233622520270848",
  "text" : "RT @EmilyBaah: #tongueoutcoosday @tongueoutcoos https:\/\/t.co\/XAGphgyZ48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TongueOutCoosday",
        "screen_name" : "tongueoutcoos",
        "indices" : [ 18, 32 ],
        "id_str" : "4783458341",
        "id" : 4783458341
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EmilyBaah\/status\/778158462794686465\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/XAGphgyZ48",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsyS8WCW8AAZeZ3.jpg",
        "id_str" : "778158401033531392",
        "id" : 778158401033531392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsyS8WCW8AAZeZ3.jpg",
        "sizes" : [ {
          "h" : 1219,
          "resize" : "fit",
          "w" : 1939
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1219,
          "resize" : "fit",
          "w" : 1939
        } ],
        "display_url" : "pic.twitter.com\/XAGphgyZ48"
      } ],
      "hashtags" : [ {
        "text" : "tongueoutcoosday",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778158462794686465",
    "text" : "#tongueoutcoosday @tongueoutcoos https:\/\/t.co\/XAGphgyZ48",
    "id" : 778158462794686465,
    "created_at" : "2016-09-20 09:06:49 +0000",
    "user" : {
      "name" : "EmilyBaah",
      "screen_name" : "EmilyBaah",
      "protected" : false,
      "id_str" : "22180969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792438768246620160\/0ES1rhAt_normal.jpg",
      "id" : 22180969,
      "verified" : false
    }
  },
  "id" : 778233622520270848,
  "created_at" : "2016-09-20 14:05:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Abramovitch",
      "screen_name" : "SethAbramovitch",
      "indices" : [ 3, 19 ],
      "id_str" : "14053627",
      "id" : 14053627
    }, {
      "name" : "Skittles",
      "screen_name" : "Skittles",
      "indices" : [ 31, 40 ],
      "id_str" : "105145017",
      "id" : 105145017
    }, {
      "name" : "Donald Trump Jr.",
      "screen_name" : "DonaldJTrumpJr",
      "indices" : [ 68, 83 ],
      "id_str" : "39344374",
      "id" : 39344374
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SethAbramovitch\/status\/778091768793407488\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/OmkJQkIqug",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsxWU5AXgAEF_B6.jpg",
      "id_str" : "778091752527986689",
      "id" : 778091752527986689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsxWU5AXgAEF_B6.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 1187
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 1187
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 1187
      } ],
      "display_url" : "pic.twitter.com\/OmkJQkIqug"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778229679606132736",
  "text" : "RT @SethAbramovitch: A rep for @Skittles gives me their response to @DonaldJTrumpJr https:\/\/t.co\/OmkJQkIqug",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Skittles",
        "screen_name" : "Skittles",
        "indices" : [ 10, 19 ],
        "id_str" : "105145017",
        "id" : 105145017
      }, {
        "name" : "Donald Trump Jr.",
        "screen_name" : "DonaldJTrumpJr",
        "indices" : [ 47, 62 ],
        "id_str" : "39344374",
        "id" : 39344374
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SethAbramovitch\/status\/778091768793407488\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/OmkJQkIqug",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsxWU5AXgAEF_B6.jpg",
        "id_str" : "778091752527986689",
        "id" : 778091752527986689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsxWU5AXgAEF_B6.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 1187
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 1187
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 1187
        } ],
        "display_url" : "pic.twitter.com\/OmkJQkIqug"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778091768793407488",
    "text" : "A rep for @Skittles gives me their response to @DonaldJTrumpJr https:\/\/t.co\/OmkJQkIqug",
    "id" : 778091768793407488,
    "created_at" : "2016-09-20 04:41:48 +0000",
    "user" : {
      "name" : "Seth Abramovitch",
      "screen_name" : "SethAbramovitch",
      "protected" : false,
      "id_str" : "14053627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796508787901218816\/PinrPlKk_normal.jpg",
      "id" : 14053627,
      "verified" : true
    }
  },
  "id" : 778229679606132736,
  "created_at" : "2016-09-20 13:49:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feathers",
      "screen_name" : "FeathersBirding",
      "indices" : [ 3, 19 ],
      "id_str" : "2361363194",
      "id" : 2361363194
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FeathersBirding\/status\/777954255831465984\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/gPfGBbGwMq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvYhwXW8AA337V.jpg",
      "id_str" : "777953435081699328",
      "id" : 777953435081699328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvYhwXW8AA337V.jpg",
      "sizes" : [ {
        "h" : 746,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1045,
        "resize" : "fit",
        "w" : 1681
      }, {
        "h" : 1045,
        "resize" : "fit",
        "w" : 1681
      } ],
      "display_url" : "pic.twitter.com\/gPfGBbGwMq"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/FeathersBirding\/status\/777954255831465984\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/gPfGBbGwMq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvYrv-XgAA22vm.jpg",
      "id_str" : "777953606775570432",
      "id" : 777953606775570432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvYrv-XgAA22vm.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 940,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1083,
        "resize" : "fit",
        "w" : 2359
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/gPfGBbGwMq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777961673151971328",
  "text" : "RT @FeathersBirding: Bath-time for the garden Robin. Nothing is as beautiful as nature. https:\/\/t.co\/gPfGBbGwMq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FeathersBirding\/status\/777954255831465984\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/gPfGBbGwMq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvYhwXW8AA337V.jpg",
        "id_str" : "777953435081699328",
        "id" : 777953435081699328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvYhwXW8AA337V.jpg",
        "sizes" : [ {
          "h" : 746,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1045,
          "resize" : "fit",
          "w" : 1681
        }, {
          "h" : 1045,
          "resize" : "fit",
          "w" : 1681
        } ],
        "display_url" : "pic.twitter.com\/gPfGBbGwMq"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FeathersBirding\/status\/777954255831465984\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/gPfGBbGwMq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvYrv-XgAA22vm.jpg",
        "id_str" : "777953606775570432",
        "id" : 777953606775570432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvYrv-XgAA22vm.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 940,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1083,
          "resize" : "fit",
          "w" : 2359
        }, {
          "h" : 551,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/gPfGBbGwMq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777954255831465984",
    "text" : "Bath-time for the garden Robin. Nothing is as beautiful as nature. https:\/\/t.co\/gPfGBbGwMq",
    "id" : 777954255831465984,
    "created_at" : "2016-09-19 19:35:22 +0000",
    "user" : {
      "name" : "Feathers",
      "screen_name" : "FeathersBirding",
      "protected" : false,
      "id_str" : "2361363194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517605352817176576\/pTxE5uc5_normal.jpeg",
      "id" : 2361363194,
      "verified" : false
    }
  },
  "id" : 777961673151971328,
  "created_at" : "2016-09-19 20:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lorraine cumming",
      "screen_name" : "wildlifelass",
      "indices" : [ 3, 16 ],
      "id_str" : "526710903",
      "id" : 526710903
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9Hrjzx8KE2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZeT5XgAA_l2C.jpg",
      "id_str" : "777532262946668544",
      "id" : 777532262946668544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZeT5XgAA_l2C.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9Hrjzx8KE2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZf2HWcAAi9Sw.jpg",
      "id_str" : "777532289311993856",
      "id" : 777532289311993856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZf2HWcAAi9Sw.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1068
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 1851,
        "resize" : "fit",
        "w" : 1647
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1851,
        "resize" : "fit",
        "w" : 1647
      } ],
      "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9Hrjzx8KE2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZichWgAA7py4.jpg",
      "id_str" : "777532333981335552",
      "id" : 777532333981335552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZichWgAA7py4.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9Hrjzx8KE2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZkEkWIAAYtZ8.jpg",
      "id_str" : "777532361911181312",
      "id" : 777532361911181312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZkEkWIAAYtZ8.jpg",
      "sizes" : [ {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1549
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1549
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
    } ],
    "hashtags" : [ {
      "text" : "Eskrigg",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "Lockerbie",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777961585860087808",
  "text" : "RT @wildlifelass: Took soooo many pics of these adorable little squirrels but so hard to resist #Eskrigg #Lockerbie https:\/\/t.co\/9Hrjzx8KE2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/9Hrjzx8KE2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZeT5XgAA_l2C.jpg",
        "id_str" : "777532262946668544",
        "id" : 777532262946668544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZeT5XgAA_l2C.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/9Hrjzx8KE2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZf2HWcAAi9Sw.jpg",
        "id_str" : "777532289311993856",
        "id" : 777532289311993856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZf2HWcAAi9Sw.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1068
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 1851,
          "resize" : "fit",
          "w" : 1647
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1851,
          "resize" : "fit",
          "w" : 1647
        } ],
        "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/9Hrjzx8KE2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZichWgAA7py4.jpg",
        "id_str" : "777532333981335552",
        "id" : 777532333981335552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZichWgAA7py4.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/777532386791845888\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/9Hrjzx8KE2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CspZkEkWIAAYtZ8.jpg",
        "id_str" : "777532361911181312",
        "id" : 777532361911181312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspZkEkWIAAYtZ8.jpg",
        "sizes" : [ {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1549
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1549
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/9Hrjzx8KE2"
      } ],
      "hashtags" : [ {
        "text" : "Eskrigg",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "Lockerbie",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777532386791845888",
    "text" : "Took soooo many pics of these adorable little squirrels but so hard to resist #Eskrigg #Lockerbie https:\/\/t.co\/9Hrjzx8KE2",
    "id" : 777532386791845888,
    "created_at" : "2016-09-18 15:39:01 +0000",
    "user" : {
      "name" : "lorraine cumming",
      "screen_name" : "wildlifelass",
      "protected" : false,
      "id_str" : "526710903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686952360673996800\/EGTFCaqx_normal.jpg",
      "id" : 526710903,
      "verified" : false
    }
  },
  "id" : 777961585860087808,
  "created_at" : "2016-09-19 20:04:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    }, {
      "name" : "BBC Four",
      "screen_name" : "BBCFOUR",
      "indices" : [ 123, 131 ],
      "id_str" : "3826680281",
      "id" : 3826680281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777950213373911040",
  "text" : "RT @derekrootboy: I am genuinely amazed that a fish can make a work of art to attract a mate. Anyone else know about this? @BBCFOUR #LifeSt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Four",
        "screen_name" : "BBCFOUR",
        "indices" : [ 105, 113 ],
        "id_str" : "3826680281",
        "id" : 3826680281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LifeStory",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777949860389584897",
    "text" : "I am genuinely amazed that a fish can make a work of art to attract a mate. Anyone else know about this? @BBCFOUR #LifeStory",
    "id" : 777949860389584897,
    "created_at" : "2016-09-19 19:17:54 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 777950213373911040,
  "created_at" : "2016-09-19 19:19:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "indices" : [ 3, 12 ],
      "id_str" : "116786271",
      "id" : 116786271
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AniArene\/status\/730971674963771392\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/KxQXVDVrnd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiTu25NWkAEfmDG.jpg",
      "id_str" : "730971666378035201",
      "id" : 730971666378035201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiTu25NWkAEfmDG.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1251,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1652,
        "resize" : "fit",
        "w" : 1352
      } ],
      "display_url" : "pic.twitter.com\/KxQXVDVrnd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777940691641044992",
  "text" : "RT @AniArene: What is Enlightenment? https:\/\/t.co\/KxQXVDVrnd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AniArene\/status\/730971674963771392\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/KxQXVDVrnd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiTu25NWkAEfmDG.jpg",
        "id_str" : "730971666378035201",
        "id" : 730971666378035201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiTu25NWkAEfmDG.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1251,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1652,
          "resize" : "fit",
          "w" : 1352
        } ],
        "display_url" : "pic.twitter.com\/KxQXVDVrnd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730971674963771392",
    "text" : "What is Enlightenment? https:\/\/t.co\/KxQXVDVrnd",
    "id" : 730971674963771392,
    "created_at" : "2016-05-13 04:03:22 +0000",
    "user" : {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "protected" : false,
      "id_str" : "116786271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797875002725036032\/G_rxW-Dq_normal.jpg",
      "id" : 116786271,
      "verified" : false
    }
  },
  "id" : 777940691641044992,
  "created_at" : "2016-09-19 18:41:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Haviour",
      "screen_name" : "SpinningJ",
      "indices" : [ 3, 13 ],
      "id_str" : "355648660",
      "id" : 355648660
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 108, 120 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brainache",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777897430897586176",
  "text" : "RT @SpinningJ: Oh my goodness - this is going to take a while I think. 8th row of pattern repeat #brainache @ErinEFarley https:\/\/t.co\/lYsOB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 93, 105 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpinningJ\/status\/777888619956690944\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/lYsOB9Rdml",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsudkucWEAAqr9d.jpg",
        "id_str" : "777888614919311360",
        "id" : 777888614919311360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsudkucWEAAqr9d.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lYsOB9Rdml"
      } ],
      "hashtags" : [ {
        "text" : "brainache",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777888619956690944",
    "text" : "Oh my goodness - this is going to take a while I think. 8th row of pattern repeat #brainache @ErinEFarley https:\/\/t.co\/lYsOB9Rdml",
    "id" : 777888619956690944,
    "created_at" : "2016-09-19 15:14:34 +0000",
    "user" : {
      "name" : "Julie Haviour",
      "screen_name" : "SpinningJ",
      "protected" : false,
      "id_str" : "355648660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1496916965\/polonaise_20spinning_20wheel_normal.jpg",
      "id" : 355648660,
      "verified" : false
    }
  },
  "id" : 777897430897586176,
  "created_at" : "2016-09-19 15:49:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "indices" : [ 3, 17 ],
      "id_str" : "39764564",
      "id" : 39764564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777875372566257664",
  "text" : "RT @ruslandvalley: Rowan was once wild, untouchable, ifyoucancatchhimyoucanhavehim. Now he wants to come home with me. https:\/\/t.co\/hEoGcsl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/777833586930180097\/video\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/hEoGcslWSG",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777832210632216576\/pu\/img\/yyjXLAuy82FeZ3uU.jpg",
        "id_str" : "777832210632216576",
        "id" : 777832210632216576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777832210632216576\/pu\/img\/yyjXLAuy82FeZ3uU.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hEoGcslWSG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777833586930180097",
    "text" : "Rowan was once wild, untouchable, ifyoucancatchhimyoucanhavehim. Now he wants to come home with me. https:\/\/t.co\/hEoGcslWSG",
    "id" : 777833586930180097,
    "created_at" : "2016-09-19 11:35:53 +0000",
    "user" : {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "protected" : false,
      "id_str" : "39764564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724649178589179904\/f5KDvdpC_normal.jpg",
      "id" : 39764564,
      "verified" : false
    }
  },
  "id" : 777875372566257664,
  "created_at" : "2016-09-19 14:21:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777686869823852544",
  "text" : "RT @JacksonPearce: Today I worked on a book, went to a wedding, then hurried home to give a chicken a shot like a pro.*\n\n*Pro status pendin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777682142889402368",
    "text" : "Today I worked on a book, went to a wedding, then hurried home to give a chicken a shot like a pro.*\n\n*Pro status pending chicken wellness",
    "id" : 777682142889402368,
    "created_at" : "2016-09-19 01:34:06 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 777686869823852544,
  "created_at" : "2016-09-19 01:52:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kerr",
      "screen_name" : "scott_kerr",
      "indices" : [ 3, 14 ],
      "id_str" : "11837102",
      "id" : 11837102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777686103184838656",
  "text" : "RT @scott_kerr: Boy writes to Lego after losing a mini-figure.\n\nLego's customer service department should run the world. https:\/\/t.co\/6iz0d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scott_kerr\/status\/776752757894184960\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/6iz0dS1gvu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CseTbouWcAIlAt_.jpg",
        "id_str" : "776751563742277634",
        "id" : 776751563742277634,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CseTbouWcAIlAt_.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 470
        } ],
        "display_url" : "pic.twitter.com\/6iz0dS1gvu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776752757894184960",
    "text" : "Boy writes to Lego after losing a mini-figure.\n\nLego's customer service department should run the world. https:\/\/t.co\/6iz0dS1gvu",
    "id" : 776752757894184960,
    "created_at" : "2016-09-16 12:01:03 +0000",
    "user" : {
      "name" : "Scott Kerr",
      "screen_name" : "scott_kerr",
      "protected" : false,
      "id_str" : "11837102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436570400399433728\/td5reU4o_normal.jpeg",
      "id" : 11837102,
      "verified" : false
    }
  },
  "id" : 777686103184838656,
  "created_at" : "2016-09-19 01:49:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "indices" : [ 3, 11 ],
      "id_str" : "16573941",
      "id" : 16573941
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/netflix\/status\/773753338617659392\/video\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/xo8mppuCa1",
      "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/773752381854986240\/img\/w3QNXkY18WhZAJhN.jpg",
      "id_str" : "773752381854986240",
      "id" : 773752381854986240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/773752381854986240\/img\/w3QNXkY18WhZAJhN.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xo8mppuCa1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777685107293429760",
  "text" : "RT @netflix: At what point does perception become reality? Amanda Knox is coming to Netflix Sept. 30. https:\/\/t.co\/xo8mppuCa1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/netflix\/status\/773753338617659392\/video\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/xo8mppuCa1",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/773752381854986240\/img\/w3QNXkY18WhZAJhN.jpg",
        "id_str" : "773752381854986240",
        "id" : 773752381854986240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/773752381854986240\/img\/w3QNXkY18WhZAJhN.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xo8mppuCa1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773753338617659392",
    "text" : "At what point does perception become reality? Amanda Knox is coming to Netflix Sept. 30. https:\/\/t.co\/xo8mppuCa1",
    "id" : 773753338617659392,
    "created_at" : "2016-09-08 05:22:26 +0000",
    "user" : {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "protected" : false,
      "id_str" : "16573941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744949842720391168\/wuzyVTTX_normal.jpg",
      "id" : 16573941,
      "verified" : true
    }
  },
  "id" : 777685107293429760,
  "created_at" : "2016-09-19 01:45:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly",
      "screen_name" : "Kmich718",
      "indices" : [ 3, 12 ],
      "id_str" : "131023703",
      "id" : 131023703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777671148565852160",
  "text" : "RT @Kmich718: This is America. Well done, Garfield HS. RT Entire Seattle HS Football Team Kneels During National Anthem https:\/\/t.co\/fGr1XX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/fGr1XXGKJQ",
        "expanded_url" : "http:\/\/crooksandliars.com\/2016\/09\/entire-seattle-hs-football-team-kneels",
        "display_url" : "crooksandliars.com\/2016\/09\/entire\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777661579944787968",
    "text" : "This is America. Well done, Garfield HS. RT Entire Seattle HS Football Team Kneels During National Anthem https:\/\/t.co\/fGr1XXGKJQ",
    "id" : 777661579944787968,
    "created_at" : "2016-09-19 00:12:23 +0000",
    "user" : {
      "name" : "Kimberly",
      "screen_name" : "Kmich718",
      "protected" : false,
      "id_str" : "131023703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796434406852308992\/5fNjXmlt_normal.jpg",
      "id" : 131023703,
      "verified" : false
    }
  },
  "id" : 777671148565852160,
  "created_at" : "2016-09-19 00:50:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "template",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "spreadsheet",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777618638698344449",
  "text" : "trying to figure out best way to sort lab results. test name, category, date.. ack. #tech #template #spreadsheet",
  "id" : 777618638698344449,
  "created_at" : "2016-09-18 21:21:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "indices" : [ 3, 14 ],
      "id_str" : "1922414958",
      "id" : 1922414958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Diabetes",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "Cancer",
      "indices" : [ 114, 121 ]
    }, {
      "text" : "Asthma",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777618066079358977",
  "text" : "RT @LonnieRhea: The 2 biggest prescription insurers 2017 lists of excluded drugs includes some Meds for #Diabetes #Cancer #Asthma \uD83D\uDE21 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Diabetes",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "Cancer",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "Asthma",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/rwxuj0QTR8",
        "expanded_url" : "https:\/\/twitter.com\/lonnierhea\/status\/777566139391971328",
        "display_url" : "twitter.com\/lonnierhea\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777567283749138432",
    "text" : "The 2 biggest prescription insurers 2017 lists of excluded drugs includes some Meds for #Diabetes #Cancer #Asthma \uD83D\uDE21 https:\/\/t.co\/rwxuj0QTR8",
    "id" : 777567283749138432,
    "created_at" : "2016-09-18 17:57:41 +0000",
    "user" : {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "protected" : false,
      "id_str" : "1922414958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738411243678007297\/OesFzoaA_normal.jpg",
      "id" : 1922414958,
      "verified" : false
    }
  },
  "id" : 777618066079358977,
  "created_at" : "2016-09-18 21:19:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "indices" : [ 3, 14 ],
      "id_str" : "49698134",
      "id" : 49698134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/o6X4nhAIbz",
      "expanded_url" : "https:\/\/twitter.com\/ismashfizzle\/status\/777575733245927425",
      "display_url" : "twitter.com\/ismashfizzle\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777602576615350272",
  "text" : "RT @JoyAnnReid: Well said. https:\/\/t.co\/o6X4nhAIbz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/o6X4nhAIbz",
        "expanded_url" : "https:\/\/twitter.com\/ismashfizzle\/status\/777575733245927425",
        "display_url" : "twitter.com\/ismashfizzle\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777588608115044352",
    "text" : "Well said. https:\/\/t.co\/o6X4nhAIbz",
    "id" : 777588608115044352,
    "created_at" : "2016-09-18 19:22:25 +0000",
    "user" : {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "protected" : false,
      "id_str" : "49698134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796364947517161472\/O7jPbVMJ_normal.jpg",
      "id" : 49698134,
      "verified" : true
    }
  },
  "id" : 777602576615350272,
  "created_at" : "2016-09-18 20:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/777598806942748672\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Ai5vp2uhik",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsqV_h7XEAA5Ftb.jpg",
      "id_str" : "777598804346474496",
      "id" : 777598804346474496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsqV_h7XEAA5Ftb.jpg",
      "sizes" : [ {
        "h" : 609,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/Ai5vp2uhik"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/fpRktvV8n3",
      "expanded_url" : "https:\/\/themighty.com\/2016\/09\/things-doctors-said-about-my-lyme-disease-that-didnt-help?_ts=1474228971",
      "display_url" : "themighty.com\/2016\/09\/things\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777598806942748672",
  "text" : "Things Doctors Said About My Lyme Disease That Didn\u2019t Help https:\/\/t.co\/fpRktvV8n3 https:\/\/t.co\/Ai5vp2uhik",
  "id" : 777598806942748672,
  "created_at" : "2016-09-18 20:02:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/777597950516133890\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xFXy670NhE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsqVNshWYAEEvET.jpg",
      "id_str" : "777597948196708353",
      "id" : 777597948196708353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsqVNshWYAEEvET.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/xFXy670NhE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/mEWLtzBFkX",
      "expanded_url" : "https:\/\/themighty.com\/2016\/09\/things-doctors-said-about-my-lyme-disease-that-didnt-help?_ts=1474228769",
      "display_url" : "themighty.com\/2016\/09\/things\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777597950516133890",
  "text" : "Things Doctors Said About My Lyme Disease That Didn\u2019t Help https:\/\/t.co\/mEWLtzBFkX https:\/\/t.co\/xFXy670NhE",
  "id" : 777597950516133890,
  "created_at" : "2016-09-18 19:59:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/777596908441374721\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/OaWu3VRP9T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsqURBFW8AQSgr-.jpg",
      "id_str" : "777596905744429060",
      "id" : 777596905744429060,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsqURBFW8AQSgr-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/OaWu3VRP9T"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/GkTSGzQNqp",
      "expanded_url" : "https:\/\/themighty.com\/2016\/09\/things-doctors-said-about-my-lyme-disease-that-didnt-help?_ts=1474228520",
      "display_url" : "themighty.com\/2016\/09\/things\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777596908441374721",
  "text" : "Things Doctors Said About My Lyme Disease That Didn\u2019t Help https:\/\/t.co\/GkTSGzQNqp https:\/\/t.co\/OaWu3VRP9T",
  "id" : 777596908441374721,
  "created_at" : "2016-09-18 19:55:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayerSunday",
      "indices" : [ 19, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/8DvZfDxM0C",
      "expanded_url" : "https:\/\/twitter.com\/coloradocareyes\/status\/776102925366099969",
      "display_url" : "twitter.com\/coloradocareye\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777543025803292672",
  "text" : "RT @AllOnMedicare: #SinglePayerSunday must read! https:\/\/t.co\/8DvZfDxM0C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayerSunday",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/8DvZfDxM0C",
        "expanded_url" : "https:\/\/twitter.com\/coloradocareyes\/status\/776102925366099969",
        "display_url" : "twitter.com\/coloradocareye\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777541586725048320",
    "text" : "#SinglePayerSunday must read! https:\/\/t.co\/8DvZfDxM0C",
    "id" : 777541586725048320,
    "created_at" : "2016-09-18 16:15:34 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 777543025803292672,
  "created_at" : "2016-09-18 16:21:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Tips for ME",
      "screen_name" : "TweetTipsforME",
      "indices" : [ 3, 18 ],
      "id_str" : "2427294475",
      "id" : 2427294475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spoonie",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "MEcfs",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "POTS",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "pwme",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/p6C7DnzhNo",
      "expanded_url" : "http:\/\/buff.ly\/2cEAkDH",
      "display_url" : "buff.ly\/2cEAkDH"
    } ]
  },
  "geo" : { },
  "id_str" : "777542898661359616",
  "text" : "RT @TweetTipsforME: Please RT: insights from the #spoonie world of #MEcfs and #POTS\nfor #pwme + #chronicillness https:\/\/t.co\/p6C7DnzhNo htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TweetTipsforME\/status\/777541702634668033\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/8NdzkjMgp1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CspiDlDWgAA4ta0.jpg",
        "id_str" : "777541699300130816",
        "id" : 777541699300130816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CspiDlDWgAA4ta0.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8NdzkjMgp1"
      } ],
      "hashtags" : [ {
        "text" : "spoonie",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "MEcfs",
        "indices" : [ 47, 53 ]
      }, {
        "text" : "POTS",
        "indices" : [ 58, 63 ]
      }, {
        "text" : "pwme",
        "indices" : [ 68, 73 ]
      }, {
        "text" : "chronicillness",
        "indices" : [ 76, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/p6C7DnzhNo",
        "expanded_url" : "http:\/\/buff.ly\/2cEAkDH",
        "display_url" : "buff.ly\/2cEAkDH"
      } ]
    },
    "geo" : { },
    "id_str" : "777541702634668033",
    "text" : "Please RT: insights from the #spoonie world of #MEcfs and #POTS\nfor #pwme + #chronicillness https:\/\/t.co\/p6C7DnzhNo https:\/\/t.co\/8NdzkjMgp1",
    "id" : 777541702634668033,
    "created_at" : "2016-09-18 16:16:02 +0000",
    "user" : {
      "name" : "Jenny Tips for ME",
      "screen_name" : "TweetTipsforME",
      "protected" : false,
      "id_str" : "2427294475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734773542659596288\/PXiwF4uP_normal.png",
      "id" : 2427294475,
      "verified" : false
    }
  },
  "id" : 777542898661359616,
  "created_at" : "2016-09-18 16:20:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "indices" : [ 3, 19 ],
      "id_str" : "4218819269",
      "id" : 4218819269
    }, {
      "name" : "Redbubble",
      "screen_name" : "redbubble",
      "indices" : [ 104, 114 ],
      "id_str" : "15276618",
      "id" : 15276618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/buHlBdVy8N",
      "expanded_url" : "http:\/\/www.redbubble.com\/people\/audiobookworm\/works\/23194253-audiobooks-rock-my-world?asc=t&p=ipad-case",
      "display_url" : "redbubble.com\/people\/audiobo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777533684132024321",
  "text" : "RT @AnAudiobookworm: How cute is this \"Audiobooks Rock My World\" iPad skin? https:\/\/t.co\/buHlBdVy8N via @redbubble",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Redbubble",
        "screen_name" : "redbubble",
        "indices" : [ 83, 93 ],
        "id_str" : "15276618",
        "id" : 15276618
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/buHlBdVy8N",
        "expanded_url" : "http:\/\/www.redbubble.com\/people\/audiobookworm\/works\/23194253-audiobooks-rock-my-world?asc=t&p=ipad-case",
        "display_url" : "redbubble.com\/people\/audiobo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777310812968849408",
    "text" : "How cute is this \"Audiobooks Rock My World\" iPad skin? https:\/\/t.co\/buHlBdVy8N via @redbubble",
    "id" : 777310812968849408,
    "created_at" : "2016-09-18 00:58:34 +0000",
    "user" : {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "protected" : false,
      "id_str" : "4218819269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690226493151117312\/IydgluWy_normal.jpg",
      "id" : 4218819269,
      "verified" : false
    }
  },
  "id" : 777533684132024321,
  "created_at" : "2016-09-18 15:44:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777529518265405440",
  "text" : "missing ppl in my TL.. dont remember names but sense the loss of their essence.",
  "id" : 777529518265405440,
  "created_at" : "2016-09-18 15:27:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy G",
      "screen_name" : "GuellichPhoto",
      "indices" : [ 3, 17 ],
      "id_str" : "2216765432",
      "id" : 2216765432
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/777367906988404737\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ChqCGT9Kq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsnD8zOUAAAVLT0.jpg",
      "id_str" : "777367860007927808",
      "id" : 777367860007927808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsnD8zOUAAAVLT0.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ChqCGT9Kq6"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/777367906988404737\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ChqCGT9Kq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsnD9XfUkAAalkM.jpg",
      "id_str" : "777367869742944256",
      "id" : 777367869742944256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsnD9XfUkAAalkM.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ChqCGT9Kq6"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/777367906988404737\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ChqCGT9Kq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsnD-u_UAAApz8U.jpg",
      "id_str" : "777367893231009792",
      "id" : 777367893231009792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsnD-u_UAAApz8U.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ChqCGT9Kq6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777528838775603200",
  "text" : "RT @GuellichPhoto: Under the desert moon.... https:\/\/t.co\/ChqCGT9Kq6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/777367906988404737\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/ChqCGT9Kq6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsnD8zOUAAAVLT0.jpg",
        "id_str" : "777367860007927808",
        "id" : 777367860007927808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsnD8zOUAAAVLT0.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ChqCGT9Kq6"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/777367906988404737\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/ChqCGT9Kq6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsnD9XfUkAAalkM.jpg",
        "id_str" : "777367869742944256",
        "id" : 777367869742944256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsnD9XfUkAAalkM.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ChqCGT9Kq6"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/GuellichPhoto\/status\/777367906988404737\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/ChqCGT9Kq6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsnD-u_UAAApz8U.jpg",
        "id_str" : "777367893231009792",
        "id" : 777367893231009792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsnD-u_UAAApz8U.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ChqCGT9Kq6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777367906988404737",
    "text" : "Under the desert moon.... https:\/\/t.co\/ChqCGT9Kq6",
    "id" : 777367906988404737,
    "created_at" : "2016-09-18 04:45:26 +0000",
    "user" : {
      "name" : "Kathy G",
      "screen_name" : "GuellichPhoto",
      "protected" : false,
      "id_str" : "2216765432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712289505932214272\/O9BsG-vM_normal.jpg",
      "id" : 2216765432,
      "verified" : false
    }
  },
  "id" : 777528838775603200,
  "created_at" : "2016-09-18 15:24:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/CNw81wgWiv",
      "expanded_url" : "https:\/\/twitter.com\/Elishabenabuya\/status\/777433969566547968",
      "display_url" : "twitter.com\/Elishabenabuya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777523035003883520",
  "text" : "very interesting. glad for the examples. https:\/\/t.co\/CNw81wgWiv",
  "id" : 777523035003883520,
  "created_at" : "2016-09-18 15:01:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy",
      "screen_name" : "taytay_88_",
      "indices" : [ 3, 14 ],
      "id_str" : "68151918",
      "id" : 68151918
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/taytay_88_\/status\/771798786641424388\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/s4ZXctsuSZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrX65RcXYAAMHbw.jpg",
      "id_str" : "771798773005770752",
      "id" : 771798773005770752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrX65RcXYAAMHbw.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 698
      } ],
      "display_url" : "pic.twitter.com\/s4ZXctsuSZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777522412527247360",
  "text" : "RT @taytay_88_: https:\/\/t.co\/s4ZXctsuSZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/taytay_88_\/status\/771798786641424388\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/s4ZXctsuSZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrX65RcXYAAMHbw.jpg",
        "id_str" : "771798773005770752",
        "id" : 771798773005770752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrX65RcXYAAMHbw.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 698
        } ],
        "display_url" : "pic.twitter.com\/s4ZXctsuSZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771798786641424388",
    "text" : "https:\/\/t.co\/s4ZXctsuSZ",
    "id" : 771798786641424388,
    "created_at" : "2016-09-02 19:55:44 +0000",
    "user" : {
      "name" : "Andy",
      "screen_name" : "taytay_88_",
      "protected" : false,
      "id_str" : "68151918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782179066057195520\/xkdCUvuG_normal.jpg",
      "id" : 68151918,
      "verified" : false
    }
  },
  "id" : 777522412527247360,
  "created_at" : "2016-09-18 14:59:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/G6evuDlc6E",
      "expanded_url" : "http:\/\/nyti.ms\/2cVcZmw",
      "display_url" : "nyti.ms\/2cVcZmw"
    } ]
  },
  "geo" : { },
  "id_str" : "777522173875544064",
  "text" : "RT @nytimes: Trump real estate empire was built on millions of dollars in assistance from the government https:\/\/t.co\/G6evuDlc6E https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/777501215823425536\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/hJ2qiFeKyh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cso9Os0XYAAHS1W.jpg",
        "id_str" : "777501208433090560",
        "id" : 777501208433090560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cso9Os0XYAAHS1W.jpg",
        "sizes" : [ {
          "h" : 1612,
          "resize" : "fit",
          "w" : 2890
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1142,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/hJ2qiFeKyh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/G6evuDlc6E",
        "expanded_url" : "http:\/\/nyti.ms\/2cVcZmw",
        "display_url" : "nyti.ms\/2cVcZmw"
      } ]
    },
    "geo" : { },
    "id_str" : "777501215823425536",
    "text" : "Trump real estate empire was built on millions of dollars in assistance from the government https:\/\/t.co\/G6evuDlc6E https:\/\/t.co\/hJ2qiFeKyh",
    "id" : 777501215823425536,
    "created_at" : "2016-09-18 13:35:09 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 777522173875544064,
  "created_at" : "2016-09-18 14:58:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777522062101536768",
  "text" : "RT @ZachsMind: More than ever, politics is about how people feel. If we cared to do what's objectively right, we wouldn't need a vote. We a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777519888898207744",
    "text" : "More than ever, politics is about how people feel. If we cared to do what's objectively right, we wouldn't need a vote. We already know.",
    "id" : 777519888898207744,
    "created_at" : "2016-09-18 14:49:21 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 777522062101536768,
  "created_at" : "2016-09-18 14:57:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "indices" : [ 3, 17 ],
      "id_str" : "39764564",
      "id" : 39764564
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/777493320373264384\/video\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/XMon7VVcS1",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777483539101130752\/pu\/img\/70sFeVOk3X_HVdN9.jpg",
      "id_str" : "777483539101130752",
      "id" : 777483539101130752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777483539101130752\/pu\/img\/70sFeVOk3X_HVdN9.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XMon7VVcS1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777522031260758016",
  "text" : "RT @ruslandvalley: Its a busy day in Rusland. Lots of traffic on the roads https:\/\/t.co\/XMon7VVcS1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/777493320373264384\/video\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/XMon7VVcS1",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777483539101130752\/pu\/img\/70sFeVOk3X_HVdN9.jpg",
        "id_str" : "777483539101130752",
        "id" : 777483539101130752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777483539101130752\/pu\/img\/70sFeVOk3X_HVdN9.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XMon7VVcS1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777493320373264384",
    "text" : "Its a busy day in Rusland. Lots of traffic on the roads https:\/\/t.co\/XMon7VVcS1",
    "id" : 777493320373264384,
    "created_at" : "2016-09-18 13:03:47 +0000",
    "user" : {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "protected" : false,
      "id_str" : "39764564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724649178589179904\/f5KDvdpC_normal.jpg",
      "id" : 39764564,
      "verified" : false
    }
  },
  "id" : 777522031260758016,
  "created_at" : "2016-09-18 14:57:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Pass",
      "screen_name" : "steven_pass",
      "indices" : [ 3, 15 ],
      "id_str" : "2311437785",
      "id" : 2311437785
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/777451866963709952\/video\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/FPVpk9kFDD",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777450559989248000\/pu\/img\/5UdfxFHl7wFk5b0B.jpg",
      "id_str" : "777450559989248000",
      "id" : 777450559989248000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777450559989248000\/pu\/img\/5UdfxFHl7wFk5b0B.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FPVpk9kFDD"
    } ],
    "hashtags" : [ {
      "text" : "Highlandcattle",
      "indices" : [ 30, 45 ]
    }, {
      "text" : "teamcoos",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777521859722108928",
  "text" : "RT @steven_pass: Lazy Sunday. #Highlandcattle #teamcoos https:\/\/t.co\/FPVpk9kFDD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/777451866963709952\/video\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/FPVpk9kFDD",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777450559989248000\/pu\/img\/5UdfxFHl7wFk5b0B.jpg",
        "id_str" : "777450559989248000",
        "id" : 777450559989248000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777450559989248000\/pu\/img\/5UdfxFHl7wFk5b0B.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FPVpk9kFDD"
      } ],
      "hashtags" : [ {
        "text" : "Highlandcattle",
        "indices" : [ 13, 28 ]
      }, {
        "text" : "teamcoos",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777451866963709952",
    "text" : "Lazy Sunday. #Highlandcattle #teamcoos https:\/\/t.co\/FPVpk9kFDD",
    "id" : 777451866963709952,
    "created_at" : "2016-09-18 10:19:04 +0000",
    "user" : {
      "name" : "Steven Pass",
      "screen_name" : "steven_pass",
      "protected" : false,
      "id_str" : "2311437785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792643598831452160\/puKwwP4Y_normal.jpg",
      "id" : 2311437785,
      "verified" : false
    }
  },
  "id" : 777521859722108928,
  "created_at" : "2016-09-18 14:57:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777520905752838144",
  "text" : "RT @existentialcoms: Why study philosophy?\nWittgenstein: to clarify thought\nPlato: to live the good life\nMarx: to change the world\nHume: mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775410356512403456",
    "text" : "Why study philosophy?\nWittgenstein: to clarify thought\nPlato: to live the good life\nMarx: to change the world\nHume: mostly to piss off Kant",
    "id" : 775410356512403456,
    "created_at" : "2016-09-12 19:06:50 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 777520905752838144,
  "created_at" : "2016-09-18 14:53:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn White",
      "screen_name" : "dawncwhite",
      "indices" : [ 3, 14 ],
      "id_str" : "3045141446",
      "id" : 3045141446
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dawncwhite\/status\/777341483091365888\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/JIJCFx3tNt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Csmr9O1WIAA__AS.jpg",
      "id_str" : "777341479140335616",
      "id" : 777341479140335616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csmr9O1WIAA__AS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/JIJCFx3tNt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777518824656670720",
  "text" : "RT @dawncwhite: https:\/\/t.co\/JIJCFx3tNt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/postplanner.com\" rel=\"nofollow\"\u003EPost Planner Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dawncwhite\/status\/777341483091365888\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/JIJCFx3tNt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Csmr9O1WIAA__AS.jpg",
        "id_str" : "777341479140335616",
        "id" : 777341479140335616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csmr9O1WIAA__AS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/JIJCFx3tNt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777341483091365888",
    "text" : "https:\/\/t.co\/JIJCFx3tNt",
    "id" : 777341483091365888,
    "created_at" : "2016-09-18 03:00:26 +0000",
    "user" : {
      "name" : "Dawn White",
      "screen_name" : "dawncwhite",
      "protected" : false,
      "id_str" : "3045141446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646662563694907395\/qXr68aNt_normal.jpg",
      "id" : 3045141446,
      "verified" : false
    }
  },
  "id" : 777518824656670720,
  "created_at" : "2016-09-18 14:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/34PynVV55X",
      "expanded_url" : "https:\/\/twitter.com\/Elishabenabuya\/status\/777190573807640577",
      "display_url" : "twitter.com\/Elishabenabuya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777515831370641408",
  "text" : "heehee https:\/\/t.co\/34PynVV55X",
  "id" : 777515831370641408,
  "created_at" : "2016-09-18 14:33:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FangirlNation",
      "screen_name" : "FGNMag",
      "indices" : [ 3, 10 ],
      "id_str" : "2413247078",
      "id" : 2413247078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cats",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777319703387770880",
  "text" : "RT @FGNMag: This is all kinds of awesome: Citizen Campaign to Replace All Ads with #Cats Triumphantly Launches in London - https:\/\/t.co\/xyX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cats",
        "indices" : [ 71, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/xyXOzzNCR6",
        "expanded_url" : "http:\/\/twistedsifter.com\/2016\/09\/ads-replaced-with-cats-in-london\/",
        "display_url" : "twistedsifter.com\/2016\/09\/ads-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777311216167292934",
    "text" : "This is all kinds of awesome: Citizen Campaign to Replace All Ads with #Cats Triumphantly Launches in London - https:\/\/t.co\/xyXOzzNCR6",
    "id" : 777311216167292934,
    "created_at" : "2016-09-18 01:00:10 +0000",
    "user" : {
      "name" : "FangirlNation",
      "screen_name" : "FGNMag",
      "protected" : false,
      "id_str" : "2413247078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782412114942005248\/pRUtTnaA_normal.jpg",
      "id" : 2413247078,
      "verified" : false
    }
  },
  "id" : 777319703387770880,
  "created_at" : "2016-09-18 01:33:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/777253879654285313\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/K5bpQDpcFv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CslcNGxWgAAnD0Q.jpg",
      "id_str" : "777253790923784192",
      "id" : 777253790923784192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CslcNGxWgAAnD0Q.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/K5bpQDpcFv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777258369140793344",
  "text" : "RT @Nigelstewart76: Nice walk along the old railway today nice and sunny https:\/\/t.co\/K5bpQDpcFv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/777253879654285313\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/K5bpQDpcFv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CslcNGxWgAAnD0Q.jpg",
        "id_str" : "777253790923784192",
        "id" : 777253790923784192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CslcNGxWgAAnD0Q.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/K5bpQDpcFv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777253879654285313",
    "text" : "Nice walk along the old railway today nice and sunny https:\/\/t.co\/K5bpQDpcFv",
    "id" : 777253879654285313,
    "created_at" : "2016-09-17 21:12:20 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 777258369140793344,
  "created_at" : "2016-09-17 21:30:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776963069654159361",
  "geo" : { },
  "id_str" : "777251794716127233",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields hehehe",
  "id" : 777251794716127233,
  "in_reply_to_status_id" : 776963069654159361,
  "created_at" : "2016-09-17 21:04:03 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "StarTalk",
      "screen_name" : "StarTalkRadio",
      "indices" : [ 28, 42 ],
      "id_str" : "41712825",
      "id" : 41712825
    }, {
      "name" : "Chuck Nice",
      "screen_name" : "chucknicecomic",
      "indices" : [ 78, 93 ],
      "id_str" : "26534772",
      "id" : 26534772
    }, {
      "name" : "iTunes Podcasts",
      "screen_name" : "iTunesPodcasts",
      "indices" : [ 97, 112 ],
      "id_str" : "48436234",
      "id" : 48436234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ada3gXAOqh",
      "expanded_url" : "http:\/\/bit.ly\/2d4BFoZ",
      "display_url" : "bit.ly\/2d4BFoZ"
    } ]
  },
  "geo" : { },
  "id_str" : "777251413084758017",
  "text" : "RT @neiltyson: JUST POSTED: @StarTalkRadio Cosmic Queries \"The Space Race\u201D w\/ @chucknicecomic on @iTunesPodcasts and https:\/\/t.co\/ada3gXAOqh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StarTalk",
        "screen_name" : "StarTalkRadio",
        "indices" : [ 13, 27 ],
        "id_str" : "41712825",
        "id" : 41712825
      }, {
        "name" : "Chuck Nice",
        "screen_name" : "chucknicecomic",
        "indices" : [ 63, 78 ],
        "id_str" : "26534772",
        "id" : 26534772
      }, {
        "name" : "iTunes Podcasts",
        "screen_name" : "iTunesPodcasts",
        "indices" : [ 82, 97 ],
        "id_str" : "48436234",
        "id" : 48436234
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ada3gXAOqh",
        "expanded_url" : "http:\/\/bit.ly\/2d4BFoZ",
        "display_url" : "bit.ly\/2d4BFoZ"
      } ]
    },
    "geo" : { },
    "id_str" : "777250562270257152",
    "text" : "JUST POSTED: @StarTalkRadio Cosmic Queries \"The Space Race\u201D w\/ @chucknicecomic on @iTunesPodcasts and https:\/\/t.co\/ada3gXAOqh",
    "id" : 777250562270257152,
    "created_at" : "2016-09-17 20:59:09 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 777251413084758017,
  "created_at" : "2016-09-17 21:02:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 3, 15 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777230410686291969",
  "text" : "RT @GeorgeTakei: Don Trump, Jr. says release of his father's tax returns would get folks \"asking questions\" that might \"detract from\" the c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776490779615367168",
    "text" : "Don Trump, Jr. says release of his father's tax returns would get folks \"asking questions\" that might \"detract from\" the campaign. NO. SHIT.",
    "id" : 776490779615367168,
    "created_at" : "2016-09-15 18:40:03 +0000",
    "user" : {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "protected" : false,
      "id_str" : "237845487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700355030117937152\/3uW9IKHD_normal.png",
      "id" : 237845487,
      "verified" : true
    }
  },
  "id" : 777230410686291969,
  "created_at" : "2016-09-17 19:39:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/x2CWr8jbQN",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx2CCzkXF",
      "display_url" : "tmblr.co\/Zp3-jx2CCzkXF"
    } ]
  },
  "geo" : { },
  "id_str" : "777175762164211712",
  "text" : "\uD83D\uDCF9 The Life of Death from Marsha Onderstijn on Vimeo. https:\/\/t.co\/x2CWr8jbQN",
  "id" : 777175762164211712,
  "created_at" : "2016-09-17 16:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/3wJNWc9hdV",
      "expanded_url" : "https:\/\/vimeo.com\/154739710",
      "display_url" : "vimeo.com\/154739710"
    } ]
  },
  "geo" : { },
  "id_str" : "777174929737445382",
  "text" : "sad and beautiful... \u201CThe Life of Death\u201D https:\/\/t.co\/3wJNWc9hdV",
  "id" : 777174929737445382,
  "created_at" : "2016-09-17 15:58:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "indices" : [ 3, 18 ],
      "id_str" : "1372975219",
      "id" : 1372975219
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BabyAnimalPics\/status\/777023107206873089\/video\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/M4I2qfh9tV",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777023042941845504\/pu\/img\/bTyoRBKJHWrkyF4a.jpg",
      "id_str" : "777023042941845504",
      "id" : 777023042941845504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777023042941845504\/pu\/img\/bTyoRBKJHWrkyF4a.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/M4I2qfh9tV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777142530509070337",
  "text" : "RT @BabyAnimalPics: now that's a happy donkey https:\/\/t.co\/M4I2qfh9tV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BabyAnimalPics\/status\/777023107206873089\/video\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/M4I2qfh9tV",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777023042941845504\/pu\/img\/bTyoRBKJHWrkyF4a.jpg",
        "id_str" : "777023042941845504",
        "id" : 777023042941845504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/777023042941845504\/pu\/img\/bTyoRBKJHWrkyF4a.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/M4I2qfh9tV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777023107206873089",
    "text" : "now that's a happy donkey https:\/\/t.co\/M4I2qfh9tV",
    "id" : 777023107206873089,
    "created_at" : "2016-09-17 05:55:19 +0000",
    "user" : {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "protected" : false,
      "id_str" : "1372975219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674018647833075712\/4AnZjeut_normal.jpg",
      "id" : 1372975219,
      "verified" : false
    }
  },
  "id" : 777142530509070337,
  "created_at" : "2016-09-17 13:49:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anime",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "gaming",
      "indices" : [ 94, 101 ]
    }, {
      "text" : "costume",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/iuLXK3xVyF",
      "expanded_url" : "http:\/\/www.newyorkcomiccon.com\/",
      "display_url" : "newyorkcomiccon.com"
    } ]
  },
  "in_reply_to_status_id_str" : "776935015146029057",
  "geo" : { },
  "id_str" : "776937981923950592",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides sorry.. comic cons.. conventions. like this &gt; https:\/\/t.co\/iuLXK3xVyF #anime #gaming #costume",
  "id" : 776937981923950592,
  "in_reply_to_status_id" : 776935015146029057,
  "created_at" : "2016-09-17 00:17:04 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/3Z5FvfgR5N",
      "expanded_url" : "https:\/\/twitter.com\/calebgraves\/status\/776903602950373376",
      "display_url" : "twitter.com\/calebgraves\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776934335614156800",
  "text" : "ohh.. i better stack em up and listen then! https:\/\/t.co\/3Z5FvfgR5N",
  "id" : 776934335614156800,
  "created_at" : "2016-09-17 00:02:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776922210401484804",
  "geo" : { },
  "id_str" : "776933302401916929",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides heehee.. you are funny (in a good way) .. you are a gem! : ) im ok, DD is feeling down, missing out on cons, etc (no energy)",
  "id" : 776933302401916929,
  "in_reply_to_status_id" : 776922210401484804,
  "created_at" : "2016-09-16 23:58:28 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Michael Gibson MD",
      "screen_name" : "CMichaelGibson",
      "indices" : [ 3, 18 ],
      "id_str" : "879161563",
      "id" : 879161563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776918254577147904",
  "text" : "RT @CMichaelGibson: Substituting heavier hydrogen atoms in drugs can slow their breakdown, leaving them in bloodstream longer https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/BBoaqrkVD6",
        "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2016-09-16\/a-decades-old-drug-technology-finally-nears-its-big-breakthrough",
        "display_url" : "bloomberg.com\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776901099563454466",
    "text" : "Substituting heavier hydrogen atoms in drugs can slow their breakdown, leaving them in bloodstream longer https:\/\/t.co\/BBoaqrkVD6",
    "id" : 776901099563454466,
    "created_at" : "2016-09-16 21:50:30 +0000",
    "user" : {
      "name" : "C. Michael Gibson MD",
      "screen_name" : "CMichaelGibson",
      "protected" : false,
      "id_str" : "879161563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2984843636\/4d4178f5c23492b2785e400e9ebf2c77_normal.jpeg",
      "id" : 879161563,
      "verified" : false
    }
  },
  "id" : 776918254577147904,
  "created_at" : "2016-09-16 22:58:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HarvestMoon",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776912831568576512",
  "text" : "RT @Charmantides: You know you are too into video games when you hoped the trend #HarvestMoon was about the Japanese farming sim. Not the a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HarvestMoon",
        "indices" : [ 63, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776898797968523264",
    "text" : "You know you are too into video games when you hoped the trend #HarvestMoon was about the Japanese farming sim. Not the actual moon.",
    "id" : 776898797968523264,
    "created_at" : "2016-09-16 21:41:22 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 776912831568576512,
  "created_at" : "2016-09-16 22:37:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 0, 10 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/y1X0GLmMtD",
      "expanded_url" : "https:\/\/twitter.com\/Charmantides\/status\/776860237651468292",
      "display_url" : "twitter.com\/Charmantides\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776863707896942592",
  "in_reply_to_user_id" : 19725644,
  "text" : "@neiltyson https:\/\/t.co\/y1X0GLmMtD",
  "id" : 776863707896942592,
  "created_at" : "2016-09-16 19:21:56 +0000",
  "in_reply_to_screen_name" : "neiltyson",
  "in_reply_to_user_id_str" : "19725644",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHRONICALLY",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776590639827914752",
  "text" : "RT @GoddessKerriLyn: WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 6\n\u2705 I never heard of that. Is it real?\n\u2705 yesterday u\u2026 why can't u today?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CHRONICALLY",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776547430254907393",
    "geo" : { },
    "id_str" : "776547971018190850",
    "in_reply_to_user_id" : 2920759605,
    "text" : "WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 6\n\u2705 I never heard of that. Is it real?\n\u2705 yesterday u\u2026 why can't u today?\n\u2705 oh I get that too.",
    "id" : 776547971018190850,
    "in_reply_to_status_id" : 776547430254907393,
    "created_at" : "2016-09-15 22:27:18 +0000",
    "in_reply_to_screen_name" : "GoddessKerriLyn",
    "in_reply_to_user_id_str" : "2920759605",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796371792990498816\/4oJw3Ycf_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 776590639827914752,
  "created_at" : "2016-09-16 01:16:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHRONICALLY",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776590587726274562",
  "text" : "RT @GoddessKerriLyn: WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 5\n\u2705 it could be worse\n\u2705 you should stop\u2026\n\u2705 you should start\u2026\n\u2705 you take\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CHRONICALLY",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776546964657889280",
    "geo" : { },
    "id_str" : "776547430254907393",
    "in_reply_to_user_id" : 2920759605,
    "text" : "WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 5\n\u2705 it could be worse\n\u2705 you should stop\u2026\n\u2705 you should start\u2026\n\u2705 you take too many medications",
    "id" : 776547430254907393,
    "in_reply_to_status_id" : 776546964657889280,
    "created_at" : "2016-09-15 22:25:09 +0000",
    "in_reply_to_screen_name" : "GoddessKerriLyn",
    "in_reply_to_user_id_str" : "2920759605",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796371792990498816\/4oJw3Ycf_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 776590587726274562,
  "created_at" : "2016-09-16 01:16:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHRONICALLY",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776590560983474176",
  "text" : "RT @GoddessKerriLyn: WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 4\n\u2705 u sleep too much\n\u2705 are u getting enough sleep?\n\u2705 my friend was cured\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CHRONICALLY",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776546370400518145",
    "geo" : { },
    "id_str" : "776546964657889280",
    "in_reply_to_user_id" : 2920759605,
    "text" : "WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 4\n\u2705 u sleep too much\n\u2705 are u getting enough sleep?\n\u2705 my friend was cured by..\n\u2705 Dr. Oz says..",
    "id" : 776546964657889280,
    "in_reply_to_status_id" : 776546370400518145,
    "created_at" : "2016-09-15 22:23:18 +0000",
    "in_reply_to_screen_name" : "GoddessKerriLyn",
    "in_reply_to_user_id_str" : "2920759605",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796371792990498816\/4oJw3Ycf_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 776590560983474176,
  "created_at" : "2016-09-16 01:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHRONICALLY",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776590464929652737",
  "text" : "RT @GoddessKerriLyn: WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 3\n\u2705 have u tried...\n\u2705 you need to get out more\n\u2705 it can't be that bad\n\u2705\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CHRONICALLY",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776545837501603845",
    "geo" : { },
    "id_str" : "776546370400518145",
    "in_reply_to_user_id" : 2920759605,
    "text" : "WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 3\n\u2705 have u tried...\n\u2705 you need to get out more\n\u2705 it can't be that bad\n\u2705 fake it till u make it",
    "id" : 776546370400518145,
    "in_reply_to_status_id" : 776545837501603845,
    "created_at" : "2016-09-15 22:20:56 +0000",
    "in_reply_to_screen_name" : "GoddessKerriLyn",
    "in_reply_to_user_id_str" : "2920759605",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796371792990498816\/4oJw3Ycf_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 776590464929652737,
  "created_at" : "2016-09-16 01:16:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHRONICALLY",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776590382050185216",
  "text" : "RT @GoddessKerriLyn: WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 2\n\u2705 you're just depressed\n\u2705 this too shall pass\n\u2705 cheer up, u need a mor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CHRONICALLY",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776545508479344640",
    "geo" : { },
    "id_str" : "776545837501603845",
    "in_reply_to_user_id" : 2920759605,
    "text" : "WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 2\n\u2705 you're just depressed\n\u2705 this too shall pass\n\u2705 cheer up, u need a more positive attitude",
    "id" : 776545837501603845,
    "in_reply_to_status_id" : 776545508479344640,
    "created_at" : "2016-09-15 22:18:49 +0000",
    "in_reply_to_screen_name" : "GoddessKerriLyn",
    "in_reply_to_user_id_str" : "2920759605",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796371792990498816\/4oJw3Ycf_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 776590382050185216,
  "created_at" : "2016-09-16 01:15:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "indices" : [ 3, 19 ],
      "id_str" : "2920759605",
      "id" : 2920759605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHRONICALLY",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776590362282434560",
  "text" : "RT @GoddessKerriLyn: WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 1\n\u2705 it must be nice not 2 go to work\n\u2705 I wish I had time 2 take a nap\n\u2705\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CHRONICALLY",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776544479323033601",
    "geo" : { },
    "id_str" : "776545508479344640",
    "in_reply_to_user_id" : 2920759605,
    "text" : "WHAT NOT TO SAY TO THE #CHRONICALLY ILL, part 1\n\u2705 it must be nice not 2 go to work\n\u2705 I wish I had time 2 take a nap\n\u2705 u just need 2 exercise",
    "id" : 776545508479344640,
    "in_reply_to_status_id" : 776544479323033601,
    "created_at" : "2016-09-15 22:17:31 +0000",
    "in_reply_to_screen_name" : "GoddessKerriLyn",
    "in_reply_to_user_id_str" : "2920759605",
    "user" : {
      "name" : "Kerri Lyn",
      "screen_name" : "GoddessKerriLyn",
      "protected" : false,
      "id_str" : "2920759605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796371792990498816\/4oJw3Ycf_normal.jpg",
      "id" : 2920759605,
      "verified" : false
    }
  },
  "id" : 776590362282434560,
  "created_at" : "2016-09-16 01:15:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVS",
      "indices" : [ 9, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776433967993982976",
  "text" : "while my #CVS dashboard is still buggy.. am grateful that I can sort RX diff ways, download, print. now have meds in my database! : )",
  "id" : 776433967993982976,
  "created_at" : "2016-09-15 14:54:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 83, 88 ]
    }, {
      "text" : "feedly",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/oMHOsYayzn",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/48b4ac15964e49\/76021?app_id=339",
      "display_url" : "producthunt.com\/r\/48b4ac15964e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776428759268352000",
  "text" : "Favorize \u2014 Highlight, share and discover bite-size content https:\/\/t.co\/oMHOsYayzn #tech #feedly",
  "id" : 776428759268352000,
  "created_at" : "2016-09-15 14:33:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rambeling",
      "screen_name" : "Rambeling",
      "indices" : [ 82, 92 ],
      "id_str" : "359618413",
      "id" : 359618413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/MpQk3C0yTv",
      "expanded_url" : "https:\/\/storify.com\/Rambeling\/knowledge",
      "display_url" : "storify.com\/Rambeling\/know\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776241353126735873",
  "text" : "A much needed history lesson on post-slavery America  https:\/\/t.co\/MpQk3C0yTv via @rambeling",
  "id" : 776241353126735873,
  "created_at" : "2016-09-15 02:08:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/muHpdeaij8",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/09\/13\/scientists-finally-catch-dolph.html",
      "display_url" : "boingboing.net\/2016\/09\/13\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776236508319719424",
  "text" : "RT @BoingBoing: Scientists have determined that dolphin speak to one another in sentences up to 5 words long https:\/\/t.co\/muHpdeaij8 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoingBoing\/status\/776122835177705472\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/fFVMUtg75B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsVXmqUWIAIWFZ9.jpg",
        "id_str" : "776122832497549314",
        "id" : 776122832497549314,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsVXmqUWIAIWFZ9.jpg",
        "sizes" : [ {
          "h" : 537,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 809,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 809,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 809,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/fFVMUtg75B"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/muHpdeaij8",
        "expanded_url" : "http:\/\/boingboing.net\/2016\/09\/13\/scientists-finally-catch-dolph.html",
        "display_url" : "boingboing.net\/2016\/09\/13\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776122835177705472",
    "text" : "Scientists have determined that dolphin speak to one another in sentences up to 5 words long https:\/\/t.co\/muHpdeaij8 https:\/\/t.co\/fFVMUtg75B",
    "id" : 776122835177705472,
    "created_at" : "2016-09-14 18:17:58 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 776236508319719424,
  "created_at" : "2016-09-15 01:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airtable",
      "screen_name" : "airtable",
      "indices" : [ 64, 73 ],
      "id_str" : "2786252385",
      "id" : 2786252385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/UpliYJrmsI",
      "expanded_url" : "https:\/\/airtable.news\/behind-the-scenes-of-language-rights-nonprofit-wikitongues-34400bf1451b#.7ha5m9phc",
      "display_url" : "airtable.news\/behind-the-sce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776131986448678917",
  "text" : "\u201CBehind the scenes of language rights nonprofit Wikitongues\u201D by @airtable https:\/\/t.co\/UpliYJrmsI",
  "id" : 776131986448678917,
  "created_at" : "2016-09-14 18:54:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airtable",
      "screen_name" : "airtable",
      "indices" : [ 46, 55 ],
      "id_str" : "2786252385",
      "id" : 2786252385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/hnsNzZloyC",
      "expanded_url" : "https:\/\/airtable.news\/a-catalog-of-every-language-in-the-world-ae1f78d3748f#.jdxu90fb9",
      "display_url" : "airtable.news\/a-catalog-of-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776131888423534592",
  "text" : "\u201CA catalog of every language in the world\u201D by @airtable https:\/\/t.co\/hnsNzZloyC",
  "id" : 776131888423534592,
  "created_at" : "2016-09-14 18:53:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoseMaryG #UniteBlue",
      "screen_name" : "nanaguerrax7",
      "indices" : [ 3, 16 ],
      "id_str" : "330319115",
      "id" : 330319115
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nanaguerrax7\/status\/776071689012596736\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/kqsmVTGKBh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsUpEoDUAAAY1hE.jpg",
      "id_str" : "776071670238806016",
      "id" : 776071670238806016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsUpEoDUAAAY1hE.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/kqsmVTGKBh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776089010175348736",
  "text" : "RT @nanaguerrax7: And no hearings or investigations or outrage!!! 22,000,000,000 https:\/\/t.co\/kqsmVTGKBh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nanaguerrax7\/status\/776071689012596736\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/kqsmVTGKBh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsUpEoDUAAAY1hE.jpg",
        "id_str" : "776071670238806016",
        "id" : 776071670238806016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsUpEoDUAAAY1hE.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/kqsmVTGKBh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776071689012596736",
    "text" : "And no hearings or investigations or outrage!!! 22,000,000,000 https:\/\/t.co\/kqsmVTGKBh",
    "id" : 776071689012596736,
    "created_at" : "2016-09-14 14:54:44 +0000",
    "user" : {
      "name" : "RoseMaryG #UniteBlue",
      "screen_name" : "nanaguerrax7",
      "protected" : false,
      "id_str" : "330319115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756831027025162241\/ZABLIvYU_normal.jpg",
      "id" : 330319115,
      "verified" : false
    }
  },
  "id" : 776089010175348736,
  "created_at" : "2016-09-14 16:03:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 66, 75 ]
    }, {
      "text" : "feedly",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/0U0mndn77Q",
      "expanded_url" : "http:\/\/tracking.feedpress.it\/link\/2905\/4403672",
      "display_url" : "tracking.feedpress.it\/link\/2905\/4403\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776069937710374913",
  "text" : "What if your life was rudely interrupted? https:\/\/t.co\/0U0mndn77Q #podcasts #feedly",
  "id" : 776069937710374913,
  "created_at" : "2016-09-14 14:47:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "indices" : [ 3, 16 ],
      "id_str" : "2423532173",
      "id" : 2423532173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/775767871049924608\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/CKSfLkoCeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQUr4xXgAEAekE.jpg",
      "id_str" : "775767780020944897",
      "id" : 775767780020944897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQUr4xXgAEAekE.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/CKSfLkoCeU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/775767871049924608\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/CKSfLkoCeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQUr47WcAAzgYi.jpg",
      "id_str" : "775767780062818304",
      "id" : 775767780062818304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQUr47WcAAzgYi.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/CKSfLkoCeU"
    } ],
    "hashtags" : [ {
      "text" : "morag",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "highlandcattle",
      "indices" : [ 40, 55 ]
    }, {
      "text" : "isleofiona",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775873260626014209",
  "text" : "RT @Maolfarmiona: #morag showing off!!! #highlandcattle #isleofiona https:\/\/t.co\/CKSfLkoCeU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/775767871049924608\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/CKSfLkoCeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQUr4xXgAEAekE.jpg",
        "id_str" : "775767780020944897",
        "id" : 775767780020944897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQUr4xXgAEAekE.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/CKSfLkoCeU"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/775767871049924608\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/CKSfLkoCeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQUr47WcAAzgYi.jpg",
        "id_str" : "775767780062818304",
        "id" : 775767780062818304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQUr47WcAAzgYi.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/CKSfLkoCeU"
      } ],
      "hashtags" : [ {
        "text" : "morag",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "highlandcattle",
        "indices" : [ 22, 37 ]
      }, {
        "text" : "isleofiona",
        "indices" : [ 38, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775767871049924608",
    "text" : "#morag showing off!!! #highlandcattle #isleofiona https:\/\/t.co\/CKSfLkoCeU",
    "id" : 775767871049924608,
    "created_at" : "2016-09-13 18:47:28 +0000",
    "user" : {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "protected" : false,
      "id_str" : "2423532173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798860009874472961\/v5GADWSz_normal.jpg",
      "id" : 2423532173,
      "verified" : false
    }
  },
  "id" : 775873260626014209,
  "created_at" : "2016-09-14 01:46:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775866654219759616",
  "text" : "showing hubby all the info ive organized in database. im tickled pink and hes like.. meh. gah.",
  "id" : 775866654219759616,
  "created_at" : "2016-09-14 01:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/FDPE6RsaTV",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/775833658615799808",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775837636007198720",
  "text" : "((fistbump)) https:\/\/t.co\/FDPE6RsaTV",
  "id" : 775837636007198720,
  "created_at" : "2016-09-13 23:24:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775828931203174400",
  "text" : "csv file editor! thats what I needed and I found one. woohoo!",
  "id" : 775828931203174400,
  "created_at" : "2016-09-13 22:50:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "LadyHaywire",
      "indices" : [ 3, 15 ],
      "id_str" : "2442345637",
      "id" : 2442345637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775823615631691776",
  "text" : "RT @LadyHaywire: Walk fields for 30mins searching for heifer. Find her standing on a ditch in a hedge, watching me looking for her.\uD83D\uDE14\uD83D\uDE14 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LadyHaywire\/status\/775738945405673472\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/BvgrsWUArk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsP6Pp-XEAALFL-.jpg",
        "id_str" : "775738707710251008",
        "id" : 775738707710251008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsP6Pp-XEAALFL-.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1229
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 408
        }, {
          "h" : 2560,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/BvgrsWUArk"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/LadyHaywire\/status\/775738945405673472\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/BvgrsWUArk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsP6RKCXgAARH1X.jpg",
        "id_str" : "775738733496860672",
        "id" : 775738733496860672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsP6RKCXgAARH1X.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1229
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 408
        }, {
          "h" : 2560,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/BvgrsWUArk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775738945405673472",
    "text" : "Walk fields for 30mins searching for heifer. Find her standing on a ditch in a hedge, watching me looking for her.\uD83D\uDE14\uD83D\uDE14 https:\/\/t.co\/BvgrsWUArk",
    "id" : 775738945405673472,
    "created_at" : "2016-09-13 16:52:31 +0000",
    "user" : {
      "name" : "Karen",
      "screen_name" : "LadyHaywire",
      "protected" : false,
      "id_str" : "2442345637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788305065085894656\/LNg8KWm6_normal.jpg",
      "id" : 2442345637,
      "verified" : false
    }
  },
  "id" : 775823615631691776,
  "created_at" : "2016-09-13 22:28:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775823511763976192",
  "text" : "i need something like mp3tag for csv files (so I can change things like names all in caps to regular case, etc) #tech",
  "id" : 775823511763976192,
  "created_at" : "2016-09-13 22:28:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/775811751665397760\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/mhNIXaMwcf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQ8p3bXYAARk7J.jpg",
      "id_str" : "775811725765599232",
      "id" : 775811725765599232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQ8p3bXYAARk7J.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/mhNIXaMwcf"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/775811751665397760\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/mhNIXaMwcf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQ8p3mWYAASnaU.jpg",
      "id_str" : "775811725811671040",
      "id" : 775811725811671040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQ8p3mWYAASnaU.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/mhNIXaMwcf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775822491570860032",
  "text" : "RT @ErinEFarley: Spooky horse! https:\/\/t.co\/mhNIXaMwcf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/775811751665397760\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/mhNIXaMwcf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQ8p3bXYAARk7J.jpg",
        "id_str" : "775811725765599232",
        "id" : 775811725765599232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQ8p3bXYAARk7J.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/mhNIXaMwcf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/775811751665397760\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/mhNIXaMwcf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQ8p3mWYAASnaU.jpg",
        "id_str" : "775811725811671040",
        "id" : 775811725811671040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQ8p3mWYAASnaU.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/mhNIXaMwcf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775811751665397760",
    "text" : "Spooky horse! https:\/\/t.co\/mhNIXaMwcf",
    "id" : 775811751665397760,
    "created_at" : "2016-09-13 21:41:50 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 775822491570860032,
  "created_at" : "2016-09-13 22:24:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/775811942271311872\/video\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/e4EiSjjzTn",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/775811895517450240\/pu\/img\/geyi2BONv3v7OJCK.jpg",
      "id_str" : "775811895517450240",
      "id" : 775811895517450240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/775811895517450240\/pu\/img\/geyi2BONv3v7OJCK.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/e4EiSjjzTn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775822439980888064",
  "text" : "RT @ErinEFarley: It's a heavy breather too. https:\/\/t.co\/e4EiSjjzTn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/775811942271311872\/video\/1",
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/e4EiSjjzTn",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/775811895517450240\/pu\/img\/geyi2BONv3v7OJCK.jpg",
        "id_str" : "775811895517450240",
        "id" : 775811895517450240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/775811895517450240\/pu\/img\/geyi2BONv3v7OJCK.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/e4EiSjjzTn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "775811751665397760",
    "geo" : { },
    "id_str" : "775811942271311872",
    "in_reply_to_user_id" : 1305052615,
    "text" : "It's a heavy breather too. https:\/\/t.co\/e4EiSjjzTn",
    "id" : 775811942271311872,
    "in_reply_to_status_id" : 775811751665397760,
    "created_at" : "2016-09-13 21:42:35 +0000",
    "in_reply_to_screen_name" : "ErinEFarley",
    "in_reply_to_user_id_str" : "1305052615",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 775822439980888064,
  "created_at" : "2016-09-13 22:24:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/775719187067043840\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/edLGrUjMbS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsPoex4WEAAZoj-.jpg",
      "id_str" : "775719176321241088",
      "id" : 775719176321241088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsPoex4WEAAZoj-.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/edLGrUjMbS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775719538298159105",
  "text" : "RT @Salmonae1: Blue Tit prefers the old bush,security. https:\/\/t.co\/edLGrUjMbS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/775719187067043840\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/edLGrUjMbS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsPoex4WEAAZoj-.jpg",
        "id_str" : "775719176321241088",
        "id" : 775719176321241088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsPoex4WEAAZoj-.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/edLGrUjMbS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775719187067043840",
    "text" : "Blue Tit prefers the old bush,security. https:\/\/t.co\/edLGrUjMbS",
    "id" : 775719187067043840,
    "created_at" : "2016-09-13 15:34:01 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 775719538298159105,
  "created_at" : "2016-09-13 15:35:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775719410665418752",
  "text" : "RT @CatskillCritter: This misty September morning in the Great Western #Catskills, so quiet after the songs of summer. https:\/\/t.co\/KwcCqYR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/775663860141395969\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/KwcCqYRbfg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsO2J7cXYAA76hJ.jpg",
        "id_str" : "775663842529599488",
        "id" : 775663842529599488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsO2J7cXYAA76hJ.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/KwcCqYRbfg"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775663860141395969",
    "text" : "This misty September morning in the Great Western #Catskills, so quiet after the songs of summer. https:\/\/t.co\/KwcCqYRbfg",
    "id" : 775663860141395969,
    "created_at" : "2016-09-13 11:54:10 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 775719410665418752,
  "created_at" : "2016-09-13 15:34:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "feedly",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/kmVFGBEGrI",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/keeping-drugs-illegal-just-makes-it-all-worse-its-time-to-think-differently\/",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775713281994612736",
  "text" : "Keeping Drugs Illegal Just Makes It All Worse\u2013 It\u2019s Time To Think Differently https:\/\/t.co\/kmVFGBEGrI #religion #feedly",
  "id" : 775713281994612736,
  "created_at" : "2016-09-13 15:10:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gay Civil Rights",
      "screen_name" : "gaycivilrights",
      "indices" : [ 3, 18 ],
      "id_str" : "18301196",
      "id" : 18301196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775708898695254016",
  "text" : "RT @gaycivilrights: 'I Hate the Hatred': 12 Year Old in Mexico Blocking Anti-Gay Protestors Is Compared to 'Tank Man' https:\/\/t.co\/zr0hIYFf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lgbt",
        "indices" : [ 122, 127 ]
      }, {
        "text" : "gay",
        "indices" : [ 128, 132 ]
      }, {
        "text" : "noh8",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/zr0hIYFfRR",
        "expanded_url" : "http:\/\/buff.ly\/2cJ1vy4",
        "display_url" : "buff.ly\/2cJ1vy4"
      } ]
    },
    "geo" : { },
    "id_str" : "775673891599548416",
    "text" : "'I Hate the Hatred': 12 Year Old in Mexico Blocking Anti-Gay Protestors Is Compared to 'Tank Man' https:\/\/t.co\/zr0hIYFfRR #lgbt #gay #noh8",
    "id" : 775673891599548416,
    "created_at" : "2016-09-13 12:34:01 +0000",
    "user" : {
      "name" : "Gay Civil Rights",
      "screen_name" : "gaycivilrights",
      "protected" : false,
      "id_str" : "18301196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655121304664698880\/yAMWNrHP_normal.jpg",
      "id" : 18301196,
      "verified" : false
    }
  },
  "id" : 775708898695254016,
  "created_at" : "2016-09-13 14:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/ypr38SxQMV",
      "expanded_url" : "https:\/\/twitter.com\/SopanDeb\/status\/775691980030484480",
      "display_url" : "twitter.com\/SopanDeb\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775708097851588608",
  "text" : "oopsie..lol https:\/\/t.co\/ypr38SxQMV",
  "id" : 775708097851588608,
  "created_at" : "2016-09-13 14:49:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buckeye Kenny",
      "screen_name" : "buckeyekenny",
      "indices" : [ 3, 16 ],
      "id_str" : "207819164",
      "id" : 207819164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Vg6Su4svH4",
      "expanded_url" : "http:\/\/www.androidauthority.com\/twitter-character-limit-stop-counting-multimedia-716112\/",
      "display_url" : "androidauthority.com\/twitter-charac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775706441013428224",
  "text" : "RT @buckeyekenny: Twitter\u2019s character limit will count words and words only starting next week | AndroidAuthority https:\/\/t.co\/Vg6Su4svH4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/Vg6Su4svH4",
        "expanded_url" : "http:\/\/www.androidauthority.com\/twitter-character-limit-stop-counting-multimedia-716112\/",
        "display_url" : "androidauthority.com\/twitter-charac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775678592449646593",
    "text" : "Twitter\u2019s character limit will count words and words only starting next week | AndroidAuthority https:\/\/t.co\/Vg6Su4svH4",
    "id" : 775678592449646593,
    "created_at" : "2016-09-13 12:52:42 +0000",
    "user" : {
      "name" : "Buckeye Kenny",
      "screen_name" : "buckeyekenny",
      "protected" : false,
      "id_str" : "207819164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797107254893875200\/xD5Rlj16_normal.jpg",
      "id" : 207819164,
      "verified" : false
    }
  },
  "id" : 775706441013428224,
  "created_at" : "2016-09-13 14:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "indices" : [ 3, 12 ],
      "id_str" : "14437914",
      "id" : 14437914
    }, {
      "name" : "STAT",
      "screen_name" : "statnews",
      "indices" : [ 87, 96 ],
      "id_str" : "3290364847",
      "id" : 3290364847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/74gIN0OiWw",
      "expanded_url" : "http:\/\/to.pbs.org\/2cT3GDI",
      "display_url" : "to.pbs.org\/2cT3GDI"
    } ]
  },
  "geo" : { },
  "id_str" : "775705975399546880",
  "text" : "RT @NewsHour: \"Science is not supposed to work this way.\" https:\/\/t.co\/74gIN0OiWw (via @statnews)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "STAT",
        "screen_name" : "statnews",
        "indices" : [ 73, 82 ],
        "id_str" : "3290364847",
        "id" : 3290364847
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/74gIN0OiWw",
        "expanded_url" : "http:\/\/to.pbs.org\/2cT3GDI",
        "display_url" : "to.pbs.org\/2cT3GDI"
      } ]
    },
    "geo" : { },
    "id_str" : "775686176007127040",
    "text" : "\"Science is not supposed to work this way.\" https:\/\/t.co\/74gIN0OiWw (via @statnews)",
    "id" : 775686176007127040,
    "created_at" : "2016-09-13 13:22:50 +0000",
    "user" : {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "protected" : false,
      "id_str" : "14437914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800880685657559040\/4ndD7fwW_normal.jpg",
      "id" : 14437914,
      "verified" : true
    }
  },
  "id" : 775705975399546880,
  "created_at" : "2016-09-13 14:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "LadyHaywire",
      "indices" : [ 3, 15 ],
      "id_str" : "2442345637",
      "id" : 2442345637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775705894319493120",
  "text" : "RT @LadyHaywire: Panda ate blackberries and now has a scour. Don't be like Panda, don't eat 5kg of fruit and shit all over the place. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LadyHaywire\/status\/775645274710630400\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/OPyY6QVl02",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsOlO5PWgAAPDZo.jpg",
        "id_str" : "775645236139819008",
        "id" : 775645236139819008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsOlO5PWgAAPDZo.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 408
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 614
        } ],
        "display_url" : "pic.twitter.com\/OPyY6QVl02"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775645274710630400",
    "text" : "Panda ate blackberries and now has a scour. Don't be like Panda, don't eat 5kg of fruit and shit all over the place. https:\/\/t.co\/OPyY6QVl02",
    "id" : 775645274710630400,
    "created_at" : "2016-09-13 10:40:18 +0000",
    "user" : {
      "name" : "Karen",
      "screen_name" : "LadyHaywire",
      "protected" : false,
      "id_str" : "2442345637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788305065085894656\/LNg8KWm6_normal.jpg",
      "id" : 2442345637,
      "verified" : false
    }
  },
  "id" : 775705894319493120,
  "created_at" : "2016-09-13 14:41:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775474627992756224",
  "geo" : { },
  "id_str" : "775483999535890432",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe or break a leg!! eek!!",
  "id" : 775483999535890432,
  "in_reply_to_status_id" : 775474627992756224,
  "created_at" : "2016-09-12 23:59:27 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775468274104594434",
  "geo" : { },
  "id_str" : "775471531342303232",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe Ouch!! ((hugs))",
  "id" : 775471531342303232,
  "in_reply_to_status_id" : 775468274104594434,
  "created_at" : "2016-09-12 23:09:55 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "feedly",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/CbdSlkCBwE",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/andygill\/on-lynching-colin-kaepernick\/",
      "display_url" : "patheos.com\/blogs\/andygill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775390265641201664",
  "text" : "On Lynching Colin Kaepernick https:\/\/t.co\/CbdSlkCBwE #religion #feedly",
  "id" : 775390265641201664,
  "created_at" : "2016-09-12 17:47:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#000000 \uD83C\uDDF5\uD83C\uDDE6",
      "screen_name" : "audacityofDOPE_",
      "indices" : [ 3, 19 ],
      "id_str" : "25889870",
      "id" : 25889870
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/audacityofDOPE_\/status\/775348177922908200\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ArF7EjNusn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKXDcdXEAASPHp.jpg",
      "id_str" : "775348171295887360",
      "id" : 775348171295887360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKXDcdXEAASPHp.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 763
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 763
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 763
      } ],
      "display_url" : "pic.twitter.com\/ArF7EjNusn"
    } ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775385861768802304",
  "text" : "RT @audacityofDOPE_: Billie Joe Armstrong of Green Day had this to say on #BlackLivesMatter. https:\/\/t.co\/ArF7EjNusn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/audacityofDOPE_\/status\/775348177922908200\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/ArF7EjNusn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKXDcdXEAASPHp.jpg",
        "id_str" : "775348171295887360",
        "id" : 775348171295887360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKXDcdXEAASPHp.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 763
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 763
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 763
        } ],
        "display_url" : "pic.twitter.com\/ArF7EjNusn"
      } ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 53, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775348177922908200",
    "text" : "Billie Joe Armstrong of Green Day had this to say on #BlackLivesMatter. https:\/\/t.co\/ArF7EjNusn",
    "id" : 775348177922908200,
    "created_at" : "2016-09-12 14:59:45 +0000",
    "user" : {
      "name" : "#000000 \uD83C\uDDF5\uD83C\uDDE6",
      "screen_name" : "audacityofDOPE_",
      "protected" : false,
      "id_str" : "25889870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798940231357566976\/BOBo0UUI_normal.jpg",
      "id" : 25889870,
      "verified" : false
    }
  },
  "id" : 775385861768802304,
  "created_at" : "2016-09-12 17:29:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetIndie",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/zPr9tmd9r1",
      "expanded_url" : "http:\/\/www.shelf-awareness.com\/theshelf\/2016-09-12\/author_bookseller_amy_stewart_s_litsy_campaign:_getindie.html",
      "display_url" : "shelf-awareness.com\/theshelf\/2016-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775347412495925248",
  "text" : "Author\/Bookseller Amy Stewart's Litsy Campaign: #GetIndie https:\/\/t.co\/zPr9tmd9r1",
  "id" : 775347412495925248,
  "created_at" : "2016-09-12 14:56:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Kerslake",
      "screen_name" : "wkerslake",
      "indices" : [ 3, 13 ],
      "id_str" : "57477810",
      "id" : 57477810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775152250364760064",
  "text" : "RT @wkerslake: There are twelve black dots at the intersections in this image. Your brain won\u2019t let you see them all at once. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wkerslake\/status\/775105333333204992\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/ig6P980LOT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsG6MSpWAAAdTob.jpg",
        "id_str" : "775105331210878976",
        "id" : 775105331210878976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsG6MSpWAAAdTob.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 972
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 972
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 972
        } ],
        "display_url" : "pic.twitter.com\/ig6P980LOT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775105333333204992",
    "text" : "There are twelve black dots at the intersections in this image. Your brain won\u2019t let you see them all at once. https:\/\/t.co\/ig6P980LOT",
    "id" : 775105333333204992,
    "created_at" : "2016-09-11 22:54:46 +0000",
    "user" : {
      "name" : "Will Kerslake",
      "screen_name" : "wkerslake",
      "protected" : false,
      "id_str" : "57477810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772585982038315008\/NbuxOJvg_normal.jpg",
      "id" : 57477810,
      "verified" : false
    }
  },
  "id" : 775152250364760064,
  "created_at" : "2016-09-12 02:01:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Face Thorpe",
      "screen_name" : "Arr",
      "indices" : [ 3, 7 ],
      "id_str" : "14166235",
      "id" : 14166235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775151998068985857",
  "text" : "RT @Arr: The reason cats are so pissy is they're God's perfect killing machines but they only weigh 8lbs and we keep picking them up and ki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774855950070972417",
    "text" : "The reason cats are so pissy is they're God's perfect killing machines but they only weigh 8lbs and we keep picking them up and kissing them",
    "id" : 774855950070972417,
    "created_at" : "2016-09-11 06:23:49 +0000",
    "user" : {
      "name" : "Face Thorpe",
      "screen_name" : "Arr",
      "protected" : false,
      "id_str" : "14166235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678637367477997568\/A1BzSV-t_normal.jpg",
      "id" : 14166235,
      "verified" : false
    }
  },
  "id" : 775151998068985857,
  "created_at" : "2016-09-12 02:00:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imafreak",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775138220627652608",
  "text" : "I like disco. and when I hear it.. I dance. #imafreak",
  "id" : 775138220627652608,
  "created_at" : "2016-09-12 01:05:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775137342990458880",
  "text" : "when you wake up one day and realize you arent the person you thought.. you got nothing to lose...",
  "id" : 775137342990458880,
  "created_at" : "2016-09-12 01:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/PvGtRl38He",
      "expanded_url" : "https:\/\/twitter.com\/HomunculusLoikm\/status\/775136170737037314",
      "display_url" : "twitter.com\/HomunculusLoik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775136941872451584",
  "text" : "a drug problem? hidden for years? https:\/\/t.co\/PvGtRl38He",
  "id" : 775136941872451584,
  "created_at" : "2016-09-12 01:00:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775131216014106624",
  "geo" : { },
  "id_str" : "775134334965653504",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe have ppl pay for the shipping? but you'd have to make a list then.",
  "id" : 775134334965653504,
  "in_reply_to_status_id" : 775131216014106624,
  "created_at" : "2016-09-12 00:50:01 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775107959386808320",
  "geo" : { },
  "id_str" : "775124813321015296",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater jeeeez...",
  "id" : 775124813321015296,
  "in_reply_to_status_id" : 775107959386808320,
  "created_at" : "2016-09-12 00:12:11 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Emmerson",
      "screen_name" : "IAmJeffEmmerson",
      "indices" : [ 3, 19 ],
      "id_str" : "1262776610",
      "id" : 1262776610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775057805011218432",
  "text" : "RT @IAmJeffEmmerson: Remember to be gentle on yourself. It took me nearly 40 years to get that through my head. What a huge difference self\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774765401196597248",
    "text" : "Remember to be gentle on yourself. It took me nearly 40 years to get that through my head. What a huge difference self-compassion makes!",
    "id" : 774765401196597248,
    "created_at" : "2016-09-11 00:24:00 +0000",
    "user" : {
      "name" : "Jeff Emmerson",
      "screen_name" : "IAmJeffEmmerson",
      "protected" : false,
      "id_str" : "1262776610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738461431901782017\/mKjEnk8b_normal.jpg",
      "id" : 1262776610,
      "verified" : true
    }
  },
  "id" : 775057805011218432,
  "created_at" : "2016-09-11 19:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcast",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774995428676886528",
  "text" : "im confused about ppl putting podcasts on youtube. cant add them to #podcast players.",
  "id" : 774995428676886528,
  "created_at" : "2016-09-11 15:38:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Y5r7wcbsdo",
      "expanded_url" : "https:\/\/twitter.com\/AudiotainmntNws\/status\/774989764990799873",
      "display_url" : "twitter.com\/AudiotainmntNw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774994076735303681",
  "text" : "started this series last night. have to download the rest! #mystery https:\/\/t.co\/Y5r7wcbsdo",
  "id" : 774994076735303681,
  "created_at" : "2016-09-11 15:32:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Wilson",
      "screen_name" : "TheRickWilson",
      "indices" : [ 3, 17 ],
      "id_str" : "19084896",
      "id" : 19084896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/keqUXqBK31",
      "expanded_url" : "http:\/\/bit.ly\/1S93xXm",
      "display_url" : "bit.ly\/1S93xXm"
    } ]
  },
  "geo" : { },
  "id_str" : "774987793869205505",
  "text" : "RT @TheRickWilson: Donald.\nTrump.\nStole.\n9\/11.\nRecovery.\nMoney.\n\nhttps:\/\/t.co\/keqUXqBK31",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/keqUXqBK31",
        "expanded_url" : "http:\/\/bit.ly\/1S93xXm",
        "display_url" : "bit.ly\/1S93xXm"
      } ]
    },
    "geo" : { },
    "id_str" : "720088623924781056",
    "text" : "Donald.\nTrump.\nStole.\n9\/11.\nRecovery.\nMoney.\n\nhttps:\/\/t.co\/keqUXqBK31",
    "id" : 720088623924781056,
    "created_at" : "2016-04-13 03:18:01 +0000",
    "user" : {
      "name" : "Rick Wilson",
      "screen_name" : "TheRickWilson",
      "protected" : false,
      "id_str" : "19084896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765312046090952705\/-Bb4dFJp_normal.jpg",
      "id" : 19084896,
      "verified" : true
    }
  },
  "id" : 774987793869205505,
  "created_at" : "2016-09-11 15:07:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "software",
      "indices" : [ 7, 16 ]
    }, {
      "text" : "contactmanager",
      "indices" : [ 68, 83 ]
    }, {
      "text" : "tech",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774985018657673216",
  "text" : "i need #software to track drs and dates. any ideas? like a personal #contactmanager so i can print lists of drs, dates. #tech",
  "id" : 774985018657673216,
  "created_at" : "2016-09-11 14:56:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "#CalExit JamesonNeat",
      "screen_name" : "MrJamesonNeat",
      "indices" : [ 11, 25 ],
      "id_str" : "108288348",
      "id" : 108288348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774816280104742912",
  "geo" : { },
  "id_str" : "774983452668157982",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time @MrJamesonNeat  i knew about dating daughter part but not the \"just the tip\" .. did he really say that???",
  "id" : 774983452668157982,
  "in_reply_to_status_id" : 774816280104742912,
  "created_at" : "2016-09-11 14:50:28 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raw Story",
      "screen_name" : "RawStory",
      "indices" : [ 3, 12 ],
      "id_str" : "16041234",
      "id" : 16041234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/xKyqqlCYHb",
      "expanded_url" : "http:\/\/ow.ly\/7MIP3045PXM",
      "display_url" : "ow.ly\/7MIP3045PXM"
    } ]
  },
  "geo" : { },
  "id_str" : "774981679165300737",
  "text" : "RT @RawStory: Hours after Twin Towers fell, Trump bragged his bldg was now the tallest in lower Manhattan https:\/\/t.co\/xKyqqlCYHb https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RawStory\/status\/774822297781825541\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fVPdIjLga7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsC4xdLWAAAXbj9.jpg",
        "id_str" : "774822295693033472",
        "id" : 774822295693033472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsC4xdLWAAAXbj9.jpg",
        "sizes" : [ {
          "h" : 366,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/fVPdIjLga7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/xKyqqlCYHb",
        "expanded_url" : "http:\/\/ow.ly\/7MIP3045PXM",
        "display_url" : "ow.ly\/7MIP3045PXM"
      } ]
    },
    "geo" : { },
    "id_str" : "774822297781825541",
    "text" : "Hours after Twin Towers fell, Trump bragged his bldg was now the tallest in lower Manhattan https:\/\/t.co\/xKyqqlCYHb https:\/\/t.co\/fVPdIjLga7",
    "id" : 774822297781825541,
    "created_at" : "2016-09-11 04:10:05 +0000",
    "user" : {
      "name" : "Raw Story",
      "screen_name" : "RawStory",
      "protected" : false,
      "id_str" : "16041234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511012709270183936\/wEVYV7Lf_normal.png",
      "id" : 16041234,
      "verified" : true
    }
  },
  "id" : 774981679165300737,
  "created_at" : "2016-09-11 14:43:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Eichenwald",
      "screen_name" : "kurteichenwald",
      "indices" : [ 3, 18 ],
      "id_str" : "215207998",
      "id" : 215207998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774980705705164800",
  "text" : "RT @kurteichenwald: stunning story. Trump laundered others peoples' charitable contributions to make it look like they were from him https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/FS04GBp8Xt",
        "expanded_url" : "https:\/\/twitter.com\/Taniel\/status\/774783687024111616",
        "display_url" : "twitter.com\/Taniel\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774829518947094528",
    "text" : "stunning story. Trump laundered others peoples' charitable contributions to make it look like they were from him https:\/\/t.co\/FS04GBp8Xt",
    "id" : 774829518947094528,
    "created_at" : "2016-09-11 04:38:47 +0000",
    "user" : {
      "name" : "Kurt Eichenwald",
      "screen_name" : "kurteichenwald",
      "protected" : false,
      "id_str" : "215207998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2193807582\/IMG_0038b_normal.jpg",
      "id" : 215207998,
      "verified" : true
    }
  },
  "id" : 774980705705164800,
  "created_at" : "2016-09-11 14:39:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Harvey",
      "screen_name" : "mrnickharvey",
      "indices" : [ 3, 16 ],
      "id_str" : "19347791",
      "id" : 19347791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mrnickharvey\/status\/714447211376025601\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/EMJx8hcIgB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ceo58sIW8AAUUn8.jpg",
      "id_str" : "714447205692796928",
      "id" : 714447205692796928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ceo58sIW8AAUUn8.jpg",
      "sizes" : [ {
        "h" : 443,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/EMJx8hcIgB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774980667268538368",
  "text" : "RT @mrnickharvey: I don't think I'll ever tire of this hastily deleted tweet from a few years ago. https:\/\/t.co\/EMJx8hcIgB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mrnickharvey\/status\/714447211376025601\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/EMJx8hcIgB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ceo58sIW8AAUUn8.jpg",
        "id_str" : "714447205692796928",
        "id" : 714447205692796928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ceo58sIW8AAUUn8.jpg",
        "sizes" : [ {
          "h" : 443,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/EMJx8hcIgB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714447211376025601",
    "text" : "I don't think I'll ever tire of this hastily deleted tweet from a few years ago. https:\/\/t.co\/EMJx8hcIgB",
    "id" : 714447211376025601,
    "created_at" : "2016-03-28 13:41:03 +0000",
    "user" : {
      "name" : "Nick Harvey",
      "screen_name" : "mrnickharvey",
      "protected" : false,
      "id_str" : "19347791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778657701077348353\/OiNS7TiB_normal.jpg",
      "id" : 19347791,
      "verified" : false
    }
  },
  "id" : 774980667268538368,
  "created_at" : "2016-09-11 14:39:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/774834961501356032\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/wmnaoC5JAS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsDESe7WYAAR6n1.jpg",
      "id_str" : "774834957726408704",
      "id" : 774834957726408704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsDESe7WYAAR6n1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 377
      } ],
      "display_url" : "pic.twitter.com\/wmnaoC5JAS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774979821512318977",
  "text" : "RT @SouthYeoEast: That's better. Fiona Mae showing off her fantastic fluffy Galloway ears https:\/\/t.co\/wmnaoC5JAS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/774834961501356032\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/wmnaoC5JAS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsDESe7WYAAR6n1.jpg",
        "id_str" : "774834957726408704",
        "id" : 774834957726408704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsDESe7WYAAR6n1.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 377
        } ],
        "display_url" : "pic.twitter.com\/wmnaoC5JAS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774834961501356032",
    "text" : "That's better. Fiona Mae showing off her fantastic fluffy Galloway ears https:\/\/t.co\/wmnaoC5JAS",
    "id" : 774834961501356032,
    "created_at" : "2016-09-11 05:00:25 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 774979821512318977,
  "created_at" : "2016-09-11 14:36:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    }, {
      "name" : "OldCrank",
      "screen_name" : "OldCrank",
      "indices" : [ 5, 14 ],
      "id_str" : "17613554",
      "id" : 17613554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774711784691216384",
  "geo" : { },
  "id_str" : "774741977271263235",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 @OldCrank : ((",
  "id" : 774741977271263235,
  "in_reply_to_status_id" : 774711784691216384,
  "created_at" : "2016-09-10 22:50:56 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Food",
      "screen_name" : "about_Jehovah",
      "indices" : [ 3, 17 ],
      "id_str" : "3105362665",
      "id" : 3105362665
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/about_Jehovah\/status\/713110890032148480\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/fipuMvjnsU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeV6k2YVAAAIVXO.jpg",
      "id_str" : "713110889499525120",
      "id" : 713110889499525120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeV6k2YVAAAIVXO.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fipuMvjnsU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774741651080220673",
  "text" : "RT @about_Jehovah: \u201CLet us consider one another to incite to love and fine works.\u201D\u2014HEB. 10:24. https:\/\/t.co\/fipuMvjnsU ,'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmoney.com\" rel=\"nofollow\"\u003ETweet Money\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/about_Jehovah\/status\/713110890032148480\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/fipuMvjnsU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeV6k2YVAAAIVXO.jpg",
        "id_str" : "713110889499525120",
        "id" : 713110889499525120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeV6k2YVAAAIVXO.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fipuMvjnsU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774707829408079872",
    "text" : "\u201CLet us consider one another to incite to love and fine works.\u201D\u2014HEB. 10:24. https:\/\/t.co\/fipuMvjnsU ,'",
    "id" : 774707829408079872,
    "created_at" : "2016-09-10 20:35:14 +0000",
    "user" : {
      "name" : "Spiritual Food",
      "screen_name" : "about_Jehovah",
      "protected" : false,
      "id_str" : "3105362665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580149281073459200\/FpyqwhxZ_normal.jpg",
      "id" : 3105362665,
      "verified" : false
    }
  },
  "id" : 774741651080220673,
  "created_at" : "2016-09-10 22:49:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774723945421561856",
  "geo" : { },
  "id_str" : "774741549192273920",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides ((digging my claws into summer))",
  "id" : 774741549192273920,
  "in_reply_to_status_id" : 774723945421561856,
  "created_at" : "2016-09-10 22:49:13 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bedard",
      "screen_name" : "gbedard1",
      "indices" : [ 0, 9 ],
      "id_str" : "41740651",
      "id" : 41740651
    }, {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 10, 26 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774729614543454208",
  "geo" : { },
  "id_str" : "774741340928245760",
  "in_reply_to_user_id" : 41740651,
  "text" : "@gbedard1 @aliceinthewater this so messes up my aura. makes me want to cry.",
  "id" : 774741340928245760,
  "in_reply_to_status_id" : 774729614543454208,
  "created_at" : "2016-09-10 22:48:24 +0000",
  "in_reply_to_screen_name" : "gbedard1",
  "in_reply_to_user_id_str" : "41740651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivestockCity, Inc.",
      "screen_name" : "livestockcity",
      "indices" : [ 3, 17 ],
      "id_str" : "705569966",
      "id" : 705569966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldSuicidePreventionDay",
      "indices" : [ 84, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774739174637314048",
  "text" : "RT @livestockcity: Be kind to people. The impact of your words can last a lifetime. #WorldSuicidePreventionDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldSuicidePreventionDay",
        "indices" : [ 65, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774611204388032513",
    "text" : "Be kind to people. The impact of your words can last a lifetime. #WorldSuicidePreventionDay",
    "id" : 774611204388032513,
    "created_at" : "2016-09-10 14:11:17 +0000",
    "user" : {
      "name" : "LivestockCity, Inc.",
      "screen_name" : "livestockcity",
      "protected" : false,
      "id_str" : "705569966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734935607273721856\/M7bhvzAF_normal.jpg",
      "id" : 705569966,
      "verified" : false
    }
  },
  "id" : 774739174637314048,
  "created_at" : "2016-09-10 22:39:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702845480304640",
  "text" : "hmm.. not sure if its kidneys or back that is sore...",
  "id" : 774702845480304640,
  "created_at" : "2016-09-10 20:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "indices" : [ 0, 16 ],
      "id_str" : "4218819269",
      "id" : 4218819269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774644414459371520",
  "geo" : { },
  "id_str" : "774645795685560320",
  "in_reply_to_user_id" : 93747129,
  "text" : "@AnAudiobookworm found you.. it finally came up.",
  "id" : 774645795685560320,
  "in_reply_to_status_id" : 774644414459371520,
  "created_at" : "2016-09-10 16:28:44 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "indices" : [ 0, 16 ],
      "id_str" : "4218819269",
      "id" : 4218819269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774638898567716864",
  "geo" : { },
  "id_str" : "774644414459371520",
  "in_reply_to_user_id" : 4218819269,
  "text" : "@AnAudiobookworm having trouble finding you.. whats your name there?",
  "id" : 774644414459371520,
  "in_reply_to_status_id" : 774638898567716864,
  "created_at" : "2016-09-10 16:23:15 +0000",
  "in_reply_to_screen_name" : "AnAudiobookworm",
  "in_reply_to_user_id_str" : "4218819269",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774638404617199616",
  "geo" : { },
  "id_str" : "774642331161128962",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater pure breeds?? well, then...",
  "id" : 774642331161128962,
  "in_reply_to_status_id" : 774638404617199616,
  "created_at" : "2016-09-10 16:14:58 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Audiobookworm \uD83C\uDFA7",
      "screen_name" : "AnAudiobookworm",
      "indices" : [ 0, 16 ],
      "id_str" : "4218819269",
      "id" : 4218819269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774446957422972931",
  "geo" : { },
  "id_str" : "774638566093750272",
  "in_reply_to_user_id" : 4218819269,
  "text" : "@AnAudiobookworm now following. are you on Litsy?",
  "id" : 774638566093750272,
  "in_reply_to_status_id" : 774446957422972931,
  "created_at" : "2016-09-10 16:00:00 +0000",
  "in_reply_to_screen_name" : "AnAudiobookworm",
  "in_reply_to_user_id_str" : "4218819269",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris & Karen Rohan",
      "screen_name" : "GAPlayingGods",
      "indices" : [ 3, 17 ],
      "id_str" : "4419101189",
      "id" : 4419101189
    }, {
      "name" : "GraphicAudio",
      "screen_name" : "GraphicAudio",
      "indices" : [ 39, 52 ],
      "id_str" : "23590245",
      "id" : 23590245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774637469732134912",
  "text" : "RT @GAPlayingGods: Got a surprise from @GraphicAudio today. It's hanging in our living room now, and it's pretty damn cool. https:\/\/t.co\/pQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GraphicAudio",
        "screen_name" : "GraphicAudio",
        "indices" : [ 20, 33 ],
        "id_str" : "23590245",
        "id" : 23590245
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GAPlayingGods\/status\/774452389571100672\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/pQDbvfw0kk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr9oVSwWgAAtTrx.jpg",
        "id_str" : "774452375952195584",
        "id" : 774452375952195584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr9oVSwWgAAtTrx.jpg",
        "sizes" : [ {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1150,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1150,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/pQDbvfw0kk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774452389571100672",
    "text" : "Got a surprise from @GraphicAudio today. It's hanging in our living room now, and it's pretty damn cool. https:\/\/t.co\/pQDbvfw0kk",
    "id" : 774452389571100672,
    "created_at" : "2016-09-10 03:40:12 +0000",
    "user" : {
      "name" : "Chris & Karen Rohan",
      "screen_name" : "GAPlayingGods",
      "protected" : false,
      "id_str" : "4419101189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674322604300353536\/h4OwxqXb_normal.png",
      "id" : 4419101189,
      "verified" : false
    }
  },
  "id" : 774637469732134912,
  "created_at" : "2016-09-10 15:55:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Shaw",
      "screen_name" : "NewCenturyShaw",
      "indices" : [ 3, 18 ],
      "id_str" : "240279242",
      "id" : 240279242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/9p547FQSP1",
      "expanded_url" : "http:\/\/newcenturyshow.podbean.com\/category\/arlington\/",
      "display_url" : "newcenturyshow.podbean.com\/category\/arlin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774412096549298176",
  "text" : "RT @NewCenturyShaw: For a few short weeks New Century: Arlington is freely available to download in 6 parts\n\nhttps:\/\/t.co\/9p547FQSP1 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NewCenturyShaw\/status\/774383134674653184\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/T43pesW449",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr8pFL1W8AAr4nu.jpg",
        "id_str" : "774382829983690752",
        "id" : 774382829983690752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr8pFL1W8AAr4nu.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 1400
        } ],
        "display_url" : "pic.twitter.com\/T43pesW449"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/9p547FQSP1",
        "expanded_url" : "http:\/\/newcenturyshow.podbean.com\/category\/arlington\/",
        "display_url" : "newcenturyshow.podbean.com\/category\/arlin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774383134674653184",
    "text" : "For a few short weeks New Century: Arlington is freely available to download in 6 parts\n\nhttps:\/\/t.co\/9p547FQSP1 https:\/\/t.co\/T43pesW449",
    "id" : 774383134674653184,
    "created_at" : "2016-09-09 23:05:01 +0000",
    "user" : {
      "name" : "Alexander Shaw",
      "screen_name" : "NewCenturyShaw",
      "protected" : false,
      "id_str" : "240279242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783966322506010624\/1zRbYE_S_normal.jpg",
      "id" : 240279242,
      "verified" : false
    }
  },
  "id" : 774412096549298176,
  "created_at" : "2016-09-10 01:00:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Little",
      "screen_name" : "Azuretalon",
      "indices" : [ 3, 14 ],
      "id_str" : "783194408",
      "id" : 783194408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Antarcticshadowvane",
      "indices" : [ 111, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774409892962635776",
  "text" : "RT @Azuretalon: All Antarctic ice melts. Turns out it was a plug. All Earth's water drains off out into space. #Antarcticshadowvane",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Antarcticshadowvane",
        "indices" : [ 95, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774288821471027200",
    "text" : "All Antarctic ice melts. Turns out it was a plug. All Earth's water drains off out into space. #Antarcticshadowvane",
    "id" : 774288821471027200,
    "created_at" : "2016-09-09 16:50:15 +0000",
    "user" : {
      "name" : "Bill Little",
      "screen_name" : "Azuretalon",
      "protected" : false,
      "id_str" : "783194408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708302453482102784\/AIddknHP_normal.jpg",
      "id" : 783194408,
      "verified" : false
    }
  },
  "id" : 774409892962635776,
  "created_at" : "2016-09-10 00:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Mxiwfh6LBV",
      "expanded_url" : "http:\/\/wp.me\/p7ka6l-3mv?utm_campaign=coschedule&utm_source=twitter&utm_medium=johnpavlovitz",
      "display_url" : "wp.me\/p7ka6l-3mv?utm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774409551252692996",
  "text" : "RT @johnpavlovitz: We're All Trying Really Hard Here. Go Easy. https:\/\/t.co\/Mxiwfh6LBV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/Mxiwfh6LBV",
        "expanded_url" : "http:\/\/wp.me\/p7ka6l-3mv?utm_campaign=coschedule&utm_source=twitter&utm_medium=johnpavlovitz",
        "display_url" : "wp.me\/p7ka6l-3mv?utm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774408305900941312",
    "text" : "We're All Trying Really Hard Here. Go Easy. https:\/\/t.co\/Mxiwfh6LBV",
    "id" : 774408305900941312,
    "created_at" : "2016-09-10 00:45:02 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 774409551252692996,
  "created_at" : "2016-09-10 00:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blogs of War",
      "screen_name" : "BlogsofWar",
      "indices" : [ 3, 14 ],
      "id_str" : "14401607",
      "id" : 14401607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774408758126637057",
  "text" : "RT @BlogsofWar: \"I'm stockpiling guns and ammo because Obama is a dictator. Oh, by the way, that Vladimir Putin is something else isn't he?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774402561910669312",
    "text" : "\"I'm stockpiling guns and ammo because Obama is a dictator. Oh, by the way, that Vladimir Putin is something else isn't he? Strong leader!\"",
    "id" : 774402561910669312,
    "created_at" : "2016-09-10 00:22:13 +0000",
    "user" : {
      "name" : "Blogs of War",
      "screen_name" : "BlogsofWar",
      "protected" : false,
      "id_str" : "14401607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639608474280685568\/h9ByS9ZU_normal.jpg",
      "id" : 14401607,
      "verified" : false
    }
  },
  "id" : 774408758126637057,
  "created_at" : "2016-09-10 00:46:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774407402175229953",
  "text" : "RT @AP: Health officials are trying to figure out what caused dozens of birds to fall out of the sky onto a Boston street. https:\/\/t.co\/Zwe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ZweFQtrpco",
        "expanded_url" : "http:\/\/apne.ws\/2cq6RCb",
        "display_url" : "apne.ws\/2cq6RCb"
      } ]
    },
    "geo" : { },
    "id_str" : "774404780189949952",
    "text" : "Health officials are trying to figure out what caused dozens of birds to fall out of the sky onto a Boston street. https:\/\/t.co\/ZweFQtrpco",
    "id" : 774404780189949952,
    "created_at" : "2016-09-10 00:31:01 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 774407402175229953,
  "created_at" : "2016-09-10 00:41:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul The Book Guy",
      "screen_name" : "PaulTheBookGuy",
      "indices" : [ 3, 18 ],
      "id_str" : "18302779",
      "id" : 18302779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/j39svjIiU4",
      "expanded_url" : "http:\/\/e360.yale.edu\/digest\/insecticide_neonicotinoids_queen_bee_eggs\/4801\/",
      "display_url" : "e360.yale.edu\/digest\/insecti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774405173624070144",
  "text" : "RT @PaulTheBookGuy: Remember when Roundup Insecticide being harmful was a conspiracy theory?  https:\/\/t.co\/j39svjIiU4  Now we know why all\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/j39svjIiU4",
        "expanded_url" : "http:\/\/e360.yale.edu\/digest\/insecticide_neonicotinoids_queen_bee_eggs\/4801\/",
        "display_url" : "e360.yale.edu\/digest\/insecti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774404111479570436",
    "text" : "Remember when Roundup Insecticide being harmful was a conspiracy theory?  https:\/\/t.co\/j39svjIiU4  Now we know why all the bees died.",
    "id" : 774404111479570436,
    "created_at" : "2016-09-10 00:28:22 +0000",
    "user" : {
      "name" : "Paul The Book Guy",
      "screen_name" : "PaulTheBookGuy",
      "protected" : false,
      "id_str" : "18302779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764379424875810817\/cb59s5P9_normal.jpg",
      "id" : 18302779,
      "verified" : false
    }
  },
  "id" : 774405173624070144,
  "created_at" : "2016-09-10 00:32:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "call me liv\uD83D\uDCCE",
      "screen_name" : "liv_thatsme",
      "indices" : [ 3, 15 ],
      "id_str" : "4299408694",
      "id" : 4299408694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774403720423628800",
  "text" : "RT @liv_thatsme: But what do you do when you're not on Twitter?\n\nMe: I don't understand the question.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773768655783993344",
    "text" : "But what do you do when you're not on Twitter?\n\nMe: I don't understand the question.",
    "id" : 773768655783993344,
    "created_at" : "2016-09-08 06:23:18 +0000",
    "user" : {
      "name" : "call me liv\uD83D\uDCCE",
      "screen_name" : "liv_thatsme",
      "protected" : false,
      "id_str" : "4299408694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801108821804544006\/vM7RGJxu_normal.jpg",
      "id" : 4299408694,
      "verified" : false
    }
  },
  "id" : 774403720423628800,
  "created_at" : "2016-09-10 00:26:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "indices" : [ 3, 15 ],
      "id_str" : "21833728",
      "id" : 21833728
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/774248623282462721\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/bfPyggyCWJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr6vBMzWgAAe0ae.jpg",
      "id_str" : "774248621105643520",
      "id" : 774248621105643520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr6vBMzWgAAe0ae.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/bfPyggyCWJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774402404343242753",
  "text" : "RT @Brasilmagic: Astrid Lindgren https:\/\/t.co\/bfPyggyCWJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/774248623282462721\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/bfPyggyCWJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr6vBMzWgAAe0ae.jpg",
        "id_str" : "774248621105643520",
        "id" : 774248621105643520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr6vBMzWgAAe0ae.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/bfPyggyCWJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774248623282462721",
    "text" : "Astrid Lindgren https:\/\/t.co\/bfPyggyCWJ",
    "id" : 774248623282462721,
    "created_at" : "2016-09-09 14:10:31 +0000",
    "user" : {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "protected" : false,
      "id_str" : "21833728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789894919787679744\/CXf0r3bi_normal.jpg",
      "id" : 21833728,
      "verified" : false
    }
  },
  "id" : 774402404343242753,
  "created_at" : "2016-09-10 00:21:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/774301956730945536\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9kukWUeSWT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr7fhhxWYAIwYy1.jpg",
      "id_str" : "774301953048338434",
      "id" : 774301953048338434,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr7fhhxWYAIwYy1.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1067
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/9kukWUeSWT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/pjtsAHEILK",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/1171927552881066\/?type=3&theater",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774401064552505349",
  "text" : "RT @dwaynereaves: Heaven and earth touching each other. https:\/\/t.co\/pjtsAHEILK https:\/\/t.co\/9kukWUeSWT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/774301956730945536\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/9kukWUeSWT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr7fhhxWYAIwYy1.jpg",
        "id_str" : "774301953048338434",
        "id" : 774301953048338434,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr7fhhxWYAIwYy1.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/9kukWUeSWT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/pjtsAHEILK",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/1171927552881066\/?type=3&theater",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774301956730945536",
    "text" : "Heaven and earth touching each other. https:\/\/t.co\/pjtsAHEILK https:\/\/t.co\/9kukWUeSWT",
    "id" : 774301956730945536,
    "created_at" : "2016-09-09 17:42:26 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 774401064552505349,
  "created_at" : "2016-09-10 00:16:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Woolsack",
      "screen_name" : "WoolsackUK",
      "indices" : [ 3, 14 ],
      "id_str" : "404066588",
      "id" : 404066588
    }, {
      "name" : "LouiseTilbrook",
      "screen_name" : "LouiseTilbrook1",
      "indices" : [ 16, 32 ],
      "id_str" : "137416404",
      "id" : 137416404
    }, {
      "name" : "Jamieson & Smith",
      "screen_name" : "Jamieson_Smith",
      "indices" : [ 65, 80 ],
      "id_str" : "44139437",
      "id" : 44139437
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woolworks",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ZjTh75Bh8C",
      "expanded_url" : "http:\/\/ravel.me\/JaneKAL\/ray",
      "display_url" : "ravel.me\/JaneKAL\/ray"
    } ]
  },
  "geo" : { },
  "id_str" : "774400950622642176",
  "text" : "RT @WoolsackUK: @LouiseTilbrook1 Very warm, very sheepy scarf in @Jamieson_Smith Shetland wool https:\/\/t.co\/ZjTh75Bh8C   #woolworks https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LouiseTilbrook",
        "screen_name" : "LouiseTilbrook1",
        "indices" : [ 0, 16 ],
        "id_str" : "137416404",
        "id" : 137416404
      }, {
        "name" : "Jamieson & Smith",
        "screen_name" : "Jamieson_Smith",
        "indices" : [ 49, 64 ],
        "id_str" : "44139437",
        "id" : 44139437
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WoolsackUK\/status\/774191702143823873\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/HNK7XlNzkJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr563fBWAAEaHfp.jpg",
        "id_str" : "774191279592833025",
        "id" : 774191279592833025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr563fBWAAEaHfp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/HNK7XlNzkJ"
      } ],
      "hashtags" : [ {
        "text" : "woolworks",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/ZjTh75Bh8C",
        "expanded_url" : "http:\/\/ravel.me\/JaneKAL\/ray",
        "display_url" : "ravel.me\/JaneKAL\/ray"
      } ]
    },
    "in_reply_to_status_id_str" : "774167174248222720",
    "geo" : { },
    "id_str" : "774191702143823873",
    "in_reply_to_user_id" : 137416404,
    "text" : "@LouiseTilbrook1 Very warm, very sheepy scarf in @Jamieson_Smith Shetland wool https:\/\/t.co\/ZjTh75Bh8C   #woolworks https:\/\/t.co\/HNK7XlNzkJ",
    "id" : 774191702143823873,
    "in_reply_to_status_id" : 774167174248222720,
    "created_at" : "2016-09-09 10:24:20 +0000",
    "in_reply_to_screen_name" : "LouiseTilbrook1",
    "in_reply_to_user_id_str" : "137416404",
    "user" : {
      "name" : "Woolsack",
      "screen_name" : "WoolsackUK",
      "protected" : false,
      "id_str" : "404066588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2596897761\/14n0trmksh9irukvlzr5_normal.jpeg",
      "id" : 404066588,
      "verified" : false
    }
  },
  "id" : 774400950622642176,
  "created_at" : "2016-09-10 00:15:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cancer",
      "indices" : [ 44, 51 ]
    }, {
      "text" : "breastcancer",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/YQW7HoF8Ld",
      "expanded_url" : "https:\/\/www.sciencedaily.com\/releases\/2016\/09\/160908084319.htm#.V9Mt531N69A.twitter",
      "display_url" : "sciencedaily.com\/releases\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774400231823773696",
  "text" : "RT @AlisynGayle: How Chinese medicine kills #cancer cells https:\/\/t.co\/YQW7HoF8Ld\n#breastcancer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cancer",
        "indices" : [ 27, 34 ]
      }, {
        "text" : "breastcancer",
        "indices" : [ 65, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/YQW7HoF8Ld",
        "expanded_url" : "https:\/\/www.sciencedaily.com\/releases\/2016\/09\/160908084319.htm#.V9Mt531N69A.twitter",
        "display_url" : "sciencedaily.com\/releases\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774363723653840900",
    "text" : "How Chinese medicine kills #cancer cells https:\/\/t.co\/YQW7HoF8Ld\n#breastcancer",
    "id" : 774363723653840900,
    "created_at" : "2016-09-09 21:47:53 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 774400231823773696,
  "created_at" : "2016-09-10 00:12:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774329369875611649",
  "text" : "Formatting my PC today...",
  "id" : 774329369875611649,
  "created_at" : "2016-09-09 19:31:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "indices" : [ 3, 16 ],
      "id_str" : "23150269",
      "id" : 23150269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774050286939758593",
  "text" : "RT @beardonabike: When you read\/hear something you disagree with, power through it. Practice slowing a quickening pulse &amp; just sit with it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773915130019000320",
    "text" : "When you read\/hear something you disagree with, power through it. Practice slowing a quickening pulse &amp; just sit with it for awhile.",
    "id" : 773915130019000320,
    "created_at" : "2016-09-08 16:05:20 +0000",
    "user" : {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "protected" : false,
      "id_str" : "23150269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461260607669293056\/udIfmFCN_normal.jpeg",
      "id" : 23150269,
      "verified" : false
    }
  },
  "id" : 774050286939758593,
  "created_at" : "2016-09-09 01:02:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Stebbins",
      "screen_name" : "jaystebbins",
      "indices" : [ 3, 15 ],
      "id_str" : "414412006",
      "id" : 414412006
    }, {
      "name" : "Taniel",
      "screen_name" : "Taniel",
      "indices" : [ 17, 24 ],
      "id_str" : "15537302",
      "id" : 15537302
    }, {
      "name" : "David Corn",
      "screen_name" : "DavidCornDC",
      "indices" : [ 25, 37 ],
      "id_str" : "15220768",
      "id" : 15220768
    }, {
      "name" : "Mike Pence",
      "screen_name" : "mike_pence",
      "indices" : [ 38, 49 ],
      "id_str" : "22203756",
      "id" : 22203756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774037182524694528",
  "text" : "RT @jaystebbins: @Taniel @DavidCornDC @mike_pence Trump's idea of \"strength\" should scare the crap out of every American. https:\/\/t.co\/nz4u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Taniel",
        "screen_name" : "Taniel",
        "indices" : [ 0, 7 ],
        "id_str" : "15537302",
        "id" : 15537302
      }, {
        "name" : "David Corn",
        "screen_name" : "DavidCornDC",
        "indices" : [ 8, 20 ],
        "id_str" : "15220768",
        "id" : 15220768
      }, {
        "name" : "Mike Pence",
        "screen_name" : "mike_pence",
        "indices" : [ 21, 32 ],
        "id_str" : "22203756",
        "id" : 22203756
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jaystebbins\/status\/774007463104290816\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/nz4unC565W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr3TrriUEAAIfJX.jpg",
        "id_str" : "774007458352074752",
        "id" : 774007458352074752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr3TrriUEAAIfJX.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/nz4unC565W"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774001854942437376",
    "geo" : { },
    "id_str" : "774007463104290816",
    "in_reply_to_user_id" : 15537302,
    "text" : "@Taniel @DavidCornDC @mike_pence Trump's idea of \"strength\" should scare the crap out of every American. https:\/\/t.co\/nz4unC565W",
    "id" : 774007463104290816,
    "in_reply_to_status_id" : 774001854942437376,
    "created_at" : "2016-09-08 22:12:14 +0000",
    "in_reply_to_screen_name" : "Taniel",
    "in_reply_to_user_id_str" : "15537302",
    "user" : {
      "name" : "Jay Stebbins",
      "screen_name" : "jaystebbins",
      "protected" : false,
      "id_str" : "414412006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495321645955809280\/EnpR_v74_normal.jpeg",
      "id" : 414412006,
      "verified" : false
    }
  },
  "id" : 774037182524694528,
  "created_at" : "2016-09-09 00:10:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773670187891437568",
  "geo" : { },
  "id_str" : "773681353183338496",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater so precious! lol",
  "id" : 773681353183338496,
  "in_reply_to_status_id" : 773670187891437568,
  "created_at" : "2016-09-08 00:36:23 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 101, 111 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/qMkHXoL8xJ",
      "expanded_url" : "https:\/\/shar.es\/1wDt5D",
      "display_url" : "shar.es\/1wDt5D"
    } ]
  },
  "geo" : { },
  "id_str" : "773567721145569281",
  "text" : "Would An Eternity In Hell Even Be Fair? (The Problem of Proportionality) https:\/\/t.co\/qMkHXoL8xJ via @sharethis",
  "id" : 773567721145569281,
  "created_at" : "2016-09-07 17:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shop 4 Autism",
      "screen_name" : "shop4autism",
      "indices" : [ 3, 15 ],
      "id_str" : "2874856874",
      "id" : 2874856874
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HistoryInPics\/status\/566300429097517057\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/8RdaxH0Gdr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vnPU7CAAA7Bw3.jpg",
      "id_str" : "566300428665487360",
      "id" : 566300428665487360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vnPU7CAAA7Bw3.jpg",
      "sizes" : [ {
        "h" : 825,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8RdaxH0Gdr"
    } ],
    "hashtags" : [ {
      "text" : "4charity",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "4charitytweets",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773551039186341888",
  "text" : "RT @shop4autism: Cross-section of the Titanic https:\/\/t.co\/8RdaxH0Gdr RT #4charity #4charitytweets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HistoryInPics\/status\/566300429097517057\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/8RdaxH0Gdr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vnPU7CAAA7Bw3.jpg",
        "id_str" : "566300428665487360",
        "id" : 566300428665487360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vnPU7CAAA7Bw3.jpg",
        "sizes" : [ {
          "h" : 825,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 825,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 825,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8RdaxH0Gdr"
      } ],
      "hashtags" : [ {
        "text" : "4charity",
        "indices" : [ 56, 65 ]
      }, {
        "text" : "4charitytweets",
        "indices" : [ 66, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773372883229868032",
    "text" : "Cross-section of the Titanic https:\/\/t.co\/8RdaxH0Gdr RT #4charity #4charitytweets",
    "id" : 773372883229868032,
    "created_at" : "2016-09-07 04:10:38 +0000",
    "user" : {
      "name" : "Shop 4 Autism",
      "screen_name" : "shop4autism",
      "protected" : false,
      "id_str" : "2874856874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527148059356958720\/h5SsyBAq_normal.jpeg",
      "id" : 2874856874,
      "verified" : false
    }
  },
  "id" : 773551039186341888,
  "created_at" : "2016-09-07 15:58:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773525251162386432",
  "geo" : { },
  "id_str" : "773549543271137280",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oh jeeez.. when i forget my effexor, i want to die so I get it.. ugh, you poor thing.",
  "id" : 773549543271137280,
  "in_reply_to_status_id" : 773525251162386432,
  "created_at" : "2016-09-07 15:52:37 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AnnotatedBible\/status\/773316581900156928\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ddOzqVfspx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrtfU5RVUAAM127.jpg",
      "id_str" : "773316573599715328",
      "id" : 773316573599715328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrtfU5RVUAAM127.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ddOzqVfspx"
    } ],
    "hashtags" : [ {
      "text" : "Magneto",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773323244812263426",
  "text" : "RT @AnnotatedBible: My #Magneto drawing, inspired by Jim Lee's classic X-Men # 1 cover https:\/\/t.co\/ddOzqVfspx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnnotatedBible\/status\/773316581900156928\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/ddOzqVfspx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrtfU5RVUAAM127.jpg",
        "id_str" : "773316573599715328",
        "id" : 773316573599715328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrtfU5RVUAAM127.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/ddOzqVfspx"
      } ],
      "hashtags" : [ {
        "text" : "Magneto",
        "indices" : [ 3, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773316581900156928",
    "text" : "My #Magneto drawing, inspired by Jim Lee's classic X-Men # 1 cover https:\/\/t.co\/ddOzqVfspx",
    "id" : 773316581900156928,
    "created_at" : "2016-09-07 00:26:55 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 773323244812263426,
  "created_at" : "2016-09-07 00:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strange Animals",
      "screen_name" : "Strange_Animals",
      "indices" : [ 3, 19 ],
      "id_str" : "1477312464",
      "id" : 1477312464
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Strange_Animals\/status\/738078935330619394\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1NsHSX0cjb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4u4RcUoAA37Gn.jpg",
      "id_str" : "738078933225086976",
      "id" : 738078933225086976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4u4RcUoAA37Gn.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1NsHSX0cjb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773238892686344192",
  "text" : "RT @Strange_Animals: The mangalitsa pig grows a hairy 'fleece' like a sheep.\n\n(Photo: Anik\u00F3) https:\/\/t.co\/1NsHSX0cjb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Strange_Animals\/status\/738078935330619394\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/1NsHSX0cjb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4u4RcUoAA37Gn.jpg",
        "id_str" : "738078933225086976",
        "id" : 738078933225086976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4u4RcUoAA37Gn.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1NsHSX0cjb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738078935330619394",
    "text" : "The mangalitsa pig grows a hairy 'fleece' like a sheep.\n\n(Photo: Anik\u00F3) https:\/\/t.co\/1NsHSX0cjb",
    "id" : 738078935330619394,
    "created_at" : "2016-06-01 18:45:05 +0000",
    "user" : {
      "name" : "Strange Animals",
      "screen_name" : "Strange_Animals",
      "protected" : false,
      "id_str" : "1477312464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681057278263443456\/G4v5Ed36_normal.jpg",
      "id" : 1477312464,
      "verified" : false
    }
  },
  "id" : 773238892686344192,
  "created_at" : "2016-09-06 19:18:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/T6oJ7nxPdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9PpWEAAlhOA.jpg",
      "id_str" : "773229305870553088",
      "id" : 773229305870553088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9PpWEAAlhOA.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/T6oJ7nxPdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9P2WYAAavS6.jpg",
      "id_str" : "773229305925099520",
      "id" : 773229305925099520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9P2WYAAavS6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/T6oJ7nxPdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9P-XEAEMecW.jpg",
      "id_str" : "773229305958699009",
      "id" : 773229305958699009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9P-XEAEMecW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/T6oJ7nxPdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9QNXgAA-XlN.jpg",
      "id_str" : "773229306021642240",
      "id" : 773229306021642240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9QNXgAA-XlN.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
    } ],
    "hashtags" : [ {
      "text" : "teamStripe",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773237953007067136",
  "text" : "RT @newlandfarm: Grasshopper, madeup and checking out the ladies! #teamStripe https:\/\/t.co\/T6oJ7nxPdu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/T6oJ7nxPdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9PpWEAAlhOA.jpg",
        "id_str" : "773229305870553088",
        "id" : 773229305870553088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9PpWEAAlhOA.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/T6oJ7nxPdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9P2WYAAavS6.jpg",
        "id_str" : "773229305925099520",
        "id" : 773229305925099520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9P2WYAAavS6.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/T6oJ7nxPdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9P-XEAEMecW.jpg",
        "id_str" : "773229305958699009",
        "id" : 773229305958699009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9P-XEAEMecW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/773229425030787073\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/T6oJ7nxPdu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsP9QNXgAA-XlN.jpg",
        "id_str" : "773229306021642240",
        "id" : 773229306021642240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsP9QNXgAA-XlN.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/T6oJ7nxPdu"
      } ],
      "hashtags" : [ {
        "text" : "teamStripe",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773229425030787073",
    "text" : "Grasshopper, madeup and checking out the ladies! #teamStripe https:\/\/t.co\/T6oJ7nxPdu",
    "id" : 773229425030787073,
    "created_at" : "2016-09-06 18:40:35 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 773237953007067136,
  "created_at" : "2016-09-06 19:14:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/YsEoecfvIp",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx2BkwbeS",
      "display_url" : "tmblr.co\/Zp3-jx2BkwbeS"
    } ]
  },
  "geo" : { },
  "id_str" : "773215214212878336",
  "text" : "When Does She Become He? https:\/\/t.co\/YsEoecfvIp",
  "id" : 773215214212878336,
  "created_at" : "2016-09-06 17:44:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "feedly",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/7PCsMKbiHy",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/unfundamentalistchristians\/2016\/09\/when-does-she-become-he\/",
      "display_url" : "patheos.com\/blogs\/unfundam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773214383224786949",
  "text" : "good post &gt;&gt; When Does She Become He? https:\/\/t.co\/7PCsMKbiHy #religion #feedly",
  "id" : 773214383224786949,
  "created_at" : "2016-09-06 17:40:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/WhAa2kiJmV",
      "expanded_url" : "https:\/\/twitter.com\/wtb6chiny\/status\/773192578061758464",
      "display_url" : "twitter.com\/wtb6chiny\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773201724718845952",
  "text" : "Thank you. Us ladies have gotten in the way of men far too long and made a mess of the world. We need to be leashed. https:\/\/t.co\/WhAa2kiJmV",
  "id" : 773201724718845952,
  "created_at" : "2016-09-06 16:50:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill McKibben",
      "screen_name" : "billmckibben",
      "indices" : [ 3, 16 ],
      "id_str" : "21786618",
      "id" : 21786618
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/billmckibben\/status\/772852827970494465\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5k3LwLfY0K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crm5cl4XgAAbbh4.jpg",
      "id_str" : "772852711926759424",
      "id" : 772852711926759424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crm5cl4XgAAbbh4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/5k3LwLfY0K"
    } ],
    "hashtags" : [ {
      "text" : "NoDAPL",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773201126325878784",
  "text" : "RT @billmckibben: Using dogs on demonstrators says something about your system. Something not good  #NoDAPL https:\/\/t.co\/5k3LwLfY0K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/billmckibben\/status\/772852827970494465\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/5k3LwLfY0K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Crm5cl4XgAAbbh4.jpg",
        "id_str" : "772852711926759424",
        "id" : 772852711926759424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crm5cl4XgAAbbh4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/5k3LwLfY0K"
      } ],
      "hashtags" : [ {
        "text" : "NoDAPL",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772852827970494465",
    "text" : "Using dogs on demonstrators says something about your system. Something not good  #NoDAPL https:\/\/t.co\/5k3LwLfY0K",
    "id" : 772852827970494465,
    "created_at" : "2016-09-05 17:44:07 +0000",
    "user" : {
      "name" : "Bill McKibben",
      "screen_name" : "billmckibben",
      "protected" : false,
      "id_str" : "21786618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772840695161774080\/_FkC7iL3_normal.jpg",
      "id" : 21786618,
      "verified" : true
    }
  },
  "id" : 773201126325878784,
  "created_at" : "2016-09-06 16:48:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/dr3Jbm6bZ3",
      "expanded_url" : "https:\/\/www.spot.im\/s\/00wew9GL5P7j",
      "display_url" : "spot.im\/s\/00wew9GL5P7j"
    } ]
  },
  "geo" : { },
  "id_str" : "773200747404136449",
  "text" : "\"Let me ask you this:  how much about vaccine damage in the 3rd world do you hear about in the ...\"  https:\/\/t.co\/dr3Jbm6bZ3",
  "id" : 773200747404136449,
  "created_at" : "2016-09-06 16:46:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/EtptZIAxSv",
      "expanded_url" : "https:\/\/www.spot.im\/s\/00znTItuol2Z",
      "display_url" : "spot.im\/s\/00znTItuol2Z"
    } ]
  },
  "geo" : { },
  "id_str" : "773199995625496576",
  "text" : "\"so, in the absence of an epidemic, healthy people are given a vaccine that causes an epidemic o...\"  https:\/\/t.co\/EtptZIAxSv",
  "id" : 773199995625496576,
  "created_at" : "2016-09-06 16:43:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shauna",
      "screen_name" : "goldengateblond",
      "indices" : [ 3, 19 ],
      "id_str" : "15576928",
      "id" : 15576928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773172176040108032",
  "text" : "RT @goldengateblond: Trump has lots of serious flaws, but calling Phyllis Schlafly a \"champion for women\" is disqualifying all by itself. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/SteANQgZEX",
        "expanded_url" : "https:\/\/twitter.com\/sopandeb\/status\/772947091651960832",
        "display_url" : "twitter.com\/sopandeb\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "772948871278317568",
    "text" : "Trump has lots of serious flaws, but calling Phyllis Schlafly a \"champion for women\" is disqualifying all by itself. https:\/\/t.co\/SteANQgZEX",
    "id" : 772948871278317568,
    "created_at" : "2016-09-06 00:05:46 +0000",
    "user" : {
      "name" : "shauna",
      "screen_name" : "goldengateblond",
      "protected" : false,
      "id_str" : "15576928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548586934319071232\/JkfxEiRT_normal.jpeg",
      "id" : 15576928,
      "verified" : true
    }
  },
  "id" : 773172176040108032,
  "created_at" : "2016-09-06 14:53:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773170888439103488",
  "text" : "RT @ErinEFarley: When did assuming that people who don't agree with you are stupid become the social norm?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773136490322800640",
    "text" : "When did assuming that people who don't agree with you are stupid become the social norm?",
    "id" : 773136490322800640,
    "created_at" : "2016-09-06 12:31:18 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 773170888439103488,
  "created_at" : "2016-09-06 14:47:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipa Jane Farley",
      "screen_name" : "philipajane",
      "indices" : [ 3, 15 ],
      "id_str" : "177881902",
      "id" : 177881902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/QSe7nhOHCJ",
      "expanded_url" : "http:\/\/ift.tt\/1QcwDWd",
      "display_url" : "ift.tt\/1QcwDWd"
    } ]
  },
  "geo" : { },
  "id_str" : "773170757874647040",
  "text" : "RT @philipajane: Morgan Freeman Is Finally a GPS Navigation Voice https:\/\/t.co\/QSe7nhOHCJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/QSe7nhOHCJ",
        "expanded_url" : "http:\/\/ift.tt\/1QcwDWd",
        "display_url" : "ift.tt\/1QcwDWd"
      } ]
    },
    "geo" : { },
    "id_str" : "773117948835790848",
    "text" : "Morgan Freeman Is Finally a GPS Navigation Voice https:\/\/t.co\/QSe7nhOHCJ",
    "id" : 773117948835790848,
    "created_at" : "2016-09-06 11:17:37 +0000",
    "user" : {
      "name" : "Philipa Jane Farley",
      "screen_name" : "philipajane",
      "protected" : false,
      "id_str" : "177881902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798830195784355840\/igeAMcBJ_normal.jpg",
      "id" : 177881902,
      "verified" : false
    }
  },
  "id" : 773170757874647040,
  "created_at" : "2016-09-06 14:47:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772958858897661952",
  "text" : "RT @sparklekaz: If life is challenging you, testing you &amp; pushing you..it's helping you become more of who you are meant to be. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sparklekaz\/status\/772953626297925633\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Enw4Fjs41r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CroVLPwWcAARg9f.jpg",
        "id_str" : "772953568999534592",
        "id" : 772953568999534592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CroVLPwWcAARg9f.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/Enw4Fjs41r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772953626297925633",
    "text" : "If life is challenging you, testing you &amp; pushing you..it's helping you become more of who you are meant to be. https:\/\/t.co\/Enw4Fjs41r",
    "id" : 772953626297925633,
    "created_at" : "2016-09-06 00:24:39 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 772958858897661952,
  "created_at" : "2016-09-06 00:45:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/E2n8g2GsSo",
      "expanded_url" : "http:\/\/www.theatlantic.com\/national\/archive\/2011\/12\/what-americans-keep-ignoring-about-finlands-school-success\/250564\/",
      "display_url" : "theatlantic.com\/national\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772951396232683520",
  "text" : "What Americans Keep Ignoring About Finland's School Success https:\/\/t.co\/E2n8g2GsSo",
  "id" : 772951396232683520,
  "created_at" : "2016-09-06 00:15:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Boykin",
      "screen_name" : "keithboykin",
      "indices" : [ 3, 15 ],
      "id_str" : "21728303",
      "id" : 21728303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772950089774034944",
  "text" : "RT @keithboykin: ''The atomic bomb is a marvelous gift that was given to our country by a wise God.'' - Phyllis Schlafly https:\/\/t.co\/kh2c6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/keithboykin\/status\/772944382039322624\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/kh2c6FCjaZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CroMp9aWIAg1N2D.jpg",
        "id_str" : "772944201046695944",
        "id" : 772944201046695944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CroMp9aWIAg1N2D.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 641
        } ],
        "display_url" : "pic.twitter.com\/kh2c6FCjaZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772944382039322624",
    "text" : "''The atomic bomb is a marvelous gift that was given to our country by a wise God.'' - Phyllis Schlafly https:\/\/t.co\/kh2c6FCjaZ",
    "id" : 772944382039322624,
    "created_at" : "2016-09-05 23:47:55 +0000",
    "user" : {
      "name" : "Keith Boykin",
      "screen_name" : "keithboykin",
      "protected" : false,
      "id_str" : "21728303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797096359807553537\/2zUaGk4y_normal.jpg",
      "id" : 21728303,
      "verified" : false
    }
  },
  "id" : 772950089774034944,
  "created_at" : "2016-09-06 00:10:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VampyBitMe",
      "screen_name" : "VampyBitme",
      "indices" : [ 3, 14 ],
      "id_str" : "51162310",
      "id" : 51162310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772949398611451904",
  "text" : "RT @VampyBitme: You don't have to appeal to everyone. You are the leader of your life, be happy with who you've become and what you are abo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772946901767368704",
    "text" : "You don't have to appeal to everyone. You are the leader of your life, be happy with who you've become and what you are about.",
    "id" : 772946901767368704,
    "created_at" : "2016-09-05 23:57:56 +0000",
    "user" : {
      "name" : "VampyBitMe",
      "screen_name" : "VampyBitme",
      "protected" : false,
      "id_str" : "51162310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798091779891306496\/JVlWtguo_normal.jpg",
      "id" : 51162310,
      "verified" : false
    }
  },
  "id" : 772949398611451904,
  "created_at" : "2016-09-06 00:07:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772945862255411200",
  "text" : "RT @aliceinthewater: Phyllis Schlafly also built a life and earned money telling women not to work. Oh the irony.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772934603942178816",
    "text" : "Phyllis Schlafly also built a life and earned money telling women not to work. Oh the irony.",
    "id" : 772934603942178816,
    "created_at" : "2016-09-05 23:09:04 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 772945862255411200,
  "created_at" : "2016-09-05 23:53:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772923802950987776",
  "text" : "RT @SenSanders: Health care cannot be dependent upon the whims and market projections of large companies whose goal is to make as much prof\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772548554695016448",
    "text" : "Health care cannot be dependent upon the whims and market projections of large companies whose goal is to make as much profit as possible.",
    "id" : 772548554695016448,
    "created_at" : "2016-09-04 21:35:03 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 772923802950987776,
  "created_at" : "2016-09-05 22:26:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stacy Gershaw",
      "screen_name" : "StacyGershaw",
      "indices" : [ 3, 16 ],
      "id_str" : "2908403438",
      "id" : 2908403438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772907380321452034",
  "text" : "RT @StacyGershaw: I read this quote in the middle of my excruciating Mormon faith crisis. It made me cry. Still does, to be perfectly\u2026 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StacyGershaw\/status\/772893576548216837\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/g1t8thvqqZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrnenHlWgAA99QZ.jpg",
        "id_str" : "772893574702727168",
        "id" : 772893574702727168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrnenHlWgAA99QZ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 926
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 926
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 926
        } ],
        "display_url" : "pic.twitter.com\/g1t8thvqqZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772893576548216837",
    "text" : "I read this quote in the middle of my excruciating Mormon faith crisis. It made me cry. Still does, to be perfectly\u2026 https:\/\/t.co\/g1t8thvqqZ",
    "id" : 772893576548216837,
    "created_at" : "2016-09-05 20:26:02 +0000",
    "user" : {
      "name" : "Stacy Gershaw",
      "screen_name" : "StacyGershaw",
      "protected" : false,
      "id_str" : "2908403438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536589216424013824\/f2OrJjcV_normal.jpeg",
      "id" : 2908403438,
      "verified" : false
    }
  },
  "id" : 772907380321452034,
  "created_at" : "2016-09-05 21:20:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Pass",
      "screen_name" : "steven_pass",
      "indices" : [ 3, 15 ],
      "id_str" : "2311437785",
      "id" : 2311437785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Highlandcattle",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772895315162791938",
  "text" : "RT @steven_pass: Lovely way to finish the day off, spending a bit of time enjoying these beautiful animals. #Highlandcattle https:\/\/t.co\/ua\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/772871303443480576\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/uaHgJukwma",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrnKJSzXYAAFPD7.jpg",
        "id_str" : "772871072085663744",
        "id" : 772871072085663744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrnKJSzXYAAFPD7.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1184,
          "resize" : "fit",
          "w" : 2104
        } ],
        "display_url" : "pic.twitter.com\/uaHgJukwma"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/772871303443480576\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/uaHgJukwma",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrnKM65WAAEX1Xr.jpg",
        "id_str" : "772871134387765249",
        "id" : 772871134387765249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrnKM65WAAEX1Xr.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1184,
          "resize" : "fit",
          "w" : 2104
        } ],
        "display_url" : "pic.twitter.com\/uaHgJukwma"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/steven_pass\/status\/772871303443480576\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/uaHgJukwma",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrnKQ6oWYAAgJ5M.jpg",
        "id_str" : "772871203035963392",
        "id" : 772871203035963392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrnKQ6oWYAAgJ5M.jpg",
        "sizes" : [ {
          "h" : 1184,
          "resize" : "fit",
          "w" : 2104
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/uaHgJukwma"
      } ],
      "hashtags" : [ {
        "text" : "Highlandcattle",
        "indices" : [ 91, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772871303443480576",
    "text" : "Lovely way to finish the day off, spending a bit of time enjoying these beautiful animals. #Highlandcattle https:\/\/t.co\/uaHgJukwma",
    "id" : 772871303443480576,
    "created_at" : "2016-09-05 18:57:32 +0000",
    "user" : {
      "name" : "Steven Pass",
      "screen_name" : "steven_pass",
      "protected" : false,
      "id_str" : "2311437785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792643598831452160\/puKwwP4Y_normal.jpg",
      "id" : 2311437785,
      "verified" : false
    }
  },
  "id" : 772895315162791938,
  "created_at" : "2016-09-05 20:32:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772854581193744385",
  "text" : "i think a contact manager might work for me to keep medical info? drs, appts, results, etc. any suggestions? #chronicillness",
  "id" : 772854581193744385,
  "created_at" : "2016-09-05 17:51:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "feedly",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/BtSPwtLSiD",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/4fc447b8ccaa50\/74946?app_id=339",
      "display_url" : "producthunt.com\/r\/4fc447b8ccaa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772821894433210369",
  "text" : "Postacard \u2014 Text a photo to send it as a postcard for $3. https:\/\/t.co\/BtSPwtLSiD #tech #feedly",
  "id" : 772821894433210369,
  "created_at" : "2016-09-05 15:41:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Getchell",
      "screen_name" : "AudiotainmntNws",
      "indices" : [ 0, 16 ],
      "id_str" : "726884722404552704",
      "id" : 726884722404552704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772612382195486724",
  "geo" : { },
  "id_str" : "772620578880688129",
  "in_reply_to_user_id" : 726884722404552704,
  "text" : "@AudiotainmntNws im newly following so dont know old way but ive found some PC to listen to via yr drops...",
  "id" : 772620578880688129,
  "in_reply_to_status_id" : 772612382195486724,
  "created_at" : "2016-09-05 02:21:15 +0000",
  "in_reply_to_screen_name" : "AudiotainmntNws",
  "in_reply_to_user_id_str" : "726884722404552704",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772605209654751232",
  "text" : "RT @fairlyspiritual: Be the trending hashtag you want to see in the world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772599420403658752",
    "text" : "Be the trending hashtag you want to see in the world.",
    "id" : 772599420403658752,
    "created_at" : "2016-09-05 00:57:10 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 772605209654751232,
  "created_at" : "2016-09-05 01:20:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan Hollingsworth",
      "screen_name" : "SoulHarmonyInc",
      "indices" : [ 3, 18 ],
      "id_str" : "557446380",
      "id" : 557446380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772603941762822144",
  "text" : "RT @SoulHarmonyInc: you can stay where you are in your thought patterns or you can pull yourself out of the self pity and move to a higher\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761733108961902593",
    "text" : "you can stay where you are in your thought patterns or you can pull yourself out of the self pity and move to a higher vibration.",
    "id" : 761733108961902593,
    "created_at" : "2016-08-06 01:18:20 +0000",
    "user" : {
      "name" : "Dylan Hollingsworth",
      "screen_name" : "SoulHarmonyInc",
      "protected" : false,
      "id_str" : "557446380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790299143725916160\/9cPZgrFc_normal.jpg",
      "id" : 557446380,
      "verified" : false
    }
  },
  "id" : 772603941762822144,
  "created_at" : "2016-09-05 01:15:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772602775511371780",
  "text" : "RT @Nigelstewart76: I bumped into this wild Buzzard earlier we stood and watched each other so close amazing experience https:\/\/t.co\/OubzJ9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/772475123467255808\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/OubzJ91mSl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Crhh-HkWYAE7ttF.jpg",
        "id_str" : "772475055905333249",
        "id" : 772475055905333249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crhh-HkWYAE7ttF.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/OubzJ91mSl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772475123467255808",
    "text" : "I bumped into this wild Buzzard earlier we stood and watched each other so close amazing experience https:\/\/t.co\/OubzJ91mSl",
    "id" : 772475123467255808,
    "created_at" : "2016-09-04 16:43:15 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 772602775511371780,
  "created_at" : "2016-09-05 01:10:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772602653004144640",
  "text" : "RT @CamoDave_: Just rescued a Pipistrelle Bat from my bloody cat, luckily not a mark on it, took it into the garden and it flew off https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/772542452687396864\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/TXsIYIbIFY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrifEeTWAAQHRc3.jpg",
        "id_str" : "772542235296530436",
        "id" : 772542235296530436,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrifEeTWAAQHRc3.jpg",
        "sizes" : [ {
          "h" : 596,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 670
        } ],
        "display_url" : "pic.twitter.com\/TXsIYIbIFY"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/772542452687396864\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/TXsIYIbIFY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrifFpOWgAA6hFL.jpg",
        "id_str" : "772542255408250880",
        "id" : 772542255408250880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrifFpOWgAA6hFL.jpg",
        "sizes" : [ {
          "h" : 670,
          "resize" : "fit",
          "w" : 661
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 661
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 661
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 661
        } ],
        "display_url" : "pic.twitter.com\/TXsIYIbIFY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772542452687396864",
    "text" : "Just rescued a Pipistrelle Bat from my bloody cat, luckily not a mark on it, took it into the garden and it flew off https:\/\/t.co\/TXsIYIbIFY",
    "id" : 772542452687396864,
    "created_at" : "2016-09-04 21:10:48 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 772602653004144640,
  "created_at" : "2016-09-05 01:10:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/aMVneFA10b",
      "expanded_url" : "https:\/\/thinkprogress.org\/fracking-bans-are-no-longer-allowed-in-oklahoma-6bae827748a0#.bwtz2fnm4",
      "display_url" : "thinkprogress.org\/fracking-bans-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772244337769979904",
  "text" : "RT @AlisynGayle: \u201CFracking Bans Are No Longer Allowed In Oklahoma\u201D by ThinkProgress https:\/\/t.co\/aMVneFA10b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/aMVneFA10b",
        "expanded_url" : "https:\/\/thinkprogress.org\/fracking-bans-are-no-longer-allowed-in-oklahoma-6bae827748a0#.bwtz2fnm4",
        "display_url" : "thinkprogress.org\/fracking-bans-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "772243476918534145",
    "text" : "\u201CFracking Bans Are No Longer Allowed In Oklahoma\u201D by ThinkProgress https:\/\/t.co\/aMVneFA10b",
    "id" : 772243476918534145,
    "created_at" : "2016-09-04 01:22:47 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 772244337769979904,
  "created_at" : "2016-09-04 01:26:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Reese Jones",
      "screen_name" : "PoliticusSarah",
      "indices" : [ 3, 18 ],
      "id_str" : "63013144",
      "id" : 63013144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TrumpInDetroit",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772226692832194560",
  "text" : "RT @PoliticusSarah: When we have bad white presidents, no one says \"won't see another white pres for generations!\" #TrumpInDetroit https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TrumpInDetroit",
        "indices" : [ 95, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/yHsRvDHfzQ",
        "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/537157586316165120",
        "display_url" : "twitter.com\/realDonaldTrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "772148369644892160",
    "text" : "When we have bad white presidents, no one says \"won't see another white pres for generations!\" #TrumpInDetroit https:\/\/t.co\/yHsRvDHfzQ",
    "id" : 772148369644892160,
    "created_at" : "2016-09-03 19:04:51 +0000",
    "user" : {
      "name" : "Sarah Reese Jones",
      "screen_name" : "PoliticusSarah",
      "protected" : false,
      "id_str" : "63013144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796798331611709441\/7SZFystq_normal.jpg",
      "id" : 63013144,
      "verified" : false
    }
  },
  "id" : 772226692832194560,
  "created_at" : "2016-09-04 00:16:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 131, 138 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/LeLuWAISgD",
      "expanded_url" : "https:\/\/www.reddit.com\/comments\/4vrvt2\/are_you_ready_to_go_retro_with_your_audio_drama\/?ref=share&ref_source=twitter",
      "display_url" : "reddit.com\/comments\/4vrvt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772159300223561729",
  "text" : "Are you ready to go retro with your audio drama? We're a company selling audio dramas and more on USB\u2026 https:\/\/t.co\/LeLuWAISgD via @reddit",
  "id" : 772159300223561729,
  "created_at" : "2016-09-03 19:48:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Player FM",
      "screen_name" : "PlayerFM",
      "indices" : [ 3, 12 ],
      "id_str" : "481597383",
      "id" : 481597383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772144546079731712",
  "text" : "RT @PlayerFM: Good Saturday! Database upgrade soon ... expect some short web downtime, Android app will continue fine if already setup. Sta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772141503691034625",
    "text" : "Good Saturday! Database upgrade soon ... expect some short web downtime, Android app will continue fine if already setup. Stay posted",
    "id" : 772141503691034625,
    "created_at" : "2016-09-03 18:37:34 +0000",
    "user" : {
      "name" : "Player FM",
      "screen_name" : "PlayerFM",
      "protected" : false,
      "id_str" : "481597383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2697929459\/8a5f777eeed7b568d6e57bcee6895d2f_normal.png",
      "id" : 481597383,
      "verified" : false
    }
  },
  "id" : 772144546079731712,
  "created_at" : "2016-09-03 18:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Light of September",
      "screen_name" : "thelightofsept",
      "indices" : [ 3, 18 ],
      "id_str" : "3044823839",
      "id" : 3044823839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772131657218392064",
  "text" : "RT @thelightofsept: @FantastiCon2015 Free-download audio series now funding Ep 9. Catch story so far on Itunes &amp; https:\/\/t.co\/ozcoYBi5q1 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thelightofsept\/status\/772113872513855488\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/ynPLZRchpq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrcZaWRW8AA8g_I.jpg",
        "id_str" : "772113801563009024",
        "id" : 772113801563009024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrcZaWRW8AA8g_I.jpg",
        "sizes" : [ {
          "h" : 279,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 1185
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 1185
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 1185
        } ],
        "display_url" : "pic.twitter.com\/ynPLZRchpq"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/thelightofsept\/status\/772113872513855488\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/ynPLZRchpq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrcZdlVWAAAK6AB.jpg",
        "id_str" : "772113857145864192",
        "id" : 772113857145864192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrcZdlVWAAAK6AB.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/ynPLZRchpq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/ozcoYBi5q1",
        "expanded_url" : "http:\/\/www.radiostatic.co.uk\/#!listen\/ywgz8",
        "display_url" : "radiostatic.co.uk\/#!listen\/ywgz8"
      } ]
    },
    "geo" : { },
    "id_str" : "772113872513855488",
    "text" : "@FantastiCon2015 Free-download audio series now funding Ep 9. Catch story so far on Itunes &amp; https:\/\/t.co\/ozcoYBi5q1 https:\/\/t.co\/ynPLZRchpq",
    "id" : 772113872513855488,
    "created_at" : "2016-09-03 16:47:47 +0000",
    "user" : {
      "name" : "Light of September",
      "screen_name" : "thelightofsept",
      "protected" : false,
      "id_str" : "3044823839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709487749481570308\/YRXDcGsl_normal.jpg",
      "id" : 3044823839,
      "verified" : false
    }
  },
  "id" : 772131657218392064,
  "created_at" : "2016-09-03 17:58:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Trask",
      "screen_name" : "AmyTrask",
      "indices" : [ 3, 12 ],
      "id_str" : "3280154588",
      "id" : 3280154588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmyTrask\/status\/772081841205612544\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/9kOFB3qvPV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crb8V4zWAAAALfa.jpg",
      "id_str" : "772081839095808000",
      "id" : 772081839095808000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crb8V4zWAAAALfa.jpg",
      "sizes" : [ {
        "h" : 479,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/9kOFB3qvPV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772098649883086849",
  "text" : "RT @AmyTrask: Morning Sam. Morning Ralph. Morning Twitter Village. https:\/\/t.co\/9kOFB3qvPV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmyTrask\/status\/772081841205612544\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/9kOFB3qvPV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Crb8V4zWAAAALfa.jpg",
        "id_str" : "772081839095808000",
        "id" : 772081839095808000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crb8V4zWAAAALfa.jpg",
        "sizes" : [ {
          "h" : 479,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/9kOFB3qvPV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772081841205612544",
    "text" : "Morning Sam. Morning Ralph. Morning Twitter Village. https:\/\/t.co\/9kOFB3qvPV",
    "id" : 772081841205612544,
    "created_at" : "2016-09-03 14:40:30 +0000",
    "user" : {
      "name" : "Amy Trask",
      "screen_name" : "AmyTrask",
      "protected" : false,
      "id_str" : "3280154588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622552105354592256\/smiw9gcU_normal.jpg",
      "id" : 3280154588,
      "verified" : true
    }
  },
  "id" : 772098649883086849,
  "created_at" : "2016-09-03 15:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Oare \uD83D\uDCCE",
      "screen_name" : "andyoare",
      "indices" : [ 3, 12 ],
      "id_str" : "170852492",
      "id" : 170852492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771861275873800192",
  "text" : "RT @andyoare: So can ppl stop praising Trump the diplomat? He lied to one of our closest allies, now fighting w him on Twitter. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andyoare\/status\/771678667541839872\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/dvo6WbU6uP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrWNe0jUIAAT-50.jpg",
        "id_str" : "771678471806263296",
        "id" : 771678471806263296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrWNe0jUIAAT-50.jpg",
        "sizes" : [ {
          "h" : 423,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/dvo6WbU6uP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771678667541839872",
    "text" : "So can ppl stop praising Trump the diplomat? He lied to one of our closest allies, now fighting w him on Twitter. https:\/\/t.co\/dvo6WbU6uP",
    "id" : 771678667541839872,
    "created_at" : "2016-09-02 11:58:26 +0000",
    "user" : {
      "name" : "Andy Oare \uD83D\uDCCE",
      "screen_name" : "andyoare",
      "protected" : false,
      "id_str" : "170852492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763048492973502465\/ufsN5XC7_normal.jpg",
      "id" : 170852492,
      "verified" : false
    }
  },
  "id" : 771861275873800192,
  "created_at" : "2016-09-03 00:04:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capital Weather Gang",
      "screen_name" : "capitalweather",
      "indices" : [ 3, 18 ],
      "id_str" : "15309804",
      "id" : 15309804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/4fnPUYxG7Y",
      "expanded_url" : "http:\/\/wapo.st\/2bQKUHq",
      "display_url" : "wapo.st\/2bQKUHq"
    } ]
  },
  "geo" : { },
  "id_str" : "771812946674671616",
  "text" : "RT @capitalweather: Thousands of birds got trapped in Hurricane Hermine\u2019s eye. Really. https:\/\/t.co\/4fnPUYxG7Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/4fnPUYxG7Y",
        "expanded_url" : "http:\/\/wapo.st\/2bQKUHq",
        "display_url" : "wapo.st\/2bQKUHq"
      } ]
    },
    "geo" : { },
    "id_str" : "771785205766053888",
    "text" : "Thousands of birds got trapped in Hurricane Hermine\u2019s eye. Really. https:\/\/t.co\/4fnPUYxG7Y",
    "id" : 771785205766053888,
    "created_at" : "2016-09-02 19:01:46 +0000",
    "user" : {
      "name" : "Capital Weather Gang",
      "screen_name" : "capitalweather",
      "protected" : false,
      "id_str" : "15309804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690370402997125120\/z108UqEi_normal.jpg",
      "id" : 15309804,
      "verified" : true
    }
  },
  "id" : 771812946674671616,
  "created_at" : "2016-09-02 20:52:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771784050331746304",
  "geo" : { },
  "id_str" : "771796401374322688",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ohh I love it! so cozy! : )",
  "id" : 771796401374322688,
  "in_reply_to_status_id" : 771784050331746304,
  "created_at" : "2016-09-02 19:46:16 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771763978406100992",
  "geo" : { },
  "id_str" : "771776678091710464",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides im good. : )",
  "id" : 771776678091710464,
  "in_reply_to_status_id" : 771763978406100992,
  "created_at" : "2016-09-02 18:27:53 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "indices" : [ 3, 19 ],
      "id_str" : "2530698811",
      "id" : 2530698811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/771657911286104065\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/gYcXTCx1lC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrV6wjEUsAQA_1O.jpg",
      "id_str" : "771657885629591556",
      "id" : 771657885629591556,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrV6wjEUsAQA_1O.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 993
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1694
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1694
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/gYcXTCx1lC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771768088211623936",
  "text" : "RT @JRfromStrickley: Coo looking at you https:\/\/t.co\/gYcXTCx1lC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JRfromStrickley\/status\/771657911286104065\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/gYcXTCx1lC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrV6wjEUsAQA_1O.jpg",
        "id_str" : "771657885629591556",
        "id" : 771657885629591556,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrV6wjEUsAQA_1O.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 993
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1694
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1694
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 562
        } ],
        "display_url" : "pic.twitter.com\/gYcXTCx1lC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771657911286104065",
    "text" : "Coo looking at you https:\/\/t.co\/gYcXTCx1lC",
    "id" : 771657911286104065,
    "created_at" : "2016-09-02 10:35:57 +0000",
    "user" : {
      "name" : "James Robinson",
      "screen_name" : "JRfromStrickley",
      "protected" : false,
      "id_str" : "2530698811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682844561933217792\/DmT71D0G_normal.jpg",
      "id" : 2530698811,
      "verified" : false
    }
  },
  "id" : 771768088211623936,
  "created_at" : "2016-09-02 17:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Res",
      "screen_name" : "BarbaraAResEsq",
      "indices" : [ 3, 18 ],
      "id_str" : "4771008201",
      "id" : 4771008201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771723665310380032",
  "text" : "RT @BarbaraAResEsq: Ann Coulter says Trump wasn't mocking the disabled reporter, he was just doing a \"standard retard\". So it's ok to mock\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771116036015923200",
    "text" : "Ann Coulter says Trump wasn't mocking the disabled reporter, he was just doing a \"standard retard\". So it's ok to mock retarded people.",
    "id" : 771116036015923200,
    "created_at" : "2016-08-31 22:42:44 +0000",
    "user" : {
      "name" : "Barbara Res",
      "screen_name" : "BarbaraAResEsq",
      "protected" : false,
      "id_str" : "4771008201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730854290496094212\/DQIU6UZ8_normal.jpg",
      "id" : 4771008201,
      "verified" : false
    }
  },
  "id" : 771723665310380032,
  "created_at" : "2016-09-02 14:57:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catch Compassion",
      "screen_name" : "CatchCompassion",
      "indices" : [ 3, 19 ],
      "id_str" : "2825542128",
      "id" : 2825542128
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 99, 109 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/3wIgoL9pgA",
      "expanded_url" : "https:\/\/shar.es\/1ZAxW8",
      "display_url" : "shar.es\/1ZAxW8"
    } ]
  },
  "geo" : { },
  "id_str" : "771716403892252672",
  "text" : "RT @CatchCompassion: The Spoon Theory written by Christine Miserandino https:\/\/t.co\/3wIgoL9pgA via @ShareThis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 78, 88 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/3wIgoL9pgA",
        "expanded_url" : "https:\/\/shar.es\/1ZAxW8",
        "display_url" : "shar.es\/1ZAxW8"
      } ]
    },
    "geo" : { },
    "id_str" : "762008025569890304",
    "text" : "The Spoon Theory written by Christine Miserandino https:\/\/t.co\/3wIgoL9pgA via @ShareThis",
    "id" : 762008025569890304,
    "created_at" : "2016-08-06 19:30:45 +0000",
    "user" : {
      "name" : "Catch Compassion",
      "screen_name" : "CatchCompassion",
      "protected" : false,
      "id_str" : "2825542128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517149388829757440\/5CTu3hs0_normal.jpeg",
      "id" : 2825542128,
      "verified" : false
    }
  },
  "id" : 771716403892252672,
  "created_at" : "2016-09-02 14:28:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald Pol",
      "screen_name" : "RonaldPolFoto",
      "indices" : [ 3, 17 ],
      "id_str" : "3971264001",
      "id" : 3971264001
    }, {
      "name" : "Wereld Natuur Fonds",
      "screen_name" : "wnfnederland",
      "indices" : [ 56, 69 ],
      "id_str" : "23577041",
      "id" : 23577041
    }, {
      "name" : "Canon Inc.",
      "screen_name" : "Canon",
      "indices" : [ 70, 76 ],
      "id_str" : "212139804",
      "id" : 212139804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildlife",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "photography",
      "indices" : [ 87, 99 ]
    }, {
      "text" : "fotografie",
      "indices" : [ 100, 111 ]
    }, {
      "text" : "natuurfotografie",
      "indices" : [ 112, 129 ]
    }, {
      "text" : "canvas",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/6YT0U0JdZo",
      "expanded_url" : "http:\/\/www.werkaandemuur.nl\/nl\/werk\/Ree\/180529\/93",
      "display_url" : "werkaandemuur.nl\/nl\/werk\/Ree\/18\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771716212321640449",
  "text" : "RT @RonaldPolFoto: \"What's up?\" https:\/\/t.co\/6YT0U0JdZo @wnfnederland @Canon #wildlife #photography #fotografie #natuurfotografie #canvas #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wereld Natuur Fonds",
        "screen_name" : "wnfnederland",
        "indices" : [ 37, 50 ],
        "id_str" : "23577041",
        "id" : 23577041
      }, {
        "name" : "Canon Inc.",
        "screen_name" : "Canon",
        "indices" : [ 51, 57 ],
        "id_str" : "212139804",
        "id" : 212139804
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wildlife",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "photography",
        "indices" : [ 68, 80 ]
      }, {
        "text" : "fotografie",
        "indices" : [ 81, 92 ]
      }, {
        "text" : "natuurfotografie",
        "indices" : [ 93, 110 ]
      }, {
        "text" : "canvas",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "art",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/6YT0U0JdZo",
        "expanded_url" : "http:\/\/www.werkaandemuur.nl\/nl\/werk\/Ree\/180529\/93",
        "display_url" : "werkaandemuur.nl\/nl\/werk\/Ree\/18\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742286128120791040",
    "text" : "\"What's up?\" https:\/\/t.co\/6YT0U0JdZo @wnfnederland @Canon #wildlife #photography #fotografie #natuurfotografie #canvas #art",
    "id" : 742286128120791040,
    "created_at" : "2016-06-13 09:22:58 +0000",
    "user" : {
      "name" : "Ronald Pol",
      "screen_name" : "RonaldPolFoto",
      "protected" : false,
      "id_str" : "3971264001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765522434011303936\/feyN0AQ-_normal.jpg",
      "id" : 3971264001,
      "verified" : false
    }
  },
  "id" : 771716212321640449,
  "created_at" : "2016-09-02 14:27:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald Pol",
      "screen_name" : "RonaldPolFoto",
      "indices" : [ 3, 17 ],
      "id_str" : "3971264001",
      "id" : 3971264001
    }, {
      "name" : "Wereld Natuur Fonds",
      "screen_name" : "wnfnederland",
      "indices" : [ 45, 58 ],
      "id_str" : "23577041",
      "id" : 23577041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wisent",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "bison",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 74, 83 ]
    }, {
      "text" : "fotografie",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "photography",
      "indices" : [ 96, 108 ]
    }, {
      "text" : "nature",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "natuur",
      "indices" : [ 117, 124 ]
    }, {
      "text" : "grazer",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771715960785006592",
  "text" : "RT @RonaldPolFoto: \"European Bison\" - Wisent @wnfnederland #wisent #bison #wildlife #fotografie #photography #nature #natuur #grazer https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wereld Natuur Fonds",
        "screen_name" : "wnfnederland",
        "indices" : [ 26, 39 ],
        "id_str" : "23577041",
        "id" : 23577041
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RonaldPolFoto\/status\/753933169817071616\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/wrtaYEZV8Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnaB3yEWYAAhrvZ.jpg",
        "id_str" : "753932782963941376",
        "id" : 753932782963941376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnaB3yEWYAAhrvZ.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 628
        } ],
        "display_url" : "pic.twitter.com\/wrtaYEZV8Z"
      } ],
      "hashtags" : [ {
        "text" : "wisent",
        "indices" : [ 40, 47 ]
      }, {
        "text" : "bison",
        "indices" : [ 48, 54 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 55, 64 ]
      }, {
        "text" : "fotografie",
        "indices" : [ 65, 76 ]
      }, {
        "text" : "photography",
        "indices" : [ 77, 89 ]
      }, {
        "text" : "nature",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "natuur",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "grazer",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753933169817071616",
    "text" : "\"European Bison\" - Wisent @wnfnederland #wisent #bison #wildlife #fotografie #photography #nature #natuur #grazer https:\/\/t.co\/wrtaYEZV8Z",
    "id" : 753933169817071616,
    "created_at" : "2016-07-15 12:44:09 +0000",
    "user" : {
      "name" : "Ronald Pol",
      "screen_name" : "RonaldPolFoto",
      "protected" : false,
      "id_str" : "3971264001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765522434011303936\/feyN0AQ-_normal.jpg",
      "id" : 3971264001,
      "verified" : false
    }
  },
  "id" : 771715960785006592,
  "created_at" : "2016-09-02 14:26:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Kelly",
      "screen_name" : "PK_sonsofjohnny",
      "indices" : [ 3, 19 ],
      "id_str" : "3644569695",
      "id" : 3644569695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771527160792309760",
  "text" : "RT @PK_sonsofjohnny: chilling out channel surfing stumbled upon KC and the Sunshine Band live in concert on AXS tv..loving the boogie band\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AXSSUNSHINE",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771520516033245184",
    "text" : "chilling out channel surfing stumbled upon KC and the Sunshine Band live in concert on AXS tv..loving the boogie band is killer #AXSSUNSHINE",
    "id" : 771520516033245184,
    "created_at" : "2016-09-02 01:29:59 +0000",
    "user" : {
      "name" : "Pat Kelly",
      "screen_name" : "PK_sonsofjohnny",
      "protected" : false,
      "id_str" : "3644569695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789575295284219904\/uuxrw7Y3_normal.jpg",
      "id" : 3644569695,
      "verified" : false
    }
  },
  "id" : 771527160792309760,
  "created_at" : "2016-09-02 01:56:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AWoww",
      "screen_name" : "AssuntaWoww",
      "indices" : [ 3, 15 ],
      "id_str" : "312308854",
      "id" : 312308854
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AXSSunshine",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771527099987398656",
  "text" : "RT @AssuntaWoww: Watching #AXSSunshine! Love me some KC and the Sunshine band! You can't help but smile:)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AXSSunshine",
        "indices" : [ 9, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771524356279336961",
    "text" : "Watching #AXSSunshine! Love me some KC and the Sunshine band! You can't help but smile:)",
    "id" : 771524356279336961,
    "created_at" : "2016-09-02 01:45:15 +0000",
    "user" : {
      "name" : "AWoww",
      "screen_name" : "AssuntaWoww",
      "protected" : false,
      "id_str" : "312308854",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 312308854,
      "verified" : false
    }
  },
  "id" : 771527099987398656,
  "created_at" : "2016-09-02 01:56:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsboogie",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771527024573841408",
  "text" : "grooving to kc and the sunshine band.. #letsboogie",
  "id" : 771527024573841408,
  "created_at" : "2016-09-02 01:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Player FM",
      "screen_name" : "PlayerFM",
      "indices" : [ 3, 12 ],
      "id_str" : "481597383",
      "id" : 481597383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771494754664210433",
  "text" : "RT @PlayerFM: Servers have been upscaled again today to meet your ever-enthusiastic demand! Go forth and podcast your socks off! \u25B6\u25B6\u25B6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771470006710308864",
    "text" : "Servers have been upscaled again today to meet your ever-enthusiastic demand! Go forth and podcast your socks off! \u25B6\u25B6\u25B6",
    "id" : 771470006710308864,
    "created_at" : "2016-09-01 22:09:17 +0000",
    "user" : {
      "name" : "Player FM",
      "screen_name" : "PlayerFM",
      "protected" : false,
      "id_str" : "481597383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2697929459\/8a5f777eeed7b568d6e57bcee6895d2f_normal.png",
      "id" : 481597383,
      "verified" : false
    }
  },
  "id" : 771494754664210433,
  "created_at" : "2016-09-01 23:47:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Collins",
      "screen_name" : "stan_sdcollins",
      "indices" : [ 3, 18 ],
      "id_str" : "858549320",
      "id" : 858549320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771469046428622849",
  "text" : "RT @stan_sdcollins: As another day ended we were blessed with another one of our wonderful nightly sunsets now occurring at 8 PM. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stan_sdcollins\/status\/771466881572241408\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/NSq8Vg4bvY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrTNCHWWIAAKbeO.jpg",
        "id_str" : "771466872403402752",
        "id" : 771466872403402752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrTNCHWWIAAKbeO.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/NSq8Vg4bvY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771466881572241408",
    "text" : "As another day ended we were blessed with another one of our wonderful nightly sunsets now occurring at 8 PM. https:\/\/t.co\/NSq8Vg4bvY",
    "id" : 771466881572241408,
    "created_at" : "2016-09-01 21:56:52 +0000",
    "user" : {
      "name" : "Stan Collins",
      "screen_name" : "stan_sdcollins",
      "protected" : false,
      "id_str" : "858549320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619964096205746176\/PDQ33Uf9_normal.jpg",
      "id" : 858549320,
      "verified" : false
    }
  },
  "id" : 771469046428622849,
  "created_at" : "2016-09-01 22:05:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 3, 13 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771468464330539008",
  "text" : "RT @ShaunKing: Dear America,\n\nYour definition of patriotism is a hollow bunch of nothingness smothered by flags and songs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771462862107803648",
    "text" : "Dear America,\n\nYour definition of patriotism is a hollow bunch of nothingness smothered by flags and songs.",
    "id" : 771462862107803648,
    "created_at" : "2016-09-01 21:40:54 +0000",
    "user" : {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "protected" : false,
      "id_str" : "755113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690138574050705408\/HkB9XCu4_normal.jpg",
      "id" : 755113,
      "verified" : true
    }
  },
  "id" : 771468464330539008,
  "created_at" : "2016-09-01 22:03:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5x5\/status\/771408904429461505\/video\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/umJDgOow5g",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/771408780366114816\/pu\/img\/nm0eMICCWxpSQWwn.jpg",
      "id_str" : "771408780366114816",
      "id" : 771408780366114816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/771408780366114816\/pu\/img\/nm0eMICCWxpSQWwn.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/umJDgOow5g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771414814681862145",
  "text" : "RT @5x5: Very cool moth. Been seeing a lot of these on our front porch. Cameo appearance by neighbor cat, Kitty. https:\/\/t.co\/umJDgOow5g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5x5\/status\/771408904429461505\/video\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/umJDgOow5g",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/771408780366114816\/pu\/img\/nm0eMICCWxpSQWwn.jpg",
        "id_str" : "771408780366114816",
        "id" : 771408780366114816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/771408780366114816\/pu\/img\/nm0eMICCWxpSQWwn.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/umJDgOow5g"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771408904429461505",
    "text" : "Very cool moth. Been seeing a lot of these on our front porch. Cameo appearance by neighbor cat, Kitty. https:\/\/t.co\/umJDgOow5g",
    "id" : 771408904429461505,
    "created_at" : "2016-09-01 18:06:29 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 771414814681862145,
  "created_at" : "2016-09-01 18:29:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul The Book Guy",
      "screen_name" : "PaulTheBookGuy",
      "indices" : [ 3, 18 ],
      "id_str" : "18302779",
      "id" : 18302779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/cGBUAZ4aFn",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/morning-mix\/wp\/2016\/09\/01\/like-its-been-nuked-millions-of-bees-dead-after-south-carolina-sprays-for-zika-mosquitoes\/",
      "display_url" : "washingtonpost.com\/news\/morning-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771408107289313281",
  "text" : "RT @PaulTheBookGuy: Sprayed for Zika mosquitos and killed all the bees instead...https:\/\/t.co\/cGBUAZ4aFn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/cGBUAZ4aFn",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/morning-mix\/wp\/2016\/09\/01\/like-its-been-nuked-millions-of-bees-dead-after-south-carolina-sprays-for-zika-mosquitoes\/",
        "display_url" : "washingtonpost.com\/news\/morning-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771385615539515392",
    "text" : "Sprayed for Zika mosquitos and killed all the bees instead...https:\/\/t.co\/cGBUAZ4aFn",
    "id" : 771385615539515392,
    "created_at" : "2016-09-01 16:33:57 +0000",
    "user" : {
      "name" : "Paul The Book Guy",
      "screen_name" : "PaulTheBookGuy",
      "protected" : false,
      "id_str" : "18302779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764379424875810817\/cb59s5P9_normal.jpg",
      "id" : 18302779,
      "verified" : false
    }
  },
  "id" : 771408107289313281,
  "created_at" : "2016-09-01 18:03:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Getchell",
      "screen_name" : "AudiotainmntNws",
      "indices" : [ 3, 19 ],
      "id_str" : "726884722404552704",
      "id" : 726884722404552704
    }, {
      "name" : "Audio-Drama.com",
      "screen_name" : "AudioDramaWiki",
      "indices" : [ 95, 110 ],
      "id_str" : "106579420",
      "id" : 106579420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771396259538239488",
  "text" : "RT @AudiotainmntNws: Looking for new audiodrama, enhanced audiobooks, or audiobooks? Check out @AudioDramaWiki there are more than 3000 lis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audio-Drama.com",
        "screen_name" : "AudioDramaWiki",
        "indices" : [ 74, 89 ],
        "id_str" : "106579420",
        "id" : 106579420
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771171045877223424",
    "text" : "Looking for new audiodrama, enhanced audiobooks, or audiobooks? Check out @AudioDramaWiki there are more than 3000 listings on that site!",
    "id" : 771171045877223424,
    "created_at" : "2016-09-01 02:21:19 +0000",
    "user" : {
      "name" : "Pam Getchell",
      "screen_name" : "AudiotainmntNws",
      "protected" : false,
      "id_str" : "726884722404552704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759896030217326593\/-MLUFKkP_normal.jpg",
      "id" : 726884722404552704,
      "verified" : false
    }
  },
  "id" : 771396259538239488,
  "created_at" : "2016-09-01 17:16:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/xfP5dYYexA",
      "expanded_url" : "https:\/\/twitter.com\/NYTScience\/status\/771333280209788928",
      "display_url" : "twitter.com\/NYTScience\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771355710038958080",
  "text" : "mind boggling and awesome https:\/\/t.co\/xfP5dYYexA",
  "id" : 771355710038958080,
  "created_at" : "2016-09-01 14:35:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NicHOLTZ",
      "screen_name" : "NoisyAstronomer",
      "indices" : [ 3, 19 ],
      "id_str" : "15099133",
      "id" : 15099133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/cAmMwoUUKt",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/ryanhatesthis\/someone-made-a-guide-for-what-to-do-when-you-see-islamophobi?bffbmain&ref=bffbmain&utm_term=.yx2zBpyXOK#.imMvgAzRM6",
      "display_url" : "buzzfeed.com\/ryanhatesthis\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771352167420657664",
  "text" : "RT @NoisyAstronomer: A French Middle Eastern woman illustrates one way to deal with harassment of others https:\/\/t.co\/cAmMwoUUKt https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NoisyAstronomer\/status\/771078464245997568\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/IXpLytZBXz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNruBxXgAAj4fX.jpg",
        "id_str" : "771078399704137728",
        "id" : 771078399704137728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNruBxXgAAj4fX.jpg",
        "sizes" : [ {
          "h" : 724,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/IXpLytZBXz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/cAmMwoUUKt",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/ryanhatesthis\/someone-made-a-guide-for-what-to-do-when-you-see-islamophobi?bffbmain&ref=bffbmain&utm_term=.yx2zBpyXOK#.imMvgAzRM6",
        "display_url" : "buzzfeed.com\/ryanhatesthis\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771078464245997568",
    "text" : "A French Middle Eastern woman illustrates one way to deal with harassment of others https:\/\/t.co\/cAmMwoUUKt https:\/\/t.co\/IXpLytZBXz",
    "id" : 771078464245997568,
    "created_at" : "2016-08-31 20:13:26 +0000",
    "user" : {
      "name" : "NicHOLTZ",
      "screen_name" : "NoisyAstronomer",
      "protected" : false,
      "id_str" : "15099133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778382845345665025\/twumxx1R_normal.jpg",
      "id" : 15099133,
      "verified" : false
    }
  },
  "id" : 771352167420657664,
  "created_at" : "2016-09-01 14:21:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]