Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian McManus",
      "screen_name" : "BoycottFox1",
      "indices" : [ 3, 15 ],
      "id_str" : "214273909",
      "id" : 214273909
    }, {
      "name" : "Teresa",
      "screen_name" : "TeresaKopec",
      "indices" : [ 20, 32 ],
      "id_str" : "15292813",
      "id" : 15292813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/qlMUnMc8",
      "expanded_url" : "http:\/\/bit.ly\/otsXK3",
      "display_url" : "bit.ly\/otsXK3"
    } ]
  },
  "geo" : { },
  "id_str" : "119919685771853824",
  "text" : "RT @BoycottFox1: RT @TeresaKopec: I joked about this at 7:15 am. http:\/\/t.co\/qlMUnMc8 Fox made it real by 5:00 pm. Beyond parody:  http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Teresa",
        "screen_name" : "TeresaKopec",
        "indices" : [ 3, 15 ],
        "id_str" : "15292813",
        "id" : 15292813
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 135, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/qlMUnMc8",
        "expanded_url" : "http:\/\/bit.ly\/otsXK3",
        "display_url" : "bit.ly\/otsXK3"
      }, {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/VW2XG9tF",
        "expanded_url" : "http:\/\/bit.ly\/q58Trv",
        "display_url" : "bit.ly\/q58Trv"
      } ]
    },
    "geo" : { },
    "id_str" : "119918025364340736",
    "text" : "RT @TeresaKopec: I joked about this at 7:15 am. http:\/\/t.co\/qlMUnMc8 Fox made it real by 5:00 pm. Beyond parody:  http:\/\/t.co\/VW2XG9tF #p2",
    "id" : 119918025364340736,
    "created_at" : "2011-09-30 23:34:19 +0000",
    "user" : {
      "name" : "Brian McManus",
      "screen_name" : "BoycottFox1",
      "protected" : false,
      "id_str" : "214273909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1728112543\/RupertMurdochDropFox2_normal.jpg",
      "id" : 214273909,
      "verified" : false
    }
  },
  "id" : 119919685771853824,
  "created_at" : "2011-09-30 23:40:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "indices" : [ 3, 13 ],
      "id_str" : "65698096",
      "id" : 65698096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119910560157548544",
  "text" : "RT @splcenter: Getting reports of water companies denying service and threatening to cut off services based on immigration status.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119909245775917056",
    "text" : "Getting reports of water companies denying service and threatening to cut off services based on immigration status.",
    "id" : 119909245775917056,
    "created_at" : "2011-09-30 22:59:26 +0000",
    "user" : {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "protected" : false,
      "id_str" : "65698096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798779235825426433\/n3bvatib_normal.jpg",
      "id" : 65698096,
      "verified" : true
    }
  },
  "id" : 119910560157548544,
  "created_at" : "2011-09-30 23:04:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Irene Latham",
      "screen_name" : "Irene_Latham",
      "indices" : [ 3, 16 ],
      "id_str" : "46089092",
      "id" : 46089092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridayreads",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119898580042522624",
  "text" : "RT @Irene_Latham: there's still time to win THE NIGHT CIRCUS for my #fridayreads giveaway. Simply RT to enter by midnight!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fridayreads",
        "indices" : [ 50, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119846617162596352",
    "text" : "there's still time to win THE NIGHT CIRCUS for my #fridayreads giveaway. Simply RT to enter by midnight!",
    "id" : 119846617162596352,
    "created_at" : "2011-09-30 18:50:34 +0000",
    "user" : {
      "name" : "Irene Latham",
      "screen_name" : "Irene_Latham",
      "protected" : false,
      "id_str" : "46089092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779319319838744576\/0ZnaDBy0_normal.jpg",
      "id" : 46089092,
      "verified" : false
    }
  },
  "id" : 119898580042522624,
  "created_at" : "2011-09-30 22:17:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119896859945873409",
  "text" : "RT @ZachsMind: History will back me up on this. Killing anyone who disagrees w\/you does not magically make you right. It just makes you  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119890956479770624",
    "text" : "History will back me up on this. Killing anyone who disagrees w\/you does not magically make you right. It just makes you even more stupid.",
    "id" : 119890956479770624,
    "created_at" : "2011-09-30 21:46:46 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 119896859945873409,
  "created_at" : "2011-09-30 22:10:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "permissiontofeel",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119896735811244032",
  "text" : "RT @psychstatemind: \"Never apologize for what you feel. It's like saying sorry for being real\" -Unknown #quote #permissiontofeel #Change ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 84, 90 ]
      }, {
        "text" : "permissiontofeel",
        "indices" : [ 91, 108 ]
      }, {
        "text" : "ChangeYourPerspective",
        "indices" : [ 109, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119070728732688384",
    "text" : "\"Never apologize for what you feel. It's like saying sorry for being real\" -Unknown #quote #permissiontofeel #ChangeYourPerspective",
    "id" : 119070728732688384,
    "created_at" : "2011-09-28 15:27:28 +0000",
    "user" : {
      "name" : "Maneet Bhatia",
      "screen_name" : "DrManeetBhatia",
      "protected" : false,
      "id_str" : "282916610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776890236152508416\/xaNdLdht_normal.jpg",
      "id" : 282916610,
      "verified" : false
    }
  },
  "id" : 119896735811244032,
  "created_at" : "2011-09-30 22:09:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119891219626196992",
  "geo" : { },
  "id_str" : "119896675698483200",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves aww..poor lil pumpkin!",
  "id" : 119896675698483200,
  "in_reply_to_status_id" : 119891219626196992,
  "created_at" : "2011-09-30 22:09:29 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "JesusOfNaz316",
      "indices" : [ 3, 17 ],
      "id_str" : "109687064",
      "id" : 109687064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119895779027591168",
  "text" : "RT @JesusOfNaz316: To win the war on terrorism, stop committing acts that terrorize.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119893939019972608",
    "text" : "To win the war on terrorism, stop committing acts that terrorize.",
    "id" : 119893939019972608,
    "created_at" : "2011-09-30 21:58:37 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "JesusOfNaz316",
      "protected" : false,
      "id_str" : "109687064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663841137\/RL000458.jpg_thinking_normal.jpg",
      "id" : 109687064,
      "verified" : false
    }
  },
  "id" : 119895779027591168,
  "created_at" : "2011-09-30 22:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119888990953410560",
  "text" : "RT @earthXplorer: please tweet everyone with respect...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119888009503059968",
    "text" : "please tweet everyone with respect...",
    "id" : 119888009503059968,
    "created_at" : "2011-09-30 21:35:03 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 119888990953410560,
  "created_at" : "2011-09-30 21:38:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    }, {
      "name" : "matron blackman",
      "screen_name" : "MatronB",
      "indices" : [ 58, 66 ],
      "id_str" : "700811086866554882",
      "id" : 700811086866554882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "photography",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/ZV3mYZ3Z",
      "expanded_url" : "http:\/\/dld.bz\/ar66V",
      "display_url" : "dld.bz\/ar66V"
    } ]
  },
  "geo" : { },
  "id_str" : "119888926126260225",
  "text" : "RT @ToadHollowPhoto: Oh my God, best owl picture EVER! RT @MatronB: Baby Tengmalms Owl ~ http:\/\/t.co\/ZV3mYZ3Z #nature #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "matron blackman",
        "screen_name" : "MatronB",
        "indices" : [ 37, 45 ],
        "id_str" : "700811086866554882",
        "id" : 700811086866554882
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "photography",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/ZV3mYZ3Z",
        "expanded_url" : "http:\/\/dld.bz\/ar66V",
        "display_url" : "dld.bz\/ar66V"
      } ]
    },
    "geo" : { },
    "id_str" : "119888740842864641",
    "text" : "Oh my God, best owl picture EVER! RT @MatronB: Baby Tengmalms Owl ~ http:\/\/t.co\/ZV3mYZ3Z #nature #photography",
    "id" : 119888740842864641,
    "created_at" : "2011-09-30 21:37:57 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 119888926126260225,
  "created_at" : "2011-09-30 21:38:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ania Ahlborn",
      "screen_name" : "aniaahlborn",
      "indices" : [ 3, 15 ],
      "id_str" : "272739347",
      "id" : 272739347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/j7ACczTc",
      "expanded_url" : "http:\/\/su.pr\/1NxQ5h",
      "display_url" : "su.pr\/1NxQ5h"
    } ]
  },
  "geo" : { },
  "id_str" : "119864145863639040",
  "text" : "RT @aniaahlborn: Fantastic shot of a creepy church. (1 pic) http:\/\/t.co\/j7ACczTc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/j7ACczTc",
        "expanded_url" : "http:\/\/su.pr\/1NxQ5h",
        "display_url" : "su.pr\/1NxQ5h"
      } ]
    },
    "geo" : { },
    "id_str" : "119863771945635840",
    "text" : "Fantastic shot of a creepy church. (1 pic) http:\/\/t.co\/j7ACczTc",
    "id" : 119863771945635840,
    "created_at" : "2011-09-30 19:58:44 +0000",
    "user" : {
      "name" : "Ania Ahlborn",
      "screen_name" : "aniaahlborn",
      "protected" : false,
      "id_str" : "272739347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729424733054357504\/gt6TTPx8_normal.jpg",
      "id" : 272739347,
      "verified" : false
    }
  },
  "id" : 119864145863639040,
  "created_at" : "2011-09-30 20:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7billion",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "whatsyournumber",
      "indices" : [ 55, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/wVF5r9ak",
      "expanded_url" : "http:\/\/shar.es\/balL1",
      "display_url" : "shar.es\/balL1"
    } ]
  },
  "geo" : { },
  "id_str" : "119861409986256897",
  "text" : "My number is 3,430,524,413 of #7billion! What's yours? #whatsyournumber http:\/\/t.co\/wVF5r9ak",
  "id" : 119861409986256897,
  "created_at" : "2011-09-30 19:49:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/4grRfzyx",
      "expanded_url" : "http:\/\/www.slate.com\/id\/2304776?tid=sm_tw_button_toolbar",
      "display_url" : "slate.com\/id\/2304776?tid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119845249228079104",
  "text" : "RT @oceanshaman: Jon Katz's Going Home: Spend one, last, perfect day with your dying dog. - Slate Magazine http:\/\/t.co\/4grRfzyx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/4grRfzyx",
        "expanded_url" : "http:\/\/www.slate.com\/id\/2304776?tid=sm_tw_button_toolbar",
        "display_url" : "slate.com\/id\/2304776?tid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "119842247851261952",
    "text" : "Jon Katz's Going Home: Spend one, last, perfect day with your dying dog. - Slate Magazine http:\/\/t.co\/4grRfzyx",
    "id" : 119842247851261952,
    "created_at" : "2011-09-30 18:33:13 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 119845249228079104,
  "created_at" : "2011-09-30 18:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119843854714277888",
  "text" : "RT @EarthLifeShop: \u2665 I Pledge Allegiance to the Earth and all the Life Which It Supports.\nOne Planet, in our care, irreplaceable,... htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/y9PlN9yD",
        "expanded_url" : "http:\/\/fb.me\/O8IgWzGy",
        "display_url" : "fb.me\/O8IgWzGy"
      } ]
    },
    "geo" : { },
    "id_str" : "119843643573018624",
    "text" : "\u2665 I Pledge Allegiance to the Earth and all the Life Which It Supports.\nOne Planet, in our care, irreplaceable,... http:\/\/t.co\/y9PlN9yD",
    "id" : 119843643573018624,
    "created_at" : "2011-09-30 18:38:45 +0000",
    "user" : {
      "name" : "Dagmar Magdalena",
      "screen_name" : "BatyaHavDesign",
      "protected" : false,
      "id_str" : "25688058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602426519487647744\/kogV47_M_normal.jpg",
      "id" : 25688058,
      "verified" : false
    }
  },
  "id" : 119843854714277888,
  "created_at" : "2011-09-30 18:39:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119839417761402880",
  "text" : "RT @UnseeingEyes: You can't trust \"video\" anymore...I wonder how much of the news is slightly exaggerated & falsified? Or they show old  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119837755495821312",
    "text" : "You can't trust \"video\" anymore...I wonder how much of the news is slightly exaggerated & falsified? Or they show old footage & make it new?",
    "id" : 119837755495821312,
    "created_at" : "2011-09-30 18:15:22 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 119839417761402880,
  "created_at" : "2011-09-30 18:21:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119831093120737281",
  "text" : "just saw a woollybear..improved my sour mood a bit.",
  "id" : 119831093120737281,
  "created_at" : "2011-09-30 17:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    }, {
      "name" : "Larry LaVoie",
      "screen_name" : "LarryLaVoie1",
      "indices" : [ 61, 74 ],
      "id_str" : "338829710",
      "id" : 338829710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/H5d6Ur2W",
      "expanded_url" : "http:\/\/larrylavoieauthor.blogspot.com\/",
      "display_url" : "larrylavoieauthor.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "119827329995390976",
  "text" : "RT @ceebee308: \"A Dog Named Jiggs\", a wonderful blog post by @LarryLaVoie1 http:\/\/t.co\/H5d6Ur2W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Larry LaVoie",
        "screen_name" : "LarryLaVoie1",
        "indices" : [ 46, 59 ],
        "id_str" : "338829710",
        "id" : 338829710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/H5d6Ur2W",
        "expanded_url" : "http:\/\/larrylavoieauthor.blogspot.com\/",
        "display_url" : "larrylavoieauthor.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "119825804204056578",
    "text" : "\"A Dog Named Jiggs\", a wonderful blog post by @LarryLaVoie1 http:\/\/t.co\/H5d6Ur2W",
    "id" : 119825804204056578,
    "created_at" : "2011-09-30 17:27:52 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 119827329995390976,
  "created_at" : "2011-09-30 17:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Challis",
      "screen_name" : "tesschallis",
      "indices" : [ 3, 15 ],
      "id_str" : "59968519",
      "id" : 59968519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119794050323845121",
  "text" : "RT @tesschallis: We have been Taught to Believe that Negative Equals Realistic & Positive Equals Unrealistic ~Susan Jeffers #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119793622429339649",
    "text" : "We have been Taught to Believe that Negative Equals Realistic & Positive Equals Unrealistic ~Susan Jeffers #quote",
    "id" : 119793622429339649,
    "created_at" : "2011-09-30 15:19:59 +0000",
    "user" : {
      "name" : "Tess Challis",
      "screen_name" : "tesschallis",
      "protected" : false,
      "id_str" : "59968519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708285115781099520\/k5W8b1mr_normal.jpg",
      "id" : 59968519,
      "verified" : false
    }
  },
  "id" : 119794050323845121,
  "created_at" : "2011-09-30 15:21:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Simon K  Lloyd",
      "screen_name" : "simonscotland",
      "indices" : [ 17, 31 ],
      "id_str" : "26969754",
      "id" : 26969754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/iWMPKkYw",
      "expanded_url" : "http:\/\/instagr.am\/p\/OnvB9\/",
      "display_url" : "instagr.am\/p\/OnvB9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "119793000154021888",
  "text" : "RT @KerriFar: RT @simonscotland: Swan looks annoyed that someone's littered their home http:\/\/t.co\/iWMPKkYw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simon K  Lloyd",
        "screen_name" : "simonscotland",
        "indices" : [ 3, 17 ],
        "id_str" : "26969754",
        "id" : 26969754
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/iWMPKkYw",
        "expanded_url" : "http:\/\/instagr.am\/p\/OnvB9\/",
        "display_url" : "instagr.am\/p\/OnvB9\/"
      } ]
    },
    "geo" : { },
    "id_str" : "119792676055949312",
    "text" : "RT @simonscotland: Swan looks annoyed that someone's littered their home http:\/\/t.co\/iWMPKkYw",
    "id" : 119792676055949312,
    "created_at" : "2011-09-30 15:16:14 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 119793000154021888,
  "created_at" : "2011-09-30 15:17:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Paper",
      "screen_name" : "NealPaper",
      "indices" : [ 3, 13 ],
      "id_str" : "137459940",
      "id" : 137459940
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pseudoskeptics",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119792927055687680",
  "text" : "RT @NealPaper: #Pseudoskeptics are desperate REALITY ENFORCERS of an reality that soon will cease to exist. Bye Bye Old System! Hello Ne ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.lux-os.com\" rel=\"nofollow\"\u003EGlobal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pseudoskeptics",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119792777147072512",
    "text" : "#Pseudoskeptics are desperate REALITY ENFORCERS of an reality that soon will cease to exist. Bye Bye Old System! Hello New World!",
    "id" : 119792777147072512,
    "created_at" : "2011-09-30 15:16:38 +0000",
    "user" : {
      "name" : "Neal Paper",
      "screen_name" : "NealPaper",
      "protected" : false,
      "id_str" : "137459940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853635340\/flower_normal.jpg",
      "id" : 137459940,
      "verified" : false
    }
  },
  "id" : 119792927055687680,
  "created_at" : "2011-09-30 15:17:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119791026557829120",
  "text" : "while I do want ppl to like me.. more important I love myself. Im ok w being the cheese. its my purpose apparently.",
  "id" : 119791026557829120,
  "created_at" : "2011-09-30 15:09:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119790595303686145",
  "text" : "the cheese stands alone..lol",
  "id" : 119790595303686145,
  "created_at" : "2011-09-30 15:07:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119790534935068672",
  "text" : "if ppl really knew me, they wldnt like me at all. they have no idea the things I feel, believe. I dont belong in any group.",
  "id" : 119790534935068672,
  "created_at" : "2011-09-30 15:07:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 3, 15 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/3ntAPNV8",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/tamanduagirl\/6196839796\/",
      "display_url" : "flickr.com\/photos\/tamandu\u2026"
    }, {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/dkMAzcYn",
      "expanded_url" : "http:\/\/fb.me\/PV1bM0lH",
      "display_url" : "fb.me\/PV1bM0lH"
    } ]
  },
  "geo" : { },
  "id_str" : "119587688394391553",
  "text" : "RT @PuaTamandua: Super cute Ori http:\/\/t.co\/3ntAPNV8 http:\/\/t.co\/dkMAzcYn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/3ntAPNV8",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/tamanduagirl\/6196839796\/",
        "display_url" : "flickr.com\/photos\/tamandu\u2026"
      }, {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/dkMAzcYn",
        "expanded_url" : "http:\/\/fb.me\/PV1bM0lH",
        "display_url" : "fb.me\/PV1bM0lH"
      } ]
    },
    "geo" : { },
    "id_str" : "119586648274120704",
    "text" : "Super cute Ori http:\/\/t.co\/3ntAPNV8 http:\/\/t.co\/dkMAzcYn",
    "id" : 119586648274120704,
    "created_at" : "2011-09-30 01:37:33 +0000",
    "user" : {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "protected" : false,
      "id_str" : "17218256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63782435\/shirt_normal.jpg",
      "id" : 17218256,
      "verified" : false
    }
  },
  "id" : 119587688394391553,
  "created_at" : "2011-09-30 01:41:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119570242983837696",
  "text" : "\"Income tax is illegal.\" - Ron on Parks & Recreation",
  "id" : 119570242983837696,
  "created_at" : "2011-09-30 00:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119567922527080450",
  "text" : "RT @UnseeingEyes: The only time we truly ever grow...is when we are pushed outside of our comfort zone & venture into the unknown.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119567485589655552",
    "text" : "The only time we truly ever grow...is when we are pushed outside of our comfort zone & venture into the unknown.",
    "id" : 119567485589655552,
    "created_at" : "2011-09-30 00:21:24 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 119567922527080450,
  "created_at" : "2011-09-30 00:23:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119540026265706496",
  "text" : "RT @drbloem: RT @KIIS_MY_TWEETZ Did you read http:\/\/t.co\/7Bgx7aKQ ? #Gardasil #HPV You don't want to be \"One Less\" person on this earth, ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gardasil",
        "indices" : [ 55, 64 ]
      }, {
        "text" : "HPV",
        "indices" : [ 65, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/7Bgx7aKQ",
        "expanded_url" : "http:\/\/bit.ly\/cKM6XB",
        "display_url" : "bit.ly\/cKM6XB"
      } ]
    },
    "geo" : { },
    "id_str" : "119539844438425601",
    "text" : "RT @KIIS_MY_TWEETZ Did you read http:\/\/t.co\/7Bgx7aKQ ? #Gardasil #HPV You don't want to be \"One Less\" person on this earth, do you?",
    "id" : 119539844438425601,
    "created_at" : "2011-09-29 22:31:34 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 119540026265706496,
  "created_at" : "2011-09-29 22:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Branley",
      "screen_name" : "YatPundit",
      "indices" : [ 3, 13 ],
      "id_str" : "10836362",
      "id" : 10836362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119534822518562817",
  "text" : "RT @YatPundit: the week after Georgia executes a man who may have been innocent, Iran wants to execute a Christian-tell me how we have t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119534083532521472",
    "text" : "the week after Georgia executes a man who may have been innocent, Iran wants to execute a Christian-tell me how we have the high ground?",
    "id" : 119534083532521472,
    "created_at" : "2011-09-29 22:08:41 +0000",
    "user" : {
      "name" : "Edward Branley",
      "screen_name" : "YatPundit",
      "protected" : false,
      "id_str" : "10836362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576092572466028544\/FWHFKWG4_normal.jpeg",
      "id" : 10836362,
      "verified" : false
    }
  },
  "id" : 119534822518562817,
  "created_at" : "2011-09-29 22:11:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 3, 16 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119534599956213760",
  "text" : "RT @SignsOfKevin: Dear moms critiquing the wardrobe of your daughter's first grade classmate, knock it off.",
  "id" : 119534599956213760,
  "created_at" : "2011-09-29 22:10:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119515997433638912",
  "geo" : { },
  "id_str" : "119519500801548288",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver that may be my next cat. currently, tho, DD's cat won't allow it..lol.",
  "id" : 119519500801548288,
  "in_reply_to_status_id" : 119515997433638912,
  "created_at" : "2011-09-29 21:10:44 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/8TSrm3pH",
      "expanded_url" : "http:\/\/bbc.in\/pdvuNf",
      "display_url" : "bbc.in\/pdvuNf"
    } ]
  },
  "geo" : { },
  "id_str" : "119518432751403008",
  "text" : "RT @Silvercrone: BBC News - Twitter clue to mood of the world http:\/\/t.co\/8TSrm3pH \/\/duh!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/8TSrm3pH",
        "expanded_url" : "http:\/\/bbc.in\/pdvuNf",
        "display_url" : "bbc.in\/pdvuNf"
      } ]
    },
    "geo" : { },
    "id_str" : "119517815656030208",
    "text" : "BBC News - Twitter clue to mood of the world http:\/\/t.co\/8TSrm3pH \/\/duh!",
    "id" : 119517815656030208,
    "created_at" : "2011-09-29 21:04:02 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 119518432751403008,
  "created_at" : "2011-09-29 21:06:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 14, 29 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119513048246530048",
  "geo" : { },
  "id_str" : "119513705615593473",
  "in_reply_to_user_id" : 25846336,
  "text" : "he's adorable @mssuzcatsilver smooches to Henry",
  "id" : 119513705615593473,
  "in_reply_to_status_id" : 119513048246530048,
  "created_at" : "2011-09-29 20:47:42 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119511766194597888",
  "text" : "RT @earthXplorer: duck......duck.......duck.......duck..........GOOSE!!!! &lt;run, run, run&gt; :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119509388259098624",
    "text" : "duck......duck.......duck.......duck..........GOOSE!!!! &lt;run, run, run&gt; :)",
    "id" : 119509388259098624,
    "created_at" : "2011-09-29 20:30:33 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 119511766194597888,
  "created_at" : "2011-09-29 20:40:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119504968322523136",
  "text" : "RT @CreativeArtwks: Winner will be drawn tomorrow for package of hand painted personalized \"Fall Leaves\" note cards. Enter Today! http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/bXHyJw3A",
        "expanded_url" : "http:\/\/bit.ly\/pFaphb",
        "display_url" : "bit.ly\/pFaphb"
      } ]
    },
    "geo" : { },
    "id_str" : "119500140309516288",
    "text" : "Winner will be drawn tomorrow for package of hand painted personalized \"Fall Leaves\" note cards. Enter Today! http:\/\/t.co\/bXHyJw3A",
    "id" : 119500140309516288,
    "created_at" : "2011-09-29 19:53:48 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 119504968322523136,
  "created_at" : "2011-09-29 20:12:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mackenzie Phillips",
      "screen_name" : "MackPhillips",
      "indices" : [ 3, 16 ],
      "id_str" : "112824083",
      "id" : 112824083
    }, {
      "name" : "Monique Coleman",
      "screen_name" : "gimmemotalk",
      "indices" : [ 22, 34 ],
      "id_str" : "34739186",
      "id" : 34739186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119489089765519360",
  "text" : "RT @MackPhillips: RT \u201C@gimmemotalk: Pakistani Teen Gang Raped, Now Her Family Faces Threat Of Death Because They Won\u2019t Kill Her\u2026  http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monique Coleman",
        "screen_name" : "gimmemotalk",
        "indices" : [ 4, 16 ],
        "id_str" : "34739186",
        "id" : 34739186
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/1OdWda9E",
        "expanded_url" : "http:\/\/bit.ly\/nvd4DH",
        "display_url" : "bit.ly\/nvd4DH"
      } ]
    },
    "geo" : { },
    "id_str" : "119487396105555968",
    "text" : "RT \u201C@gimmemotalk: Pakistani Teen Gang Raped, Now Her Family Faces Threat Of Death Because They Won\u2019t Kill Her\u2026  http:\/\/t.co\/1OdWda9E\u201D",
    "id" : 119487396105555968,
    "created_at" : "2011-09-29 19:03:09 +0000",
    "user" : {
      "name" : "Mackenzie Phillips",
      "screen_name" : "MackPhillips",
      "protected" : false,
      "id_str" : "112824083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2662430044\/dbadcb70117893b43317fd0afcd6be1c_normal.jpeg",
      "id" : 112824083,
      "verified" : true
    }
  },
  "id" : 119489089765519360,
  "created_at" : "2011-09-29 19:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Winkler Estes",
      "screen_name" : "GiggleFlower",
      "indices" : [ 3, 16 ],
      "id_str" : "28919933",
      "id" : 28919933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119488982106112000",
  "text" : "RT @GiggleFlower: Every time I find out the meaning of life, they change it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myspace.com\/506204160\" rel=\"nofollow\"\u003EGiggleLand\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119486195087577088",
    "text" : "Every time I find out the meaning of life, they change it.",
    "id" : 119486195087577088,
    "created_at" : "2011-09-29 18:58:23 +0000",
    "user" : {
      "name" : "Debbie Winkler Estes",
      "screen_name" : "GiggleFlower",
      "protected" : false,
      "id_str" : "28919933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1792954418\/9026_102737076405648_100000080679517_80687_4025563_n_normal.jpg",
      "id" : 28919933,
      "verified" : false
    }
  },
  "id" : 119488982106112000,
  "created_at" : "2011-09-29 19:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Frank Scavo",
      "screen_name" : "fscavo",
      "indices" : [ 23, 30 ],
      "id_str" : "17719090",
      "id" : 17719090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/qsXEJyp4",
      "expanded_url" : "http:\/\/bit.ly\/r0MzKo",
      "display_url" : "bit.ly\/r0MzKo"
    } ]
  },
  "geo" : { },
  "id_str" : "119480101418180608",
  "text" : "RT @MartijnLinssen: RT @fscavo: Bonehead alert: Teacher penalizes students for saying \"bless you\" after one sneezes http:\/\/t.co\/qsXEJyp4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frank Scavo",
        "screen_name" : "fscavo",
        "indices" : [ 3, 10 ],
        "id_str" : "17719090",
        "id" : 17719090
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/qsXEJyp4",
        "expanded_url" : "http:\/\/bit.ly\/r0MzKo",
        "display_url" : "bit.ly\/r0MzKo"
      } ]
    },
    "geo" : { },
    "id_str" : "119477881817669632",
    "text" : "RT @fscavo: Bonehead alert: Teacher penalizes students for saying \"bless you\" after one sneezes http:\/\/t.co\/qsXEJyp4 &lt; a point to it, but...",
    "id" : 119477881817669632,
    "created_at" : "2011-09-29 18:25:21 +0000",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 119480101418180608,
  "created_at" : "2011-09-29 18:34:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    }, {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 44, 54 ],
      "id_str" : "26426173",
      "id" : 26426173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/poKvtj6S",
      "expanded_url" : "http:\/\/amzn.to\/nr5e3Z",
      "display_url" : "amzn.to\/nr5e3Z"
    } ]
  },
  "geo" : { },
  "id_str" : "119456952345559040",
  "text" : "RT @amazonmp3: HOORAY: Get $2 towards music @amazonmp3 for a limited time. Find out how and please retweet: http:\/\/t.co\/poKvtj6S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon Music",
        "screen_name" : "amazonmp3",
        "indices" : [ 29, 39 ],
        "id_str" : "26426173",
        "id" : 26426173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/poKvtj6S",
        "expanded_url" : "http:\/\/amzn.to\/nr5e3Z",
        "display_url" : "amzn.to\/nr5e3Z"
      } ]
    },
    "geo" : { },
    "id_str" : "119456427873017856",
    "text" : "HOORAY: Get $2 towards music @amazonmp3 for a limited time. Find out how and please retweet: http:\/\/t.co\/poKvtj6S",
    "id" : 119456427873017856,
    "created_at" : "2011-09-29 17:00:06 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 119456952345559040,
  "created_at" : "2011-09-29 17:02:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/SllXzmuh",
      "expanded_url" : "http:\/\/on.today.com\/omw7dI",
      "display_url" : "on.today.com\/omw7dI"
    } ]
  },
  "geo" : { },
  "id_str" : "119414689213071361",
  "text" : "Animal Tracks - Cliffhanger: Can a mama lion save her cub? http:\/\/t.co\/SllXzmuh",
  "id" : 119414689213071361,
  "created_at" : "2011-09-29 14:14:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119407851784519681",
  "text" : "RT @UnseeingEyes: This guy...what a quality guy; I'm only going to take $1 a year; but I own all the media, make all the laws, & my comp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119336437236764673",
    "text" : "This guy...what a quality guy; I'm only going to take $1 a year; but I own all the media, make all the laws, & my companies get every deal.",
    "id" : 119336437236764673,
    "created_at" : "2011-09-29 09:03:18 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 119407851784519681,
  "created_at" : "2011-09-29 13:47:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119407762739445760",
  "text" : "RT @wow_trees: \"I THINK THEREFORE I AM NEITHER REPUBLICAN OR DEMOCRAT.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119405193237499904",
    "text" : "\"I THINK THEREFORE I AM NEITHER REPUBLICAN OR DEMOCRAT.\"",
    "id" : 119405193237499904,
    "created_at" : "2011-09-29 13:36:31 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 119407762739445760,
  "created_at" : "2011-09-29 13:46:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119136246764281856",
  "text" : "RT @UnseeingEyes: In essence, what are we really? The answer is simple. We are ENERGY. And we know energy cannot be created nor destroyed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119135600304599041",
    "text" : "In essence, what are we really? The answer is simple. We are ENERGY. And we know energy cannot be created nor destroyed.",
    "id" : 119135600304599041,
    "created_at" : "2011-09-28 19:45:15 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 119136246764281856,
  "created_at" : "2011-09-28 19:47:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 17, 30 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119127557684736000",
  "text" : "I love libraries @UnseeingEyes but I was running up fees not getting books back on time.",
  "id" : 119127557684736000,
  "created_at" : "2011-09-28 19:13:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 56, 69 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119127178645483520",
  "text" : "I do have many physical books and still go through them @UnseeingEyes I believe in choices\/options.",
  "id" : 119127178645483520,
  "created_at" : "2011-09-28 19:11:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119123609292767234",
  "geo" : { },
  "id_str" : "119125646252314624",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes If I didn't have my Sony\/Kindle, I would not have read the books I've read. Gave up going to library.",
  "id" : 119125646252314624,
  "in_reply_to_status_id" : 119123609292767234,
  "created_at" : "2011-09-28 19:05:41 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blog Kindle",
      "screen_name" : "BlogKindle",
      "indices" : [ 3, 14 ],
      "id_str" : "42677929",
      "id" : 42677929
    }, {
      "name" : "Blog Kindle",
      "screen_name" : "BlogKindle",
      "indices" : [ 47, 58 ],
      "id_str" : "42677929",
      "id" : 42677929
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freestuff",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "rt",
      "indices" : [ 27, 30 ]
    }, {
      "text" : "kindlefire",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/ENbJtoF9",
      "expanded_url" : "http:\/\/wp.me\/p9M6U-25N",
      "display_url" : "wp.me\/p9M6U-25N"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/VrI9rT6P",
      "expanded_url" : "http:\/\/blogkindle.com\/",
      "display_url" : "blogkindle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "119108219183439872",
  "text" : "RT @BlogKindle: #freestuff #rt this and follow @blogkindle for a chance to win #kindlefire http:\/\/t.co\/ENbJtoF9 http:\/\/t.co\/VrI9rT6P via ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blog Kindle",
        "screen_name" : "BlogKindle",
        "indices" : [ 31, 42 ],
        "id_str" : "42677929",
        "id" : 42677929
      }, {
        "name" : "Blog Kindle",
        "screen_name" : "BlogKindle",
        "indices" : [ 121, 132 ],
        "id_str" : "42677929",
        "id" : 42677929
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freestuff",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "rt",
        "indices" : [ 11, 14 ]
      }, {
        "text" : "kindlefire",
        "indices" : [ 63, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/ENbJtoF9",
        "expanded_url" : "http:\/\/wp.me\/p9M6U-25N",
        "display_url" : "wp.me\/p9M6U-25N"
      }, {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/VrI9rT6P",
        "expanded_url" : "http:\/\/blogkindle.com\/",
        "display_url" : "blogkindle.com"
      } ]
    },
    "geo" : { },
    "id_str" : "119105623546798083",
    "text" : "#freestuff #rt this and follow @blogkindle for a chance to win #kindlefire http:\/\/t.co\/ENbJtoF9 http:\/\/t.co\/VrI9rT6P via @BlogKindle",
    "id" : 119105623546798083,
    "created_at" : "2011-09-28 17:46:08 +0000",
    "user" : {
      "name" : "Blog Kindle",
      "screen_name" : "BlogKindle",
      "protected" : false,
      "id_str" : "42677929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/245765675\/blogkindle-logo_normal.png",
      "id" : 42677929,
      "verified" : false
    }
  },
  "id" : 119108219183439872,
  "created_at" : "2011-09-28 17:56:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/sg2K0Rw4",
      "expanded_url" : "http:\/\/goo.gl\/fb\/A7WQS",
      "display_url" : "goo.gl\/fb\/A7WQS"
    } ]
  },
  "geo" : { },
  "id_str" : "119100676365230081",
  "text" : "RT @BooksOnTheKnob: $2 Free Credit in Amazon MP3 Store http:\/\/t.co\/sg2K0Rw4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/sg2K0Rw4",
        "expanded_url" : "http:\/\/goo.gl\/fb\/A7WQS",
        "display_url" : "goo.gl\/fb\/A7WQS"
      } ]
    },
    "geo" : { },
    "id_str" : "119100213213413376",
    "text" : "$2 Free Credit in Amazon MP3 Store http:\/\/t.co\/sg2K0Rw4",
    "id" : 119100213213413376,
    "created_at" : "2011-09-28 17:24:38 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 119100676365230081,
  "created_at" : "2011-09-28 17:26:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119087640170594304",
  "text" : "not sure I'm excited about these new Kindles. hmm..",
  "id" : 119087640170594304,
  "created_at" : "2011-09-28 16:34:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Strauss",
      "screen_name" : "justjoel59",
      "indices" : [ 3, 14 ],
      "id_str" : "314087476",
      "id" : 314087476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119087059171426304",
  "text" : "RT @justjoel59: The problem is not that America is losing it's democracy, but that our elected representatives are no longer representin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119085707892490241",
    "text" : "The problem is not that America is losing it's democracy, but that our elected representatives are no longer representing us.",
    "id" : 119085707892490241,
    "created_at" : "2011-09-28 16:26:59 +0000",
    "user" : {
      "name" : "Joel Strauss",
      "screen_name" : "justjoel59",
      "protected" : false,
      "id_str" : "314087476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470042679\/DSC03663_normal.JPG",
      "id" : 314087476,
      "verified" : false
    }
  },
  "id" : 119087059171426304,
  "created_at" : "2011-09-28 16:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Strauss",
      "screen_name" : "justjoel59",
      "indices" : [ 3, 14 ],
      "id_str" : "314087476",
      "id" : 314087476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119087036358594560",
  "text" : "RT @justjoel59: Every elected official is now beholden to corporations and the rich, who do NOT have the public's best interest in mind  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119086062701260801",
    "text" : "Every elected official is now beholden to corporations and the rich, who do NOT have the public's best interest in mind or heart.",
    "id" : 119086062701260801,
    "created_at" : "2011-09-28 16:28:24 +0000",
    "user" : {
      "name" : "Joel Strauss",
      "screen_name" : "justjoel59",
      "protected" : false,
      "id_str" : "314087476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1470042679\/DSC03663_normal.JPG",
      "id" : 314087476,
      "verified" : false
    }
  },
  "id" : 119087036358594560,
  "created_at" : "2011-09-28 16:32:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 3, 15 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    }, {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 87, 99 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BannedBooksWeek",
      "indices" : [ 40, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/5v980mQO",
      "expanded_url" : "http:\/\/on.fb.me\/nNpE2r",
      "display_url" : "on.fb.me\/nNpE2r"
    } ]
  },
  "geo" : { },
  "id_str" : "119045724599095296",
  "text" : "RT @PenguinPbks: Share your blogs about #BannedBooksWeek on our FB pg. to win a set of @PenguinPbks banned books. http:\/\/t.co\/5v980mQO W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Penguin Books",
        "screen_name" : "PenguinPbks",
        "indices" : [ 70, 82 ],
        "id_str" : "735512676990849025",
        "id" : 735512676990849025
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BannedBooksWeek",
        "indices" : [ 23, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/5v980mQO",
        "expanded_url" : "http:\/\/on.fb.me\/nNpE2r",
        "display_url" : "on.fb.me\/nNpE2r"
      } ]
    },
    "geo" : { },
    "id_str" : "119041454415949824",
    "text" : "Share your blogs about #BannedBooksWeek on our FB pg. to win a set of @PenguinPbks banned books. http:\/\/t.co\/5v980mQO Winner chosen on 9\/30!",
    "id" : 119041454415949824,
    "created_at" : "2011-09-28 13:31:09 +0000",
    "user" : {
      "name" : "Penguin Books",
      "screen_name" : "PenguinBooks",
      "protected" : false,
      "id_str" : "23484629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796407064574697472\/Vm0-gZS2_normal.jpg",
      "id" : 23484629,
      "verified" : true
    }
  },
  "id" : 119045724599095296,
  "created_at" : "2011-09-28 13:48:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "indices" : [ 3, 13 ],
      "id_str" : "22380908",
      "id" : 22380908
    }, {
      "name" : "TorontoStar",
      "screen_name" : "TorontoStar",
      "indices" : [ 85, 97 ],
      "id_str" : "12848262",
      "id" : 12848262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/ejaFbyn0",
      "expanded_url" : "http:\/\/bit.ly\/p3zY3t",
      "display_url" : "bit.ly\/p3zY3t"
    } ]
  },
  "geo" : { },
  "id_str" : "118845333961846784",
  "text" : "RT @BethLayne: TheStar - Asperger's theory does about-face: http:\/\/t.co\/ejaFbyn0 via @TorontoStar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TorontoStar",
        "screen_name" : "TorontoStar",
        "indices" : [ 70, 82 ],
        "id_str" : "12848262",
        "id" : 12848262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/ejaFbyn0",
        "expanded_url" : "http:\/\/bit.ly\/p3zY3t",
        "display_url" : "bit.ly\/p3zY3t"
      } ]
    },
    "geo" : { },
    "id_str" : "118843174931279873",
    "text" : "TheStar - Asperger's theory does about-face: http:\/\/t.co\/ejaFbyn0 via @TorontoStar",
    "id" : 118843174931279873,
    "created_at" : "2011-09-28 00:23:15 +0000",
    "user" : {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "protected" : false,
      "id_str" : "22380908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796841124904116224\/6H0GAfoZ_normal.jpg",
      "id" : 22380908,
      "verified" : false
    }
  },
  "id" : 118845333961846784,
  "created_at" : "2011-09-28 00:31:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118815416448581632",
  "text" : "@SamsaricWarrior yeah, mosquitos are bad here, too",
  "id" : 118815416448581632,
  "created_at" : "2011-09-27 22:32:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Rayburn",
      "screen_name" : "topshelfebooks",
      "indices" : [ 3, 18 ],
      "id_str" : "231431785",
      "id" : 231431785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118786958729289728",
  "text" : "RT @topshelfebooks: I \u2665  books! Retweet if you're with me!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118784314027679744",
    "text" : "I \u2665  books! Retweet if you're with me!",
    "id" : 118784314027679744,
    "created_at" : "2011-09-27 20:29:22 +0000",
    "user" : {
      "name" : "Misty Rayburn",
      "screen_name" : "topshelfebooks",
      "protected" : false,
      "id_str" : "231431785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704834759629938688\/o3bRCVgp_normal.jpg",
      "id" : 231431785,
      "verified" : false
    }
  },
  "id" : 118786958729289728,
  "created_at" : "2011-09-27 20:39:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dragons Den",
      "screen_name" : "Dragons_Den",
      "indices" : [ 0, 12 ],
      "id_str" : "16958963",
      "id" : 16958963
    }, {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 27, 43 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118750980031512576",
  "geo" : { },
  "id_str" : "118753132875485185",
  "in_reply_to_user_id" : 16958963,
  "text" : "@Dragons_Den tweet this to @TheHudsonValley",
  "id" : 118753132875485185,
  "in_reply_to_status_id" : 118750980031512576,
  "created_at" : "2011-09-27 18:25:27 +0000",
  "in_reply_to_screen_name" : "Dragons_Den",
  "in_reply_to_user_id_str" : "16958963",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merralin",
      "screen_name" : "Merralin",
      "indices" : [ 0, 9 ],
      "id_str" : "4783081",
      "id" : 4783081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/nHlBtTIo",
      "expanded_url" : "http:\/\/www.bookmarktracker.com\/",
      "display_url" : "bookmarktracker.com"
    } ]
  },
  "in_reply_to_status_id_str" : "118747598986293248",
  "geo" : { },
  "id_str" : "118748984247459840",
  "in_reply_to_user_id" : 4783081,
  "text" : "@Merralin not sure if what you're looking for... http:\/\/t.co\/nHlBtTIo",
  "id" : 118748984247459840,
  "in_reply_to_status_id" : 118747598986293248,
  "created_at" : "2011-09-27 18:08:58 +0000",
  "in_reply_to_screen_name" : "Merralin",
  "in_reply_to_user_id_str" : "4783081",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118742015700774912",
  "text" : "it could be you or me...",
  "id" : 118742015700774912,
  "created_at" : "2011-09-27 17:41:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 105, 120 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/OcVqcsvi",
      "expanded_url" : "http:\/\/huff.to\/oLXI7I",
      "display_url" : "huff.to\/oLXI7I"
    } ]
  },
  "geo" : { },
  "id_str" : "118741875007029248",
  "text" : "RT @DarciaHelle: If You Take Away The Death Penalty, There's Justice All Around http:\/\/t.co\/OcVqcsvi via @huffingtonpost",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 88, 103 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/OcVqcsvi",
        "expanded_url" : "http:\/\/huff.to\/oLXI7I",
        "display_url" : "huff.to\/oLXI7I"
      } ]
    },
    "geo" : { },
    "id_str" : "118736210666598400",
    "text" : "If You Take Away The Death Penalty, There's Justice All Around http:\/\/t.co\/OcVqcsvi via @huffingtonpost",
    "id" : 118736210666598400,
    "created_at" : "2011-09-27 17:18:13 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 118741875007029248,
  "created_at" : "2011-09-27 17:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118662514715271168",
  "text" : "she has also taken to sleeping in sissy's room after going out",
  "id" : 118662514715271168,
  "created_at" : "2011-09-27 12:25:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118662176780193793",
  "text" : "its like having a baby again..dog getting up every night to go out...",
  "id" : 118662176780193793,
  "created_at" : "2011-09-27 12:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 3, 15 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StayTuned",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118661687279759361",
  "text" : "RT @PenguinPbks: Hello Fellow Tweeters. Get ready for a day of bookish links and giveaways! #StayTuned",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StayTuned",
        "indices" : [ 75, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118659084403744768",
    "text" : "Hello Fellow Tweeters. Get ready for a day of bookish links and giveaways! #StayTuned",
    "id" : 118659084403744768,
    "created_at" : "2011-09-27 12:11:44 +0000",
    "user" : {
      "name" : "Penguin Books",
      "screen_name" : "PenguinBooks",
      "protected" : false,
      "id_str" : "23484629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796407064574697472\/Vm0-gZS2_normal.jpg",
      "id" : 23484629,
      "verified" : true
    }
  },
  "id" : 118661687279759361,
  "created_at" : "2011-09-27 12:22:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "indices" : [ 3, 12 ],
      "id_str" : "48164887",
      "id" : 48164887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 106, 112 ]
    }, {
      "text" : "senryu",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118661614646988800",
  "text" : "RT @amoz1939: flock of crows on branch ~ watch school children walk to school ~ food packs in school bags #haiku #senryu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 92, 98 ]
      }, {
        "text" : "senryu",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118659767639089153",
    "text" : "flock of crows on branch ~ watch school children walk to school ~ food packs in school bags #haiku #senryu",
    "id" : 118659767639089153,
    "created_at" : "2011-09-27 12:14:27 +0000",
    "user" : {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "protected" : false,
      "id_str" : "48164887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775135706238758913\/cwiqEl_8_normal.jpg",
      "id" : 48164887,
      "verified" : false
    }
  },
  "id" : 118661614646988800,
  "created_at" : "2011-09-27 12:21:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newfy lover (\u0693\u05F2)",
      "screen_name" : "newfylover1",
      "indices" : [ 3, 15 ],
      "id_str" : "55337635",
      "id" : 55337635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118661345569800192",
  "text" : "RT @newfylover1: Normal people scare me...stupid people annoy me... and the crazy and wild people are the ones I am friends with.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118660457623060481",
    "text" : "Normal people scare me...stupid people annoy me... and the crazy and wild people are the ones I am friends with.",
    "id" : 118660457623060481,
    "created_at" : "2011-09-27 12:17:12 +0000",
    "user" : {
      "name" : "Newfy lover (\u0693\u05F2)",
      "screen_name" : "newfylover1",
      "protected" : false,
      "id_str" : "55337635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1747815949\/DSCN1241_-_Copy_-_Copy_-_Copy_normal.JPG",
      "id" : 55337635,
      "verified" : false
    }
  },
  "id" : 118661345569800192,
  "created_at" : "2011-09-27 12:20:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118421341111201792",
  "text" : "I don't like Fall. It's so deceptive.",
  "id" : 118421341111201792,
  "created_at" : "2011-09-26 20:27:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrimCommand",
      "screen_name" : "GrimCommand",
      "indices" : [ 3, 15 ],
      "id_str" : "18044241",
      "id" : 18044241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Baby",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "Elk",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "Standing",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "Shadow",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "Gather",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/FzAKKLnb",
      "expanded_url" : "http:\/\/goo.gl\/Zo9bB",
      "display_url" : "goo.gl\/Zo9bB"
    } ]
  },
  "geo" : { },
  "id_str" : "118384176604004352",
  "text" : "RT @GrimCommand: A #Baby #Elk #Standing in the #Shadow | #Gather - http:\/\/t.co\/FzAKKLnb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Baby",
        "indices" : [ 2, 7 ]
      }, {
        "text" : "Elk",
        "indices" : [ 8, 12 ]
      }, {
        "text" : "Standing",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "Shadow",
        "indices" : [ 30, 37 ]
      }, {
        "text" : "Gather",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/FzAKKLnb",
        "expanded_url" : "http:\/\/goo.gl\/Zo9bB",
        "display_url" : "goo.gl\/Zo9bB"
      } ]
    },
    "geo" : { },
    "id_str" : "118116252030996480",
    "text" : "A #Baby #Elk #Standing in the #Shadow | #Gather - http:\/\/t.co\/FzAKKLnb",
    "id" : 118116252030996480,
    "created_at" : "2011-09-26 00:14:43 +0000",
    "user" : {
      "name" : "GrimCommand",
      "screen_name" : "GrimCommand",
      "protected" : false,
      "id_str" : "18044241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67080546\/th_eyes_normal.gif",
      "id" : 18044241,
      "verified" : false
    }
  },
  "id" : 118384176604004352,
  "created_at" : "2011-09-26 17:59:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118377758765219840",
  "text" : "RT @SpiritualNurse: Some people strengthen society just by being the kind of people they are. - John W. Gardner",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118377146350714880",
    "text" : "Some people strengthen society just by being the kind of people they are. - John W. Gardner",
    "id" : 118377146350714880,
    "created_at" : "2011-09-26 17:31:25 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 118377758765219840,
  "created_at" : "2011-09-26 17:33:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 3, 16 ],
      "id_str" : "19658826",
      "id" : 19658826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/C5o9yVM1",
      "expanded_url" : "http:\/\/bit.ly\/q0FuPb",
      "display_url" : "bit.ly\/q0FuPb"
    } ]
  },
  "geo" : { },
  "id_str" : "118376762005655552",
  "text" : "RT @newscientist: How do you smuggle a pacemaker into an MRI? With an invisibility cloak for magnets, of course http:\/\/t.co\/C5o9yVM1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/C5o9yVM1",
        "expanded_url" : "http:\/\/bit.ly\/q0FuPb",
        "display_url" : "bit.ly\/q0FuPb"
      } ]
    },
    "geo" : { },
    "id_str" : "118375668231847936",
    "text" : "How do you smuggle a pacemaker into an MRI? With an invisibility cloak for magnets, of course http:\/\/t.co\/C5o9yVM1",
    "id" : 118375668231847936,
    "created_at" : "2011-09-26 17:25:33 +0000",
    "user" : {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "protected" : false,
      "id_str" : "19658826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464088830509731840\/e92TpMR9_normal.png",
      "id" : 19658826,
      "verified" : true
    }
  },
  "id" : 118376762005655552,
  "created_at" : "2011-09-26 17:29:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118374393217953792",
  "text" : "RT @JeremyCShipp: So far my time machine only goes forward one second at a time, but I think I\u2019m making progress.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118374243728756736",
    "text" : "So far my time machine only goes forward one second at a time, but I think I\u2019m making progress.",
    "id" : 118374243728756736,
    "created_at" : "2011-09-26 17:19:53 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 118374393217953792,
  "created_at" : "2011-09-26 17:20:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118129311155888128",
  "text" : "RT @JosephRanseth: On the off chance that you haven't heard it yet today: You Are Amazing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118128739950407680",
    "text" : "On the off chance that you haven't heard it yet today: You Are Amazing.",
    "id" : 118128739950407680,
    "created_at" : "2011-09-26 01:04:20 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 118129311155888128,
  "created_at" : "2011-09-26 01:06:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Diana Samalot",
      "screen_name" : "dsamalot",
      "indices" : [ 21, 30 ],
      "id_str" : "73278152",
      "id" : 73278152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118127075755442177",
  "text" : "RT @DwayneReaves: RT @dsamalot: To have more than you've got, become more than you are.Jim Rohn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Diana Samalot",
        "screen_name" : "dsamalot",
        "indices" : [ 3, 12 ],
        "id_str" : "73278152",
        "id" : 73278152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118120049725804544",
    "text" : "RT @dsamalot: To have more than you've got, become more than you are.Jim Rohn",
    "id" : 118120049725804544,
    "created_at" : "2011-09-26 00:29:49 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 118127075755442177,
  "created_at" : "2011-09-26 00:57:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118094844408233984",
  "geo" : { },
  "id_str" : "118095267991003136",
  "in_reply_to_user_id" : 155031802,
  "text" : "@iKrisBee LOL",
  "id" : 118095267991003136,
  "in_reply_to_status_id" : 118094844408233984,
  "created_at" : "2011-09-25 22:51:20 +0000",
  "in_reply_to_screen_name" : "krisrandom",
  "in_reply_to_user_id_str" : "155031802",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118089267586150400",
  "text" : "RT @taraburner: We didn't lose the game; we just ran out of time.  ~Vince Lombardi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118088158930944000",
    "text" : "We didn't lose the game; we just ran out of time.  ~Vince Lombardi",
    "id" : 118088158930944000,
    "created_at" : "2011-09-25 22:23:05 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 118089267586150400,
  "created_at" : "2011-09-25 22:27:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117989184244953088",
  "geo" : { },
  "id_str" : "117990012888416256",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver what a lovely face \u2665",
  "id" : 117990012888416256,
  "in_reply_to_status_id" : 117989184244953088,
  "created_at" : "2011-09-25 15:53:05 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117970825755373568",
  "text" : "all of politics is just a game that the powerful & wealthy play. its got nothing to do with making life better.",
  "id" : 117970825755373568,
  "created_at" : "2011-09-25 14:36:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/tFAjdO4h",
      "expanded_url" : "http:\/\/tinyurl.com\/3jo8cs9",
      "display_url" : "tinyurl.com\/3jo8cs9"
    } ]
  },
  "geo" : { },
  "id_str" : "117965241228337152",
  "text" : "RT @JeremyCShipp: Could you please help me spread the word about the Kindle 3G Giveaway on my blog? http:\/\/t.co\/tFAjdO4h #kindle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/tFAjdO4h",
        "expanded_url" : "http:\/\/tinyurl.com\/3jo8cs9",
        "display_url" : "tinyurl.com\/3jo8cs9"
      } ]
    },
    "geo" : { },
    "id_str" : "117963821376733186",
    "text" : "Could you please help me spread the word about the Kindle 3G Giveaway on my blog? http:\/\/t.co\/tFAjdO4h #kindle",
    "id" : 117963821376733186,
    "created_at" : "2011-09-25 14:09:01 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 117965241228337152,
  "created_at" : "2011-09-25 14:14:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 0, 13 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117963821376733186",
  "geo" : { },
  "id_str" : "117965140497924096",
  "in_reply_to_user_id" : 17374293,
  "text" : "@JeremyCShipp feel free to add to readerswin.com site : )",
  "id" : 117965140497924096,
  "in_reply_to_status_id" : 117963821376733186,
  "created_at" : "2011-09-25 14:14:15 +0000",
  "in_reply_to_screen_name" : "JeremyCShipp",
  "in_reply_to_user_id_str" : "17374293",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "indices" : [ 3, 13 ],
      "id_str" : "62554155",
      "id" : 62554155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117954561389510656",
  "text" : "RT @ceebee308: COFFEE!!!! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117952877418385410",
    "text" : "COFFEE!!!! :)",
    "id" : 117952877418385410,
    "created_at" : "2011-09-25 13:25:32 +0000",
    "user" : {
      "name" : "Claude Bouchard",
      "screen_name" : "ceebee308",
      "protected" : false,
      "id_str" : "62554155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709795772636729345\/llpY2LN7_normal.jpg",
      "id" : 62554155,
      "verified" : false
    }
  },
  "id" : 117954561389510656,
  "created_at" : "2011-09-25 13:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117954477063012352",
  "text" : "my local library has kindle books.. yay! of course, most of them are on waiting list. now got to renew my library card.",
  "id" : 117954477063012352,
  "created_at" : "2011-09-25 13:31:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    }, {
      "name" : "Causes and Effects",
      "screen_name" : "CausesEffects",
      "indices" : [ 23, 37 ],
      "id_str" : "33338245",
      "id" : 33338245
    }, {
      "name" : "Aine Belton",
      "screen_name" : "AineBelton",
      "indices" : [ 42, 53 ],
      "id_str" : "24859536",
      "id" : 24859536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117773557995544576",
  "text" : "RT @AnAmericanMonk: RT @CausesEffects: RT @AineBelton Be a lamp, a lifeboat, a ladder. Help someone's Soul heal. Walk out of your house  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Causes and Effects",
        "screen_name" : "CausesEffects",
        "indices" : [ 3, 17 ],
        "id_str" : "33338245",
        "id" : 33338245
      }, {
        "name" : "Aine Belton",
        "screen_name" : "AineBelton",
        "indices" : [ 22, 33 ],
        "id_str" : "24859536",
        "id" : 24859536
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117773355045761024",
    "text" : "RT @CausesEffects: RT @AineBelton Be a lamp, a lifeboat, a ladder. Help someone's Soul heal. Walk out of your house like a shepherd ~Rumi",
    "id" : 117773355045761024,
    "created_at" : "2011-09-25 01:32:10 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 117773557995544576,
  "created_at" : "2011-09-25 01:32:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/aTn1nwZG",
      "expanded_url" : "http:\/\/lockerz.com\/s\/141728858",
      "display_url" : "lockerz.com\/s\/141728858"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/I3gQ1qTP",
      "expanded_url" : "http:\/\/lockerz.com\/s\/141728955",
      "display_url" : "lockerz.com\/s\/141728955"
    } ]
  },
  "geo" : { },
  "id_str" : "117773130012958720",
  "text" : "RT @mimismutts: If you don't like these from a few minutes ago, you're not a sunset person http:\/\/t.co\/aTn1nwZG http:\/\/t.co\/I3gQ1qTP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/aTn1nwZG",
        "expanded_url" : "http:\/\/lockerz.com\/s\/141728858",
        "display_url" : "lockerz.com\/s\/141728858"
      }, {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/I3gQ1qTP",
        "expanded_url" : "http:\/\/lockerz.com\/s\/141728955",
        "display_url" : "lockerz.com\/s\/141728955"
      } ]
    },
    "geo" : { },
    "id_str" : "117772702827294720",
    "text" : "If you don't like these from a few minutes ago, you're not a sunset person http:\/\/t.co\/aTn1nwZG http:\/\/t.co\/I3gQ1qTP",
    "id" : 117772702827294720,
    "created_at" : "2011-09-25 01:29:35 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 117773130012958720,
  "created_at" : "2011-09-25 01:31:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Brown",
      "screen_name" : "FrugaleReader",
      "indices" : [ 3, 17 ],
      "id_str" : "199456136",
      "id" : 199456136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/m4eXui3l",
      "expanded_url" : "http:\/\/nblo.gs\/nxXKK",
      "display_url" : "nblo.gs\/nxXKK"
    } ]
  },
  "geo" : { },
  "id_str" : "117732450217631744",
  "text" : "RT @FrugaleReader: A \u007BSpecial\u007D Saturday Giveaway: A Kindle Copy of Water for Elephants! http:\/\/t.co\/m4eXui3l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/m4eXui3l",
        "expanded_url" : "http:\/\/nblo.gs\/nxXKK",
        "display_url" : "nblo.gs\/nxXKK"
      } ]
    },
    "geo" : { },
    "id_str" : "117727937393995776",
    "text" : "A \u007BSpecial\u007D Saturday Giveaway: A Kindle Copy of Water for Elephants! http:\/\/t.co\/m4eXui3l",
    "id" : 117727937393995776,
    "created_at" : "2011-09-24 22:31:42 +0000",
    "user" : {
      "name" : "Elizabeth Brown",
      "screen_name" : "FrugaleReader",
      "protected" : false,
      "id_str" : "199456136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1322880132\/ETB_Photo_TEOTP_normal.jpg",
      "id" : 199456136,
      "verified" : false
    }
  },
  "id" : 117732450217631744,
  "created_at" : "2011-09-24 22:49:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenda Wallace",
      "screen_name" : "BrendaBWallace",
      "indices" : [ 3, 18 ],
      "id_str" : "40580919",
      "id" : 40580919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117673292822872064",
  "text" : "RT @BrendaBWallace: Giving away Kindle Oct 8 to launch BRILLIANT PREY up to #21 Psych Thrillers. Just RT to enter (Only 99 cents) http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAN1",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/pnPw1Tku",
        "expanded_url" : "http:\/\/tinyurl.com\/3jrugaq",
        "display_url" : "tinyurl.com\/3jrugaq"
      } ]
    },
    "geo" : { },
    "id_str" : "117662528774995968",
    "text" : "Giving away Kindle Oct 8 to launch BRILLIANT PREY up to #21 Psych Thrillers. Just RT to enter (Only 99 cents) http:\/\/t.co\/pnPw1Tku #IAN1 THX",
    "id" : 117662528774995968,
    "created_at" : "2011-09-24 18:11:47 +0000",
    "user" : {
      "name" : "Brenda Wallace",
      "screen_name" : "BrendaBWallace",
      "protected" : false,
      "id_str" : "40580919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598671832196087808\/8xuhEKh2_normal.jpg",
      "id" : 40580919,
      "verified" : false
    }
  },
  "id" : 117673292822872064,
  "created_at" : "2011-09-24 18:54:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blurb",
      "screen_name" : "BlurbBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "18958606",
      "id" : 18958606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/DDu2sBtH",
      "expanded_url" : "http:\/\/bit.ly\/nrxhQY",
      "display_url" : "bit.ly\/nrxhQY"
    } ]
  },
  "geo" : { },
  "id_str" : "117672732417724416",
  "text" : "RT @BlurbBooks: Scientists reconstruct what the eye sees http:\/\/t.co\/DDu2sBtH or to paraphrase Isherwood: You are a camera with its shut ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/DDu2sBtH",
        "expanded_url" : "http:\/\/bit.ly\/nrxhQY",
        "display_url" : "bit.ly\/nrxhQY"
      } ]
    },
    "geo" : { },
    "id_str" : "117319939114811392",
    "text" : "Scientists reconstruct what the eye sees http:\/\/t.co\/DDu2sBtH or to paraphrase Isherwood: You are a camera with its shutter open...",
    "id" : 117319939114811392,
    "created_at" : "2011-09-23 19:30:27 +0000",
    "user" : {
      "name" : "Blurb",
      "screen_name" : "BlurbBooks",
      "protected" : false,
      "id_str" : "18958606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745037832842969088\/3usfLVH-_normal.jpg",
      "id" : 18958606,
      "verified" : true
    }
  },
  "id" : 117672732417724416,
  "created_at" : "2011-09-24 18:52:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117639507330867200",
  "text" : "also, if you see life as black\/white.. you're wrong! nanananabooboo",
  "id" : 117639507330867200,
  "created_at" : "2011-09-24 16:40:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117639199687049216",
  "text" : "WHY do ppl argue w those whom they deem wrong? gets nowhere. must like the drama? want to scream!",
  "id" : 117639199687049216,
  "created_at" : "2011-09-24 16:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Holloway100%\u2665",
      "screen_name" : "RoadHog444",
      "indices" : [ 3, 14 ],
      "id_str" : "15877727",
      "id" : 15877727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/jRlPWNLB",
      "expanded_url" : "http:\/\/bit.ly\/qPybau",
      "display_url" : "bit.ly\/qPybau"
    }, {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/ViWMFRl7",
      "expanded_url" : "http:\/\/bit.ly\/oeuaiI",
      "display_url" : "bit.ly\/oeuaiI"
    } ]
  },
  "geo" : { },
  "id_str" : "117638070853042176",
  "text" : "RT @RoadHog444: White Squirrel http:\/\/t.co\/jRlPWNLB this girl is hard to catch\u2026 on camera [Like it? http:\/\/t.co\/ViWMFRl7 ]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.likemytweets.com\/\" rel=\"nofollow\"\u003ELike My Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/jRlPWNLB",
        "expanded_url" : "http:\/\/bit.ly\/qPybau",
        "display_url" : "bit.ly\/qPybau"
      }, {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/ViWMFRl7",
        "expanded_url" : "http:\/\/bit.ly\/oeuaiI",
        "display_url" : "bit.ly\/oeuaiI"
      } ]
    },
    "geo" : { },
    "id_str" : "117634976782102528",
    "text" : "White Squirrel http:\/\/t.co\/jRlPWNLB this girl is hard to catch\u2026 on camera [Like it? http:\/\/t.co\/ViWMFRl7 ]",
    "id" : 117634976782102528,
    "created_at" : "2011-09-24 16:22:18 +0000",
    "user" : {
      "name" : "James Holloway100%\u2665",
      "screen_name" : "RoadHog444",
      "protected" : false,
      "id_str" : "15877727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/58375108\/James-Roadhog-Holloway_normal.jpg",
      "id" : 15877727,
      "verified" : false
    }
  },
  "id" : 117638070853042176,
  "created_at" : "2011-09-24 16:34:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117622453102059520",
  "text" : "@XNutsyX awww, thanks ((hugs)) I so enjoyed putting it together. It really does express who I am : )",
  "id" : 117622453102059520,
  "created_at" : "2011-09-24 15:32:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/T2IT1niJ",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "117621947256418304",
  "text" : "btw, I moved my blog from my abfabgab.com to http:\/\/t.co\/T2IT1niJ (I forget why now..lol)",
  "id" : 117621947256418304,
  "created_at" : "2011-09-24 15:30:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/US0bxtLc",
      "expanded_url" : "http:\/\/www.abfabgab.com",
      "display_url" : "abfabgab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "117621410402283520",
  "text" : "Have you seen my website? It's a labor of love \u2665 http:\/\/t.co\/US0bxtLc",
  "id" : 117621410402283520,
  "created_at" : "2011-09-24 15:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dega Omar",
      "screen_name" : "degamuna",
      "indices" : [ 3, 12 ],
      "id_str" : "27186150",
      "id" : 27186150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyWallStreet",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117613930376990720",
  "text" : "RT @degamuna: We are too broke to pay for education and healthcare but we can afford a war in Libya, Iraq and Afghanistan. #OccupyWallStreet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyWallStreet",
        "indices" : [ 109, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116981613363068928",
    "text" : "We are too broke to pay for education and healthcare but we can afford a war in Libya, Iraq and Afghanistan. #OccupyWallStreet",
    "id" : 116981613363068928,
    "created_at" : "2011-09-22 21:06:04 +0000",
    "user" : {
      "name" : "Dega Omar",
      "screen_name" : "degamuna",
      "protected" : false,
      "id_str" : "27186150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1518561763\/me_normal.jpg",
      "id" : 27186150,
      "verified" : false
    }
  },
  "id" : 117613930376990720,
  "created_at" : "2011-09-24 14:58:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CosmicConsciousness",
      "indices" : [ 18, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117612398499733505",
  "text" : "RT @DeepakChopra: #CosmicConsciousness We came from the light, the place where the light came into being of its own accord--Gospel of Thomas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117611902913347584",
    "text" : "#CosmicConsciousness We came from the light, the place where the light came into being of its own accord--Gospel of Thomas",
    "id" : 117611902913347584,
    "created_at" : "2011-09-24 14:50:37 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 117612398499733505,
  "created_at" : "2011-09-24 14:52:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookDragon",
      "screen_name" : "SIBookDragon",
      "indices" : [ 3, 16 ],
      "id_str" : "31204566",
      "id" : 31204566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BannedBooksWeek",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117609206231740416",
  "text" : "RT @SIBookDragon: #BannedBooksWeek begins today through Oct. 1 And THIS is what keeps making it to the top of the banned list: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BannedBooksWeek",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/MMST3EGM",
        "expanded_url" : "http:\/\/bit.ly\/qjTyHg",
        "display_url" : "bit.ly\/qjTyHg"
      } ]
    },
    "geo" : { },
    "id_str" : "117601824395108352",
    "text" : "#BannedBooksWeek begins today through Oct. 1 And THIS is what keeps making it to the top of the banned list: http:\/\/t.co\/MMST3EGM",
    "id" : 117601824395108352,
    "created_at" : "2011-09-24 14:10:34 +0000",
    "user" : {
      "name" : "BookDragon",
      "screen_name" : "SIBookDragon",
      "protected" : false,
      "id_str" : "31204566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463365960523452416\/JloCenEu_normal.jpeg",
      "id" : 31204566,
      "verified" : false
    }
  },
  "id" : 117609206231740416,
  "created_at" : "2011-09-24 14:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Bryant",
      "screen_name" : "tsutrav",
      "indices" : [ 3, 11 ],
      "id_str" : "14764911",
      "id" : 14764911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tablet",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "kindle4",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/FZXLQppp",
      "expanded_url" : "http:\/\/dthin.gs\/n7keWW",
      "display_url" : "dthin.gs\/n7keWW"
    } ]
  },
  "geo" : { },
  "id_str" : "117592027444686848",
  "text" : "RT @tsutrav: Amazon has announced a Press Conference for Sept.28th 10a NYC-time. http:\/\/t.co\/FZXLQppp #tablet #kindle4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tablet",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "kindle4",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/FZXLQppp",
        "expanded_url" : "http:\/\/dthin.gs\/n7keWW",
        "display_url" : "dthin.gs\/n7keWW"
      } ]
    },
    "geo" : { },
    "id_str" : "117588608147398657",
    "text" : "Amazon has announced a Press Conference for Sept.28th 10a NYC-time. http:\/\/t.co\/FZXLQppp #tablet #kindle4",
    "id" : 117588608147398657,
    "created_at" : "2011-09-24 13:18:03 +0000",
    "user" : {
      "name" : "Travis Bryant",
      "screen_name" : "tsutrav",
      "protected" : false,
      "id_str" : "14764911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817697339\/twitterProfilePhoto_normal.jpg",
      "id" : 14764911,
      "verified" : false
    }
  },
  "id" : 117592027444686848,
  "created_at" : "2011-09-24 13:31:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117591615761166337",
  "text" : "RT @TheEntertainer: What excites you that you're NOT doing? Now STOP IT, and start doing it, what's the matter with you! Avoid ALL... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/JOBbN1Qm",
        "expanded_url" : "http:\/\/fb.me\/VHV47ci9",
        "display_url" : "fb.me\/VHV47ci9"
      } ]
    },
    "geo" : { },
    "id_str" : "117590046156128256",
    "text" : "What excites you that you're NOT doing? Now STOP IT, and start doing it, what's the matter with you! Avoid ALL... http:\/\/t.co\/JOBbN1Qm",
    "id" : 117590046156128256,
    "created_at" : "2011-09-24 13:23:46 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 117591615761166337,
  "created_at" : "2011-09-24 13:30:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117589996315213824",
  "text" : "RT @CrystalLewis: Never look down on anybody unless you're helping him up. ~ Jesse Jackson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117587361990316032",
    "text" : "Never look down on anybody unless you're helping him up. ~ Jesse Jackson",
    "id" : 117587361990316032,
    "created_at" : "2011-09-24 13:13:06 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 117589996315213824,
  "created_at" : "2011-09-24 13:23:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/uiR9WZ1v",
      "expanded_url" : "http:\/\/amzn.to\/qQdwLc",
      "display_url" : "amzn.to\/qQdwLc"
    } ]
  },
  "geo" : { },
  "id_str" : "117402915697733632",
  "text" : "@tragic_pizza im reading Angel of Death Row: My Life as a Death Penalty Defense Lawyer http:\/\/t.co\/uiR9WZ1v",
  "id" : 117402915697733632,
  "created_at" : "2011-09-24 01:00:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 39, 53 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 58, 73 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117390304142831617",
  "text" : "@tragic_pizza I talk to capybaras like @GaribaldiRous  or @hippopotatomus (Dobby) .. LOL",
  "id" : 117390304142831617,
  "created_at" : "2011-09-24 00:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "117346122682470400",
  "geo" : { },
  "id_str" : "117363199556325377",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous LOL",
  "id" : 117363199556325377,
  "in_reply_to_status_id" : 117346122682470400,
  "created_at" : "2011-09-23 22:22:21 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeTheMatch",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/5iFqABUF",
      "expanded_url" : "http:\/\/marrow.org\/Get_Involved\/Connect\/Spread_the_Word.aspx?src=enews",
      "display_url" : "marrow.org\/Get_Involved\/C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117348865077805057",
  "text" : "#BeTheMatch - Spread the Word http:\/\/t.co\/5iFqABUF",
  "id" : 117348865077805057,
  "created_at" : "2011-09-23 21:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 19, 34 ],
      "id_str" : "140291463",
      "id" : 140291463
    }, {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 35, 45 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 46, 59 ],
      "id_str" : "44101564",
      "id" : 44101564
    }, {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 60, 72 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 73, 82 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 83, 95 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 15, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117346055112241153",
  "text" : "awesome peeps! #FF @skypilotofhope @Matth3ous @Joeandrasi93 @AlisynGayle @JohnCali @fearfuldogs \u2665",
  "id" : 117346055112241153,
  "created_at" : "2011-09-23 21:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ancient Proverbs",
      "screen_name" : "AncientProverbs",
      "indices" : [ 3, 19 ],
      "id_str" : "226922556",
      "id" : 226922556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117344703350964224",
  "text" : "RT @AncientProverbs: One who is injured ought not to return the injury, for on no account can it be right to do an injustice. -Socrates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116768289471991808",
    "text" : "One who is injured ought not to return the injury, for on no account can it be right to do an injustice. -Socrates",
    "id" : 116768289471991808,
    "created_at" : "2011-09-22 06:58:24 +0000",
    "user" : {
      "name" : "Sports Motivation",
      "screen_name" : "Sports_HQ",
      "protected" : false,
      "id_str" : "139986343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2679035753\/b0d2eb7d0b01e7381bd8ca944b055f60_normal.jpeg",
      "id" : 139986343,
      "verified" : false
    }
  },
  "id" : 117344703350964224,
  "created_at" : "2011-09-23 21:08:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/PhTBacwv",
      "expanded_url" : "http:\/\/amzn.to\/nGgWPe",
      "display_url" : "amzn.to\/nGgWPe"
    } ]
  },
  "geo" : { },
  "id_str" : "117343857036886017",
  "text" : "My Highlights: Angel of Death Row: My Life as a Death Penalty Defense Lawyer http:\/\/t.co\/PhTBacwv",
  "id" : 117343857036886017,
  "created_at" : "2011-09-23 21:05:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmytry Karpov",
      "screen_name" : "DmytryKarpov",
      "indices" : [ 3, 16 ],
      "id_str" : "176332199",
      "id" : 176332199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117334952969908225",
  "text" : "RT @DmytryKarpov: RT this for a chance to win a free copy of Dark Edge. \"Tales that will suck you in, chew you up, and leave you begging ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117328646548619264",
    "text" : "RT this for a chance to win a free copy of Dark Edge. \"Tales that will suck you in, chew you up, and leave you begging for more\"-Lmstull",
    "id" : 117328646548619264,
    "created_at" : "2011-09-23 20:05:03 +0000",
    "user" : {
      "name" : "Dmytry Karpov",
      "screen_name" : "DmytryKarpov",
      "protected" : false,
      "id_str" : "176332199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1705590424\/D_author_profile_pic_2_optomized_normal",
      "id" : 176332199,
      "verified" : false
    }
  },
  "id" : 117334952969908225,
  "created_at" : "2011-09-23 20:30:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "HikiMadwoman",
      "screen_name" : "HikiMadwoman",
      "indices" : [ 26, 39 ],
      "id_str" : "80726149",
      "id" : 80726149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117324246862151680",
  "text" : "RT @CoyoteSings: Snap! RT @HikiMadwoman: i keep thinking of \"toliet seat girl\" from dead like me. i miss that show.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HikiMadwoman",
        "screen_name" : "HikiMadwoman",
        "indices" : [ 9, 22 ],
        "id_str" : "80726149",
        "id" : 80726149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117322733947330561",
    "text" : "Snap! RT @HikiMadwoman: i keep thinking of \"toliet seat girl\" from dead like me. i miss that show.",
    "id" : 117322733947330561,
    "created_at" : "2011-09-23 19:41:34 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 117324246862151680,
  "created_at" : "2011-09-23 19:47:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "indices" : [ 3, 16 ],
      "id_str" : "15175368",
      "id" : 15175368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/I8COKpnR",
      "expanded_url" : "http:\/\/bit.ly\/qiIJu3",
      "display_url" : "bit.ly\/qiIJu3"
    } ]
  },
  "geo" : { },
  "id_str" : "117304885195714561",
  "text" : "RT @theofficenbc: VIDEO: \"Basically you lie like a plank in weird places. That's it. Sometimes you get run over.\" http:\/\/t.co\/I8COKpnR # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theoffice",
        "indices" : [ 117, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/I8COKpnR",
        "expanded_url" : "http:\/\/bit.ly\/qiIJu3",
        "display_url" : "bit.ly\/qiIJu3"
      } ]
    },
    "geo" : { },
    "id_str" : "117302644204249088",
    "text" : "VIDEO: \"Basically you lie like a plank in weird places. That's it. Sometimes you get run over.\" http:\/\/t.co\/I8COKpnR #theoffice",
    "id" : 117302644204249088,
    "created_at" : "2011-09-23 18:21:44 +0000",
    "user" : {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "protected" : false,
      "id_str" : "15175368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3672312614\/17217191debc391b060a6798b6c2ad10_normal.jpeg",
      "id" : 15175368,
      "verified" : true
    }
  },
  "id" : 117304885195714561,
  "created_at" : "2011-09-23 18:30:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "indices" : [ 85, 100 ],
      "id_str" : "7622122",
      "id" : 7622122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/uTxXlZYW",
      "expanded_url" : "http:\/\/bit.ly\/oONghj",
      "display_url" : "bit.ly\/oONghj"
    } ]
  },
  "geo" : { },
  "id_str" : "117295503376527360",
  "text" : "Win A Spot In The Virtual Indie Craft Fair | IndieBizChicks.com http:\/\/t.co\/uTxXlZYW @indiebizchicks",
  "id" : 117295503376527360,
  "created_at" : "2011-09-23 17:53:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BestDayEver",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117266765691629568",
  "text" : "RT @JosephRanseth: Today's Challenge: Believe that you can change someone's life for the better, then act it out. #BestDayEver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BestDayEver",
        "indices" : [ 95, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117266198575591427",
    "text" : "Today's Challenge: Believe that you can change someone's life for the better, then act it out. #BestDayEver",
    "id" : 117266198575591427,
    "created_at" : "2011-09-23 15:56:55 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 117266765691629568,
  "created_at" : "2011-09-23 15:59:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117266573001113600",
  "text" : "just to clarify.. I like being an Eeyore. Tigger is just too bouncy for me..lol.",
  "id" : 117266573001113600,
  "created_at" : "2011-09-23 15:58:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117266133073145856",
  "text" : "I will never be a Tigger. I am an Eeyore all the way through.",
  "id" : 117266133073145856,
  "created_at" : "2011-09-23 15:56:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin",
      "screen_name" : "infpBlog",
      "indices" : [ 3, 12 ],
      "id_str" : "48772319",
      "id" : 48772319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/HkcgXbTo",
      "expanded_url" : "https:\/\/twitter.com\/#!\/infpBlog\/lists",
      "display_url" : "twitter.com\/#!\/infpBlog\/li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117265878797656065",
  "text" : "RT @infpBlog: So far almost 2500 INFPs on my lists - http:\/\/t.co\/HkcgXbTo - that have tweeted that they were INFPs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/HkcgXbTo",
        "expanded_url" : "https:\/\/twitter.com\/#!\/infpBlog\/lists",
        "display_url" : "twitter.com\/#!\/infpBlog\/li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "117264457645834240",
    "text" : "So far almost 2500 INFPs on my lists - http:\/\/t.co\/HkcgXbTo - that have tweeted that they were INFPs.",
    "id" : 117264457645834240,
    "created_at" : "2011-09-23 15:50:00 +0000",
    "user" : {
      "name" : "Corin",
      "screen_name" : "infpBlog",
      "protected" : false,
      "id_str" : "48772319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1423053271\/avatar4768_3.gif_normal.jpg",
      "id" : 48772319,
      "verified" : false
    }
  },
  "id" : 117265878797656065,
  "created_at" : "2011-09-23 15:55:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117247853939798018",
  "text" : "RT @DharmaTalks: Little things asked of us add up, contributing to the shift in consciousness. One drop can create hundreds of ripples.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117246875421249536",
    "text" : "Little things asked of us add up, contributing to the shift in consciousness. One drop can create hundreds of ripples.",
    "id" : 117246875421249536,
    "created_at" : "2011-09-23 14:40:08 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 117247853939798018,
  "created_at" : "2011-09-23 14:44:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 73, 85 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridayreads",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117241052804550657",
  "text" : "#fridayreads Reading book 2 of The Left Hand of God trilogy - loving it! @DuttonBooks",
  "id" : 117241052804550657,
  "created_at" : "2011-09-23 14:16:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "indices" : [ 3, 15 ],
      "id_str" : "17210956",
      "id" : 17210956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117239921747570688",
  "text" : "RT @kempruffner: There are two theories about arguing with women. Neither one works.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117239333806800897",
    "text" : "There are two theories about arguing with women. Neither one works.",
    "id" : 117239333806800897,
    "created_at" : "2011-09-23 14:10:10 +0000",
    "user" : {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "protected" : false,
      "id_str" : "17210956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63757772\/china_bike_normal.jpg",
      "id" : 17210956,
      "verified" : false
    }
  },
  "id" : 117239921747570688,
  "created_at" : "2011-09-23 14:12:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117239054600380416",
  "text" : "@SamsaricWarrior omg'ness.. agree 100%.. have learned waaay more from my DD than could have alone!",
  "id" : 117239054600380416,
  "created_at" : "2011-09-23 14:09:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 8, 23 ],
      "id_str" : "62867227",
      "id" : 62867227
    }, {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 38, 51 ],
      "id_str" : "42974138",
      "id" : 42974138
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 52, 65 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 66, 78 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 79, 90 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 108, 115 ],
      "id_str" : "122393631",
      "id" : 122393631
    }, {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 116, 130 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 4, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117236810043764736",
  "text" : "VIP #FF @thesexyatheist @tragic_pizza @gravestomper @dwaynereaves @CaroleODell @mimismutts @SamsaricWarrior @ssmdad @heathenrabbit \u2665\u2665\u2665",
  "id" : 117236810043764736,
  "created_at" : "2011-09-23 14:00:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "indices" : [ 3, 16 ],
      "id_str" : "15120037",
      "id" : 15120037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/SVdTjknz",
      "expanded_url" : "http:\/\/nblo.gs\/nudJR",
      "display_url" : "nblo.gs\/nudJR"
    } ]
  },
  "geo" : { },
  "id_str" : "117233119643439104",
  "text" : "RT @AnissaMayhew: My Husband Got a Girlfriend http:\/\/t.co\/SVdTjknz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/SVdTjknz",
        "expanded_url" : "http:\/\/nblo.gs\/nudJR",
        "display_url" : "nblo.gs\/nudJR"
      } ]
    },
    "geo" : { },
    "id_str" : "117226290515427329",
    "text" : "My Husband Got a Girlfriend http:\/\/t.co\/SVdTjknz",
    "id" : 117226290515427329,
    "created_at" : "2011-09-23 13:18:20 +0000",
    "user" : {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "protected" : false,
      "id_str" : "15120037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3062161006\/ad2239750e205707bab7b90d1b5e5373_normal.jpeg",
      "id" : 15120037,
      "verified" : false
    }
  },
  "id" : 117233119643439104,
  "created_at" : "2011-09-23 13:45:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117043913998602240",
  "text" : "RT @SpiritualNurse: \"God is a frequency. Stay tuned.\" - Alan Cohen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117041905031843840",
    "text" : "\"God is a frequency. Stay tuned.\" - Alan Cohen",
    "id" : 117041905031843840,
    "created_at" : "2011-09-23 01:05:39 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 117043913998602240,
  "created_at" : "2011-09-23 01:13:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muddy Paw Cheesecake",
      "screen_name" : "MPCheesecake",
      "indices" : [ 3, 16 ],
      "id_str" : "90388248",
      "id" : 90388248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116997793159188480",
  "text" : "RT @MPCheesecake: Guess a number between 1 & 100 between now and 9pm cst. Winner(s) get a free 9\" Cheesecake. That's it! GO!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116996542367416321",
    "text" : "Guess a number between 1 & 100 between now and 9pm cst. Winner(s) get a free 9\" Cheesecake. That's it! GO!",
    "id" : 116996542367416321,
    "created_at" : "2011-09-22 22:05:24 +0000",
    "user" : {
      "name" : "Muddy Paw Cheesecake",
      "screen_name" : "MPCheesecake",
      "protected" : false,
      "id_str" : "90388248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3367198543\/bcd3ecfcbaed63ece604112940e08007_normal.png",
      "id" : 90388248,
      "verified" : false
    }
  },
  "id" : 116997793159188480,
  "created_at" : "2011-09-22 22:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muddy Paw Cheesecake",
      "screen_name" : "MPCheesecake",
      "indices" : [ 0, 13 ],
      "id_str" : "90388248",
      "id" : 90388248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116996542367416321",
  "geo" : { },
  "id_str" : "116997773836029952",
  "in_reply_to_user_id" : 90388248,
  "text" : "@MPCheesecake 33",
  "id" : 116997773836029952,
  "in_reply_to_status_id" : 116996542367416321,
  "created_at" : "2011-09-22 22:10:17 +0000",
  "in_reply_to_screen_name" : "MPCheesecake",
  "in_reply_to_user_id_str" : "90388248",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B.J. Novak",
      "screen_name" : "bjnovak",
      "indices" : [ 3, 11 ],
      "id_str" : "28644174",
      "id" : 28644174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116992156266283008",
  "text" : "RT @bjnovak: Andy Darryl  Jim Pam Dwight Kelly Kevin Stanley Erin Toby Angela Oscar Meredith Phyllis Ryan Creed & Robert California #the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theoffice",
        "indices" : [ 119, 129 ]
      }, {
        "text" : "tonight",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116975661398228993",
    "text" : "Andy Darryl  Jim Pam Dwight Kelly Kevin Stanley Erin Toby Angela Oscar Meredith Phyllis Ryan Creed & Robert California #theoffice #tonight",
    "id" : 116975661398228993,
    "created_at" : "2011-09-22 20:42:25 +0000",
    "user" : {
      "name" : "B.J. Novak",
      "screen_name" : "bjnovak",
      "protected" : false,
      "id_str" : "28644174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740436182107049984\/y0N8Sqbi_normal.jpg",
      "id" : 28644174,
      "verified" : true
    }
  },
  "id" : 116992156266283008,
  "created_at" : "2011-09-22 21:47:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Alan Schelske",
      "screen_name" : "schelske",
      "indices" : [ 14, 23 ],
      "id_str" : "17903611",
      "id" : 17903611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116992018663743488",
  "text" : "@tragic_pizza @schelske ROFL..that comment just strikes me as hilarious for some reason.. ((bighugs))",
  "id" : 116992018663743488,
  "created_at" : "2011-09-22 21:47:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116991173784117248",
  "text" : "@SamsaricWarrior a nobody..which is why I want a Hummer..",
  "id" : 116991173784117248,
  "created_at" : "2011-09-22 21:44:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116990334365474818",
  "text" : "RT @LSFProgram: Look!  Look!  Look deep into nature and you will understand everything.  Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116989280320106496",
    "text" : "Look!  Look!  Look deep into nature and you will understand everything.  Albert Einstein",
    "id" : 116989280320106496,
    "created_at" : "2011-09-22 21:36:32 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 116990334365474818,
  "created_at" : "2011-09-22 21:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116975550995767296",
  "text" : "tonight's the night...",
  "id" : 116975550995767296,
  "created_at" : "2011-09-22 20:41:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 3, 17 ],
      "id_str" : "112762057",
      "id" : 112762057
    }, {
      "name" : "Traci L Slatton",
      "screen_name" : "tracilslatton",
      "indices" : [ 62, 76 ],
      "id_str" : "26790346",
      "id" : 26790346
    }, {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 88, 102 ],
      "id_str" : "112762057",
      "id" : 112762057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Giveaway",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116971731826126848",
  "text" : "RT @loveofreading: FSB #Giveaway for US\/CANADA: Win FALLEN by @TracilSlatton. RT\/Follow @LoveOfReading by 9\/28. http:\/\/ow.ly\/6AFty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Traci L Slatton",
        "screen_name" : "tracilslatton",
        "indices" : [ 43, 57 ],
        "id_str" : "26790346",
        "id" : 26790346
      }, {
        "name" : "Love of Reading",
        "screen_name" : "loveofreading",
        "indices" : [ 69, 83 ],
        "id_str" : "112762057",
        "id" : 112762057
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Giveaway",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116970031744692224",
    "text" : "FSB #Giveaway for US\/CANADA: Win FALLEN by @TracilSlatton. RT\/Follow @LoveOfReading by 9\/28. http:\/\/ow.ly\/6AFty",
    "id" : 116970031744692224,
    "created_at" : "2011-09-22 20:20:03 +0000",
    "user" : {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "protected" : false,
      "id_str" : "112762057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/807514027\/loricon2_normal.jpg",
      "id" : 112762057,
      "verified" : false
    }
  },
  "id" : 116971731826126848,
  "created_at" : "2011-09-22 20:26:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Hipps",
      "screen_name" : "shanehipps",
      "indices" : [ 3, 14 ],
      "id_str" : "36979917",
      "id" : 36979917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116964195823661056",
  "text" : "RT @shanehipps: Trying to understand the Kingdom of God with your mind is like trying to taste a kiwi with your ear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116931129914834944",
    "text" : "Trying to understand the Kingdom of God with your mind is like trying to taste a kiwi with your ear.",
    "id" : 116931129914834944,
    "created_at" : "2011-09-22 17:45:28 +0000",
    "user" : {
      "name" : "Shane Hipps",
      "screen_name" : "shanehipps",
      "protected" : false,
      "id_str" : "36979917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605361644785442817\/ht7jYUa1_normal.jpg",
      "id" : 36979917,
      "verified" : false
    }
  },
  "id" : 116964195823661056,
  "created_at" : "2011-09-22 19:56:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116956482121105408",
  "text" : "still on the hunt for bible cover that holds notepad & pen. tired of carrying stuff in a bag o-O",
  "id" : 116956482121105408,
  "created_at" : "2011-09-22 19:26:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116953817014222848",
  "text" : "I should (take my own advice and) cut down number I follow..",
  "id" : 116953817014222848,
  "created_at" : "2011-09-22 19:15:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116952495238029312",
  "geo" : { },
  "id_str" : "116953153760542720",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell im having a weird day. feelings just burst out. i blame on hormones..lol ((hugs)) thx for reading! : )",
  "id" : 116953153760542720,
  "in_reply_to_status_id" : 116952495238029312,
  "created_at" : "2011-09-22 19:12:59 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ania Ahlborn",
      "screen_name" : "aniaahlborn",
      "indices" : [ 0, 12 ],
      "id_str" : "272739347",
      "id" : 272739347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116949736703008769",
  "geo" : { },
  "id_str" : "116952740197969922",
  "in_reply_to_user_id" : 272739347,
  "text" : "@aniaahlborn I added this to readerswin.com under Author Giveaways",
  "id" : 116952740197969922,
  "in_reply_to_status_id" : 116949736703008769,
  "created_at" : "2011-09-22 19:11:20 +0000",
  "in_reply_to_screen_name" : "aniaahlborn",
  "in_reply_to_user_id_str" : "272739347",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116951580045086720",
  "text" : "if you're not reading this, then unfollow me!!! I refuse to be a number.",
  "id" : 116951580045086720,
  "created_at" : "2011-09-22 19:06:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116951259562524672",
  "text" : "RT @KerriFar: One word or a pleasing smile is often enough to raise up a saddened and wounded soul.\r ~ Therese Of Lisieux #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116946116666343425",
    "text" : "One word or a pleasing smile is often enough to raise up a saddened and wounded soul.\r ~ Therese Of Lisieux #quote",
    "id" : 116946116666343425,
    "created_at" : "2011-09-22 18:45:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 116951259562524672,
  "created_at" : "2011-09-22 19:05:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Paper",
      "screen_name" : "NealPaper",
      "indices" : [ 3, 13 ],
      "id_str" : "137459940",
      "id" : 137459940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/JS729rXx",
      "expanded_url" : "http:\/\/lux-os.com\/y\/1q4",
      "display_url" : "lux-os.com\/y\/1q4"
    } ]
  },
  "geo" : { },
  "id_str" : "116950592773029889",
  "text" : "RT @NealPaper: History repeats until it's message is understood by the collective consciousness - http:\/\/t.co\/JS729rXx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.lux-os.com\" rel=\"nofollow\"\u003EGlobal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/JS729rXx",
        "expanded_url" : "http:\/\/lux-os.com\/y\/1q4",
        "display_url" : "lux-os.com\/y\/1q4"
      } ]
    },
    "geo" : { },
    "id_str" : "116950073761468417",
    "text" : "History repeats until it's message is understood by the collective consciousness - http:\/\/t.co\/JS729rXx",
    "id" : 116950073761468417,
    "created_at" : "2011-09-22 19:00:45 +0000",
    "user" : {
      "name" : "Neal Paper",
      "screen_name" : "NealPaper",
      "protected" : false,
      "id_str" : "137459940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853635340\/flower_normal.jpg",
      "id" : 137459940,
      "verified" : false
    }
  },
  "id" : 116950592773029889,
  "created_at" : "2011-09-22 19:02:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116944771473342465",
  "text" : "sometimes I wish I could be someone else so I could belong... UGH. ((slaps self))",
  "id" : 116944771473342465,
  "created_at" : "2011-09-22 18:39:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116944438370123776",
  "text" : "it's not easy to be me. ppl don't realize that.",
  "id" : 116944438370123776,
  "created_at" : "2011-09-22 18:38:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116944023700242432",
  "text" : "I was very bad in previous life. This current life is my punishment.",
  "id" : 116944023700242432,
  "created_at" : "2011-09-22 18:36:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 3, 15 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    }, {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 31, 43 ],
      "id_str" : "35773039",
      "id" : 35773039
    }, {
      "name" : "#1book140",
      "screen_name" : "1book140",
      "indices" : [ 65, 74 ],
      "id_str" : "277519996",
      "id" : 277519996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horror",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116943896197611520",
  "text" : "RT @PenguinPbks: Like #horror? @TheAtlantic's Twitter book club, @1book140, needs an October title. But hurry up deadline is 9\/23 5pm -  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Atlantic",
        "screen_name" : "TheAtlantic",
        "indices" : [ 14, 26 ],
        "id_str" : "35773039",
        "id" : 35773039
      }, {
        "name" : "#1book140",
        "screen_name" : "1book140",
        "indices" : [ 48, 57 ],
        "id_str" : "277519996",
        "id" : 277519996
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "horror",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/pibEqx8b",
        "expanded_url" : "http:\/\/bit.ly\/qmyPVP",
        "display_url" : "bit.ly\/qmyPVP"
      } ]
    },
    "geo" : { },
    "id_str" : "116943766769762304",
    "text" : "Like #horror? @TheAtlantic's Twitter book club, @1book140, needs an October title. But hurry up deadline is 9\/23 5pm - http:\/\/t.co\/pibEqx8b",
    "id" : 116943766769762304,
    "created_at" : "2011-09-22 18:35:41 +0000",
    "user" : {
      "name" : "Penguin Books",
      "screen_name" : "PenguinBooks",
      "protected" : false,
      "id_str" : "23484629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796407064574697472\/Vm0-gZS2_normal.jpg",
      "id" : 23484629,
      "verified" : true
    }
  },
  "id" : 116943896197611520,
  "created_at" : "2011-09-22 18:36:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116943834184814592",
  "text" : "I want to scream because I am frustrated with world, with myself.",
  "id" : 116943834184814592,
  "created_at" : "2011-09-22 18:35:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116943698633293824",
  "text" : "I could have easily been someone else. I am who I am by default and so are majority of people.",
  "id" : 116943698633293824,
  "created_at" : "2011-09-22 18:35:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116942573532229632",
  "text" : "RT @andrewtshaffer: Also breaking news: the sun causes cancer. And we still go outside. So, yeah.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116939677885407233",
    "text" : "Also breaking news: the sun causes cancer. And we still go outside. So, yeah.",
    "id" : 116939677885407233,
    "created_at" : "2011-09-22 18:19:26 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 116942573532229632,
  "created_at" : "2011-09-22 18:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 3, 9 ],
      "id_str" : "16955991",
      "id" : 16955991
    }, {
      "name" : "slackbot",
      "screen_name" : "pareene",
      "indices" : [ 71, 79 ],
      "id_str" : "50149303",
      "id" : 50149303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/StJAfpCl",
      "expanded_url" : "http:\/\/salon.com\/a\/soEQfAA",
      "display_url" : "salon.com\/a\/soEQfAA"
    } ]
  },
  "geo" : { },
  "id_str" : "116933097467019264",
  "text" : "RT @Salon: Why nobody could save Troy Davis. http:\/\/t.co\/StJAfpCl (via @pareene)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "slackbot",
        "screen_name" : "pareene",
        "indices" : [ 60, 68 ],
        "id_str" : "50149303",
        "id" : 50149303
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/StJAfpCl",
        "expanded_url" : "http:\/\/salon.com\/a\/soEQfAA",
        "display_url" : "salon.com\/a\/soEQfAA"
      } ]
    },
    "geo" : { },
    "id_str" : "116914088986152960",
    "text" : "Why nobody could save Troy Davis. http:\/\/t.co\/StJAfpCl (via @pareene)",
    "id" : 116914088986152960,
    "created_at" : "2011-09-22 16:37:45 +0000",
    "user" : {
      "name" : "Salon",
      "screen_name" : "Salon",
      "protected" : false,
      "id_str" : "16955991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793144947444707328\/obBB1x2a_normal.jpg",
      "id" : 16955991,
      "verified" : true
    }
  },
  "id" : 116933097467019264,
  "created_at" : "2011-09-22 17:53:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Molly",
      "screen_name" : "Molly_Kats",
      "indices" : [ 15, 26 ],
      "id_str" : "166212191",
      "id" : 166212191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116929120516046848",
  "text" : "RT @BestAt: RT @Molly_Kats: In hell, you have to find the start to Scotch Tape over and over.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Molly",
        "screen_name" : "Molly_Kats",
        "indices" : [ 3, 14 ],
        "id_str" : "166212191",
        "id" : 166212191
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116928304803610624",
    "text" : "RT @Molly_Kats: In hell, you have to find the start to Scotch Tape over and over.",
    "id" : 116928304803610624,
    "created_at" : "2011-09-22 17:34:14 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 116929120516046848,
  "created_at" : "2011-09-22 17:37:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116905198181556224",
  "text" : "RT @GeneDoucette: In fairness, Georgia has a point. If they let one innocent guy out, ALL the innocent guys are gonna want the same trea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116903564441436160",
    "text" : "In fairness, Georgia has a point. If they let one innocent guy out, ALL the innocent guys are gonna want the same treatment.",
    "id" : 116903564441436160,
    "created_at" : "2011-09-22 15:55:56 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 116905198181556224,
  "created_at" : "2011-09-22 16:02:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rain Gatdula",
      "screen_name" : "RainGatdula",
      "indices" : [ 27, 39 ],
      "id_str" : "3188065214",
      "id" : 3188065214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116898153663438848",
  "geo" : { },
  "id_str" : "116899903208304641",
  "in_reply_to_user_id" : 67592283,
  "text" : "profound metaphor for life @raingatdula",
  "id" : 116899903208304641,
  "in_reply_to_status_id" : 116898153663438848,
  "created_at" : "2011-09-22 15:41:23 +0000",
  "in_reply_to_screen_name" : "rainhimself",
  "in_reply_to_user_id_str" : "67592283",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rain Gatdula",
      "screen_name" : "RainGatdula",
      "indices" : [ 3, 15 ],
      "id_str" : "3188065214",
      "id" : 3188065214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116899628921798656",
  "text" : "RT @raingatdula: Press any key to continue or any other key to quit...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116898153663438848",
    "text" : "Press any key to continue or any other key to quit...",
    "id" : 116898153663438848,
    "created_at" : "2011-09-22 15:34:26 +0000",
    "user" : {
      "name" : "Rain",
      "screen_name" : "rainhimself",
      "protected" : false,
      "id_str" : "67592283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000020820376\/d021dda1e6294bd5391832745494b412_normal.jpeg",
      "id" : 67592283,
      "verified" : false
    }
  },
  "id" : 116899628921798656,
  "created_at" : "2011-09-22 15:40:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "indices" : [ 3, 16 ],
      "id_str" : "15175368",
      "id" : 15175368
    }, {
      "name" : "Angela Kinsey",
      "screen_name" : "AngelaKinsey",
      "indices" : [ 21, 34 ],
      "id_str" : "277595625",
      "id" : 277595625
    }, {
      "name" : "Brian Baumgartner",
      "screen_name" : "BBBaumgartner",
      "indices" : [ 77, 91 ],
      "id_str" : "26020351",
      "id" : 26020351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheOffice",
      "indices" : [ 47, 57 ]
    }, {
      "text" : "TheOffice",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116899549204844544",
  "text" : "RT @theofficenbc: RT @AngelaKinsey Season 8 of #TheOffice starts tonight! RT @BBBaumgartner #TheOffice. Returns. Tonight. 9pm EST & PST. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angela Kinsey",
        "screen_name" : "AngelaKinsey",
        "indices" : [ 3, 16 ],
        "id_str" : "277595625",
        "id" : 277595625
      }, {
        "name" : "Brian Baumgartner",
        "screen_name" : "BBBaumgartner",
        "indices" : [ 59, 73 ],
        "id_str" : "26020351",
        "id" : 26020351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheOffice",
        "indices" : [ 29, 39 ]
      }, {
        "text" : "TheOffice",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116898878409818113",
    "text" : "RT @AngelaKinsey Season 8 of #TheOffice starts tonight! RT @BBBaumgartner #TheOffice. Returns. Tonight. 9pm EST & PST. 8pm CST. On NBC.",
    "id" : 116898878409818113,
    "created_at" : "2011-09-22 15:37:19 +0000",
    "user" : {
      "name" : "The Office",
      "screen_name" : "theofficenbc",
      "protected" : false,
      "id_str" : "15175368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3672312614\/17217191debc391b060a6798b6c2ad10_normal.jpeg",
      "id" : 15175368,
      "verified" : true
    }
  },
  "id" : 116899549204844544,
  "created_at" : "2011-09-22 15:39:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116897428589912064",
  "text" : "I think the school nurse thinks I'm weird.. oh, well.",
  "id" : 116897428589912064,
  "created_at" : "2011-09-22 15:31:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Rachid H",
      "screen_name" : "rachidH",
      "indices" : [ 24, 32 ],
      "id_str" : "18059728",
      "id" : 18059728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "Cairo",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "rachidh",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "nature",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "photo",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/kf9xwbqC",
      "expanded_url" : "http:\/\/twitpic.com\/6nuv0u",
      "display_url" : "twitpic.com\/6nuv0u"
    } ]
  },
  "geo" : { },
  "id_str" : "116897130114850816",
  "text" : "RT @KerriFar: Super! RT @rachidH: Corvus cornix Pride ~ Black hooded crow http:\/\/t.co\/kf9xwbqC #birds #Cairo #rachidh #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachid H",
        "screen_name" : "rachidH",
        "indices" : [ 10, 18 ],
        "id_str" : "18059728",
        "id" : 18059728
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "Cairo",
        "indices" : [ 88, 94 ]
      }, {
        "text" : "rachidh",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "nature",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "photo",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/kf9xwbqC",
        "expanded_url" : "http:\/\/twitpic.com\/6nuv0u",
        "display_url" : "twitpic.com\/6nuv0u"
      } ]
    },
    "geo" : { },
    "id_str" : "116893769793675264",
    "text" : "Super! RT @rachidH: Corvus cornix Pride ~ Black hooded crow http:\/\/t.co\/kf9xwbqC #birds #Cairo #rachidh #nature #photo",
    "id" : 116893769793675264,
    "created_at" : "2011-09-22 15:17:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 116897130114850816,
  "created_at" : "2011-09-22 15:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittany",
      "screen_name" : "barefootfoodie",
      "indices" : [ 3, 18 ],
      "id_str" : "160794974",
      "id" : 160794974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/TB8hwybp",
      "expanded_url" : "http:\/\/bit.ly\/pSTyEN",
      "display_url" : "bit.ly\/pSTyEN"
    } ]
  },
  "geo" : { },
  "id_str" : "116894061499125761",
  "text" : "RT @barefootfoodie: Fear based parenting.  Everyone's a winner. Except, you know...the kids.  Whatever.  http:\/\/t.co\/TB8hwybp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/TB8hwybp",
        "expanded_url" : "http:\/\/bit.ly\/pSTyEN",
        "display_url" : "bit.ly\/pSTyEN"
      } ]
    },
    "geo" : { },
    "id_str" : "116887843665739776",
    "text" : "Fear based parenting.  Everyone's a winner. Except, you know...the kids.  Whatever.  http:\/\/t.co\/TB8hwybp",
    "id" : 116887843665739776,
    "created_at" : "2011-09-22 14:53:28 +0000",
    "user" : {
      "name" : "Brittany Gibbons",
      "screen_name" : "brittanyherself",
      "protected" : false,
      "id_str" : "15153542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771762640393732097\/zrgPYFCY_normal.jpg",
      "id" : 15153542,
      "verified" : true
    }
  },
  "id" : 116894061499125761,
  "created_at" : "2011-09-22 15:18:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Rea",
      "screen_name" : "robertrea",
      "indices" : [ 46, 56 ],
      "id_str" : "28357727",
      "id" : 28357727
    }, {
      "name" : "Mark Davidson",
      "screen_name" : "markdavidson",
      "indices" : [ 110, 123 ],
      "id_str" : "7490342",
      "id" : 7490342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116893292704169984",
  "text" : "RT @kindlevixen: IF I could +1 this, I would. @robertrea Never EVER fire your twitter ghostwriters. Check out @markdavidson 's timeline  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Rea",
        "screen_name" : "robertrea",
        "indices" : [ 29, 39 ],
        "id_str" : "28357727",
        "id" : 28357727
      }, {
        "name" : "Mark Davidson",
        "screen_name" : "markdavidson",
        "indices" : [ 93, 106 ],
        "id_str" : "7490342",
        "id" : 7490342
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116889619013971968",
    "text" : "IF I could +1 this, I would. @robertrea Never EVER fire your twitter ghostwriters. Check out @markdavidson 's timeline before he deletes it",
    "id" : 116889619013971968,
    "created_at" : "2011-09-22 15:00:31 +0000",
    "user" : {
      "name" : "Moxie Hart",
      "screen_name" : "moxie_hart",
      "protected" : false,
      "id_str" : "17165443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787765007673069568\/KoX_CNph_normal.jpg",
      "id" : 17165443,
      "verified" : false
    }
  },
  "id" : 116893292704169984,
  "created_at" : "2011-09-22 15:15:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116886563908096000",
  "text" : "RT @JohnCali: The key to getting inside your Vibrational Vortex of Creation...is being in the state of appreciation...and th\u2026 (cont) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/duW8FTOl",
        "expanded_url" : "http:\/\/deck.ly\/~TkS6h",
        "display_url" : "deck.ly\/~TkS6h"
      } ]
    },
    "geo" : { },
    "id_str" : "116881045944664064",
    "text" : "The key to getting inside your Vibrational Vortex of Creation...is being in the state of appreciation...and th\u2026 (cont) http:\/\/t.co\/duW8FTOl",
    "id" : 116881045944664064,
    "created_at" : "2011-09-22 14:26:27 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 116886563908096000,
  "created_at" : "2011-09-22 14:48:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116886363873357824",
  "text" : "RT @JohnCali: You have no real control of what anyone else is doing with their vibration...but you have complete control ove\u2026 (cont) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/VncW4yOU",
        "expanded_url" : "http:\/\/deck.ly\/~m86Gg",
        "display_url" : "deck.ly\/~m86Gg"
      } ]
    },
    "geo" : { },
    "id_str" : "116881320071794688",
    "text" : "You have no real control of what anyone else is doing with their vibration...but you have complete control ove\u2026 (cont) http:\/\/t.co\/VncW4yOU",
    "id" : 116881320071794688,
    "created_at" : "2011-09-22 14:27:32 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 116886363873357824,
  "created_at" : "2011-09-22 14:47:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 0, 9 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116881378578145281",
  "geo" : { },
  "id_str" : "116886051435446273",
  "in_reply_to_user_id" : 27094110,
  "text" : "@JohnCali YES!",
  "id" : 116886051435446273,
  "in_reply_to_status_id" : 116881378578145281,
  "created_at" : "2011-09-22 14:46:20 +0000",
  "in_reply_to_screen_name" : "JohnCali",
  "in_reply_to_user_id_str" : "27094110",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116885811210883073",
  "text" : "RT @JohnCali: ...giving your attention to them (other people's negative experiences) deprives you of who you are. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116881378578145281",
    "text" : "...giving your attention to them (other people's negative experiences) deprives you of who you are. ~ Abraham",
    "id" : 116881378578145281,
    "created_at" : "2011-09-22 14:27:46 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 116885811210883073,
  "created_at" : "2011-09-22 14:45:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "movefearlessly",
      "screen_name" : "movefearlessly",
      "indices" : [ 3, 18 ],
      "id_str" : "16274867",
      "id" : 16274867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116885447287914496",
  "text" : "RT @movefearlessly: Be yourself - everyone else is taken. ~  Anonymous",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.gremlinsocial.com\" rel=\"nofollow\"\u003EGremlin Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116884682011983872",
    "text" : "Be yourself - everyone else is taken. ~  Anonymous",
    "id" : 116884682011983872,
    "created_at" : "2011-09-22 14:40:54 +0000",
    "user" : {
      "name" : "movefearlessly",
      "screen_name" : "movefearlessly",
      "protected" : false,
      "id_str" : "16274867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1391906844\/me10_normal.jpg",
      "id" : 16274867,
      "verified" : false
    }
  },
  "id" : 116885447287914496,
  "created_at" : "2011-09-22 14:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Alley",
      "screen_name" : "kirstiealley",
      "indices" : [ 3, 16 ],
      "id_str" : "36528126",
      "id" : 36528126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116885364408451073",
  "text" : "RT @kirstiealley: Mankind will never be free until we stop addtessing hate and violence with hate and violence..We need to STOP this vic ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116819886205964288",
    "text" : "Mankind will never be free until we stop addtessing hate and violence with hate and violence..We need to STOP this vicious cycle..compassion",
    "id" : 116819886205964288,
    "created_at" : "2011-09-22 10:23:25 +0000",
    "user" : {
      "name" : "Kirstie Alley",
      "screen_name" : "kirstiealley",
      "protected" : false,
      "id_str" : "36528126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688133582695448577\/aqnKj9p5_normal.png",
      "id" : 36528126,
      "verified" : true
    }
  },
  "id" : 116885364408451073,
  "created_at" : "2011-09-22 14:43:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Mark Ritch",
      "screen_name" : "JeremyRitch",
      "indices" : [ 3, 15 ],
      "id_str" : "22289976",
      "id" : 22289976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116882069740716032",
  "text" : "RT @JeremyRitch: Let us remember what Jesus said about casting the first stone, that goes for the executioner and the rest of us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116746748340346880",
    "text" : "Let us remember what Jesus said about casting the first stone, that goes for the executioner and the rest of us.",
    "id" : 116746748340346880,
    "created_at" : "2011-09-22 05:32:48 +0000",
    "user" : {
      "name" : "Jeremy Mark Ritch",
      "screen_name" : "JeremyRitch",
      "protected" : false,
      "id_str" : "22289976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763768799795503104\/3dsBNPV-_normal.jpg",
      "id" : 22289976,
      "verified" : false
    }
  },
  "id" : 116882069740716032,
  "created_at" : "2011-09-22 14:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Pax Paxochka",
      "screen_name" : "Paxochka",
      "indices" : [ 15, 24 ],
      "id_str" : "35888311",
      "id" : 35888311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116882017399996416",
  "text" : "RT @BestAt: RT @Paxochka: If you don't like what I tweet I don't give a shit because it's not your twitter account, it's mine.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pax Paxochka",
        "screen_name" : "Paxochka",
        "indices" : [ 3, 12 ],
        "id_str" : "35888311",
        "id" : 35888311
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116873262423736320",
    "text" : "RT @Paxochka: If you don't like what I tweet I don't give a shit because it's not your twitter account, it's mine.",
    "id" : 116873262423736320,
    "created_at" : "2011-09-22 13:55:31 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 116882017399996416,
  "created_at" : "2011-09-22 14:30:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "juttakueppers",
      "screen_name" : "jkgermany",
      "indices" : [ 96, 106 ],
      "id_str" : "159187322",
      "id" : 159187322
    }, {
      "name" : "America United",
      "screen_name" : "Progress2day",
      "indices" : [ 108, 121 ],
      "id_str" : "212808638",
      "id" : 212808638
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 122, 136 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116675033778225152",
  "text" : "RT @CharlesBivona: The death penalty damages everyone involved..all killing has consequences RT @jkgermany: @Progress2day @CharlesBivona ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "juttakueppers",
        "screen_name" : "jkgermany",
        "indices" : [ 77, 87 ],
        "id_str" : "159187322",
        "id" : 159187322
      }, {
        "name" : "America United",
        "screen_name" : "Progress2day",
        "indices" : [ 89, 102 ],
        "id_str" : "212808638",
        "id" : 212808638
      }, {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 103, 117 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116674321572827137",
    "text" : "The death penalty damages everyone involved..all killing has consequences RT @jkgermany: @Progress2day @CharlesBivona It is a medieval act.",
    "id" : 116674321572827137,
    "created_at" : "2011-09-22 00:45:00 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 116675033778225152,
  "created_at" : "2011-09-22 00:47:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116576343554129920",
  "text" : "RT @fearfuldogs: just cos WE want 2 do something w our pets doesn't mean they want to! nice 2 include our animals but not at their expen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116575189839527936",
    "text" : "just cos WE want 2 do something w our pets doesn't mean they want to! nice 2 include our animals but not at their expense IMHO",
    "id" : 116575189839527936,
    "created_at" : "2011-09-21 18:11:05 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 116576343554129920,
  "created_at" : "2011-09-21 18:15:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116569840013152257",
  "text" : "public announcement: I do not agree with last RT. thank you.",
  "id" : 116569840013152257,
  "created_at" : "2011-09-21 17:49:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buck Buckaroo",
      "screen_name" : "buckbuckaroo",
      "indices" : [ 3, 16 ],
      "id_str" : "43580563",
      "id" : 43580563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116569615072641024",
  "text" : "RT @buckbuckaroo: Why the hell would you ever go hiking IN FREAKING IRAN?! You deserve to be jailed because you're A FREAKING MORON.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116565668735885312",
    "text" : "Why the hell would you ever go hiking IN FREAKING IRAN?! You deserve to be jailed because you're A FREAKING MORON.",
    "id" : 116565668735885312,
    "created_at" : "2011-09-21 17:33:15 +0000",
    "user" : {
      "name" : "Buck Buckaroo",
      "screen_name" : "buckbuckaroo",
      "protected" : false,
      "id_str" : "43580563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1720694632\/O_Hara3_normal.jpg",
      "id" : 43580563,
      "verified" : false
    }
  },
  "id" : 116569615072641024,
  "created_at" : "2011-09-21 17:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116552638912413696",
  "geo" : { },
  "id_str" : "116565330427523072",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell \u2665u2 : )",
  "id" : 116565330427523072,
  "in_reply_to_status_id" : 116552638912413696,
  "created_at" : "2011-09-21 17:31:55 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116553163305263105",
  "text" : "I have no qualms about not finishing a book I started",
  "id" : 116553163305263105,
  "created_at" : "2011-09-21 16:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116541998848155648",
  "text" : "RT @ReverendSue: Call GA Parole Board: 404.656.5651..wait for message..dial 0#...wait for message..dial 5..BE PATIENT. You will talk to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TroyDavis",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116540516325277697",
    "text" : "Call GA Parole Board: 404.656.5651..wait for message..dial 0#...wait for message..dial 5..BE PATIENT. You will talk to live rep. #TroyDavis",
    "id" : 116540516325277697,
    "created_at" : "2011-09-21 15:53:18 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 116541998848155648,
  "created_at" : "2011-09-21 15:59:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "DC Debbie",
      "screen_name" : "DCdebbie",
      "indices" : [ 20, 29 ],
      "id_str" : "14266637",
      "id" : 14266637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116541970981195776",
  "text" : "RT @ReverendSue: RT @DCdebbie Keep calling the Ga Parole Board (404)656-5651 Rt to all ur followers They told me they are counting # rec ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DC Debbie",
        "screen_name" : "DCdebbie",
        "indices" : [ 3, 12 ],
        "id_str" : "14266637",
        "id" : 14266637
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TroyDavis",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116540679701794816",
    "text" : "RT @DCdebbie Keep calling the Ga Parole Board (404)656-5651 Rt to all ur followers They told me they are counting # received. #TroyDavis",
    "id" : 116540679701794816,
    "created_at" : "2011-09-21 15:53:57 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 116541970981195776,
  "created_at" : "2011-09-21 15:59:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 19, 31 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116536723177086976",
  "geo" : { },
  "id_str" : "116541429995683841",
  "in_reply_to_user_id" : 71118021,
  "text" : "making funny faces @CaroleODell to distract her from her work :D",
  "id" : 116541429995683841,
  "in_reply_to_status_id" : 116536723177086976,
  "created_at" : "2011-09-21 15:56:56 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116522964362596353",
  "text" : "gratitude to Iran for release of US hikers",
  "id" : 116522964362596353,
  "created_at" : "2011-09-21 14:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116273666442002432",
  "text" : "RT @CharlesBivona: \"Social policy is geared to the transfer of wealth and power to those who already have it, and deliberately so.\" -Noa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chomsky",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "quote",
        "indices" : [ 128, 134 ]
      }, {
        "text" : "p2",
        "indices" : [ 135, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116273407456313344",
    "text" : "\"Social policy is geared to the transfer of wealth and power to those who already have it, and deliberately so.\" -Noam #Chomsky #quote #p2",
    "id" : 116273407456313344,
    "created_at" : "2011-09-20 22:11:55 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 116273666442002432,
  "created_at" : "2011-09-20 22:12:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "indices" : [ 0, 7 ],
      "id_str" : "18089695",
      "id" : 18089695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116267528887615488",
  "geo" : { },
  "id_str" : "116272127690276865",
  "in_reply_to_user_id" : 18089695,
  "text" : "@rynedp LOL",
  "id" : 116272127690276865,
  "in_reply_to_status_id" : 116267528887615488,
  "created_at" : "2011-09-20 22:06:50 +0000",
  "in_reply_to_screen_name" : "rynedp",
  "in_reply_to_user_id_str" : "18089695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116271757467451393",
  "text" : "RT @SangyeH: I don't understand how Christians say \"God is the only judge\" but in the same breath think it's fine to kill someone as jud ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116269767060504576",
    "text" : "I don't understand how Christians say \"God is the only judge\" but in the same breath think it's fine to kill someone as judgment.",
    "id" : 116269767060504576,
    "created_at" : "2011-09-20 21:57:27 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 116271757467451393,
  "created_at" : "2011-09-20 22:05:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Dark Lord",
      "screen_name" : "Lord_Voldemort7",
      "indices" : [ 3, 19 ],
      "id_str" : "160817572",
      "id" : 160817572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116266362598457345",
  "text" : "RT @Lord_Voldemort7: Some people see a glass as half empty. Some see a glass as half full. Most need to get a life & do something beside ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116260168341274624",
    "text" : "Some people see a glass as half empty. Some see a glass as half full. Most need to get a life & do something besides stare at glasses.",
    "id" : 116260168341274624,
    "created_at" : "2011-09-20 21:19:18 +0000",
    "user" : {
      "name" : "The Dark Lord",
      "screen_name" : "Lord_Voldemort7",
      "protected" : false,
      "id_str" : "160817572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1258281289\/300px-Lordvoldemort_normal.jpg",
      "id" : 160817572,
      "verified" : false
    }
  },
  "id" : 116266362598457345,
  "created_at" : "2011-09-20 21:43:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Barber",
      "screen_name" : "jmattbarber",
      "indices" : [ 29, 41 ],
      "id_str" : "22770745",
      "id" : 22770745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116246952286486528",
  "text" : "RT @WarriorBanker: Idiot: RT @jmattbarber: Today for first time in American history destructive, disordered sexual behavior is openly al ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Barber",
        "screen_name" : "jmattbarber",
        "indices" : [ 10, 22 ],
        "id_str" : "22770745",
        "id" : 22770745
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116245039612559360",
    "text" : "Idiot: RT @jmattbarber: Today for first time in American history destructive, disordered sexual behavior is openly allowed in the military",
    "id" : 116245039612559360,
    "created_at" : "2011-09-20 20:19:11 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 116246952286486528,
  "created_at" : "2011-09-20 20:26:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 0, 12 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116196456435683328",
  "geo" : { },
  "id_str" : "116203511825440768",
  "in_reply_to_user_id" : 23484629,
  "text" : "@PenguinPbks westborough, mass - tatnuck booksellers",
  "id" : 116203511825440768,
  "in_reply_to_status_id" : 116196456435683328,
  "created_at" : "2011-09-20 17:34:10 +0000",
  "in_reply_to_screen_name" : "PenguinBooks",
  "in_reply_to_user_id_str" : "23484629",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116170363074912256",
  "text" : "RT @adampknave: I am in no way against any religion. I am 100% against any religious person who tries to use their faith to trump my belief.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116169797074567168",
    "text" : "I am in no way against any religion. I am 100% against any religious person who tries to use their faith to trump my belief.",
    "id" : 116169797074567168,
    "created_at" : "2011-09-20 15:20:12 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 116170363074912256,
  "created_at" : "2011-09-20 15:22:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116169797061984256",
  "text" : "@SamsaricWarrior rules.. it's a dirty word.",
  "id" : 116169797061984256,
  "created_at" : "2011-09-20 15:20:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116169561497280512",
  "text" : "@SamsaricWarrior say what??? : (",
  "id" : 116169561497280512,
  "created_at" : "2011-09-20 15:19:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116168223442993152",
  "text" : "RT @JohnCali: Don't use errors as an excuse to beat yourself up. Use them as an opportunity to lift yourself up. Forgivenes\u2026 (cont) http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/52XNTXHn",
        "expanded_url" : "http:\/\/deck.ly\/~XTquZ",
        "display_url" : "deck.ly\/~XTquZ"
      } ]
    },
    "geo" : { },
    "id_str" : "116167382195638272",
    "text" : "Don't use errors as an excuse to beat yourself up. Use them as an opportunity to lift yourself up. Forgivenes\u2026 (cont) http:\/\/t.co\/52XNTXHn",
    "id" : 116167382195638272,
    "created_at" : "2011-09-20 15:10:36 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 116168223442993152,
  "created_at" : "2011-09-20 15:13:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116164337118347264",
  "geo" : { },
  "id_str" : "116165834367451136",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle ((hugs)) sweetie \u2665",
  "id" : 116165834367451136,
  "in_reply_to_status_id" : 116164337118347264,
  "created_at" : "2011-09-20 15:04:27 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116160236611579904",
  "geo" : { },
  "id_str" : "116164873930551296",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time only go cuz it makes MIL happy (well, gets me out of house and among ppl for an hour or so)",
  "id" : 116164873930551296,
  "in_reply_to_status_id" : 116160236611579904,
  "created_at" : "2011-09-20 15:00:38 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116160236611579904",
  "geo" : { },
  "id_str" : "116164560985128960",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time I wanted to go but didnt want to go. slept a bit late. my laziness took over. ; )",
  "id" : 116164560985128960,
  "in_reply_to_status_id" : 116160236611579904,
  "created_at" : "2011-09-20 14:59:24 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116159216133218304",
  "text" : "didnt go to bible study today. MIL on vacay. feel guilty...",
  "id" : 116159216133218304,
  "created_at" : "2011-09-20 14:38:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Photography",
      "screen_name" : "Wildlife_Photo",
      "indices" : [ 3, 18 ],
      "id_str" : "68092194",
      "id" : 68092194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WildlifePhoto",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/299uyiqw",
      "expanded_url" : "http:\/\/bit.ly\/oNlaHP",
      "display_url" : "bit.ly\/oNlaHP"
    } ]
  },
  "geo" : { },
  "id_str" : "116155294928744448",
  "text" : "RT @Wildlife_Photo: Natural Moments: Bird and Wildlife Photography - How to Pet a Bumblebee: http:\/\/t.co\/299uyiqw #WildlifePhoto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildlife-photography-blog.com\" rel=\"nofollow\"\u003EWildlife Photography Blog\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WildlifePhoto",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/299uyiqw",
        "expanded_url" : "http:\/\/bit.ly\/oNlaHP",
        "display_url" : "bit.ly\/oNlaHP"
      } ]
    },
    "geo" : { },
    "id_str" : "116154228581482496",
    "text" : "Natural Moments: Bird and Wildlife Photography - How to Pet a Bumblebee: http:\/\/t.co\/299uyiqw #WildlifePhoto",
    "id" : 116154228581482496,
    "created_at" : "2011-09-20 14:18:20 +0000",
    "user" : {
      "name" : "Wildlife Photography",
      "screen_name" : "Wildlife_Photo",
      "protected" : false,
      "id_str" : "68092194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378006206\/logo3_normal.png",
      "id" : 68092194,
      "verified" : false
    }
  },
  "id" : 116155294928744448,
  "created_at" : "2011-09-20 14:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dmytry Karpov",
      "screen_name" : "DmytryKarpov",
      "indices" : [ 3, 16 ],
      "id_str" : "176332199",
      "id" : 176332199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115916943940259840",
  "text" : "RT @DmytryKarpov: RT this for a chance to win a free copy of Dark Edge. \"Tales that will suck you in, chew you up, and leave you begging ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0411\u0435\u043B\u0438\u043A\u043E\u0432 \u041C\u0438\u0445\u0430\u0438\u043B",
        "screen_name" : "LMStull",
        "indices" : [ 129, 137 ],
        "id_str" : "2835376119",
        "id" : 2835376119
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115915155732303872",
    "text" : "RT this for a chance to win a free copy of Dark Edge. \"Tales that will suck you in, chew you up, and leave you begging for more\"-@Lmstull",
    "id" : 115915155732303872,
    "created_at" : "2011-09-19 22:28:21 +0000",
    "user" : {
      "name" : "Dmytry Karpov",
      "screen_name" : "DmytryKarpov",
      "protected" : false,
      "id_str" : "176332199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1705590424\/D_author_profile_pic_2_optomized_normal",
      "id" : 176332199,
      "verified" : false
    }
  },
  "id" : 115916943940259840,
  "created_at" : "2011-09-19 22:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115889062241509376",
  "text" : "@animalswisdom thx4love.. kitty resting. hopefully better now.",
  "id" : 115889062241509376,
  "created_at" : "2011-09-19 20:44:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115833506604662784",
  "text" : "poor cat not feeling well today...",
  "id" : 115833506604662784,
  "created_at" : "2011-09-19 17:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115597710526128128",
  "in_reply_to_user_id" : 155031802,
  "text" : "@iKrisBee fyi: did you send me a dm? just got one from you w link. you might be hacked?",
  "id" : 115597710526128128,
  "created_at" : "2011-09-19 01:26:56 +0000",
  "in_reply_to_screen_name" : "krisrandom",
  "in_reply_to_user_id_str" : "155031802",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/abandontheherd\/status\/115579782506352640\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/2Aimye09",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZqfMyfCEAEEGCG.jpg",
      "id_str" : "115579782510546945",
      "id" : 115579782510546945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZqfMyfCEAEEGCG.jpg",
      "sizes" : [ {
        "h" : 846,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2Aimye09"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115580460997951488",
  "text" : "RT @abandontheherd: See your thoughts as clouds passing and begin focusing on the serene, blue sky between. http:\/\/t.co\/2Aimye09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abandontheherd\/status\/115579782506352640\/photo\/1",
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/2Aimye09",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AZqfMyfCEAEEGCG.jpg",
        "id_str" : "115579782510546945",
        "id" : 115579782510546945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZqfMyfCEAEEGCG.jpg",
        "sizes" : [ {
          "h" : 846,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2Aimye09"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115579782506352640",
    "text" : "See your thoughts as clouds passing and begin focusing on the serene, blue sky between. http:\/\/t.co\/2Aimye09",
    "id" : 115579782506352640,
    "created_at" : "2011-09-19 00:15:42 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 115580460997951488,
  "created_at" : "2011-09-19 00:18:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115580426302656512",
  "text" : "RT @abandontheherd: The less you fight with life the happier you'll be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115580054943182848",
    "text" : "The less you fight with life the happier you'll be.",
    "id" : 115580054943182848,
    "created_at" : "2011-09-19 00:16:47 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 115580426302656512,
  "created_at" : "2011-09-19 00:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenda Wallace",
      "screen_name" : "BrendaBWallace",
      "indices" : [ 3, 18 ],
      "id_str" : "40580919",
      "id" : 40580919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115530939228094467",
  "text" : "RT @BrendaBWallace: Giving away Kindle Oct 8 to launch BRILLIANT PREY up to #21 Psych Thrillers. Just RT to enter (Only 99 cents) http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAN1",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/pnPw1Tku",
        "expanded_url" : "http:\/\/tinyurl.com\/3jrugaq",
        "display_url" : "tinyurl.com\/3jrugaq"
      } ]
    },
    "geo" : { },
    "id_str" : "115528323102281728",
    "text" : "Giving away Kindle Oct 8 to launch BRILLIANT PREY up to #21 Psych Thrillers. Just RT to enter (Only 99 cents) http:\/\/t.co\/pnPw1Tku #IAN1 THX",
    "id" : 115528323102281728,
    "created_at" : "2011-09-18 20:51:13 +0000",
    "user" : {
      "name" : "Brenda Wallace",
      "screen_name" : "BrendaBWallace",
      "protected" : false,
      "id_str" : "40580919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598671832196087808\/8xuhEKh2_normal.jpg",
      "id" : 40580919,
      "verified" : false
    }
  },
  "id" : 115530939228094467,
  "created_at" : "2011-09-18 21:01:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115461573925027840",
  "geo" : { },
  "id_str" : "115461961843621888",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts back at ya with ((hugs)) - always nice to see your tweets!",
  "id" : 115461961843621888,
  "in_reply_to_status_id" : 115461573925027840,
  "created_at" : "2011-09-18 16:27:31 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115461506967146496",
  "text" : "RT @JohnCali: The desire to change others but cloaks your desire to change yourself. ~ Alan Cohen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115454579243614208",
    "text" : "The desire to change others but cloaks your desire to change yourself. ~ Alan Cohen",
    "id" : 115454579243614208,
    "created_at" : "2011-09-18 15:58:11 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 115461506967146496,
  "created_at" : "2011-09-18 16:25:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115461478475243522",
  "text" : "RT @JohnCali: Question: What is real? Answer: Real is what is perceived. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115454629021618176",
    "text" : "Question: What is real? Answer: Real is what is perceived. ~ Abraham",
    "id" : 115454629021618176,
    "created_at" : "2011-09-18 15:58:23 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 115461478475243522,
  "created_at" : "2011-09-18 16:25:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Jean-Michel Leclercq",
      "screen_name" : "jmleclercq",
      "indices" : [ 21, 32 ],
      "id_str" : "17948250",
      "id" : 17948250
    }, {
      "name" : "PhotoAsia",
      "screen_name" : "photoasia",
      "indices" : [ 106, 116 ],
      "id_str" : "256555214",
      "id" : 256555214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/9kBXSiIW",
      "expanded_url" : "http:\/\/togs.im\/lpgms",
      "display_url" : "togs.im\/lpgms"
    } ]
  },
  "geo" : { },
  "id_str" : "115456630073720832",
  "text" : "RT @DwayneReaves: RT @jmleclercq: 30 Awe-Inspiring Examples of Mist Photography http:\/\/t.co\/9kBXSiIW \/via @photoasia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jean-Michel Leclercq",
        "screen_name" : "jmleclercq",
        "indices" : [ 3, 14 ],
        "id_str" : "17948250",
        "id" : 17948250
      }, {
        "name" : "PhotoAsia",
        "screen_name" : "photoasia",
        "indices" : [ 88, 98 ],
        "id_str" : "256555214",
        "id" : 256555214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/9kBXSiIW",
        "expanded_url" : "http:\/\/togs.im\/lpgms",
        "display_url" : "togs.im\/lpgms"
      } ]
    },
    "geo" : { },
    "id_str" : "115452189606031361",
    "text" : "RT @jmleclercq: 30 Awe-Inspiring Examples of Mist Photography http:\/\/t.co\/9kBXSiIW \/via @photoasia",
    "id" : 115452189606031361,
    "created_at" : "2011-09-18 15:48:41 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 115456630073720832,
  "created_at" : "2011-09-18 16:06:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115455986122227713",
  "text" : "I see beautiful beings in my stream today. : ) Yup.. that includes you!",
  "id" : 115455986122227713,
  "created_at" : "2011-09-18 16:03:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/VDC7kxRW",
      "expanded_url" : "http:\/\/yfrog.com\/nyiohfuj",
      "display_url" : "yfrog.com\/nyiohfuj"
    } ]
  },
  "geo" : { },
  "id_str" : "115455537872764929",
  "text" : "RT @GaribaldiRous: Me and a squirrel. This will be part of the new blog post I am working on. http:\/\/t.co\/VDC7kxRW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/VDC7kxRW",
        "expanded_url" : "http:\/\/yfrog.com\/nyiohfuj",
        "display_url" : "yfrog.com\/nyiohfuj"
      } ]
    },
    "geo" : { },
    "id_str" : "115449329925369856",
    "text" : "Me and a squirrel. This will be part of the new blog post I am working on. http:\/\/t.co\/VDC7kxRW",
    "id" : 115449329925369856,
    "created_at" : "2011-09-18 15:37:19 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 115455537872764929,
  "created_at" : "2011-09-18 16:01:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115200556091457536",
  "text" : "RT @bunnybuddhism: Bunniness means being willing to connect with one another in new and often unexpected ways.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115198866541912065",
    "text" : "Bunniness means being willing to connect with one another in new and often unexpected ways.",
    "id" : 115198866541912065,
    "created_at" : "2011-09-17 23:02:04 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 115200556091457536,
  "created_at" : "2011-09-17 23:08:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115187240522616835",
  "text" : "@SamsaricWarrior you're certainly not shy with your tweets..lol. Reach past that comfort zone. If you want to do, then DO. Don't worry. : )",
  "id" : 115187240522616835,
  "created_at" : "2011-09-17 22:15:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115178453472522240",
  "geo" : { },
  "id_str" : "115186627898380289",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell ahhh.. yup.. they FAIL!",
  "id" : 115186627898380289,
  "in_reply_to_status_id" : 115178453472522240,
  "created_at" : "2011-09-17 22:13:26 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa April Smith",
      "screen_name" : "LisaAprilSmith",
      "indices" : [ 3, 18 ],
      "id_str" : "290168681",
      "id" : 290168681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115182044891459585",
  "text" : "RT @LisaAprilSmith: Blog about books and own a Kindle, iPad or smartphone? For a free copy of the hot mystery Dangerous Lies email Write ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115180239327465472",
    "text" : "Blog about books and own a Kindle, iPad or smartphone? For a free copy of the hot mystery Dangerous Lies email WriteLIsa@LisaAprilSmith.com",
    "id" : 115180239327465472,
    "created_at" : "2011-09-17 21:48:03 +0000",
    "user" : {
      "name" : "Lisa April Smith",
      "screen_name" : "LisaAprilSmith",
      "protected" : false,
      "id_str" : "290168681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560435401798602752\/Ms6DuJzh_normal.jpeg",
      "id" : 290168681,
      "verified" : false
    }
  },
  "id" : 115182044891459585,
  "created_at" : "2011-09-17 21:55:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115177542687801345",
  "text" : "@SamsaricWarrior why the heck you a skerrred little sissy? its selfish not to share your wisdom & creativity!",
  "id" : 115177542687801345,
  "created_at" : "2011-09-17 21:37:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115167247659577344",
  "geo" : { },
  "id_str" : "115170804282556416",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell do you have to print it? usually you just show it at biz, or it has code?",
  "id" : 115170804282556416,
  "in_reply_to_status_id" : 115167247659577344,
  "created_at" : "2011-09-17 21:10:34 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilke Breder",
      "screen_name" : "onejackdaw",
      "indices" : [ 3, 14 ],
      "id_str" : "79162356",
      "id" : 79162356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/GcUUu6rt",
      "expanded_url" : "http:\/\/nblo.gs\/ndB5u",
      "display_url" : "nblo.gs\/ndB5u"
    } ]
  },
  "geo" : { },
  "id_str" : "115107905132441600",
  "text" : "RT @onejackdaw: Trumpeter Swans at Montezuma NWR in upstate NY http:\/\/t.co\/GcUUu6rt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/GcUUu6rt",
        "expanded_url" : "http:\/\/nblo.gs\/ndB5u",
        "display_url" : "nblo.gs\/ndB5u"
      } ]
    },
    "geo" : { },
    "id_str" : "115107131576950786",
    "text" : "Trumpeter Swans at Montezuma NWR in upstate NY http:\/\/t.co\/GcUUu6rt",
    "id" : 115107131576950786,
    "created_at" : "2011-09-17 16:57:33 +0000",
    "user" : {
      "name" : "Hilke Breder",
      "screen_name" : "onejackdaw",
      "protected" : false,
      "id_str" : "79162356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595735568\/HB_4_4048_normal.jpg",
      "id" : 79162356,
      "verified" : false
    }
  },
  "id" : 115107905132441600,
  "created_at" : "2011-09-17 17:00:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115082736968007680",
  "text" : "RT @Soulseedzforall: Sometimes your worst fear becomes your greatest opportunity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115082430825771008",
    "text" : "Sometimes your worst fear becomes your greatest opportunity.",
    "id" : 115082430825771008,
    "created_at" : "2011-09-17 15:19:24 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 115082736968007680,
  "created_at" : "2011-09-17 15:20:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115080459762925568",
  "text" : "@SamsaricWarrior its so funny you feel that way.. cuz Im like that. if you were parent I was meeting I would feel not good enough.",
  "id" : 115080459762925568,
  "created_at" : "2011-09-17 15:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115078480139517953",
  "geo" : { },
  "id_str" : "115080161988329472",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses top right side of their profile (oops.. its blue when I hover over it.. so its actually white)",
  "id" : 115080161988329472,
  "in_reply_to_status_id" : 115078480139517953,
  "created_at" : "2011-09-17 15:10:23 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "115077247857205248",
  "geo" : { },
  "id_str" : "115078261284941824",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses blue friends box, dropdown list, click unfriend at bottom ?",
  "id" : 115078261284941824,
  "in_reply_to_status_id" : 115077247857205248,
  "created_at" : "2011-09-17 15:02:50 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115074993439776768",
  "text" : "@SamsaricWarrior habits are hard to break.",
  "id" : 115074993439776768,
  "created_at" : "2011-09-17 14:49:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna White Glaser",
      "screen_name" : "readdonnaglaser",
      "indices" : [ 3, 19 ],
      "id_str" : "174919515",
      "id" : 174919515
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcon2011",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115070163405111297",
  "text" : "RT @readdonnaglaser: Re. Ebooks Why is it friend or foe? It should be partners.  _ Astute reader quote  #bcon2011",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bcon2011",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115069968256741376",
    "text" : "Re. Ebooks Why is it friend or foe? It should be partners.  _ Astute reader quote  #bcon2011",
    "id" : 115069968256741376,
    "created_at" : "2011-09-17 14:29:52 +0000",
    "user" : {
      "name" : "Donna White Glaser",
      "screen_name" : "readdonnaglaser",
      "protected" : false,
      "id_str" : "174919515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1493489633\/D06F9042ret-comp_normal.jpg",
      "id" : 174919515,
      "verified" : false
    }
  },
  "id" : 115070163405111297,
  "created_at" : "2011-09-17 14:30:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115068654411976704",
  "text" : "RT @TrishScott: Waiting for circumstances to change so you can feel good is like looking in a mirror waiting for your reflection to smil ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115067754226266113",
    "text" : "Waiting for circumstances to change so you can feel good is like looking in a mirror waiting for your reflection to smile first.~Bashar",
    "id" : 115067754226266113,
    "created_at" : "2011-09-17 14:21:05 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 115068654411976704,
  "created_at" : "2011-09-17 14:24:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115068515861536768",
  "text" : "its cold.. bleh!",
  "id" : 115068515861536768,
  "created_at" : "2011-09-17 14:24:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114801296762077184",
  "text" : "@SamsaricWarrior ROFL... don't forget the bottle of rum! ; )",
  "id" : 114801296762077184,
  "created_at" : "2011-09-16 20:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 71, 85 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/dpevNxzl",
      "expanded_url" : "http:\/\/melodylamb.blogspot.com\/p\/newsletter-and-updates.html",
      "display_url" : "melodylamb.blogspot.com\/p\/newsletter-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114732899948953600",
  "text" : "I subscribed! Her mini art is beautiful! &gt;&gt; http:\/\/t.co\/dpevNxzl @MelodyLeaLamb",
  "id" : 114732899948953600,
  "created_at" : "2011-09-16 16:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The WOO",
      "screen_name" : "Woo100",
      "indices" : [ 3, 10 ],
      "id_str" : "29075225",
      "id" : 29075225
    }, {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 12, 28 ],
      "id_str" : "95607516",
      "id" : 95607516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114719067507658752",
  "text" : "RT @Woo100: @DonkeySanctuary Indeed! Donkeycam is the perfect answer to stress! Docs should prescribe it, 5 mins of Donkeycam to be take ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Donkey Sanctuary",
        "screen_name" : "DonkeySanctuary",
        "indices" : [ 0, 16 ],
        "id_str" : "95607516",
        "id" : 95607516
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "114698525538926592",
    "geo" : { },
    "id_str" : "114704058417295361",
    "in_reply_to_user_id" : 95607516,
    "text" : "@DonkeySanctuary Indeed! Donkeycam is the perfect answer to stress! Docs should prescribe it, 5 mins of Donkeycam to be taken as required!",
    "id" : 114704058417295361,
    "in_reply_to_status_id" : 114698525538926592,
    "created_at" : "2011-09-16 14:15:53 +0000",
    "in_reply_to_screen_name" : "DonkeySanctuary",
    "in_reply_to_user_id_str" : "95607516",
    "user" : {
      "name" : "The WOO",
      "screen_name" : "Woo100",
      "protected" : false,
      "id_str" : "29075225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748096764335382528\/ekq8-3wW_normal.jpg",
      "id" : 29075225,
      "verified" : false
    }
  },
  "id" : 114719067507658752,
  "created_at" : "2011-09-16 15:15:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "indices" : [ 3, 17 ],
      "id_str" : "253228348",
      "id" : 253228348
    }, {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "indices" : [ 93, 107 ],
      "id_str" : "253228348",
      "id" : 253228348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114718452526223361",
  "text" : "RT @GreyMuzzleOrg: Can you help a senior shelter dog out? Please tell one friend today about @GreyMuzzleOrg !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GreyMuzzleOrg",
        "screen_name" : "GreyMuzzleOrg",
        "indices" : [ 74, 88 ],
        "id_str" : "253228348",
        "id" : 253228348
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114717900350308352",
    "text" : "Can you help a senior shelter dog out? Please tell one friend today about @GreyMuzzleOrg !",
    "id" : 114717900350308352,
    "created_at" : "2011-09-16 15:10:53 +0000",
    "user" : {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "protected" : false,
      "id_str" : "253228348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770761270416908289\/ZOXprD-__normal.jpg",
      "id" : 253228348,
      "verified" : false
    }
  },
  "id" : 114718452526223361,
  "created_at" : "2011-09-16 15:13:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114702661898600448",
  "text" : "@HEATHENRABBIT mommy chose mothers day to leave this world. she now sits next to dad in our dining room. so far, they've been good..lol",
  "id" : 114702661898600448,
  "created_at" : "2011-09-16 14:10:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 56, 69 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114696849142710272",
  "text" : "good luck w interview today. you're in my thoughts. : ) @DwayneReaves",
  "id" : 114696849142710272,
  "created_at" : "2011-09-16 13:47:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 58, 74 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/8pw72cb4",
      "expanded_url" : "http:\/\/www.readerswin.com\/phpld\/index.php?c=14",
      "display_url" : "readerswin.com\/phpld\/index.ph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114360297682247680",
  "text" : "Win An E-ink Capsule Ball on Twitter http:\/\/t.co\/8pw72cb4 @thDigitalReader",
  "id" : 114360297682247680,
  "created_at" : "2011-09-15 15:29:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ancient Proverbs",
      "screen_name" : "AncientProverbs",
      "indices" : [ 3, 19 ],
      "id_str" : "226922556",
      "id" : 226922556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114341072041279488",
  "text" : "RT @AncientProverbs: Be kind, for everyone you meet is fighting a hard battle. -Plato",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114337006775054337",
    "text" : "Be kind, for everyone you meet is fighting a hard battle. -Plato",
    "id" : 114337006775054337,
    "created_at" : "2011-09-15 13:57:21 +0000",
    "user" : {
      "name" : "Sports Motivation",
      "screen_name" : "Sports_HQ",
      "protected" : false,
      "id_str" : "139986343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2679035753\/b0d2eb7d0b01e7381bd8ca944b055f60_normal.jpeg",
      "id" : 139986343,
      "verified" : false
    }
  },
  "id" : 114341072041279488,
  "created_at" : "2011-09-15 14:13:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blog Kindle",
      "screen_name" : "BlogKindle",
      "indices" : [ 3, 14 ],
      "id_str" : "42677929",
      "id" : 42677929
    }, {
      "name" : "Blog Kindle",
      "screen_name" : "BlogKindle",
      "indices" : [ 56, 67 ],
      "id_str" : "42677929",
      "id" : 42677929
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "amazon",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "kindle",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/HxMK01g",
      "expanded_url" : "http:\/\/blogkindle.com\/2011\/09\/free-kindle-3g-giveaway\/",
      "display_url" : "blogkindle.com\/2011\/09\/free-k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114324221391405057",
  "text" : "RT @BlogKindle: Win #free #amazon #kindle - just follow @blogkindle and retweet this message - http:\/\/t.co\/HxMK01g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blog Kindle",
        "screen_name" : "BlogKindle",
        "indices" : [ 40, 51 ],
        "id_str" : "42677929",
        "id" : 42677929
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "amazon",
        "indices" : [ 10, 17 ]
      }, {
        "text" : "kindle",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 98 ],
        "url" : "http:\/\/t.co\/HxMK01g",
        "expanded_url" : "http:\/\/blogkindle.com\/2011\/09\/free-kindle-3g-giveaway\/",
        "display_url" : "blogkindle.com\/2011\/09\/free-k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "111982324157136896",
    "text" : "Win #free #amazon #kindle - just follow @blogkindle and retweet this message - http:\/\/t.co\/HxMK01g",
    "id" : 111982324157136896,
    "created_at" : "2011-09-09 02:00:41 +0000",
    "user" : {
      "name" : "Blog Kindle",
      "screen_name" : "BlogKindle",
      "protected" : false,
      "id_str" : "42677929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/245765675\/blogkindle-logo_normal.png",
      "id" : 42677929,
      "verified" : false
    }
  },
  "id" : 114324221391405057,
  "created_at" : "2011-09-15 13:06:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Nobody",
      "screen_name" : "1anobody",
      "indices" : [ 3, 12 ],
      "id_str" : "57143767",
      "id" : 57143767
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 68, 81 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114166955614797824",
  "text" : "RT @1anobody: If so inclined please do a feel good deed tonight for @DwayneReaves who is at the end of a rope & consumed by stress. bit. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dwayne Reaves",
        "screen_name" : "dwaynereaves",
        "indices" : [ 54, 67 ],
        "id_str" : "73908822",
        "id" : 73908822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114155170916597760",
    "text" : "If so inclined please do a feel good deed tonight for @DwayneReaves who is at the end of a rope & consumed by stress. bit.ly\/qlcYmz",
    "id" : 114155170916597760,
    "created_at" : "2011-09-15 01:54:48 +0000",
    "user" : {
      "name" : "A Nobody",
      "screen_name" : "1anobody",
      "protected" : false,
      "id_str" : "57143767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/348582594\/LOGO2_normal.jpg",
      "id" : 57143767,
      "verified" : false
    }
  },
  "id" : 114166955614797824,
  "created_at" : "2011-09-15 02:41:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114160310587375616",
  "geo" : { },
  "id_str" : "114164569148112896",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 ((hugs))",
  "id" : 114164569148112896,
  "in_reply_to_status_id" : 114160310587375616,
  "created_at" : "2011-09-15 02:32:09 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "114144655037317120",
  "geo" : { },
  "id_str" : "114150051571433472",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves what am I to do with you, Dwayne?",
  "id" : 114150051571433472,
  "in_reply_to_status_id" : 114144655037317120,
  "created_at" : "2011-09-15 01:34:27 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Warren",
      "screen_name" : "film_girl",
      "indices" : [ 3, 13 ],
      "id_str" : "9866582",
      "id" : 9866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Ez33EmpU",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2011\/09\/13\/1016557\/-That-was-my-brothers-death-you-were-cheering,-you-a$$holes-Updated",
      "display_url" : "dailykos.com\/story\/2011\/09\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114149518643175424",
  "text" : "RT @film_girl: That was my brother's death you were cheering, you a$$holes Updated http:\/\/t.co\/Ez33EmpU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/Ez33EmpU",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2011\/09\/13\/1016557\/-That-was-my-brothers-death-you-were-cheering,-you-a$$holes-Updated",
        "display_url" : "dailykos.com\/story\/2011\/09\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "114119365481336832",
    "text" : "That was my brother's death you were cheering, you a$$holes Updated http:\/\/t.co\/Ez33EmpU",
    "id" : 114119365481336832,
    "created_at" : "2011-09-14 23:32:31 +0000",
    "user" : {
      "name" : "Christina Warren",
      "screen_name" : "film_girl",
      "protected" : false,
      "id_str" : "9866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661230566285557761\/WvOijxjJ_normal.jpg",
      "id" : 9866582,
      "verified" : true
    }
  },
  "id" : 114149518643175424,
  "created_at" : "2011-09-15 01:32:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113977441038503936",
  "text" : "I believe in humanity. I will never stop cheering for us.",
  "id" : 113977441038503936,
  "created_at" : "2011-09-14 14:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113687116617236480",
  "geo" : { },
  "id_str" : "113760379699605505",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell thank you for your sweet comment. makes my day! : )",
  "id" : 113760379699605505,
  "in_reply_to_status_id" : 113687116617236480,
  "created_at" : "2011-09-13 23:46:02 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113425923214278656",
  "text" : "RT @JosephRanseth: You have no obligation to live up to anyone else's expectations... just remember to extend them the same courtesy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113425332777918464",
    "text" : "You have no obligation to live up to anyone else's expectations... just remember to extend them the same courtesy.",
    "id" : 113425332777918464,
    "created_at" : "2011-09-13 01:34:41 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 113425923214278656,
  "created_at" : "2011-09-13 01:37:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 32, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113328470007885824",
  "text" : "RT @DuttonBooks: RT to enter to #win a copy of BLOOD FEUD by Kathleen Sharp. True story of a salesman who blew the whistle on a deadly p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 15, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113327291320385536",
    "text" : "RT to enter to #win a copy of BLOOD FEUD by Kathleen Sharp. True story of a salesman who blew the whistle on a deadly prescription drug.",
    "id" : 113327291320385536,
    "created_at" : "2011-09-12 19:05:06 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 113328470007885824,
  "created_at" : "2011-09-12 19:09:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113314471115620352",
  "text" : "RT @BrianMerritt: People are strange creatures.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113312697436745728",
    "text" : "People are strange creatures.",
    "id" : 113312697436745728,
    "created_at" : "2011-09-12 18:07:06 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 113314471115620352,
  "created_at" : "2011-09-12 18:14:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "indices" : [ 3, 17 ],
      "id_str" : "8833312",
      "id" : 8833312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113292767064625152",
  "text" : "RT @MicheleKnight: We are in a revolutionary time, so be a warrior of love as each of us creates the whole..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113292064170590209",
    "text" : "We are in a revolutionary time, so be a warrior of love as each of us creates the whole..",
    "id" : 113292064170590209,
    "created_at" : "2011-09-12 16:45:07 +0000",
    "user" : {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "protected" : false,
      "id_str" : "8833312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616164060292337664\/DM_Io58r_normal.jpg",
      "id" : 8833312,
      "verified" : false
    }
  },
  "id" : 113292767064625152,
  "created_at" : "2011-09-12 16:47:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "113265029628964864",
  "geo" : { },
  "id_str" : "113266688090324992",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awww.. that's sweet! : )",
  "id" : 113266688090324992,
  "in_reply_to_status_id" : 113265029628964864,
  "created_at" : "2011-09-12 15:04:17 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113041548379303936",
  "text" : "RT @ShipsofSong: U don't need demons on the doorstep 4 humanity 2 experience tribulation, U only need humanity's fear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113035942486478848",
    "text" : "U don't need demons on the doorstep 4 humanity 2 experience tribulation, U only need humanity's fear.",
    "id" : 113035942486478848,
    "created_at" : "2011-09-11 23:47:23 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 113041548379303936,
  "created_at" : "2011-09-12 00:09:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113041383530569730",
  "text" : "@SamsaricWarrior he looks good!",
  "id" : 113041383530569730,
  "created_at" : "2011-09-12 00:09:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112682759960530944",
  "text" : "sometimes I really hate being a girl...",
  "id" : 112682759960530944,
  "created_at" : "2011-09-11 00:23:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112552963326754816",
  "text" : "The Saturday Pet Blogger Hop: The Birthday Puppy via @nigelbugger",
  "id" : 112552963326754816,
  "created_at" : "2011-09-10 15:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112535433853927425",
  "text" : "RT @BrianMerritt: Life is a tragedy when seen in close-up, but a comedy in long-shot.  Charlie Chaplin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112533585692602369",
    "text" : "Life is a tragedy when seen in close-up, but a comedy in long-shot.  Charlie Chaplin",
    "id" : 112533585692602369,
    "created_at" : "2011-09-10 14:31:12 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 112535433853927425,
  "created_at" : "2011-09-10 14:38:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USE",
      "indices" : [ 106, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112321682575855616",
  "text" : "RT @UnseeingEyes: But we must concentrate & focus on the living...on life...that which is past...is gone. #USE -V-",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USE",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112321227288354817",
    "text" : "But we must concentrate & focus on the living...on life...that which is past...is gone. #USE -V-",
    "id" : 112321227288354817,
    "created_at" : "2011-09-10 00:27:22 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 112321682575855616,
  "created_at" : "2011-09-10 00:29:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas W Lance",
      "screen_name" : "douglance",
      "indices" : [ 3, 13 ],
      "id_str" : "757782870329024512",
      "id" : 757782870329024512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112297358506721280",
  "text" : "RT @DougLance: Every society honors its live conformists and its dead troublemakers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112297168152428544",
    "text" : "Every society honors its live conformists and its dead troublemakers.",
    "id" : 112297168152428544,
    "created_at" : "2011-09-09 22:51:45 +0000",
    "user" : {
      "name" : "Douglas W. Lance",
      "screen_name" : "DouglasWLance",
      "protected" : false,
      "id_str" : "14164456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000334743376\/a99c70bf244662760a73dc24c1b1588f_normal.png",
      "id" : 14164456,
      "verified" : false
    }
  },
  "id" : 112297358506721280,
  "created_at" : "2011-09-09 22:52:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USE",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112297343671468032",
  "text" : "RT @UnseeingEyes: We are asleep with compasses in our hands.  #USE -W.S. Merwin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USE",
        "indices" : [ 44, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112297089538592768",
    "text" : "We are asleep with compasses in our hands.  #USE -W.S. Merwin",
    "id" : 112297089538592768,
    "created_at" : "2011-09-09 22:51:27 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 112297343671468032,
  "created_at" : "2011-09-09 22:52:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 3, 17 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http:\/\/t.co\/2Qbyjh0",
      "expanded_url" : "http:\/\/bit.ly\/babysparrow",
      "display_url" : "bit.ly\/babysparrow"
    } ]
  },
  "geo" : { },
  "id_str" : "112184787522945025",
  "text" : "RT @MelodyLeaLamb: My Amazing Experience-Raising Baby Bird: http:\/\/t.co\/2Qbyjh0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 60 ],
        "url" : "http:\/\/t.co\/2Qbyjh0",
        "expanded_url" : "http:\/\/bit.ly\/babysparrow",
        "display_url" : "bit.ly\/babysparrow"
      } ]
    },
    "geo" : { },
    "id_str" : "112183484432384000",
    "text" : "My Amazing Experience-Raising Baby Bird: http:\/\/t.co\/2Qbyjh0",
    "id" : 112183484432384000,
    "created_at" : "2011-09-09 15:20:01 +0000",
    "user" : {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "protected" : false,
      "id_str" : "15855422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94236021\/NewPic_normal.JPG",
      "id" : 15855422,
      "verified" : false
    }
  },
  "id" : 112184787522945025,
  "created_at" : "2011-09-09 15:25:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 0, 13 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112179440162848768",
  "geo" : { },
  "id_str" : "112180949579599873",
  "in_reply_to_user_id" : 42974138,
  "text" : "@GraveStomper oops..lol..",
  "id" : 112180949579599873,
  "in_reply_to_status_id" : 112179440162848768,
  "created_at" : "2011-09-09 15:09:57 +0000",
  "in_reply_to_screen_name" : "GraveStomper",
  "in_reply_to_user_id_str" : "42974138",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112179121769037824",
  "text" : "RT @GraveStomper: Basically I do whatever needs to be done to help people get back to who they really are at their core...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112176318459809792",
    "text" : "Basically I do whatever needs to be done to help people get back to who they really are at their core...",
    "id" : 112176318459809792,
    "created_at" : "2011-09-09 14:51:33 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 112179121769037824,
  "created_at" : "2011-09-09 15:02:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "112177727758540800",
  "geo" : { },
  "id_str" : "112178899257016321",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen omg'ness.. my feelings exactly!! it's driving me nuts all the stuff on tv about it.",
  "id" : 112178899257016321,
  "in_reply_to_status_id" : 112177727758540800,
  "created_at" : "2011-09-09 15:01:48 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112168812719247360",
  "text" : "people trying to control other people will never fix the world...",
  "id" : 112168812719247360,
  "created_at" : "2011-09-09 14:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111987069324234752",
  "text" : "zombie drill at tkd tonight.. so much fun!!",
  "id" : 111987069324234752,
  "created_at" : "2011-09-09 02:19:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111856537034702848",
  "geo" : { },
  "id_str" : "111857249978302464",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC I LOVE a good peach (plum, nectarine, orange) .. gotta be sweet and not too mushy, tho. picky about my fresh foods..lol",
  "id" : 111857249978302464,
  "in_reply_to_status_id" : 111856537034702848,
  "created_at" : "2011-09-08 17:43:41 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111856855415914496",
  "text" : "1st day back to school. hope she does ok. its as bad on me as on her..lol",
  "id" : 111856855415914496,
  "created_at" : "2011-09-08 17:42:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111841069217488896",
  "text" : "RT @adampknave: I keep seeing \"Google buys Zagat\" but my brain keeps parsing it as \"Google buys Saget.\" As in Bob. WHY DID YOU BUY BOB S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111839121005219841",
    "text" : "I keep seeing \"Google buys Zagat\" but my brain keeps parsing it as \"Google buys Saget.\" As in Bob. WHY DID YOU BUY BOB SAGET, GOOGLE?!",
    "id" : 111839121005219841,
    "created_at" : "2011-09-08 16:31:38 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 111841069217488896,
  "created_at" : "2011-09-08 16:39:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111841029493235712",
  "text" : "RT @bcmouser: Maybe some are the way they are because no one has shown them kindness & grace in a transformative & compelling way. \n\n#ou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "outlawpreachers",
        "indices" : [ 119, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111839384042614784",
    "text" : "Maybe some are the way they are because no one has shown them kindness & grace in a transformative & compelling way. \n\n#outlawpreachers",
    "id" : 111839384042614784,
    "created_at" : "2011-09-08 16:32:41 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 111841029493235712,
  "created_at" : "2011-09-08 16:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111620443550654465",
  "text" : "RT @ShipsofSong: Life is eternal. Do not allow the illusion to betray you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111617815932436481",
    "text" : "Life is eternal. Do not allow the illusion to betray you.",
    "id" : 111617815932436481,
    "created_at" : "2011-09-08 01:52:15 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 111620443550654465,
  "created_at" : "2011-09-08 02:02:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    }, {
      "name" : "Daniel",
      "screen_name" : "ThatFeelsNICE",
      "indices" : [ 23, 37 ],
      "id_str" : "151920532",
      "id" : 151920532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111579982895124480",
  "text" : "RT @AnAmericanMonk: RT @ThatFeelsNICE: No evidence will convince you of the truth of what you do not want.- A Course in miracles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel",
        "screen_name" : "ThatFeelsNICE",
        "indices" : [ 3, 17 ],
        "id_str" : "151920532",
        "id" : 151920532
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111577132806840320",
    "text" : "RT @ThatFeelsNICE: No evidence will convince you of the truth of what you do not want.- A Course in miracles",
    "id" : 111577132806840320,
    "created_at" : "2011-09-07 23:10:36 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 111579982895124480,
  "created_at" : "2011-09-07 23:21:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/111471282322804737\/photo\/1",
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/qA2O0YP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYwGimnCEAAH9L1.jpg",
      "id_str" : "111471282326999040",
      "id" : 111471282326999040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYwGimnCEAAH9L1.jpg",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 341
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 341
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 341
      } ],
      "display_url" : "pic.twitter.com\/qA2O0YP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111475776104312832",
  "text" : "RT @petsalive: An inbred cat. http:\/\/t.co\/qA2O0YP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/111471282322804737\/photo\/1",
        "indices" : [ 15, 34 ],
        "url" : "http:\/\/t.co\/qA2O0YP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AYwGimnCEAAH9L1.jpg",
        "id_str" : "111471282326999040",
        "id" : 111471282326999040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYwGimnCEAAH9L1.jpg",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 341
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 341
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 341
        } ],
        "display_url" : "pic.twitter.com\/qA2O0YP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111471282322804737",
    "text" : "An inbred cat. http:\/\/t.co\/qA2O0YP",
    "id" : 111471282322804737,
    "created_at" : "2011-09-07 16:09:59 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 111475776104312832,
  "created_at" : "2011-09-07 16:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NatHunter953",
      "screen_name" : "NatHunter953",
      "indices" : [ 3, 16 ],
      "id_str" : "2500417250",
      "id" : 2500417250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111473596504875008",
  "text" : "RT @NatHunter953: Don't u hate it when u get so drunk on fermented apples that you end up stuck in a tree?! Don't worry - he's okay now. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatHunter953\/status\/111472730913775619\/photo\/1",
        "indices" : [ 119, 138 ],
        "url" : "http:\/\/t.co\/n3sHjXo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AYwH27DCIAAcGyD.jpg",
        "id_str" : "111472730922164224",
        "id" : 111472730922164224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYwH27DCIAAcGyD.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/n3sHjXo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111472730913775619",
    "text" : "Don't u hate it when u get so drunk on fermented apples that you end up stuck in a tree?! Don't worry - he's okay now. http:\/\/t.co\/n3sHjXo",
    "id" : 111472730913775619,
    "created_at" : "2011-09-07 16:15:45 +0000",
    "user" : {
      "name" : "Natalie Hunter",
      "screen_name" : "nathunter1035",
      "protected" : false,
      "id_str" : "42898131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451013516611170304\/su0v589R_normal.jpeg",
      "id" : 42898131,
      "verified" : false
    }
  },
  "id" : 111473596504875008,
  "created_at" : "2011-09-07 16:19:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111461462614085632",
  "text" : "LOLOL @SamsaricWarrior",
  "id" : 111461462614085632,
  "created_at" : "2011-09-07 15:30:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111446779895099393",
  "text" : "puppy liked getting a rub-down after being out in rain...",
  "id" : 111446779895099393,
  "created_at" : "2011-09-07 14:32:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "111125235692085248",
  "geo" : { },
  "id_str" : "111126034706997248",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld ..just slap them..lol..love it! : )",
  "id" : 111126034706997248,
  "in_reply_to_status_id" : 111125235692085248,
  "created_at" : "2011-09-06 17:18:05 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111125882936098817",
  "text" : "RT @Buddhaworld: dont let anybody tell you what to do, and if they try, slap them. buddha volko.#lovecoach#spirituality#life",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111125235692085248",
    "text" : "dont let anybody tell you what to do, and if they try, slap them. buddha volko.#lovecoach#spirituality#life",
    "id" : 111125235692085248,
    "created_at" : "2011-09-06 17:14:55 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 111125882936098817,
  "created_at" : "2011-09-06 17:17:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rain Gatdula",
      "screen_name" : "RainGatdula",
      "indices" : [ 3, 15 ],
      "id_str" : "3188065214",
      "id" : 3188065214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111073740816781312",
  "text" : "RT @raingatdula: Lyman Beecher~ Never chase a lie. Let it alone and it will run itself to death.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110981558441226240",
    "text" : "Lyman Beecher~ Never chase a lie. Let it alone and it will run itself to death.",
    "id" : 110981558441226240,
    "created_at" : "2011-09-06 07:44:00 +0000",
    "user" : {
      "name" : "Rain",
      "screen_name" : "rainhimself",
      "protected" : false,
      "id_str" : "67592283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000020820376\/d021dda1e6294bd5391832745494b412_normal.jpeg",
      "id" : 67592283,
      "verified" : false
    }
  },
  "id" : 111073740816781312,
  "created_at" : "2011-09-06 13:50:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111073119556485120",
  "text" : "lots of angry dreams lately. me swearing & yelling at people.. ugh.",
  "id" : 111073119556485120,
  "created_at" : "2011-09-06 13:47:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111072969249402880",
  "text" : "hey what does it mean when you get no fortune in your fortune cookie? happened to me other day.",
  "id" : 111072969249402880,
  "created_at" : "2011-09-06 13:47:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110889570379374593",
  "text" : "so MIL has decided I'm going to the bible study group starting up again after summer break. I guess it makes her happy.",
  "id" : 110889570379374593,
  "created_at" : "2011-09-06 01:38:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 16, 25 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Nigella Hillgarth",
      "screen_name" : "NHillgarth",
      "indices" : [ 42, 53 ],
      "id_str" : "63913500",
      "id" : 63913500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eco",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "photo",
      "indices" : [ 122, 128 ]
    }, {
      "text" : "nature",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/3sXkDs7",
      "expanded_url" : "http:\/\/dld.bz\/apcmY",
      "display_url" : "dld.bz\/apcmY"
    } ]
  },
  "geo" : { },
  "id_str" : "110838453285044224",
  "text" : "RT @wildobs: RT @KerriFar: Beyond WOW! RT @NHillgarth: A Beautiful Fox In my Yard this morning~  #eco http:\/\/t.co\/3sXkDs7 #photo #nature ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KerriFar",
        "screen_name" : "KerriFar",
        "indices" : [ 3, 12 ],
        "id_str" : "12088232",
        "id" : 12088232
      }, {
        "name" : "Nigella Hillgarth",
        "screen_name" : "NHillgarth",
        "indices" : [ 29, 40 ],
        "id_str" : "63913500",
        "id" : 63913500
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eco",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "photo",
        "indices" : [ 109, 115 ]
      }, {
        "text" : "nature",
        "indices" : [ 116, 123 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 108 ],
        "url" : "http:\/\/t.co\/3sXkDs7",
        "expanded_url" : "http:\/\/dld.bz\/apcmY",
        "display_url" : "dld.bz\/apcmY"
      } ]
    },
    "geo" : { },
    "id_str" : "110835792124985344",
    "text" : "RT @KerriFar: Beyond WOW! RT @NHillgarth: A Beautiful Fox In my Yard this morning~  #eco http:\/\/t.co\/3sXkDs7 #photo #nature #wildlife",
    "id" : 110835792124985344,
    "created_at" : "2011-09-05 22:04:46 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 110838453285044224,
  "created_at" : "2011-09-05 22:15:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110772124238618624",
  "text" : "RT @ReverendSue: Killing animals that kill humans who enter their natural territory is NOT a solution. End destruction of animal habitat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bears",
        "indices" : [ 122, 128 ]
      }, {
        "text" : "green",
        "indices" : [ 129, 135 ]
      }, {
        "text" : "p2",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110771502495969280",
    "text" : "Killing animals that kill humans who enter their natural territory is NOT a solution. End destruction of animal habitats! #bears #green #p2",
    "id" : 110771502495969280,
    "created_at" : "2011-09-05 17:49:18 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 110772124238618624,
  "created_at" : "2011-09-05 17:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110747720674844672",
  "text" : "sinuses irritated past 2 days. vicious headaches. bleh.",
  "id" : 110747720674844672,
  "created_at" : "2011-09-05 16:14:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MB's eBookNewser",
      "screen_name" : "eBookNewser",
      "indices" : [ 3, 15 ],
      "id_str" : "509372493",
      "id" : 509372493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HarryPotter",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/p5CwzPP",
      "expanded_url" : "http:\/\/mbist.ro\/qV3zGr",
      "display_url" : "mbist.ro\/qV3zGr"
    } ]
  },
  "geo" : { },
  "id_str" : "110747489069563906",
  "text" : "RT @eBookNewser: The upcoming $149 Sony Reader will ship with a coupon for free #HarryPotter eBook: http:\/\/t.co\/p5CwzPP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HarryPotter",
        "indices" : [ 63, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 102 ],
        "url" : "http:\/\/t.co\/p5CwzPP",
        "expanded_url" : "http:\/\/mbist.ro\/qV3zGr",
        "display_url" : "mbist.ro\/qV3zGr"
      } ]
    },
    "geo" : { },
    "id_str" : "110745760332644352",
    "text" : "The upcoming $149 Sony Reader will ship with a coupon for free #HarryPotter eBook: http:\/\/t.co\/p5CwzPP",
    "id" : 110745760332644352,
    "created_at" : "2011-09-05 16:07:01 +0000",
    "user" : {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "protected" : false,
      "id_str" : "90893629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461987151496744960\/7LSAvXUw_normal.png",
      "id" : 90893629,
      "verified" : false
    }
  },
  "id" : 110747489069563906,
  "created_at" : "2011-09-05 16:13:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110522622617456640",
  "text" : "still makes me sad that the hospital left my mother in pain for 6 hours while waiting for neuro consult to get there.",
  "id" : 110522622617456640,
  "created_at" : "2011-09-05 01:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109631712992043009",
  "text" : "Needed - testers for new site. Book bloggers, reviews, giveaways. readerswin.com\/phpld\/ Thanks!",
  "id" : 109631712992043009,
  "created_at" : "2011-09-02 14:20:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake Jensen",
      "screen_name" : "BigBadBlake",
      "indices" : [ 3, 15 ],
      "id_str" : "2161990044",
      "id" : 2161990044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109405071036514304",
  "text" : "RT @BigBadBlake: Twitter is like having a diary you only want strangers to read.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77528047259090944",
    "text" : "Twitter is like having a diary you only want strangers to read.",
    "id" : 77528047259090944,
    "created_at" : "2011-06-06 00:11:41 +0000",
    "user" : {
      "name" : "WalterBlakeKnoblock",
      "screen_name" : "WBKnoblock",
      "protected" : false,
      "id_str" : "26518374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731674535129432068\/J4yCYhnE_normal.jpg",
      "id" : 26518374,
      "verified" : false
    }
  },
  "id" : 109405071036514304,
  "created_at" : "2011-09-01 23:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109359192598511616",
  "text" : "book bloggers.. need help testing my site. any volunteers?",
  "id" : 109359192598511616,
  "created_at" : "2011-09-01 20:17:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]