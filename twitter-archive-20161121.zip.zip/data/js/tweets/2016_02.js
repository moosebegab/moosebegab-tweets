Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704480357270331392",
  "text" : "DD: think about your life choices, mother, and how they affect those around you.",
  "id" : 704480357270331392,
  "created_at" : "2016-03-01 01:36:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 3, 14 ],
      "id_str" : "15314194",
      "id" : 15314194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704467114585956354",
  "text" : "RT @dee_carney: I could eat the hell out of a piece of carrot cake with cream cheese frosting right now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704465668054376448",
    "text" : "I could eat the hell out of a piece of carrot cake with cream cheese frosting right now.",
    "id" : 704465668054376448,
    "created_at" : "2016-03-01 00:37:58 +0000",
    "user" : {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "protected" : false,
      "id_str" : "15314194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649739435890839552\/00nSuPH-_normal.jpg",
      "id" : 15314194,
      "verified" : false
    }
  },
  "id" : 704467114585956354,
  "created_at" : "2016-03-01 00:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    }, {
      "name" : "Landon Schott",
      "screen_name" : "landonschott",
      "indices" : [ 35, 48 ],
      "id_str" : "32962854",
      "id" : 32962854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/HTZHgCsES5",
      "expanded_url" : "https:\/\/twitter.com\/landonschott\/status\/704403350805045249",
      "display_url" : "twitter.com\/landonschott\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704462007630749696",
  "text" : "RT @Irish_Atheist: A reminder that @landonschott is an anti-LGBT predator, exploiting us for his own profit. https:\/\/t.co\/HTZHgCsES5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Landon Schott",
        "screen_name" : "landonschott",
        "indices" : [ 16, 29 ],
        "id_str" : "32962854",
        "id" : 32962854
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/HTZHgCsES5",
        "expanded_url" : "https:\/\/twitter.com\/landonschott\/status\/704403350805045249",
        "display_url" : "twitter.com\/landonschott\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704455450390040576",
    "text" : "A reminder that @landonschott is an anti-LGBT predator, exploiting us for his own profit. https:\/\/t.co\/HTZHgCsES5",
    "id" : 704455450390040576,
    "created_at" : "2016-02-29 23:57:22 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 704462007630749696,
  "created_at" : "2016-03-01 00:23:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/704456408029331456\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/1ufrIKqBjs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cca7XthWIAAEh7j.jpg",
      "id_str" : "704456407760904192",
      "id" : 704456407760904192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cca7XthWIAAEh7j.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1ufrIKqBjs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704460154683707393",
  "text" : "RT @SciencePorn: I'm up for the fight. https:\/\/t.co\/1ufrIKqBjs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/704456408029331456\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/1ufrIKqBjs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cca7XthWIAAEh7j.jpg",
        "id_str" : "704456407760904192",
        "id" : 704456407760904192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cca7XthWIAAEh7j.jpg",
        "sizes" : [ {
          "h" : 601,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1ufrIKqBjs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704456408029331456",
    "text" : "I'm up for the fight. https:\/\/t.co\/1ufrIKqBjs",
    "id" : 704456408029331456,
    "created_at" : "2016-03-01 00:01:10 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 704460154683707393,
  "created_at" : "2016-03-01 00:16:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "Crispi66",
      "indices" : [ 3, 12 ],
      "id_str" : "603459434",
      "id" : 603459434
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Crispi66\/status\/704206218760462336\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Mvf5AG4GLp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcXXzOeWEAArej8.jpg",
      "id_str" : "704206191812022272",
      "id" : 704206191812022272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcXXzOeWEAArej8.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2275
      } ],
      "display_url" : "pic.twitter.com\/Mvf5AG4GLp"
    } ],
    "hashtags" : [ {
      "text" : "kittyloafmonday",
      "indices" : [ 65, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704455569986494469",
  "text" : "RT @Crispi66: \"Still raining Zoe ?\"\n\"...Ughh...\" \uD83D\uDE03\nGrumpy double\n#kittyloafmonday  \uD83C\uDF02 https:\/\/t.co\/Mvf5AG4GLp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Crispi66\/status\/704206218760462336\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Mvf5AG4GLp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcXXzOeWEAArej8.jpg",
        "id_str" : "704206191812022272",
        "id" : 704206191812022272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcXXzOeWEAArej8.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 2275
        } ],
        "display_url" : "pic.twitter.com\/Mvf5AG4GLp"
      } ],
      "hashtags" : [ {
        "text" : "kittyloafmonday",
        "indices" : [ 51, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704206218760462336",
    "text" : "\"Still raining Zoe ?\"\n\"...Ughh...\" \uD83D\uDE03\nGrumpy double\n#kittyloafmonday  \uD83C\uDF02 https:\/\/t.co\/Mvf5AG4GLp",
    "id" : 704206218760462336,
    "created_at" : "2016-02-29 07:27:00 +0000",
    "user" : {
      "name" : "Cristina",
      "screen_name" : "Crispi66",
      "protected" : false,
      "id_str" : "603459434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587164356485451776\/FvLBVKIy_normal.jpg",
      "id" : 603459434,
      "verified" : false
    }
  },
  "id" : 704455569986494469,
  "created_at" : "2016-02-29 23:57:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 3, 14 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "704451743531339776",
  "text" : "RT @WhiteHouse: The last time a president's Supreme Court nominee was denied a hearing?\n \n1875.\n\nhttps:\/\/t.co\/O5iYU1cW6b #SCOTUS https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/704422548226875392\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ZHCQoZaXiU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccacf-xWAAEHoZu.jpg",
        "id_str" : "704422464969900033",
        "id" : 704422464969900033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccacf-xWAAEHoZu.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZHCQoZaXiU"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/O5iYU1cW6b",
        "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
        "display_url" : "go.wh.gov\/SCOTUS"
      } ]
    },
    "geo" : { },
    "id_str" : "704422548226875392",
    "text" : "The last time a president's Supreme Court nominee was denied a hearing?\n \n1875.\n\nhttps:\/\/t.co\/O5iYU1cW6b #SCOTUS https:\/\/t.co\/ZHCQoZaXiU",
    "id" : 704422548226875392,
    "created_at" : "2016-02-29 21:46:37 +0000",
    "user" : {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "protected" : false,
      "id_str" : "30313925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
      "id" : 30313925,
      "verified" : true
    }
  },
  "id" : 704451743531339776,
  "created_at" : "2016-02-29 23:42:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Talking Points Memo",
      "screen_name" : "TPM",
      "indices" : [ 3, 7 ],
      "id_str" : "14717197",
      "id" : 14717197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/vw4JHui51j",
      "expanded_url" : "http:\/\/bit.ly\/1OJsVhs",
      "display_url" : "bit.ly\/1OJsVhs"
    } ]
  },
  "geo" : { },
  "id_str" : "704450472606834688",
  "text" : "RT @TPM: BREAKING: Judge rules that US can't force Apple to provide FBI access to locked iPhone data https:\/\/t.co\/vw4JHui51j https:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TPM\/status\/704431984118988802\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/oRNDnjKdJn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcalKD9WIAEuHxR.jpg",
        "id_str" : "704431984009945089",
        "id" : 704431984009945089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcalKD9WIAEuHxR.jpg",
        "sizes" : [ {
          "h" : 365,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oRNDnjKdJn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/vw4JHui51j",
        "expanded_url" : "http:\/\/bit.ly\/1OJsVhs",
        "display_url" : "bit.ly\/1OJsVhs"
      } ]
    },
    "geo" : { },
    "id_str" : "704431984118988802",
    "text" : "BREAKING: Judge rules that US can't force Apple to provide FBI access to locked iPhone data https:\/\/t.co\/vw4JHui51j https:\/\/t.co\/oRNDnjKdJn",
    "id" : 704431984118988802,
    "created_at" : "2016-02-29 22:24:07 +0000",
    "user" : {
      "name" : "Talking Points Memo",
      "screen_name" : "TPM",
      "protected" : false,
      "id_str" : "14717197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472039922929369090\/1GIGWESD_normal.png",
      "id" : 14717197,
      "verified" : true
    }
  },
  "id" : 704450472606834688,
  "created_at" : "2016-02-29 23:37:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "indices" : [ 3, 18 ],
      "id_str" : "26560483",
      "id" : 26560483
    }, {
      "name" : "John Hart",
      "screen_name" : "JohnHartAuthor",
      "indices" : [ 29, 44 ],
      "id_str" : "274630800",
      "id" : 274630800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704427523845836801",
  "text" : "RT @MacmillanAudio: ALCs for @JohnHartAuthor's REDEMPTION ROAD are in! Keep an eye on our social accounts for a chance to get your own. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Hart",
        "screen_name" : "JohnHartAuthor",
        "indices" : [ 9, 24 ],
        "id_str" : "274630800",
        "id" : 274630800
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MacmillanAudio\/status\/704421505250299909\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/qXuupIyA8v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcabnhUXEAAgmUV.jpg",
        "id_str" : "704421494991032320",
        "id" : 704421494991032320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcabnhUXEAAgmUV.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qXuupIyA8v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704421505250299909",
    "text" : "ALCs for @JohnHartAuthor's REDEMPTION ROAD are in! Keep an eye on our social accounts for a chance to get your own. https:\/\/t.co\/qXuupIyA8v",
    "id" : 704421505250299909,
    "created_at" : "2016-02-29 21:42:29 +0000",
    "user" : {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "protected" : false,
      "id_str" : "26560483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473834349394010112\/_cwv_j5v_normal.jpeg",
      "id" : 26560483,
      "verified" : true
    }
  },
  "id" : 704427523845836801,
  "created_at" : "2016-02-29 22:06:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy Loh",
      "screen_name" : "KathyLoh",
      "indices" : [ 3, 12 ],
      "id_str" : "18706924",
      "id" : 18706924
    }, {
      "name" : "Jessica Stillman",
      "screen_name" : "EntryLevelRebel",
      "indices" : [ 74, 90 ],
      "id_str" : "57682960",
      "id" : 57682960
    }, {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "indices" : [ 119, 123 ],
      "id_str" : "16896485",
      "id" : 16896485
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "behavior",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/k8aGDNTgwv",
      "expanded_url" : "http:\/\/www.inc.com\/jessica-stillman\/complaining-rewires-your-brain-for-negativity-science-says.html",
      "display_url" : "inc.com\/jessica-stillm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704403912330186752",
  "text" : "RT @KathyLoh: Complaining rewires your brain for negativity, science says @entrylevelrebel https:\/\/t.co\/k8aGDNTgwv via @Inc #behavior #pers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jessica Stillman",
        "screen_name" : "EntryLevelRebel",
        "indices" : [ 60, 76 ],
        "id_str" : "57682960",
        "id" : 57682960
      }, {
        "name" : "Inc.",
        "screen_name" : "Inc",
        "indices" : [ 105, 109 ],
        "id_str" : "16896485",
        "id" : 16896485
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "behavior",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "personalgrowth",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/k8aGDNTgwv",
        "expanded_url" : "http:\/\/www.inc.com\/jessica-stillman\/complaining-rewires-your-brain-for-negativity-science-says.html",
        "display_url" : "inc.com\/jessica-stillm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704400991412625408",
    "text" : "Complaining rewires your brain for negativity, science says @entrylevelrebel https:\/\/t.co\/k8aGDNTgwv via @Inc #behavior #personalgrowth",
    "id" : 704400991412625408,
    "created_at" : "2016-02-29 20:20:58 +0000",
    "user" : {
      "name" : "Kathy Loh",
      "screen_name" : "KathyLoh",
      "protected" : false,
      "id_str" : "18706924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494694002709377024\/kLgpH418_normal.jpeg",
      "id" : 18706924,
      "verified" : false
    }
  },
  "id" : 704403912330186752,
  "created_at" : "2016-02-29 20:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Case",
      "screen_name" : "jessecase",
      "indices" : [ 3, 13 ],
      "id_str" : "24664313",
      "id" : 24664313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/mQ8tVzgboe",
      "expanded_url" : "http:\/\/jessevscancer.com",
      "display_url" : "jessevscancer.com"
    } ]
  },
  "geo" : { },
  "id_str" : "704393380223131648",
  "text" : "RT @jessecase: For the next 2 months I have to shit in a bag. Here's a goddamn podcast about it. https:\/\/t.co\/mQ8tVzgboe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/mQ8tVzgboe",
        "expanded_url" : "http:\/\/jessevscancer.com",
        "display_url" : "jessevscancer.com"
      } ]
    },
    "geo" : { },
    "id_str" : "704071501272772608",
    "text" : "For the next 2 months I have to shit in a bag. Here's a goddamn podcast about it. https:\/\/t.co\/mQ8tVzgboe",
    "id" : 704071501272772608,
    "created_at" : "2016-02-28 22:31:41 +0000",
    "user" : {
      "name" : "Jesse Case",
      "screen_name" : "jessecase",
      "protected" : false,
      "id_str" : "24664313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486957095892160513\/b_ho7daM_normal.png",
      "id" : 24664313,
      "verified" : false
    }
  },
  "id" : 704393380223131648,
  "created_at" : "2016-02-29 19:50:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lidder Snr",
      "screen_name" : "laikalad",
      "indices" : [ 3, 12 ],
      "id_str" : "599191354",
      "id" : 599191354
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/laikalad\/status\/704381861565505536\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/mWwOvwZGWM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZ3ki7W8AAFMHD.jpg",
      "id_str" : "704381861464829952",
      "id" : 704381861464829952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZ3ki7W8AAFMHD.jpg",
      "sizes" : [ {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mWwOvwZGWM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704382735637454852",
  "text" : "RT @laikalad: September sunset. https:\/\/t.co\/mWwOvwZGWM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/laikalad\/status\/704381861565505536\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/mWwOvwZGWM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZ3ki7W8AAFMHD.jpg",
        "id_str" : "704381861464829952",
        "id" : 704381861464829952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZ3ki7W8AAFMHD.jpg",
        "sizes" : [ {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mWwOvwZGWM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704381861565505536",
    "text" : "September sunset. https:\/\/t.co\/mWwOvwZGWM",
    "id" : 704381861565505536,
    "created_at" : "2016-02-29 19:04:57 +0000",
    "user" : {
      "name" : "Paul Lidder Snr",
      "screen_name" : "laikalad",
      "protected" : false,
      "id_str" : "599191354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746971554324480\/F2N3yDKH_normal.jpg",
      "id" : 599191354,
      "verified" : false
    }
  },
  "id" : 704382735637454852,
  "created_at" : "2016-02-29 19:08:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thDigitalReader\/status\/704378012859506692\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/y1gXN6I5vS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZ0EfGUAAAlGIY.jpg",
      "id_str" : "704378012146335744",
      "id" : 704378012146335744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZ0EfGUAAAlGIY.jpg",
      "sizes" : [ {
        "h" : 482,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/y1gXN6I5vS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704381352993558528",
  "text" : "RT @thDigitalReader: hello, my name is ... https:\/\/t.co\/y1gXN6I5vS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thDigitalReader\/status\/704378012859506692\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/y1gXN6I5vS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZ0EfGUAAAlGIY.jpg",
        "id_str" : "704378012146335744",
        "id" : 704378012146335744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZ0EfGUAAAlGIY.jpg",
        "sizes" : [ {
          "h" : 482,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/y1gXN6I5vS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704378012859506692",
    "text" : "hello, my name is ... https:\/\/t.co\/y1gXN6I5vS",
    "id" : 704378012859506692,
    "created_at" : "2016-02-29 18:49:39 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 704381352993558528,
  "created_at" : "2016-02-29 19:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/FCSSb3iRFA",
      "expanded_url" : "http:\/\/jessevscancer.com\/episodes\/2016\/2\/27\/episode-34-the-ass-surgery-special-part-1",
      "display_url" : "jessevscancer.com\/episodes\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704376266171027456",
  "text" : "Episode 34 - the Ass Surgery Special PART 1 https:\/\/t.co\/FCSSb3iRFA",
  "id" : 704376266171027456,
  "created_at" : "2016-02-29 18:42:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/ogMgShh08U",
      "expanded_url" : "https:\/\/twitter.com\/timkellernyc\/status\/703636479763996673",
      "display_url" : "twitter.com\/timkellernyc\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704355901801684992",
  "text" : "RT @micahjmurray: Huh. Well there\u2019s my problem. https:\/\/t.co\/ogMgShh08U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/ogMgShh08U",
        "expanded_url" : "https:\/\/twitter.com\/timkellernyc\/status\/703636479763996673",
        "display_url" : "twitter.com\/timkellernyc\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704352246167830528",
    "text" : "Huh. Well there\u2019s my problem. https:\/\/t.co\/ogMgShh08U",
    "id" : 704352246167830528,
    "created_at" : "2016-02-29 17:07:16 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 704355901801684992,
  "created_at" : "2016-02-29 17:21:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Towleroad",
      "screen_name" : "tlrd",
      "indices" : [ 3, 8 ],
      "id_str" : "2065391",
      "id" : 2065391
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tlrd\/status\/704348290251300864\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/JmqcrvuRzW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZZBkKW0AER0tz.jpg",
      "id_str" : "704348275151917057",
      "id" : 704348275151917057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZZBkKW0AER0tz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JmqcrvuRzW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2CHhWRw4dh",
      "expanded_url" : "http:\/\/bit.ly\/1UukVrK",
      "display_url" : "bit.ly\/1UukVrK"
    } ]
  },
  "geo" : { },
  "id_str" : "704354754441441280",
  "text" : "RT @tlrd: Justin Trudeau to Grant Posthumous Pardon to Man Imprisoned for Being Gay https:\/\/t.co\/2CHhWRw4dh https:\/\/t.co\/JmqcrvuRzW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tlrd\/status\/704348290251300864\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/JmqcrvuRzW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZZBkKW0AER0tz.jpg",
        "id_str" : "704348275151917057",
        "id" : 704348275151917057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZZBkKW0AER0tz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/JmqcrvuRzW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/2CHhWRw4dh",
        "expanded_url" : "http:\/\/bit.ly\/1UukVrK",
        "display_url" : "bit.ly\/1UukVrK"
      } ]
    },
    "geo" : { },
    "id_str" : "704348290251300864",
    "text" : "Justin Trudeau to Grant Posthumous Pardon to Man Imprisoned for Being Gay https:\/\/t.co\/2CHhWRw4dh https:\/\/t.co\/JmqcrvuRzW",
    "id" : 704348290251300864,
    "created_at" : "2016-02-29 16:51:33 +0000",
    "user" : {
      "name" : "Towleroad",
      "screen_name" : "tlrd",
      "protected" : false,
      "id_str" : "2065391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610555327055032323\/y1c7WpMT_normal.jpg",
      "id" : 2065391,
      "verified" : false
    }
  },
  "id" : 704354754441441280,
  "created_at" : "2016-02-29 17:17:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/m76bjNviVx",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/703901452612325376",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704347432394596352",
  "text" : "just existing is a sin. made by god in his image but we're too awful to be around. god doesnt make mistakes?? hmm.. https:\/\/t.co\/m76bjNviVx",
  "id" : 704347432394596352,
  "created_at" : "2016-02-29 16:48:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cutters Edge",
      "screen_name" : "CuttersEdgeNY",
      "indices" : [ 3, 17 ],
      "id_str" : "3285642314",
      "id" : 3285642314
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CuttersEdgeNY\/status\/685192734605459457\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/L3VYeHjNQ9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJLKWJWcAAfrg7.png",
      "id_str" : "685192734429310976",
      "id" : 685192734429310976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJLKWJWcAAfrg7.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 304
      } ],
      "display_url" : "pic.twitter.com\/L3VYeHjNQ9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704346477791989763",
  "text" : "RT @CuttersEdgeNY: The latest trend in hair color is macaron -- are you a fan? https:\/\/t.co\/L3VYeHjNQ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.mainstreethub.com\/consultation\/?source=twitter_post_tool&utm_source=twitter&utm_medium=post%2Btool&utm_campaign=twitt\" rel=\"nofollow\"\u003EMain Street Hub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CuttersEdgeNY\/status\/685192734605459457\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/L3VYeHjNQ9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJLKWJWcAAfrg7.png",
        "id_str" : "685192734429310976",
        "id" : 685192734429310976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJLKWJWcAAfrg7.png",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 304
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 304
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 304
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 304
        } ],
        "display_url" : "pic.twitter.com\/L3VYeHjNQ9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685192734605459457",
    "text" : "The latest trend in hair color is macaron -- are you a fan? https:\/\/t.co\/L3VYeHjNQ9",
    "id" : 685192734605459457,
    "created_at" : "2016-01-07 20:14:12 +0000",
    "user" : {
      "name" : "Cutters Edge",
      "screen_name" : "CuttersEdgeNY",
      "protected" : false,
      "id_str" : "3285642314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623173957802328065\/XpmUObx4_normal.png",
      "id" : 3285642314,
      "verified" : false
    }
  },
  "id" : 704346477791989763,
  "created_at" : "2016-02-29 16:44:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wakingup",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/JdGv9ime97",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/703957455252955136",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704345493212631040",
  "text" : "now THAT is Good News! #wakingup https:\/\/t.co\/JdGv9ime97",
  "id" : 704345493212631040,
  "created_at" : "2016-02-29 16:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Island Wool Company",
      "screen_name" : "islandwool",
      "indices" : [ 3, 14 ],
      "id_str" : "831725366",
      "id" : 831725366
    }, {
      "name" : "Anniken Allis",
      "screen_name" : "YarnAddictAnni",
      "indices" : [ 73, 88 ],
      "id_str" : "257618490",
      "id" : 257618490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/3EDlc4ESIU",
      "expanded_url" : "http:\/\/bit.ly\/1TMIUTA",
      "display_url" : "bit.ly\/1TMIUTA"
    } ]
  },
  "geo" : { },
  "id_str" : "704343387491717120",
  "text" : "RT @islandwool: This lovely lace shawl &amp; mittens set in Navia Duo by @YarnAddictAnni is now on our website: https:\/\/t.co\/3EDlc4ESIU https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anniken Allis",
        "screen_name" : "YarnAddictAnni",
        "indices" : [ 57, 72 ],
        "id_str" : "257618490",
        "id" : 257618490
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/islandwool\/status\/704336680090783744\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Hi0NiXh9BT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZOegbXIAQbmI0.jpg",
        "id_str" : "704336677737799684",
        "id" : 704336677737799684,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZOegbXIAQbmI0.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Hi0NiXh9BT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/3EDlc4ESIU",
        "expanded_url" : "http:\/\/bit.ly\/1TMIUTA",
        "display_url" : "bit.ly\/1TMIUTA"
      } ]
    },
    "geo" : { },
    "id_str" : "704336680090783744",
    "text" : "This lovely lace shawl &amp; mittens set in Navia Duo by @YarnAddictAnni is now on our website: https:\/\/t.co\/3EDlc4ESIU https:\/\/t.co\/Hi0NiXh9BT",
    "id" : 704336680090783744,
    "created_at" : "2016-02-29 16:05:25 +0000",
    "user" : {
      "name" : "Island Wool Company",
      "screen_name" : "islandwool",
      "protected" : false,
      "id_str" : "831725366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570926127632248832\/CZmWrALn_normal.jpeg",
      "id" : 831725366,
      "verified" : false
    }
  },
  "id" : 704343387491717120,
  "created_at" : "2016-02-29 16:32:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Ham",
      "screen_name" : "aigkenham",
      "indices" : [ 4, 14 ],
      "id_str" : "212308700",
      "id" : 212308700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704342741069733889",
  "text" : "wow @aigkenham is in attack mode today on his TL...",
  "id" : 704342741069733889,
  "created_at" : "2016-02-29 16:29:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704334712257519616",
  "geo" : { },
  "id_str" : "704341930050777088",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe thats awful. for me its a happy song.",
  "id" : 704341930050777088,
  "in_reply_to_status_id" : 704334712257519616,
  "created_at" : "2016-02-29 16:26:16 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WorldofAnimalsMag",
      "screen_name" : "WorldAnimalsMag",
      "indices" : [ 3, 19 ],
      "id_str" : "1948966561",
      "id" : 1948966561
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WorldAnimalsMag\/status\/704336329161760770\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/1RszjwwGlN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZOKLOWEAA34wn.jpg",
      "id_str" : "704336328448675840",
      "id" : 704336328448675840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZOKLOWEAA34wn.jpg",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1RszjwwGlN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704341439652691968",
  "text" : "RT @WorldAnimalsMag: Moose with antlers are better at finding females over long distances than those without https:\/\/t.co\/1RszjwwGlN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WorldAnimalsMag\/status\/704336329161760770\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/1RszjwwGlN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZOKLOWEAA34wn.jpg",
        "id_str" : "704336328448675840",
        "id" : 704336328448675840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZOKLOWEAA34wn.jpg",
        "sizes" : [ {
          "h" : 410,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1RszjwwGlN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704336329161760770",
    "text" : "Moose with antlers are better at finding females over long distances than those without https:\/\/t.co\/1RszjwwGlN",
    "id" : 704336329161760770,
    "created_at" : "2016-02-29 16:04:01 +0000",
    "user" : {
      "name" : "WorldofAnimalsMag",
      "screen_name" : "WorldAnimalsMag",
      "protected" : false,
      "id_str" : "1948966561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791565619867054080\/RNnFPqiA_normal.jpg",
      "id" : 1948966561,
      "verified" : false
    }
  },
  "id" : 704341439652691968,
  "created_at" : "2016-02-29 16:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Law of Attraction",
      "screen_name" : "LAWOFATTRACTlON",
      "indices" : [ 3, 19 ],
      "id_str" : "2977422557",
      "id" : 2977422557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704339572029825024",
  "text" : "RT @LAWOFATTRACTlON: The only thing keeping you from our Creator's abundance is your belief in lack. Be open to receive unlimited abundance\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693056536038473729",
    "text" : "The only thing keeping you from our Creator's abundance is your belief in lack. Be open to receive unlimited abundance in your life.",
    "id" : 693056536038473729,
    "created_at" : "2016-01-29 13:02:09 +0000",
    "user" : {
      "name" : "Law of Attraction",
      "screen_name" : "LAWOFATTRACTlON",
      "protected" : false,
      "id_str" : "2977422557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555176232631824384\/zIBBOI78_normal.jpeg",
      "id" : 2977422557,
      "verified" : false
    }
  },
  "id" : 704339572029825024,
  "created_at" : "2016-02-29 16:16:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/uVbK8pYCuB",
      "expanded_url" : "https:\/\/plus.google.com\/110585962532856059731\/posts\/7xwheZMwCdE?_utm_source=199-1-1",
      "display_url" : "plus.google.com\/11058596253285\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704330572877930500",
  "text" : "\"When the X-Files tell the truth... But you think you're watching TV...\"  https:\/\/t.co\/uVbK8pYCuB",
  "id" : 704330572877930500,
  "created_at" : "2016-02-29 15:41:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orca",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "PrinceRupert",
      "indices" : [ 27, 40 ]
    }, {
      "text" : "Whale",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704316267004608512",
  "text" : "RT @ScarlettWulf: #Orca in #PrinceRupert. So Brilliant to stand on the shore watching them fish, will Never Forget! #Whale https:\/\/t.co\/Dnf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/703611671990829060\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/DnfZfLzprX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcO7CqxUsAAhRFa.jpg",
        "id_str" : "703611621315227648",
        "id" : 703611621315227648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcO7CqxUsAAhRFa.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1111,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 556,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DnfZfLzprX"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/703611671990829060\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/DnfZfLzprX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcO7DY3VAAAigKY.jpg",
        "id_str" : "703611633688444928",
        "id" : 703611633688444928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcO7DY3VAAAigKY.jpg",
        "sizes" : [ {
          "h" : 1118,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DnfZfLzprX"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/703611671990829060\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/DnfZfLzprX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcO7EAXVIAA_V-l.jpg",
        "id_str" : "703611644291653632",
        "id" : 703611644291653632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcO7EAXVIAA_V-l.jpg",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1130,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/DnfZfLzprX"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/703611671990829060\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/DnfZfLzprX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcO7EzfUsAAe-Y2.jpg",
        "id_str" : "703611658015387648",
        "id" : 703611658015387648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcO7EzfUsAAe-Y2.jpg",
        "sizes" : [ {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 994,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/DnfZfLzprX"
      } ],
      "hashtags" : [ {
        "text" : "Orca",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "PrinceRupert",
        "indices" : [ 9, 22 ]
      }, {
        "text" : "Whale",
        "indices" : [ 98, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703611671990829060",
    "text" : "#Orca in #PrinceRupert. So Brilliant to stand on the shore watching them fish, will Never Forget! #Whale https:\/\/t.co\/DnfZfLzprX",
    "id" : 703611671990829060,
    "created_at" : "2016-02-27 16:04:29 +0000",
    "user" : {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "protected" : false,
      "id_str" : "1348108910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741919775668867072\/yzqHRx03_normal.jpg",
      "id" : 1348108910,
      "verified" : false
    }
  },
  "id" : 704316267004608512,
  "created_at" : "2016-02-29 14:44:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrinceRupert",
      "indices" : [ 44, 57 ]
    }, {
      "text" : "BeautifulBC",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "ExploreCanada",
      "indices" : [ 71, 85 ]
    }, {
      "text" : "explorebc",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "SnowMoon",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "Moontastic",
      "indices" : [ 107, 118 ]
    }, {
      "text" : "FullMoon",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704316086443966464",
  "text" : "RT @ScarlettWulf: Blessed Be the Snow Moon! #PrinceRupert #BeautifulBC #ExploreCanada #explorebc #SnowMoon #Moontastic #FullMoon https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/702009928932683776\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/otuT2ESGek",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb4KS5rVIAAfb1-.jpg",
        "id_str" : "702009911752859648",
        "id" : 702009911752859648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb4KS5rVIAAfb1-.jpg",
        "sizes" : [ {
          "h" : 377,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1134,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1134,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/otuT2ESGek"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/702009928932683776\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/otuT2ESGek",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb4KTiaUYAADwMK.jpg",
        "id_str" : "702009922687361024",
        "id" : 702009922687361024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb4KTiaUYAADwMK.jpg",
        "sizes" : [ {
          "h" : 1093,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1093,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/otuT2ESGek"
      } ],
      "hashtags" : [ {
        "text" : "PrinceRupert",
        "indices" : [ 26, 39 ]
      }, {
        "text" : "BeautifulBC",
        "indices" : [ 40, 52 ]
      }, {
        "text" : "ExploreCanada",
        "indices" : [ 53, 67 ]
      }, {
        "text" : "explorebc",
        "indices" : [ 68, 78 ]
      }, {
        "text" : "SnowMoon",
        "indices" : [ 79, 88 ]
      }, {
        "text" : "Moontastic",
        "indices" : [ 89, 100 ]
      }, {
        "text" : "FullMoon",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702009928932683776",
    "text" : "Blessed Be the Snow Moon! #PrinceRupert #BeautifulBC #ExploreCanada #explorebc #SnowMoon #Moontastic #FullMoon https:\/\/t.co\/otuT2ESGek",
    "id" : 702009928932683776,
    "created_at" : "2016-02-23 05:59:44 +0000",
    "user" : {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "protected" : false,
      "id_str" : "1348108910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741919775668867072\/yzqHRx03_normal.jpg",
      "id" : 1348108910,
      "verified" : false
    }
  },
  "id" : 704316086443966464,
  "created_at" : "2016-02-29 14:43:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704174810008522752",
  "geo" : { },
  "id_str" : "704315435236335616",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley love it.. gorgeous! so jealous of your talent.",
  "id" : 704315435236335616,
  "in_reply_to_status_id" : 704174810008522752,
  "created_at" : "2016-02-29 14:40:59 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/aBQvhRHEHp",
      "expanded_url" : "https:\/\/twitter.com\/goforhi\/status\/702654763721031681",
      "display_url" : "twitter.com\/goforhi\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704051355669897221",
  "text" : "true. and making them defensive about it entrenches them more. https:\/\/t.co\/aBQvhRHEHp",
  "id" : 704051355669897221,
  "created_at" : "2016-02-28 21:11:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704012985237442562",
  "geo" : { },
  "id_str" : "704050804135751680",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides now thats a stare! lol",
  "id" : 704050804135751680,
  "in_reply_to_status_id" : 704012985237442562,
  "created_at" : "2016-02-28 21:09:26 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Williams",
      "screen_name" : "lisajrwilliams",
      "indices" : [ 3, 18 ],
      "id_str" : "3127052793",
      "id" : 3127052793
    }, {
      "name" : "The Trentham Estate",
      "screen_name" : "TrenthamEstate",
      "indices" : [ 40, 55 ],
      "id_str" : "155862312",
      "id" : 155862312
    }, {
      "name" : "Trentham Gardens",
      "screen_name" : "TrenthamGardens",
      "indices" : [ 56, 72 ],
      "id_str" : "413151220",
      "id" : 413151220
    }, {
      "name" : "StaffsWildlife",
      "screen_name" : "StaffsWildlife",
      "indices" : [ 73, 88 ],
      "id_str" : "127463990",
      "id" : 127463990
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisajrwilliams\/status\/704002279951704065\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/dVgL0Mg4mG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcUePgsWoAAsIMU.jpg",
      "id_str" : "704002168576188416",
      "id" : 704002168576188416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcUePgsWoAAsIMU.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/dVgL0Mg4mG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704006617382129664",
  "text" : "RT @lisajrwilliams: Greylag Goose cross @TrenthamEstate @TrenthamGardens @StaffsWildlife https:\/\/t.co\/dVgL0Mg4mG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Trentham Estate",
        "screen_name" : "TrenthamEstate",
        "indices" : [ 20, 35 ],
        "id_str" : "155862312",
        "id" : 155862312
      }, {
        "name" : "Trentham Gardens",
        "screen_name" : "TrenthamGardens",
        "indices" : [ 36, 52 ],
        "id_str" : "413151220",
        "id" : 413151220
      }, {
        "name" : "StaffsWildlife",
        "screen_name" : "StaffsWildlife",
        "indices" : [ 53, 68 ],
        "id_str" : "127463990",
        "id" : 127463990
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisajrwilliams\/status\/704002279951704065\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/dVgL0Mg4mG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcUePgsWoAAsIMU.jpg",
        "id_str" : "704002168576188416",
        "id" : 704002168576188416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcUePgsWoAAsIMU.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/dVgL0Mg4mG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704002279951704065",
    "text" : "Greylag Goose cross @TrenthamEstate @TrenthamGardens @StaffsWildlife https:\/\/t.co\/dVgL0Mg4mG",
    "id" : 704002279951704065,
    "created_at" : "2016-02-28 17:56:37 +0000",
    "user" : {
      "name" : "Lisa Williams",
      "screen_name" : "lisajrwilliams",
      "protected" : false,
      "id_str" : "3127052793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582292881567809536\/3L5GSchb_normal.jpg",
      "id" : 3127052793,
      "verified" : false
    }
  },
  "id" : 704006617382129664,
  "created_at" : "2016-02-28 18:13:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/L9S8vKaF2x",
      "expanded_url" : "http:\/\/goo.gl\/UkND8s",
      "display_url" : "goo.gl\/UkND8s"
    } ]
  },
  "geo" : { },
  "id_str" : "703998232888680450",
  "text" : "RT @dailygalaxy: The Perseus Signal -- \"What We Found Could Not Be Explained by Known Physics\"  https:\/\/t.co\/L9S8vKaF2x https:\/\/t.co\/xlK0ry\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/703995155511013376\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/xlK0ryXVd0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcUX3PDVAAAai_y.jpg",
        "id_str" : "703995154454085632",
        "id" : 703995154454085632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcUX3PDVAAAai_y.jpg",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 695
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 695
        } ],
        "display_url" : "pic.twitter.com\/xlK0ryXVd0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/L9S8vKaF2x",
        "expanded_url" : "http:\/\/goo.gl\/UkND8s",
        "display_url" : "goo.gl\/UkND8s"
      } ]
    },
    "geo" : { },
    "id_str" : "703995155511013376",
    "text" : "The Perseus Signal -- \"What We Found Could Not Be Explained by Known Physics\"  https:\/\/t.co\/L9S8vKaF2x https:\/\/t.co\/xlK0ryXVd0",
    "id" : 703995155511013376,
    "created_at" : "2016-02-28 17:28:19 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 703998232888680450,
  "created_at" : "2016-02-28 17:40:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan M. Nardi",
      "screen_name" : "StefanMNardi",
      "indices" : [ 3, 16 ],
      "id_str" : "3390939742",
      "id" : 3390939742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StefanMNardi\/status\/699547789014016000\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/BzXHQE0ktq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbVLAfFWIAAbfpM.jpg",
      "id_str" : "699547788841984000",
      "id" : 699547788841984000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbVLAfFWIAAbfpM.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/BzXHQE0ktq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703988946011820033",
  "text" : "RT @StefanMNardi: https:\/\/t.co\/BzXHQE0ktq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StefanMNardi\/status\/699547789014016000\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/BzXHQE0ktq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbVLAfFWIAAbfpM.jpg",
        "id_str" : "699547788841984000",
        "id" : 699547788841984000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbVLAfFWIAAbfpM.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/BzXHQE0ktq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699547789014016000",
    "text" : "https:\/\/t.co\/BzXHQE0ktq",
    "id" : 699547789014016000,
    "created_at" : "2016-02-16 10:56:04 +0000",
    "user" : {
      "name" : "Stefan M. Nardi",
      "screen_name" : "StefanMNardi",
      "protected" : false,
      "id_str" : "3390939742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624552106834264064\/asMdkZrL_normal.jpg",
      "id" : 3390939742,
      "verified" : false
    }
  },
  "id" : 703988946011820033,
  "created_at" : "2016-02-28 17:03:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan M. Nardi",
      "screen_name" : "StefanMNardi",
      "indices" : [ 3, 16 ],
      "id_str" : "3390939742",
      "id" : 3390939742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StefanMNardi\/status\/703570822758277120\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/89YCjO1LDp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcOV73uXIAAcZSn.jpg",
      "id_str" : "703570822603153408",
      "id" : 703570822603153408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcOV73uXIAAcZSn.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 955,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 955,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/89YCjO1LDp"
    } ],
    "hashtags" : [ {
      "text" : "50shades",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "scifi",
      "indices" : [ 45, 51 ]
    }, {
      "text" : "amreading",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703988530658320384",
  "text" : "RT @StefanMNardi: Hahahahhahhahaha #50shades #scifi #amreading https:\/\/t.co\/89YCjO1LDp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StefanMNardi\/status\/703570822758277120\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/89YCjO1LDp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcOV73uXIAAcZSn.jpg",
        "id_str" : "703570822603153408",
        "id" : 703570822603153408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcOV73uXIAAcZSn.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 955,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 955,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/89YCjO1LDp"
      } ],
      "hashtags" : [ {
        "text" : "50shades",
        "indices" : [ 17, 26 ]
      }, {
        "text" : "scifi",
        "indices" : [ 27, 33 ]
      }, {
        "text" : "amreading",
        "indices" : [ 34, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703570822758277120",
    "text" : "Hahahahhahhahaha #50shades #scifi #amreading https:\/\/t.co\/89YCjO1LDp",
    "id" : 703570822758277120,
    "created_at" : "2016-02-27 13:22:10 +0000",
    "user" : {
      "name" : "Stefan M. Nardi",
      "screen_name" : "StefanMNardi",
      "protected" : false,
      "id_str" : "3390939742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624552106834264064\/asMdkZrL_normal.jpg",
      "id" : 3390939742,
      "verified" : false
    }
  },
  "id" : 703988530658320384,
  "created_at" : "2016-02-28 17:01:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. Saddler \uD83D\uDCCE",
      "screen_name" : "Politics_PR",
      "indices" : [ 3, 15 ],
      "id_str" : "16711026",
      "id" : 16711026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703983550018748416",
  "text" : "RT @Politics_PR: America in 2016. 3 siblings picking up their daily allowance of bottled water from the Fire Dept in Flint, MI https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Politics_PR\/status\/697624279643484160\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/G8gIZKm0pt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca51lfbW8AAVYXG.jpg",
        "id_str" : "697624279240863744",
        "id" : 697624279240863744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca51lfbW8AAVYXG.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/G8gIZKm0pt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697624279643484160",
    "text" : "America in 2016. 3 siblings picking up their daily allowance of bottled water from the Fire Dept in Flint, MI https:\/\/t.co\/G8gIZKm0pt",
    "id" : 697624279643484160,
    "created_at" : "2016-02-11 03:32:44 +0000",
    "user" : {
      "name" : "R. Saddler \uD83D\uDCCE",
      "screen_name" : "Politics_PR",
      "protected" : false,
      "id_str" : "16711026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2432272230\/4r8kj4xxupk14i5glkm7_normal.jpeg",
      "id" : 16711026,
      "verified" : false
    }
  },
  "id" : 703983550018748416,
  "created_at" : "2016-02-28 16:42:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703978599301435395",
  "text" : "A Course In Miracles by Helen Schucman was another one that caused a big leap out of the ocean to see there was more out there than I knew.",
  "id" : 703978599301435395,
  "created_at" : "2016-02-28 16:22:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703978067212050433",
  "text" : "Natural Cures They Don't Want You to Know About by Kevin Trudeau I think was the first one that jarred my \"reality\" re: authority.",
  "id" : 703978067212050433,
  "created_at" : "2016-02-28 16:20:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703977181563719680",
  "text" : "we really do live in a matrix re: consciousness of society .. it takes a knock to wake up, to question. mine was a book, of course..lol",
  "id" : 703977181563719680,
  "created_at" : "2016-02-28 16:16:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gamble",
      "screen_name" : "Farnell_Simmys",
      "indices" : [ 3, 18 ],
      "id_str" : "338444354",
      "id" : 338444354
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Farnell_Simmys\/status\/703903994515734532\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/jkBS3ayaNw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcTE5TIW8AAtgcw.jpg",
      "id_str" : "703903930443558912",
      "id" : 703903930443558912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcTE5TIW8AAtgcw.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jkBS3ayaNw"
    } ],
    "hashtags" : [ {
      "text" : "simmental",
      "indices" : [ 61, 71 ]
    }, {
      "text" : "teamdairy",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703976497753812992",
  "text" : "RT @Farnell_Simmys: Calves to raise a Sunday morning smile\uD83D\uDE0A\n #simmental\n#teamdairy https:\/\/t.co\/jkBS3ayaNw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Farnell_Simmys\/status\/703903994515734532\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/jkBS3ayaNw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcTE5TIW8AAtgcw.jpg",
        "id_str" : "703903930443558912",
        "id" : 703903930443558912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcTE5TIW8AAtgcw.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1161,
          "resize" : "fit",
          "w" : 2064
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/jkBS3ayaNw"
      } ],
      "hashtags" : [ {
        "text" : "simmental",
        "indices" : [ 41, 51 ]
      }, {
        "text" : "teamdairy",
        "indices" : [ 52, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703903994515734532",
    "text" : "Calves to raise a Sunday morning smile\uD83D\uDE0A\n #simmental\n#teamdairy https:\/\/t.co\/jkBS3ayaNw",
    "id" : 703903994515734532,
    "created_at" : "2016-02-28 11:26:04 +0000",
    "user" : {
      "name" : "Alan Gamble",
      "screen_name" : "Farnell_Simmys",
      "protected" : false,
      "id_str" : "338444354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688803447668379648\/oPoqpGoV_normal.jpg",
      "id" : 338444354,
      "verified" : false
    }
  },
  "id" : 703976497753812992,
  "created_at" : "2016-02-28 16:14:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Sprankle, PsyD",
      "screen_name" : "DrSprankle",
      "indices" : [ 3, 14 ],
      "id_str" : "423967218",
      "id" : 423967218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sexwork",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703975473517346816",
  "text" : "RT @DrSprankle: No country can wave its flag as a symbol of freedom if bodily autonomy is criminalized within its borders. #sexwork #procho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sexwork",
        "indices" : [ 107, 115 ]
      }, {
        "text" : "prochoice",
        "indices" : [ 116, 126 ]
      }, {
        "text" : "transrights",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703962403088650240",
    "text" : "No country can wave its flag as a symbol of freedom if bodily autonomy is criminalized within its borders. #sexwork #prochoice #transrights",
    "id" : 703962403088650240,
    "created_at" : "2016-02-28 15:18:10 +0000",
    "user" : {
      "name" : "Eric Sprankle, PsyD",
      "screen_name" : "DrSprankle",
      "protected" : false,
      "id_str" : "423967218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799007551060742144\/3BZQ91Eg_normal.jpg",
      "id" : 423967218,
      "verified" : false
    }
  },
  "id" : 703975473517346816,
  "created_at" : "2016-02-28 16:10:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/500408549168541696\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/zoB2GHz6Ig",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvHO7IwCUAEiJUn.jpg",
      "id_str" : "500408548971401217",
      "id" : 500408548971401217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvHO7IwCUAEiJUn.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/zoB2GHz6Ig"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703974736372572160",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/zoB2GHz6Ig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/500408549168541696\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/zoB2GHz6Ig",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvHO7IwCUAEiJUn.jpg",
        "id_str" : "500408548971401217",
        "id" : 500408548971401217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvHO7IwCUAEiJUn.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/zoB2GHz6Ig"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703962889615441920",
    "text" : "https:\/\/t.co\/zoB2GHz6Ig",
    "id" : 703962889615441920,
    "created_at" : "2016-02-28 15:20:06 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 703974736372572160,
  "created_at" : "2016-02-28 16:07:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serdar",
      "screen_name" : "serdargoknur",
      "indices" : [ 3, 16 ],
      "id_str" : "1962422936",
      "id" : 1962422936
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/serdargoknur\/status\/703827413164097536\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/1w3yHLnH0t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcR_TVDVAAI7xsx.jpg",
      "id_str" : "703827411821985794",
      "id" : 703827411821985794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcR_TVDVAAI7xsx.jpg",
      "sizes" : [ {
        "h" : 638,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 638,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 638,
        "resize" : "fit",
        "w" : 425
      } ],
      "display_url" : "pic.twitter.com\/1w3yHLnH0t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703974020534956032",
  "text" : "RT @serdargoknur: Good morning https:\/\/t.co\/1w3yHLnH0t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/serdargoknur\/status\/703827413164097536\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/1w3yHLnH0t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcR_TVDVAAI7xsx.jpg",
        "id_str" : "703827411821985794",
        "id" : 703827411821985794,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcR_TVDVAAI7xsx.jpg",
        "sizes" : [ {
          "h" : 638,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 425
        } ],
        "display_url" : "pic.twitter.com\/1w3yHLnH0t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703827413164097536",
    "text" : "Good morning https:\/\/t.co\/1w3yHLnH0t",
    "id" : 703827413164097536,
    "created_at" : "2016-02-28 06:21:46 +0000",
    "user" : {
      "name" : "Serdar",
      "screen_name" : "serdargoknur",
      "protected" : false,
      "id_str" : "1962422936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800959262621134848\/rJ4QkSEr_normal.jpg",
      "id" : 1962422936,
      "verified" : false
    }
  },
  "id" : 703974020534956032,
  "created_at" : "2016-02-28 16:04:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K\u00F6ksal Ak\u0131n",
      "screen_name" : "Koksalakn",
      "indices" : [ 3, 13 ],
      "id_str" : "1643909461",
      "id" : 1643909461
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Koksalakn\/status\/703921544230281217\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/QJIWx2E7sm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcTU6fiW4AAVNwC.jpg",
      "id_str" : "703921543139745792",
      "id" : 703921543139745792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcTU6fiW4AAVNwC.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/QJIWx2E7sm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703973890247270400",
  "text" : "RT @Koksalakn: - to understand pillow , you must be one with pillow   ! https:\/\/t.co\/QJIWx2E7sm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Koksalakn\/status\/703921544230281217\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/QJIWx2E7sm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcTU6fiW4AAVNwC.jpg",
        "id_str" : "703921543139745792",
        "id" : 703921543139745792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcTU6fiW4AAVNwC.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/QJIWx2E7sm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703921544230281217",
    "text" : "- to understand pillow , you must be one with pillow   ! https:\/\/t.co\/QJIWx2E7sm",
    "id" : 703921544230281217,
    "created_at" : "2016-02-28 12:35:49 +0000",
    "user" : {
      "name" : "K\u00F6ksal Ak\u0131n",
      "screen_name" : "Koksalakn",
      "protected" : false,
      "id_str" : "1643909461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610196765191589888\/ENC99YX7_normal.jpg",
      "id" : 1643909461,
      "verified" : false
    }
  },
  "id" : 703973890247270400,
  "created_at" : "2016-02-28 16:03:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703973504560066562",
  "text" : "so tired of close-minded ppl.. yes, i know thats my ego talking and i should know better but i need to study more to pass test.",
  "id" : 703973504560066562,
  "created_at" : "2016-02-28 16:02:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "AwakenYourTrueSelf",
      "screen_name" : "AwakeningTrue",
      "indices" : [ 23, 37 ],
      "id_str" : "359215142",
      "id" : 359215142
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AwakeningTrue\/status\/699581255139065856\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/p6HD3MekJ0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbVpcbZWEAET0Dd.jpg",
      "id_str" : "699581254237294593",
      "id" : 699581254237294593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbVpcbZWEAET0Dd.jpg",
      "sizes" : [ {
        "h" : 207,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 288
      } ],
      "display_url" : "pic.twitter.com\/p6HD3MekJ0"
    } ],
    "hashtags" : [ {
      "text" : "IAmChoosingLove",
      "indices" : [ 65, 81 ]
    }, {
      "text" : "JoyTrain",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703971220576985088",
  "text" : "RT @JamiaStarheart: RT @AwakeningTrue: Choose joy! Choose love!  #IAmChoosingLove  #JoyTrain https:\/\/t.co\/p6HD3MekJ0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AwakenYourTrueSelf",
        "screen_name" : "AwakeningTrue",
        "indices" : [ 3, 17 ],
        "id_str" : "359215142",
        "id" : 359215142
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AwakeningTrue\/status\/699581255139065856\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/p6HD3MekJ0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbVpcbZWEAET0Dd.jpg",
        "id_str" : "699581254237294593",
        "id" : 699581254237294593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbVpcbZWEAET0Dd.jpg",
        "sizes" : [ {
          "h" : 207,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 288
        } ],
        "display_url" : "pic.twitter.com\/p6HD3MekJ0"
      } ],
      "hashtags" : [ {
        "text" : "IAmChoosingLove",
        "indices" : [ 45, 61 ]
      }, {
        "text" : "JoyTrain",
        "indices" : [ 63, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703964503222960128",
    "text" : "RT @AwakeningTrue: Choose joy! Choose love!  #IAmChoosingLove  #JoyTrain https:\/\/t.co\/p6HD3MekJ0",
    "id" : 703964503222960128,
    "created_at" : "2016-02-28 15:26:31 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 703971220576985088,
  "created_at" : "2016-02-28 15:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hill",
      "screen_name" : "thehill",
      "indices" : [ 3, 11 ],
      "id_str" : "1917731",
      "id" : 1917731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thehill\/status\/703960975368654849\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/1ZOEMXpRmJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcT4xtWVIAA07XP.jpg",
      "id_str" : "703960974647173120",
      "id" : 703960974647173120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcT4xtWVIAA07XP.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 645
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 645
      } ],
      "display_url" : "pic.twitter.com\/1ZOEMXpRmJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/yCcGW74ZtB",
      "expanded_url" : "http:\/\/hill.cm\/e7JliJn",
      "display_url" : "hill.cm\/e7JliJn"
    } ]
  },
  "geo" : { },
  "id_str" : "703969860355801088",
  "text" : "RT @thehill: BREAKING: Top DNC official resigns to endorse Sanders https:\/\/t.co\/yCcGW74ZtB https:\/\/t.co\/1ZOEMXpRmJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thehill\/status\/703960975368654849\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/1ZOEMXpRmJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcT4xtWVIAA07XP.jpg",
        "id_str" : "703960974647173120",
        "id" : 703960974647173120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcT4xtWVIAA07XP.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 645
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 645
        } ],
        "display_url" : "pic.twitter.com\/1ZOEMXpRmJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/yCcGW74ZtB",
        "expanded_url" : "http:\/\/hill.cm\/e7JliJn",
        "display_url" : "hill.cm\/e7JliJn"
      } ]
    },
    "geo" : { },
    "id_str" : "703960975368654849",
    "text" : "BREAKING: Top DNC official resigns to endorse Sanders https:\/\/t.co\/yCcGW74ZtB https:\/\/t.co\/1ZOEMXpRmJ",
    "id" : 703960975368654849,
    "created_at" : "2016-02-28 15:12:30 +0000",
    "user" : {
      "name" : "The Hill",
      "screen_name" : "thehill",
      "protected" : false,
      "id_str" : "1917731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718186698824413184\/H1qUtJzN_normal.jpg",
      "id" : 1917731,
      "verified" : true
    }
  },
  "id" : 703969860355801088,
  "created_at" : "2016-02-28 15:47:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meet the Press",
      "screen_name" : "MeetThePress",
      "indices" : [ 3, 16 ],
      "id_str" : "11856892",
      "id" : 11856892
    }, {
      "name" : "Tulsi Gabbard",
      "screen_name" : "TulsiGabbard",
      "indices" : [ 37, 50 ],
      "id_str" : "26637348",
      "id" : 26637348
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "indices" : [ 103, 117 ],
      "id_str" : "216776631",
      "id" : 216776631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MTP",
      "indices" : [ 31, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703969771470118912",
  "text" : "RT @meetthepress: EXCLUSIVE on #MTP: @TulsiGabbard resigned from position as DNC Vice Chair to support @BernieSanders. https:\/\/t.co\/cvRE4SI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tulsi Gabbard",
        "screen_name" : "TulsiGabbard",
        "indices" : [ 19, 32 ],
        "id_str" : "26637348",
        "id" : 26637348
      }, {
        "name" : "Bernie Sanders",
        "screen_name" : "BernieSanders",
        "indices" : [ 85, 99 ],
        "id_str" : "216776631",
        "id" : 216776631
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/meetthepress\/status\/703959324138283012\/video\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/cvRE4SITy2",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/703959041056202752\/pu\/img\/2RSUP964kl6BvI52.jpg",
        "id_str" : "703959041056202752",
        "id" : 703959041056202752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/703959041056202752\/pu\/img\/2RSUP964kl6BvI52.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cvRE4SITy2"
      } ],
      "hashtags" : [ {
        "text" : "MTP",
        "indices" : [ 13, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703959324138283012",
    "text" : "EXCLUSIVE on #MTP: @TulsiGabbard resigned from position as DNC Vice Chair to support @BernieSanders. https:\/\/t.co\/cvRE4SITy2",
    "id" : 703959324138283012,
    "created_at" : "2016-02-28 15:05:56 +0000",
    "user" : {
      "name" : "Meet the Press",
      "screen_name" : "MeetThePress",
      "protected" : false,
      "id_str" : "11856892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644224561743925248\/FlPhykc4_normal.jpg",
      "id" : 11856892,
      "verified" : true
    }
  },
  "id" : 703969771470118912,
  "created_at" : "2016-02-28 15:47:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "indices" : [ 3, 15 ],
      "id_str" : "15327996",
      "id" : 15327996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/c1e3RjCRlP",
      "expanded_url" : "http:\/\/fox13now.com\/2016\/02\/27\/large-police-presence-in-rio-grande-district-after-report-of-shooting\/",
      "display_url" : "fox13now.com\/2016\/02\/27\/lar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703957878000975872",
  "text" : "RT @BFriedmanDC: Rioting in Salt Lake City tonight after police shot a 17-year-old holding a broomstick. https:\/\/t.co\/c1e3RjCRlP https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BFriedmanDC\/status\/703821906936352769\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/G8JTgEHj3K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcR6S3aUAAAOCVf.jpg",
        "id_str" : "703821906307186688",
        "id" : 703821906307186688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcR6S3aUAAAOCVf.jpg",
        "sizes" : [ {
          "h" : 155,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 819
        } ],
        "display_url" : "pic.twitter.com\/G8JTgEHj3K"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/c1e3RjCRlP",
        "expanded_url" : "http:\/\/fox13now.com\/2016\/02\/27\/large-police-presence-in-rio-grande-district-after-report-of-shooting\/",
        "display_url" : "fox13now.com\/2016\/02\/27\/lar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703821906936352769",
    "text" : "Rioting in Salt Lake City tonight after police shot a 17-year-old holding a broomstick. https:\/\/t.co\/c1e3RjCRlP https:\/\/t.co\/G8JTgEHj3K",
    "id" : 703821906936352769,
    "created_at" : "2016-02-28 05:59:53 +0000",
    "user" : {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "protected" : false,
      "id_str" : "15327996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649427993161433088\/nzkLsEDl_normal.jpg",
      "id" : 15327996,
      "verified" : true
    }
  },
  "id" : 703957878000975872,
  "created_at" : "2016-02-28 15:00:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703729500450906113",
  "text" : "RT @anthrodog: this is a picture of the prime minister of canada at a pride parade with fluttershy and rainbow dash cosplayers https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/anthrodog\/status\/703392800025370624\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/b0tllNSkAS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcLz_WfUcAAcMMc.jpg",
        "id_str" : "703392761517469696",
        "id" : 703392761517469696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcLz_WfUcAAcMMc.jpg",
        "sizes" : [ {
          "h" : 593,
          "resize" : "fit",
          "w" : 790
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 790
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/b0tllNSkAS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703392800025370624",
    "text" : "this is a picture of the prime minister of canada at a pride parade with fluttershy and rainbow dash cosplayers https:\/\/t.co\/b0tllNSkAS",
    "id" : 703392800025370624,
    "created_at" : "2016-02-27 01:34:46 +0000",
    "user" : {
      "name" : "Bobby Schroeder",
      "screen_name" : "ponettplus",
      "protected" : false,
      "id_str" : "630876343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785922542183657472\/KTgcg_GM_normal.jpg",
      "id" : 630876343,
      "verified" : false
    }
  },
  "id" : 703729500450906113,
  "created_at" : "2016-02-27 23:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Davies",
      "screen_name" : "KDaviesdesigns",
      "indices" : [ 3, 18 ],
      "id_str" : "20640071",
      "id" : 20640071
    }, {
      "name" : "Gawthorpe Textiles",
      "screen_name" : "RBKS_Textiles",
      "indices" : [ 121, 135 ],
      "id_str" : "584942293",
      "id" : 584942293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/v700bdTmOn",
      "expanded_url" : "http:\/\/wp.me\/p4Ouz-7S2",
      "display_url" : "wp.me\/p4Ouz-7S2"
    } ]
  },
  "geo" : { },
  "id_str" : "703722233206874112",
  "text" : "RT @KDaviesdesigns: My new yoke is inspired by a C19th Kashmir shawl in the Gawthorpe Collection https:\/\/t.co\/v700bdTmOn @RBKS_Textiles htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gawthorpe Textiles",
        "screen_name" : "RBKS_Textiles",
        "indices" : [ 101, 115 ],
        "id_str" : "584942293",
        "id" : 584942293
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KDaviesdesigns\/status\/703516382500102145\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/pS625lBpEQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcNka93W0AACxH8.jpg",
        "id_str" : "703516381246050304",
        "id" : 703516381246050304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcNka93W0AACxH8.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 756,
          "resize" : "fit",
          "w" : 1134
        } ],
        "display_url" : "pic.twitter.com\/pS625lBpEQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/v700bdTmOn",
        "expanded_url" : "http:\/\/wp.me\/p4Ouz-7S2",
        "display_url" : "wp.me\/p4Ouz-7S2"
      } ]
    },
    "geo" : { },
    "id_str" : "703516382500102145",
    "text" : "My new yoke is inspired by a C19th Kashmir shawl in the Gawthorpe Collection https:\/\/t.co\/v700bdTmOn @RBKS_Textiles https:\/\/t.co\/pS625lBpEQ",
    "id" : 703516382500102145,
    "created_at" : "2016-02-27 09:45:50 +0000",
    "user" : {
      "name" : "Kate Davies",
      "screen_name" : "KDaviesdesigns",
      "protected" : false,
      "id_str" : "20640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689811180660080641\/83JypkGn_normal.jpg",
      "id" : 20640071,
      "verified" : false
    }
  },
  "id" : 703722233206874112,
  "created_at" : "2016-02-27 23:23:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "lovelylicious",
      "indices" : [ 3, 17 ],
      "id_str" : "770756381712363521",
      "id" : 770756381712363521
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheDivision",
      "indices" : [ 66, 78 ]
    }, {
      "text" : "BirthdayHype",
      "indices" : [ 104, 117 ]
    }, {
      "text" : "Giveaway",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "twitch",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703699423042396165",
  "text" : "RT @lovelylicious: Well....apparently we're giving away a copy of #TheDivision on my stream tonight!!!! #BirthdayHype #Giveaway #twitch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheDivision",
        "indices" : [ 47, 59 ]
      }, {
        "text" : "BirthdayHype",
        "indices" : [ 85, 98 ]
      }, {
        "text" : "Giveaway",
        "indices" : [ 99, 108 ]
      }, {
        "text" : "twitch",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703681237647384576",
    "text" : "Well....apparently we're giving away a copy of #TheDivision on my stream tonight!!!! #BirthdayHype #Giveaway #twitch",
    "id" : 703681237647384576,
    "created_at" : "2016-02-27 20:40:55 +0000",
    "user" : {
      "name" : "Lish",
      "screen_name" : "ZombieLishy",
      "protected" : false,
      "id_str" : "23562569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796975801186938880\/JJQYPyEs_normal.jpg",
      "id" : 23562569,
      "verified" : false
    }
  },
  "id" : 703699423042396165,
  "created_at" : "2016-02-27 21:53:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703656951310254081",
  "geo" : { },
  "id_str" : "703659680783069188",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time heard of it, didnt know what it meant.",
  "id" : 703659680783069188,
  "in_reply_to_status_id" : 703656951310254081,
  "created_at" : "2016-02-27 19:15:15 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheep In Stitches",
      "screen_name" : "sheepinstitches",
      "indices" : [ 3, 19 ],
      "id_str" : "4653323836",
      "id" : 4653323836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Swaledale",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "sheep",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703652424490336257",
  "text" : "RT @sheepinstitches: One #Swaledale #sheep finished ! Wasn't sure about the horns but blanket stitch edging works.Available via Etsy soon h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sheepinstitches\/status\/703647266960240642\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iYU7rabB7s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcPbdXHWEAEI0_U.jpg",
        "id_str" : "703647264267440129",
        "id" : 703647264267440129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcPbdXHWEAEI0_U.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iYU7rabB7s"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/sheepinstitches\/status\/703647266960240642\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iYU7rabB7s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcPbdXBWEAAA8TQ.jpg",
        "id_str" : "703647264242274304",
        "id" : 703647264242274304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcPbdXBWEAAA8TQ.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/iYU7rabB7s"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/sheepinstitches\/status\/703647266960240642\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iYU7rabB7s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcPbct9WIAAeain.jpg",
        "id_str" : "703647253219647488",
        "id" : 703647253219647488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcPbct9WIAAeain.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/iYU7rabB7s"
      } ],
      "hashtags" : [ {
        "text" : "Swaledale",
        "indices" : [ 4, 14 ]
      }, {
        "text" : "sheep",
        "indices" : [ 15, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703647266960240642",
    "text" : "One #Swaledale #sheep finished ! Wasn't sure about the horns but blanket stitch edging works.Available via Etsy soon https:\/\/t.co\/iYU7rabB7s",
    "id" : 703647266960240642,
    "created_at" : "2016-02-27 18:25:56 +0000",
    "user" : {
      "name" : "Sheep In Stitches",
      "screen_name" : "sheepinstitches",
      "protected" : false,
      "id_str" : "4653323836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682162157929279488\/2-bBr3Z5_normal.jpg",
      "id" : 4653323836,
      "verified" : false
    }
  },
  "id" : 703652424490336257,
  "created_at" : "2016-02-27 18:46:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobookwish",
      "indices" : [ 30, 44 ]
    }, {
      "text" : "fantasy",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703644121538371584",
  "text" : "Under The Harrow by Mark Dunn #audiobookwish #fantasy",
  "id" : 703644121538371584,
  "created_at" : "2016-02-27 18:13:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobookwish",
      "indices" : [ 36, 50 ]
    }, {
      "text" : "audible",
      "indices" : [ 51, 59 ]
    }, {
      "text" : "visionary",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703641708941152256",
  "text" : "The End of Mr. Y by Scarlett Thomas #audiobookwish #audible #visionary",
  "id" : 703641708941152256,
  "created_at" : "2016-02-27 18:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fgoldsmith",
      "screen_name" : "fgoldsmith",
      "indices" : [ 3, 14 ],
      "id_str" : "15917950",
      "id" : 15917950
    }, {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "indices" : [ 34, 47 ],
      "id_str" : "59801057",
      "id" : 59801057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobookwish",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703638695002378241",
  "text" : "RT @fgoldsmith: Check out the new @AudioFileMag initiative to bring attention to missing listening #audiobookwish",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AudioFile Magazine",
        "screen_name" : "AudioFileMag",
        "indices" : [ 18, 31 ],
        "id_str" : "59801057",
        "id" : 59801057
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "audiobookwish",
        "indices" : [ 83, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703631263127769088",
    "text" : "Check out the new @AudioFileMag initiative to bring attention to missing listening #audiobookwish",
    "id" : 703631263127769088,
    "created_at" : "2016-02-27 17:22:20 +0000",
    "user" : {
      "name" : "fgoldsmith",
      "screen_name" : "fgoldsmith",
      "protected" : false,
      "id_str" : "15917950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70527910\/Snapshot_2009-01-08_20-02-44_normal.jpg",
      "id" : 15917950,
      "verified" : false
    }
  },
  "id" : 703638695002378241,
  "created_at" : "2016-02-27 17:51:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Alexandria",
      "screen_name" : "tomalpat",
      "indices" : [ 23, 32 ],
      "id_str" : "804471787",
      "id" : 804471787
    }, {
      "name" : "Inspired Neuron",
      "screen_name" : "Inspiredneuron",
      "indices" : [ 45, 60 ],
      "id_str" : "2324828978",
      "id" : 2324828978
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tomalpat\/status\/703429512176934913\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/VIkUr7gRFA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcMVaeeUkAAgHuU.jpg",
      "id_str" : "703429511400951808",
      "id" : 703429511400951808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcMVaeeUkAAgHuU.jpg",
      "sizes" : [ {
        "h" : 422,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/VIkUr7gRFA"
    } ],
    "hashtags" : [ {
      "text" : "Truth",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703637405925036033",
  "text" : "RT @JamiaStarheart: RT @tomalpat: #Truth via @Inspiredneuron https:\/\/t.co\/VIkUr7gRFA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexandria",
        "screen_name" : "tomalpat",
        "indices" : [ 3, 12 ],
        "id_str" : "804471787",
        "id" : 804471787
      }, {
        "name" : "Inspired Neuron",
        "screen_name" : "Inspiredneuron",
        "indices" : [ 25, 40 ],
        "id_str" : "2324828978",
        "id" : 2324828978
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tomalpat\/status\/703429512176934913\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/VIkUr7gRFA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcMVaeeUkAAgHuU.jpg",
        "id_str" : "703429511400951808",
        "id" : 703429511400951808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcMVaeeUkAAgHuU.jpg",
        "sizes" : [ {
          "h" : 422,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 432
        } ],
        "display_url" : "pic.twitter.com\/VIkUr7gRFA"
      } ],
      "hashtags" : [ {
        "text" : "Truth",
        "indices" : [ 14, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703636811961257984",
    "text" : "RT @tomalpat: #Truth via @Inspiredneuron https:\/\/t.co\/VIkUr7gRFA",
    "id" : 703636811961257984,
    "created_at" : "2016-02-27 17:44:23 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 703637405925036033,
  "created_at" : "2016-02-27 17:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Alexandria",
      "screen_name" : "tomalpat",
      "indices" : [ 23, 32 ],
      "id_str" : "804471787",
      "id" : 804471787
    }, {
      "name" : "Inspired Neuron",
      "screen_name" : "Inspiredneuron",
      "indices" : [ 49, 64 ],
      "id_str" : "2324828978",
      "id" : 2324828978
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tomalpat\/status\/703429156902608896\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/UJpG9doDlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcMVFypUYAAlSgf.jpg",
      "id_str" : "703429156038533120",
      "id" : 703429156038533120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcMVFypUYAAlSgf.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/UJpG9doDlG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703637338983895040",
  "text" : "RT @JamiaStarheart: RT @tomalpat: Perception via @Inspiredneuron https:\/\/t.co\/UJpG9doDlG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexandria",
        "screen_name" : "tomalpat",
        "indices" : [ 3, 12 ],
        "id_str" : "804471787",
        "id" : 804471787
      }, {
        "name" : "Inspired Neuron",
        "screen_name" : "Inspiredneuron",
        "indices" : [ 29, 44 ],
        "id_str" : "2324828978",
        "id" : 2324828978
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tomalpat\/status\/703429156902608896\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/UJpG9doDlG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcMVFypUYAAlSgf.jpg",
        "id_str" : "703429156038533120",
        "id" : 703429156038533120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcMVFypUYAAlSgf.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/UJpG9doDlG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703636865128263682",
    "text" : "RT @tomalpat: Perception via @Inspiredneuron https:\/\/t.co\/UJpG9doDlG",
    "id" : 703636865128263682,
    "created_at" : "2016-02-27 17:44:36 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 703637338983895040,
  "created_at" : "2016-02-27 17:46:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/703634125916401664\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uJONxxBArA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcPPgbIWAAE5TD7.jpg",
      "id_str" : "703634122745446401",
      "id" : 703634122745446401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcPPgbIWAAE5TD7.jpg",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/uJONxxBArA"
    } ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "review",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "YA",
      "indices" : [ 23, 26 ]
    }, {
      "text" : "Freebie",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Aeoj8nqaMq",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/audiobooks\/comments\/47ojwv\/freebie_friday\/d0epl4l?_ts=1456594422",
      "display_url" : "reddit.com\/r\/audiobooks\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703634125916401664",
  "text" : "#audiobook for #review #YA TheVoicesOfBrian comments on #Freebie Friday https:\/\/t.co\/Aeoj8nqaMq https:\/\/t.co\/uJONxxBArA",
  "id" : 703634125916401664,
  "created_at" : "2016-02-27 17:33:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 59, 69 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/CNrrcdY26V",
      "expanded_url" : "http:\/\/igg.me\/p\/1657001\/twtr",
      "display_url" : "igg.me\/p\/1657001\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "703630068678008832",
  "text" : "Help make it happen for A Laptop Fitting in Your Pocket on @indiegogo https:\/\/t.co\/CNrrcdY26V",
  "id" : 703630068678008832,
  "created_at" : "2016-02-27 17:17:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "indices" : [ 2, 15 ],
      "id_str" : "59801057",
      "id" : 59801057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703575921085784068",
  "geo" : { },
  "id_str" : "703618608203767808",
  "in_reply_to_user_id" : 59801057,
  "text" : ". @AudioFileMag love this idea! soooo needed!",
  "id" : 703618608203767808,
  "in_reply_to_status_id" : 703575921085784068,
  "created_at" : "2016-02-27 16:32:03 +0000",
  "in_reply_to_screen_name" : "AudioFileMag",
  "in_reply_to_user_id_str" : "59801057",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "indices" : [ 3, 16 ],
      "id_str" : "59801057",
      "id" : 59801057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobookwish",
      "indices" : [ 39, 53 ]
    }, {
      "text" : "diversevoices",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703618012646141952",
  "text" : "RT @AudioFileMag: Want to hear it? Tag #audiobookwish for books\/writers that have escaped production #diversevoices matter to diverse audio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "audiobookwish",
        "indices" : [ 21, 35 ]
      }, {
        "text" : "diversevoices",
        "indices" : [ 83, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703575921085784068",
    "text" : "Want to hear it? Tag #audiobookwish for books\/writers that have escaped production #diversevoices matter to diverse audiobook enthusiasts",
    "id" : 703575921085784068,
    "created_at" : "2016-02-27 13:42:26 +0000",
    "user" : {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "protected" : false,
      "id_str" : "59801057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525009056\/ArrowsforFacebook_normal.jpg",
      "id" : 59801057,
      "verified" : false
    }
  },
  "id" : 703618012646141952,
  "created_at" : "2016-02-27 16:29:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703614333834686464",
  "text" : "RT @aliceinthewater: Mr. Wait. Which mass shooting are we talking about? Me: this is screwed up that we can't remember which one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703403295000231936",
    "text" : "Mr. Wait. Which mass shooting are we talking about? Me: this is screwed up that we can't remember which one.",
    "id" : 703403295000231936,
    "created_at" : "2016-02-27 02:16:28 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 703614333834686464,
  "created_at" : "2016-02-27 16:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad E. Colby",
      "screen_name" : "TheChadColby",
      "indices" : [ 3, 16 ],
      "id_str" : "213651463",
      "id" : 213651463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/uliJtYGpi9",
      "expanded_url" : "https:\/\/vine.co\/v\/i6U26OiKI5j",
      "display_url" : "vine.co\/v\/i6U26OiKI5j"
    } ]
  },
  "geo" : { },
  "id_str" : "703612890255859713",
  "text" : "RT @TheChadColby: Over Lake Huron MI https:\/\/t.co\/uliJtYGpi9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/uliJtYGpi9",
        "expanded_url" : "https:\/\/vine.co\/v\/i6U26OiKI5j",
        "display_url" : "vine.co\/v\/i6U26OiKI5j"
      } ]
    },
    "geo" : { },
    "id_str" : "703569244622098434",
    "text" : "Over Lake Huron MI https:\/\/t.co\/uliJtYGpi9",
    "id" : 703569244622098434,
    "created_at" : "2016-02-27 13:15:54 +0000",
    "user" : {
      "name" : "Chad E. Colby",
      "screen_name" : "TheChadColby",
      "protected" : false,
      "id_str" : "213651463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663545384489234432\/L8zFkYix_normal.jpg",
      "id" : 213651463,
      "verified" : false
    }
  },
  "id" : 703612890255859713,
  "created_at" : "2016-02-27 16:09:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 0, 7 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703596175715233793",
  "geo" : { },
  "id_str" : "703611756233543680",
  "in_reply_to_user_id" : 6872302,
  "text" : "@Mahala jeeezus...",
  "id" : 703611756233543680,
  "in_reply_to_status_id" : 703596175715233793,
  "created_at" : "2016-02-27 16:04:49 +0000",
  "in_reply_to_screen_name" : "Mahala",
  "in_reply_to_user_id_str" : "6872302",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Harris",
      "screen_name" : "RichHarris2",
      "indices" : [ 3, 15 ],
      "id_str" : "33175391",
      "id" : 33175391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703610941007654912",
  "text" : "RT @RichHarris2: There's no such thing as a mid life crisis. Every damn day is a fucking crisis. Peace and love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703556299313647616",
    "text" : "There's no such thing as a mid life crisis. Every damn day is a fucking crisis. Peace and love.",
    "id" : 703556299313647616,
    "created_at" : "2016-02-27 12:24:27 +0000",
    "user" : {
      "name" : "Richard Harris",
      "screen_name" : "RichHarris2",
      "protected" : false,
      "id_str" : "33175391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788278656711831552\/gYbDfayv_normal.jpg",
      "id" : 33175391,
      "verified" : false
    }
  },
  "id" : 703610941007654912,
  "created_at" : "2016-02-27 16:01:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coffeeaddictkitty\u2600",
      "screen_name" : "yndiabarrows",
      "indices" : [ 3, 16 ],
      "id_str" : "1297463521",
      "id" : 1297463521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703609703239131137",
  "text" : "RT @yndiabarrows: Never spread hate, always be loving. Even if you may not agree, understand, or whatever else - don't ever spread hate. Be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703426368491511808",
    "text" : "Never spread hate, always be loving. Even if you may not agree, understand, or whatever else - don't ever spread hate. Be a good influence.",
    "id" : 703426368491511808,
    "created_at" : "2016-02-27 03:48:09 +0000",
    "user" : {
      "name" : "Coffeeaddictkitty\u2600",
      "screen_name" : "yndiabarrows",
      "protected" : false,
      "id_str" : "1297463521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795825155008327681\/G1IndNpe_normal.jpg",
      "id" : 1297463521,
      "verified" : false
    }
  },
  "id" : 703609703239131137,
  "created_at" : "2016-02-27 15:56:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ravenmaster1\/status\/703607448544944129\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/cAFvIlI3fs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcO3PavXEAAEwpK.jpg",
      "id_str" : "703607442303815680",
      "id" : 703607442303815680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcO3PavXEAAEwpK.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 646,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 646,
        "resize" : "fit",
        "w" : 647
      } ],
      "display_url" : "pic.twitter.com\/cAFvIlI3fs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703609383352180736",
  "text" : "RT @ravenmaster1: https:\/\/t.co\/cAFvIlI3fs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ravenmaster1\/status\/703607448544944129\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/cAFvIlI3fs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcO3PavXEAAEwpK.jpg",
        "id_str" : "703607442303815680",
        "id" : 703607442303815680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcO3PavXEAAEwpK.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 646,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 646,
          "resize" : "fit",
          "w" : 647
        } ],
        "display_url" : "pic.twitter.com\/cAFvIlI3fs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703607448544944129",
    "text" : "https:\/\/t.co\/cAFvIlI3fs",
    "id" : 703607448544944129,
    "created_at" : "2016-02-27 15:47:42 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 703609383352180736,
  "created_at" : "2016-02-27 15:55:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703398892696682497",
  "text" : "\"instead of reading jesus is love, read jesus rained down fire\" GAH. I need to stop following links.. I know better.",
  "id" : 703398892696682497,
  "created_at" : "2016-02-27 01:58:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/beJ2aoBEn8",
      "expanded_url" : "http:\/\/booksonic.org",
      "display_url" : "booksonic.org"
    }, {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/7aJUjaHHRb",
      "expanded_url" : "https:\/\/twitter.com\/inkbitspixels\/status\/703386943204278272",
      "display_url" : "twitter.com\/inkbitspixels\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703393521466798084",
  "text" : "and for android users, there is https:\/\/t.co\/beJ2aoBEn8 https:\/\/t.co\/7aJUjaHHRb",
  "id" : 703393521466798084,
  "created_at" : "2016-02-27 01:37:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anipals",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703381578710446080",
  "text" : "RT @SangyeH: Friends, I'm homeless &amp; need your help to get secure, healthy housing for myself &amp; my #anipals. Thank you!\n \nhttps:\/\/t.co\/cPnV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "anipals",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/cPnVS5ktSy",
        "expanded_url" : "https:\/\/www.gofundme.com\/j6nzp3yk?utm_source=internal&utm_medium=email&utm_content=cta_button&utm_campaign=upd_n",
        "display_url" : "gofundme.com\/j6nzp3yk?utm_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703307168334815232",
    "text" : "Friends, I'm homeless &amp; need your help to get secure, healthy housing for myself &amp; my #anipals. Thank you!\n \nhttps:\/\/t.co\/cPnVS5ktSy",
    "id" : 703307168334815232,
    "created_at" : "2016-02-26 19:54:30 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 703381578710446080,
  "created_at" : "2016-02-27 00:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ms Maggie)))",
      "screen_name" : "maggiepriceless",
      "indices" : [ 3, 19 ],
      "id_str" : "233749323",
      "id" : 233749323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/sWjxL7j5mp",
      "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/703333087791484928",
      "display_url" : "twitter.com\/neiltyson\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703380150872895488",
  "text" : "RT @maggiepriceless: My favorite kind.  https:\/\/t.co\/sWjxL7j5mp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/sWjxL7j5mp",
        "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/703333087791484928",
        "display_url" : "twitter.com\/neiltyson\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703333208323072002",
    "text" : "My favorite kind.  https:\/\/t.co\/sWjxL7j5mp",
    "id" : 703333208323072002,
    "created_at" : "2016-02-26 21:37:58 +0000",
    "user" : {
      "name" : "(((Ms Maggie)))",
      "screen_name" : "maggiepriceless",
      "protected" : false,
      "id_str" : "233749323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797340094042689536\/iYz5ibhq_normal.jpg",
      "id" : 233749323,
      "verified" : false
    }
  },
  "id" : 703380150872895488,
  "created_at" : "2016-02-27 00:44:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/8S700nsTTs",
      "expanded_url" : "http:\/\/religiondispatches.org\/why-it-is-heresy-to-read-the-bible-literally-an-interview-with-john-shelby-spong\/",
      "display_url" : "religiondispatches.org\/why-it-is-here\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703376438897078277",
  "text" : "Why It Is Heresy to Read the Bible Literally: An Interview with John Shelby Spong https:\/\/t.co\/8S700nsTTs",
  "id" : 703376438897078277,
  "created_at" : "2016-02-27 00:29:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "review",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "timetravel",
      "indices" : [ 76, 87 ]
    }, {
      "text" : "scifi",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/uWneXpAMUY",
      "expanded_url" : "https:\/\/youtu.be\/Xou-GJVos80",
      "display_url" : "youtu.be\/Xou-GJVos80"
    } ]
  },
  "geo" : { },
  "id_str" : "703307533948227584",
  "text" : "The Dinosaur Four by Geoff Jones https:\/\/t.co\/uWneXpAMUY #audiobook #review #timetravel #scifi",
  "id" : 703307533948227584,
  "created_at" : "2016-02-26 19:55:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/oybufMzswX",
      "expanded_url" : "https:\/\/youtu.be\/v-gyZIiELtg",
      "display_url" : "youtu.be\/v-gyZIiELtg"
    } ]
  },
  "geo" : { },
  "id_str" : "703305584305643520",
  "text" : "Anyone Smart Left On Youtube? https:\/\/t.co\/oybufMzswX",
  "id" : 703305584305643520,
  "created_at" : "2016-02-26 19:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "reviews",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "funny",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/ZkQsS8YyXz",
      "expanded_url" : "https:\/\/youtu.be\/2htdkev66wc",
      "display_url" : "youtu.be\/2htdkev66wc"
    } ]
  },
  "geo" : { },
  "id_str" : "703302330050023424",
  "text" : "FREE Audio book for lucky viewers! https:\/\/t.co\/ZkQsS8YyXz #audiobooks #reviews #funny",
  "id" : 703302330050023424,
  "created_at" : "2016-02-26 19:35:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 3, 16 ],
      "id_str" : "457997266",
      "id" : 457997266
    }, {
      "name" : "Anthony Vicino",
      "screen_name" : "AnthonyVicino",
      "indices" : [ 69, 83 ],
      "id_str" : "1001012042",
      "id" : 1001012042
    }, {
      "name" : "Adam Verner",
      "screen_name" : "adam_verner",
      "indices" : [ 92, 104 ],
      "id_str" : "50075352",
      "id" : 50075352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/czNsEh41Di",
      "expanded_url" : "http:\/\/audiobookreviewer.com\/reviews\/time-heist-firstborn-saga-book-1-by-anthony-vicino\/",
      "display_url" : "audiobookreviewer.com\/reviews\/time-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703265963446292480",
  "text" : "RT @AudioBookRev: #audiobook review &amp; #giveaway of Time Heist by @AnthonyVicino read by @adam_verner https:\/\/t.co\/czNsEh41Di @Bandofdystopi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.gremlinsocial.com\" rel=\"nofollow\"\u003EGremlin Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Vicino",
        "screen_name" : "AnthonyVicino",
        "indices" : [ 51, 65 ],
        "id_str" : "1001012042",
        "id" : 1001012042
      }, {
        "name" : "Adam Verner",
        "screen_name" : "adam_verner",
        "indices" : [ 74, 86 ],
        "id_str" : "50075352",
        "id" : 50075352
      }, {
        "name" : "Band Of Dystopian",
        "screen_name" : "Bandofdystopian",
        "indices" : [ 111, 127 ],
        "id_str" : "2722393056",
        "id" : 2722393056
      }, {
        "name" : "Scifi Book Cafe",
        "screen_name" : "ScifiBookCafe",
        "indices" : [ 128, 142 ],
        "id_str" : "1918386283",
        "id" : 1918386283
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "audiobook",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "giveaway",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/czNsEh41Di",
        "expanded_url" : "http:\/\/audiobookreviewer.com\/reviews\/time-heist-firstborn-saga-book-1-by-anthony-vicino\/",
        "display_url" : "audiobookreviewer.com\/reviews\/time-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703260396803633152",
    "text" : "#audiobook review &amp; #giveaway of Time Heist by @AnthonyVicino read by @adam_verner https:\/\/t.co\/czNsEh41Di @Bandofdystopian @ScifiBookCafe",
    "id" : 703260396803633152,
    "created_at" : "2016-02-26 16:48:39 +0000",
    "user" : {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "protected" : false,
      "id_str" : "457997266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740455024\/avatar_normal.png",
      "id" : 457997266,
      "verified" : false
    }
  },
  "id" : 703265963446292480,
  "created_at" : "2016-02-26 17:10:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "YA",
      "indices" : [ 62, 65 ]
    }, {
      "text" : "fantasy",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/uCSoC5K3VH",
      "expanded_url" : "https:\/\/twitter.com\/AudioFileMag\/status\/703233835123740673",
      "display_url" : "twitter.com\/AudioFileMag\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703255383087955969",
  "text" : "listened to audio sample.. now its on my TBL list. #audiobook #YA #fantasy https:\/\/t.co\/uCSoC5K3VH",
  "id" : 703255383087955969,
  "created_at" : "2016-02-26 16:28:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703217238350897152",
  "text" : "RT @bend_time: ffs jon stewart, just throw us some podcasts from the farm, would ya? WE NEED YOU.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703047680121962496",
    "text" : "ffs jon stewart, just throw us some podcasts from the farm, would ya? WE NEED YOU.",
    "id" : 703047680121962496,
    "created_at" : "2016-02-26 02:43:23 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 703217238350897152,
  "created_at" : "2016-02-26 13:57:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/703210209632763905\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/mZuQS5Qu1Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcJN9BpXEAAwhuM.jpg",
      "id_str" : "703210202632491008",
      "id" : 703210202632491008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcJN9BpXEAAwhuM.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/mZuQS5Qu1Y"
    } ],
    "hashtags" : [ {
      "text" : "abandonedhome",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703210600009224192",
  "text" : "RT @dwaynereaves: #abandonedhome on Main Street in Roxboro N.C https:\/\/t.co\/mZuQS5Qu1Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/703210209632763905\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/mZuQS5Qu1Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcJN9BpXEAAwhuM.jpg",
        "id_str" : "703210202632491008",
        "id" : 703210202632491008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcJN9BpXEAAwhuM.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/mZuQS5Qu1Y"
      } ],
      "hashtags" : [ {
        "text" : "abandonedhome",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703210209632763905",
    "text" : "#abandonedhome on Main Street in Roxboro N.C https:\/\/t.co\/mZuQS5Qu1Y",
    "id" : 703210209632763905,
    "created_at" : "2016-02-26 13:29:13 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 703210600009224192,
  "created_at" : "2016-02-26 13:30:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Troyano",
      "screen_name" : "luistroyano",
      "indices" : [ 3, 15 ],
      "id_str" : "72933296",
      "id" : 72933296
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/luistroyano\/status\/702908986362871808\/video\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/NQ4AMS6IBs",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702908891458363392\/pu\/img\/reJBvypzAlJGF1Fk.jpg",
      "id_str" : "702908891458363392",
      "id" : 702908891458363392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702908891458363392\/pu\/img\/reJBvypzAlJGF1Fk.jpg",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/NQ4AMS6IBs"
    } ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703015890749681665",
  "text" : "RT @luistroyano: Erm, where do I get a high-fiving #cat from?! https:\/\/t.co\/NQ4AMS6IBs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/luistroyano\/status\/702908986362871808\/video\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/NQ4AMS6IBs",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702908891458363392\/pu\/img\/reJBvypzAlJGF1Fk.jpg",
        "id_str" : "702908891458363392",
        "id" : 702908891458363392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702908891458363392\/pu\/img\/reJBvypzAlJGF1Fk.jpg",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/NQ4AMS6IBs"
      } ],
      "hashtags" : [ {
        "text" : "cat",
        "indices" : [ 34, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702908986362871808",
    "text" : "Erm, where do I get a high-fiving #cat from?! https:\/\/t.co\/NQ4AMS6IBs",
    "id" : 702908986362871808,
    "created_at" : "2016-02-25 17:32:16 +0000",
    "user" : {
      "name" : "Luis Troyano",
      "screen_name" : "luistroyano",
      "protected" : false,
      "id_str" : "72933296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769934818373210113\/y_6Pq4qh_normal.jpg",
      "id" : 72933296,
      "verified" : true
    }
  },
  "id" : 703015890749681665,
  "created_at" : "2016-02-26 00:37:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VQY7dcQ5d6",
      "expanded_url" : "https:\/\/twitter.com\/SangHeffa\/status\/702995609653915648",
      "display_url" : "twitter.com\/SangHeffa\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703010705801416704",
  "text" : "RT @SangyeH: Millions of \"true Democrats\" voted against Hillary in 2008.\n#justsayin  https:\/\/t.co\/VQY7dcQ5d6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justsayin",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/VQY7dcQ5d6",
        "expanded_url" : "https:\/\/twitter.com\/SangHeffa\/status\/702995609653915648",
        "display_url" : "twitter.com\/SangHeffa\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702997439637168129",
    "text" : "Millions of \"true Democrats\" voted against Hillary in 2008.\n#justsayin  https:\/\/t.co\/VQY7dcQ5d6",
    "id" : 702997439637168129,
    "created_at" : "2016-02-25 23:23:45 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 703010705801416704,
  "created_at" : "2016-02-26 00:16:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/703001241836773377\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/lxSBzxzMrF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcGP5siW4AAUIwL.jpg",
      "id_str" : "703001238217089024",
      "id" : 703001238217089024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcGP5siW4AAUIwL.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 381
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/lxSBzxzMrF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/TXrZKg1vvJ",
      "expanded_url" : "http:\/\/www.victorzammit.com\/articles\/nasascientist2full.htm?_ts=1456443527",
      "display_url" : "victorzammit.com\/articles\/nasas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703001241836773377",
  "text" : "brain, death, dimensions... nasascientistfull2 https:\/\/t.co\/TXrZKg1vvJ https:\/\/t.co\/lxSBzxzMrF",
  "id" : 703001241836773377,
  "created_at" : "2016-02-25 23:38:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claude West -Cat Man",
      "screen_name" : "claudeone",
      "indices" : [ 3, 13 ],
      "id_str" : "172509738",
      "id" : 172509738
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/claudeone\/status\/702908956029669378\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/GDb2fk5TOh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcE7-JwW8AAn_1c.jpg",
      "id_str" : "702908955803185152",
      "id" : 702908955803185152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcE7-JwW8AAn_1c.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 236
      } ],
      "display_url" : "pic.twitter.com\/GDb2fk5TOh"
    } ],
    "hashtags" : [ {
      "text" : "catsoftwitter",
      "indices" : [ 77, 91 ]
    }, {
      "text" : "cats",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702984736961069056",
  "text" : "RT @claudeone: Kitty Wisdom of the Day. A cats worst enemy is a closed door. #catsoftwitter, #cats https:\/\/t.co\/GDb2fk5TOh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/claudeone\/status\/702908956029669378\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/GDb2fk5TOh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcE7-JwW8AAn_1c.jpg",
        "id_str" : "702908955803185152",
        "id" : 702908955803185152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcE7-JwW8AAn_1c.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 236
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 236
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 236
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 236
        } ],
        "display_url" : "pic.twitter.com\/GDb2fk5TOh"
      } ],
      "hashtags" : [ {
        "text" : "catsoftwitter",
        "indices" : [ 62, 76 ]
      }, {
        "text" : "cats",
        "indices" : [ 78, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702908956029669378",
    "text" : "Kitty Wisdom of the Day. A cats worst enemy is a closed door. #catsoftwitter, #cats https:\/\/t.co\/GDb2fk5TOh",
    "id" : 702908956029669378,
    "created_at" : "2016-02-25 17:32:09 +0000",
    "user" : {
      "name" : "Claude West -Cat Man",
      "screen_name" : "claudeone",
      "protected" : false,
      "id_str" : "172509738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3339996328\/e6a65d0e7f4878e542aa4877ecada85c_normal.jpeg",
      "id" : 172509738,
      "verified" : false
    }
  },
  "id" : 702984736961069056,
  "created_at" : "2016-02-25 22:33:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abundance Mindset",
      "screen_name" : "AbundanceMind11",
      "indices" : [ 3, 19 ],
      "id_str" : "3944570420",
      "id" : 3944570420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702983743104000000",
  "text" : "RT @AbundanceMind11: You are in a process of spiritual unfolding. You must watch your heart, know the truth, and be patient with your unfol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702973100862926848",
    "text" : "You are in a process of spiritual unfolding. You must watch your heart, know the truth, and be patient with your unfolding process.",
    "id" : 702973100862926848,
    "created_at" : "2016-02-25 21:47:02 +0000",
    "user" : {
      "name" : "Abundance Mindset",
      "screen_name" : "AbundanceMind11",
      "protected" : false,
      "id_str" : "3944570420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656472891488276480\/fWLkRhQG_normal.jpg",
      "id" : 3944570420,
      "verified" : false
    }
  },
  "id" : 702983743104000000,
  "created_at" : "2016-02-25 22:29:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Always loving OB",
      "screen_name" : "WellyTopping",
      "indices" : [ 3, 16 ],
      "id_str" : "3154626832",
      "id" : 3154626832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/earthepix\/status\/702912753023873024\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/vtMhnfFi1p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcE_bKtVAAEXezc.jpg",
      "id_str" : "702912752810000385",
      "id" : 702912752810000385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcE_bKtVAAEXezc.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/vtMhnfFi1p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702933020119056384",
  "text" : "RT @WellyTopping: Hugging cats https:\/\/t.co\/vtMhnfFi1p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/earthepix\/status\/702912753023873024\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/vtMhnfFi1p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcE_bKtVAAEXezc.jpg",
        "id_str" : "702912752810000385",
        "id" : 702912752810000385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcE_bKtVAAEXezc.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/vtMhnfFi1p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702931542327357440",
    "text" : "Hugging cats https:\/\/t.co\/vtMhnfFi1p",
    "id" : 702931542327357440,
    "created_at" : "2016-02-25 19:01:54 +0000",
    "user" : {
      "name" : "Always loving OB",
      "screen_name" : "WellyTopping",
      "protected" : false,
      "id_str" : "3154626832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742257282038140929\/N5ox5ck2_normal.png",
      "id" : 3154626832,
      "verified" : false
    }
  },
  "id" : 702933020119056384,
  "created_at" : "2016-02-25 19:07:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Thompson",
      "screen_name" : "bri66thomp",
      "indices" : [ 3, 14 ],
      "id_str" : "1269155425",
      "id" : 1269155425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bri66thomp\/status\/702928004088008705\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/IZxylvx8ey",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcFNSqSW0AAx_FB.jpg",
      "id_str" : "702927999830773760",
      "id" : 702927999830773760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcFNSqSW0AAx_FB.jpg",
      "sizes" : [ {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IZxylvx8ey"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702932830641377280",
  "text" : "RT @bri66thomp: RN Duck giving me the dirty. \"Oi, keep off me bread\uD83D\uDE21\" https:\/\/t.co\/IZxylvx8ey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bri66thomp\/status\/702928004088008705\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/IZxylvx8ey",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcFNSqSW0AAx_FB.jpg",
        "id_str" : "702927999830773760",
        "id" : 702927999830773760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcFNSqSW0AAx_FB.jpg",
        "sizes" : [ {
          "h" : 704,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IZxylvx8ey"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702928004088008705",
    "text" : "RN Duck giving me the dirty. \"Oi, keep off me bread\uD83D\uDE21\" https:\/\/t.co\/IZxylvx8ey",
    "id" : 702928004088008705,
    "created_at" : "2016-02-25 18:47:50 +0000",
    "user" : {
      "name" : "Brian Thompson",
      "screen_name" : "bri66thomp",
      "protected" : false,
      "id_str" : "1269155425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3386684382\/fbb7fe7df647846b9dd863894164d1c9_normal.jpeg",
      "id" : 1269155425,
      "verified" : false
    }
  },
  "id" : 702932830641377280,
  "created_at" : "2016-02-25 19:07:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 3, 19 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/eQfTdtbU2G",
      "expanded_url" : "http:\/\/TheHudsonValley.com",
      "display_url" : "TheHudsonValley.com"
    } ]
  },
  "geo" : { },
  "id_str" : "702932663800348672",
  "text" : "RT @TheHudsonValley: Workers walking on cables between the newly built towers of the Mid-Hudson Bridge, 1929. https:\/\/t.co\/eQfTdtbU2G RT! h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheHudsonValley\/status\/702931984272723969\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3Koj1szaci",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcFQ6i1WAAAayz5.jpg",
        "id_str" : "702931983559688192",
        "id" : 702931983559688192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcFQ6i1WAAAayz5.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 544
        } ],
        "display_url" : "pic.twitter.com\/3Koj1szaci"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/eQfTdtbU2G",
        "expanded_url" : "http:\/\/TheHudsonValley.com",
        "display_url" : "TheHudsonValley.com"
      } ]
    },
    "geo" : { },
    "id_str" : "702931984272723969",
    "text" : "Workers walking on cables between the newly built towers of the Mid-Hudson Bridge, 1929. https:\/\/t.co\/eQfTdtbU2G RT! https:\/\/t.co\/3Koj1szaci",
    "id" : 702931984272723969,
    "created_at" : "2016-02-25 19:03:39 +0000",
    "user" : {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "protected" : false,
      "id_str" : "102313523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567810424549044227\/C6iux0NV_normal.png",
      "id" : 102313523,
      "verified" : false
    }
  },
  "id" : 702932663800348672,
  "created_at" : "2016-02-25 19:06:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    }, {
      "name" : "Rich \uD83D\uDCFD Swifty2606",
      "screen_name" : "swifty2606",
      "indices" : [ 18, 29 ],
      "id_str" : "183760071",
      "id" : 183760071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702923076950958080",
  "text" : "RT @SciencePorn: .@swifty2606 Would that mean that the second cat would be double-dead, double-alive, alive-dead or dead-alive(also dead)? \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rich \uD83D\uDCFD Swifty2606",
        "screen_name" : "swifty2606",
        "indices" : [ 1, 12 ],
        "id_str" : "183760071",
        "id" : 183760071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702919523100393472",
    "geo" : { },
    "id_str" : "702922373641715712",
    "in_reply_to_user_id" : 183760071,
    "text" : ".@swifty2606 Would that mean that the second cat would be double-dead, double-alive, alive-dead or dead-alive(also dead)? Poor cat",
    "id" : 702922373641715712,
    "in_reply_to_status_id" : 702919523100393472,
    "created_at" : "2016-02-25 18:25:28 +0000",
    "in_reply_to_screen_name" : "swifty2606",
    "in_reply_to_user_id_str" : "183760071",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 702923076950958080,
  "created_at" : "2016-02-25 18:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "indices" : [ 3, 16 ],
      "id_str" : "217626610",
      "id" : 217626610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702917672657408001",
  "text" : "RT @jameslsutter: ME: \"Hmm, which tweet should I pin to my profile? Writing advice? Book links?\"\n\nMY BRAIN: \"THE ONE ABOUT ZEUS GETTING LAI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699367132597891072",
    "text" : "ME: \"Hmm, which tweet should I pin to my profile? Writing advice? Book links?\"\n\nMY BRAIN: \"THE ONE ABOUT ZEUS GETTING LAID AT THE ZOO.\"",
    "id" : 699367132597891072,
    "created_at" : "2016-02-15 22:58:12 +0000",
    "user" : {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "protected" : false,
      "id_str" : "217626610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739849533346054144\/6CIwOnsG_normal.jpg",
      "id" : 217626610,
      "verified" : false
    }
  },
  "id" : 702917672657408001,
  "created_at" : "2016-02-25 18:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "indices" : [ 3, 16 ],
      "id_str" : "217626610",
      "id" : 217626610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/40tWqel4Al",
      "expanded_url" : "https:\/\/twitter.com\/RobHBedford\/status\/700696068682551296",
      "display_url" : "twitter.com\/RobHBedford\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702917373632839680",
  "text" : "RT @jameslsutter: See Rob. See Rob's excellent taste. Be like Rob. https:\/\/t.co\/40tWqel4Al",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/40tWqel4Al",
        "expanded_url" : "https:\/\/twitter.com\/RobHBedford\/status\/700696068682551296",
        "display_url" : "twitter.com\/RobHBedford\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700727655348330496",
    "text" : "See Rob. See Rob's excellent taste. Be like Rob. https:\/\/t.co\/40tWqel4Al",
    "id" : 700727655348330496,
    "created_at" : "2016-02-19 17:04:26 +0000",
    "user" : {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "protected" : false,
      "id_str" : "217626610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739849533346054144\/6CIwOnsG_normal.jpg",
      "id" : 217626610,
      "verified" : false
    }
  },
  "id" : 702917373632839680,
  "created_at" : "2016-02-25 18:05:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "indices" : [ 3, 16 ],
      "id_str" : "217626610",
      "id" : 217626610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702917337779937280",
  "text" : "RT @jameslsutter: Today I learned that a group of wombats is called a \"wisdom.\" A wisdom of wombats!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700834770540843008",
    "text" : "Today I learned that a group of wombats is called a \"wisdom.\" A wisdom of wombats!",
    "id" : 700834770540843008,
    "created_at" : "2016-02-20 00:10:04 +0000",
    "user" : {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "protected" : false,
      "id_str" : "217626610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739849533346054144\/6CIwOnsG_normal.jpg",
      "id" : 217626610,
      "verified" : false
    }
  },
  "id" : 702917337779937280,
  "created_at" : "2016-02-25 18:05:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "indices" : [ 0, 13 ],
      "id_str" : "217626610",
      "id" : 217626610
    }, {
      "name" : "Ray_Porter",
      "screen_name" : "Ray_Porter",
      "indices" : [ 98, 109 ],
      "id_str" : "388692159",
      "id" : 388692159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700727655348330496",
  "geo" : { },
  "id_str" : "702916664946458629",
  "in_reply_to_user_id" : 217626610,
  "text" : "@jameslsutter i listened to this recently. book 2 TBR. I want more Salim Ghadafar audiobooks with @Ray_Porter .. Make it happen.",
  "id" : 702916664946458629,
  "in_reply_to_status_id" : 700727655348330496,
  "created_at" : "2016-02-25 18:02:47 +0000",
  "in_reply_to_screen_name" : "jameslsutter",
  "in_reply_to_user_id_str" : "217626610",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUS",
      "indices" : [ 31, 37 ]
    }, {
      "text" : "BarackObama",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "RayCharles",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/SpH8eJU3yI",
      "expanded_url" : "https:\/\/tmblr.co\/Zwrgwo22M_kzr",
      "display_url" : "tmblr.co\/Zwrgwo22M_kzr"
    } ]
  },
  "geo" : { },
  "id_str" : "702894630984163329",
  "text" : "RT @Matth3ous: \uD83D\uDCF9 Listen to the #POTUS #BarackObama sing the intro to a classic by the late, great #RayCharles... https:\/\/t.co\/SpH8eJU3yI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "BarackObama",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "RayCharles",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/SpH8eJU3yI",
        "expanded_url" : "https:\/\/tmblr.co\/Zwrgwo22M_kzr",
        "display_url" : "tmblr.co\/Zwrgwo22M_kzr"
      } ]
    },
    "geo" : { },
    "id_str" : "702875409151606784",
    "text" : "\uD83D\uDCF9 Listen to the #POTUS #BarackObama sing the intro to a classic by the late, great #RayCharles... https:\/\/t.co\/SpH8eJU3yI",
    "id" : 702875409151606784,
    "created_at" : "2016-02-25 15:18:50 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 702894630984163329,
  "created_at" : "2016-02-25 16:35:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "review",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/bZHEDeCgJX",
      "expanded_url" : "https:\/\/twitter.com\/adamrshields\/status\/702850003451015169",
      "display_url" : "twitter.com\/adamrshields\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702893806811746306",
  "text" : "sold! thx.. got WS version. #audiobook #review https:\/\/t.co\/bZHEDeCgJX",
  "id" : 702893806811746306,
  "created_at" : "2016-02-25 16:31:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702635770771705856",
  "geo" : { },
  "id_str" : "702651276006465536",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep heehee. i dont watch much tv but seems when I \"want\" to watch, something interrupts.. very annoying.",
  "id" : 702651276006465536,
  "in_reply_to_status_id" : 702635770771705856,
  "created_at" : "2016-02-25 00:28:13 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702638898850222081",
  "geo" : { },
  "id_str" : "702651010955743234",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe hehe.. our aussie is similar.. she'll get up and move.",
  "id" : 702651010955743234,
  "in_reply_to_status_id" : 702638898850222081,
  "created_at" : "2016-02-25 00:27:10 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TamiShields",
      "screen_name" : "TamiShields",
      "indices" : [ 0, 12 ],
      "id_str" : "18398793",
      "id" : 18398793
    }, {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 13, 26 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "702639446676643840",
  "geo" : { },
  "id_str" : "702650754629287936",
  "in_reply_to_user_id" : 18398793,
  "text" : "@TamiShields @adamrshields  tiny poncho is adorable : )",
  "id" : 702650754629287936,
  "in_reply_to_status_id" : 702639446676643840,
  "created_at" : "2016-02-25 00:26:09 +0000",
  "in_reply_to_screen_name" : "TamiShields",
  "in_reply_to_user_id_str" : "18398793",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncwx",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702650103643938821",
  "text" : "RT @dwaynereaves: The day ended with a Rainbow here in Person County #ncwx @LizHortonABC11 https:\/\/t.co\/KNubEkVwz3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/702649304259891200\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/KNubEkVwz3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcBPrC0W8AAuADA.jpg",
        "id_str" : "702649142779244544",
        "id" : 702649142779244544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcBPrC0W8AAuADA.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/KNubEkVwz3"
      } ],
      "hashtags" : [ {
        "text" : "ncwx",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702649304259891200",
    "text" : "The day ended with a Rainbow here in Person County #ncwx @LizHortonABC11 https:\/\/t.co\/KNubEkVwz3",
    "id" : 702649304259891200,
    "created_at" : "2016-02-25 00:20:23 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 702650103643938821,
  "created_at" : "2016-02-25 00:23:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD87 Q-LUM",
      "screen_name" : "ElectrumCube",
      "indices" : [ 3, 16 ],
      "id_str" : "16639123",
      "id" : 16639123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702589604260663296",
  "text" : "RT @ElectrumCube: the defining quality of autistic people is feeling things too much, so we should be called hyperpaths",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mvilla.it\/fenix\" rel=\"nofollow\"\u003EFenix for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702588716041138176",
    "geo" : { },
    "id_str" : "702588790481682432",
    "in_reply_to_user_id" : 16639123,
    "text" : "the defining quality of autistic people is feeling things too much, so we should be called hyperpaths",
    "id" : 702588790481682432,
    "in_reply_to_status_id" : 702588716041138176,
    "created_at" : "2016-02-24 20:19:55 +0000",
    "in_reply_to_screen_name" : "ElectrumCube",
    "in_reply_to_user_id_str" : "16639123",
    "user" : {
      "name" : "\uD83E\uDD87 Q-LUM",
      "screen_name" : "ElectrumCube",
      "protected" : false,
      "id_str" : "16639123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793483483117125632\/XMooPFDV_normal.jpg",
      "id" : 16639123,
      "verified" : false
    }
  },
  "id" : 702589604260663296,
  "created_at" : "2016-02-24 20:23:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD87 Q-LUM",
      "screen_name" : "ElectrumCube",
      "indices" : [ 3, 16 ],
      "id_str" : "16639123",
      "id" : 16639123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702589587949019136",
  "text" : "RT @ElectrumCube: the word \"autistic\" is etymologically weird to me because it's based on us seeming \"self absorbed\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mvilla.it\/fenix\" rel=\"nofollow\"\u003EFenix for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702588716041138176",
    "text" : "the word \"autistic\" is etymologically weird to me because it's based on us seeming \"self absorbed\"",
    "id" : 702588716041138176,
    "created_at" : "2016-02-24 20:19:38 +0000",
    "user" : {
      "name" : "\uD83E\uDD87 Q-LUM",
      "screen_name" : "ElectrumCube",
      "protected" : false,
      "id_str" : "16639123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793483483117125632\/XMooPFDV_normal.jpg",
      "id" : 16639123,
      "verified" : false
    }
  },
  "id" : 702589587949019136,
  "created_at" : "2016-02-24 20:23:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gomez",
      "screen_name" : "alangomez",
      "indices" : [ 3, 13 ],
      "id_str" : "16413730",
      "id" : 16413730
    }, {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 116, 125 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/IY8wM41Lzb",
      "expanded_url" : "http:\/\/usat.ly\/1TFyKUR",
      "display_url" : "usat.ly\/1TFyKUR"
    } ]
  },
  "geo" : { },
  "id_str" : "702581826246803456",
  "text" : "RT @alangomez: Rather terrifying: I got hacked mid-air while writing an Apple-FBI story https:\/\/t.co\/IY8wM41Lzb via @usatoday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA TODAY",
        "screen_name" : "USATODAY",
        "indices" : [ 101, 110 ],
        "id_str" : "15754281",
        "id" : 15754281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/IY8wM41Lzb",
        "expanded_url" : "http:\/\/usat.ly\/1TFyKUR",
        "display_url" : "usat.ly\/1TFyKUR"
      } ]
    },
    "geo" : { },
    "id_str" : "702568757919682560",
    "text" : "Rather terrifying: I got hacked mid-air while writing an Apple-FBI story https:\/\/t.co\/IY8wM41Lzb via @usatoday",
    "id" : 702568757919682560,
    "created_at" : "2016-02-24 19:00:19 +0000",
    "user" : {
      "name" : "Alan Gomez",
      "screen_name" : "alangomez",
      "protected" : false,
      "id_str" : "16413730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536215453342126081\/s-HN67uT_normal.jpeg",
      "id" : 16413730,
      "verified" : true
    }
  },
  "id" : 702581826246803456,
  "created_at" : "2016-02-24 19:52:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/cuiIsXGEBg",
      "expanded_url" : "https:\/\/twitter.com\/GottaLaff\/status\/702562413367787520",
      "display_url" : "twitter.com\/GottaLaff\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702566358228344832",
  "text" : "LOL https:\/\/t.co\/cuiIsXGEBg",
  "id" : 702566358228344832,
  "created_at" : "2016-02-24 18:50:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/TOklJ8dtYA",
      "expanded_url" : "https:\/\/twitter.com\/viciousbabushka\/status\/702510856538558464",
      "display_url" : "twitter.com\/viciousbabushk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702563257215799296",
  "text" : "im not judging melania but this is true... https:\/\/t.co\/TOklJ8dtYA",
  "id" : 702563257215799296,
  "created_at" : "2016-02-24 18:38:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget Mellor",
      "screen_name" : "bidamellor",
      "indices" : [ 3, 14 ],
      "id_str" : "1101111733",
      "id" : 1101111733
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bidamellor\/status\/702539747990872065\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/YbFc6dF6rH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_sJyzWAAEjkXB.jpg",
      "id_str" : "702539719893188609",
      "id" : 702539719893188609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_sJyzWAAEjkXB.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YbFc6dF6rH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702561779025629184",
  "text" : "RT @bidamellor: Crocuses emerging in Harrogate https:\/\/t.co\/YbFc6dF6rH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bidamellor\/status\/702539747990872065\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/YbFc6dF6rH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_sJyzWAAEjkXB.jpg",
        "id_str" : "702539719893188609",
        "id" : 702539719893188609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_sJyzWAAEjkXB.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YbFc6dF6rH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702539747990872065",
    "text" : "Crocuses emerging in Harrogate https:\/\/t.co\/YbFc6dF6rH",
    "id" : 702539747990872065,
    "created_at" : "2016-02-24 17:05:03 +0000",
    "user" : {
      "name" : "Bridget Mellor",
      "screen_name" : "bidamellor",
      "protected" : false,
      "id_str" : "1101111733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749737384284225536\/sVfK4S-6_normal.jpg",
      "id" : 1101111733,
      "verified" : false
    }
  },
  "id" : 702561779025629184,
  "created_at" : "2016-02-24 18:32:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/627xGDNM31",
      "expanded_url" : "https:\/\/twitter.com\/qikipedia\/status\/702514383528796161",
      "display_url" : "twitter.com\/qikipedia\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702561672175624193",
  "text" : "hmm.. would that improve my astigmatism then? https:\/\/t.co\/627xGDNM31",
  "id" : 702561672175624193,
  "created_at" : "2016-02-24 18:32:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncwx",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "weather",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702561265064013824",
  "text" : "RT @dwaynereaves: Fast moving clouds here in Roxboro and a lot of wind. Make it a safe day everyone! #ncwx #weather @LizHortonABC11 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/702550102540419076\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/m3Rzw0EGqc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_1PzVXIAEKTHb.jpg",
        "id_str" : "702549718719733761",
        "id" : 702549718719733761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_1PzVXIAEKTHb.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1067
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        } ],
        "display_url" : "pic.twitter.com\/m3Rzw0EGqc"
      } ],
      "hashtags" : [ {
        "text" : "ncwx",
        "indices" : [ 83, 88 ]
      }, {
        "text" : "weather",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702550102540419076",
    "text" : "Fast moving clouds here in Roxboro and a lot of wind. Make it a safe day everyone! #ncwx #weather @LizHortonABC11 https:\/\/t.co\/m3Rzw0EGqc",
    "id" : 702550102540419076,
    "created_at" : "2016-02-24 17:46:11 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 702561265064013824,
  "created_at" : "2016-02-24 18:30:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702553346620727296",
  "text" : "dh is doing public service by taking care of me. i have worked (part-time). left prev job combinination of dd needs and my neurosis.",
  "id" : 702553346620727296,
  "created_at" : "2016-02-24 17:59:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702552172253290497",
  "text" : "RT @AndyBoxHill: The setting sun painted dappled orange on these twisted branches through the yew canopy. Looks fab doesn't it. \uD83D\uDE0A https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/702550598894428160\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/uszB5uZEQB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_18p7W8AA3uo1.jpg",
        "id_str" : "702550489288863744",
        "id" : 702550489288863744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_18p7W8AA3uo1.jpg",
        "sizes" : [ {
          "h" : 1343,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1343,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/uszB5uZEQB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702550598894428160",
    "text" : "The setting sun painted dappled orange on these twisted branches through the yew canopy. Looks fab doesn't it. \uD83D\uDE0A https:\/\/t.co\/uszB5uZEQB",
    "id" : 702550598894428160,
    "created_at" : "2016-02-24 17:48:10 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 702552172253290497,
  "created_at" : "2016-02-24 17:54:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702551635449479169",
  "text" : "another example of my neurosis .. creamer has a specific spot in fridge. if it is moved elsewhere.. to me, we have none.",
  "id" : 702551635449479169,
  "created_at" : "2016-02-24 17:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702551023949316096",
  "text" : "i read a lot and want to leave reviews but 5 stars is too many choices. 3 would work better for me.",
  "id" : 702551023949316096,
  "created_at" : "2016-02-24 17:49:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OCD",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702549117759832064",
  "text" : "while im not official #OCD .. ive got tendencies? hard to make decisions, very rigid in specific ways. also perfection or nothing.",
  "id" : 702549117759832064,
  "created_at" : "2016-02-24 17:42:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Chesler",
      "screen_name" : "RickChesler",
      "indices" : [ 3, 15 ],
      "id_str" : "17554456",
      "id" : 17554456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ocean",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/KUqDUTTNUF",
      "expanded_url" : "http:\/\/ow.ly\/YHUPz",
      "display_url" : "ow.ly\/YHUPz"
    } ]
  },
  "geo" : { },
  "id_str" : "702547443620171777",
  "text" : "RT @RickChesler: Mysterious Deep Hum Found Within The Ocean's \"Twilight Zone\u201D #ocean https:\/\/t.co\/KUqDUTTNUF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ocean",
        "indices" : [ 61, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/KUqDUTTNUF",
        "expanded_url" : "http:\/\/ow.ly\/YHUPz",
        "display_url" : "ow.ly\/YHUPz"
      } ]
    },
    "geo" : { },
    "id_str" : "702541886444191744",
    "text" : "Mysterious Deep Hum Found Within The Ocean's \"Twilight Zone\u201D #ocean https:\/\/t.co\/KUqDUTTNUF",
    "id" : 702541886444191744,
    "created_at" : "2016-02-24 17:13:32 +0000",
    "user" : {
      "name" : "Rick Chesler",
      "screen_name" : "RickChesler",
      "protected" : false,
      "id_str" : "17554456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772163787654737920\/_e3IDVfp_normal.jpg",
      "id" : 17554456,
      "verified" : false
    }
  },
  "id" : 702547443620171777,
  "created_at" : "2016-02-24 17:35:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark LaViolette",
      "screen_name" : "MarkLaViolette",
      "indices" : [ 3, 18 ],
      "id_str" : "331173947",
      "id" : 331173947
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 112, 123 ]
    }, {
      "text" : "ListenedTo",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702538017936814080",
  "text" : "RT @MarkLaViolette: I finished listening to the audiobook \"Deadpool: Paws\" by GraphicAudio. Highly Recommended. #audiobooks #ListenedTo htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkLaViolette\/status\/702521088194977792\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/yCNYt06KJ6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_bNR3UkAAJjTU.jpg",
        "id_str" : "702521088073306112",
        "id" : 702521088073306112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_bNR3UkAAJjTU.jpg",
        "sizes" : [ {
          "h" : 458,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 458
        } ],
        "display_url" : "pic.twitter.com\/yCNYt06KJ6"
      } ],
      "hashtags" : [ {
        "text" : "audiobooks",
        "indices" : [ 92, 103 ]
      }, {
        "text" : "ListenedTo",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702521088194977792",
    "text" : "I finished listening to the audiobook \"Deadpool: Paws\" by GraphicAudio. Highly Recommended. #audiobooks #ListenedTo https:\/\/t.co\/yCNYt06KJ6",
    "id" : 702521088194977792,
    "created_at" : "2016-02-24 15:50:54 +0000",
    "user" : {
      "name" : "Mark LaViolette",
      "screen_name" : "MarkLaViolette",
      "protected" : false,
      "id_str" : "331173947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797349365056765952\/I2TZhfOz_normal.jpg",
      "id" : 331173947,
      "verified" : false
    }
  },
  "id" : 702538017936814080,
  "created_at" : "2016-02-24 16:58:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 3, 16 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/tDy0ErXxQq",
      "expanded_url" : "https:\/\/shipguy.wordpress.com\/2014\/02\/16\/its-all-about-scale\/",
      "display_url" : "shipguy.wordpress.com\/2014\/02\/16\/its\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702535830527746049",
  "text" : "RT @TorontoLydia: Here\u2019s a blog post explaining the picture I just retweeted: https:\/\/t.co\/tDy0ErXxQq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/tDy0ErXxQq",
        "expanded_url" : "https:\/\/shipguy.wordpress.com\/2014\/02\/16\/its-all-about-scale\/",
        "display_url" : "shipguy.wordpress.com\/2014\/02\/16\/its\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702530776252948481",
    "text" : "Here\u2019s a blog post explaining the picture I just retweeted: https:\/\/t.co\/tDy0ErXxQq",
    "id" : 702530776252948481,
    "created_at" : "2016-02-24 16:29:24 +0000",
    "user" : {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "protected" : false,
      "id_str" : "17068546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2110881642\/LydiaTea_normal",
      "id" : 17068546,
      "verified" : false
    }
  },
  "id" : 702535830527746049,
  "created_at" : "2016-02-24 16:49:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 3, 16 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hk9AzZnCPm",
      "expanded_url" : "https:\/\/twitter.com\/WorldAndScience\/status\/702520887560384513",
      "display_url" : "twitter.com\/WorldAndScienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702535785728315392",
  "text" : "RT @TorontoLydia: I\u2019m retweeting this so my next tweet will make sense.  https:\/\/t.co\/hk9AzZnCPm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/hk9AzZnCPm",
        "expanded_url" : "https:\/\/twitter.com\/WorldAndScience\/status\/702520887560384513",
        "display_url" : "twitter.com\/WorldAndScienc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702530660305608704",
    "text" : "I\u2019m retweeting this so my next tweet will make sense.  https:\/\/t.co\/hk9AzZnCPm",
    "id" : 702530660305608704,
    "created_at" : "2016-02-24 16:28:56 +0000",
    "user" : {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "protected" : false,
      "id_str" : "17068546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2110881642\/LydiaTea_normal",
      "id" : 17068546,
      "verified" : false
    }
  },
  "id" : 702535785728315392,
  "created_at" : "2016-02-24 16:49:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sac88",
      "screen_name" : "sac88",
      "indices" : [ 3, 9 ],
      "id_str" : "16329237",
      "id" : 16329237
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sac88\/status\/702521229522022400\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/z5UCUeLYdN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_bUkvUEAAPoxK.jpg",
      "id_str" : "702521213399076864",
      "id" : 702521213399076864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_bUkvUEAAPoxK.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/z5UCUeLYdN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702535203668025344",
  "text" : "RT @sac88: Grackle showing off while taking a bath! https:\/\/t.co\/z5UCUeLYdN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sac88\/status\/702521229522022400\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/z5UCUeLYdN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_bUkvUEAAPoxK.jpg",
        "id_str" : "702521213399076864",
        "id" : 702521213399076864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_bUkvUEAAPoxK.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/z5UCUeLYdN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702521229522022400",
    "text" : "Grackle showing off while taking a bath! https:\/\/t.co\/z5UCUeLYdN",
    "id" : 702521229522022400,
    "created_at" : "2016-02-24 15:51:27 +0000",
    "user" : {
      "name" : "sac88",
      "screen_name" : "sac88",
      "protected" : false,
      "id_str" : "16329237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588703374054330370\/GFUNcyPz_normal.jpg",
      "id" : 16329237,
      "verified" : false
    }
  },
  "id" : 702535203668025344,
  "created_at" : "2016-02-24 16:46:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrimeFictionLover",
      "screen_name" : "CriFiLover",
      "indices" : [ 3, 14 ],
      "id_str" : "335928666",
      "id" : 335928666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702534109835501569",
  "text" : "RT @CriFiLover: What is your favourite regional variety when it comes to crime fiction?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702532925389193216",
    "text" : "What is your favourite regional variety when it comes to crime fiction?",
    "id" : 702532925389193216,
    "created_at" : "2016-02-24 16:37:56 +0000",
    "user" : {
      "name" : "CrimeFictionLover",
      "screen_name" : "CriFiLover",
      "protected" : false,
      "id_str" : "335928666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1459831052\/cfl_logo_courier_normal.jpg",
      "id" : 335928666,
      "verified" : false
    }
  },
  "id" : 702534109835501569,
  "created_at" : "2016-02-24 16:42:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deadpool",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Gw9xx0rUVp",
      "expanded_url" : "https:\/\/twitter.com\/MarkLaViolette\/status\/702418620496871424",
      "display_url" : "twitter.com\/MarkLaViolette\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702529862163161088",
  "text" : "huh.. audio sample was kinda funny... (usu not my thing) #deadpool #audiobook https:\/\/t.co\/Gw9xx0rUVp",
  "id" : 702529862163161088,
  "created_at" : "2016-02-24 16:25:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Vicino",
      "screen_name" : "AnthonyVicino",
      "indices" : [ 3, 17 ],
      "id_str" : "1001012042",
      "id" : 1001012042
    }, {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 52, 65 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702523801532243971",
  "text" : "RT @AnthonyVicino: Looking for your next adventure? @AudioBookRev is giving away copies of the Time Heist audiobook! Go sign up today!\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audiobook Reviewer",
        "screen_name" : "AudioBookRev",
        "indices" : [ 33, 46 ],
        "id_str" : "457997266",
        "id" : 457997266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/HfXFXl3ecF",
        "expanded_url" : "http:\/\/audiobookreviewer.com\/reviews\/time-heist-firstborn-saga-book-1-by-anthony-vicino\/",
        "display_url" : "audiobookreviewer.com\/reviews\/time-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702502651167055872",
    "text" : "Looking for your next adventure? @AudioBookRev is giving away copies of the Time Heist audiobook! Go sign up today!\nhttps:\/\/t.co\/HfXFXl3ecF",
    "id" : 702502651167055872,
    "created_at" : "2016-02-24 14:37:38 +0000",
    "user" : {
      "name" : "Anthony Vicino",
      "screen_name" : "AnthonyVicino",
      "protected" : false,
      "id_str" : "1001012042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637652004010004484\/8_YtwmVB_normal.jpg",
      "id" : 1001012042,
      "verified" : false
    }
  },
  "id" : 702523801532243971,
  "created_at" : "2016-02-24 16:01:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hillary",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "Bernie",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702522189417807872",
  "text" : "RT @SangyeH: I've seen both #Hillary &amp; #Bernie supporters labeling the other. That dehumanizes people, making it easier to justify hating t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hillary",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "Bernie",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702357314364272640",
    "text" : "I've seen both #Hillary &amp; #Bernie supporters labeling the other. That dehumanizes people, making it easier to justify hating them",
    "id" : 702357314364272640,
    "created_at" : "2016-02-24 05:00:07 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 702522189417807872,
  "created_at" : "2016-02-24 15:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Carlin",
      "screen_name" : "kelly_carlin",
      "indices" : [ 3, 16 ],
      "id_str" : "17736232",
      "id" : 17736232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702521669945069568",
  "text" : "RT @kelly_carlin: Dear Aliens,\n\nNow would be a good time.\n\nSigned, \nEarth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702391394720194560",
    "text" : "Dear Aliens,\n\nNow would be a good time.\n\nSigned, \nEarth",
    "id" : 702391394720194560,
    "created_at" : "2016-02-24 07:15:32 +0000",
    "user" : {
      "name" : "Kelly Carlin",
      "screen_name" : "kelly_carlin",
      "protected" : false,
      "id_str" : "17736232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740277342119985152\/oGLJmxOl_normal.jpg",
      "id" : 17736232,
      "verified" : false
    }
  },
  "id" : 702521669945069568,
  "created_at" : "2016-02-24 15:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Robinson",
      "screen_name" : "BigDaddyThug",
      "indices" : [ 3, 16 ],
      "id_str" : "244201813",
      "id" : 244201813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702521489917124609",
  "text" : "RT @BigDaddyThug: Psst. You.\n\nI don't know what's ahead of you today, what you have to do, or what you're struggling with.\n\nBut you know wh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702468072372830208",
    "text" : "Psst. You.\n\nI don't know what's ahead of you today, what you have to do, or what you're struggling with.\n\nBut you know what?\n\nYou got this.",
    "id" : 702468072372830208,
    "created_at" : "2016-02-24 12:20:14 +0000",
    "user" : {
      "name" : "Todd Robinson",
      "screen_name" : "BigDaddyThug",
      "protected" : false,
      "id_str" : "244201813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797978440066547712\/0e9lefwM_normal.jpg",
      "id" : 244201813,
      "verified" : false
    }
  },
  "id" : 702521489917124609,
  "created_at" : "2016-02-24 15:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "indices" : [ 3, 19 ],
      "id_str" : "30364057",
      "id" : 30364057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/mE4VzAjZi6",
      "expanded_url" : "https:\/\/twitter.com\/thinkprogress\/status\/702177375702810625",
      "display_url" : "twitter.com\/thinkprogress\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702520148197023744",
  "text" : "RT @SarahKSilverman: This person is great, https:\/\/t.co\/mE4VzAjZi6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/mE4VzAjZi6",
        "expanded_url" : "https:\/\/twitter.com\/thinkprogress\/status\/702177375702810625",
        "display_url" : "twitter.com\/thinkprogress\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702182375669702656",
    "text" : "This person is great, https:\/\/t.co\/mE4VzAjZi6",
    "id" : 702182375669702656,
    "created_at" : "2016-02-23 17:24:58 +0000",
    "user" : {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "protected" : false,
      "id_str" : "30364057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533405266658615296\/ULwCXwFs_normal.jpeg",
      "id" : 30364057,
      "verified" : true
    }
  },
  "id" : 702520148197023744,
  "created_at" : "2016-02-24 15:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kara Bren",
      "screen_name" : "Kara_L_Bren",
      "indices" : [ 3, 15 ],
      "id_str" : "16057592",
      "id" : 16057592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OldTymeChem",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702289111940521985",
  "text" : "RT @Kara_L_Bren: \"Electron maps\" in my grandmother's high school chemistry workbook \/ lab notebook, Silver Lake MN, 1933 #OldTymeChem https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kara_L_Bren\/status\/702161583947038720\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/zLyyENGJnR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb6UPTsWIAIIkjG.jpg",
        "id_str" : "702161582621597698",
        "id" : 702161582621597698,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb6UPTsWIAIIkjG.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        } ],
        "display_url" : "pic.twitter.com\/zLyyENGJnR"
      } ],
      "hashtags" : [ {
        "text" : "OldTymeChem",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702161583947038720",
    "text" : "\"Electron maps\" in my grandmother's high school chemistry workbook \/ lab notebook, Silver Lake MN, 1933 #OldTymeChem https:\/\/t.co\/zLyyENGJnR",
    "id" : 702161583947038720,
    "created_at" : "2016-02-23 16:02:21 +0000",
    "user" : {
      "name" : "Kara Bren",
      "screen_name" : "Kara_L_Bren",
      "protected" : false,
      "id_str" : "16057592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550710999766953986\/8MktLJj3_normal.jpeg",
      "id" : 16057592,
      "verified" : false
    }
  },
  "id" : 702289111940521985,
  "created_at" : "2016-02-24 00:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702287326085582849",
  "text" : "my jaw joint hurts.. even after i used massager on it. ((whine)) and it still makes crunchy noise.",
  "id" : 702287326085582849,
  "created_at" : "2016-02-24 00:22:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ian ballam",
      "screen_name" : "ianballam",
      "indices" : [ 3, 13 ],
      "id_str" : "356749785",
      "id" : 356749785
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ianballam\/status\/702213741430050816\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Xd4Ti9y8oh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7DqwhW0AAkfaS.jpg",
      "id_str" : "702213731263107072",
      "id" : 702213731263107072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7DqwhW0AAkfaS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Xd4Ti9y8oh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ianballam\/status\/702213741430050816\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Xd4Ti9y8oh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7DrRcW4AEkVT_.jpg",
      "id_str" : "702213740100509697",
      "id" : 702213740100509697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7DrRcW4AEkVT_.jpg",
      "sizes" : [ {
        "h" : 571,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 714
      } ],
      "display_url" : "pic.twitter.com\/Xd4Ti9y8oh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ianballam\/status\/702213741430050816\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Xd4Ti9y8oh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7DrMxW8AE9qRJ.jpg",
      "id_str" : "702213738846416897",
      "id" : 702213738846416897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7DrMxW8AE9qRJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 664
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 664
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 664
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 664
      } ],
      "display_url" : "pic.twitter.com\/Xd4Ti9y8oh"
    } ],
    "hashtags" : [ {
      "text" : "LytchettFields",
      "indices" : [ 62, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702263075852967936",
  "text" : "RT @ianballam: Long-tailed Tit collecting nesting material at #LytchettFields https:\/\/t.co\/Xd4Ti9y8oh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ianballam\/status\/702213741430050816\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/Xd4Ti9y8oh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7DqwhW0AAkfaS.jpg",
        "id_str" : "702213731263107072",
        "id" : 702213731263107072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7DqwhW0AAkfaS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 831
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 831
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 831
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Xd4Ti9y8oh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ianballam\/status\/702213741430050816\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/Xd4Ti9y8oh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7DrRcW4AEkVT_.jpg",
        "id_str" : "702213740100509697",
        "id" : 702213740100509697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7DrRcW4AEkVT_.jpg",
        "sizes" : [ {
          "h" : 571,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 714
        } ],
        "display_url" : "pic.twitter.com\/Xd4Ti9y8oh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ianballam\/status\/702213741430050816\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/Xd4Ti9y8oh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7DrMxW8AE9qRJ.jpg",
        "id_str" : "702213738846416897",
        "id" : 702213738846416897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7DrMxW8AE9qRJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 664
        } ],
        "display_url" : "pic.twitter.com\/Xd4Ti9y8oh"
      } ],
      "hashtags" : [ {
        "text" : "LytchettFields",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702213741430050816",
    "text" : "Long-tailed Tit collecting nesting material at #LytchettFields https:\/\/t.co\/Xd4Ti9y8oh",
    "id" : 702213741430050816,
    "created_at" : "2016-02-23 19:29:37 +0000",
    "user" : {
      "name" : "ian ballam",
      "screen_name" : "ianballam",
      "protected" : false,
      "id_str" : "356749785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572665654004559872\/HOpphSoc_normal.jpeg",
      "id" : 356749785,
      "verified" : false
    }
  },
  "id" : 702263075852967936,
  "created_at" : "2016-02-23 22:45:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/702249417428971520\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ew9GEr63no",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7kH3qW8AA4iIJ.jpg",
      "id_str" : "702249415768207360",
      "id" : 702249415768207360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7kH3qW8AA4iIJ.jpg",
      "sizes" : [ {
        "h" : 586,
        "resize" : "fit",
        "w" : 811
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 811
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 811
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ew9GEr63no"
    } ],
    "hashtags" : [ {
      "text" : "Sunset",
      "indices" : [ 44, 51 ]
    }, {
      "text" : "Middlewich",
      "indices" : [ 52, 63 ]
    }, {
      "text" : "Cheshire",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "sunlight",
      "indices" : [ 74, 83 ]
    }, {
      "text" : "glow",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "warmth",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "cycling",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702250495814057984",
  "text" : "RT @Swanwhisperer: Upon the Fields are Gold #Sunset #Middlewich #Cheshire #sunlight #glow #warmth #cycling https:\/\/t.co\/ew9GEr63no",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/702249417428971520\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ew9GEr63no",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb7kH3qW8AA4iIJ.jpg",
        "id_str" : "702249415768207360",
        "id" : 702249415768207360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb7kH3qW8AA4iIJ.jpg",
        "sizes" : [ {
          "h" : 586,
          "resize" : "fit",
          "w" : 811
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 811
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 811
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ew9GEr63no"
      } ],
      "hashtags" : [ {
        "text" : "Sunset",
        "indices" : [ 25, 32 ]
      }, {
        "text" : "Middlewich",
        "indices" : [ 33, 44 ]
      }, {
        "text" : "Cheshire",
        "indices" : [ 45, 54 ]
      }, {
        "text" : "sunlight",
        "indices" : [ 55, 64 ]
      }, {
        "text" : "glow",
        "indices" : [ 65, 70 ]
      }, {
        "text" : "warmth",
        "indices" : [ 71, 78 ]
      }, {
        "text" : "cycling",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702249417428971520",
    "text" : "Upon the Fields are Gold #Sunset #Middlewich #Cheshire #sunlight #glow #warmth #cycling https:\/\/t.co\/ew9GEr63no",
    "id" : 702249417428971520,
    "created_at" : "2016-02-23 21:51:22 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 702250495814057984,
  "created_at" : "2016-02-23 21:55:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Beverly",
      "screen_name" : "jaredbeverly",
      "indices" : [ 3, 16 ],
      "id_str" : "20893330",
      "id" : 20893330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/aIu87AkTBn",
      "expanded_url" : "https:\/\/twitter.com\/NautilusMag\/status\/702040283966386176",
      "display_url" : "twitter.com\/NautilusMag\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702237024833691648",
  "text" : "RT @jaredbeverly: Because the gay agenda is winning. https:\/\/t.co\/aIu87AkTBn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/aIu87AkTBn",
        "expanded_url" : "https:\/\/twitter.com\/NautilusMag\/status\/702040283966386176",
        "display_url" : "twitter.com\/NautilusMag\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702231056452337665",
    "text" : "Because the gay agenda is winning. https:\/\/t.co\/aIu87AkTBn",
    "id" : 702231056452337665,
    "created_at" : "2016-02-23 20:38:25 +0000",
    "user" : {
      "name" : "Jared Beverly",
      "screen_name" : "jaredbeverly",
      "protected" : false,
      "id_str" : "20893330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614460342588956672\/hfK9Rr1Q_normal.jpg",
      "id" : 20893330,
      "verified" : false
    }
  },
  "id" : 702237024833691648,
  "created_at" : "2016-02-23 21:02:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan McWilliams",
      "screen_name" : "SusnMcWilliams",
      "indices" : [ 3, 18 ],
      "id_str" : "316759888",
      "id" : 316759888
    }, {
      "name" : "Emily Arnim",
      "screen_name" : "EmilyArnim",
      "indices" : [ 97, 108 ],
      "id_str" : "328794540",
      "id" : 328794540
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SusnMcWilliams\/status\/682250845547696128\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/jsCJ6BHrPo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfXhnEU0AA55s9.jpg",
      "id_str" : "682250840992698368",
      "id" : 682250840992698368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfXhnEU0AA55s9.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jsCJ6BHrPo"
    } ],
    "hashtags" : [ {
      "text" : "pushThoseBoundries",
      "indices" : [ 20, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702234224636665856",
  "text" : "RT @SusnMcWilliams: #pushThoseBoundries how else r u supposed to create a better world ...credit @EmilyArnim https:\/\/t.co\/jsCJ6BHrPo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emily Arnim",
        "screen_name" : "EmilyArnim",
        "indices" : [ 77, 88 ],
        "id_str" : "328794540",
        "id" : 328794540
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SusnMcWilliams\/status\/682250845547696128\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/jsCJ6BHrPo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfXhnEU0AA55s9.jpg",
        "id_str" : "682250840992698368",
        "id" : 682250840992698368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfXhnEU0AA55s9.jpg",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jsCJ6BHrPo"
      } ],
      "hashtags" : [ {
        "text" : "pushThoseBoundries",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682250845547696128",
    "text" : "#pushThoseBoundries how else r u supposed to create a better world ...credit @EmilyArnim https:\/\/t.co\/jsCJ6BHrPo",
    "id" : 682250845547696128,
    "created_at" : "2015-12-30 17:24:11 +0000",
    "user" : {
      "name" : "Susan McWilliams",
      "screen_name" : "SusnMcWilliams",
      "protected" : false,
      "id_str" : "316759888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544216622454824960\/isj-6yIP_normal.jpeg",
      "id" : 316759888,
      "verified" : false
    }
  },
  "id" : 702234224636665856,
  "created_at" : "2016-02-23 20:51:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702218014754807814",
  "text" : "as a kid, i always thought i was a mistake.. somehow slipped through some vortex.",
  "id" : 702218014754807814,
  "created_at" : "2016-02-23 19:46:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702217444807598080",
  "text" : "i had great rage as a child for not being able to integrate. it spills out sometimes. i dont know how to be angry w\/out rage. sigh.",
  "id" : 702217444807598080,
  "created_at" : "2016-02-23 19:44:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702215893179375616",
  "text" : "i never belonged. ive always been an outsider. ive always been alone. me and my thoughts. i suppose thats why i see things differently.",
  "id" : 702215893179375616,
  "created_at" : "2016-02-23 19:38:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702215210128510976",
  "text" : "we dont like the tugging of thoughts and emotions. its uncomfortable.. so uncomfortable.",
  "id" : 702215210128510976,
  "created_at" : "2016-02-23 19:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702213969688264704",
  "text" : "hillary\/bernie; science\/religion; patriotic\/anti-war; christian\/atheist; hunter\/vegan .. etc. we want validation, security.",
  "id" : 702213969688264704,
  "created_at" : "2016-02-23 19:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702212874874331137",
  "text" : "hmm.. I can see why ppl cling to ideas.. we want to be part of.. so we become more of.. to find safety within the group.",
  "id" : 702212874874331137,
  "created_at" : "2016-02-23 19:26:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeepakChopra\/status\/702191202842517504\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/vFc90xMxOn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb6vLYGUUAEJF7o.jpg",
      "id_str" : "702191201898745857",
      "id" : 702191201898745857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb6vLYGUUAEJF7o.jpg",
      "sizes" : [ {
        "h" : 497,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/vFc90xMxOn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/u7BdcrH2Yv",
      "expanded_url" : "http:\/\/j.mp\/1XCjUhc",
      "display_url" : "j.mp\/1XCjUhc"
    } ]
  },
  "geo" : { },
  "id_str" : "702193333372903428",
  "text" : "RT @DeepakChopra: Where Is the Tipping Point for Consciousness? https:\/\/t.co\/u7BdcrH2Yv https:\/\/t.co\/vFc90xMxOn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.deepakchopra.com\" rel=\"nofollow\"\u003EDeepak Chopra\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeepakChopra\/status\/702191202842517504\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/vFc90xMxOn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb6vLYGUUAEJF7o.jpg",
        "id_str" : "702191201898745857",
        "id" : 702191201898745857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb6vLYGUUAEJF7o.jpg",
        "sizes" : [ {
          "h" : 497,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/vFc90xMxOn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/u7BdcrH2Yv",
        "expanded_url" : "http:\/\/j.mp\/1XCjUhc",
        "display_url" : "j.mp\/1XCjUhc"
      } ]
    },
    "geo" : { },
    "id_str" : "702191202842517504",
    "text" : "Where Is the Tipping Point for Consciousness? https:\/\/t.co\/u7BdcrH2Yv https:\/\/t.co\/vFc90xMxOn",
    "id" : 702191202842517504,
    "created_at" : "2016-02-23 18:00:03 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 702193333372903428,
  "created_at" : "2016-02-23 18:08:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Bales",
      "screen_name" : "TomBales1",
      "indices" : [ 3, 13 ],
      "id_str" : "307677859",
      "id" : 307677859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702192187652571136",
  "text" : "RT @TomBales1: If people become multimillionaires doing \"public service\" they haven't been serving the public. We don't pay them that much.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701796978091425797",
    "text" : "If people become multimillionaires doing \"public service\" they haven't been serving the public. We don't pay them that much.",
    "id" : 701796978091425797,
    "created_at" : "2016-02-22 15:53:32 +0000",
    "user" : {
      "name" : "Tom Bales",
      "screen_name" : "TomBales1",
      "protected" : false,
      "id_str" : "307677859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576801926840328192\/QFBJntLd_normal.jpeg",
      "id" : 307677859,
      "verified" : false
    }
  },
  "id" : 702192187652571136,
  "created_at" : "2016-02-23 18:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702191882835775488",
  "text" : "jeezus.. christians posting memes about bernie.. gah!!",
  "id" : 702191882835775488,
  "created_at" : "2016-02-23 18:02:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "sunrise",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702191348837957633",
  "text" : "RT @AWrobley: I pass this tree each time I go to class...kept thinking I want to take its photo...so I did. #Arizona #sunrise https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/702190303004917761\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/ITkblqap0I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb6uXBPUYAAyVNZ.jpg",
        "id_str" : "702190302409285632",
        "id" : 702190302409285632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb6uXBPUYAAyVNZ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1620,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1620,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ITkblqap0I"
      } ],
      "hashtags" : [ {
        "text" : "Arizona",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "sunrise",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702190303004917761",
    "text" : "I pass this tree each time I go to class...kept thinking I want to take its photo...so I did. #Arizona #sunrise https:\/\/t.co\/ITkblqap0I",
    "id" : 702190303004917761,
    "created_at" : "2016-02-23 17:56:28 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 702191348837957633,
  "created_at" : "2016-02-23 18:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tobyfox",
      "screen_name" : "tobyfox",
      "indices" : [ 3, 11 ],
      "id_str" : "39157744",
      "id" : 39157744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702188503631798272",
  "text" : "RT @tobyfox: Clarify \"Other\" of previous poll.\n\nHow did you find \"UNDERTALE.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701432957899300864",
    "text" : "Clarify \"Other\" of previous poll.\n\nHow did you find \"UNDERTALE.\"",
    "id" : 701432957899300864,
    "created_at" : "2016-02-21 15:47:03 +0000",
    "user" : {
      "name" : "tobyfox",
      "screen_name" : "tobyfox",
      "protected" : false,
      "id_str" : "39157744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785864955811725312\/cZDBbU2x_normal.jpg",
      "id" : 39157744,
      "verified" : false
    }
  },
  "id" : 702188503631798272,
  "created_at" : "2016-02-23 17:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat~Mow",
      "screen_name" : "KKMschan",
      "indices" : [ 3, 12 ],
      "id_str" : "188533731",
      "id" : 188533731
    }, {
      "name" : "ThisisVT.",
      "screen_name" : "THISISVT",
      "indices" : [ 14, 23 ],
      "id_str" : "627356719",
      "id" : 627356719
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KKMschan\/status\/702175679102775300\/video\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/EdLAxyI3o0",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702175624723566592\/pu\/img\/eOkhEHgiEMdgE-ur.jpg",
      "id_str" : "702175624723566592",
      "id" : 702175624723566592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702175624723566592\/pu\/img\/eOkhEHgiEMdgE-ur.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EdLAxyI3o0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702188213671174144",
  "text" : "RT @KKMschan: @THISISVT Lake Champlain Burlington VT https:\/\/t.co\/EdLAxyI3o0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThisisVT.",
        "screen_name" : "THISISVT",
        "indices" : [ 0, 9 ],
        "id_str" : "627356719",
        "id" : 627356719
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KKMschan\/status\/702175679102775300\/video\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/EdLAxyI3o0",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702175624723566592\/pu\/img\/eOkhEHgiEMdgE-ur.jpg",
        "id_str" : "702175624723566592",
        "id" : 702175624723566592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702175624723566592\/pu\/img\/eOkhEHgiEMdgE-ur.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/EdLAxyI3o0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702175679102775300",
    "in_reply_to_user_id" : 627356719,
    "text" : "@THISISVT Lake Champlain Burlington VT https:\/\/t.co\/EdLAxyI3o0",
    "id" : 702175679102775300,
    "created_at" : "2016-02-23 16:58:22 +0000",
    "in_reply_to_screen_name" : "THISISVT",
    "in_reply_to_user_id_str" : "627356719",
    "user" : {
      "name" : "Kat~Mow",
      "screen_name" : "KKMschan",
      "protected" : false,
      "id_str" : "188533731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759570375890104324\/RPOxXfiN_normal.jpg",
      "id" : 188533731,
      "verified" : false
    }
  },
  "id" : 702188213671174144,
  "created_at" : "2016-02-23 17:48:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gillies jones",
      "screen_name" : "gilliesjones",
      "indices" : [ 3, 16 ],
      "id_str" : "195735940",
      "id" : 195735940
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gilliesjones\/status\/702166861643915264\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/y4J8JXB7yO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb6ZCFzW8AE5zR_.jpg",
      "id_str" : "702166853112754177",
      "id" : 702166853112754177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb6ZCFzW8AE5zR_.jpg",
      "sizes" : [ {
        "h" : 555,
        "resize" : "fit",
        "w" : 573
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 573
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 573
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 573
      } ],
      "display_url" : "pic.twitter.com\/y4J8JXB7yO"
    } ],
    "hashtags" : [ {
      "text" : "wildDaffodil",
      "indices" : [ 61, 74 ]
    }, {
      "text" : "springtime",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702188037623717888",
  "text" : "RT @gilliesjones: Final stages of design prototyping for new #wildDaffodil limited edition bowl. #springtime https:\/\/t.co\/y4J8JXB7yO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gilliesjones\/status\/702166861643915264\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/y4J8JXB7yO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb6ZCFzW8AE5zR_.jpg",
        "id_str" : "702166853112754177",
        "id" : 702166853112754177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb6ZCFzW8AE5zR_.jpg",
        "sizes" : [ {
          "h" : 555,
          "resize" : "fit",
          "w" : 573
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 573
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 573
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 573
        } ],
        "display_url" : "pic.twitter.com\/y4J8JXB7yO"
      } ],
      "hashtags" : [ {
        "text" : "wildDaffodil",
        "indices" : [ 43, 56 ]
      }, {
        "text" : "springtime",
        "indices" : [ 79, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702166861643915264",
    "text" : "Final stages of design prototyping for new #wildDaffodil limited edition bowl. #springtime https:\/\/t.co\/y4J8JXB7yO",
    "id" : 702166861643915264,
    "created_at" : "2016-02-23 16:23:20 +0000",
    "user" : {
      "name" : "gillies jones",
      "screen_name" : "gilliesjones",
      "protected" : false,
      "id_str" : "195735940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592644087423049728\/9THN6zCj_normal.jpg",
      "id" : 195735940,
      "verified" : false
    }
  },
  "id" : 702188037623717888,
  "created_at" : "2016-02-23 17:47:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "near_rhymes",
      "screen_name" : "near_rhymes",
      "indices" : [ 3, 15 ],
      "id_str" : "238117103",
      "id" : 238117103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702163701974102017",
  "text" : "RT @near_rhymes: everyday celebrate your escape from insanity, depravity, and death",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702152229885763584",
    "text" : "everyday celebrate your escape from insanity, depravity, and death",
    "id" : 702152229885763584,
    "created_at" : "2016-02-23 15:25:11 +0000",
    "user" : {
      "name" : "near_rhymes",
      "screen_name" : "near_rhymes",
      "protected" : false,
      "id_str" : "238117103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797273268382265344\/QWKtA-FW_normal.jpg",
      "id" : 238117103,
      "verified" : false
    }
  },
  "id" : 702163701974102017,
  "created_at" : "2016-02-23 16:10:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/2X43zXTFLv",
      "expanded_url" : "https:\/\/twitter.com\/_carlosoviedo\/status\/702156750229790720",
      "display_url" : "twitter.com\/_carlosoviedo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702163307914993664",
  "text" : "ohh.. this was in \"fear the sky\" #audiobook I just finished. https:\/\/t.co\/2X43zXTFLv",
  "id" : 702163307914993664,
  "created_at" : "2016-02-23 16:09:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    }, {
      "name" : "Pastor Mark Driscoll",
      "screen_name" : "PastorMark",
      "indices" : [ 16, 27 ],
      "id_str" : "4276531",
      "id" : 4276531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702146523996487680",
  "text" : "RT @jorymicah: .@PastorMark up to his old shenanigans: preaching men are to be \"head\" w\/o addressing the truth of what \"head\" means https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pastor Mark Driscoll",
        "screen_name" : "PastorMark",
        "indices" : [ 1, 12 ],
        "id_str" : "4276531",
        "id" : 4276531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/OhOfTtaprL",
        "expanded_url" : "http:\/\/www.gracecitychurch.com\/sermon\/becoming-a-godly-man\/",
        "display_url" : "gracecitychurch.com\/sermon\/becomin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702142443244785664",
    "text" : ".@PastorMark up to his old shenanigans: preaching men are to be \"head\" w\/o addressing the truth of what \"head\" means https:\/\/t.co\/OhOfTtaprL",
    "id" : 702142443244785664,
    "created_at" : "2016-02-23 14:46:18 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 702146523996487680,
  "created_at" : "2016-02-23 15:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lin-Manuel Miranda",
      "screen_name" : "Lin_Manuel",
      "indices" : [ 3, 14 ],
      "id_str" : "79923701",
      "id" : 79923701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuyABook",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/MoAdUAf9jE",
      "expanded_url" : "https:\/\/twitter.com\/pix11news\/status\/701917001980235777",
      "display_url" : "twitter.com\/pix11news\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702146503540924417",
  "text" : "RT @Lin_Manuel: Very sweet, but I'm happy to pay for 'em now that I'm in a position to afford 'em! #BuyABook  https:\/\/t.co\/MoAdUAf9jE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuyABook",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/MoAdUAf9jE",
        "expanded_url" : "https:\/\/twitter.com\/pix11news\/status\/701917001980235777",
        "display_url" : "twitter.com\/pix11news\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701978992899964928",
    "text" : "Very sweet, but I'm happy to pay for 'em now that I'm in a position to afford 'em! #BuyABook  https:\/\/t.co\/MoAdUAf9jE",
    "id" : 701978992899964928,
    "created_at" : "2016-02-23 03:56:48 +0000",
    "user" : {
      "name" : "Lin-Manuel Miranda",
      "screen_name" : "Lin_Manuel",
      "protected" : false,
      "id_str" : "79923701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794222903734759425\/3_7J2Od1_normal.jpg",
      "id" : 79923701,
      "verified" : true
    }
  },
  "id" : 702146503540924417,
  "created_at" : "2016-02-23 15:02:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702135391814606848",
  "text" : "I earned the original level of the Mount Everest badge - I just spent 20 hours listening to an audiobook. And it was awesome.",
  "id" : 702135391814606848,
  "created_at" : "2016-02-23 14:18:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702133875561127937",
  "text" : "I finished listening to Fear the Sky: The Fear Saga, Book 1 (Unabridged) by Stephen Moss, narrated by R.C. Bray on my Audible app.",
  "id" : 702133875561127937,
  "created_at" : "2016-02-23 14:12:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701936818799783937",
  "geo" : { },
  "id_str" : "701940987275436033",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time good for you. not worth it to raise your bp and make yourself miserable.",
  "id" : 701940987275436033,
  "in_reply_to_status_id" : 701936818799783937,
  "created_at" : "2016-02-23 01:25:47 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701925247151423493",
  "text" : "RT @benjamincorey: Please, Christian Parents: Don't Try To Break Your Child's Will (They're Going To Need It In Life): https:\/\/t.co\/tubjsyX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/tubjsyXBil",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/dear-christian-parent-please-dont-try-to-break-their-will\/",
        "display_url" : "patheos.com\/blogs\/formerly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701829439080894464",
    "text" : "Please, Christian Parents: Don't Try To Break Your Child's Will (They're Going To Need It In Life): https:\/\/t.co\/tubjsyXBil",
    "id" : 701829439080894464,
    "created_at" : "2016-02-22 18:02:32 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 701925247151423493,
  "created_at" : "2016-02-23 00:23:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible Support",
      "screen_name" : "audiblesupport",
      "indices" : [ 3, 18 ],
      "id_str" : "3247929645",
      "id" : 3247929645
    }, {
      "name" : "Audible Support",
      "screen_name" : "audiblesupport",
      "indices" : [ 32, 47 ],
      "id_str" : "3247929645",
      "id" : 3247929645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701855502045749249",
  "text" : "RT @audiblesupport: Introducing @audiblesupport, our dedicated handle for Audible Customer Care. Have a question? We're listening. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audible Support",
        "screen_name" : "audiblesupport",
        "indices" : [ 12, 27 ],
        "id_str" : "3247929645",
        "id" : 3247929645
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/audiblesupport\/status\/701828807242682368\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/9RstlKr8dZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb1llOAW4AAagZu.jpg",
        "id_str" : "701828807028826112",
        "id" : 701828807028826112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb1llOAW4AAagZu.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/9RstlKr8dZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701828807242682368",
    "text" : "Introducing @audiblesupport, our dedicated handle for Audible Customer Care. Have a question? We're listening. https:\/\/t.co\/9RstlKr8dZ",
    "id" : 701828807242682368,
    "created_at" : "2016-02-22 18:00:01 +0000",
    "user" : {
      "name" : "Audible Support",
      "screen_name" : "audiblesupport",
      "protected" : false,
      "id_str" : "3247929645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697855682129850369\/9GWRW4A2_normal.jpg",
      "id" : 3247929645,
      "verified" : true
    }
  },
  "id" : 701855502045749249,
  "created_at" : "2016-02-22 19:46:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701840591852797954",
  "geo" : { },
  "id_str" : "701855023333040131",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe yay!!",
  "id" : 701855023333040131,
  "in_reply_to_status_id" : 701840591852797954,
  "created_at" : "2016-02-22 19:44:12 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701854763231682560",
  "text" : "someone posted that weed is just as dangerous as alcohol when driving. im inclined no, not as bad. what say you, peeps?",
  "id" : 701854763231682560,
  "created_at" : "2016-02-22 19:43:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Bridge",
      "screen_name" : "tbridge",
      "indices" : [ 3, 11 ],
      "id_str" : "11011",
      "id" : 11011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701854131963695104",
  "text" : "RT @tbridge: Have we tried turning the country off and then back on again?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701211856023769090",
    "text" : "Have we tried turning the country off and then back on again?",
    "id" : 701211856023769090,
    "created_at" : "2016-02-21 01:08:29 +0000",
    "user" : {
      "name" : "Tom Bridge",
      "screen_name" : "tbridge",
      "protected" : false,
      "id_str" : "11011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566268263769059328\/JxyixHkJ_normal.jpeg",
      "id" : 11011,
      "verified" : false
    }
  },
  "id" : 701854131963695104,
  "created_at" : "2016-02-22 19:40:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "review",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "physics",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "audioplay",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/bG5wu74JyL",
      "expanded_url" : "https:\/\/youtu.be\/jbSWebAZRUs",
      "display_url" : "youtu.be\/jbSWebAZRUs"
    } ]
  },
  "geo" : { },
  "id_str" : "701842788174925824",
  "text" : "Copenhagan by LA Theatreworks https:\/\/t.co\/bG5wu74JyL #audiobooks #review #physics #audioplay",
  "id" : 701842788174925824,
  "created_at" : "2016-02-22 18:55:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701811933926653953",
  "geo" : { },
  "id_str" : "701837136622919680",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater wth? what a moron.",
  "id" : 701837136622919680,
  "in_reply_to_status_id" : 701811933926653953,
  "created_at" : "2016-02-22 18:33:07 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paste Magazine",
      "screen_name" : "PasteMagazine",
      "indices" : [ 3, 17 ],
      "id_str" : "6604072",
      "id" : 6604072
    }, {
      "name" : "Jesse Case",
      "screen_name" : "jessecase",
      "indices" : [ 20, 30 ],
      "id_str" : "24664313",
      "id" : 24664313
    }, {
      "name" : "Tess Barker",
      "screen_name" : "TesstifyBarker",
      "indices" : [ 70, 85 ],
      "id_str" : "35918992",
      "id" : 35918992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/L8pq18fY2a",
      "expanded_url" : "http:\/\/goo.gl\/RznYlM",
      "display_url" : "goo.gl\/RznYlM"
    } ]
  },
  "geo" : { },
  "id_str" : "701817594777640960",
  "text" : "RT @PasteMagazine: .@jessecase podcasts about his battle with cancer. @TesstifyBarker talks to him for Paste. https:\/\/t.co\/L8pq18fY2a https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pastemagazine.com\/\" rel=\"nofollow\"\u003EPaste\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Case",
        "screen_name" : "jessecase",
        "indices" : [ 1, 11 ],
        "id_str" : "24664313",
        "id" : 24664313
      }, {
        "name" : "Tess Barker",
        "screen_name" : "TesstifyBarker",
        "indices" : [ 51, 66 ],
        "id_str" : "35918992",
        "id" : 35918992
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PasteMagazine\/status\/701812889246511104\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/gkanT2YddC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb1XGrHVIAAPbOd.jpg",
        "id_str" : "701812889103966208",
        "id" : 701812889103966208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb1XGrHVIAAPbOd.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 633
        } ],
        "display_url" : "pic.twitter.com\/gkanT2YddC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/L8pq18fY2a",
        "expanded_url" : "http:\/\/goo.gl\/RznYlM",
        "display_url" : "goo.gl\/RznYlM"
      } ]
    },
    "geo" : { },
    "id_str" : "701812889246511104",
    "text" : ".@jessecase podcasts about his battle with cancer. @TesstifyBarker talks to him for Paste. https:\/\/t.co\/L8pq18fY2a https:\/\/t.co\/gkanT2YddC",
    "id" : 701812889246511104,
    "created_at" : "2016-02-22 16:56:46 +0000",
    "user" : {
      "name" : "Paste Magazine",
      "screen_name" : "PasteMagazine",
      "protected" : false,
      "id_str" : "6604072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438710163638190080\/rTFJabCs_normal.jpeg",
      "id" : 6604072,
      "verified" : true
    }
  },
  "id" : 701817594777640960,
  "created_at" : "2016-02-22 17:15:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 0, 13 ],
      "id_str" : "457997266",
      "id" : 457997266
    }, {
      "name" : "R.C. Bray",
      "screen_name" : "audbks",
      "indices" : [ 14, 21 ],
      "id_str" : "2293107631",
      "id" : 2293107631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701791632618729472",
  "geo" : { },
  "id_str" : "701809357873397765",
  "in_reply_to_user_id" : 457997266,
  "text" : "@AudioBookRev @audbks dont want to read..lol. almost done w bk 1. really enjoying it!",
  "id" : 701809357873397765,
  "in_reply_to_status_id" : 701791632618729472,
  "created_at" : "2016-02-22 16:42:44 +0000",
  "in_reply_to_screen_name" : "AudioBookRev",
  "in_reply_to_user_id_str" : "457997266",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701808196504182784",
  "text" : "DD: mom, a joke for you. me: groans. DD: when im naked in the bathroom, the shower gets turned on. me: groans.",
  "id" : 701808196504182784,
  "created_at" : "2016-02-22 16:38:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAccidentallyDrankDecaf",
      "indices" : [ 15, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701798869978497025",
  "text" : "RT @ZachsMind: #IAccidentallyDrankDecaf and I now want to know where politicians stand on making decaf illegal. No one should be subjected \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAccidentallyDrankDecaf",
        "indices" : [ 0, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701759413539835908",
    "text" : "#IAccidentallyDrankDecaf and I now want to know where politicians stand on making decaf illegal. No one should be subjected to this ever.",
    "id" : 701759413539835908,
    "created_at" : "2016-02-22 13:24:16 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 701798869978497025,
  "created_at" : "2016-02-22 16:01:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701782173473382400",
  "geo" : { },
  "id_str" : "701798222470246401",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ((hugs))",
  "id" : 701798222470246401,
  "in_reply_to_status_id" : 701782173473382400,
  "created_at" : "2016-02-22 15:58:29 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701797722953752576",
  "text" : "but its hard cuz im bored so i seek that which hits buttons.",
  "id" : 701797722953752576,
  "created_at" : "2016-02-22 15:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701797552157552640",
  "text" : "its going to take me a little bit to shift gears.",
  "id" : 701797552157552640,
  "created_at" : "2016-02-22 15:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701797413946839043",
  "text" : "its true.. what you focus on grows. thats why i lost my bliss. damn politics..lol. i started focusing on those who made me angry. #woo",
  "id" : 701797413946839043,
  "created_at" : "2016-02-22 15:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brown Saraah",
      "screen_name" : "Brown_Saraah",
      "indices" : [ 3, 16 ],
      "id_str" : "2302239423",
      "id" : 2302239423
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Brown_Saraah\/status\/701415228660002817\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/4r8YuqNmOH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbvtbSwWAAAkUsx.jpg",
      "id_str" : "701415220133101568",
      "id" : 701415220133101568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbvtbSwWAAAkUsx.jpg",
      "sizes" : [ {
        "h" : 868,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 868,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 868,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 587
      } ],
      "display_url" : "pic.twitter.com\/4r8YuqNmOH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701796950660804608",
  "text" : "RT @Brown_Saraah: I wish more people were this nice to English learners. https:\/\/t.co\/4r8YuqNmOH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Brown_Saraah\/status\/701415228660002817\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/4r8YuqNmOH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbvtbSwWAAAkUsx.jpg",
        "id_str" : "701415220133101568",
        "id" : 701415220133101568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbvtbSwWAAAkUsx.jpg",
        "sizes" : [ {
          "h" : 868,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 868,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 868,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 587
        } ],
        "display_url" : "pic.twitter.com\/4r8YuqNmOH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701415228660002817",
    "text" : "I wish more people were this nice to English learners. https:\/\/t.co\/4r8YuqNmOH",
    "id" : 701415228660002817,
    "created_at" : "2016-02-21 14:36:36 +0000",
    "user" : {
      "name" : "Brown Saraah",
      "screen_name" : "Brown_Saraah",
      "protected" : false,
      "id_str" : "2302239423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796577308136116224\/Kfgy65XX_normal.jpg",
      "id" : 2302239423,
      "verified" : false
    }
  },
  "id" : 701796950660804608,
  "created_at" : "2016-02-22 15:53:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "indices" : [ 3, 14 ],
      "id_str" : "2441608651",
      "id" : 2441608651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/701009095403245568\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/k6ybEJ9D3P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbp8DqIUYAAri30.jpg",
      "id_str" : "701009094300164096",
      "id" : 701009094300164096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbp8DqIUYAAri30.jpg",
      "sizes" : [ {
        "h" : 753,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1286,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2511,
        "resize" : "fit",
        "w" : 3999
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/k6ybEJ9D3P"
    } ],
    "hashtags" : [ {
      "text" : "sunset",
      "indices" : [ 16, 23 ]
    }, {
      "text" : "mountfuji",
      "indices" : [ 24, 34 ]
    }, {
      "text" : "riverside",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701793457539567617",
  "text" : "RT @mido3bitte: #sunset #mountfuji #riverside https:\/\/t.co\/k6ybEJ9D3P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/701009095403245568\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/k6ybEJ9D3P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbp8DqIUYAAri30.jpg",
        "id_str" : "701009094300164096",
        "id" : 701009094300164096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbp8DqIUYAAri30.jpg",
        "sizes" : [ {
          "h" : 753,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1286,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2511,
          "resize" : "fit",
          "w" : 3999
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/k6ybEJ9D3P"
      } ],
      "hashtags" : [ {
        "text" : "sunset",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "mountfuji",
        "indices" : [ 8, 18 ]
      }, {
        "text" : "riverside",
        "indices" : [ 19, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701009095403245568",
    "text" : "#sunset #mountfuji #riverside https:\/\/t.co\/k6ybEJ9D3P",
    "id" : 701009095403245568,
    "created_at" : "2016-02-20 11:42:47 +0000",
    "user" : {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "protected" : false,
      "id_str" : "2441608651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746727881498206208\/tfRux6Hm_normal.jpg",
      "id" : 2441608651,
      "verified" : false
    }
  },
  "id" : 701793457539567617,
  "created_at" : "2016-02-22 15:39:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Scott",
      "screen_name" : "matttockington",
      "indices" : [ 3, 18 ],
      "id_str" : "2710934836",
      "id" : 2710934836
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/matttockington\/status\/701083725875044354\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KmhEsEEQ1e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbq_7xvXIAEmT27.jpg",
      "id_str" : "701083725694705665",
      "id" : 701083725694705665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbq_7xvXIAEmT27.jpg",
      "sizes" : [ {
        "h" : 864,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 864,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/KmhEsEEQ1e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701793172872159232",
  "text" : "RT @matttockington: Mountain Hare in a white out from the Cairngorms today. https:\/\/t.co\/KmhEsEEQ1e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/matttockington\/status\/701083725875044354\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/KmhEsEEQ1e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbq_7xvXIAEmT27.jpg",
        "id_str" : "701083725694705665",
        "id" : 701083725694705665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbq_7xvXIAEmT27.jpg",
        "sizes" : [ {
          "h" : 864,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 864,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/KmhEsEEQ1e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701083725875044354",
    "text" : "Mountain Hare in a white out from the Cairngorms today. https:\/\/t.co\/KmhEsEEQ1e",
    "id" : 701083725875044354,
    "created_at" : "2016-02-20 16:39:20 +0000",
    "user" : {
      "name" : "Matt Scott",
      "screen_name" : "matttockington",
      "protected" : false,
      "id_str" : "2710934836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743097522781061120\/PgXnzqnT_normal.jpg",
      "id" : 2710934836,
      "verified" : false
    }
  },
  "id" : 701793172872159232,
  "created_at" : "2016-02-22 15:38:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/701157286560059392\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/fdaZFXYdUL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsC1EjWIAAhWl2.jpg",
      "id_str" : "701157277764558848",
      "id" : 701157277764558848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsC1EjWIAAhWl2.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/fdaZFXYdUL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701793085022457856",
  "text" : "RT @Nigelstewart76: A lovely Hare love spotting them \uD83D\uDC4D https:\/\/t.co\/fdaZFXYdUL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/701157286560059392\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/fdaZFXYdUL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsC1EjWIAAhWl2.jpg",
        "id_str" : "701157277764558848",
        "id" : 701157277764558848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsC1EjWIAAhWl2.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/fdaZFXYdUL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701157286560059392",
    "text" : "A lovely Hare love spotting them \uD83D\uDC4D https:\/\/t.co\/fdaZFXYdUL",
    "id" : 701157286560059392,
    "created_at" : "2016-02-20 21:31:38 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 701793085022457856,
  "created_at" : "2016-02-22 15:38:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Fiet",
      "screen_name" : "aprilfiet",
      "indices" : [ 3, 13 ],
      "id_str" : "74924807",
      "id" : 74924807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/aprilfiet\/status\/701573955367227396\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/biTM1rmwrB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbx9x0oUAAAPJ7Y.jpg",
      "id_str" : "701573936857743360",
      "id" : 701573936857743360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbx9x0oUAAAPJ7Y.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/biTM1rmwrB"
    } ],
    "hashtags" : [ {
      "text" : "crochet",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701574330359091202",
  "text" : "RT @aprilfiet: Getting my granny square on #crochet https:\/\/t.co\/biTM1rmwrB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aprilfiet\/status\/701573955367227396\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/biTM1rmwrB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbx9x0oUAAAPJ7Y.jpg",
        "id_str" : "701573936857743360",
        "id" : 701573936857743360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbx9x0oUAAAPJ7Y.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/biTM1rmwrB"
      } ],
      "hashtags" : [ {
        "text" : "crochet",
        "indices" : [ 28, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701573955367227396",
    "text" : "Getting my granny square on #crochet https:\/\/t.co\/biTM1rmwrB",
    "id" : 701573955367227396,
    "created_at" : "2016-02-22 01:07:20 +0000",
    "user" : {
      "name" : "April Fiet",
      "screen_name" : "aprilfiet",
      "protected" : false,
      "id_str" : "74924807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469457797642330113\/gDMwoMTY_normal.jpeg",
      "id" : 74924807,
      "verified" : false
    }
  },
  "id" : 701574330359091202,
  "created_at" : "2016-02-22 01:08:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701537063510929408",
  "text" : "RT @jorymicah: The deeper I dive into gender injustice in the Church, the darker it gets. Its way less about theology &amp; much more about pol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701535572108701700",
    "text" : "The deeper I dive into gender injustice in the Church, the darker it gets. Its way less about theology &amp; much more about politics and money.",
    "id" : 701535572108701700,
    "created_at" : "2016-02-21 22:34:48 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 701537063510929408,
  "created_at" : "2016-02-21 22:40:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichole (Nikki)",
      "screen_name" : "SkepticNikki",
      "indices" : [ 3, 16 ],
      "id_str" : "2235067650",
      "id" : 2235067650
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheism",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701527388396589058",
  "text" : "RT @SkepticNikki: If religion makes you happy, fine. \nJust don't try to control my body, government, or sex life with it.\n\n#atheism https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SkepticNikki\/status\/700133182662959107\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/m6KmEdtY0g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbdfambVAAA27uz.jpg",
        "id_str" : "700133177675808768",
        "id" : 700133177675808768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbdfambVAAA27uz.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/m6KmEdtY0g"
      } ],
      "hashtags" : [ {
        "text" : "atheism",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700133182662959107",
    "text" : "If religion makes you happy, fine. \nJust don't try to control my body, government, or sex life with it.\n\n#atheism https:\/\/t.co\/m6KmEdtY0g",
    "id" : 700133182662959107,
    "created_at" : "2016-02-18 01:42:13 +0000",
    "user" : {
      "name" : "Nichole (Nikki)",
      "screen_name" : "SkepticNikki",
      "protected" : false,
      "id_str" : "2235067650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796060254840582144\/Rhcny04Y_normal.jpg",
      "id" : 2235067650,
      "verified" : false
    }
  },
  "id" : 701527388396589058,
  "created_at" : "2016-02-21 22:02:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The City Monk",
      "screen_name" : "iamthecitymonk",
      "indices" : [ 3, 18 ],
      "id_str" : "2280012325",
      "id" : 2280012325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Love",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "kindness",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701500818030260224",
  "text" : "RT @iamthecitymonk: \u201C#Love is the absence of judgment.\" - Dalai Lama #kindness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Love",
        "indices" : [ 1, 6 ]
      }, {
        "text" : "kindness",
        "indices" : [ 49, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701489648472891392",
    "text" : "\u201C#Love is the absence of judgment.\" - Dalai Lama #kindness",
    "id" : 701489648472891392,
    "created_at" : "2016-02-21 19:32:19 +0000",
    "user" : {
      "name" : "The City Monk",
      "screen_name" : "iamthecitymonk",
      "protected" : false,
      "id_str" : "2280012325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526358494299951105\/beI0yN9E_normal.jpeg",
      "id" : 2280012325,
      "verified" : false
    }
  },
  "id" : 701500818030260224,
  "created_at" : "2016-02-21 20:16:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "indices" : [ 3, 12 ],
      "id_str" : "75372132",
      "id" : 75372132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/GfvSWpdNbj",
      "expanded_url" : "http:\/\/ow.ly\/Yon5E",
      "display_url" : "ow.ly\/Yon5E"
    } ]
  },
  "geo" : { },
  "id_str" : "701471844554162177",
  "text" : "RT @PRHAudio: A neuroscientist explains why we like to color: https:\/\/t.co\/GfvSWpdNbj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/GfvSWpdNbj",
        "expanded_url" : "http:\/\/ow.ly\/Yon5E",
        "display_url" : "ow.ly\/Yon5E"
      } ]
    },
    "geo" : { },
    "id_str" : "701464018893070336",
    "text" : "A neuroscientist explains why we like to color: https:\/\/t.co\/GfvSWpdNbj",
    "id" : 701464018893070336,
    "created_at" : "2016-02-21 17:50:29 +0000",
    "user" : {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "protected" : false,
      "id_str" : "75372132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606215515279753216\/KBzpETdK_normal.jpg",
      "id" : 75372132,
      "verified" : false
    }
  },
  "id" : 701471844554162177,
  "created_at" : "2016-02-21 18:21:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701467885076611073",
  "text" : "RT @ZachsMind: if you feel everything in life is a business transaction, then you fail at being an artist, a person, and.. yeah.  https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/eaXhLDMMST",
        "expanded_url" : "https:\/\/twitter.com\/ThatEricAlper\/status\/701459052379959299",
        "display_url" : "twitter.com\/ThatEricAlper\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701459265634983936",
    "text" : "if you feel everything in life is a business transaction, then you fail at being an artist, a person, and.. yeah.  https:\/\/t.co\/eaXhLDMMST",
    "id" : 701459265634983936,
    "created_at" : "2016-02-21 17:31:36 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 701467885076611073,
  "created_at" : "2016-02-21 18:05:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "politics",
      "indices" : [ 67, 76 ]
    }, {
      "text" : "WeAreOne",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701464516610146306",
  "text" : "aha moment.. each side fears their rights being taken away.. hmm.. #politics #WeAreOne",
  "id" : 701464516610146306,
  "created_at" : "2016-02-21 17:52:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Polad",
      "screen_name" : "RickPolad",
      "indices" : [ 3, 13 ],
      "id_str" : "1335002192",
      "id" : 1335002192
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RickPolad\/status\/701431585095155712\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/FtQ2rN9rw8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbv8NhUUkAAOruE.jpg",
      "id_str" : "701431476198346752",
      "id" : 701431476198346752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbv8NhUUkAAOruE.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/FtQ2rN9rw8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701432893923586048",
  "text" : "RT @RickPolad: Good day for software uploads! https:\/\/t.co\/FtQ2rN9rw8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RickPolad\/status\/701431585095155712\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/FtQ2rN9rw8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbv8NhUUkAAOruE.jpg",
        "id_str" : "701431476198346752",
        "id" : 701431476198346752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbv8NhUUkAAOruE.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/FtQ2rN9rw8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701431585095155712",
    "text" : "Good day for software uploads! https:\/\/t.co\/FtQ2rN9rw8",
    "id" : 701431585095155712,
    "created_at" : "2016-02-21 15:41:36 +0000",
    "user" : {
      "name" : "Rick Polad",
      "screen_name" : "RickPolad",
      "protected" : false,
      "id_str" : "1335002192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3551811210\/473eba0a73c55aefaf4818d7a2a4a756_normal.jpeg",
      "id" : 1335002192,
      "verified" : false
    }
  },
  "id" : 701432893923586048,
  "created_at" : "2016-02-21 15:46:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fearthesky",
      "indices" : [ 68, 79 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701432624162729984",
  "text" : "r.c. bray really has brought the characters alive in his narration. #fearthesky #audiobook",
  "id" : 701432624162729984,
  "created_at" : "2016-02-21 15:45:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701431917397340160",
  "text" : "i can see im going to have to get the other 2 books as well. im really enjoying \"fear the sky\" audiobook.",
  "id" : 701431917397340160,
  "created_at" : "2016-02-21 15:42:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701430672695672832",
  "text" : "I'm 78% through Fear the Sky (Unabridged) by Stephen Moss, narrated by R.C. Bray on my Audible app.",
  "id" : 701430672695672832,
  "created_at" : "2016-02-21 15:37:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/701423377265901576\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/y2nSOZUXWo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbv016wW8AE2NeO.jpg",
      "id_str" : "701423374128574465",
      "id" : 701423374128574465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbv016wW8AE2NeO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/y2nSOZUXWo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/zjvvy7W8z5",
      "expanded_url" : "http:\/\/johnpavlovitz.com\/2016\/02\/19\/the-arrogance-of-evangelism?_ts=1456067335",
      "display_url" : "johnpavlovitz.com\/2016\/02\/19\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701423377265901576",
  "text" : "The Arrogance of Evangelical Evangelism https:\/\/t.co\/zjvvy7W8z5 https:\/\/t.co\/y2nSOZUXWo",
  "id" : 701423377265901576,
  "created_at" : "2016-02-21 15:08:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    }, {
      "name" : "Casey Cagle",
      "screen_name" : "CaseyCagle",
      "indices" : [ 36, 47 ],
      "id_str" : "7116142",
      "id" : 7116142
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rjmedwed\/status\/701080728977678338\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/rdDcDiXWaH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbq9MBnWAAAMaVB.png",
      "id_str" : "701080706299068416",
      "id" : 701080706299068416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbq9MBnWAAAMaVB.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 487
      } ],
      "display_url" : "pic.twitter.com\/rdDcDiXWaH"
    } ],
    "hashtags" : [ {
      "text" : "gapol",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701216632631328770",
  "text" : "RT @rjmedwed: With one post Lt. Gov @CaseyCagle told all non-Christians they are not welcome in Georgia. #gapol https:\/\/t.co\/rdDcDiXWaH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Casey Cagle",
        "screen_name" : "CaseyCagle",
        "indices" : [ 22, 33 ],
        "id_str" : "7116142",
        "id" : 7116142
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rjmedwed\/status\/701080728977678338\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/rdDcDiXWaH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbq9MBnWAAAMaVB.png",
        "id_str" : "701080706299068416",
        "id" : 701080706299068416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbq9MBnWAAAMaVB.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 487
        } ],
        "display_url" : "pic.twitter.com\/rdDcDiXWaH"
      } ],
      "hashtags" : [ {
        "text" : "gapol",
        "indices" : [ 91, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701080728977678338",
    "text" : "With one post Lt. Gov @CaseyCagle told all non-Christians they are not welcome in Georgia. #gapol https:\/\/t.co\/rdDcDiXWaH",
    "id" : 701080728977678338,
    "created_at" : "2016-02-20 16:27:25 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 701216632631328770,
  "created_at" : "2016-02-21 01:27:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701216048620638208",
  "text" : "RT @JeremyCShipp: So what country are we all moving to?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701206767649189888",
    "text" : "So what country are we all moving to?",
    "id" : 701206767649189888,
    "created_at" : "2016-02-21 00:48:15 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 701216048620638208,
  "created_at" : "2016-02-21 01:25:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The City Monk",
      "screen_name" : "iamthecitymonk",
      "indices" : [ 3, 18 ],
      "id_str" : "2280012325",
      "id" : 2280012325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "peace",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701200831635451904",
  "text" : "RT @iamthecitymonk: \u201CMy religion is very simple. My religion is #kindness.\u201D - Dalai Lama #peace",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindness",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "peace",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701199246121422848",
    "text" : "\u201CMy religion is very simple. My religion is #kindness.\u201D - Dalai Lama #peace",
    "id" : 701199246121422848,
    "created_at" : "2016-02-21 00:18:22 +0000",
    "user" : {
      "name" : "The City Monk",
      "screen_name" : "iamthecitymonk",
      "protected" : false,
      "id_str" : "2280012325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526358494299951105\/beI0yN9E_normal.jpeg",
      "id" : 2280012325,
      "verified" : false
    }
  },
  "id" : 701200831635451904,
  "created_at" : "2016-02-21 00:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ZrEPgacITV",
      "expanded_url" : "https:\/\/youtu.be\/Adgx9wt63NY",
      "display_url" : "youtu.be\/Adgx9wt63NY"
    } ]
  },
  "geo" : { },
  "id_str" : "701198892990332928",
  "text" : "the roof, the roof, the roof is on fire.. Bloodhound Gang - Fire Water Burn https:\/\/t.co\/ZrEPgacITV",
  "id" : 701198892990332928,
  "created_at" : "2016-02-21 00:16:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701097325389815810",
  "text" : "RT @ErinEFarley: Everyone has an old, well organized, tabbed binder full of plans for their Everquest characters, right? https:\/\/t.co\/pDVT2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/701096769275334656\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/pDVT2fJDlQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbrLw8XUUAAW7PT.jpg",
        "id_str" : "701096733707620352",
        "id" : 701096733707620352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbrLw8XUUAAW7PT.jpg",
        "sizes" : [ {
          "h" : 1604,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1604,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 940,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/pDVT2fJDlQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701096769275334656",
    "text" : "Everyone has an old, well organized, tabbed binder full of plans for their Everquest characters, right? https:\/\/t.co\/pDVT2fJDlQ",
    "id" : 701096769275334656,
    "created_at" : "2016-02-20 17:31:10 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 701097325389815810,
  "created_at" : "2016-02-20 17:33:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "Athyvaya \uD83C\uDF51",
      "screen_name" : "athyvaya",
      "indices" : [ 11, 20 ],
      "id_str" : "1314433710",
      "id" : 1314433710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ponders",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701069634594734080",
  "geo" : { },
  "id_str" : "701097076168511488",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time @athyvaya TOL.. we (humanity) need 2 wake ourselves up.. hmm.. #ponders",
  "id" : 701097076168511488,
  "in_reply_to_status_id" : 701069634594734080,
  "created_at" : "2016-02-20 17:32:23 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Molina",
      "screen_name" : "MikeMolina",
      "indices" : [ 3, 14 ],
      "id_str" : "15246435",
      "id" : 15246435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701052114756308994",
  "text" : "RT @MikeMolina: What if Jesus' Law of Love was part of a mighty law governing the evolution of our brains toward higher consciousness? Data\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700891421763502080",
    "text" : "What if Jesus' Law of Love was part of a mighty law governing the evolution of our brains toward higher consciousness? Data says very likely",
    "id" : 700891421763502080,
    "created_at" : "2016-02-20 03:55:11 +0000",
    "user" : {
      "name" : "Mike Molina",
      "screen_name" : "MikeMolina",
      "protected" : false,
      "id_str" : "15246435",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3185540371\/024c271144a1cfc733f75f328738820d_normal.jpeg",
      "id" : 15246435,
      "verified" : false
    }
  },
  "id" : 701052114756308994,
  "created_at" : "2016-02-20 14:33:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie M",
      "screen_name" : "AskAuntieEm1",
      "indices" : [ 3, 16 ],
      "id_str" : "552310370",
      "id" : 552310370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701049095000035330",
  "text" : "RT @AskAuntieEm1: Plot twist, we're ALL delusional.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700958628237307904",
    "text" : "Plot twist, we're ALL delusional.",
    "id" : 700958628237307904,
    "created_at" : "2016-02-20 08:22:14 +0000",
    "user" : {
      "name" : "Auntie M",
      "screen_name" : "AskAuntieEm1",
      "protected" : false,
      "id_str" : "552310370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000133657098\/43fda401ceb6e87b47d341cfbbdf46ed_normal.jpeg",
      "id" : 552310370,
      "verified" : false
    }
  },
  "id" : 701049095000035330,
  "created_at" : "2016-02-20 14:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/700818954063843331\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/neH0snD73I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbnPH4lW8AIOrEo.jpg",
      "id_str" : "700818951387934722",
      "id" : 700818951387934722,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbnPH4lW8AIOrEo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/neH0snD73I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/AH8KVbs5VL",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nolongerquivering\/2016\/02\/quoting-quiverfull-spanking-strong-willed-children\/?repeat=w3tc&_ts=1455923230",
      "display_url" : "patheos.com\/blogs\/nolonger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700818954063843331",
  "text" : "Quoting Quiverfull: Spanking 'Strong-Willed' Children? https:\/\/t.co\/AH8KVbs5VL https:\/\/t.co\/neH0snD73I",
  "id" : 700818954063843331,
  "created_at" : "2016-02-19 23:07:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700814413683535875",
  "text" : "jaw joint pain past week. think its related to sinuses. really sore tonight.",
  "id" : 700814413683535875,
  "created_at" : "2016-02-19 22:49:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "indices" : [ 3, 10 ],
      "id_str" : "18694547",
      "id" : 18694547
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/4ores7\/status\/700798678651371520\/photo\/1",
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/GXikPWY69d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbm8rzaXIAAPE79.jpg",
      "id_str" : "700798677753995264",
      "id" : 700798677753995264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbm8rzaXIAAPE79.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 766
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 766
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 766
      } ],
      "display_url" : "pic.twitter.com\/GXikPWY69d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700803556249501696",
  "text" : "RT @4ores7: https:\/\/t.co\/GXikPWY69d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/4ores7\/status\/700798678651371520\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/GXikPWY69d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbm8rzaXIAAPE79.jpg",
        "id_str" : "700798677753995264",
        "id" : 700798677753995264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbm8rzaXIAAPE79.jpg",
        "sizes" : [ {
          "h" : 623,
          "resize" : "fit",
          "w" : 766
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 766
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 766
        } ],
        "display_url" : "pic.twitter.com\/GXikPWY69d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700798678651371520",
    "text" : "https:\/\/t.co\/GXikPWY69d",
    "id" : 700798678651371520,
    "created_at" : "2016-02-19 21:46:39 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 700803556249501696,
  "created_at" : "2016-02-19 22:06:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700795869705011200",
  "geo" : { },
  "id_str" : "700797461820940289",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides DD has ranitidine.. i might ask my DR for that.",
  "id" : 700797461820940289,
  "in_reply_to_status_id" : 700795869705011200,
  "created_at" : "2016-02-19 21:41:49 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Michael D. Hill",
      "screen_name" : "GeePawHill",
      "indices" : [ 73, 84 ],
      "id_str" : "21333111",
      "id" : 21333111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/WN0lfifksp",
      "expanded_url" : "https:\/\/www.facebook.com\/onealexharms\/posts\/10153254029701510",
      "display_url" : "facebook.com\/onealexharms\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700795600581689345",
  "text" : "RT @onealexharms: Did I say that, or did I just think it? (With &lt;3 to @geepawhill) Rant continues here: https:\/\/t.co\/WN0lfifksp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael D. Hill",
        "screen_name" : "GeePawHill",
        "indices" : [ 55, 66 ],
        "id_str" : "21333111",
        "id" : 21333111
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/WN0lfifksp",
        "expanded_url" : "https:\/\/www.facebook.com\/onealexharms\/posts\/10153254029701510",
        "display_url" : "facebook.com\/onealexharms\/p\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "700792149596643328",
    "geo" : { },
    "id_str" : "700794775339999232",
    "in_reply_to_user_id" : 15349954,
    "text" : "Did I say that, or did I just think it? (With &lt;3 to @geepawhill) Rant continues here: https:\/\/t.co\/WN0lfifksp",
    "id" : 700794775339999232,
    "in_reply_to_status_id" : 700792149596643328,
    "created_at" : "2016-02-19 21:31:09 +0000",
    "in_reply_to_screen_name" : "onealexharms",
    "in_reply_to_user_id_str" : "15349954",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 700795600581689345,
  "created_at" : "2016-02-19 21:34:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700795436903243778",
  "text" : "RT @BrianRathbone: We are forged from the stars and are capable of no less.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700795033511919617",
    "text" : "We are forged from the stars and are capable of no less.",
    "id" : 700795033511919617,
    "created_at" : "2016-02-19 21:32:10 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 700795436903243778,
  "created_at" : "2016-02-19 21:33:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "acidreflux",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700794309637906432",
  "text" : "did 14 day nexium.. finished a few days ago. didnt seem to work. #acidreflux",
  "id" : 700794309637906432,
  "created_at" : "2016-02-19 21:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700793470252744704",
  "text" : "RT @onealexharms: A baby, born among the colonizers, is colonized from its first breath. Gotta get free. Gotta get free.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700792149596643328",
    "text" : "A baby, born among the colonizers, is colonized from its first breath. Gotta get free. Gotta get free.",
    "id" : 700792149596643328,
    "created_at" : "2016-02-19 21:20:43 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 700793470252744704,
  "created_at" : "2016-02-19 21:25:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    }, {
      "name" : "Cheshire WT",
      "screen_name" : "CheshireWT",
      "indices" : [ 15, 26 ],
      "id_str" : "92775763",
      "id" : 92775763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fox",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "Hedgehog",
      "indices" : [ 67, 76 ]
    }, {
      "text" : "CheshiresWildlife",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700779110122070017",
  "text" : "RT @CamoDave_: @CheshireWT Share &amp; share alike, Vixen #Fox and #Hedgehog feeding together in the garden #CheshiresWildlife https:\/\/t.co\/ypj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cheshire WT",
        "screen_name" : "CheshireWT",
        "indices" : [ 0, 11 ],
        "id_str" : "92775763",
        "id" : 92775763
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/700417390606217217\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/ypjUfxDawB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbhh554WIAAbD9t.jpg",
        "id_str" : "700417389473701888",
        "id" : 700417389473701888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbhh554WIAAbD9t.jpg",
        "sizes" : [ {
          "h" : 645,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ypjUfxDawB"
      } ],
      "hashtags" : [ {
        "text" : "Fox",
        "indices" : [ 43, 47 ]
      }, {
        "text" : "Hedgehog",
        "indices" : [ 52, 61 ]
      }, {
        "text" : "CheshiresWildlife",
        "indices" : [ 93, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700417390606217217",
    "in_reply_to_user_id" : 92775763,
    "text" : "@CheshireWT Share &amp; share alike, Vixen #Fox and #Hedgehog feeding together in the garden #CheshiresWildlife https:\/\/t.co\/ypjUfxDawB",
    "id" : 700417390606217217,
    "created_at" : "2016-02-18 20:31:33 +0000",
    "in_reply_to_screen_name" : "CheshireWT",
    "in_reply_to_user_id_str" : "92775763",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 700779110122070017,
  "created_at" : "2016-02-19 20:28:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/VJXQKNDa4I",
      "expanded_url" : "https:\/\/twitter.com\/slaton_becky\/status\/700346258871824384",
      "display_url" : "twitter.com\/slaton_becky\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700777996295102465",
  "text" : "YES!! https:\/\/t.co\/VJXQKNDa4I",
  "id" : 700777996295102465,
  "created_at" : "2016-02-19 20:24:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Devoted Yogi",
      "screen_name" : "ADevotedYogi",
      "indices" : [ 3, 16 ],
      "id_str" : "612931307",
      "id" : 612931307
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ADevotedYogi\/status\/698828784334737408\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/DXjV2upYN9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbK9E6PWcAA7cHg.jpg",
      "id_str" : "698828784246616064",
      "id" : 698828784246616064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbK9E6PWcAA7cHg.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 435
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 435
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 435
      } ],
      "display_url" : "pic.twitter.com\/DXjV2upYN9"
    } ],
    "hashtags" : [ {
      "text" : "QuoteoftheDay",
      "indices" : [ 49, 63 ]
    }, {
      "text" : "wisdom",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700773388323717121",
  "text" : "RT @ADevotedYogi: another worthy\n to be called a #QuoteoftheDay \n\n#wisdom https:\/\/t.co\/DXjV2upYN9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ADevotedYogi\/status\/698828784334737408\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/DXjV2upYN9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbK9E6PWcAA7cHg.jpg",
        "id_str" : "698828784246616064",
        "id" : 698828784246616064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbK9E6PWcAA7cHg.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 435
        } ],
        "display_url" : "pic.twitter.com\/DXjV2upYN9"
      } ],
      "hashtags" : [ {
        "text" : "QuoteoftheDay",
        "indices" : [ 31, 45 ]
      }, {
        "text" : "wisdom",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698828784334737408",
    "text" : "another worthy\n to be called a #QuoteoftheDay \n\n#wisdom https:\/\/t.co\/DXjV2upYN9",
    "id" : 698828784334737408,
    "created_at" : "2016-02-14 11:19:00 +0000",
    "user" : {
      "name" : "A Devoted Yogi",
      "screen_name" : "ADevotedYogi",
      "protected" : false,
      "id_str" : "612931307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547675394380296192\/yRcaH8qD_normal.jpeg",
      "id" : 612931307,
      "verified" : false
    }
  },
  "id" : 700773388323717121,
  "created_at" : "2016-02-19 20:06:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "indices" : [ 3, 19 ],
      "id_str" : "624392588",
      "id" : 624392588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700772047031443457",
  "text" : "RT @IvanMor79062729: Why would I allow such temporary conditions to determine whether I'm happy or not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700771277213052928",
    "text" : "Why would I allow such temporary conditions to determine whether I'm happy or not.",
    "id" : 700771277213052928,
    "created_at" : "2016-02-19 19:57:46 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "protected" : false,
      "id_str" : "624392588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507966772410974208\/so1kO-9u_normal.jpeg",
      "id" : 624392588,
      "verified" : false
    }
  },
  "id" : 700772047031443457,
  "created_at" : "2016-02-19 20:00:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "indices" : [ 3, 19 ],
      "id_str" : "624392588",
      "id" : 624392588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700771968967057408",
  "text" : "RT @IvanMor79062729: If you hate me now, it doesn't mean you'll hate me later.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700770937403101184",
    "text" : "If you hate me now, it doesn't mean you'll hate me later.",
    "id" : 700770937403101184,
    "created_at" : "2016-02-19 19:56:25 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "protected" : false,
      "id_str" : "624392588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507966772410974208\/so1kO-9u_normal.jpeg",
      "id" : 624392588,
      "verified" : false
    }
  },
  "id" : 700771968967057408,
  "created_at" : "2016-02-19 20:00:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "indices" : [ 3, 19 ],
      "id_str" : "624392588",
      "id" : 624392588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700771678771499008",
  "text" : "RT @IvanMor79062729: Because i regard my shifting thoughts, buthere is nothing there that is constant. Except for it's temporary.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700770010948509696",
    "text" : "Because i regard my shifting thoughts, buthere is nothing there that is constant. Except for it's temporary.",
    "id" : 700770010948509696,
    "created_at" : "2016-02-19 19:52:44 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "IvanMor79062729",
      "protected" : false,
      "id_str" : "624392588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507966772410974208\/so1kO-9u_normal.jpeg",
      "id" : 624392588,
      "verified" : false
    }
  },
  "id" : 700771678771499008,
  "created_at" : "2016-02-19 19:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700770315547193344",
  "text" : "i have 2 see my DR soon for med renewal. she gonna complain about my weight so i procrastinate making appt. gah.",
  "id" : 700770315547193344,
  "created_at" : "2016-02-19 19:53:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700768781883166720",
  "text" : "why should you like me? i could get TBI and be different person. what does that mean? who are we? whats real? nothing. its all a dream.",
  "id" : 700768781883166720,
  "created_at" : "2016-02-19 19:47:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 0, 12 ],
      "id_str" : "27905866",
      "id" : 27905866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700763767659851776",
  "geo" : { },
  "id_str" : "700767289503645697",
  "in_reply_to_user_id" : 27905866,
  "text" : "@rev_heather wonderful! : )",
  "id" : 700767289503645697,
  "in_reply_to_status_id" : 700763767659851776,
  "created_at" : "2016-02-19 19:41:56 +0000",
  "in_reply_to_screen_name" : "rev_heather",
  "in_reply_to_user_id_str" : "27905866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 3, 10 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/amazon\/status\/700696347167555584\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/uJ7bMufVoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CblfnXcXIAAWAS2.jpg",
      "id_str" : "700696346945331200",
      "id" : 700696346945331200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CblfnXcXIAAWAS2.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uJ7bMufVoV"
    } ],
    "hashtags" : [ {
      "text" : "magical",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700767152907759616",
  "text" : "RT @amazon: Friday's got us feeling like... #magical https:\/\/t.co\/uJ7bMufVoV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amazon\/status\/700696347167555584\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/uJ7bMufVoV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CblfnXcXIAAWAS2.jpg",
        "id_str" : "700696346945331200",
        "id" : 700696346945331200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CblfnXcXIAAWAS2.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uJ7bMufVoV"
      } ],
      "hashtags" : [ {
        "text" : "magical",
        "indices" : [ 32, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700696347167555584",
    "text" : "Friday's got us feeling like... #magical https:\/\/t.co\/uJ7bMufVoV",
    "id" : 700696347167555584,
    "created_at" : "2016-02-19 15:00:02 +0000",
    "user" : {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "protected" : false,
      "id_str" : "20793816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786252488223580160\/9-Lwv1sI_normal.jpg",
      "id" : 20793816,
      "verified" : true
    }
  },
  "id" : 700767152907759616,
  "created_at" : "2016-02-19 19:41:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700766118881808384",
  "text" : "RT @CatFoodBreath: \"You never really understand a cat until you consider things from his point of view.\"  Meow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700712666264829952",
    "text" : "\"You never really understand a cat until you consider things from his point of view.\"  Meow.",
    "id" : 700712666264829952,
    "created_at" : "2016-02-19 16:04:52 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 700766118881808384,
  "created_at" : "2016-02-19 19:37:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ZCtxu4PB9E",
      "expanded_url" : "http:\/\/ebks.to\/1OGCHa5",
      "display_url" : "ebks.to\/1OGCHa5"
    } ]
  },
  "geo" : { },
  "id_str" : "700760574334861312",
  "text" : "RT @ebookfriendly: Do you know such punctuation marks as interrobang, certitude point, or exclamation coma?  https:\/\/t.co\/ZCtxu4PB9E https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/700734482966515714\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/wy2R01uEo2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbmCTKkW8AQkdZL.jpg",
        "id_str" : "700734482798800900",
        "id" : 700734482798800900,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbmCTKkW8AQkdZL.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 826
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 274
        }, {
          "h" : 2083,
          "resize" : "fit",
          "w" : 840
        } ],
        "display_url" : "pic.twitter.com\/wy2R01uEo2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/ZCtxu4PB9E",
        "expanded_url" : "http:\/\/ebks.to\/1OGCHa5",
        "display_url" : "ebks.to\/1OGCHa5"
      } ]
    },
    "geo" : { },
    "id_str" : "700734482966515714",
    "text" : "Do you know such punctuation marks as interrobang, certitude point, or exclamation coma?  https:\/\/t.co\/ZCtxu4PB9E https:\/\/t.co\/wy2R01uEo2",
    "id" : 700734482966515714,
    "created_at" : "2016-02-19 17:31:34 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 700760574334861312,
  "created_at" : "2016-02-19 19:15:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700760072939384833",
  "text" : "I believe in evolution.. even after death. The spiritual world evolves as the physical world evolves. as above so below.. etc. #woo &lt;3",
  "id" : 700760072939384833,
  "created_at" : "2016-02-19 19:13:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Farm",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "Cowichan",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "Canada",
      "indices" : [ 83, 90 ]
    }, {
      "text" : "HDR",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "photography",
      "indices" : [ 96, 108 ]
    }, {
      "text" : "rural",
      "indices" : [ 109, 115 ]
    }, {
      "text" : "light",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "landscape",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700758621055922176",
  "text" : "RT @ToadHollowPhoto: #Farm - #Cowichan Valley, Vancouver Island, British Columbia, #Canada #HDR #photography #rural #light #landscape https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ToadHollowPhoto\/status\/700756249902592000\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/NALEmh8kNu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbmWAQOUkAAGkaR.jpg",
        "id_str" : "700756148132024320",
        "id" : 700756148132024320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbmWAQOUkAAGkaR.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/NALEmh8kNu"
      } ],
      "hashtags" : [ {
        "text" : "Farm",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "Cowichan",
        "indices" : [ 8, 17 ]
      }, {
        "text" : "Canada",
        "indices" : [ 62, 69 ]
      }, {
        "text" : "HDR",
        "indices" : [ 70, 74 ]
      }, {
        "text" : "photography",
        "indices" : [ 75, 87 ]
      }, {
        "text" : "rural",
        "indices" : [ 88, 94 ]
      }, {
        "text" : "light",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "landscape",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700756249902592000",
    "text" : "#Farm - #Cowichan Valley, Vancouver Island, British Columbia, #Canada #HDR #photography #rural #light #landscape https:\/\/t.co\/NALEmh8kNu",
    "id" : 700756249902592000,
    "created_at" : "2016-02-19 18:58:04 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 700758621055922176,
  "created_at" : "2016-02-19 19:07:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secular Coalition",
      "screen_name" : "seculardotorg",
      "indices" : [ 3, 17 ],
      "id_str" : "39319668",
      "id" : 39319668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/YYsKdIsw7a",
      "expanded_url" : "http:\/\/nyti.ms\/1Q3X2We",
      "display_url" : "nyti.ms\/1Q3X2We"
    } ]
  },
  "geo" : { },
  "id_str" : "700758170935828480",
  "text" : "RT @seculardotorg: In one sentence Jerry Falwell Jr. repudiates the entire foundation of the religious right https:\/\/t.co\/YYsKdIsw7a https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/seculardotorg\/status\/700756894667796480\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/K0ZqceY46F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbmHpQeUMAAcDg7.jpg",
        "id_str" : "700740359899328512",
        "id" : 700740359899328512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbmHpQeUMAAcDg7.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 871
        }, {
          "h" : 75,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 132,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 871
        } ],
        "display_url" : "pic.twitter.com\/K0ZqceY46F"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/YYsKdIsw7a",
        "expanded_url" : "http:\/\/nyti.ms\/1Q3X2We",
        "display_url" : "nyti.ms\/1Q3X2We"
      } ]
    },
    "geo" : { },
    "id_str" : "700756894667796480",
    "text" : "In one sentence Jerry Falwell Jr. repudiates the entire foundation of the religious right https:\/\/t.co\/YYsKdIsw7a https:\/\/t.co\/K0ZqceY46F",
    "id" : 700756894667796480,
    "created_at" : "2016-02-19 19:00:37 +0000",
    "user" : {
      "name" : "Secular Coalition",
      "screen_name" : "seculardotorg",
      "protected" : false,
      "id_str" : "39319668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649212820148477952\/p64J6Uu1_normal.jpg",
      "id" : 39319668,
      "verified" : true
    }
  },
  "id" : 700758170935828480,
  "created_at" : "2016-02-19 19:05:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KcvHUkB6oy",
      "expanded_url" : "https:\/\/twitter.com\/bend_time\/status\/700735276474171393",
      "display_url" : "twitter.com\/bend_time\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700740344598499328",
  "text" : "its about reaching for the better thought than the next better thought, etc. AH and ACIMchanged how I view the world https:\/\/t.co\/KcvHUkB6oy",
  "id" : 700740344598499328,
  "created_at" : "2016-02-19 17:54:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/MhnbSilxdg",
      "expanded_url" : "https:\/\/youtu.be\/VEW3z-nfIGk",
      "display_url" : "youtu.be\/VEW3z-nfIGk"
    } ]
  },
  "geo" : { },
  "id_str" : "700730954319470594",
  "text" : "Abraham Hicks 2016 - You are able to turn it around (new) https:\/\/t.co\/MhnbSilxdg",
  "id" : 700730954319470594,
  "created_at" : "2016-02-19 17:17:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/pYmZ3AKqZY",
      "expanded_url" : "https:\/\/twitter.com\/pickeringpublib\/status\/700714845239435265",
      "display_url" : "twitter.com\/pickeringpubli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700730566560223233",
  "text" : "wisdom https:\/\/t.co\/pYmZ3AKqZY",
  "id" : 700730566560223233,
  "created_at" : "2016-02-19 17:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AbrahamHicks",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700730123473911808",
  "text" : "god.. i need to listen to more #AbrahamHicks .. feeling lighter already.. have gotten too into world caught up in negativity.",
  "id" : 700730123473911808,
  "created_at" : "2016-02-19 17:14:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/VHdqF85Hrc",
      "expanded_url" : "https:\/\/youtu.be\/GuihUtfhdu4",
      "display_url" : "youtu.be\/GuihUtfhdu4"
    } ]
  },
  "geo" : { },
  "id_str" : "700727781341077504",
  "text" : "love AH.. we create w our thoughts.. Abraham Hicks 2016 - Project what feels good to you (new) https:\/\/t.co\/VHdqF85Hrc",
  "id" : 700727781341077504,
  "created_at" : "2016-02-19 17:04:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zoe's Bag Boutique",
      "screen_name" : "zoesbagboutique",
      "indices" : [ 3, 19 ],
      "id_str" : "27628892",
      "id" : 27628892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ySX3gd3Gh1",
      "expanded_url" : "http:\/\/fb.me\/77JSbCarq",
      "display_url" : "fb.me\/77JSbCarq"
    } ]
  },
  "geo" : { },
  "id_str" : "700717489622114304",
  "text" : "RT @zoesbagboutique: A new knitting fabric, this is Knitting Hearts https:\/\/t.co\/ySX3gd3Gh1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/ySX3gd3Gh1",
        "expanded_url" : "http:\/\/fb.me\/77JSbCarq",
        "display_url" : "fb.me\/77JSbCarq"
      } ]
    },
    "geo" : { },
    "id_str" : "700715099015749632",
    "text" : "A new knitting fabric, this is Knitting Hearts https:\/\/t.co\/ySX3gd3Gh1",
    "id" : 700715099015749632,
    "created_at" : "2016-02-19 16:14:32 +0000",
    "user" : {
      "name" : "Zoe's Bag Boutique",
      "screen_name" : "zoesbagboutique",
      "protected" : false,
      "id_str" : "27628892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2167261924\/188x188_for_new_facebook_page_normal.gif",
      "id" : 27628892,
      "verified" : false
    }
  },
  "id" : 700717489622114304,
  "created_at" : "2016-02-19 16:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/vPWozACtjP",
      "expanded_url" : "https:\/\/www.facebook.com\/SwanWatch-Ryan-Mottram-Nature-photography-933477200004111\/",
      "display_url" : "facebook.com\/SwanWatch-Ryan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700716600240918528",
  "text" : "RT @Swanwhisperer: please like and share my photography page https:\/\/t.co\/vPWozACtjP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/vPWozACtjP",
        "expanded_url" : "https:\/\/www.facebook.com\/SwanWatch-Ryan-Mottram-Nature-photography-933477200004111\/",
        "display_url" : "facebook.com\/SwanWatch-Ryan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700714826981453824",
    "text" : "please like and share my photography page https:\/\/t.co\/vPWozACtjP",
    "id" : 700714826981453824,
    "created_at" : "2016-02-19 16:13:28 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 700716600240918528,
  "created_at" : "2016-02-19 16:20:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/r22cUEuN9d",
      "expanded_url" : "http:\/\/maitria.com\/podcast",
      "display_url" : "maitria.com\/podcast"
    } ]
  },
  "geo" : { },
  "id_str" : "700716123050782721",
  "text" : "RT @onealexharms: If you\u2019re liking the Geek Joy podcast, please share it with your friends. https:\/\/t.co\/r22cUEuN9d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/r22cUEuN9d",
        "expanded_url" : "http:\/\/maitria.com\/podcast",
        "display_url" : "maitria.com\/podcast"
      } ]
    },
    "geo" : { },
    "id_str" : "700715256407007232",
    "text" : "If you\u2019re liking the Geek Joy podcast, please share it with your friends. https:\/\/t.co\/r22cUEuN9d",
    "id" : 700715256407007232,
    "created_at" : "2016-02-19 16:15:10 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 700716123050782721,
  "created_at" : "2016-02-19 16:18:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vita Bella",
      "screen_name" : "BeyondMeds",
      "indices" : [ 3, 14 ],
      "id_str" : "307559685",
      "id" : 307559685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700709589906546688",
  "text" : "RT @BeyondMeds: If you feel envious dive into that feeling and find grief...grief for something you might have had...feel that grief comple\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700333145468571648",
    "text" : "If you feel envious dive into that feeling and find grief...grief for something you might have had...feel that grief completely and heal.",
    "id" : 700333145468571648,
    "created_at" : "2016-02-18 14:56:48 +0000",
    "user" : {
      "name" : "Monica",
      "screen_name" : "ParadoxNow_",
      "protected" : false,
      "id_str" : "482488440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792834770912710657\/FX7dok1j_normal.jpg",
      "id" : 482488440,
      "verified" : false
    }
  },
  "id" : 700709589906546688,
  "created_at" : "2016-02-19 15:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nichols",
      "screen_name" : "NicholsUprising",
      "indices" : [ 3, 19 ],
      "id_str" : "466519303",
      "id" : 466519303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700701694376607744",
  "text" : "RT @NicholsUprising: Embarrassing that a senator would get the history so very wrong. Presidents have often appointed in election years. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/HHU0hXecWV",
        "expanded_url" : "https:\/\/twitter.com\/lisamurkowski\/status\/700482929869377536",
        "display_url" : "twitter.com\/lisamurkowski\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700690979322376192",
    "text" : "Embarrassing that a senator would get the history so very wrong. Presidents have often appointed in election years. https:\/\/t.co\/HHU0hXecWV",
    "id" : 700690979322376192,
    "created_at" : "2016-02-19 14:38:42 +0000",
    "user" : {
      "name" : "John Nichols",
      "screen_name" : "NicholsUprising",
      "protected" : false,
      "id_str" : "466519303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441901473299853312\/KQn3SLti_normal.jpeg",
      "id" : 466519303,
      "verified" : false
    }
  },
  "id" : 700701694376607744,
  "created_at" : "2016-02-19 15:21:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700684037334110208",
  "text" : "I'm 56% through Fear the Sky (Unabridged) by Stephen Moss, narrated by R.C. Bray on my Audible app.",
  "id" : 700684037334110208,
  "created_at" : "2016-02-19 14:11:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700497708402933760",
  "text" : "RT @existentialcoms: I think I might have some kind of allergy to life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700497586436722688",
    "text" : "I think I might have some kind of allergy to life.",
    "id" : 700497586436722688,
    "created_at" : "2016-02-19 01:50:13 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 700497708402933760,
  "created_at" : "2016-02-19 01:50:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GSayJ7EnTI",
      "expanded_url" : "https:\/\/twitter.com\/lisamurkowski\/status\/700482929869377536",
      "display_url" : "twitter.com\/lisamurkowski\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700496230854500352",
  "text" : "there is no tradition. in fact, dont think any POTUS has left vacancy open for next Anyone? Correct me if Im wrong. https:\/\/t.co\/GSayJ7EnTI",
  "id" : 700496230854500352,
  "created_at" : "2016-02-19 01:44:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF84SardonicTart\u2122\uD83C\uDF84",
      "screen_name" : "SardonicTart",
      "indices" : [ 3, 16 ],
      "id_str" : "1195521564",
      "id" : 1195521564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700493402509422592",
  "text" : "RT @SardonicTart: How to log off Twitter:\n\n1) Die",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697520600605130753",
    "text" : "How to log off Twitter:\n\n1) Die",
    "id" : 697520600605130753,
    "created_at" : "2016-02-10 20:40:45 +0000",
    "user" : {
      "name" : "\uD83C\uDF84SardonicTart\u2122\uD83C\uDF84",
      "screen_name" : "SardonicTart",
      "protected" : false,
      "id_str" : "1195521564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793492656995336192\/YujdMg_N_normal.jpg",
      "id" : 1195521564,
      "verified" : false
    }
  },
  "id" : 700493402509422592,
  "created_at" : "2016-02-19 01:33:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Pagan Duchess",
      "screen_name" : "Duchwela2",
      "indices" : [ 3, 13 ],
      "id_str" : "1706231244",
      "id" : 1706231244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Aqqv6bbb3E",
      "expanded_url" : "https:\/\/twitter.com\/lisamurkowski\/status\/700482929869377536",
      "display_url" : "twitter.com\/lisamurkowski\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700493189862412292",
  "text" : "RT @Duchwela2: I'm confused. When did that ever happen? https:\/\/t.co\/Aqqv6bbb3E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/Aqqv6bbb3E",
        "expanded_url" : "https:\/\/twitter.com\/lisamurkowski\/status\/700482929869377536",
        "display_url" : "twitter.com\/lisamurkowski\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700491330418380800",
    "text" : "I'm confused. When did that ever happen? https:\/\/t.co\/Aqqv6bbb3E",
    "id" : 700491330418380800,
    "created_at" : "2016-02-19 01:25:22 +0000",
    "user" : {
      "name" : "The Pagan Duchess",
      "screen_name" : "Duchwela2",
      "protected" : false,
      "id_str" : "1706231244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798639176228880386\/dsaS2HzR_normal.jpg",
      "id" : 1706231244,
      "verified" : false
    }
  },
  "id" : 700493189862412292,
  "created_at" : "2016-02-19 01:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "indices" : [ 3, 10 ],
      "id_str" : "14202817",
      "id" : 14202817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/o6xTAsXX2n",
      "expanded_url" : "http:\/\/wpo.st\/VIpC1",
      "display_url" : "wpo.st\/VIpC1"
    } ]
  },
  "geo" : { },
  "id_str" : "700461832180514816",
  "text" : "RT @scalzi: Very interesting:\n\nI\u2019m a liberal lawyer. Clerking for Scalia taught me how to think about the law. https:\/\/t.co\/o6xTAsXX2n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/o6xTAsXX2n",
        "expanded_url" : "http:\/\/wpo.st\/VIpC1",
        "display_url" : "wpo.st\/VIpC1"
      } ]
    },
    "geo" : { },
    "id_str" : "700326211214516224",
    "text" : "Very interesting:\n\nI\u2019m a liberal lawyer. Clerking for Scalia taught me how to think about the law. https:\/\/t.co\/o6xTAsXX2n",
    "id" : 700326211214516224,
    "created_at" : "2016-02-18 14:29:14 +0000",
    "user" : {
      "name" : "John Scalzi",
      "screen_name" : "scalzi",
      "protected" : false,
      "id_str" : "14202817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475245194\/59992708a306aaa836bf1699f8b47d5d_normal.png",
      "id" : 14202817,
      "verified" : true
    }
  },
  "id" : 700461832180514816,
  "created_at" : "2016-02-18 23:28:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700441321052438528",
  "text" : "i did not like myself.. then I accepted myself. now.. im confused??",
  "id" : 700441321052438528,
  "created_at" : "2016-02-18 22:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700440221582827521",
  "text" : "i can see it now. my 5s will not b fun. issues buried deep coming to surface. ugh. i want my bliss back!",
  "id" : 700440221582827521,
  "created_at" : "2016-02-18 22:02:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OverDrive Libraries",
      "screen_name" : "OverDriveLibs",
      "indices" : [ 3, 17 ],
      "id_str" : "100572292",
      "id" : 100572292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kwE5VBcN3Z",
      "expanded_url" : "http:\/\/vrl.ht\/8871E",
      "display_url" : "vrl.ht\/8871E"
    } ]
  },
  "geo" : { },
  "id_str" : "700439511952654336",
  "text" : "RT @OverDriveLibs: We share lots of books in each podcast episode. You can sample &amp; borrow them all right here: https:\/\/t.co\/kwE5VBcN3Z htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.viralheat.com\" rel=\"nofollow\"\u003ECision Social Edition\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OverDriveLibs\/status\/700438401061777409\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Yuf3e5Yx6A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbh1A6jUsAAB6ji.jpg",
        "id_str" : "700438400633974784",
        "id" : 700438400633974784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbh1A6jUsAAB6ji.jpg",
        "sizes" : [ {
          "h" : 609,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 735,
          "resize" : "fit",
          "w" : 1236
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Yuf3e5Yx6A"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/kwE5VBcN3Z",
        "expanded_url" : "http:\/\/vrl.ht\/8871E",
        "display_url" : "vrl.ht\/8871E"
      } ]
    },
    "geo" : { },
    "id_str" : "700438401061777409",
    "text" : "We share lots of books in each podcast episode. You can sample &amp; borrow them all right here: https:\/\/t.co\/kwE5VBcN3Z https:\/\/t.co\/Yuf3e5Yx6A",
    "id" : 700438401061777409,
    "created_at" : "2016-02-18 21:55:02 +0000",
    "user" : {
      "name" : "OverDrive Libraries",
      "screen_name" : "OverDriveLibs",
      "protected" : false,
      "id_str" : "100572292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799275994305720320\/EvwrkMdk_normal.jpg",
      "id" : 100572292,
      "verified" : false
    }
  },
  "id" : 700439511952654336,
  "created_at" : "2016-02-18 21:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 0, 14 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700430663565078529",
  "geo" : { },
  "id_str" : "700439328581926912",
  "in_reply_to_user_id" : 272369448,
  "text" : "@Swanwhisperer nice pic. sorry you havent been well. hope it turns around soon.",
  "id" : 700439328581926912,
  "in_reply_to_status_id" : 700430663565078529,
  "created_at" : "2016-02-18 21:58:44 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sad",
      "indices" : [ 7, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/iZrVlYUzGj",
      "expanded_url" : "https:\/\/twitter.com\/bend_time\/status\/700394321225207808",
      "display_url" : "twitter.com\/bend_time\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700400106399526913",
  "text" : "nooo!! #sad https:\/\/t.co\/iZrVlYUzGj",
  "id" : 700400106399526913,
  "created_at" : "2016-02-18 19:22:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/700377022846144512\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hJI1XQOhpJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbg9MIUW4AAriY7.jpg",
      "id_str" : "700377020656705536",
      "id" : 700377020656705536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbg9MIUW4AAriY7.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/hJI1XQOhpJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700379894618914817",
  "text" : "RT @jacqueduncalf: \"Why are you under here as well Wise one \"\" I thought you were scared my friend so I comfort you\" https:\/\/t.co\/hJI1XQOhpJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/700377022846144512\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/hJI1XQOhpJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbg9MIUW4AAriY7.jpg",
        "id_str" : "700377020656705536",
        "id" : 700377020656705536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbg9MIUW4AAriY7.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/hJI1XQOhpJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700377022846144512",
    "text" : "\"Why are you under here as well Wise one \"\" I thought you were scared my friend so I comfort you\" https:\/\/t.co\/hJI1XQOhpJ",
    "id" : 700377022846144512,
    "created_at" : "2016-02-18 17:51:09 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 700379894618914817,
  "created_at" : "2016-02-18 18:02:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K. Hulegaard",
      "screen_name" : "HulegaardBooks",
      "indices" : [ 3, 18 ],
      "id_str" : "216410258",
      "id" : 216410258
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HulegaardBooks\/status\/700378861016461312\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/hvfkKPSSua",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbg-1vnUMAA6SU_.jpg",
      "id_str" : "700378835091468288",
      "id" : 700378835091468288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbg-1vnUMAA6SU_.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hvfkKPSSua"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700379116848160768",
  "text" : "RT @HulegaardBooks: I have to be careful around here. Someone's always trying to steal my secrets. https:\/\/t.co\/hvfkKPSSua",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HulegaardBooks\/status\/700378861016461312\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/hvfkKPSSua",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbg-1vnUMAA6SU_.jpg",
        "id_str" : "700378835091468288",
        "id" : 700378835091468288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbg-1vnUMAA6SU_.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hvfkKPSSua"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700378861016461312",
    "text" : "I have to be careful around here. Someone's always trying to steal my secrets. https:\/\/t.co\/hvfkKPSSua",
    "id" : 700378861016461312,
    "created_at" : "2016-02-18 17:58:27 +0000",
    "user" : {
      "name" : "David K. Hulegaard",
      "screen_name" : "HulegaardBooks",
      "protected" : false,
      "id_str" : "216410258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432974144804626432\/nwds5WEI_normal.jpeg",
      "id" : 216410258,
      "verified" : false
    }
  },
  "id" : 700379116848160768,
  "created_at" : "2016-02-18 17:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Doubtmoore",
      "screen_name" : "Doubtism",
      "indices" : [ 0, 9 ],
      "id_str" : "3948640959",
      "id" : 3948640959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700365034229264384",
  "geo" : { },
  "id_str" : "700368171027591168",
  "in_reply_to_user_id" : 3948640959,
  "text" : "@Doubtism i love the #woo : )",
  "id" : 700368171027591168,
  "in_reply_to_status_id" : 700365034229264384,
  "created_at" : "2016-02-18 17:15:58 +0000",
  "in_reply_to_screen_name" : "Doubtism",
  "in_reply_to_user_id_str" : "3948640959",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Doubtmoore",
      "screen_name" : "Doubtism",
      "indices" : [ 0, 9 ],
      "id_str" : "3948640959",
      "id" : 3948640959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700365493589377025",
  "geo" : { },
  "id_str" : "700367737990836224",
  "in_reply_to_user_id" : 3948640959,
  "text" : "@Doubtism actually, i agree w you there..lol",
  "id" : 700367737990836224,
  "in_reply_to_status_id" : 700365493589377025,
  "created_at" : "2016-02-18 17:14:15 +0000",
  "in_reply_to_screen_name" : "Doubtism",
  "in_reply_to_user_id_str" : "3948640959",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Doubtmoore",
      "screen_name" : "Doubtism",
      "indices" : [ 0, 9 ],
      "id_str" : "3948640959",
      "id" : 3948640959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700338209994207232",
  "geo" : { },
  "id_str" : "700364213382991872",
  "in_reply_to_user_id" : 3948640959,
  "text" : "@Doubtism conglomerate of life exp. ..ghosts, NDEs, nature, animals, quantum physics, the wonder of it all.",
  "id" : 700364213382991872,
  "in_reply_to_status_id" : 700338209994207232,
  "created_at" : "2016-02-18 17:00:15 +0000",
  "in_reply_to_screen_name" : "Doubtism",
  "in_reply_to_user_id_str" : "3948640959",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Doubtmoore",
      "screen_name" : "Doubtism",
      "indices" : [ 0, 9 ],
      "id_str" : "3948640959",
      "id" : 3948640959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700337716043649024",
  "geo" : { },
  "id_str" : "700363270880890880",
  "in_reply_to_user_id" : 3948640959,
  "text" : "@Doubtism you were just so.. adament.. w that statement. like saying dont think beyond the facts (which is what pushes us forward)",
  "id" : 700363270880890880,
  "in_reply_to_status_id" : 700337716043649024,
  "created_at" : "2016-02-18 16:56:30 +0000",
  "in_reply_to_screen_name" : "Doubtism",
  "in_reply_to_user_id_str" : "3948640959",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 105, 120 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/5DyvSY3bvB",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/02\/evangelical-john-piper-says-god-changed-mind-executing-homosexuals\/",
      "display_url" : "brucegerencser.net\/2016\/02\/evange\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700356469896695808",
  "text" : "Evangelical John Piper Says God Changed His Mind About Executing Homosexuals https:\/\/t.co\/5DyvSY3bvB via @BruceGerencser",
  "id" : 700356469896695808,
  "created_at" : "2016-02-18 16:29:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.toneden.io\" rel=\"nofollow\"\u003EToneDen\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Black Guill\u2206ume \u2122",
      "screen_name" : "GuillaumeCoquin",
      "indices" : [ 30, 46 ],
      "id_str" : "215836916",
      "id" : 215836916
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/700351674246782976\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/fynrmg0tD6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbgmIwaUkAAcBrc.jpg",
      "id_str" : "700351673932222464",
      "id" : 700351673932222464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbgmIwaUkAAcBrc.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/fynrmg0tD6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/kzotubau1n",
      "expanded_url" : "http:\/\/get.tndn.io\/m\/ANTEjqgw4q",
      "display_url" : "get.tndn.io\/m\/ANTEjqgw4q"
    } ]
  },
  "geo" : { },
  "id_str" : "700351674246782976",
  "text" : "Just downloaded this dope ass @guillaumecoquin track! Get it here: https:\/\/t.co\/kzotubau1n https:\/\/t.co\/fynrmg0tD6",
  "id" : 700351674246782976,
  "created_at" : "2016-02-18 16:10:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/bBviIbJZhY",
      "expanded_url" : "https:\/\/twitter.com\/Buddhaworld\/status\/700301392511176705",
      "display_url" : "twitter.com\/Buddhaworld\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700339918808162304",
  "text" : "catchy tune https:\/\/t.co\/bBviIbJZhY",
  "id" : 700339918808162304,
  "created_at" : "2016-02-18 15:23:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/8OuQ0raiFP",
      "expanded_url" : "https:\/\/twitter.com\/Doubtism\/status\/700322143574355968",
      "display_url" : "twitter.com\/Doubtism\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700337279374589952",
  "text" : "o-O .. sigh.. https:\/\/t.co\/8OuQ0raiFP",
  "id" : 700337279374589952,
  "created_at" : "2016-02-18 15:13:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "indices" : [ 3, 17 ],
      "id_str" : "555307309",
      "id" : 555307309
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TA",
      "indices" : [ 129, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700335875604029440",
  "text" : "RT @takecareofUUU: An act of Kindness.U may not see the results immediately but what can't be seen is often felt for a long time.#TA https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/takecareofUUU\/status\/700158182430285824\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7CCEpT8Rsm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbd2KBGWIAA3Dcg.jpg",
        "id_str" : "700158181545222144",
        "id" : 700158181545222144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbd2KBGWIAA3Dcg.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7CCEpT8Rsm"
      } ],
      "hashtags" : [ {
        "text" : "TA",
        "indices" : [ 110, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700158182430285824",
    "text" : "An act of Kindness.U may not see the results immediately but what can't be seen is often felt for a long time.#TA https:\/\/t.co\/7CCEpT8Rsm",
    "id" : 700158182430285824,
    "created_at" : "2016-02-18 03:21:33 +0000",
    "user" : {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "protected" : false,
      "id_str" : "555307309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537254454949445634\/7uw1omdM_normal.jpeg",
      "id" : 555307309,
      "verified" : false
    }
  },
  "id" : 700335875604029440,
  "created_at" : "2016-02-18 15:07:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "indices" : [ 3, 9 ],
      "id_str" : "38473215",
      "id" : 38473215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700333956810612736",
  "text" : "RT @mikta: Feb. 15th, 1945: 3rd day of allied bombing on Dresden, events that would eventually inspire 'Slaughterhouse-Five' https:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mikta\/status\/699406899272257537\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/CYoTMYMXjX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbTK3n2UEAAduJg.jpg",
        "id_str" : "699406899087675392",
        "id" : 699406899087675392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbTK3n2UEAAduJg.jpg",
        "sizes" : [ {
          "h" : 649,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 925
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 925
        } ],
        "display_url" : "pic.twitter.com\/CYoTMYMXjX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699406899272257537",
    "text" : "Feb. 15th, 1945: 3rd day of allied bombing on Dresden, events that would eventually inspire 'Slaughterhouse-Five' https:\/\/t.co\/CYoTMYMXjX",
    "id" : 699406899272257537,
    "created_at" : "2016-02-16 01:36:13 +0000",
    "user" : {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "protected" : false,
      "id_str" : "38473215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605163269968363520\/Xw0d9aky_normal.jpg",
      "id" : 38473215,
      "verified" : false
    }
  },
  "id" : 700333956810612736,
  "created_at" : "2016-02-18 15:00:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "indices" : [ 3, 9 ],
      "id_str" : "38473215",
      "id" : 38473215
    }, {
      "name" : "Sojourners",
      "screen_name" : "Sojourners",
      "indices" : [ 108, 119 ],
      "id_str" : "16673982",
      "id" : 16673982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/iLPzzhtCZL",
      "expanded_url" : "https:\/\/shar.es\/14DxZR",
      "display_url" : "shar.es\/14DxZR"
    } ]
  },
  "geo" : { },
  "id_str" : "700333832520728577",
  "text" : "RT @mikta: History Will Judge Today's Christians According to These 4 Questions https:\/\/t.co\/iLPzzhtCZL via @sojourners",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sojourners",
        "screen_name" : "Sojourners",
        "indices" : [ 97, 108 ],
        "id_str" : "16673982",
        "id" : 16673982
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/iLPzzhtCZL",
        "expanded_url" : "https:\/\/shar.es\/14DxZR",
        "display_url" : "shar.es\/14DxZR"
      } ]
    },
    "geo" : { },
    "id_str" : "700043471277551616",
    "text" : "History Will Judge Today's Christians According to These 4 Questions https:\/\/t.co\/iLPzzhtCZL via @sojourners",
    "id" : 700043471277551616,
    "created_at" : "2016-02-17 19:45:44 +0000",
    "user" : {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "protected" : false,
      "id_str" : "38473215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605163269968363520\/Xw0d9aky_normal.jpg",
      "id" : 38473215,
      "verified" : false
    }
  },
  "id" : 700333832520728577,
  "created_at" : "2016-02-18 14:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "indices" : [ 3, 9 ],
      "id_str" : "38473215",
      "id" : 38473215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700333755542740992",
  "text" : "RT @mikta: God, help me never to make false assumptions about people I\u2019ve never met, circumstances I\u2019ve never known, and events I\u2019ve never \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596695697577086979",
    "text" : "God, help me never to make false assumptions about people I\u2019ve never met, circumstances I\u2019ve never known, and events I\u2019ve never experienced.",
    "id" : 596695697577086979,
    "created_at" : "2015-05-08 15:18:35 +0000",
    "user" : {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "protected" : false,
      "id_str" : "38473215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605163269968363520\/Xw0d9aky_normal.jpg",
      "id" : 38473215,
      "verified" : false
    }
  },
  "id" : 700333755542740992,
  "created_at" : "2016-02-18 14:59:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/700332657331326976\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/KThB6WGE3M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbgU1r5XEAI2hZh.jpg",
      "id_str" : "700332654605045762",
      "id" : 700332654605045762,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbgU1r5XEAI2hZh.jpg",
      "sizes" : [ {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KThB6WGE3M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/x9BCIB8Stm",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/freedhearts\/2016\/02\/16\/christians-you-do-not-have-permission-to-condemn-lgbt\/?_ts=1455807288#comment-2519985964",
      "display_url" : "patheos.com\/blogs\/freedhea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700332657331326976",
  "text" : "Christians, You Do NOT Have Permission to Condemn LGBT https:\/\/t.co\/x9BCIB8Stm https:\/\/t.co\/KThB6WGE3M",
  "id" : 700332657331326976,
  "created_at" : "2016-02-18 14:54:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawkins Dog",
      "screen_name" : "DawkinsDog",
      "indices" : [ 3, 14 ],
      "id_str" : "260729164",
      "id" : 260729164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700136390923841536",
  "text" : "RT @DawkinsDog: Apparently feeling sickened by a god capable of eternal torture means I have \"misplaced anger\"\n\nNo, I just find the concept\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700072848057090054",
    "text" : "Apparently feeling sickened by a god capable of eternal torture means I have \"misplaced anger\"\n\nNo, I just find the concept disgusting.",
    "id" : 700072848057090054,
    "created_at" : "2016-02-17 21:42:28 +0000",
    "user" : {
      "name" : "Dawkins Dog",
      "screen_name" : "DawkinsDog",
      "protected" : false,
      "id_str" : "260729164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797281847810158592\/DHx-Fieo_normal.jpg",
      "id" : 260729164,
      "verified" : false
    }
  },
  "id" : 700136390923841536,
  "created_at" : "2016-02-18 01:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700132246183944197",
  "text" : "RT @benjamincorey: Gun rights? Obey! Our government is ordained by God!\nGay rights? Resist! Our government is godless!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700131156063186944",
    "text" : "Gun rights? Obey! Our government is ordained by God!\nGay rights? Resist! Our government is godless!",
    "id" : 700131156063186944,
    "created_at" : "2016-02-18 01:34:10 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 700132246183944197,
  "created_at" : "2016-02-18 01:38:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 3, 19 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700113984834420736",
  "text" : "RT @JourneyTheHedgi: I don't even know why I'm on zyprexa... Anyone I know taking it, and have you ever had issues w\/ weight and stuff whil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700099216794873857",
    "text" : "I don't even know why I'm on zyprexa... Anyone I know taking it, and have you ever had issues w\/ weight and stuff while on it?",
    "id" : 700099216794873857,
    "created_at" : "2016-02-17 23:27:15 +0000",
    "user" : {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "protected" : false,
      "id_str" : "1137858745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567144176848891905\/-TmPAWNk_normal.png",
      "id" : 1137858745,
      "verified" : false
    }
  },
  "id" : 700113984834420736,
  "created_at" : "2016-02-18 00:25:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/700100553137754112\/video\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/mY4lB2qMAf",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/700100458212360192\/pu\/img\/ZYb0YcjTkcR8vQW5.jpg",
      "id_str" : "700100458212360192",
      "id" : 700100458212360192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/700100458212360192\/pu\/img\/ZYb0YcjTkcR8vQW5.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mY4lB2qMAf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700113647343894528",
  "text" : "RT @ErinEFarley: Sunset with deer. https:\/\/t.co\/mY4lB2qMAf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/700100553137754112\/video\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/mY4lB2qMAf",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/700100458212360192\/pu\/img\/ZYb0YcjTkcR8vQW5.jpg",
        "id_str" : "700100458212360192",
        "id" : 700100458212360192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/700100458212360192\/pu\/img\/ZYb0YcjTkcR8vQW5.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mY4lB2qMAf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700100553137754112",
    "text" : "Sunset with deer. https:\/\/t.co\/mY4lB2qMAf",
    "id" : 700100553137754112,
    "created_at" : "2016-02-17 23:32:33 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 700113647343894528,
  "created_at" : "2016-02-18 00:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 84, 94 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/uyy9Ao0aOW",
      "expanded_url" : "https:\/\/shar.es\/14O2Ct",
      "display_url" : "shar.es\/14O2Ct"
    } ]
  },
  "geo" : { },
  "id_str" : "700113228823711744",
  "text" : "RT @dwaynereaves: Railroad, what's around the corner? \n https:\/\/t.co\/uyy9Ao0aOW via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 66, 76 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/uyy9Ao0aOW",
        "expanded_url" : "https:\/\/shar.es\/14O2Ct",
        "display_url" : "shar.es\/14O2Ct"
      } ]
    },
    "geo" : { },
    "id_str" : "700108145616621574",
    "text" : "Railroad, what's around the corner? \n https:\/\/t.co\/uyy9Ao0aOW via @sharethis",
    "id" : 700108145616621574,
    "created_at" : "2016-02-18 00:02:43 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 700113228823711744,
  "created_at" : "2016-02-18 00:22:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/700099292934115329\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/7hD3Ioz7Fv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbdAmEHWwAEHGH8.jpg",
      "id_str" : "700099289763201025",
      "id" : 700099289763201025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbdAmEHWwAEHGH8.jpg",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/7hD3Ioz7Fv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/M9KGBBkGNR",
      "expanded_url" : "http:\/\/samanthapfield.com\/2016\/02\/17\/living-without-inspiration-the-bible-and-me?_ts=1455751649",
      "display_url" : "samanthapfield.com\/2016\/02\/17\/liv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700099292934115329",
  "text" : "living without inspiration: the Bible and Me \u2013 Samantha Field https:\/\/t.co\/M9KGBBkGNR https:\/\/t.co\/7hD3Ioz7Fv",
  "id" : 700099292934115329,
  "created_at" : "2016-02-17 23:27:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicola white mudlark",
      "screen_name" : "TideLineArt",
      "indices" : [ 3, 15 ],
      "id_str" : "1093104451",
      "id" : 1093104451
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tidelineart",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700031233150078976",
  "text" : "RT @TideLineArt: If you find a piece of driftwood that looks like a cow's head, you just have to make a driftwood cow! #tidelineart https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TideLineArt\/status\/700024737620226049\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/zxLERlt9JI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbb8uXiWwAEmfKa.jpg",
        "id_str" : "700024665624985601",
        "id" : 700024665624985601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbb8uXiWwAEmfKa.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1440
        } ],
        "display_url" : "pic.twitter.com\/zxLERlt9JI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TideLineArt\/status\/700024737620226049\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/zxLERlt9JI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbb8wjHWIAAsxjd.jpg",
        "id_str" : "700024703092662272",
        "id" : 700024703092662272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbb8wjHWIAAsxjd.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zxLERlt9JI"
      } ],
      "hashtags" : [ {
        "text" : "tidelineart",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700024737620226049",
    "text" : "If you find a piece of driftwood that looks like a cow's head, you just have to make a driftwood cow! #tidelineart https:\/\/t.co\/zxLERlt9JI",
    "id" : 700024737620226049,
    "created_at" : "2016-02-17 18:31:17 +0000",
    "user" : {
      "name" : "nicola white mudlark",
      "screen_name" : "TideLineArt",
      "protected" : false,
      "id_str" : "1093104451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511070234686394368\/y437u3dW_normal.jpeg",
      "id" : 1093104451,
      "verified" : false
    }
  },
  "id" : 700031233150078976,
  "created_at" : "2016-02-17 18:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700010166801080320",
  "geo" : { },
  "id_str" : "700024898736033797",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld I want the song, find it but cant buy or DL.. bad links. got a good link for it?",
  "id" : 700024898736033797,
  "in_reply_to_status_id" : 700010166801080320,
  "created_at" : "2016-02-17 18:31:56 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/YjP0WgUVKK",
      "expanded_url" : "https:\/\/youtu.be\/QCdSPgeaW3E",
      "display_url" : "youtu.be\/QCdSPgeaW3E"
    } ]
  },
  "geo" : { },
  "id_str" : "700020913903964161",
  "text" : "RT @Buddhaworld: https:\/\/t.co\/YjP0WgUVKK,  Rudolfs newest alien song. \" you don't need another star\". Headphones required for a superior te\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/YjP0WgUVKK",
        "expanded_url" : "https:\/\/youtu.be\/QCdSPgeaW3E",
        "display_url" : "youtu.be\/QCdSPgeaW3E"
      } ]
    },
    "geo" : { },
    "id_str" : "700010166801080320",
    "text" : "https:\/\/t.co\/YjP0WgUVKK,  Rudolfs newest alien song. \" you don't need another star\". Headphones required for a superior telepathic listening",
    "id" : 700010166801080320,
    "created_at" : "2016-02-17 17:33:23 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 700020913903964161,
  "created_at" : "2016-02-17 18:16:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699999050813284352",
  "text" : "RT @UnseelieMe: Re: that retweet? Creating a backdoor on our encrypted devices allows the govt (and hackers) access to everything we do ele\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699976812336701440",
    "text" : "Re: that retweet? Creating a backdoor on our encrypted devices allows the govt (and hackers) access to everything we do electronically.",
    "id" : 699976812336701440,
    "created_at" : "2016-02-17 15:20:51 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 699999050813284352,
  "created_at" : "2016-02-17 16:49:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oli Young",
      "screen_name" : "oliyoung",
      "indices" : [ 3, 12 ],
      "id_str" : "813276",
      "id" : 813276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/M6Tux2y1mB",
      "expanded_url" : "http:\/\/www.apple.com\/customer-letter\/",
      "display_url" : "apple.com\/customer-lette\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699998968240074754",
  "text" : "RT @oliyoung: Apple just declared war. You want to be on their side.  https:\/\/t.co\/M6Tux2y1mB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/M6Tux2y1mB",
        "expanded_url" : "http:\/\/www.apple.com\/customer-letter\/",
        "display_url" : "apple.com\/customer-lette\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699900035509583872",
    "text" : "Apple just declared war. You want to be on their side.  https:\/\/t.co\/M6Tux2y1mB",
    "id" : 699900035509583872,
    "created_at" : "2016-02-17 10:15:46 +0000",
    "user" : {
      "name" : "Oli Young",
      "screen_name" : "oliyoung",
      "protected" : false,
      "id_str" : "813276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736842436601745409\/LVEVrTYF_normal.jpg",
      "id" : 813276,
      "verified" : false
    }
  },
  "id" : 699998968240074754,
  "created_at" : "2016-02-17 16:48:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cultured Ruffian",
      "screen_name" : "CulturedRuffian",
      "indices" : [ 3, 19 ],
      "id_str" : "18857913",
      "id" : 18857913
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CulturedRuffian\/status\/699585646403387392\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Zi9k808tHI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVtVP8WwAA9sXs.jpg",
      "id_str" : "699585528950341632",
      "id" : 699585528950341632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVtVP8WwAA9sXs.jpg",
      "sizes" : [ {
        "h" : 218,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 148,
        "resize" : "crop",
        "w" : 148
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 148
      } ],
      "display_url" : "pic.twitter.com\/Zi9k808tHI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699967456798969856",
  "text" : "RT @CulturedRuffian: When life hands you lemons and you tell life to shove it. https:\/\/t.co\/Zi9k808tHI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CulturedRuffian\/status\/699585646403387392\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Zi9k808tHI",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVtVP8WwAA9sXs.jpg",
        "id_str" : "699585528950341632",
        "id" : 699585528950341632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbVtVP8WwAA9sXs.jpg",
        "sizes" : [ {
          "h" : 218,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 148,
          "resize" : "crop",
          "w" : 148
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 148
        } ],
        "display_url" : "pic.twitter.com\/Zi9k808tHI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699585646403387392",
    "text" : "When life hands you lemons and you tell life to shove it. https:\/\/t.co\/Zi9k808tHI",
    "id" : 699585646403387392,
    "created_at" : "2016-02-16 13:26:30 +0000",
    "user" : {
      "name" : "The Cultured Ruffian",
      "screen_name" : "CulturedRuffian",
      "protected" : false,
      "id_str" : "18857913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793406779015192576\/iW-WbemL_normal.jpg",
      "id" : 18857913,
      "verified" : false
    }
  },
  "id" : 699967456798969856,
  "created_at" : "2016-02-17 14:43:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Extinction Symbol",
      "screen_name" : "extinctsymbol",
      "indices" : [ 3, 17 ],
      "id_str" : "522593098",
      "id" : 522593098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/sFVBCl6sQS",
      "expanded_url" : "http:\/\/www.biologicaldiversity.org\/news\/press_releases\/2016\/red-wolf-02-16-2016.html",
      "display_url" : "biologicaldiversity.org\/news\/press_rel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699776251834273792",
  "text" : "RT @extinctsymbol: Red Wolf Population Plunges to as Few as 50 as U.S. Government Abandons Recovery Program: https:\/\/t.co\/sFVBCl6sQS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/sFVBCl6sQS",
        "expanded_url" : "http:\/\/www.biologicaldiversity.org\/news\/press_releases\/2016\/red-wolf-02-16-2016.html",
        "display_url" : "biologicaldiversity.org\/news\/press_rel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699738046288289792",
    "text" : "Red Wolf Population Plunges to as Few as 50 as U.S. Government Abandons Recovery Program: https:\/\/t.co\/sFVBCl6sQS",
    "id" : 699738046288289792,
    "created_at" : "2016-02-16 23:32:05 +0000",
    "user" : {
      "name" : "Extinction Symbol",
      "screen_name" : "extinctsymbol",
      "protected" : false,
      "id_str" : "522593098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567733818199531520\/u3Y7lq8z_normal.jpeg",
      "id" : 522593098,
      "verified" : false
    }
  },
  "id" : 699776251834273792,
  "created_at" : "2016-02-17 02:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TongueOutEwesday",
      "screen_name" : "tongueoutewes",
      "indices" : [ 3, 17 ],
      "id_str" : "4867240780",
      "id" : 4867240780
    }, {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 58, 69 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tongueoutewes\/status\/699731919416635392\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/QkjTKPURNg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXyV1EUMAAPRV9.jpg",
      "id_str" : "699731773962334208",
      "id" : 699731773962334208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXyV1EUMAAPRV9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/QkjTKPURNg"
    } ],
    "hashtags" : [ {
      "text" : "tongueOutEwesday",
      "indices" : [ 35, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699733857130692608",
  "text" : "RT @tongueoutewes: An old favorite #tongueOutEwesday from @PVickerton. Very arty! https:\/\/t.co\/QkjTKPURNg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hawcroft Lleyn",
        "screen_name" : "PVickerton",
        "indices" : [ 39, 50 ],
        "id_str" : "1046103560",
        "id" : 1046103560
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tongueoutewes\/status\/699731919416635392\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/QkjTKPURNg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXyV1EUMAAPRV9.jpg",
        "id_str" : "699731773962334208",
        "id" : 699731773962334208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXyV1EUMAAPRV9.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/QkjTKPURNg"
      } ],
      "hashtags" : [ {
        "text" : "tongueOutEwesday",
        "indices" : [ 16, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699731919416635392",
    "text" : "An old favorite #tongueOutEwesday from @PVickerton. Very arty! https:\/\/t.co\/QkjTKPURNg",
    "id" : 699731919416635392,
    "created_at" : "2016-02-16 23:07:44 +0000",
    "user" : {
      "name" : "TongueOutEwesday",
      "screen_name" : "tongueoutewes",
      "protected" : false,
      "id_str" : "4867240780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697129311959195652\/9c3FZ0bK_normal.jpg",
      "id" : 4867240780,
      "verified" : false
    }
  },
  "id" : 699733857130692608,
  "created_at" : "2016-02-16 23:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie Gambino",
      "screen_name" : "ravenite1940",
      "indices" : [ 3, 16 ],
      "id_str" : "4866891269",
      "id" : 4866891269
    }, {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 18, 34 ],
      "id_str" : "95607516",
      "id" : 95607516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699733571246936064",
  "text" : "RT @ravenite1940: @DonkeySanctuary Finished Woollies ready to raise some money for their brothers and sisters at the Sanctuary \u2764\uFE0Fxx https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Donkey Sanctuary",
        "screen_name" : "DonkeySanctuary",
        "indices" : [ 0, 16 ],
        "id_str" : "95607516",
        "id" : 95607516
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenite1940\/status\/696284103570808833\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/1u4GwhgDlA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CamysgPWIAA7frF.jpg",
        "id_str" : "696284095043739648",
        "id" : 696284095043739648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CamysgPWIAA7frF.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1u4GwhgDlA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696284103570808833",
    "in_reply_to_user_id" : 95607516,
    "text" : "@DonkeySanctuary Finished Woollies ready to raise some money for their brothers and sisters at the Sanctuary \u2764\uFE0Fxx https:\/\/t.co\/1u4GwhgDlA",
    "id" : 696284103570808833,
    "created_at" : "2016-02-07 10:47:21 +0000",
    "in_reply_to_screen_name" : "DonkeySanctuary",
    "in_reply_to_user_id_str" : "95607516",
    "user" : {
      "name" : "Carrie Gambino",
      "screen_name" : "ravenite1940",
      "protected" : false,
      "id_str" : "4866891269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763504146246950913\/Ae6DKylp_normal.jpg",
      "id" : 4866891269,
      "verified" : false
    }
  },
  "id" : 699733571246936064,
  "created_at" : "2016-02-16 23:14:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barlochan Highlander",
      "screen_name" : "BarlochanBeef",
      "indices" : [ 3, 17 ],
      "id_str" : "410047652",
      "id" : 410047652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BarlochanBeef\/status\/699679709932752898\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/GanZu6VaZc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXC-FzWIAAUO-M.jpg",
      "id_str" : "699679689091194880",
      "id" : 699679689091194880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXC-FzWIAAUO-M.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GanZu6VaZc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699683722438799362",
  "text" : "RT @BarlochanBeef: Love is ....\n... Even on a wet horrible day! https:\/\/t.co\/GanZu6VaZc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BarlochanBeef\/status\/699679709932752898\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/GanZu6VaZc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXC-FzWIAAUO-M.jpg",
        "id_str" : "699679689091194880",
        "id" : 699679689091194880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXC-FzWIAAUO-M.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GanZu6VaZc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699679709932752898",
    "text" : "Love is ....\n... Even on a wet horrible day! https:\/\/t.co\/GanZu6VaZc",
    "id" : 699679709932752898,
    "created_at" : "2016-02-16 19:40:16 +0000",
    "user" : {
      "name" : "Barlochan Highlander",
      "screen_name" : "BarlochanBeef",
      "protected" : false,
      "id_str" : "410047652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2694130773\/01a35d52476eb296c8d6eafbf1a02781_normal.jpeg",
      "id" : 410047652,
      "verified" : false
    }
  },
  "id" : 699683722438799362,
  "created_at" : "2016-02-16 19:56:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699675651423543296",
  "text" : "anxiety inducing incident.. cat foot got caught in DD ds wire. cat hissing.. dog freaking.",
  "id" : 699675651423543296,
  "created_at" : "2016-02-16 19:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 0, 13 ],
      "id_str" : "926185416",
      "id" : 926185416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699670628274728961",
  "geo" : { },
  "id_str" : "699672296508751872",
  "in_reply_to_user_id" : 926185416,
  "text" : "@hoosierworld how does anyone not know how bad fracking is?? ack.",
  "id" : 699672296508751872,
  "in_reply_to_status_id" : 699670628274728961,
  "created_at" : "2016-02-16 19:10:49 +0000",
  "in_reply_to_screen_name" : "hoosierworld",
  "in_reply_to_user_id_str" : "926185416",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 100, 110 ]
    }, {
      "text" : "review",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/jWfSYh3IiT",
      "expanded_url" : "https:\/\/youtu.be\/rxKHhCHAvJI",
      "display_url" : "youtu.be\/rxKHhCHAvJI"
    } ]
  },
  "geo" : { },
  "id_str" : "699668432766312448",
  "text" : "The Teaching Company, Integrated History Of Greece And Rome Audio lectur... https:\/\/t.co\/jWfSYh3IiT #audiobook #review",
  "id" : 699668432766312448,
  "created_at" : "2016-02-16 18:55:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McNeil",
      "screen_name" : "GretchenMcNeil",
      "indices" : [ 3, 18 ],
      "id_str" : "14734870",
      "id" : 14734870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/61TtCx8AzB",
      "expanded_url" : "http:\/\/amzn.to\/1Q5JsmY",
      "display_url" : "amzn.to\/1Q5JsmY"
    } ]
  },
  "geo" : { },
  "id_str" : "699655782439194624",
  "text" : "RT @GretchenMcNeil: BEWARE THE WILD eBook is on sale! https:\/\/t.co\/61TtCx8AzB RT by 3pm PST to win an ARC of BEHOLD THE BONE and more! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GretchenMcNeil\/status\/699654167007080448\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/RIGPMcD2Ta",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbWrvzkUEAAiqXb.jpg",
        "id_str" : "699654154910699520",
        "id" : 699654154910699520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbWrvzkUEAAiqXb.jpg",
        "sizes" : [ {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/RIGPMcD2Ta"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/61TtCx8AzB",
        "expanded_url" : "http:\/\/amzn.to\/1Q5JsmY",
        "display_url" : "amzn.to\/1Q5JsmY"
      } ]
    },
    "geo" : { },
    "id_str" : "699654167007080448",
    "text" : "BEWARE THE WILD eBook is on sale! https:\/\/t.co\/61TtCx8AzB RT by 3pm PST to win an ARC of BEHOLD THE BONE and more! https:\/\/t.co\/RIGPMcD2Ta",
    "id" : 699654167007080448,
    "created_at" : "2016-02-16 17:58:47 +0000",
    "user" : {
      "name" : "Gretchen McNeil",
      "screen_name" : "GretchenMcNeil",
      "protected" : false,
      "id_str" : "14734870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796829431096410112\/oiFyRrxn_normal.jpg",
      "id" : 14734870,
      "verified" : false
    }
  },
  "id" : 699655782439194624,
  "created_at" : "2016-02-16 18:05:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "indices" : [ 3, 18 ],
      "id_str" : "148856572",
      "id" : 148856572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AUDIOBOOK",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699636600213528578",
  "text" : "RT @Audiobook_Comm: Calling all #AUDIOBOOK BLOGGERS! The APA Announces 2nd \u201CAudiobook Blogger of the Year\u201D Contest! Enter to win here: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AUDIOBOOK",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/AZcphOPyMZ",
        "expanded_url" : "https:\/\/audiopub.org\/audioblogger.asp",
        "display_url" : "audiopub.org\/audioblogger.a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699632846227578881",
    "text" : "Calling all #AUDIOBOOK BLOGGERS! The APA Announces 2nd \u201CAudiobook Blogger of the Year\u201D Contest! Enter to win here: https:\/\/t.co\/AZcphOPyMZ",
    "id" : 699632846227578881,
    "created_at" : "2016-02-16 16:34:03 +0000",
    "user" : {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "protected" : false,
      "id_str" : "148856572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716970602259738624\/qDTP4Z12_normal.jpg",
      "id" : 148856572,
      "verified" : false
    }
  },
  "id" : 699636600213528578,
  "created_at" : "2016-02-16 16:48:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrien Joly",
      "screen_name" : "adrienjoly",
      "indices" : [ 3, 14 ],
      "id_str" : "6468662",
      "id" : 6468662
    }, {
      "name" : "Corey Crellin",
      "screen_name" : "CoreyCrellin",
      "indices" : [ 29, 42 ],
      "id_str" : "2321502938",
      "id" : 2321502938
    }, {
      "name" : "Fetchnotes",
      "screen_name" : "fetchnotes",
      "indices" : [ 105, 116 ],
      "id_str" : "280073926",
      "id" : 280073926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699632647534993408",
  "text" : "RT @adrienjoly: Thumbs up to @CoreyCrellin for taking over a otherwise-shut-down startup product, and to @fetchnotes for enabling this! \/cc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Corey Crellin",
        "screen_name" : "CoreyCrellin",
        "indices" : [ 13, 26 ],
        "id_str" : "2321502938",
        "id" : 2321502938
      }, {
        "name" : "Fetchnotes",
        "screen_name" : "fetchnotes",
        "indices" : [ 89, 100 ],
        "id_str" : "280073926",
        "id" : 280073926
      }, {
        "name" : "Tiffany Zhong",
        "screen_name" : "tzhongg",
        "indices" : [ 124, 132 ],
        "id_str" : "2458844640",
        "id" : 2458844640
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "699350224142086144",
    "geo" : { },
    "id_str" : "699522085564116992",
    "in_reply_to_user_id" : 2458844640,
    "text" : "Thumbs up to @CoreyCrellin for taking over a otherwise-shut-down startup product, and to @fetchnotes for enabling this! \/cc @tzhongg",
    "id" : 699522085564116992,
    "in_reply_to_status_id" : 699350224142086144,
    "created_at" : "2016-02-16 09:13:56 +0000",
    "in_reply_to_screen_name" : "tzhongg",
    "in_reply_to_user_id_str" : "2458844640",
    "user" : {
      "name" : "Adrien Joly",
      "screen_name" : "adrienjoly",
      "protected" : false,
      "id_str" : "6468662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508699918844698624\/2O1MKUxt_normal.jpeg",
      "id" : 6468662,
      "verified" : false
    }
  },
  "id" : 699632647534993408,
  "created_at" : "2016-02-16 16:33:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Zhong",
      "screen_name" : "tzhongg",
      "indices" : [ 3, 11 ],
      "id_str" : "2458844640",
      "id" : 2458844640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699632598608379904",
  "text" : "RT @tzhongg: It's always awesome when a popular product is about to shut down and someone decides to personally take it over. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tzhongg\/status\/699350224142086144\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/mcsRaPy1qG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbSXUqAUkAAZRYP.png",
        "id_str" : "699350223278084096",
        "id" : 699350223278084096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbSXUqAUkAAZRYP.png",
        "sizes" : [ {
          "h" : 355,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 626,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 626,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 626,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/mcsRaPy1qG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699350224142086144",
    "text" : "It's always awesome when a popular product is about to shut down and someone decides to personally take it over. https:\/\/t.co\/mcsRaPy1qG",
    "id" : 699350224142086144,
    "created_at" : "2016-02-15 21:51:01 +0000",
    "user" : {
      "name" : "Tiffany Zhong",
      "screen_name" : "tzhongg",
      "protected" : false,
      "id_str" : "2458844640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743528627816456192\/npFh139y_normal.jpg",
      "id" : 2458844640,
      "verified" : true
    }
  },
  "id" : 699632598608379904,
  "created_at" : "2016-02-16 16:33:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 8, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/viF6UOs5gF",
      "expanded_url" : "https:\/\/twitter.com\/dullandwicked\/status\/699592375753170945",
      "display_url" : "twitter.com\/dullandwicked\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699629456722419712",
  "text" : "deep... #woo https:\/\/t.co\/viF6UOs5gF",
  "id" : 699629456722419712,
  "created_at" : "2016-02-16 16:20:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "life",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/2qLfCBHlj2",
      "expanded_url" : "https:\/\/twitter.com\/BridgetPhetasy\/status\/699457683070414848",
      "display_url" : "twitter.com\/BridgetPhetasy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699608673124016129",
  "text" : "#life https:\/\/t.co\/2qLfCBHlj2",
  "id" : 699608673124016129,
  "created_at" : "2016-02-16 14:58:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthea Kitching",
      "screen_name" : "KitchyandCo",
      "indices" : [ 3, 15 ],
      "id_str" : "533160609",
      "id" : 533160609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bluefacedleicester",
      "indices" : [ 56, 75 ]
    }, {
      "text" : "happysheep",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699608092862976001",
  "text" : "RT @KitchyandCo: First time Horace has been in the snow #bluefacedleicester #happysheep I think he is a little excited. https:\/\/t.co\/YlpLYM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KitchyandCo\/status\/699531487390126080\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/YlpLYMB3Ju",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbU8LgjWIAAQSIL.jpg",
        "id_str" : "699531485540392960",
        "id" : 699531485540392960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbU8LgjWIAAQSIL.jpg",
        "sizes" : [ {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 756,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 756,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YlpLYMB3Ju"
      } ],
      "hashtags" : [ {
        "text" : "bluefacedleicester",
        "indices" : [ 39, 58 ]
      }, {
        "text" : "happysheep",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699531487390126080",
    "text" : "First time Horace has been in the snow #bluefacedleicester #happysheep I think he is a little excited. https:\/\/t.co\/YlpLYMB3Ju",
    "id" : 699531487390126080,
    "created_at" : "2016-02-16 09:51:17 +0000",
    "user" : {
      "name" : "Anthea Kitching",
      "screen_name" : "KitchyandCo",
      "protected" : false,
      "id_str" : "533160609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733566298232213504\/dYaUN7Mw_normal.jpg",
      "id" : 533160609,
      "verified" : false
    }
  },
  "id" : 699608092862976001,
  "created_at" : "2016-02-16 14:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC15 Arizona",
      "screen_name" : "abc15",
      "indices" : [ 3, 9 ],
      "id_str" : "9721292",
      "id" : 9721292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abc15wx",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "abc15",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699438964256739328",
  "text" : "RT @abc15: BEAUTIFUL! \n\nA group of wild donkeys were seen at Lake Pleasant as the sun sets. Pic: Jenny L. #abc15wx #abc15 https:\/\/t.co\/PII1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abc15\/status\/699412501872697345\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/PII1V6W8IC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbTPgLMXIAUBnAo.jpg",
        "id_str" : "699411993816670213",
        "id" : 699411993816670213,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbTPgLMXIAUBnAo.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/PII1V6W8IC"
      } ],
      "hashtags" : [ {
        "text" : "abc15wx",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "abc15",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699412501872697345",
    "text" : "BEAUTIFUL! \n\nA group of wild donkeys were seen at Lake Pleasant as the sun sets. Pic: Jenny L. #abc15wx #abc15 https:\/\/t.co\/PII1V6W8IC",
    "id" : 699412501872697345,
    "created_at" : "2016-02-16 01:58:29 +0000",
    "user" : {
      "name" : "ABC15 Arizona",
      "screen_name" : "abc15",
      "protected" : false,
      "id_str" : "9721292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550984712378806273\/GQhFtyB8_normal.jpeg",
      "id" : 9721292,
      "verified" : true
    }
  },
  "id" : 699438964256739328,
  "created_at" : "2016-02-16 03:43:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 117, 127 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/o0QFvvjCBp",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/2\/15\/10980830\/oprah-winfrey-weight-watchers?utm_campaign=vox&utm_content=feature%3Afixed&utm_medium=social&utm_source=twitter",
      "display_url" : "vox.com\/2016\/2\/15\/1098\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699393253938982912",
  "text" : "I've spent years trying to get skinny. Oprah's Weight Watchers ads convinced me to stop. https:\/\/t.co\/o0QFvvjCBp via @voxdotcom",
  "id" : 699393253938982912,
  "created_at" : "2016-02-16 00:42:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/rkmo5bA4Nj",
      "expanded_url" : "http:\/\/www.cbc.ca\/1.2663585",
      "display_url" : "cbc.ca\/1.2663585"
    } ]
  },
  "geo" : { },
  "id_str" : "699393202000891904",
  "text" : "Science confirms you will never lose those extra pounds https:\/\/t.co\/rkmo5bA4Nj",
  "id" : 699393202000891904,
  "created_at" : "2016-02-16 00:41:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699358526909607938",
  "geo" : { },
  "id_str" : "699361039733944321",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields lol.. precious!",
  "id" : 699361039733944321,
  "in_reply_to_status_id" : 699358526909607938,
  "created_at" : "2016-02-15 22:34:00 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Humdrum Harv",
      "screen_name" : "harvardheinous",
      "indices" : [ 3, 18 ],
      "id_str" : "22117992",
      "id" : 22117992
    }, {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 66, 82 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/harvardheinous\/status\/699356708234207232\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/sonvRCGJIT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbSdNA_UcAERb2N.jpg",
      "id_str" : "699356689078710273",
      "id" : 699356689078710273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbSdNA_UcAERb2N.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/sonvRCGJIT"
    } ],
    "hashtags" : [ {
      "text" : "IBM",
      "indices" : [ 36, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699360680718295040",
  "text" : "RT @harvardheinous: Hudson River at #IBM Poughkeepsie right now.  @TheHudsonValley https:\/\/t.co\/sonvRCGJIT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Hudson Valley",
        "screen_name" : "TheHudsonValley",
        "indices" : [ 46, 62 ],
        "id_str" : "102313523",
        "id" : 102313523
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/harvardheinous\/status\/699356708234207232\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/sonvRCGJIT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbSdNA_UcAERb2N.jpg",
        "id_str" : "699356689078710273",
        "id" : 699356689078710273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbSdNA_UcAERb2N.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/sonvRCGJIT"
      } ],
      "hashtags" : [ {
        "text" : "IBM",
        "indices" : [ 16, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699356708234207232",
    "text" : "Hudson River at #IBM Poughkeepsie right now.  @TheHudsonValley https:\/\/t.co\/sonvRCGJIT",
    "id" : 699356708234207232,
    "created_at" : "2016-02-15 22:16:47 +0000",
    "user" : {
      "name" : "Humdrum Harv",
      "screen_name" : "harvardheinous",
      "protected" : false,
      "id_str" : "22117992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459339970176512003\/o3FndGnL_normal.jpeg",
      "id" : 22117992,
      "verified" : false
    }
  },
  "id" : 699360680718295040,
  "created_at" : "2016-02-15 22:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "helen warlow",
      "screen_name" : "HWarlow",
      "indices" : [ 3, 11 ],
      "id_str" : "2328834820",
      "id" : 2328834820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699327091171528705",
  "text" : "RT @HWarlow: This is such a sweet image, it's an etching by Nicholas Wilson who paints as well as etches, usually wildlife. https:\/\/t.co\/kZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HWarlow\/status\/699324376475398144\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/kZceT6YXr8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR_0KDWIAAVODm.jpg",
        "id_str" : "699324376177582080",
        "id" : 699324376177582080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR_0KDWIAAVODm.jpg",
        "sizes" : [ {
          "h" : 806,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 806,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 806,
          "resize" : "fit",
          "w" : 570
        } ],
        "display_url" : "pic.twitter.com\/kZceT6YXr8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699324376475398144",
    "text" : "This is such a sweet image, it's an etching by Nicholas Wilson who paints as well as etches, usually wildlife. https:\/\/t.co\/kZceT6YXr8",
    "id" : 699324376475398144,
    "created_at" : "2016-02-15 20:08:18 +0000",
    "user" : {
      "name" : "helen warlow",
      "screen_name" : "HWarlow",
      "protected" : false,
      "id_str" : "2328834820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767102847318159360\/EcYqKbx__normal.jpg",
      "id" : 2328834820,
      "verified" : false
    }
  },
  "id" : 699327091171528705,
  "created_at" : "2016-02-15 20:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison O'Neill",
      "screen_name" : "woolismybread",
      "indices" : [ 3, 17 ],
      "id_str" : "2221397359",
      "id" : 2221397359
    }, {
      "name" : "Countryside",
      "screen_name" : "NFUCountryside",
      "indices" : [ 51, 66 ],
      "id_str" : "293966763",
      "id" : 293966763
    }, {
      "name" : "Cumbria Weather",
      "screen_name" : "CumbriaWeather",
      "indices" : [ 67, 82 ],
      "id_str" : "320075522",
      "id" : 320075522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ejN89ydetD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zDTW8AA99RH.jpg",
      "id_str" : "699315561092804608",
      "id" : 699315561092804608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zDTW8AA99RH.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ejN89ydetD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ejN89ydetD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zDeWEAE9QXM.jpg",
      "id_str" : "699315561138884609",
      "id" : 699315561138884609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zDeWEAE9QXM.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ejN89ydetD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ejN89ydetD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zE4W0AIy4mn.jpg",
      "id_str" : "699315561516421122",
      "id" : 699315561516421122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zE4W0AIy4mn.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ejN89ydetD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ejN89ydetD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zKtWEAEpHeT.jpg",
      "id_str" : "699315563080847361",
      "id" : 699315563080847361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zKtWEAEpHeT.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ejN89ydetD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699318274216103936",
  "text" : "RT @woolismybread: Stunning day. On farm and fell. @NFUCountryside @CumbriaWeather https:\/\/t.co\/ejN89ydetD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Countryside",
        "screen_name" : "NFUCountryside",
        "indices" : [ 32, 47 ],
        "id_str" : "293966763",
        "id" : 293966763
      }, {
        "name" : "Cumbria Weather",
        "screen_name" : "CumbriaWeather",
        "indices" : [ 48, 63 ],
        "id_str" : "320075522",
        "id" : 320075522
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/ejN89ydetD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zDTW8AA99RH.jpg",
        "id_str" : "699315561092804608",
        "id" : 699315561092804608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zDTW8AA99RH.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ejN89ydetD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/ejN89ydetD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zDeWEAE9QXM.jpg",
        "id_str" : "699315561138884609",
        "id" : 699315561138884609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zDeWEAE9QXM.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ejN89ydetD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/ejN89ydetD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zE4W0AIy4mn.jpg",
        "id_str" : "699315561516421122",
        "id" : 699315561516421122,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zE4W0AIy4mn.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ejN89ydetD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woolismybread\/status\/699315705238462464\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/ejN89ydetD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbR3zKtWEAEpHeT.jpg",
        "id_str" : "699315563080847361",
        "id" : 699315563080847361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbR3zKtWEAEpHeT.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ejN89ydetD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699315705238462464",
    "text" : "Stunning day. On farm and fell. @NFUCountryside @CumbriaWeather https:\/\/t.co\/ejN89ydetD",
    "id" : 699315705238462464,
    "created_at" : "2016-02-15 19:33:51 +0000",
    "user" : {
      "name" : "Alison O'Neill",
      "screen_name" : "woolismybread",
      "protected" : false,
      "id_str" : "2221397359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555055062582824960\/MmiC-Umy_normal.jpeg",
      "id" : 2221397359,
      "verified" : false
    }
  },
  "id" : 699318274216103936,
  "created_at" : "2016-02-15 19:44:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 0, 14 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699303362211266560",
  "geo" : { },
  "id_str" : "699305215112146947",
  "in_reply_to_user_id" : 272369448,
  "text" : "@Swanwhisperer you get smooched?",
  "id" : 699305215112146947,
  "in_reply_to_status_id" : 699303362211266560,
  "created_at" : "2016-02-15 18:52:10 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/M94AsFH02r",
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/699303362211266560",
      "display_url" : "twitter.com\/Swanwhisperer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699304289987117056",
  "text" : "precious. wanna smooch them. https:\/\/t.co\/M94AsFH02r",
  "id" : 699304289987117056,
  "created_at" : "2016-02-15 18:48:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Reynolds",
      "screen_name" : "PeterReynoldsVA",
      "indices" : [ 3, 19 ],
      "id_str" : "2836904676",
      "id" : 2836904676
    }, {
      "name" : "R.C. Bray",
      "screen_name" : "audbks",
      "indices" : [ 80, 87 ],
      "id_str" : "2293107631",
      "id" : 2293107631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699295434792116225",
  "text" : "RT @PeterReynoldsVA: Ep. 2 of The Vocal Booth is out with the prolific RC Bray (@audbks)!  Narrated a little book called...The Martian:  ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "R.C. Bray",
        "screen_name" : "audbks",
        "indices" : [ 59, 66 ],
        "id_str" : "2293107631",
        "id" : 2293107631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/6HznuC6wcQ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=jHLkhjT7DTQ",
        "display_url" : "youtube.com\/watch?v=jHLkhj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697816864563597313",
    "text" : "Ep. 2 of The Vocal Booth is out with the prolific RC Bray (@audbks)!  Narrated a little book called...The Martian:  https:\/\/t.co\/6HznuC6wcQ",
    "id" : 697816864563597313,
    "created_at" : "2016-02-11 16:17:59 +0000",
    "user" : {
      "name" : "Peter Reynolds",
      "screen_name" : "PeterReynoldsVA",
      "protected" : false,
      "id_str" : "2836904676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594137559803932672\/UpzYKn7Q_normal.jpg",
      "id" : 2836904676,
      "verified" : false
    }
  },
  "id" : 699295434792116225,
  "created_at" : "2016-02-15 18:13:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 54, 64 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/oSPnyjM7nC",
      "expanded_url" : "https:\/\/shar.es\/14yu83",
      "display_url" : "shar.es\/14yu83"
    } ]
  },
  "geo" : { },
  "id_str" : "699287622980608000",
  "text" : "RT @dwaynereaves: Orange\n https:\/\/t.co\/oSPnyjM7nC via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 36, 46 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/oSPnyjM7nC",
        "expanded_url" : "https:\/\/shar.es\/14yu83",
        "display_url" : "shar.es\/14yu83"
      } ]
    },
    "geo" : { },
    "id_str" : "699271752493490176",
    "text" : "Orange\n https:\/\/t.co\/oSPnyjM7nC via @sharethis",
    "id" : 699271752493490176,
    "created_at" : "2016-02-15 16:39:12 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 699287622980608000,
  "created_at" : "2016-02-15 17:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doubting Pastor",
      "screen_name" : "doubtingpastor",
      "indices" : [ 3, 18 ],
      "id_str" : "4667849280",
      "id" : 4667849280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699286208749375489",
  "text" : "RT @doubtingpastor: Our inability to nail down who God is and how He works speaks to His divinity. A God I fully understand wouldn't be muc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685294416953647104",
    "text" : "Our inability to nail down who God is and how He works speaks to His divinity. A God I fully understand wouldn't be much of a God at all!",
    "id" : 685294416953647104,
    "created_at" : "2016-01-08 02:58:15 +0000",
    "user" : {
      "name" : "Doubting Pastor",
      "screen_name" : "doubtingpastor",
      "protected" : false,
      "id_str" : "4667849280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681642268705435648\/9ru70K7w_normal.jpg",
      "id" : 4667849280,
      "verified" : false
    }
  },
  "id" : 699286208749375489,
  "created_at" : "2016-02-15 17:36:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Wyden",
      "screen_name" : "RonWyden",
      "indices" : [ 3, 12 ],
      "id_str" : "250188760",
      "id" : 250188760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/y2uT3Ncy7e",
      "expanded_url" : "https:\/\/medium.com\/@RonWyden\/internet-access-is-permanently-tax-free-finally-666eb9063cff#.af8ppl9jb",
      "display_url" : "medium.com\/@RonWyden\/inte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699286134057234432",
  "text" : "RT @RonWyden: Internet access is permanently tax free. Finally. Big win for American consumers &amp; businesses today: https:\/\/t.co\/y2uT3Ncy7e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/y2uT3Ncy7e",
        "expanded_url" : "https:\/\/medium.com\/@RonWyden\/internet-access-is-permanently-tax-free-finally-666eb9063cff#.af8ppl9jb",
        "display_url" : "medium.com\/@RonWyden\/inte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697841297814642688",
    "text" : "Internet access is permanently tax free. Finally. Big win for American consumers &amp; businesses today: https:\/\/t.co\/y2uT3Ncy7e",
    "id" : 697841297814642688,
    "created_at" : "2016-02-11 17:55:05 +0000",
    "user" : {
      "name" : "Ron Wyden",
      "screen_name" : "RonWyden",
      "protected" : false,
      "id_str" : "250188760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649659158531297280\/w_0M4leg_normal.jpg",
      "id" : 250188760,
      "verified" : true
    }
  },
  "id" : 699286134057234432,
  "created_at" : "2016-02-15 17:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Batty",
      "screen_name" : "chasebatty",
      "indices" : [ 3, 14 ],
      "id_str" : "20478304",
      "id" : 20478304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/16Dpw7t7x4",
      "expanded_url" : "https:\/\/twitter.com\/asksciencemike\/status\/699223164069507072",
      "display_url" : "twitter.com\/asksciencemike\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699286062900912128",
  "text" : "RT @chasebatty: If there is such a thing as a simple explanation of gravity waves and their importance, this is it.  https:\/\/t.co\/16Dpw7t7x4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/16Dpw7t7x4",
        "expanded_url" : "https:\/\/twitter.com\/asksciencemike\/status\/699223164069507072",
        "display_url" : "twitter.com\/asksciencemike\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699251514167066624",
    "text" : "If there is such a thing as a simple explanation of gravity waves and their importance, this is it.  https:\/\/t.co\/16Dpw7t7x4",
    "id" : 699251514167066624,
    "created_at" : "2016-02-15 15:18:47 +0000",
    "user" : {
      "name" : "Chase Batty",
      "screen_name" : "chasebatty",
      "protected" : false,
      "id_str" : "20478304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1259277195\/AA_normal.jpg",
      "id" : 20478304,
      "verified" : false
    }
  },
  "id" : 699286062900912128,
  "created_at" : "2016-02-15 17:36:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doubting Pastor",
      "screen_name" : "doubtingpastor",
      "indices" : [ 3, 18 ],
      "id_str" : "4667849280",
      "id" : 4667849280
    }, {
      "name" : "Ask Science Mike",
      "screen_name" : "asksciencemike",
      "indices" : [ 31, 46 ],
      "id_str" : "2970458165",
      "id" : 2970458165
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boom",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699285978905710594",
  "text" : "RT @doubtingpastor: Just heard @asksciencemike say \"Every Christian is some other Christian's heretic.\" \uD83D\uDE33 #boom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ask Science Mike",
        "screen_name" : "asksciencemike",
        "indices" : [ 11, 26 ],
        "id_str" : "2970458165",
        "id" : 2970458165
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "boom",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699252314293407744",
    "text" : "Just heard @asksciencemike say \"Every Christian is some other Christian's heretic.\" \uD83D\uDE33 #boom",
    "id" : 699252314293407744,
    "created_at" : "2016-02-15 15:21:57 +0000",
    "user" : {
      "name" : "Doubting Pastor",
      "screen_name" : "doubtingpastor",
      "protected" : false,
      "id_str" : "4667849280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681642268705435648\/9ru70K7w_normal.jpg",
      "id" : 4667849280,
      "verified" : false
    }
  },
  "id" : 699285978905710594,
  "created_at" : "2016-02-15 17:35:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rescuedducks",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "rescuedgoose",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/G7rdnbgvKC",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BB0Ll1zBH2d\/",
      "display_url" : "instagram.com\/p\/BB0Ll1zBH2d\/"
    } ]
  },
  "geo" : { },
  "id_str" : "699285390688194564",
  "text" : "RT @ducksandclucks: Joey takes his new job of sheep herding dog very seriously. #rescuedducks #rescuedgoose\u2026 https:\/\/t.co\/G7rdnbgvKC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rescuedducks",
        "indices" : [ 60, 73 ]
      }, {
        "text" : "rescuedgoose",
        "indices" : [ 74, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/G7rdnbgvKC",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BB0Ll1zBH2d\/",
        "display_url" : "instagram.com\/p\/BB0Ll1zBH2d\/"
      } ]
    },
    "geo" : { },
    "id_str" : "699284410315702272",
    "text" : "Joey takes his new job of sheep herding dog very seriously. #rescuedducks #rescuedgoose\u2026 https:\/\/t.co\/G7rdnbgvKC",
    "id" : 699284410315702272,
    "created_at" : "2016-02-15 17:29:30 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 699285390688194564,
  "created_at" : "2016-02-15 17:33:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "weirdnews share",
      "screen_name" : "weirdnewsshare",
      "indices" : [ 3, 18 ],
      "id_str" : "600601851",
      "id" : 600601851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/6gAa69wW4S",
      "expanded_url" : "http:\/\/dlvr.it\/KWNHSW",
      "display_url" : "dlvr.it\/KWNHSW"
    } ]
  },
  "geo" : { },
  "id_str" : "699285041147465728",
  "text" : "RT @weirdnewsshare: Government Says It Has Lost More UFO X-Files - Huffington Post https:\/\/t.co\/6gAa69wW4S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/6gAa69wW4S",
        "expanded_url" : "http:\/\/dlvr.it\/KWNHSW",
        "display_url" : "dlvr.it\/KWNHSW"
      } ]
    },
    "geo" : { },
    "id_str" : "699284425482199040",
    "text" : "Government Says It Has Lost More UFO X-Files - Huffington Post https:\/\/t.co\/6gAa69wW4S",
    "id" : 699284425482199040,
    "created_at" : "2016-02-15 17:29:33 +0000",
    "user" : {
      "name" : "weirdnews share",
      "screen_name" : "weirdnewsshare",
      "protected" : false,
      "id_str" : "600601851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2393949414\/6b2m8sn9j9m2wvgf95vn_normal.jpeg",
      "id" : 600601851,
      "verified" : false
    }
  },
  "id" : 699285041147465728,
  "created_at" : "2016-02-15 17:32:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Internet",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "social",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "media",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "users",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "vaccines",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/59yQXeHCmB",
      "expanded_url" : "http:\/\/bit.ly\/214MTw7",
      "display_url" : "bit.ly\/214MTw7"
    } ]
  },
  "geo" : { },
  "id_str" : "699284893013041154",
  "text" : "RT @HealthRanger: #Internet monitoring system to stalk #social #media #users who question safety of #vaccines: https:\/\/t.co\/59yQXeHCmB http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthRanger\/status\/699284548568231936\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/dF7P4Szk86",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbRbl4YUAAE7bEI.jpg",
        "id_str" : "699284548496916481",
        "id" : 699284548496916481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbRbl4YUAAE7bEI.jpg",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/dF7P4Szk86"
      } ],
      "hashtags" : [ {
        "text" : "Internet",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "social",
        "indices" : [ 37, 44 ]
      }, {
        "text" : "media",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "users",
        "indices" : [ 52, 58 ]
      }, {
        "text" : "vaccines",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/59yQXeHCmB",
        "expanded_url" : "http:\/\/bit.ly\/214MTw7",
        "display_url" : "bit.ly\/214MTw7"
      } ]
    },
    "geo" : { },
    "id_str" : "699284548568231936",
    "text" : "#Internet monitoring system to stalk #social #media #users who question safety of #vaccines: https:\/\/t.co\/59yQXeHCmB https:\/\/t.co\/dF7P4Szk86",
    "id" : 699284548568231936,
    "created_at" : "2016-02-15 17:30:03 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 699284893013041154,
  "created_at" : "2016-02-15 17:31:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Audiobook",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/1vLT0ZY0iL",
      "expanded_url" : "https:\/\/youtu.be\/ojxzeV1L_UU",
      "display_url" : "youtu.be\/ojxzeV1L_UU"
    } ]
  },
  "geo" : { },
  "id_str" : "699275974756712448",
  "text" : "Awesome Audio books FREE #Audiobook Winners Are??????? https:\/\/t.co\/1vLT0ZY0iL",
  "id" : 699275974756712448,
  "created_at" : "2016-02-15 16:55:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699270858897018880",
  "text" : "I'm 24% through Fear the Sky (Unabridged) by Stephen Moss, narrated by R.C. Bray on my Audible app.",
  "id" : 699270858897018880,
  "created_at" : "2016-02-15 16:35:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oblivia",
      "screen_name" : "aveuaskew",
      "indices" : [ 3, 13 ],
      "id_str" : "580215009",
      "id" : 580215009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699267114394382339",
  "text" : "RT @aveuaskew: Some people hate themselves so much they punish you for loving them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698755010838994944",
    "text" : "Some people hate themselves so much they punish you for loving them.",
    "id" : 698755010838994944,
    "created_at" : "2016-02-14 06:25:51 +0000",
    "user" : {
      "name" : "Oblivia",
      "screen_name" : "aveuaskew",
      "protected" : false,
      "id_str" : "580215009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793996538787676160\/nVkMLfbf_normal.jpg",
      "id" : 580215009,
      "verified" : false
    }
  },
  "id" : 699267114394382339,
  "created_at" : "2016-02-15 16:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophie Calder",
      "screen_name" : "SophCalder",
      "indices" : [ 3, 14 ],
      "id_str" : "51692793",
      "id" : 51692793
    }, {
      "name" : "Sarah Pinborough",
      "screen_name" : "SarahPinborough",
      "indices" : [ 99, 115 ],
      "id_str" : "300246481",
      "id" : 300246481
    }, {
      "name" : "Claire Frost",
      "screen_name" : "FabFrosty",
      "indices" : [ 116, 126 ],
      "id_str" : "513740773",
      "id" : 513740773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "13Minutes",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699265183483621377",
  "text" : "RT @SophCalder: An unsettling psychological thriller...the scary world of teenage girls #13Minutes @SarahPinborough @FabFrosty https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Pinborough",
        "screen_name" : "SarahPinborough",
        "indices" : [ 83, 99 ],
        "id_str" : "300246481",
        "id" : 300246481
      }, {
        "name" : "Claire Frost",
        "screen_name" : "FabFrosty",
        "indices" : [ 100, 110 ],
        "id_str" : "513740773",
        "id" : 513740773
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SophCalder\/status\/699175773257777152\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/BwrffVbWOr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbP4qUYWEAAZL-L.jpg",
        "id_str" : "699175773081571328",
        "id" : 699175773081571328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbP4qUYWEAAZL-L.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/BwrffVbWOr"
      } ],
      "hashtags" : [ {
        "text" : "13Minutes",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699175773257777152",
    "text" : "An unsettling psychological thriller...the scary world of teenage girls #13Minutes @SarahPinborough @FabFrosty https:\/\/t.co\/BwrffVbWOr",
    "id" : 699175773257777152,
    "created_at" : "2016-02-15 10:17:49 +0000",
    "user" : {
      "name" : "Sophie Calder",
      "screen_name" : "SophCalder",
      "protected" : false,
      "id_str" : "51692793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522776412873187328\/s3gztJB7_normal.jpeg",
      "id" : 51692793,
      "verified" : false
    }
  },
  "id" : 699265183483621377,
  "created_at" : "2016-02-15 16:13:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Breakwell",
      "screen_name" : "XplodingUnicorn",
      "indices" : [ 3, 19 ],
      "id_str" : "780104972",
      "id" : 780104972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699262409496793089",
  "text" : "RT @XplodingUnicorn: My toddler is walking around the house saying \"Oh no!\" over and over.\n\nAt first it was cute, but now I'm afraid she kn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699245637645299712",
    "text" : "My toddler is walking around the house saying \"Oh no!\" over and over.\n\nAt first it was cute, but now I'm afraid she knows something I don't.",
    "id" : 699245637645299712,
    "created_at" : "2016-02-15 14:55:26 +0000",
    "user" : {
      "name" : "James Breakwell",
      "screen_name" : "XplodingUnicorn",
      "protected" : false,
      "id_str" : "780104972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442499711799283713\/zgRMtvS-_normal.jpeg",
      "id" : 780104972,
      "verified" : true
    }
  },
  "id" : 699262409496793089,
  "created_at" : "2016-02-15 16:02:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Women",
      "screen_name" : "Epic_Women",
      "indices" : [ 3, 14 ],
      "id_str" : "169291609",
      "id" : 169291609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699262152109137920",
  "text" : "RT @Epic_Women: Don't hold to anger, hurt or pain. They steal your energy and keep you from love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699258812944027648",
    "text" : "Don't hold to anger, hurt or pain. They steal your energy and keep you from love.",
    "id" : 699258812944027648,
    "created_at" : "2016-02-15 15:47:47 +0000",
    "user" : {
      "name" : "Epic Women",
      "screen_name" : "Epic_Women",
      "protected" : false,
      "id_str" : "169291609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2689948123\/6ffee16f8c24a438eedac169e5ce80f3_normal.jpeg",
      "id" : 169291609,
      "verified" : false
    }
  },
  "id" : 699262152109137920,
  "created_at" : "2016-02-15 16:01:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699261925725761542",
  "text" : "RT @Swanwhisperer: The Sun is Shinning the Bees are Buzzing and Birds Singing , Mute swans Nesting It can only mean that one thing is on my\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699174321625919488",
    "text" : "The Sun is Shinning the Bees are Buzzing and Birds Singing , Mute swans Nesting It can only mean that one thing is on my patch in Cheshire",
    "id" : 699174321625919488,
    "created_at" : "2016-02-15 10:12:02 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 699261925725761542,
  "created_at" : "2016-02-15 16:00:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25LaQuette\uD83D\uDD25",
      "screen_name" : "LaQuetteLikes",
      "indices" : [ 3, 17 ],
      "id_str" : "2213246778",
      "id" : 2213246778
    }, {
      "name" : "Amber Patrice Riley",
      "screen_name" : "MsAmberPRiley",
      "indices" : [ 30, 44 ],
      "id_str" : "127431090",
      "id" : 127431090
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slay",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "yass",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698994156232953856",
  "text" : "RT @LaQuetteLikes: The lovely @MsAmberPRiley  reinforces my belief: Sexy isn't a dress size, it's what you carry inside. #slay #yass \uD83D\uDD25 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amber Patrice Riley",
        "screen_name" : "MsAmberPRiley",
        "indices" : [ 11, 25 ],
        "id_str" : "127431090",
        "id" : 127431090
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaQuetteLikes\/status\/698976138249564162\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/B0t4TZ0lvD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbNDF-jWAAASNST.jpg",
        "id_str" : "698976137142206464",
        "id" : 698976137142206464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbNDF-jWAAASNST.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 730
        } ],
        "display_url" : "pic.twitter.com\/B0t4TZ0lvD"
      } ],
      "hashtags" : [ {
        "text" : "slay",
        "indices" : [ 102, 107 ]
      }, {
        "text" : "yass",
        "indices" : [ 108, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698976138249564162",
    "text" : "The lovely @MsAmberPRiley  reinforces my belief: Sexy isn't a dress size, it's what you carry inside. #slay #yass \uD83D\uDD25 https:\/\/t.co\/B0t4TZ0lvD",
    "id" : 698976138249564162,
    "created_at" : "2016-02-14 21:04:32 +0000",
    "user" : {
      "name" : "\uD83D\uDD25LaQuette\uD83D\uDD25",
      "screen_name" : "LaQuetteLikes",
      "protected" : false,
      "id_str" : "2213246778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771421730535510016\/-tPF541__normal.jpg",
      "id" : 2213246778,
      "verified" : false
    }
  },
  "id" : 698994156232953856,
  "created_at" : "2016-02-14 22:16:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cornelia",
      "screen_name" : "PaladinCornelia",
      "indices" : [ 3, 19 ],
      "id_str" : "1282197158",
      "id" : 1282197158
    }, {
      "name" : "John Dickerson",
      "screen_name" : "jdickerson",
      "indices" : [ 26, 37 ],
      "id_str" : "4119741",
      "id" : 4119741
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 85, 93 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698990302842003456",
  "text" : "RT @PaladinCornelia: Dear @jdickerson,\n\nWould you please forward this information to @tedcruz ?\n\nSigned,\nThe American People https:\/\/t.co\/x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Dickerson",
        "screen_name" : "jdickerson",
        "indices" : [ 5, 16 ],
        "id_str" : "4119741",
        "id" : 4119741
      }, {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 64, 72 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PaladinCornelia\/status\/698957210190123008\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/xXboz5hGC8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbMx4PNUkAAL_BS.png",
        "id_str" : "698957209397399552",
        "id" : 698957209397399552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbMx4PNUkAAL_BS.png",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 472
        } ],
        "display_url" : "pic.twitter.com\/xXboz5hGC8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698957210190123008",
    "text" : "Dear @jdickerson,\n\nWould you please forward this information to @tedcruz ?\n\nSigned,\nThe American People https:\/\/t.co\/xXboz5hGC8",
    "id" : 698957210190123008,
    "created_at" : "2016-02-14 19:49:19 +0000",
    "user" : {
      "name" : "Cornelia",
      "screen_name" : "PaladinCornelia",
      "protected" : false,
      "id_str" : "1282197158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616623141419257856\/C1IMMpAK_normal.png",
      "id" : 1282197158,
      "verified" : false
    }
  },
  "id" : 698990302842003456,
  "created_at" : "2016-02-14 22:00:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    }, {
      "name" : "Juha Marila",
      "screen_name" : "psjuma",
      "indices" : [ 23, 30 ],
      "id_str" : "70630505",
      "id" : 70630505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psychiatry",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698981413421522948",
  "text" : "RT @JeffreyGuterman: . @psjuma The field of #psychiatry created the myth there is such a thing as objective reality, and only sane people h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juha Marila",
        "screen_name" : "psjuma",
        "indices" : [ 2, 9 ],
        "id_str" : "70630505",
        "id" : 70630505
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "psychiatry",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "698979894047408128",
    "geo" : { },
    "id_str" : "698981140816855040",
    "in_reply_to_user_id" : 70630505,
    "text" : ". @psjuma The field of #psychiatry created the myth there is such a thing as objective reality, and only sane people have access to it.",
    "id" : 698981140816855040,
    "in_reply_to_status_id" : 698979894047408128,
    "created_at" : "2016-02-14 21:24:25 +0000",
    "in_reply_to_screen_name" : "psjuma",
    "in_reply_to_user_id_str" : "70630505",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 698981413421522948,
  "created_at" : "2016-02-14 21:25:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 3, 15 ],
      "id_str" : "27905866",
      "id" : 27905866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698981385781043205",
  "text" : "RT @rev_heather: We need new words for pervasive sadness that isn't clinical depression, for constant worrying that isn't clinical anxiety.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698981168209907712",
    "text" : "We need new words for pervasive sadness that isn't clinical depression, for constant worrying that isn't clinical anxiety.",
    "id" : 698981168209907712,
    "created_at" : "2016-02-14 21:24:31 +0000",
    "user" : {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "protected" : false,
      "id_str" : "27905866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741797818600435712\/MMrRhgJC_normal.jpg",
      "id" : 27905866,
      "verified" : false
    }
  },
  "id" : 698981385781043205,
  "created_at" : "2016-02-14 21:25:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698949759831244801",
  "text" : "RT @benjamincorey: The idea of being a strict \"constitutional originalist\" sorta seems like the equivalent of being a KJV only fundamentali\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698699473334063104",
    "text" : "The idea of being a strict \"constitutional originalist\" sorta seems like the equivalent of being a KJV only fundamentalist.",
    "id" : 698699473334063104,
    "created_at" : "2016-02-14 02:45:10 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 698949759831244801,
  "created_at" : "2016-02-14 19:19:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "indices" : [ 3, 18 ],
      "id_str" : "24254537",
      "id" : 24254537
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GrumpyTheology\/status\/698941784810979332\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/QRIwTM9Xk1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbMj2XCXIAAywN-.jpg",
      "id_str" : "698941783976386560",
      "id" : 698941783976386560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbMj2XCXIAAywN-.jpg",
      "sizes" : [ {
        "h" : 154,
        "resize" : "fit",
        "w" : 177
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 177
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 177
      }, {
        "h" : 154,
        "resize" : "fit",
        "w" : 177
      } ],
      "display_url" : "pic.twitter.com\/QRIwTM9Xk1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698945953752080384",
  "text" : "RT @GrumpyTheology: Facebook now has a sticker pack that includes these lesbian otters. Happy valentines day! https:\/\/t.co\/QRIwTM9Xk1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GrumpyTheology\/status\/698941784810979332\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/QRIwTM9Xk1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbMj2XCXIAAywN-.jpg",
        "id_str" : "698941783976386560",
        "id" : 698941783976386560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbMj2XCXIAAywN-.jpg",
        "sizes" : [ {
          "h" : 154,
          "resize" : "fit",
          "w" : 177
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 177
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 177
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 177
        } ],
        "display_url" : "pic.twitter.com\/QRIwTM9Xk1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698941784810979332",
    "text" : "Facebook now has a sticker pack that includes these lesbian otters. Happy valentines day! https:\/\/t.co\/QRIwTM9Xk1",
    "id" : 698941784810979332,
    "created_at" : "2016-02-14 18:48:01 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 698945953752080384,
  "created_at" : "2016-02-14 19:04:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/698903815299452928\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/1ehjwDYXUV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbMBTtXWIAAjOJJ.jpg",
      "id_str" : "698903805279215616",
      "id" : 698903805279215616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbMBTtXWIAAjOJJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 696
      }, {
        "h" : 883,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 696
      } ],
      "display_url" : "pic.twitter.com\/1ehjwDYXUV"
    } ],
    "hashtags" : [ {
      "text" : "Valentines",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698921658300678144",
  "text" : "RT @Interior: Happy #Valentines Day! Nothing says \uD83D\uDC93 like owls snuggling in a heart-shaped hole. Pic: Jon LeVasseur https:\/\/t.co\/1ehjwDYXUV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/698903815299452928\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/1ehjwDYXUV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbMBTtXWIAAjOJJ.jpg",
        "id_str" : "698903805279215616",
        "id" : 698903805279215616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbMBTtXWIAAjOJJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 696
        }, {
          "h" : 883,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 696
        } ],
        "display_url" : "pic.twitter.com\/1ehjwDYXUV"
      } ],
      "hashtags" : [ {
        "text" : "Valentines",
        "indices" : [ 6, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698903815299452928",
    "text" : "Happy #Valentines Day! Nothing says \uD83D\uDC93 like owls snuggling in a heart-shaped hole. Pic: Jon LeVasseur https:\/\/t.co\/1ehjwDYXUV",
    "id" : 698903815299452928,
    "created_at" : "2016-02-14 16:17:09 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 698921658300678144,
  "created_at" : "2016-02-14 17:28:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Downey Jr",
      "screen_name" : "RobertDowneyJr",
      "indices" : [ 3, 18 ],
      "id_str" : "47786101",
      "id" : 47786101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RobertDowneyJr\/status\/698917643223314432\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/UiqU8B90MP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbJsLGIUsAE-FX8.jpg",
      "id_str" : "698739830075731969",
      "id" : 698739830075731969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbJsLGIUsAE-FX8.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/UiqU8B90MP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698919400695599104",
  "text" : "RT @RobertDowneyJr: Happy Valentine's Day! \n\n(Credit: Sekra on Tumblr) https:\/\/t.co\/UiqU8B90MP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RobertDowneyJr\/status\/698917643223314432\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/UiqU8B90MP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbJsLGIUsAE-FX8.jpg",
        "id_str" : "698739830075731969",
        "id" : 698739830075731969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbJsLGIUsAE-FX8.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/UiqU8B90MP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698917643223314432",
    "text" : "Happy Valentine's Day! \n\n(Credit: Sekra on Tumblr) https:\/\/t.co\/UiqU8B90MP",
    "id" : 698917643223314432,
    "created_at" : "2016-02-14 17:12:06 +0000",
    "user" : {
      "name" : "Robert Downey Jr",
      "screen_name" : "RobertDowneyJr",
      "protected" : false,
      "id_str" : "47786101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712016346775564289\/ajnm_P3F_normal.jpg",
      "id" : 47786101,
      "verified" : true
    }
  },
  "id" : 698919400695599104,
  "created_at" : "2016-02-14 17:19:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 61, 71 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ZDYQcKzDAa",
      "expanded_url" : "https:\/\/shar.es\/14xqD0",
      "display_url" : "shar.es\/14xqD0"
    } ]
  },
  "geo" : { },
  "id_str" : "698916346499878914",
  "text" : "RT @dwaynereaves: Winter Sunset\n https:\/\/t.co\/ZDYQcKzDAa via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 43, 53 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/ZDYQcKzDAa",
        "expanded_url" : "https:\/\/shar.es\/14xqD0",
        "display_url" : "shar.es\/14xqD0"
      } ]
    },
    "geo" : { },
    "id_str" : "698900602961715202",
    "text" : "Winter Sunset\n https:\/\/t.co\/ZDYQcKzDAa via @sharethis",
    "id" : 698900602961715202,
    "created_at" : "2016-02-14 16:04:23 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 698916346499878914,
  "created_at" : "2016-02-14 17:06:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bookish",
      "screen_name" : "BookishHQ",
      "indices" : [ 3, 13 ],
      "id_str" : "322830973",
      "id" : 322830973
    }, {
      "name" : "Aziz Ansari",
      "screen_name" : "azizansari",
      "indices" : [ 75, 86 ],
      "id_str" : "6480682",
      "id" : 6480682
    }, {
      "name" : "Leigh Bardugo",
      "screen_name" : "LBardugo",
      "indices" : [ 88, 97 ],
      "id_str" : "24490456",
      "id" : 24490456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/O2231yLfYc",
      "expanded_url" : "http:\/\/trib.al\/IvtMPeF",
      "display_url" : "trib.al\/IvtMPeF"
    } ]
  },
  "geo" : { },
  "id_str" : "698915391716851716",
  "text" : "RT @BookishHQ: Literary Valentine\u2019s Day Cards for Your Reader: Inspired by @azizansari, @LBardugo, and more https:\/\/t.co\/O2231yLfYc https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aziz Ansari",
        "screen_name" : "azizansari",
        "indices" : [ 60, 71 ],
        "id_str" : "6480682",
        "id" : 6480682
      }, {
        "name" : "Leigh Bardugo",
        "screen_name" : "LBardugo",
        "indices" : [ 73, 82 ],
        "id_str" : "24490456",
        "id" : 24490456
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BookishHQ\/status\/698900784893792256\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Eb4WJjEiEg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbL-j3hW8AArh5K.jpg",
        "id_str" : "698900784348590080",
        "id" : 698900784348590080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbL-j3hW8AArh5K.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/Eb4WJjEiEg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/O2231yLfYc",
        "expanded_url" : "http:\/\/trib.al\/IvtMPeF",
        "display_url" : "trib.al\/IvtMPeF"
      } ]
    },
    "geo" : { },
    "id_str" : "698900784893792256",
    "text" : "Literary Valentine\u2019s Day Cards for Your Reader: Inspired by @azizansari, @LBardugo, and more https:\/\/t.co\/O2231yLfYc https:\/\/t.co\/Eb4WJjEiEg",
    "id" : 698900784893792256,
    "created_at" : "2016-02-14 16:05:06 +0000",
    "user" : {
      "name" : "Bookish",
      "screen_name" : "BookishHQ",
      "protected" : false,
      "id_str" : "322830973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000610603604\/bcce2d517be00107ae7ed8660d5143a9_normal.png",
      "id" : 322830973,
      "verified" : true
    }
  },
  "id" : 698915391716851716,
  "created_at" : "2016-02-14 17:03:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Machinima",
      "screen_name" : "Machinima",
      "indices" : [ 3, 13 ],
      "id_str" : "29514951",
      "id" : 29514951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Machinima\/status\/685224421058031616\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/y8f8d4USIq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJn-uWWsAU6YQ4.png",
      "id_str" : "685224420605079557",
      "id" : 685224420605079557,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJn-uWWsAU6YQ4.png",
      "sizes" : [ {
        "h" : 779,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y8f8d4USIq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698913355013189632",
  "text" : "RT @Machinima: When the feels hit you too hard.. https:\/\/t.co\/y8f8d4USIq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Machinima\/status\/685224421058031616\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/y8f8d4USIq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYJn-uWWsAU6YQ4.png",
        "id_str" : "685224420605079557",
        "id" : 685224420605079557,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYJn-uWWsAU6YQ4.png",
        "sizes" : [ {
          "h" : 779,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 441,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/y8f8d4USIq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685224421058031616",
    "text" : "When the feels hit you too hard.. https:\/\/t.co\/y8f8d4USIq",
    "id" : 685224421058031616,
    "created_at" : "2016-01-07 22:20:07 +0000",
    "user" : {
      "name" : "Machinima",
      "screen_name" : "Machinima",
      "protected" : false,
      "id_str" : "29514951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793520002464817152\/to3fEr7o_normal.jpg",
      "id" : 29514951,
      "verified" : true
    }
  },
  "id" : 698913355013189632,
  "created_at" : "2016-02-14 16:55:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cornelia",
      "screen_name" : "PaladinCornelia",
      "indices" : [ 3, 19 ],
      "id_str" : "1282197158",
      "id" : 1282197158
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Scalia",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698912679629561858",
  "text" : "RT @PaladinCornelia: Basically what #Scalia was saying is 'once found guilty - always guilty'.\nEven if DNA evidence proves otherwise. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PaladinCornelia\/status\/698900780082855937\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/y22o4faSwi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbL-jlCUMAAglIb.png",
        "id_str" : "698900779386548224",
        "id" : 698900779386548224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbL-jlCUMAAglIb.png",
        "sizes" : [ {
          "h" : 166,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 92,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/y22o4faSwi"
      } ],
      "hashtags" : [ {
        "text" : "Scalia",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698900780082855937",
    "text" : "Basically what #Scalia was saying is 'once found guilty - always guilty'.\nEven if DNA evidence proves otherwise. https:\/\/t.co\/y22o4faSwi",
    "id" : 698900780082855937,
    "created_at" : "2016-02-14 16:05:05 +0000",
    "user" : {
      "name" : "Cornelia",
      "screen_name" : "PaladinCornelia",
      "protected" : false,
      "id_str" : "1282197158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616623141419257856\/C1IMMpAK_normal.png",
      "id" : 1282197158,
      "verified" : false
    }
  },
  "id" : 698912679629561858,
  "created_at" : "2016-02-14 16:52:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jopilatje",
      "screen_name" : "jopilatje",
      "indices" : [ 3, 13 ],
      "id_str" : "3503354237",
      "id" : 3503354237
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "study",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "sunset",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698911791552864256",
  "text" : "RT @jopilatje: A landscape #study I made a couple of days ago. Hooray for free time so I can make random mountains during #sunset! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jopilatje\/status\/669224044680597504\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/HSaKA0zr0G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmPuLCVAAELqed.jpg",
        "id_str" : "669224043040538625",
        "id" : 669224043040538625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmPuLCVAAELqed.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HSaKA0zr0G"
      } ],
      "hashtags" : [ {
        "text" : "study",
        "indices" : [ 12, 18 ]
      }, {
        "text" : "sunset",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669224044680597504",
    "text" : "A landscape #study I made a couple of days ago. Hooray for free time so I can make random mountains during #sunset! https:\/\/t.co\/HSaKA0zr0G",
    "id" : 669224044680597504,
    "created_at" : "2015-11-24 18:40:20 +0000",
    "user" : {
      "name" : "jopilatje",
      "screen_name" : "jopilatje",
      "protected" : false,
      "id_str" : "3503354237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638393962441474048\/V3JC5aWz_normal.png",
      "id" : 3503354237,
      "verified" : false
    }
  },
  "id" : 698911791552864256,
  "created_at" : "2016-02-14 16:48:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jopilatje",
      "screen_name" : "jopilatje",
      "indices" : [ 3, 13 ],
      "id_str" : "3503354237",
      "id" : 3503354237
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jopilatje\/status\/671390038538743808\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/6ZRB4UYx0v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVFBrnkVEAAdQ2-.jpg",
      "id_str" : "671390037066452992",
      "id" : 671390037066452992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVFBrnkVEAAdQ2-.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6ZRB4UYx0v"
    } ],
    "hashtags" : [ {
      "text" : "forest",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "landscape",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698911736473264128",
  "text" : "RT @jopilatje: Rough study of a #forest to practise some more #landscape. https:\/\/t.co\/6ZRB4UYx0v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jopilatje\/status\/671390038538743808\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/6ZRB4UYx0v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVFBrnkVEAAdQ2-.jpg",
        "id_str" : "671390037066452992",
        "id" : 671390037066452992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVFBrnkVEAAdQ2-.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6ZRB4UYx0v"
      } ],
      "hashtags" : [ {
        "text" : "forest",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "landscape",
        "indices" : [ 47, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671390038538743808",
    "text" : "Rough study of a #forest to practise some more #landscape. https:\/\/t.co\/6ZRB4UYx0v",
    "id" : 671390038538743808,
    "created_at" : "2015-11-30 18:07:13 +0000",
    "user" : {
      "name" : "jopilatje",
      "screen_name" : "jopilatje",
      "protected" : false,
      "id_str" : "3503354237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638393962441474048\/V3JC5aWz_normal.png",
      "id" : 3503354237,
      "verified" : false
    }
  },
  "id" : 698911736473264128,
  "created_at" : "2016-02-14 16:48:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jurikoii",
      "screen_name" : "jurikoii",
      "indices" : [ 3, 12 ],
      "id_str" : "775330015818969088",
      "id" : 775330015818969088
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jurikoii\/status\/698810733988069381\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/kFWOrnbwLy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbKsqBLWwAAOZYS.jpg",
      "id_str" : "698810730066395136",
      "id" : 698810730066395136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbKsqBLWwAAOZYS.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1040,
        "resize" : "fit",
        "w" : 1569
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kFWOrnbwLy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698911344049922048",
  "text" : "RT @jurikoii: i'm ready to spend my entire sunday rendering this https:\/\/t.co\/kFWOrnbwLy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jurikoii\/status\/698810733988069381\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/kFWOrnbwLy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbKsqBLWwAAOZYS.jpg",
        "id_str" : "698810730066395136",
        "id" : 698810730066395136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbKsqBLWwAAOZYS.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1040,
          "resize" : "fit",
          "w" : 1569
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kFWOrnbwLy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698810733988069381",
    "text" : "i'm ready to spend my entire sunday rendering this https:\/\/t.co\/kFWOrnbwLy",
    "id" : 698810733988069381,
    "created_at" : "2016-02-14 10:07:16 +0000",
    "user" : {
      "name" : "Jurgen",
      "screen_name" : "jurgenkuqi",
      "protected" : false,
      "id_str" : "2522972204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740532669235220480\/Tdmw7Cn4_normal.jpg",
      "id" : 2522972204,
      "verified" : false
    }
  },
  "id" : 698911344049922048,
  "created_at" : "2016-02-14 16:47:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698904469044645890",
  "text" : "RT @TheGoldenMirror: We're suspended in a state of unconscious reaction until we acquire the ability to consciously act. Grow aware of what\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698902334202580993",
    "text" : "We're suspended in a state of unconscious reaction until we acquire the ability to consciously act. Grow aware of what you do.",
    "id" : 698902334202580993,
    "created_at" : "2016-02-14 16:11:16 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 698904469044645890,
  "created_at" : "2016-02-14 16:19:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "indices" : [ 3, 17 ],
      "id_str" : "555307309",
      "id" : 555307309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698904410131402752",
  "text" : "RT @takecareofUUU: Please be kind as U go through life.We need more kind, caring &amp; gentle people. Be 1 of those who spreads kindness#TA htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/takecareofUUU\/status\/698902338749231106\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/M0pDdGJkxq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbL_-TyUcAAGnmy.jpg",
        "id_str" : "698902338124148736",
        "id" : 698902338124148736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbL_-TyUcAAGnmy.jpg",
        "sizes" : [ {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/M0pDdGJkxq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698902338749231106",
    "text" : "Please be kind as U go through life.We need more kind, caring &amp; gentle people. Be 1 of those who spreads kindness#TA https:\/\/t.co\/M0pDdGJkxq",
    "id" : 698902338749231106,
    "created_at" : "2016-02-14 16:11:17 +0000",
    "user" : {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "protected" : false,
      "id_str" : "555307309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537254454949445634\/7uw1omdM_normal.jpeg",
      "id" : 555307309,
      "verified" : false
    }
  },
  "id" : 698904410131402752,
  "created_at" : "2016-02-14 16:19:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FarmingUK",
      "screen_name" : "FarmingUK",
      "indices" : [ 3, 13 ],
      "id_str" : "141576773",
      "id" : 141576773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyValentinesDay",
      "indices" : [ 99, 118 ]
    }, {
      "text" : "NiceHairDo",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698899027262369793",
  "text" : "RT @FarmingUK: Has anyone put in this amount of effort for Valentines? If so, you deserve an award #HappyValentinesDay #NiceHairDo https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmingUK\/status\/698812077775982592\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/N7ylaQplTQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbKt4JRWAAEqWKb.jpg",
        "id_str" : "698812072268791809",
        "id" : 698812072268791809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbKt4JRWAAEqWKb.jpg",
        "sizes" : [ {
          "h" : 234,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/N7ylaQplTQ"
      } ],
      "hashtags" : [ {
        "text" : "HappyValentinesDay",
        "indices" : [ 84, 103 ]
      }, {
        "text" : "NiceHairDo",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698812077775982592",
    "text" : "Has anyone put in this amount of effort for Valentines? If so, you deserve an award #HappyValentinesDay #NiceHairDo https:\/\/t.co\/N7ylaQplTQ",
    "id" : 698812077775982592,
    "created_at" : "2016-02-14 10:12:37 +0000",
    "user" : {
      "name" : "FarmingUK",
      "screen_name" : "FarmingUK",
      "protected" : false,
      "id_str" : "141576773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572414090442579968\/vpyLoEL-_normal.jpeg",
      "id" : 141576773,
      "verified" : false
    }
  },
  "id" : 698899027262369793,
  "created_at" : "2016-02-14 15:58:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698898621832523776",
  "text" : "RT @onealexharms: \uD83D\uDC9C There is one person who is always with me. \uD83D\uDC99 24\/7. \uD83D\uDC9B We love and support each other no matter what. \uD83D\uDC9A Happy Valentines \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698895473210486784",
    "text" : "\uD83D\uDC9C There is one person who is always with me. \uD83D\uDC99 24\/7. \uD83D\uDC9B We love and support each other no matter what. \uD83D\uDC9A Happy Valentines Day, me! \uD83D\uDC93",
    "id" : 698895473210486784,
    "created_at" : "2016-02-14 15:44:00 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 698898621832523776,
  "created_at" : "2016-02-14 15:56:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KerriFar\/status\/698894723793215489\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Yb71jPd710",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbL5DCjVAAA1oHR.jpg",
      "id_str" : "698894722815819776",
      "id" : 698894722815819776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbL5DCjVAAA1oHR.jpg",
      "sizes" : [ {
        "h" : 665,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/Yb71jPd710"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "nature",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/AFY6jUk881",
      "expanded_url" : "http:\/\/goo.gl\/T8opq1",
      "display_url" : "goo.gl\/T8opq1"
    } ]
  },
  "geo" : { },
  "id_str" : "698897318389682177",
  "text" : "RT @KerriFar: Catbirds in Love :)  --  https:\/\/t.co\/AFY6jUk881 ~ #birds #nature https:\/\/t.co\/Yb71jPd710",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KerriFar\/status\/698894723793215489\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/Yb71jPd710",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbL5DCjVAAA1oHR.jpg",
        "id_str" : "698894722815819776",
        "id" : 698894722815819776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbL5DCjVAAA1oHR.jpg",
        "sizes" : [ {
          "h" : 665,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/Yb71jPd710"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "nature",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/AFY6jUk881",
        "expanded_url" : "http:\/\/goo.gl\/T8opq1",
        "display_url" : "goo.gl\/T8opq1"
      } ]
    },
    "geo" : { },
    "id_str" : "698894723793215489",
    "text" : "Catbirds in Love :)  --  https:\/\/t.co\/AFY6jUk881 ~ #birds #nature https:\/\/t.co\/Yb71jPd710",
    "id" : 698894723793215489,
    "created_at" : "2016-02-14 15:41:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 698897318389682177,
  "created_at" : "2016-02-14 15:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "scifi",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/UkrNt1I5fO",
      "expanded_url" : "http:\/\/www.anthonyvicino.com\/giving-away-5-free-time-heist-audiobooks-and-5-free-ebooks\/",
      "display_url" : "anthonyvicino.com\/giving-away-5-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698884805858091008",
  "text" : "Enter to Win a copy of the Time Heist Audiobook and Ebook! #giveaway #scifi https:\/\/t.co\/UkrNt1I5fO",
  "id" : 698884805858091008,
  "created_at" : "2016-02-14 15:01:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698872078364184576",
  "text" : "I'm 14% through Fear the Sky (Unabridged) by Stephen Moss, narrated by R.C. Bray on my Audible app.",
  "id" : 698872078364184576,
  "created_at" : "2016-02-14 14:11:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Phillips \uD83D\uDCCE",
      "screen_name" : "phillipsan",
      "indices" : [ 3, 14 ],
      "id_str" : "11255812",
      "id" : 11255812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 118, 128 ]
    }, {
      "text" : "SupremeCourt",
      "indices" : [ 129, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698694138728947712",
  "text" : "RT @phillipsan: interpreting Constitution as originally meant = continued slavery &amp; women would not have the vote #GOPDebate #SupremeCourt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "SupremeCourt",
        "indices" : [ 113, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698691618912636932",
    "text" : "interpreting Constitution as originally meant = continued slavery &amp; women would not have the vote #GOPDebate #SupremeCourt",
    "id" : 698691618912636932,
    "created_at" : "2016-02-14 02:13:57 +0000",
    "user" : {
      "name" : "Adam Phillips \uD83D\uDCCE",
      "screen_name" : "phillipsan",
      "protected" : false,
      "id_str" : "11255812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000723917102\/9482d1bc659c3fddc08e33886a406fa0_normal.jpeg",
      "id" : 11255812,
      "verified" : false
    }
  },
  "id" : 698694138728947712,
  "created_at" : "2016-02-14 02:23:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Soulseedzforall\/status\/698692336331567104\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/qELdOmonrx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbJA-h1UcAAfPEE.jpg",
      "id_str" : "698692335173922816",
      "id" : 698692335173922816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbJA-h1UcAAfPEE.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qELdOmonrx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698693572724449281",
  "text" : "RT @Soulseedzforall: Hang in there and ask for help https:\/\/t.co\/qELdOmonrx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Soulseedzforall\/status\/698692336331567104\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/qELdOmonrx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbJA-h1UcAAfPEE.jpg",
        "id_str" : "698692335173922816",
        "id" : 698692335173922816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbJA-h1UcAAfPEE.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qELdOmonrx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698692336331567104",
    "text" : "Hang in there and ask for help https:\/\/t.co\/qELdOmonrx",
    "id" : 698692336331567104,
    "created_at" : "2016-02-14 02:16:48 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 698693572724449281,
  "created_at" : "2016-02-14 02:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ask Science Mike",
      "screen_name" : "asksciencemike",
      "indices" : [ 3, 18 ],
      "id_str" : "2970458165",
      "id" : 2970458165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698689004938600449",
  "text" : "RT @asksciencemike: There\u2019s only ONE question this week\u2013we cover Einstein, Relativity, and Gravity Waves in a single, 30 minute answer. Mon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698556146215354369",
    "text" : "There\u2019s only ONE question this week\u2013we cover Einstein, Relativity, and Gravity Waves in a single, 30 minute answer. Monday, here we come!",
    "id" : 698556146215354369,
    "created_at" : "2016-02-13 17:15:38 +0000",
    "user" : {
      "name" : "Ask Science Mike",
      "screen_name" : "asksciencemike",
      "protected" : false,
      "id_str" : "2970458165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701170538954141696\/-HYTfCrE_normal.jpg",
      "id" : 2970458165,
      "verified" : false
    }
  },
  "id" : 698689004938600449,
  "created_at" : "2016-02-14 02:03:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capt'n Queerbeard",
      "screen_name" : "deadhead1991",
      "indices" : [ 3, 16 ],
      "id_str" : "484399952",
      "id" : 484399952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/2kWPUTPbSp",
      "expanded_url" : "https:\/\/twitter.com\/Lily_Bell82\/status\/697912977626894336",
      "display_url" : "twitter.com\/Lily_Bell82\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698684304310853632",
  "text" : "RT @deadhead1991: I can't rt this enough  https:\/\/t.co\/2kWPUTPbSp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/2kWPUTPbSp",
        "expanded_url" : "https:\/\/twitter.com\/Lily_Bell82\/status\/697912977626894336",
        "display_url" : "twitter.com\/Lily_Bell82\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698358062399275008",
    "text" : "I can't rt this enough  https:\/\/t.co\/2kWPUTPbSp",
    "id" : 698358062399275008,
    "created_at" : "2016-02-13 04:08:31 +0000",
    "user" : {
      "name" : "Capt'n Queerbeard",
      "screen_name" : "deadhead1991",
      "protected" : false,
      "id_str" : "484399952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793593164368113664\/Cds10sGC_normal.jpg",
      "id" : 484399952,
      "verified" : false
    }
  },
  "id" : 698684304310853632,
  "created_at" : "2016-02-14 01:44:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    }, {
      "name" : "MJC",
      "screen_name" : "matteocarr",
      "indices" : [ 15, 26 ],
      "id_str" : "41184553",
      "id" : 41184553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698662196352589824",
  "geo" : { },
  "id_str" : "698668725986291712",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist @matteocarr wth?? o-O",
  "id" : 698668725986291712,
  "in_reply_to_status_id" : 698662196352589824,
  "created_at" : "2016-02-14 00:42:59 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698654194975305728",
  "geo" : { },
  "id_str" : "698656265413775360",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist im torn whether now or next year (we will have dem prez) bcuz I'd love to see PBO nom as others have mentioned.",
  "id" : 698656265413775360,
  "in_reply_to_status_id" : 698654194975305728,
  "created_at" : "2016-02-13 23:53:28 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698647462173605888",
  "text" : "RT @MimiMadeira1: Who knows what surprises lay ahead of us",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698646106930941952",
    "text" : "Who knows what surprises lay ahead of us",
    "id" : 698646106930941952,
    "created_at" : "2016-02-13 23:13:06 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 698647462173605888,
  "created_at" : "2016-02-13 23:18:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/QIywthXFJJ",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/698626793008455680",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698629286194978817",
  "text" : "anyone that can assist him? ive followed him for awhile now and hes a good egg that needs a break. https:\/\/t.co\/QIywthXFJJ",
  "id" : 698629286194978817,
  "created_at" : "2016-02-13 22:06:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carlosaleman",
      "screen_name" : "carlosaleman",
      "indices" : [ 3, 16 ],
      "id_str" : "11025612",
      "id" : 11025612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698581603182845952",
  "text" : "RT @carlosaleman: I'm not normal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698580703257165824",
    "text" : "I'm not normal",
    "id" : 698580703257165824,
    "created_at" : "2016-02-13 18:53:13 +0000",
    "user" : {
      "name" : "carlosaleman",
      "screen_name" : "carlosaleman",
      "protected" : false,
      "id_str" : "11025612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758121858528968704\/BKkOFzfj_normal.jpg",
      "id" : 11025612,
      "verified" : false
    }
  },
  "id" : 698581603182845952,
  "created_at" : "2016-02-13 18:56:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This American Life",
      "screen_name" : "ThisAmerLife",
      "indices" : [ 10, 23 ],
      "id_str" : "149180925",
      "id" : 149180925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mentalillness",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/8pMbmK7Kd5",
      "expanded_url" : "http:\/\/tal.fm\/579",
      "display_url" : "tal.fm\/579"
    } ]
  },
  "geo" : { },
  "id_str" : "698578443697549312",
  "text" : "Check out @ThisAmerLife episode 579: 'My Damn Mind.' https:\/\/t.co\/8pMbmK7Kd5 #mentalillness patient shot in hospital",
  "id" : 698578443697549312,
  "created_at" : "2016-02-13 18:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/fm2SO6EXhv",
      "expanded_url" : "http:\/\/nyti.ms\/1QZB1Xr",
      "display_url" : "nyti.ms\/1QZB1Xr"
    } ]
  },
  "geo" : { },
  "id_str" : "698578172758138884",
  "text" : "When the Hospital Fires the Bullet https:\/\/t.co\/fm2SO6EXhv",
  "id" : 698578172758138884,
  "created_at" : "2016-02-13 18:43:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dark Faerie Tales",
      "screen_name" : "DarkFaerieTales",
      "indices" : [ 3, 19 ],
      "id_str" : "23559325",
      "id" : 23559325
    }, {
      "name" : "Emily Kate Johnston",
      "screen_name" : "ek_johnston",
      "indices" : [ 85, 97 ],
      "id_str" : "267527746",
      "id" : 267527746
    }, {
      "name" : "Disney Books",
      "screen_name" : "DisneyHyperion",
      "indices" : [ 122, 137 ],
      "id_str" : "36370102",
      "id" : 36370102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/iT9EwrQiUZ",
      "expanded_url" : "http:\/\/darkfaerietales.com\/review-thousand-nights-ek-johnston.html",
      "display_url" : "darkfaerietales.com\/review-thousan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698571087559397376",
  "text" : "RT @DarkFaerieTales: \u201CEasy read with a powerful message\u201D Review A Thousand Nights by @ek_johnston https:\/\/t.co\/iT9EwrQiUZ @DisneyHyperion h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emily Kate Johnston",
        "screen_name" : "ek_johnston",
        "indices" : [ 64, 76 ],
        "id_str" : "267527746",
        "id" : 267527746
      }, {
        "name" : "Disney Books",
        "screen_name" : "DisneyHyperion",
        "indices" : [ 101, 116 ],
        "id_str" : "36370102",
        "id" : 36370102
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DarkFaerieTales\/status\/698549780222500865\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/iTlHSaSrf8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbG_UtyUUAAQRvj.jpg",
        "id_str" : "698549779828068352",
        "id" : 698549779828068352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbG_UtyUUAAQRvj.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 198
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 198
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 198
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 198
        } ],
        "display_url" : "pic.twitter.com\/iTlHSaSrf8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/iT9EwrQiUZ",
        "expanded_url" : "http:\/\/darkfaerietales.com\/review-thousand-nights-ek-johnston.html",
        "display_url" : "darkfaerietales.com\/review-thousan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698549780222500865",
    "text" : "\u201CEasy read with a powerful message\u201D Review A Thousand Nights by @ek_johnston https:\/\/t.co\/iT9EwrQiUZ @DisneyHyperion https:\/\/t.co\/iTlHSaSrf8",
    "id" : 698549780222500865,
    "created_at" : "2016-02-13 16:50:20 +0000",
    "user" : {
      "name" : "Dark Faerie Tales",
      "screen_name" : "DarkFaerieTales",
      "protected" : false,
      "id_str" : "23559325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1493551121\/DFT_Button_normal.jpeg",
      "id" : 23559325,
      "verified" : false
    }
  },
  "id" : 698571087559397376,
  "created_at" : "2016-02-13 18:15:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "existential",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/XujoSulsGu",
      "expanded_url" : "https:\/\/twitter.com\/DrJoeDispenza\/status\/695653984690802688",
      "display_url" : "twitter.com\/DrJoeDispenza\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698554425066057728",
  "text" : "who are we, who are we?? injury opened conscious access to brain area (at 3:40) #woo #existential https:\/\/t.co\/XujoSulsGu",
  "id" : 698554425066057728,
  "created_at" : "2016-02-13 17:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/z3xWRwUUU1",
      "expanded_url" : "http:\/\/www.fastcodesign.com\/3036542\/the-flight-patterns-of-winged-creatured-visualized",
      "display_url" : "fastcodesign.com\/3036542\/the-fl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698551417590697984",
  "text" : "RT @pourmecoffee: Bird and math lovers: this is cool. \"How five different creatures flap their wings\"  https:\/\/t.co\/z3xWRwUUU1 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pourmecoffee\/status\/698549208744329216\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/jBkJOE3WzA",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbG-ypLWcAEjyN0.jpg",
        "id_str" : "698549194475335681",
        "id" : 698549194475335681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbG-ypLWcAEjyN0.jpg",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 722,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 722,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/jBkJOE3WzA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/z3xWRwUUU1",
        "expanded_url" : "http:\/\/www.fastcodesign.com\/3036542\/the-flight-patterns-of-winged-creatured-visualized",
        "display_url" : "fastcodesign.com\/3036542\/the-fl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698549208744329216",
    "text" : "Bird and math lovers: this is cool. \"How five different creatures flap their wings\"  https:\/\/t.co\/z3xWRwUUU1 https:\/\/t.co\/jBkJOE3WzA",
    "id" : 698549208744329216,
    "created_at" : "2016-02-13 16:48:04 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682738304354140160\/OpbXjxXU_normal.jpg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 698551417590697984,
  "created_at" : "2016-02-13 16:56:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ned the toothpick",
      "screen_name" : "nedthetoothpik",
      "indices" : [ 3, 18 ],
      "id_str" : "2740547934",
      "id" : 2740547934
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nedthetoothpik\/status\/698534362749542401\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/cWrRofv2Gy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbGxTSaXIAIw2sm.jpg",
      "id_str" : "698534362137174018",
      "id" : 698534362137174018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbGxTSaXIAIw2sm.jpg",
      "sizes" : [ {
        "h" : 847,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 847,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 847,
        "resize" : "fit",
        "w" : 564
      } ],
      "display_url" : "pic.twitter.com\/cWrRofv2Gy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698551301622407168",
  "text" : "RT @nedthetoothpik: Such a pretty image\n:-) https:\/\/t.co\/cWrRofv2Gy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nedthetoothpik\/status\/698534362749542401\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/cWrRofv2Gy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbGxTSaXIAIw2sm.jpg",
        "id_str" : "698534362137174018",
        "id" : 698534362137174018,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbGxTSaXIAIw2sm.jpg",
        "sizes" : [ {
          "h" : 847,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 847,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 847,
          "resize" : "fit",
          "w" : 564
        } ],
        "display_url" : "pic.twitter.com\/cWrRofv2Gy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698534362749542401",
    "text" : "Such a pretty image\n:-) https:\/\/t.co\/cWrRofv2Gy",
    "id" : 698534362749542401,
    "created_at" : "2016-02-13 15:49:04 +0000",
    "user" : {
      "name" : "ned the toothpick",
      "screen_name" : "nedthetoothpik",
      "protected" : false,
      "id_str" : "2740547934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501123337137831937\/L6lzk_i0_normal.jpeg",
      "id" : 2740547934,
      "verified" : false
    }
  },
  "id" : 698551301622407168,
  "created_at" : "2016-02-13 16:56:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698523452278513668",
  "text" : "I'm 7% through Fear the Sky (Unabridged) by Stephen Moss, narrated by R.C. Bray on my Audible app.",
  "id" : 698523452278513668,
  "created_at" : "2016-02-13 15:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/698514002754801664\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/zFvKCVdBr4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbGeyB0WIAAn9G8.png",
      "id_str" : "698513999537774592",
      "id" : 698513999537774592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbGeyB0WIAAn9G8.png",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      } ],
      "display_url" : "pic.twitter.com\/zFvKCVdBr4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/d6OVOhPV7k",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/Hypothyroidism\/comments\/45585v\/i_cant_continue_like_this_tsht4_normal_but?_ts=1455373690",
      "display_url" : "reddit.com\/r\/Hypothyroidi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698514002754801664",
  "text" : "I can't continue like this: TSH\/T4 \"normal\" but experiencing harsh mental and physical s... https:\/\/t.co\/d6OVOhPV7k https:\/\/t.co\/zFvKCVdBr4",
  "id" : 698514002754801664,
  "created_at" : "2016-02-13 14:28:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Poke",
      "screen_name" : "ThePoke",
      "indices" : [ 3, 11 ],
      "id_str" : "143145579",
      "id" : 143145579
    }, {
      "name" : "Keir Shiels",
      "screen_name" : "keirshiels",
      "indices" : [ 103, 114 ],
      "id_str" : "262907164",
      "id" : 262907164
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThePoke\/status\/698212515726004224\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vKafMODN70",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbAE7oGXEAAvj9W.jpg",
      "id_str" : "698063364665315328",
      "id" : 698063364665315328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbAE7oGXEAAvj9W.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vKafMODN70"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/6bKzvvoN0Z",
      "expanded_url" : "http:\/\/www.thepoke.co.uk\/2016\/02\/11\/gloria-gaynors-will-survive-shakespearean-sonnet\/",
      "display_url" : "thepoke.co.uk\/2016\/02\/11\/glo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698324697461755912",
  "text" : "RT @ThePoke: Gloria Gaynor\u2019s \u201CI Will Survive\u201D as a Shakespearean Sonnet\n\nhttps:\/\/t.co\/6bKzvvoN0Z\n\n(via @keirshiels) https:\/\/t.co\/vKafMODN70",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keir Shiels",
        "screen_name" : "keirshiels",
        "indices" : [ 90, 101 ],
        "id_str" : "262907164",
        "id" : 262907164
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThePoke\/status\/698212515726004224\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/vKafMODN70",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbAE7oGXEAAvj9W.jpg",
        "id_str" : "698063364665315328",
        "id" : 698063364665315328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbAE7oGXEAAvj9W.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vKafMODN70"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/6bKzvvoN0Z",
        "expanded_url" : "http:\/\/www.thepoke.co.uk\/2016\/02\/11\/gloria-gaynors-will-survive-shakespearean-sonnet\/",
        "display_url" : "thepoke.co.uk\/2016\/02\/11\/glo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "698212515726004224",
    "text" : "Gloria Gaynor\u2019s \u201CI Will Survive\u201D as a Shakespearean Sonnet\n\nhttps:\/\/t.co\/6bKzvvoN0Z\n\n(via @keirshiels) https:\/\/t.co\/vKafMODN70",
    "id" : 698212515726004224,
    "created_at" : "2016-02-12 18:30:10 +0000",
    "user" : {
      "name" : "The Poke",
      "screen_name" : "ThePoke",
      "protected" : false,
      "id_str" : "143145579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556060000410296321\/BXU9aiar_normal.png",
      "id" : 143145579,
      "verified" : false
    }
  },
  "id" : 698324697461755912,
  "created_at" : "2016-02-13 01:55:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698284667460591616",
  "text" : "im an attack goose and I WILL bite.",
  "id" : 698284667460591616,
  "created_at" : "2016-02-12 23:16:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 2, 12 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698231147822768129",
  "geo" : { },
  "id_str" : "698266589905481728",
  "in_reply_to_user_id" : 16181537,
  "text" : ". @ZachsMind every single person that lives lies.",
  "id" : 698266589905481728,
  "in_reply_to_status_id" : 698231147822768129,
  "created_at" : "2016-02-12 22:05:02 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/698261995846529029\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/YMb0P5O6ZG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbC5lTOW0AAXYeU.jpg",
      "id_str" : "698261992709214208",
      "id" : 698261992709214208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbC5lTOW0AAXYeU.jpg",
      "sizes" : [ {
        "h" : 631,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YMb0P5O6ZG"
    } ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/QJbyUJGT8k",
      "expanded_url" : "https:\/\/www.google.com\/search?q=hashimotos+suicidal+thoughts&_ts=1455313606",
      "display_url" : "google.com\/search?q=hashi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698261995846529029",
  "text" : "its a thing... #hashimotos suicidal thoughts - Google Search https:\/\/t.co\/QJbyUJGT8k https:\/\/t.co\/YMb0P5O6ZG",
  "id" : 698261995846529029,
  "created_at" : "2016-02-12 21:46:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 0, 16 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "698210145424302080",
  "geo" : { },
  "id_str" : "698216033409241088",
  "in_reply_to_user_id" : 1137858745,
  "text" : "@JourneyTheHedgi me, too... &lt;3",
  "id" : 698216033409241088,
  "in_reply_to_status_id" : 698210145424302080,
  "created_at" : "2016-02-12 18:44:09 +0000",
  "in_reply_to_screen_name" : "JourneyTheHedgi",
  "in_reply_to_user_id_str" : "1137858745",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psychiatricsymptoms",
      "indices" : [ 35, 55 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698209336636665856",
  "text" : "appt w psych today. hope it helps. #psychiatricsymptoms #hashimotos #chronicillness",
  "id" : 698209336636665856,
  "created_at" : "2016-02-12 18:17:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 82, 88 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyWeSnap",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/pmn0DpfYho",
      "expanded_url" : "http:\/\/buff.ly\/1PHFHPg",
      "display_url" : "buff.ly\/1PHFHPg"
    } ]
  },
  "geo" : { },
  "id_str" : "698207973462712320",
  "text" : "RT @DuttonBooks: For those who want to understand rage, \u201Cthis book delivers\" says @sciam MIND: https:\/\/t.co\/pmn0DpfYho #WhyWeSnap https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scientific American",
        "screen_name" : "sciam",
        "indices" : [ 65, 71 ],
        "id_str" : "14647570",
        "id" : 14647570
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DuttonBooks\/status\/698206017373499393\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/8mmuaQZuAD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbCGrGUXIAA6flZ.jpg",
        "id_str" : "698206017230938112",
        "id" : 698206017230938112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbCGrGUXIAA6flZ.jpg",
        "sizes" : [ {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8mmuaQZuAD"
      } ],
      "hashtags" : [ {
        "text" : "WhyWeSnap",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/pmn0DpfYho",
        "expanded_url" : "http:\/\/buff.ly\/1PHFHPg",
        "display_url" : "buff.ly\/1PHFHPg"
      } ]
    },
    "geo" : { },
    "id_str" : "698206017373499393",
    "text" : "For those who want to understand rage, \u201Cthis book delivers\" says @sciam MIND: https:\/\/t.co\/pmn0DpfYho #WhyWeSnap https:\/\/t.co\/8mmuaQZuAD",
    "id" : 698206017373499393,
    "created_at" : "2016-02-12 18:04:21 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 698207973462712320,
  "created_at" : "2016-02-12 18:12:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Reader",
      "screen_name" : "AbiReader",
      "indices" : [ 3, 13 ],
      "id_str" : "1227440088",
      "id" : 1227440088
    }, {
      "name" : "Red Tractor",
      "screen_name" : "RedTractorFood",
      "indices" : [ 15, 30 ],
      "id_str" : "295277986",
      "id" : 295277986
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/dmpz9oDhSh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3QinW4AAg4vT.jpg",
      "id_str" : "698189068295921664",
      "id" : 698189068295921664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3QinW4AAg4vT.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dmpz9oDhSh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/dmpz9oDhSh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3Qi5WEAAhbGB.jpg",
      "id_str" : "698189068371365888",
      "id" : 698189068371365888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3Qi5WEAAhbGB.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dmpz9oDhSh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/dmpz9oDhSh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3Qi0WEAAtdCP.jpg",
      "id_str" : "698189068350394368",
      "id" : 698189068350394368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3Qi0WEAAtdCP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dmpz9oDhSh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/dmpz9oDhSh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3QixWEAA4tE7.jpg",
      "id_str" : "698189068337811456",
      "id" : 698189068337811456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3QixWEAA4tE7.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dmpz9oDhSh"
    } ],
    "hashtags" : [ {
      "text" : "valentines",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "GoldslandFarm",
      "indices" : [ 43, 57 ]
    }, {
      "text" : "cowlove",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698198236784435200",
  "text" : "RT @AbiReader: @RedTractorFood #valentines #GoldslandFarm #cowlove https:\/\/t.co\/dmpz9oDhSh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Red Tractor",
        "screen_name" : "RedTractorFood",
        "indices" : [ 0, 15 ],
        "id_str" : "295277986",
        "id" : 295277986
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/dmpz9oDhSh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3QinW4AAg4vT.jpg",
        "id_str" : "698189068295921664",
        "id" : 698189068295921664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3QinW4AAg4vT.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dmpz9oDhSh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/dmpz9oDhSh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3Qi5WEAAhbGB.jpg",
        "id_str" : "698189068371365888",
        "id" : 698189068371365888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3Qi5WEAAhbGB.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dmpz9oDhSh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/dmpz9oDhSh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3Qi0WEAAtdCP.jpg",
        "id_str" : "698189068350394368",
        "id" : 698189068350394368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3Qi0WEAAtdCP.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dmpz9oDhSh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/698189088709595141\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/dmpz9oDhSh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB3QixWEAA4tE7.jpg",
        "id_str" : "698189068337811456",
        "id" : 698189068337811456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB3QixWEAA4tE7.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dmpz9oDhSh"
      } ],
      "hashtags" : [ {
        "text" : "valentines",
        "indices" : [ 16, 27 ]
      }, {
        "text" : "GoldslandFarm",
        "indices" : [ 28, 42 ]
      }, {
        "text" : "cowlove",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "698103212256137216",
    "geo" : { },
    "id_str" : "698189088709595141",
    "in_reply_to_user_id" : 295277986,
    "text" : "@RedTractorFood #valentines #GoldslandFarm #cowlove https:\/\/t.co\/dmpz9oDhSh",
    "id" : 698189088709595141,
    "in_reply_to_status_id" : 698103212256137216,
    "created_at" : "2016-02-12 16:57:05 +0000",
    "in_reply_to_screen_name" : "RedTractorFood",
    "in_reply_to_user_id_str" : "295277986",
    "user" : {
      "name" : "Abi Reader",
      "screen_name" : "AbiReader",
      "protected" : false,
      "id_str" : "1227440088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632430031659098112\/LHjg68y-_normal.png",
      "id" : 1227440088,
      "verified" : false
    }
  },
  "id" : 698198236784435200,
  "created_at" : "2016-02-12 17:33:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LivingSocial",
      "screen_name" : "LivingSocial",
      "indices" : [ 78, 91 ],
      "id_str" : "14773982",
      "id" : 14773982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/nq7wvb3u2a",
      "expanded_url" : "https:\/\/www.livingsocial.com\/deals\/1540086-3-months-of-audible-that-s-3-audiobooks?ref=share-undefined-twitter-web-deals&rpi=206759174&rui=217350032",
      "display_url" : "livingsocial.com\/deals\/1540086-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698185821430669312",
  "text" : "$9 for 3 Months of Audible \u2013 That\u2019s 3 Audiobooks! https:\/\/t.co\/nq7wvb3u2a via @LivingSocial",
  "id" : 698185821430669312,
  "created_at" : "2016-02-12 16:44:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698172080332869632",
  "text" : "I finished listening to Death's Heretic (Unabridged) by James L. Sutter, narrated by Ray Porter on my Audible app.",
  "id" : 698172080332869632,
  "created_at" : "2016-02-12 15:49:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We Fix Your Adverts",
      "screen_name" : "WeFixYourAdvert",
      "indices" : [ 3, 19 ],
      "id_str" : "4824209247",
      "id" : 4824209247
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WeFixYourAdvert\/status\/697360752513044482\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/X3VSM3tLrt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca2F6FAWcAEAIc9.jpg",
      "id_str" : "697360750134849537",
      "id" : 697360750134849537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca2F6FAWcAEAIc9.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3840,
        "resize" : "fit",
        "w" : 2160
      } ],
      "display_url" : "pic.twitter.com\/X3VSM3tLrt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698169272779063296",
  "text" : "RT @WeFixYourAdvert: Just a normal commute in London https:\/\/t.co\/X3VSM3tLrt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WeFixYourAdvert\/status\/697360752513044482\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/X3VSM3tLrt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca2F6FAWcAEAIc9.jpg",
        "id_str" : "697360750134849537",
        "id" : 697360750134849537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca2F6FAWcAEAIc9.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3840,
          "resize" : "fit",
          "w" : 2160
        } ],
        "display_url" : "pic.twitter.com\/X3VSM3tLrt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697360752513044482",
    "text" : "Just a normal commute in London https:\/\/t.co\/X3VSM3tLrt",
    "id" : 697360752513044482,
    "created_at" : "2016-02-10 10:05:34 +0000",
    "user" : {
      "name" : "We Fix Your Adverts",
      "screen_name" : "WeFixYourAdvert",
      "protected" : false,
      "id_str" : "4824209247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689135419108274176\/ur85H04C_normal.jpg",
      "id" : 4824209247,
      "verified" : false
    }
  },
  "id" : 698169272779063296,
  "created_at" : "2016-02-12 15:38:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 3, 15 ],
      "id_str" : "18393773",
      "id" : 18393773
    }, {
      "name" : "Cumberwench",
      "screen_name" : "RamonaMGreene",
      "indices" : [ 41, 55 ],
      "id_str" : "234662690",
      "id" : 234662690
    }, {
      "name" : "We Fix Your Adverts",
      "screen_name" : "WeFixYourAdvert",
      "indices" : [ 57, 73 ],
      "id_str" : "4824209247",
      "id" : 4824209247
    }, {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 74, 86 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RamonaMGreene\/status\/697925824591187969\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/S0SVSdO0NX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca-H1kVVIAA8Nd8.jpg",
      "id_str" : "697925821621673984",
      "id" : 697925821621673984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca-H1kVVIAA8Nd8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/S0SVSdO0NX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698168494039367681",
  "text" : "RT @neilhimself: More doom of goose. RT \"@RamonaMGreene: @WeFixYourAdvert @neilhimself https:\/\/t.co\/S0SVSdO0NX\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cumberwench",
        "screen_name" : "RamonaMGreene",
        "indices" : [ 24, 38 ],
        "id_str" : "234662690",
        "id" : 234662690
      }, {
        "name" : "We Fix Your Adverts",
        "screen_name" : "WeFixYourAdvert",
        "indices" : [ 40, 56 ],
        "id_str" : "4824209247",
        "id" : 4824209247
      }, {
        "name" : "Neil Gaiman",
        "screen_name" : "neilhimself",
        "indices" : [ 57, 69 ],
        "id_str" : "18393773",
        "id" : 18393773
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RamonaMGreene\/status\/697925824591187969\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/S0SVSdO0NX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca-H1kVVIAA8Nd8.jpg",
        "id_str" : "697925821621673984",
        "id" : 697925821621673984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca-H1kVVIAA8Nd8.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/S0SVSdO0NX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697926047673638913",
    "text" : "More doom of goose. RT \"@RamonaMGreene: @WeFixYourAdvert @neilhimself https:\/\/t.co\/S0SVSdO0NX\"",
    "id" : 697926047673638913,
    "created_at" : "2016-02-11 23:31:51 +0000",
    "user" : {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "protected" : false,
      "id_str" : "18393773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695563324444921856\/5kJZz_ha_normal.jpg",
      "id" : 18393773,
      "verified" : true
    }
  },
  "id" : 698168494039367681,
  "created_at" : "2016-02-12 15:35:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698167111571652608",
  "text" : "gah. you all drive me crazy. just unfollow me now.",
  "id" : 698167111571652608,
  "created_at" : "2016-02-12 15:29:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/698158264710754305\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/IKdTLoCPeC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbBbPYEW8AEenU5.jpg",
      "id_str" : "698158261959323649",
      "id" : 698158261959323649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbBbPYEW8AEenU5.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/IKdTLoCPeC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/628LwR6Ya6",
      "expanded_url" : "http:\/\/samanthapfield.com\/2016\/02\/11\/homeschoolers-socialization-isnt-a-joke?_ts=1455288872",
      "display_url" : "samanthapfield.com\/2016\/02\/11\/hom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698158264710754305",
  "text" : "socialization isn't a freaking joke \u2013 Samantha Field https:\/\/t.co\/628LwR6Ya6 https:\/\/t.co\/IKdTLoCPeC",
  "id" : 698158264710754305,
  "created_at" : "2016-02-12 14:54:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wood works crando",
      "screen_name" : "crando0630",
      "indices" : [ 3, 14 ],
      "id_str" : "362750077",
      "id" : 362750077
    }, {
      "name" : "Victoria ECY",
      "screen_name" : "EdenCottage",
      "indices" : [ 16, 28 ],
      "id_str" : "211853001",
      "id" : 211853001
    }, {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 29, 42 ],
      "id_str" : "255681332",
      "id" : 255681332
    }, {
      "name" : "#NativeBreeds",
      "screen_name" : "nativebreedsGB",
      "indices" : [ 43, 58 ],
      "id_str" : "2377830169",
      "id" : 2377830169
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 59, 71 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 72, 88 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697956825270976513",
  "text" : "RT @crando0630: @EdenCottage @SouthYeoEast @nativebreedsGB @ErinEFarley @hilltopfarmgirl \nThere are waiting for owners.:) https:\/\/t.co\/CQFy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victoria ECY",
        "screen_name" : "EdenCottage",
        "indices" : [ 0, 12 ],
        "id_str" : "211853001",
        "id" : 211853001
      }, {
        "name" : "Farmer Dixon",
        "screen_name" : "SouthYeoEast",
        "indices" : [ 13, 26 ],
        "id_str" : "255681332",
        "id" : 255681332
      }, {
        "name" : "#NativeBreeds",
        "screen_name" : "nativebreedsGB",
        "indices" : [ 27, 42 ],
        "id_str" : "2377830169",
        "id" : 2377830169
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 43, 55 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      }, {
        "name" : "Hill Top Farm",
        "screen_name" : "hilltopfarmgirl",
        "indices" : [ 56, 72 ],
        "id_str" : "457436503",
        "id" : 457436503
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crando0630\/status\/697930107478941696\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/CQFydZeQuO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca-LuONUYAAEZJy.jpg",
        "id_str" : "697930093469917184",
        "id" : 697930093469917184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca-LuONUYAAEZJy.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CQFydZeQuO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "697919224103202817",
    "geo" : { },
    "id_str" : "697930107478941696",
    "in_reply_to_user_id" : 211853001,
    "text" : "@EdenCottage @SouthYeoEast @nativebreedsGB @ErinEFarley @hilltopfarmgirl \nThere are waiting for owners.:) https:\/\/t.co\/CQFydZeQuO",
    "id" : 697930107478941696,
    "in_reply_to_status_id" : 697919224103202817,
    "created_at" : "2016-02-11 23:47:59 +0000",
    "in_reply_to_screen_name" : "EdenCottage",
    "in_reply_to_user_id_str" : "211853001",
    "user" : {
      "name" : "wood works crando",
      "screen_name" : "crando0630",
      "protected" : false,
      "id_str" : "362750077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1519067772\/007_normal.JPG",
      "id" : 362750077,
      "verified" : false
    }
  },
  "id" : 697956825270976513,
  "created_at" : "2016-02-12 01:34:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "scifi",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/UkrNt1I5fO",
      "expanded_url" : "http:\/\/www.anthonyvicino.com\/giving-away-5-free-time-heist-audiobooks-and-5-free-ebooks\/",
      "display_url" : "anthonyvicino.com\/giving-away-5-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697889277036883969",
  "text" : "Enter to Win a copy of the Time Heist Audiobook and Ebook! #giveaway #scifi https:\/\/t.co\/UkrNt1I5fO",
  "id" : 697889277036883969,
  "created_at" : "2016-02-11 21:05:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/Xw6F4YzLv1",
      "expanded_url" : "http:\/\/www.nbcnews.com\/video\/dogs-fiery-rescue-caught-on-camera-621008963555",
      "display_url" : "nbcnews.com\/video\/dogs-fie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697884625364979712",
  "text" : "Dog's Fiery Rescue Caught On Camera https:\/\/t.co\/Xw6F4YzLv1",
  "id" : 697884625364979712,
  "created_at" : "2016-02-11 20:47:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/gDbWLJs9hN",
      "expanded_url" : "https:\/\/twitter.com\/NewRepublic\/status\/697832521116024832",
      "display_url" : "twitter.com\/NewRepublic\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697847817763733504",
  "text" : "sounds almost cartoonish..lol. cool. https:\/\/t.co\/gDbWLJs9hN",
  "id" : 697847817763733504,
  "created_at" : "2016-02-11 18:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elite Daily",
      "screen_name" : "EliteDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "331057915",
      "id" : 331057915
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EliteDaily\/status\/694923377941815297\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/cgtyeE0vMu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTdIVEWYAA_8o1.png",
      "id_str" : "694923377685979136",
      "id" : 694923377685979136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTdIVEWYAA_8o1.png",
      "sizes" : [ {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 669
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 669
      } ],
      "display_url" : "pic.twitter.com\/cgtyeE0vMu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697833589661134849",
  "text" : "RT @EliteDaily: ah, good times. https:\/\/t.co\/cgtyeE0vMu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EliteDaily\/status\/694923377941815297\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/cgtyeE0vMu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTdIVEWYAA_8o1.png",
        "id_str" : "694923377685979136",
        "id" : 694923377685979136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTdIVEWYAA_8o1.png",
        "sizes" : [ {
          "h" : 369,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 669
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 669
        } ],
        "display_url" : "pic.twitter.com\/cgtyeE0vMu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694923377941815297",
    "text" : "ah, good times. https:\/\/t.co\/cgtyeE0vMu",
    "id" : 694923377941815297,
    "created_at" : "2016-02-03 16:40:19 +0000",
    "user" : {
      "name" : "Elite Daily",
      "screen_name" : "EliteDaily",
      "protected" : false,
      "id_str" : "331057915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793536952716890113\/eJfEwL9T_normal.jpg",
      "id" : 331057915,
      "verified" : true
    }
  },
  "id" : 697833589661134849,
  "created_at" : "2016-02-11 17:24:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michio Kaku",
      "screen_name" : "michiokaku",
      "indices" : [ 3, 14 ],
      "id_str" : "19515424",
      "id" : 19515424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697827848674013185",
  "text" : "RT @michiokaku: Einstein would be proud of this discovery of gravity waves. If gravity waves WERE NOT found, them much of modern physics wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697826395133714432",
    "text" : "Einstein would be proud of this discovery of gravity waves. If gravity waves WERE NOT found, them much of modern physics would collapse.",
    "id" : 697826395133714432,
    "created_at" : "2016-02-11 16:55:52 +0000",
    "user" : {
      "name" : "Dr. Michio Kaku",
      "screen_name" : "michiokaku",
      "protected" : false,
      "id_str" : "19515424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2477428816\/oyj5obfw5nrjiqhtylp9_normal.jpeg",
      "id" : 19515424,
      "verified" : true
    }
  },
  "id" : 697827848674013185,
  "created_at" : "2016-02-11 17:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "indices" : [ 3, 16 ],
      "id_str" : "21611239",
      "id" : 21611239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/CHXd8875YP",
      "expanded_url" : "http:\/\/havewedetectedgravitationalwavesyet.com\/",
      "display_url" : "\u2026vewedetectedgravitationalwavesyet.com"
    } ]
  },
  "geo" : { },
  "id_str" : "697827358217265152",
  "text" : "RT @seanmcarroll: Hey this web page has been updated. \nhttps:\/\/t.co\/CHXd8875YP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/CHXd8875YP",
        "expanded_url" : "http:\/\/havewedetectedgravitationalwavesyet.com\/",
        "display_url" : "\u2026vewedetectedgravitationalwavesyet.com"
      } ]
    },
    "geo" : { },
    "id_str" : "697826477039943680",
    "text" : "Hey this web page has been updated. \nhttps:\/\/t.co\/CHXd8875YP",
    "id" : 697826477039943680,
    "created_at" : "2016-02-11 16:56:11 +0000",
    "user" : {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "protected" : false,
      "id_str" : "21611239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554901773467406337\/emLyWwmt_normal.jpeg",
      "id" : 21611239,
      "verified" : true
    }
  },
  "id" : 697827358217265152,
  "created_at" : "2016-02-11 16:59:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michio Kaku",
      "screen_name" : "michiokaku",
      "indices" : [ 3, 14 ],
      "id_str" : "19515424",
      "id" : 19515424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697827109721530370",
  "text" : "RT @michiokaku: It means: if the sun were to disappear at this very instant, it would take 8 minutes for the earth's orbit to be disrupted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697826752605921280",
    "text" : "It means: if the sun were to disappear at this very instant, it would take 8 minutes for the earth's orbit to be disrupted.",
    "id" : 697826752605921280,
    "created_at" : "2016-02-11 16:57:17 +0000",
    "user" : {
      "name" : "Dr. Michio Kaku",
      "screen_name" : "michiokaku",
      "protected" : false,
      "id_str" : "19515424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2477428816\/oyj5obfw5nrjiqhtylp9_normal.jpeg",
      "id" : 19515424,
      "verified" : true
    }
  },
  "id" : 697827109721530370,
  "created_at" : "2016-02-11 16:58:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/RQ6lLKvIZt",
      "expanded_url" : "https:\/\/www.allaboutbirds.org\/mesmerizing-migration-watch-118-bird-species-migrate-across-a-map-of-the-western-hemisphere\/",
      "display_url" : "allaboutbirds.org\/mesmerizing-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697794460353167360",
  "text" : "animated bird migration map https:\/\/t.co\/RQ6lLKvIZt",
  "id" : 697794460353167360,
  "created_at" : "2016-02-11 14:48:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllTheWayCute",
      "screen_name" : "AllTheWayCute",
      "indices" : [ 3, 17 ],
      "id_str" : "2717331290",
      "id" : 2717331290
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AllTheWayCute\/status\/694944733123235840\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/EkyxLEo85Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTwjWwWAAADoya.jpg",
      "id_str" : "694944732716335104",
      "id" : 694944732716335104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTwjWwWAAADoya.jpg",
      "sizes" : [ {
        "h" : 382,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com\/EkyxLEo85Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697576504927113217",
  "text" : "RT @AllTheWayCute: They'll never see me! https:\/\/t.co\/EkyxLEo85Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AllTheWayCute\/status\/694944733123235840\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/EkyxLEo85Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTwjWwWAAADoya.jpg",
        "id_str" : "694944732716335104",
        "id" : 694944732716335104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTwjWwWAAADoya.jpg",
        "sizes" : [ {
          "h" : 382,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/EkyxLEo85Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694944733123235840",
    "text" : "They'll never see me! https:\/\/t.co\/EkyxLEo85Y",
    "id" : 694944733123235840,
    "created_at" : "2016-02-03 18:05:10 +0000",
    "user" : {
      "name" : "AllTheWayCute",
      "screen_name" : "AllTheWayCute",
      "protected" : false,
      "id_str" : "2717331290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501402660281393152\/OiF3MMDU_normal.jpeg",
      "id" : 2717331290,
      "verified" : false
    }
  },
  "id" : 697576504927113217,
  "created_at" : "2016-02-11 00:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 6, 18 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697565041910894592",
  "text" : "hmm.. @mindymayhem hasn't tweeted in awhile (since Dec). I hope she's ok.",
  "id" : 697565041910894592,
  "created_at" : "2016-02-10 23:37:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tonile Wortley",
      "screen_name" : "tonilehelena",
      "indices" : [ 49, 62 ],
      "id_str" : "15144635",
      "id" : 15144635
    }, {
      "name" : "Lisa",
      "screen_name" : "TenaciousReader",
      "indices" : [ 64, 80 ],
      "id_str" : "252264083",
      "id" : 252264083
    }, {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 82, 95 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/pLHNCHl0cZ",
      "expanded_url" : "https:\/\/listenupaudiobooks.wordpress.com\/2016\/02\/10\/audiobook-news-reviews-25-210\/",
      "display_url" : "listenupaudiobooks.wordpress.com\/2016\/02\/10\/aud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697552985870766080",
  "text" : "RT @Listen2Books: Audiobook News &amp; Reviews w\/@tonilehelena, @TenaciousReader, @audiobookrev &amp; more! https:\/\/t.co\/pLHNCHl0cZ https:\/\/t.co\/gg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tonile Wortley",
        "screen_name" : "tonilehelena",
        "indices" : [ 31, 44 ],
        "id_str" : "15144635",
        "id" : 15144635
      }, {
        "name" : "Lisa",
        "screen_name" : "TenaciousReader",
        "indices" : [ 46, 62 ],
        "id_str" : "252264083",
        "id" : 252264083
      }, {
        "name" : "Audiobook Reviewer",
        "screen_name" : "AudioBookRev",
        "indices" : [ 64, 77 ],
        "id_str" : "457997266",
        "id" : 457997266
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Listen2Books\/status\/697548991118987264\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/ggxKlC8qrn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4xHFVUcAAEdk6.jpg",
        "id_str" : "697548990049447936",
        "id" : 697548990049447936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4xHFVUcAAEdk6.jpg",
        "sizes" : [ {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ggxKlC8qrn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/pLHNCHl0cZ",
        "expanded_url" : "https:\/\/listenupaudiobooks.wordpress.com\/2016\/02\/10\/audiobook-news-reviews-25-210\/",
        "display_url" : "listenupaudiobooks.wordpress.com\/2016\/02\/10\/aud\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697548991118987264",
    "text" : "Audiobook News &amp; Reviews w\/@tonilehelena, @TenaciousReader, @audiobookrev &amp; more! https:\/\/t.co\/pLHNCHl0cZ https:\/\/t.co\/ggxKlC8qrn",
    "id" : 697548991118987264,
    "created_at" : "2016-02-10 22:33:33 +0000",
    "user" : {
      "name" : "ListenUp Audiobooks",
      "screen_name" : "ListenUpAudio",
      "protected" : false,
      "id_str" : "423665516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798245817324683264\/GINN5xbO_normal.jpg",
      "id" : 423665516,
      "verified" : false
    }
  },
  "id" : 697552985870766080,
  "created_at" : "2016-02-10 22:49:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/697523802079686656\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/gnP9YyYdlz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4aMrDW4AAKM3w.jpg",
      "id_str" : "697523797306564608",
      "id" : 697523797306564608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4aMrDW4AAKM3w.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gnP9YyYdlz"
    } ],
    "hashtags" : [ {
      "text" : "CDWG",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "LovesintheAir",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697523913828519937",
  "text" : "RT @CamoDave_: The Collared Doves are starting to get a bit frisky in the #CDWG today 10\/2\/2016 #LovesintheAir https:\/\/t.co\/gnP9YyYdlz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/697523802079686656\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/gnP9YyYdlz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4aMrDW4AAKM3w.jpg",
        "id_str" : "697523797306564608",
        "id" : 697523797306564608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4aMrDW4AAKM3w.jpg",
        "sizes" : [ {
          "h" : 674,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 674
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gnP9YyYdlz"
      } ],
      "hashtags" : [ {
        "text" : "CDWG",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "LovesintheAir",
        "indices" : [ 81, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697523802079686656",
    "text" : "The Collared Doves are starting to get a bit frisky in the #CDWG today 10\/2\/2016 #LovesintheAir https:\/\/t.co\/gnP9YyYdlz",
    "id" : 697523802079686656,
    "created_at" : "2016-02-10 20:53:28 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 697523913828519937,
  "created_at" : "2016-02-10 20:53:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "indices" : [ 3, 17 ],
      "id_str" : "39764564",
      "id" : 39764564
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/697356388784283648\/video\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/6C0hiW5G1V",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/697351431100243973\/pu\/img\/7dgNR6PLqPgQ8hRK.jpg",
      "id_str" : "697351431100243973",
      "id" : 697351431100243973,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/697351431100243973\/pu\/img\/7dgNR6PLqPgQ8hRK.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6C0hiW5G1V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697442014552592384",
  "text" : "RT @ruslandvalley: Listen to the birdsong outside my kitchen door \u2764\uFE0F https:\/\/t.co\/6C0hiW5G1V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/697356388784283648\/video\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/6C0hiW5G1V",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/697351431100243973\/pu\/img\/7dgNR6PLqPgQ8hRK.jpg",
        "id_str" : "697351431100243973",
        "id" : 697351431100243973,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/697351431100243973\/pu\/img\/7dgNR6PLqPgQ8hRK.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6C0hiW5G1V"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697356388784283648",
    "text" : "Listen to the birdsong outside my kitchen door \u2764\uFE0F https:\/\/t.co\/6C0hiW5G1V",
    "id" : 697356388784283648,
    "created_at" : "2016-02-10 09:48:13 +0000",
    "user" : {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "protected" : false,
      "id_str" : "39764564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724649178589179904\/f5KDvdpC_normal.jpg",
      "id" : 39764564,
      "verified" : false
    }
  },
  "id" : 697442014552592384,
  "created_at" : "2016-02-10 15:28:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/697346754522583040\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/EGDNA8S6NI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca15Ih_WEAAVes5.jpg",
      "id_str" : "697346704782266368",
      "id" : 697346704782266368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca15Ih_WEAAVes5.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EGDNA8S6NI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/697346754522583040\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/EGDNA8S6NI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca15IiYWIAAxxZL.jpg",
      "id_str" : "697346704887128064",
      "id" : 697346704887128064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca15IiYWIAAxxZL.jpg",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1485
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EGDNA8S6NI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697441820184342528",
  "text" : "RT @newlandfarm: They're back, any Magician missing some Doves? https:\/\/t.co\/EGDNA8S6NI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/697346754522583040\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/EGDNA8S6NI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca15Ih_WEAAVes5.jpg",
        "id_str" : "697346704782266368",
        "id" : 697346704782266368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca15Ih_WEAAVes5.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EGDNA8S6NI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/697346754522583040\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/EGDNA8S6NI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca15IiYWIAAxxZL.jpg",
        "id_str" : "697346704887128064",
        "id" : 697346704887128064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca15IiYWIAAxxZL.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1485
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EGDNA8S6NI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697346754522583040",
    "text" : "They're back, any Magician missing some Doves? https:\/\/t.co\/EGDNA8S6NI",
    "id" : 697346754522583040,
    "created_at" : "2016-02-10 09:09:57 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 697441820184342528,
  "created_at" : "2016-02-10 15:27:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697413592396787712",
  "geo" : { },
  "id_str" : "697441750512754688",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep you are so awesome. : )",
  "id" : 697441750512754688,
  "in_reply_to_status_id" : 697413592396787712,
  "created_at" : "2016-02-10 15:27:25 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Mac",
      "screen_name" : "LeslieMac",
      "indices" : [ 3, 13 ],
      "id_str" : "14235543",
      "id" : 14235543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697204480731910144",
  "text" : "RT @LeslieMac: In #Flint all day today. If you had to wake up every day &amp; needed to scramble to figure out where you can get water - what w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Flint",
        "indices" : [ 3, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697084935144923136",
    "text" : "In #Flint all day today. If you had to wake up every day &amp; needed to scramble to figure out where you can get water - what would you do?",
    "id" : 697084935144923136,
    "created_at" : "2016-02-09 15:49:34 +0000",
    "user" : {
      "name" : "Leslie Mac",
      "screen_name" : "LeslieMac",
      "protected" : false,
      "id_str" : "14235543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793402921786322944\/yCSUJq8q_normal.jpg",
      "id" : 14235543,
      "verified" : true
    }
  },
  "id" : 697204480731910144,
  "created_at" : "2016-02-09 23:44:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "review",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/aRW0DxLFSa",
      "expanded_url" : "https:\/\/youtu.be\/HMbCFnwTCj4",
      "display_url" : "youtu.be\/HMbCFnwTCj4"
    } ]
  },
  "geo" : { },
  "id_str" : "697193750280466433",
  "text" : "Scatter Adapt and Remember by Annalee Newitz https:\/\/t.co\/aRW0DxLFSa #audiobooks #review",
  "id" : 697193750280466433,
  "created_at" : "2016-02-09 23:01:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "youtube",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/NHBWH60Rw4",
      "expanded_url" : "https:\/\/youtu.be\/9rCfI5a6PIQ",
      "display_url" : "youtu.be\/9rCfI5a6PIQ"
    } ]
  },
  "geo" : { },
  "id_str" : "697192665746644996",
  "text" : "Fine Bro's Are Tip Of The \"Fraud\" Iceberg https:\/\/t.co\/NHBWH60Rw4 #audiobooks #youtube",
  "id" : 697192665746644996,
  "created_at" : "2016-02-09 22:57:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697165447557464064",
  "text" : "finally got voter reg form printed so DD can register to vote in Primary.. yay!",
  "id" : 697165447557464064,
  "created_at" : "2016-02-09 21:09:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Support",
      "screen_name" : "WindowsSupport",
      "indices" : [ 0, 15 ],
      "id_str" : "875957876",
      "id" : 875957876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697148210343714817",
  "geo" : { },
  "id_str" : "697165144892305408",
  "in_reply_to_user_id" : 875957876,
  "text" : "@WindowsSupport huh.. removed printer, installed again, driver downloaded. then it worked. but will it work tomorrow? ;D (ps. thanks)",
  "id" : 697165144892305408,
  "in_reply_to_status_id" : 697148210343714817,
  "created_at" : "2016-02-09 21:08:17 +0000",
  "in_reply_to_screen_name" : "WindowsSupport",
  "in_reply_to_user_id_str" : "875957876",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Support",
      "screen_name" : "WindowsSupport",
      "indices" : [ 0, 15 ],
      "id_str" : "875957876",
      "id" : 875957876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697097879710777345",
  "geo" : { },
  "id_str" : "697139163892678656",
  "in_reply_to_user_id" : 875957876,
  "text" : "@WindowsSupport server print spooler service not running. my pc prints via wifi thru another pc thats wired to printer.",
  "id" : 697139163892678656,
  "in_reply_to_status_id" : 697097879710777345,
  "created_at" : "2016-02-09 19:25:03 +0000",
  "in_reply_to_screen_name" : "WindowsSupport",
  "in_reply_to_user_id_str" : "875957876",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697136130056179712",
  "text" : "dh, dd and I just had \"lively\" discussion re: racism, \"reverse\" racism. it was thought provoking really.",
  "id" : 697136130056179712,
  "created_at" : "2016-02-09 19:13:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TongueOutEwesday",
      "screen_name" : "tongueoutewes",
      "indices" : [ 3, 17 ],
      "id_str" : "4867240780",
      "id" : 4867240780
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tongueoutewes\/status\/697130809782837248\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/JDkTG0Sjqn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cay0xj4XIAA8ZEP.jpg",
      "id_str" : "697130805873811456",
      "id" : 697130805873811456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cay0xj4XIAA8ZEP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JDkTG0Sjqn"
    } ],
    "hashtags" : [ {
      "text" : "tongueOutEwesday",
      "indices" : [ 79, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697135378441052160",
  "text" : "RT @tongueoutewes: Who likes sheep with their tongues out? \uD83D\uDC0F\uD83D\uDC45\uD83D\uDC0F\nWe do! Tag them #tongueOutEwesday and we'll RT them. https:\/\/t.co\/JDkTG0Sjqn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tongueoutewes\/status\/697130809782837248\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/JDkTG0Sjqn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cay0xj4XIAA8ZEP.jpg",
        "id_str" : "697130805873811456",
        "id" : 697130805873811456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cay0xj4XIAA8ZEP.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JDkTG0Sjqn"
      } ],
      "hashtags" : [ {
        "text" : "tongueOutEwesday",
        "indices" : [ 60, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697130809782837248",
    "text" : "Who likes sheep with their tongues out? \uD83D\uDC0F\uD83D\uDC45\uD83D\uDC0F\nWe do! Tag them #tongueOutEwesday and we'll RT them. https:\/\/t.co\/JDkTG0Sjqn",
    "id" : 697130809782837248,
    "created_at" : "2016-02-09 18:51:51 +0000",
    "user" : {
      "name" : "TongueOutEwesday",
      "screen_name" : "tongueoutewes",
      "protected" : false,
      "id_str" : "4867240780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697129311959195652\/9c3FZ0bK_normal.jpg",
      "id" : 4867240780,
      "verified" : false
    }
  },
  "id" : 697135378441052160,
  "created_at" : "2016-02-09 19:10:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Californicator (TMI)",
      "screen_name" : "FloodyHippie",
      "indices" : [ 3, 16 ],
      "id_str" : "2851482614",
      "id" : 2851482614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697131271475040256",
  "text" : "RT @FloodyHippie: There are children who live their lives in war zones, and I can't summon the courage to answer my phone when it rings.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694512346396381184",
    "text" : "There are children who live their lives in war zones, and I can't summon the courage to answer my phone when it rings.",
    "id" : 694512346396381184,
    "created_at" : "2016-02-02 13:27:01 +0000",
    "user" : {
      "name" : "Californicator (TMI)",
      "screen_name" : "FloodyHippie",
      "protected" : false,
      "id_str" : "2851482614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730022621211828224\/Zo3OnU2h_normal.jpg",
      "id" : 2851482614,
      "verified" : false
    }
  },
  "id" : 697131271475040256,
  "created_at" : "2016-02-09 18:53:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/697130388007821316\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/F3sYvCMe8S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cay0ZOYWcAEIOxT.jpg",
      "id_str" : "697130387785543681",
      "id" : 697130387785543681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cay0ZOYWcAEIOxT.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/F3sYvCMe8S"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/ajKykGdEpf",
      "expanded_url" : "http:\/\/ebks.to\/1WVmi25",
      "display_url" : "ebks.to\/1WVmi25"
    } ]
  },
  "geo" : { },
  "id_str" : "697130516475224064",
  "text" : "RT @ebookfriendly: Oh yeaaah! https:\/\/t.co\/ajKykGdEpf https:\/\/t.co\/F3sYvCMe8S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/697130388007821316\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/F3sYvCMe8S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cay0ZOYWcAEIOxT.jpg",
        "id_str" : "697130387785543681",
        "id" : 697130387785543681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cay0ZOYWcAEIOxT.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 705,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 705,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 705,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/F3sYvCMe8S"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/ajKykGdEpf",
        "expanded_url" : "http:\/\/ebks.to\/1WVmi25",
        "display_url" : "ebks.to\/1WVmi25"
      } ]
    },
    "geo" : { },
    "id_str" : "697130388007821316",
    "text" : "Oh yeaaah! https:\/\/t.co\/ajKykGdEpf https:\/\/t.co\/F3sYvCMe8S",
    "id" : 697130388007821316,
    "created_at" : "2016-02-09 18:50:11 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 697130516475224064,
  "created_at" : "2016-02-09 18:50:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2721\u03B1\u2113\u24BC\u24B9\u24B6\u24B9\uFF11c\u044F\u03B9s\u03C9\u03B5\u2113\u2113\uD83C\uDF08",
      "screen_name" : "Gdad1",
      "indices" : [ 3, 9 ],
      "id_str" : "15545122",
      "id" : 15545122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697123432794824705",
  "text" : "RT @Gdad1: Today's GOP: We don't give a damn about water! We just want to be in your bedroom!\nMI REPS Pass Bill Making Sodomy.. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/MiPD9tr9IO",
        "expanded_url" : "https:\/\/shar.es\/14uW5c",
        "display_url" : "shar.es\/14uW5c"
      } ]
    },
    "geo" : { },
    "id_str" : "697086707837964289",
    "text" : "Today's GOP: We don't give a damn about water! We just want to be in your bedroom!\nMI REPS Pass Bill Making Sodomy.. https:\/\/t.co\/MiPD9tr9IO",
    "id" : 697086707837964289,
    "created_at" : "2016-02-09 15:56:37 +0000",
    "user" : {
      "name" : "\u2721\u03B1\u2113\u24BC\u24B9\u24B6\u24B9\uFF11c\u044F\u03B9s\u03C9\u03B5\u2113\u2113\uD83C\uDF08",
      "screen_name" : "Gdad1",
      "protected" : false,
      "id_str" : "15545122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799632195916800000\/Li2iwbB__normal.jpg",
      "id" : 15545122,
      "verified" : false
    }
  },
  "id" : 697123432794824705,
  "created_at" : "2016-02-09 18:22:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Windows10",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697089323439673345",
  "text" : "im joining the #Windows10 sucks bandwagon. since dh has had win10.. i have issues every single time I want to print. argh!",
  "id" : 697089323439673345,
  "created_at" : "2016-02-09 16:07:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyme Stats",
      "screen_name" : "lymestats",
      "indices" : [ 3, 13 ],
      "id_str" : "3059408982",
      "id" : 3059408982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lymestats\/status\/691902247043756034\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/zcSoMQe46v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZohbWNWwAAeVDd.jpg",
      "id_str" : "691902246456573952",
      "id" : 691902246456573952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZohbWNWwAAeVDd.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1700,
        "resize" : "fit",
        "w" : 1700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zcSoMQe46v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/WSzoXwNcip",
      "expanded_url" : "https:\/\/www.change.org\/p\/president-obama-and-congress-a-call-to-legalize-lyme-disease",
      "display_url" : "change.org\/p\/president-ob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697078819765641216",
  "text" : "RT @lymestats: Dr Alan MacDonald finds Lyme Borrelia in 5 out of 5 brain tumor biopsies. https:\/\/t.co\/WSzoXwNcip https:\/\/t.co\/zcSoMQe46v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lymestats\/status\/691902247043756034\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/zcSoMQe46v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZohbWNWwAAeVDd.jpg",
        "id_str" : "691902246456573952",
        "id" : 691902246456573952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZohbWNWwAAeVDd.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1700,
          "resize" : "fit",
          "w" : 1700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zcSoMQe46v"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/WSzoXwNcip",
        "expanded_url" : "https:\/\/www.change.org\/p\/president-obama-and-congress-a-call-to-legalize-lyme-disease",
        "display_url" : "change.org\/p\/president-ob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691902247043756034",
    "text" : "Dr Alan MacDonald finds Lyme Borrelia in 5 out of 5 brain tumor biopsies. https:\/\/t.co\/WSzoXwNcip https:\/\/t.co\/zcSoMQe46v",
    "id" : 691902247043756034,
    "created_at" : "2016-01-26 08:35:25 +0000",
    "user" : {
      "name" : "Lyme Stats",
      "screen_name" : "lymestats",
      "protected" : false,
      "id_str" : "3059408982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593242186734383105\/JjzbavQQ_normal.png",
      "id" : 3059408982,
      "verified" : false
    }
  },
  "id" : 697078819765641216,
  "created_at" : "2016-02-09 15:25:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696835621403430912",
  "geo" : { },
  "id_str" : "696841191988584453",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep uh oh...",
  "id" : 696841191988584453,
  "in_reply_to_status_id" : 696835621403430912,
  "created_at" : "2016-02-08 23:41:01 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/579507355190185984\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/iDv5b8wTRb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CArS3nUWcAAhhzJ.jpg",
      "id_str" : "579507354959507456",
      "id" : 579507354959507456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CArS3nUWcAAhhzJ.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/iDv5b8wTRb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696793141278601217",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/iDv5b8wTRb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/579507355190185984\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/iDv5b8wTRb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CArS3nUWcAAhhzJ.jpg",
        "id_str" : "579507354959507456",
        "id" : 579507354959507456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CArS3nUWcAAhhzJ.jpg",
        "sizes" : [ {
          "h" : 381,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/iDv5b8wTRb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696789344972054528",
    "text" : "https:\/\/t.co\/iDv5b8wTRb",
    "id" : 696789344972054528,
    "created_at" : "2016-02-08 20:15:00 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 696793141278601217,
  "created_at" : "2016-02-08 20:30:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/BdBHZw3qUb",
      "expanded_url" : "http:\/\/goo.gl\/lXf2A4",
      "display_url" : "goo.gl\/lXf2A4"
    } ]
  },
  "geo" : { },
  "id_str" : "696722131451842560",
  "text" : "RT @5x5: \u201COlder Ladies\u201D song\/video by Donnalou Stevens https:\/\/t.co\/BdBHZw3qUb #love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 70, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/BdBHZw3qUb",
        "expanded_url" : "http:\/\/goo.gl\/lXf2A4",
        "display_url" : "goo.gl\/lXf2A4"
      } ]
    },
    "geo" : { },
    "id_str" : "696700946462674945",
    "text" : "\u201COlder Ladies\u201D song\/video by Donnalou Stevens https:\/\/t.co\/BdBHZw3qUb #love",
    "id" : 696700946462674945,
    "created_at" : "2016-02-08 14:23:44 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 696722131451842560,
  "created_at" : "2016-02-08 15:47:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/696647566839189504\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vcEbb9gnPG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Car9RQvW0AAnaaA.jpg",
      "id_str" : "696647565375361024",
      "id" : 696647565375361024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Car9RQvW0AAnaaA.jpg",
      "sizes" : [ {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1121
      } ],
      "display_url" : "pic.twitter.com\/vcEbb9gnPG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696710352017473537",
  "text" : "RT @Swanwhisperer: only got up at 10.30 now its nearly 11am, oh dear . Looking like filming all afternoon then https:\/\/t.co\/vcEbb9gnPG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/696647566839189504\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/vcEbb9gnPG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Car9RQvW0AAnaaA.jpg",
        "id_str" : "696647565375361024",
        "id" : 696647565375361024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Car9RQvW0AAnaaA.jpg",
        "sizes" : [ {
          "h" : 155,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1121
        } ],
        "display_url" : "pic.twitter.com\/vcEbb9gnPG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696647566839189504",
    "text" : "only got up at 10.30 now its nearly 11am, oh dear . Looking like filming all afternoon then https:\/\/t.co\/vcEbb9gnPG",
    "id" : 696647566839189504,
    "created_at" : "2016-02-08 10:51:37 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 696710352017473537,
  "created_at" : "2016-02-08 15:01:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firedoglake",
      "screen_name" : "firedoglake",
      "indices" : [ 3, 15 ],
      "id_str" : "16013368",
      "id" : 16013368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Denver",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "Police",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "FreeSpeech",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VSmFtLSLd6",
      "expanded_url" : "http:\/\/bit.ly\/23MmNjD",
      "display_url" : "bit.ly\/23MmNjD"
    } ]
  },
  "geo" : { },
  "id_str" : "696442024594182144",
  "text" : "RT @firedoglake: #Denver Police Manual Reveals Use Of Torture On Peaceful Protesters https:\/\/t.co\/VSmFtLSLd6\n\n#Police #FreeSpeech https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/firedoglake\/status\/696439821602914304\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/GuxhFmXR0t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CalpX2zVAAADdDr.jpg",
        "id_str" : "696203475974160384",
        "id" : 696203475974160384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CalpX2zVAAADdDr.jpg",
        "sizes" : [ {
          "h" : 193,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 86,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GuxhFmXR0t"
      } ],
      "hashtags" : [ {
        "text" : "Denver",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Police",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "FreeSpeech",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/VSmFtLSLd6",
        "expanded_url" : "http:\/\/bit.ly\/23MmNjD",
        "display_url" : "bit.ly\/23MmNjD"
      } ]
    },
    "geo" : { },
    "id_str" : "696439821602914304",
    "text" : "#Denver Police Manual Reveals Use Of Torture On Peaceful Protesters https:\/\/t.co\/VSmFtLSLd6\n\n#Police #FreeSpeech https:\/\/t.co\/GuxhFmXR0t",
    "id" : 696439821602914304,
    "created_at" : "2016-02-07 21:06:07 +0000",
    "user" : {
      "name" : "Firedoglake",
      "screen_name" : "firedoglake",
      "protected" : false,
      "id_str" : "16013368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459071374024118272\/V6ZgiO0z_normal.png",
      "id" : 16013368,
      "verified" : false
    }
  },
  "id" : 696442024594182144,
  "created_at" : "2016-02-07 21:14:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696376532558811140",
  "text" : "if using my pc as a server (ie. booksonic to stream audiobooks) I have to leave said pc on when I want to stream? #tech",
  "id" : 696376532558811140,
  "created_at" : "2016-02-07 16:54:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/wgVArCMPf2",
      "expanded_url" : "https:\/\/popeen.com\/2016\/02\/05\/booksonic-server-is-out-of-beta-i-celebrate-with-an-app-giveaway\/",
      "display_url" : "popeen.com\/2016\/02\/05\/boo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696373283801997312",
  "text" : "Booksonic server is out of BETA. I celebrate with an app giveaway https:\/\/t.co\/wgVArCMPf2 #audiobooks",
  "id" : 696373283801997312,
  "created_at" : "2016-02-07 16:41:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/696372668090732546\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/aKYZJal8nW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaoDP89WAAA1Xu0.jpg",
      "id_str" : "696372664978505728",
      "id" : 696372664978505728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaoDP89WAAA1Xu0.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/aKYZJal8nW"
    } ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/YNehvOEGZg",
      "expanded_url" : "https:\/\/popeen.com\/2016\/01\/14\/how-to-stream-audiobooks-to-your-phone-with-booksonic?_ts=1454863155",
      "display_url" : "popeen.com\/2016\/01\/14\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696372668090732546",
  "text" : "How to stream #audiobooks to your phone with Booksonic \u2013 https:\/\/t.co\/YNehvOEGZg https:\/\/t.co\/aKYZJal8nW",
  "id" : 696372668090732546,
  "created_at" : "2016-02-07 16:39:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Walfred",
      "screen_name" : "MWalfred",
      "indices" : [ 3, 12 ],
      "id_str" : "2192473280",
      "id" : 2192473280
    }, {
      "name" : "XFINITY",
      "screen_name" : "XFINITY",
      "indices" : [ 15, 23 ],
      "id_str" : "14996251",
      "id" : 14996251
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MWalfred\/status\/696354371672502273\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/g3HWMmGLl1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CanymsiVIAA7zxn.jpg",
      "id_str" : "696354364009553920",
      "id" : 696354364009553920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CanymsiVIAA7zxn.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g3HWMmGLl1"
    } ],
    "hashtags" : [ {
      "text" : "Siamese",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696370668632416257",
  "text" : "RT @MWalfred: .@XFINITY can your customer service help us with a possessive #Siamese? https:\/\/t.co\/g3HWMmGLl1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "XFINITY",
        "screen_name" : "XFINITY",
        "indices" : [ 1, 9 ],
        "id_str" : "14996251",
        "id" : 14996251
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MWalfred\/status\/696354371672502273\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/g3HWMmGLl1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CanymsiVIAA7zxn.jpg",
        "id_str" : "696354364009553920",
        "id" : 696354364009553920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CanymsiVIAA7zxn.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g3HWMmGLl1"
      } ],
      "hashtags" : [ {
        "text" : "Siamese",
        "indices" : [ 62, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696354371672502273",
    "text" : ".@XFINITY can your customer service help us with a possessive #Siamese? https:\/\/t.co\/g3HWMmGLl1",
    "id" : 696354371672502273,
    "created_at" : "2016-02-07 15:26:34 +0000",
    "user" : {
      "name" : "Michele Walfred",
      "screen_name" : "MWalfred",
      "protected" : false,
      "id_str" : "2192473280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792849802199302144\/NqBfFW08_normal.jpg",
      "id" : 2192473280,
      "verified" : false
    }
  },
  "id" : 696370668632416257,
  "created_at" : "2016-02-07 16:31:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696369305005461504",
  "text" : "I'm 51% through Death's Heretic (Unabridged) by James L. Sutter, narrated by Ray Porter on my Audible app.",
  "id" : 696369305005461504,
  "created_at" : "2016-02-07 16:25:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Langhinrichs",
      "screen_name" : "SaraLang",
      "indices" : [ 3, 12 ],
      "id_str" : "15754851",
      "id" : 15754851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696368251035652100",
  "text" : "RT @SaraLang: Who Would Jesus Waterboard?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696164487368302592",
    "text" : "Who Would Jesus Waterboard?",
    "id" : 696164487368302592,
    "created_at" : "2016-02-07 02:52:02 +0000",
    "user" : {
      "name" : "Sara Langhinrichs",
      "screen_name" : "SaraLang",
      "protected" : false,
      "id_str" : "15754851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708270181621960706\/NvsE_gFN_normal.jpg",
      "id" : 15754851,
      "verified" : false
    }
  },
  "id" : 696368251035652100,
  "created_at" : "2016-02-07 16:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Planned Parenthood",
      "screen_name" : "PPact",
      "indices" : [ 3, 9 ],
      "id_str" : "22162854",
      "id" : 22162854
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 23, 31 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696367391119437825",
  "text" : "RT @PPact: FACT CHECK: @tedcruz wants to keep the government from getting between people &amp; their doctors \u2014 except when it comes to women. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 12, 20 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 131, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696162281017638912",
    "text" : "FACT CHECK: @tedcruz wants to keep the government from getting between people &amp; their doctors \u2014 except when it comes to women. #GOPDebate",
    "id" : 696162281017638912,
    "created_at" : "2016-02-07 02:43:16 +0000",
    "user" : {
      "name" : "Planned Parenthood",
      "screen_name" : "PPact",
      "protected" : false,
      "id_str" : "22162854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796736794452598784\/OVVnbWE7_normal.jpg",
      "id" : 22162854,
      "verified" : true
    }
  },
  "id" : 696367391119437825,
  "created_at" : "2016-02-07 16:18:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel \uD83D\uDCCE",
      "screen_name" : "the_dol",
      "indices" : [ 3, 11 ],
      "id_str" : "296449773",
      "id" : 296449773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/6T1Wn084bn",
      "expanded_url" : "https:\/\/twitter.com\/naral\/status\/696177635475361792",
      "display_url" : "twitter.com\/naral\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696366965145911300",
  "text" : "RT @the_dol: Or a person in the path of a carpet bomb. Or a death penalty inmate. Or a black person.  https:\/\/t.co\/6T1Wn084bn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/6T1Wn084bn",
        "expanded_url" : "https:\/\/twitter.com\/naral\/status\/696177635475361792",
        "display_url" : "twitter.com\/naral\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "696178596201672704",
    "text" : "Or a person in the path of a carpet bomb. Or a death penalty inmate. Or a black person.  https:\/\/t.co\/6T1Wn084bn",
    "id" : 696178596201672704,
    "created_at" : "2016-02-07 03:48:06 +0000",
    "user" : {
      "name" : "Rachel \uD83D\uDCCE",
      "screen_name" : "the_dol",
      "protected" : false,
      "id_str" : "296449773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798028608337915904\/10EHAkaR_normal.jpg",
      "id" : 296449773,
      "verified" : false
    }
  },
  "id" : 696366965145911300,
  "created_at" : "2016-02-07 16:16:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dezmion Barrow",
      "screen_name" : "dezthepioneer",
      "indices" : [ 3, 17 ],
      "id_str" : "172441959",
      "id" : 172441959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bEHNpAxTM5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BBb5ke0pL7t\/",
      "display_url" : "instagram.com\/p\/BBb5ke0pL7t\/"
    } ]
  },
  "geo" : { },
  "id_str" : "696008565715292160",
  "text" : "RT @dezthepioneer: Listening to my New audio book and I must say this one is the truth smh. I'm having a brain\u2026 https:\/\/t.co\/bEHNpAxTM5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/bEHNpAxTM5",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BBb5ke0pL7t\/",
        "display_url" : "instagram.com\/p\/BBb5ke0pL7t\/"
      } ]
    },
    "geo" : { },
    "id_str" : "695867085071654912",
    "text" : "Listening to my New audio book and I must say this one is the truth smh. I'm having a brain\u2026 https:\/\/t.co\/bEHNpAxTM5",
    "id" : 695867085071654912,
    "created_at" : "2016-02-06 07:10:16 +0000",
    "user" : {
      "name" : "Dezmion Barrow",
      "screen_name" : "dezthepioneer",
      "protected" : false,
      "id_str" : "172441959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000696856312\/c654cb89e1f34f0bebb33c7e7b9e92d9_normal.jpeg",
      "id" : 172441959,
      "verified" : false
    }
  },
  "id" : 696008565715292160,
  "created_at" : "2016-02-06 16:32:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "indices" : [ 3, 15 ],
      "id_str" : "14345566",
      "id" : 14345566
    }, {
      "name" : "Christin Miserandino",
      "screen_name" : "bydls",
      "indices" : [ 80, 86 ],
      "id_str" : "9196392",
      "id" : 9196392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696006375919505408",
  "text" : "RT @TheBloggess: ...But in case you missed it you should read theSpoon Theory.  @bydls helped me &amp; others more than she knows.  https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christin Miserandino",
        "screen_name" : "bydls",
        "indices" : [ 63, 69 ],
        "id_str" : "9196392",
        "id" : 9196392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/rIBfkG3kO2",
        "expanded_url" : "http:\/\/www.butyoudontlooksick.com\/articles\/written-by-christine\/the-spoon-theory\/",
        "display_url" : "butyoudontlooksick.com\/articles\/writt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695831781514194945",
    "text" : "...But in case you missed it you should read theSpoon Theory.  @bydls helped me &amp; others more than she knows.  https:\/\/t.co\/rIBfkG3kO2",
    "id" : 695831781514194945,
    "created_at" : "2016-02-06 04:49:59 +0000",
    "user" : {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "protected" : false,
      "id_str" : "14345566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1459362861\/cheesecake_copy2_normal.jpg",
      "id" : 14345566,
      "verified" : true
    }
  },
  "id" : 696006375919505408,
  "created_at" : "2016-02-06 16:23:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medicinal Marijuana",
      "screen_name" : "MedMarijuanaA",
      "indices" : [ 3, 17 ],
      "id_str" : "2548263246",
      "id" : 2548263246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cannabis",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "cannabismedicine",
      "indices" : [ 76, 93 ]
    }, {
      "text" : "medicalcannabis",
      "indices" : [ 94, 110 ]
    }, {
      "text" : "nausearelief",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/TwdzmYA55a",
      "expanded_url" : "http:\/\/ow.ly\/XxJqq",
      "display_url" : "ow.ly\/XxJqq"
    } ]
  },
  "geo" : { },
  "id_str" : "696003397242265603",
  "text" : "RT @MedMarijuanaA: How #Cannabis Can Relieve Nausea https:\/\/t.co\/TwdzmYA55a #cannabismedicine #medicalcannabis #nausearelief https:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MedMarijuanaA\/status\/695978215257612288\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/iNTixeyLal",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Caicf8VW4AAeYRG.jpg",
        "id_str" : "695978215014326272",
        "id" : 695978215014326272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Caicf8VW4AAeYRG.jpg",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/iNTixeyLal"
      } ],
      "hashtags" : [ {
        "text" : "Cannabis",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "cannabismedicine",
        "indices" : [ 57, 74 ]
      }, {
        "text" : "medicalcannabis",
        "indices" : [ 75, 91 ]
      }, {
        "text" : "nausearelief",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/TwdzmYA55a",
        "expanded_url" : "http:\/\/ow.ly\/XxJqq",
        "display_url" : "ow.ly\/XxJqq"
      } ]
    },
    "geo" : { },
    "id_str" : "695978215257612288",
    "text" : "How #Cannabis Can Relieve Nausea https:\/\/t.co\/TwdzmYA55a #cannabismedicine #medicalcannabis #nausearelief https:\/\/t.co\/iNTixeyLal",
    "id" : 695978215257612288,
    "created_at" : "2016-02-06 14:31:51 +0000",
    "user" : {
      "name" : "Medicinal Marijuana",
      "screen_name" : "MedMarijuanaA",
      "protected" : false,
      "id_str" : "2548263246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535137608209141760\/jl69gNz2_normal.jpeg",
      "id" : 2548263246,
      "verified" : false
    }
  },
  "id" : 696003397242265603,
  "created_at" : "2016-02-06 16:11:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695993464476008448",
  "text" : "I'm 35% through Death's Heretic (Unabridged) by James L. Sutter, narrated by Ray Porter on my Audible app.",
  "id" : 695993464476008448,
  "created_at" : "2016-02-06 15:32:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "feedly",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/RO6hk0tung",
      "expanded_url" : "http:\/\/samanthapfield.com\/2016\/02\/05\/being-a-christian-does-affect-my-ethics\/",
      "display_url" : "samanthapfield.com\/2016\/02\/05\/bei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695777594155864065",
  "text" : "Law of Kindness: how Christianity affects my ethics https:\/\/t.co\/RO6hk0tung #religion #feedly",
  "id" : 695777594155864065,
  "created_at" : "2016-02-06 01:14:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mjolnir\uD83E\uDD83MK86\u26A1\uFE0F",
      "screen_name" : "MjolnirMK86",
      "indices" : [ 3, 15 ],
      "id_str" : "140689622",
      "id" : 140689622
    }, {
      "name" : "Nerdy Show",
      "screen_name" : "nerdyshow",
      "indices" : [ 64, 74 ],
      "id_str" : "61105459",
      "id" : 61105459
    }, {
      "name" : "Brian LeTendre",
      "screen_name" : "SeeBrianWrite",
      "indices" : [ 75, 89 ],
      "id_str" : "14270675",
      "id" : 14270675
    }, {
      "name" : "PKMNcast.com",
      "screen_name" : "pokemonpodcast",
      "indices" : [ 90, 105 ],
      "id_str" : "170174151",
      "id" : 170174151
    }, {
      "name" : "No Apologies Podcast",
      "screen_name" : "NoApologies123",
      "indices" : [ 106, 121 ],
      "id_str" : "935884646",
      "id" : 935884646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695766689410105345",
  "text" : "RT @MjolnirMK86: You should all be listening to these podcasts. @nerdyshow @SeeBrianWrite @pokemonpodcast @NoApologies123 https:\/\/t.co\/4lCw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nerdy Show",
        "screen_name" : "nerdyshow",
        "indices" : [ 47, 57 ],
        "id_str" : "61105459",
        "id" : 61105459
      }, {
        "name" : "Brian LeTendre",
        "screen_name" : "SeeBrianWrite",
        "indices" : [ 58, 72 ],
        "id_str" : "14270675",
        "id" : 14270675
      }, {
        "name" : "PKMNcast.com",
        "screen_name" : "pokemonpodcast",
        "indices" : [ 73, 88 ],
        "id_str" : "170174151",
        "id" : 170174151
      }, {
        "name" : "No Apologies Podcast",
        "screen_name" : "NoApologies123",
        "indices" : [ 89, 104 ],
        "id_str" : "935884646",
        "id" : 935884646
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MjolnirMK86\/status\/695764319636758529\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/4lCwl5dCEY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CafZ9KUVIAAnL3M.jpg",
        "id_str" : "695764312216903680",
        "id" : 695764312216903680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CafZ9KUVIAAnL3M.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/4lCwl5dCEY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695764319636758529",
    "text" : "You should all be listening to these podcasts. @nerdyshow @SeeBrianWrite @pokemonpodcast @NoApologies123 https:\/\/t.co\/4lCwl5dCEY",
    "id" : 695764319636758529,
    "created_at" : "2016-02-06 00:21:55 +0000",
    "user" : {
      "name" : "Mjolnir\uD83E\uDD83MK86\u26A1\uFE0F",
      "screen_name" : "MjolnirMK86",
      "protected" : false,
      "id_str" : "140689622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789647093342302209\/TZWMzQIf_normal.jpg",
      "id" : 140689622,
      "verified" : false
    }
  },
  "id" : 695766689410105345,
  "created_at" : "2016-02-06 00:31:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Windows10",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/HVJUbNU36a",
      "expanded_url" : "http:\/\/ultimateoutsider.com\/downloads\/",
      "display_url" : "ultimateoutsider.com\/downloads\/"
    }, {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/pvhmfuO0JH",
      "expanded_url" : "https:\/\/twitter.com\/UnseelieMe\/status\/695664294017572864",
      "display_url" : "twitter.com\/UnseelieMe\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695742452716695552",
  "text" : "i got this to keep #Windows10 away &gt; https:\/\/t.co\/HVJUbNU36a GWX Control Panel https:\/\/t.co\/pvhmfuO0JH",
  "id" : 695742452716695552,
  "created_at" : "2016-02-05 22:55:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/onealexharms\/status\/695632869218095104\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/KznGLpVqVb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CadiJwtXEAAKwYz.png",
      "id_str" : "695632587285532672",
      "id" : 695632587285532672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CadiJwtXEAAKwYz.png",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 697
      } ],
      "display_url" : "pic.twitter.com\/KznGLpVqVb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/XFborhf7ug",
      "expanded_url" : "http:\/\/mosaicscience.com\/story\/why-calorie-broken",
      "display_url" : "mosaicscience.com\/story\/why-calo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695643617495490564",
  "text" : "RT @onealexharms: \u201Cobese\u2026 lean\u2026 exact same diet\u201D \nhttps:\/\/t.co\/XFborhf7ug https:\/\/t.co\/KznGLpVqVb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/onealexharms\/status\/695632869218095104\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/KznGLpVqVb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CadiJwtXEAAKwYz.png",
        "id_str" : "695632587285532672",
        "id" : 695632587285532672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CadiJwtXEAAKwYz.png",
        "sizes" : [ {
          "h" : 216,
          "resize" : "fit",
          "w" : 697
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 105,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 697
        } ],
        "display_url" : "pic.twitter.com\/KznGLpVqVb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/XFborhf7ug",
        "expanded_url" : "http:\/\/mosaicscience.com\/story\/why-calorie-broken",
        "display_url" : "mosaicscience.com\/story\/why-calo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695632869218095104",
    "text" : "\u201Cobese\u2026 lean\u2026 exact same diet\u201D \nhttps:\/\/t.co\/XFborhf7ug https:\/\/t.co\/KznGLpVqVb",
    "id" : 695632869218095104,
    "created_at" : "2016-02-05 15:39:34 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 695643617495490564,
  "created_at" : "2016-02-05 16:22:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Bowers",
      "screen_name" : "andybowers",
      "indices" : [ 3, 14 ],
      "id_str" : "16007952",
      "id" : 16007952
    }, {
      "name" : "Susan Cain",
      "screen_name" : "susancain",
      "indices" : [ 47, 57 ],
      "id_str" : "16581861",
      "id" : 16581861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695630412991897601",
  "text" : "RT @andybowers: Introverts unite! The terrific @susancain has a new podcast that starts where her massive bestseller Quiet left off. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Cain",
        "screen_name" : "susancain",
        "indices" : [ 31, 41 ],
        "id_str" : "16581861",
        "id" : 16581861
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/cqaV1CWksz",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/podcast\/quiet-power-introverts-susan\/id1065074566?mt=2",
        "display_url" : "itunes.apple.com\/us\/podcast\/qui\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695334329124163584",
    "text" : "Introverts unite! The terrific @susancain has a new podcast that starts where her massive bestseller Quiet left off. https:\/\/t.co\/cqaV1CWksz",
    "id" : 695334329124163584,
    "created_at" : "2016-02-04 19:53:17 +0000",
    "user" : {
      "name" : "Andy Bowers",
      "screen_name" : "andybowers",
      "protected" : false,
      "id_str" : "16007952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710834407960084480\/Jv9G3YuG_normal.jpg",
      "id" : 16007952,
      "verified" : true
    }
  },
  "id" : 695630412991897601,
  "created_at" : "2016-02-05 15:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "indices" : [ 3, 13 ],
      "id_str" : "410135192",
      "id" : 410135192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "politics",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695627591785562113",
  "text" : "RT @laprofe63: I'm impressed by how passionate some are about their chosen candidate. Let's just hope ppl remember #politics often requires\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "politics",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695625106635284480",
    "text" : "I'm impressed by how passionate some are about their chosen candidate. Let's just hope ppl remember #politics often requires compromise.",
    "id" : 695625106635284480,
    "created_at" : "2016-02-05 15:08:44 +0000",
    "user" : {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "protected" : false,
      "id_str" : "410135192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528579278326095872\/RQTxr53H_normal.jpeg",
      "id" : 410135192,
      "verified" : false
    }
  },
  "id" : 695627591785562113,
  "created_at" : "2016-02-05 15:18:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "feedly",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/c5skF8PKRG",
      "expanded_url" : "http:\/\/scripting.com\/liveblog\/users\/davewiner\/2016\/02\/04\/0975.html",
      "display_url" : "scripting.com\/liveblog\/users\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695416534437507072",
  "text" : "This is a test https:\/\/t.co\/c5skF8PKRG #tech #feedly",
  "id" : 695416534437507072,
  "created_at" : "2016-02-05 01:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695412386442817538",
  "text" : "verizon yahoo mail sucks. trying to get DH's mail off that into gmail or on pc. nothing works. ugh.",
  "id" : 695412386442817538,
  "created_at" : "2016-02-05 01:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Conner",
      "screen_name" : "LitHousewife",
      "indices" : [ 49, 62 ],
      "id_str" : "17769221",
      "id" : 17769221
    }, {
      "name" : "Kris Vik",
      "screen_name" : "KrisVikBookCafe",
      "indices" : [ 64, 80 ],
      "id_str" : "2584734565",
      "id" : 2584734565
    }, {
      "name" : "Felicia",
      "screen_name" : "FeliciaSueLynn",
      "indices" : [ 82, 97 ],
      "id_str" : "33383092",
      "id" : 33383092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/KVlWOkomWw",
      "expanded_url" : "https:\/\/listenupaudiobooks.wordpress.com\/2016\/02\/04\/audiobook-news-reviews-123-24",
      "display_url" : "listenupaudiobooks.wordpress.com\/2016\/02\/04\/aud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695362997347201024",
  "text" : "RT @Listen2Books: Audiobook News &amp; Reviews w\/@lithousewife, @KrisVikBookCafe,\n@feliciasuelynn &amp; more! https:\/\/t.co\/KVlWOkomWw https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Conner",
        "screen_name" : "LitHousewife",
        "indices" : [ 31, 44 ],
        "id_str" : "17769221",
        "id" : 17769221
      }, {
        "name" : "Kris Vik",
        "screen_name" : "KrisVikBookCafe",
        "indices" : [ 46, 62 ],
        "id_str" : "2584734565",
        "id" : 2584734565
      }, {
        "name" : "Felicia",
        "screen_name" : "FeliciaSueLynn",
        "indices" : [ 64, 79 ],
        "id_str" : "33383092",
        "id" : 33383092
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Listen2Books\/status\/695358834571767809\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FHdBbu0y6p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZpLLQUsAEvJEn.jpg",
        "id_str" : "695358833196052481",
        "id" : 695358833196052481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZpLLQUsAEvJEn.jpg",
        "sizes" : [ {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FHdBbu0y6p"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/KVlWOkomWw",
        "expanded_url" : "https:\/\/listenupaudiobooks.wordpress.com\/2016\/02\/04\/audiobook-news-reviews-123-24",
        "display_url" : "listenupaudiobooks.wordpress.com\/2016\/02\/04\/aud\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695358834571767809",
    "text" : "Audiobook News &amp; Reviews w\/@lithousewife, @KrisVikBookCafe,\n@feliciasuelynn &amp; more! https:\/\/t.co\/KVlWOkomWw https:\/\/t.co\/FHdBbu0y6p",
    "id" : 695358834571767809,
    "created_at" : "2016-02-04 21:30:39 +0000",
    "user" : {
      "name" : "ListenUp Audiobooks",
      "screen_name" : "ListenUpAudio",
      "protected" : false,
      "id_str" : "423665516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798245817324683264\/GINN5xbO_normal.jpg",
      "id" : 423665516,
      "verified" : false
    }
  },
  "id" : 695362997347201024,
  "created_at" : "2016-02-04 21:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Podcast Profile",
      "screen_name" : "podcastprofile",
      "indices" : [ 0, 15 ],
      "id_str" : "4838780835",
      "id" : 4838780835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695337464282554373",
  "geo" : { },
  "id_str" : "695341189642321920",
  "in_reply_to_user_id" : 4838780835,
  "text" : "@podcastprofile yay. image and title are now showing! : )",
  "id" : 695341189642321920,
  "in_reply_to_status_id" : 695337464282554373,
  "created_at" : "2016-02-04 20:20:33 +0000",
  "in_reply_to_screen_name" : "podcastprofile",
  "in_reply_to_user_id_str" : "4838780835",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF42Cali Girl \uD83C\uDF42",
      "screen_name" : "Just_Beachy72",
      "indices" : [ 3, 17 ],
      "id_str" : "847772358",
      "id" : 847772358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695316721901637632",
  "text" : "RT @Just_Beachy72: Twitter...where you come across likeminded people and it's therapeutic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694709798508433408",
    "text" : "Twitter...where you come across likeminded people and it's therapeutic",
    "id" : 694709798508433408,
    "created_at" : "2016-02-03 02:31:37 +0000",
    "user" : {
      "name" : "\uD83C\uDF42Cali Girl \uD83C\uDF42",
      "screen_name" : "Just_Beachy72",
      "protected" : false,
      "id_str" : "847772358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793337988998656000\/zSLu6wgU_normal.jpg",
      "id" : 847772358,
      "verified" : false
    }
  },
  "id" : 695316721901637632,
  "created_at" : "2016-02-04 18:43:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Podcast Profile",
      "screen_name" : "podcastprofile",
      "indices" : [ 0, 15 ],
      "id_str" : "4838780835",
      "id" : 4838780835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695296976305459200",
  "in_reply_to_user_id" : 4838780835,
  "text" : "@podcastprofile anyone else having trouble with a podcast not U\/L properly? image shows in my pc app but not on profile.",
  "id" : 695296976305459200,
  "created_at" : "2016-02-04 17:24:51 +0000",
  "in_reply_to_screen_name" : "podcastprofile",
  "in_reply_to_user_id_str" : "4838780835",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "casual coding",
      "screen_name" : "casualcoding",
      "indices" : [ 3, 16 ],
      "id_str" : "1361568260",
      "id" : 1361568260
    }, {
      "name" : "Podcast Profile",
      "screen_name" : "podcastprofile",
      "indices" : [ 94, 109 ],
      "id_str" : "4838780835",
      "id" : 4838780835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/Q2nWrtxaoV",
      "expanded_url" : "http:\/\/podcastprofile.com",
      "display_url" : "podcastprofile.com"
    } ]
  },
  "geo" : { },
  "id_str" : "695296446090895360",
  "text" : "RT @casualcoding: Say hello to https:\/\/t.co\/Q2nWrtxaoV and show which podcasts you listen to. @podcastprofile is the result of our first 2-\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Podcast Profile",
        "screen_name" : "podcastprofile",
        "indices" : [ 76, 91 ],
        "id_str" : "4838780835",
        "id" : 4838780835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/Q2nWrtxaoV",
        "expanded_url" : "http:\/\/podcastprofile.com",
        "display_url" : "podcastprofile.com"
      } ]
    },
    "geo" : { },
    "id_str" : "693059062888579072",
    "text" : "Say hello to https:\/\/t.co\/Q2nWrtxaoV and show which podcasts you listen to. @podcastprofile is the result of our first 2-day hackathon.",
    "id" : 693059062888579072,
    "created_at" : "2016-01-29 13:12:11 +0000",
    "user" : {
      "name" : "casual coding",
      "screen_name" : "casualcoding",
      "protected" : false,
      "id_str" : "1361568260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504194250565644288\/FlxFrQte_normal.png",
      "id" : 1361568260,
      "verified" : false
    }
  },
  "id" : 695296446090895360,
  "created_at" : "2016-02-04 17:22:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2603\uFE0FMattzilla\uD83C\uDF84\u2744\uFE0F",
      "screen_name" : "mattZillaaaa",
      "indices" : [ 3, 16 ],
      "id_str" : "39291808",
      "id" : 39291808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695282255019773952",
  "text" : "RT @mattZillaaaa: *changes voicemail recording to \"your call cannot be completed as dialed. Please check the number and dial again",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695066740552790017",
    "text" : "*changes voicemail recording to \"your call cannot be completed as dialed. Please check the number and dial again",
    "id" : 695066740552790017,
    "created_at" : "2016-02-04 02:09:59 +0000",
    "user" : {
      "name" : "\u2603\uFE0FMattzilla\uD83C\uDF84\u2744\uFE0F",
      "screen_name" : "mattZillaaaa",
      "protected" : false,
      "id_str" : "39291808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800106251627675648\/VaM0CEIh_normal.jpg",
      "id" : 39291808,
      "verified" : false
    }
  },
  "id" : 695282255019773952,
  "created_at" : "2016-02-04 16:26:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marie Curie",
      "screen_name" : "mariecurieuk",
      "indices" : [ 3, 16 ],
      "id_str" : "22028340",
      "id" : 22028340
    }, {
      "name" : "The Independent",
      "screen_name" : "Independent",
      "indices" : [ 61, 73 ],
      "id_str" : "16973333",
      "id" : 16973333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695277639347609600",
  "text" : "RT @mariecurieuk: On World Cancer Day, food for thought from @independent. Have people with terminal cancer 'lost a battle'? https:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Independent",
        "screen_name" : "Independent",
        "indices" : [ 43, 55 ],
        "id_str" : "16973333",
        "id" : 16973333
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mariecurieuk\/status\/695158723061354496\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/UrZy6tdrLQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaWzLOLXEAAkWrE.png",
        "id_str" : "695158722864287744",
        "id" : 695158722864287744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaWzLOLXEAAkWrE.png",
        "sizes" : [ {
          "h" : 324,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UrZy6tdrLQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695158723061354496",
    "text" : "On World Cancer Day, food for thought from @independent. Have people with terminal cancer 'lost a battle'? https:\/\/t.co\/UrZy6tdrLQ",
    "id" : 695158723061354496,
    "created_at" : "2016-02-04 08:15:29 +0000",
    "user" : {
      "name" : "Marie Curie",
      "screen_name" : "mariecurieuk",
      "protected" : false,
      "id_str" : "22028340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585667683850579969\/ZUzBxQvL_normal.png",
      "id" : 22028340,
      "verified" : true
    }
  },
  "id" : 695277639347609600,
  "created_at" : "2016-02-04 16:08:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aspergers",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695273059524063232",
  "geo" : { },
  "id_str" : "695275584885284864",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ahem.. #aspergers is not a mental disorder but a neuro condition. IF he is aspie, that has nothing to do w his vileness.",
  "id" : 695275584885284864,
  "in_reply_to_status_id" : 695273059524063232,
  "created_at" : "2016-02-04 15:59:51 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mashable\/status\/695208454600916992\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/VMvqo5tiYC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaXgZ9KWYAAOEDI.jpg",
      "id_str" : "695208454017933312",
      "id" : 695208454017933312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaXgZ9KWYAAOEDI.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 950
      } ],
      "display_url" : "pic.twitter.com\/VMvqo5tiYC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Mx4rCx1Mqs",
      "expanded_url" : "http:\/\/on.mash.to\/1SuVHtO",
      "display_url" : "on.mash.to\/1SuVHtO"
    } ]
  },
  "geo" : { },
  "id_str" : "695270962477006848",
  "text" : "RT @mashable: Samsung to roll out screen-equipped trucks that show the road ahead https:\/\/t.co\/Mx4rCx1Mqs https:\/\/t.co\/VMvqo5tiYC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mashable\/status\/695208454600916992\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/VMvqo5tiYC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaXgZ9KWYAAOEDI.jpg",
        "id_str" : "695208454017933312",
        "id" : 695208454017933312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaXgZ9KWYAAOEDI.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        } ],
        "display_url" : "pic.twitter.com\/VMvqo5tiYC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/Mx4rCx1Mqs",
        "expanded_url" : "http:\/\/on.mash.to\/1SuVHtO",
        "display_url" : "on.mash.to\/1SuVHtO"
      } ]
    },
    "geo" : { },
    "id_str" : "695208454600916992",
    "text" : "Samsung to roll out screen-equipped trucks that show the road ahead https:\/\/t.co\/Mx4rCx1Mqs https:\/\/t.co\/VMvqo5tiYC",
    "id" : 695208454600916992,
    "created_at" : "2016-02-04 11:33:06 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 695270962477006848,
  "created_at" : "2016-02-04 15:41:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just True Blue",
      "screen_name" : "JustTrueBlue",
      "indices" : [ 3, 16 ],
      "id_str" : "860687102",
      "id" : 860687102
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JustTrueBlue\/status\/694953007310577665\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/BbF4yQWjzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaT4Eh9WIAAAepz.jpg",
      "id_str" : "694952999240736768",
      "id" : 694952999240736768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaT4Eh9WIAAAepz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BbF4yQWjzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695051807618392065",
  "text" : "RT @JustTrueBlue: I support BOTH blue candidates. This guy nails it. https:\/\/t.co\/BbF4yQWjzR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JustTrueBlue\/status\/694953007310577665\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/BbF4yQWjzR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaT4Eh9WIAAAepz.jpg",
        "id_str" : "694952999240736768",
        "id" : 694952999240736768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaT4Eh9WIAAAepz.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BbF4yQWjzR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694953007310577665",
    "text" : "I support BOTH blue candidates. This guy nails it. https:\/\/t.co\/BbF4yQWjzR",
    "id" : 694953007310577665,
    "created_at" : "2016-02-03 18:38:03 +0000",
    "user" : {
      "name" : "Just True Blue",
      "screen_name" : "JustTrueBlue",
      "protected" : false,
      "id_str" : "860687102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000154117809\/114cd852f32aa1d4229a1d4e1e3cc05c_normal.jpeg",
      "id" : 860687102,
      "verified" : false
    }
  },
  "id" : 695051807618392065,
  "created_at" : "2016-02-04 01:10:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695034084444217344",
  "text" : "RT @JohnFugelsang: My favorite Bible story is when Jesus feeds the multitudes after administering a drug test to make sure they deserve foo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694687440364240896",
    "text" : "My favorite Bible story is when Jesus feeds the multitudes after administering a drug test to make sure they deserve food.",
    "id" : 694687440364240896,
    "created_at" : "2016-02-03 01:02:47 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 695034084444217344,
  "created_at" : "2016-02-04 00:00:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 0, 6 ]
    }, {
      "text" : "books",
      "indices" : [ 7, 13 ]
    }, {
      "text" : "podcast",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/VxNDl3wS9p",
      "expanded_url" : "https:\/\/twitter.com\/Crystal_Face_\/status\/695030919636348928",
      "display_url" : "twitter.com\/Crystal_Face_\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695031847231819776",
  "text" : "#scifi #books #podcast https:\/\/t.co\/VxNDl3wS9p",
  "id" : 695031847231819776,
  "created_at" : "2016-02-03 23:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pfizer",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "VP",
      "indices" : [ 33, 36 ]
    }, {
      "text" : "drug",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "crimes",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "documentary",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/0rk1HNc1Tl",
      "expanded_url" : "http:\/\/bit.ly\/1IeAT2h",
      "display_url" : "bit.ly\/1IeAT2h"
    } ]
  },
  "geo" : { },
  "id_str" : "695005879171686404",
  "text" : "RT @HealthRanger: Former #Pfizer #VP comes clean about #drug industry #crimes in powerful #documentary: https:\/\/t.co\/0rk1HNc1Tl https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthRanger\/status\/695003845223579648\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Iu2yhDDXqF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaUmUJkUUAE15Ek.jpg",
        "id_str" : "695003845106094081",
        "id" : 695003845106094081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaUmUJkUUAE15Ek.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/Iu2yhDDXqF"
      } ],
      "hashtags" : [ {
        "text" : "Pfizer",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "VP",
        "indices" : [ 15, 18 ]
      }, {
        "text" : "drug",
        "indices" : [ 37, 42 ]
      }, {
        "text" : "crimes",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "documentary",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/0rk1HNc1Tl",
        "expanded_url" : "http:\/\/bit.ly\/1IeAT2h",
        "display_url" : "bit.ly\/1IeAT2h"
      } ]
    },
    "geo" : { },
    "id_str" : "695003845223579648",
    "text" : "Former #Pfizer #VP comes clean about #drug industry #crimes in powerful #documentary: https:\/\/t.co\/0rk1HNc1Tl https:\/\/t.co\/Iu2yhDDXqF",
    "id" : 695003845223579648,
    "created_at" : "2016-02-03 22:00:03 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 695005879171686404,
  "created_at" : "2016-02-03 22:08:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/8OijCtA7cV",
      "expanded_url" : "http:\/\/smar.ws\/5WyCo",
      "display_url" : "smar.ws\/5WyCo"
    } ]
  },
  "geo" : { },
  "id_str" : "694990914742255616",
  "text" : "RT @5thdimdreamz: It\u2019s on: We\u2019re getting four more Democratic debates https:\/\/t.co\/8OijCtA7cV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/8OijCtA7cV",
        "expanded_url" : "http:\/\/smar.ws\/5WyCo",
        "display_url" : "smar.ws\/5WyCo"
      } ]
    },
    "geo" : { },
    "id_str" : "694990585367662592",
    "text" : "It\u2019s on: We\u2019re getting four more Democratic debates https:\/\/t.co\/8OijCtA7cV",
    "id" : 694990585367662592,
    "created_at" : "2016-02-03 21:07:22 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 694990914742255616,
  "created_at" : "2016-02-03 21:08:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/4WOdoHFete",
      "expanded_url" : "https:\/\/twitter.com\/Irish_Atheist\/status\/694950930496753666",
      "display_url" : "twitter.com\/Irish_Atheist\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694956526960824320",
  "text" : "good thoughts here... https:\/\/t.co\/4WOdoHFete",
  "id" : 694956526960824320,
  "created_at" : "2016-02-03 18:52:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/R4kEffuW51",
      "expanded_url" : "https:\/\/twitter.com\/newhorizons2015\/status\/694898738515484672",
      "display_url" : "twitter.com\/newhorizons201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694939872000372736",
  "text" : "RT @5x5: Pluto will always be #9 in my eyes! Thanks Clyde Tombaugh. https:\/\/t.co\/R4kEffuW51",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/R4kEffuW51",
        "expanded_url" : "https:\/\/twitter.com\/newhorizons2015\/status\/694898738515484672",
        "display_url" : "twitter.com\/newhorizons201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694919485174759424",
    "text" : "Pluto will always be #9 in my eyes! Thanks Clyde Tombaugh. https:\/\/t.co\/R4kEffuW51",
    "id" : 694919485174759424,
    "created_at" : "2016-02-03 16:24:50 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 694939872000372736,
  "created_at" : "2016-02-03 17:45:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah R",
      "screen_name" : "SarieAnneR",
      "indices" : [ 3, 14 ],
      "id_str" : "68568162",
      "id" : 68568162
    }, {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 16, 31 ],
      "id_str" : "582993732",
      "id" : 582993732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694938294984036355",
  "text" : "RT @SarieAnneR: @DefendTheSheep You are free to decide what to do with your life, AND you get a bonus person to manage your home and watch \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Anne",
        "screen_name" : "DefendTheSheep",
        "indices" : [ 0, 15 ],
        "id_str" : "582993732",
        "id" : 582993732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "694936086540345345",
    "geo" : { },
    "id_str" : "694936306007326720",
    "in_reply_to_user_id" : 68568162,
    "text" : "@DefendTheSheep You are free to decide what to do with your life, AND you get a bonus person to manage your home and watch your kids",
    "id" : 694936306007326720,
    "in_reply_to_status_id" : 694936086540345345,
    "created_at" : "2016-02-03 17:31:41 +0000",
    "in_reply_to_screen_name" : "SarieAnneR",
    "in_reply_to_user_id_str" : "68568162",
    "user" : {
      "name" : "Sarah R",
      "screen_name" : "SarieAnneR",
      "protected" : false,
      "id_str" : "68568162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695676796344205312\/pElJ0K_6_normal.jpg",
      "id" : 68568162,
      "verified" : false
    }
  },
  "id" : 694938294984036355,
  "created_at" : "2016-02-03 17:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah R",
      "screen_name" : "SarieAnneR",
      "indices" : [ 3, 14 ],
      "id_str" : "68568162",
      "id" : 68568162
    }, {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 16, 31 ],
      "id_str" : "582993732",
      "id" : 582993732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694938259969937409",
  "text" : "RT @SarieAnneR: @DefendTheSheep Of course, if you're a dude, trusting God's character not required, because you are SET.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Anne",
        "screen_name" : "DefendTheSheep",
        "indices" : [ 0, 15 ],
        "id_str" : "582993732",
        "id" : 582993732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "694926744202006529",
    "geo" : { },
    "id_str" : "694936086540345345",
    "in_reply_to_user_id" : 582993732,
    "text" : "@DefendTheSheep Of course, if you're a dude, trusting God's character not required, because you are SET.",
    "id" : 694936086540345345,
    "in_reply_to_status_id" : 694926744202006529,
    "created_at" : "2016-02-03 17:30:48 +0000",
    "in_reply_to_screen_name" : "DefendTheSheep",
    "in_reply_to_user_id_str" : "582993732",
    "user" : {
      "name" : "Sarah R",
      "screen_name" : "SarieAnneR",
      "protected" : false,
      "id_str" : "68568162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695676796344205312\/pElJ0K_6_normal.jpg",
      "id" : 68568162,
      "verified" : false
    }
  },
  "id" : 694938259969937409,
  "created_at" : "2016-02-03 17:39:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 3, 18 ],
      "id_str" : "582993732",
      "id" : 582993732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694938122937880576",
  "text" : "RT @DefendTheSheep: TGC often uses the phrase \"gender roles,\" but they really mean gender rules - rules they enforce, not God. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DefendTheSheep\/status\/694926744202006529\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/1AdLcC2Fp5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTgL9tUUAE46Lk.jpg",
        "id_str" : "694926738669719553",
        "id" : 694926738669719553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTgL9tUUAE46Lk.jpg",
        "sizes" : [ {
          "h" : 441,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 814,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 814,
          "resize" : "fit",
          "w" : 628
        } ],
        "display_url" : "pic.twitter.com\/1AdLcC2Fp5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694926744202006529",
    "text" : "TGC often uses the phrase \"gender roles,\" but they really mean gender rules - rules they enforce, not God. https:\/\/t.co\/1AdLcC2Fp5",
    "id" : 694926744202006529,
    "created_at" : "2016-02-03 16:53:41 +0000",
    "user" : {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "protected" : false,
      "id_str" : "582993732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719282831931781120\/BB0VrKyw_normal.jpg",
      "id" : 582993732,
      "verified" : false
    }
  },
  "id" : 694938122937880576,
  "created_at" : "2016-02-03 17:38:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "feedly",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/jg64JBTL8r",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/8fe898b0797234\/49965?app_id=339",
      "display_url" : "producthunt.com\/r\/8fe898b07972\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694936007796457473",
  "text" : "Treys \u2014 Like solitaire... but fun! https:\/\/t.co\/jg64JBTL8r #tech #feedly",
  "id" : 694936007796457473,
  "created_at" : "2016-02-03 17:30:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "feedly",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/LqlTYdIOjZ",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/d1a7a954bdd3a0\/50080?app_id=339",
      "display_url" : "producthunt.com\/r\/d1a7a954bdd3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694933619417210881",
  "text" : "PINDEX \u2014 Collect and discover the best educational material https:\/\/t.co\/LqlTYdIOjZ #tech #feedly",
  "id" : 694933619417210881,
  "created_at" : "2016-02-03 17:21:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.producthunt.com\" rel=\"nofollow\"\u003EProduct Hunt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 34, 46 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "Florian Letsch",
      "screen_name" : "FlorianLetsch",
      "indices" : [ 50, 64 ],
      "id_str" : "183628109",
      "id" : 183628109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/694933141920808962\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ctHX6aJIog",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTmArLWYAAp4MY.jpg",
      "id_str" : "694933141786615808",
      "id" : 694933141786615808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTmArLWYAAp4MY.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 843
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 843
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ctHX6aJIog"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/GeEHV985st",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/podcast-profile#comment-227514",
      "display_url" : "producthunt.com\/tech\/podcast-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694933141920808962",
  "text" : "My thoughts on Podcast Profile on @ProductHunt cc @florianletsch https:\/\/t.co\/GeEHV985st https:\/\/t.co\/ctHX6aJIog",
  "id" : 694933141920808962,
  "created_at" : "2016-02-03 17:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "history",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "podcast",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/OFAAlXpAlO",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/dan-carlin-hardcore-history_us_5643b5b5e4b08cda34875511",
      "display_url" : "huffingtonpost.com\/entry\/dan-carl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694923275764371456",
  "text" : "America's best #history teacher doesn't work at a school https:\/\/t.co\/OFAAlXpAlO #podcast",
  "id" : 694923275764371456,
  "created_at" : "2016-02-03 16:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/694913720477208577\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/sdSGs4kbnU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTUWDmWAAEdvQq.png",
      "id_str" : "694913717910241281",
      "id" : 694913717910241281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTUWDmWAAEdvQq.png",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 256
      } ],
      "display_url" : "pic.twitter.com\/sdSGs4kbnU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ntcXbgIr57",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/audiobooks\/comments\/4407nr\/deaths_heretic_free_on_audible?_ts=1454515315",
      "display_url" : "reddit.com\/r\/audiobooks\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694913720477208577",
  "text" : "Death's Heretic free on Audible : audiobooks https:\/\/t.co\/ntcXbgIr57 https:\/\/t.co\/sdSGs4kbnU",
  "id" : 694913720477208577,
  "created_at" : "2016-02-03 16:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Universe Daily",
      "screen_name" : "NewUniverseD",
      "indices" : [ 3, 16 ],
      "id_str" : "140676200",
      "id" : 140676200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NewUniverseD\/status\/694883237072601088\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/QKdXJYWEaa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaS4n0kXEAA3X1r.png",
      "id_str" : "694883236787458048",
      "id" : 694883236787458048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaS4n0kXEAA3X1r.png",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 980
      } ],
      "display_url" : "pic.twitter.com\/QKdXJYWEaa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hWroOHC1bt",
      "expanded_url" : "http:\/\/buff.ly\/1KVMN0j",
      "display_url" : "buff.ly\/1KVMN0j"
    } ]
  },
  "geo" : { },
  "id_str" : "694910173303955456",
  "text" : "RT @NewUniverseD: Scientists May Have Discovered What Moves Time Forward https:\/\/t.co\/hWroOHC1bt https:\/\/t.co\/QKdXJYWEaa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NewUniverseD\/status\/694883237072601088\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/QKdXJYWEaa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaS4n0kXEAA3X1r.png",
        "id_str" : "694883236787458048",
        "id" : 694883236787458048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaS4n0kXEAA3X1r.png",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 572,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 572,
          "resize" : "fit",
          "w" : 980
        } ],
        "display_url" : "pic.twitter.com\/QKdXJYWEaa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/hWroOHC1bt",
        "expanded_url" : "http:\/\/buff.ly\/1KVMN0j",
        "display_url" : "buff.ly\/1KVMN0j"
      } ]
    },
    "geo" : { },
    "id_str" : "694883237072601088",
    "text" : "Scientists May Have Discovered What Moves Time Forward https:\/\/t.co\/hWroOHC1bt https:\/\/t.co\/QKdXJYWEaa",
    "id" : 694883237072601088,
    "created_at" : "2016-02-03 14:00:48 +0000",
    "user" : {
      "name" : "New Universe Daily",
      "screen_name" : "NewUniverseD",
      "protected" : false,
      "id_str" : "140676200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531262864732868608\/uqg2IYOf_normal.png",
      "id" : 140676200,
      "verified" : false
    }
  },
  "id" : 694910173303955456,
  "created_at" : "2016-02-03 15:47:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "indices" : [ 3, 16 ],
      "id_str" : "1413936181",
      "id" : 1413936181
    }, {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "indices" : [ 18, 31 ],
      "id_str" : "1413936181",
      "id" : 1413936181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694905839505825793",
  "text" : "RT @FionaJDavies: @FionaJDavies a sneaky peek around the corner reveals two massive birds trying to sus out the bird feeder! https:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fiona",
        "screen_name" : "FionaJDavies",
        "indices" : [ 0, 13 ],
        "id_str" : "1413936181",
        "id" : 1413936181
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FionaJDavies\/status\/694886546957340672\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/PCezlhs7nC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaS7cE3WIAAnaS2.jpg",
        "id_str" : "694886333538508800",
        "id" : 694886333538508800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaS7cE3WIAAnaS2.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PCezlhs7nC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "694885772604923904",
    "geo" : { },
    "id_str" : "694886546957340672",
    "in_reply_to_user_id" : 1413936181,
    "text" : "@FionaJDavies a sneaky peek around the corner reveals two massive birds trying to sus out the bird feeder! https:\/\/t.co\/PCezlhs7nC",
    "id" : 694886546957340672,
    "in_reply_to_status_id" : 694885772604923904,
    "created_at" : "2016-02-03 14:13:57 +0000",
    "in_reply_to_screen_name" : "FionaJDavies",
    "in_reply_to_user_id_str" : "1413936181",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "protected" : false,
      "id_str" : "1413936181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456679350880829440\/z2YfOoH2_normal.jpeg",
      "id" : 1413936181,
      "verified" : false
    }
  },
  "id" : 694905839505825793,
  "created_at" : "2016-02-03 15:30:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "indices" : [ 3, 12 ],
      "id_str" : "75372132",
      "id" : 75372132
    }, {
      "name" : "Jane Mayer",
      "screen_name" : "JaneMayerNYer",
      "indices" : [ 69, 83 ],
      "id_str" : "561516853",
      "id" : 561516853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/kWuFwjD7jP",
      "expanded_url" : "http:\/\/bit.ly\/1PQBsGx",
      "display_url" : "bit.ly\/1PQBsGx"
    } ]
  },
  "geo" : { },
  "id_str" : "694646558093135872",
  "text" : "RT @PRHAudio: Is America is living in an age of economic inequality? @JaneMayerNYer answers in DARK MONEY: https:\/\/t.co\/kWuFwjD7jP https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Mayer",
        "screen_name" : "JaneMayerNYer",
        "indices" : [ 55, 69 ],
        "id_str" : "561516853",
        "id" : 561516853
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PRHAudio\/status\/694626962665508864\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0kbo6eB88S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaPPirlWYAAk0b5.jpg",
        "id_str" : "694626962267070464",
        "id" : 694626962267070464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaPPirlWYAAk0b5.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 387
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 387
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 387
        } ],
        "display_url" : "pic.twitter.com\/0kbo6eB88S"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/kWuFwjD7jP",
        "expanded_url" : "http:\/\/bit.ly\/1PQBsGx",
        "display_url" : "bit.ly\/1PQBsGx"
      } ]
    },
    "geo" : { },
    "id_str" : "694626962665508864",
    "text" : "Is America is living in an age of economic inequality? @JaneMayerNYer answers in DARK MONEY: https:\/\/t.co\/kWuFwjD7jP https:\/\/t.co\/0kbo6eB88S",
    "id" : 694626962665508864,
    "created_at" : "2016-02-02 21:02:28 +0000",
    "user" : {
      "name" : "PRH Audio",
      "screen_name" : "PRHAudio",
      "protected" : false,
      "id_str" : "75372132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606215515279753216\/KBzpETdK_normal.jpg",
      "id" : 75372132,
      "verified" : false
    }
  },
  "id" : 694646558093135872,
  "created_at" : "2016-02-02 22:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Hyett\u2728",
      "screen_name" : "julie_hyett",
      "indices" : [ 3, 15 ],
      "id_str" : "2431670476",
      "id" : 2431670476
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/julie_hyett\/status\/694495950014955520\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/DSzxs0A1GC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaNYUWrWQAAycsq.jpg",
      "id_str" : "694495874253209600",
      "id" : 694495874253209600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaNYUWrWQAAycsq.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DSzxs0A1GC"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/julie_hyett\/status\/694495950014955520\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/DSzxs0A1GC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaNYUW-WIAYT598.jpg",
      "id_str" : "694495874332893190",
      "id" : 694495874332893190,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaNYUW-WIAYT598.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DSzxs0A1GC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694645966234914817",
  "text" : "RT @julie_hyett: Always one! https:\/\/t.co\/DSzxs0A1GC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/julie_hyett\/status\/694495950014955520\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/DSzxs0A1GC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaNYUWrWQAAycsq.jpg",
        "id_str" : "694495874253209600",
        "id" : 694495874253209600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaNYUWrWQAAycsq.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DSzxs0A1GC"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/julie_hyett\/status\/694495950014955520\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/DSzxs0A1GC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaNYUW-WIAYT598.jpg",
        "id_str" : "694495874332893190",
        "id" : 694495874332893190,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaNYUW-WIAYT598.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DSzxs0A1GC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694495950014955520",
    "text" : "Always one! https:\/\/t.co\/DSzxs0A1GC",
    "id" : 694495950014955520,
    "created_at" : "2016-02-02 12:21:52 +0000",
    "user" : {
      "name" : "Julie Hyett\u2728",
      "screen_name" : "julie_hyett",
      "protected" : false,
      "id_str" : "2431670476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796786314079272961\/8_GkJq4l_normal.jpg",
      "id" : 2431670476,
      "verified" : false
    }
  },
  "id" : 694645966234914817,
  "created_at" : "2016-02-02 22:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694558384838819841",
  "text" : "gahh.. i hate apple. ive got 20 legit songs i cant get onto my fiio x1 cuz m4p. why those 20? all other songs were itunes.",
  "id" : 694558384838819841,
  "created_at" : "2016-02-02 16:29:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/GC1s2yulXs",
      "expanded_url" : "https:\/\/youtu.be\/sCyzdD0vYOw",
      "display_url" : "youtu.be\/sCyzdD0vYOw"
    } ]
  },
  "geo" : { },
  "id_str" : "694339276671184896",
  "text" : "CANADA for President 2016 https:\/\/t.co\/GC1s2yulXs",
  "id" : 694339276671184896,
  "created_at" : "2016-02-02 01:59:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694181683063570432",
  "text" : "is there a way to bulk edit songs for mp3 player? they all have numbers in front of song titles.",
  "id" : 694181683063570432,
  "created_at" : "2016-02-01 15:33:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maitria",
      "screen_name" : "hellomaitria",
      "indices" : [ 3, 16 ],
      "id_str" : "958990622",
      "id" : 958990622
    }, {
      "name" : "Amber Conville",
      "screen_name" : "crebma",
      "indices" : [ 75, 82 ],
      "id_str" : "128264038",
      "id" : 128264038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/8mO15Tp6mZ",
      "expanded_url" : "http:\/\/geekjoypodcast.libsyn.com\/because-somebody-will-help-me",
      "display_url" : "geekjoypodcast.libsyn.com\/because-somebo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694177862740529152",
  "text" : "RT @hellomaitria: Geek Joy Podcast #3 \"Because Somebody Will Help Me\" with @crebma https:\/\/t.co\/8mO15Tp6mZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/libsyn.com\/3\/\" rel=\"nofollow\"\u003ELibsyn On-Publish\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amber Conville",
        "screen_name" : "crebma",
        "indices" : [ 57, 64 ],
        "id_str" : "128264038",
        "id" : 128264038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/8mO15Tp6mZ",
        "expanded_url" : "http:\/\/geekjoypodcast.libsyn.com\/because-somebody-will-help-me",
        "display_url" : "geekjoypodcast.libsyn.com\/because-somebo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693977469775417345",
    "text" : "Geek Joy Podcast #3 \"Because Somebody Will Help Me\" with @crebma https:\/\/t.co\/8mO15Tp6mZ",
    "id" : 693977469775417345,
    "created_at" : "2016-02-01 02:01:36 +0000",
    "user" : {
      "name" : "Maitria",
      "screen_name" : "hellomaitria",
      "protected" : false,
      "id_str" : "958990622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513781956622835712\/PsBjofJl_normal.png",
      "id" : 958990622,
      "verified" : false
    }
  },
  "id" : 694177862740529152,
  "created_at" : "2016-02-01 15:17:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Holman",
      "screen_name" : "joannamuses",
      "indices" : [ 3, 15 ],
      "id_str" : "18622950",
      "id" : 18622950
    }, {
      "name" : "Owl City",
      "screen_name" : "owlcity",
      "indices" : [ 33, 41 ],
      "id_str" : "15265990",
      "id" : 15265990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694177448964005889",
  "text" : "RT @joannamuses: Adam Young from @owlcity just released FOR FREE an incredible album of Apollo 11 themed film scores. It's amazing! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owl City",
        "screen_name" : "owlcity",
        "indices" : [ 16, 24 ],
        "id_str" : "15265990",
        "id" : 15265990
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/2ijndTiaj1",
        "expanded_url" : "http:\/\/www.ayoungscores.com\/",
        "display_url" : "ayoungscores.com"
      } ]
    },
    "geo" : { },
    "id_str" : "694098161283936257",
    "text" : "Adam Young from @owlcity just released FOR FREE an incredible album of Apollo 11 themed film scores. It's amazing! https:\/\/t.co\/2ijndTiaj1",
    "id" : 694098161283936257,
    "created_at" : "2016-02-01 10:01:12 +0000",
    "user" : {
      "name" : "Joanna Holman",
      "screen_name" : "joannamuses",
      "protected" : false,
      "id_str" : "18622950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688281262339932160\/svl56s1D_normal.jpg",
      "id" : 18622950,
      "verified" : false
    }
  },
  "id" : 694177448964005889,
  "created_at" : "2016-02-01 15:16:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tim cornwell",
      "screen_name" : "247razz",
      "indices" : [ 3, 11 ],
      "id_str" : "272175633",
      "id" : 272175633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694175024605990912",
  "text" : "RT @247razz: Doodlebug is a orphaned baby. His rescuer gave him a teddy bear which he wouldn't let go. Goodnight everyone I'm out https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/247razz\/status\/693959371466895362\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/N9WI2ZC3ZL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaFwXj_WwAQ2ncs.jpg",
        "id_str" : "693959367692042244",
        "id" : 693959367692042244,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaFwXj_WwAQ2ncs.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/N9WI2ZC3ZL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693959371466895362",
    "text" : "Doodlebug is a orphaned baby. His rescuer gave him a teddy bear which he wouldn't let go. Goodnight everyone I'm out https:\/\/t.co\/N9WI2ZC3ZL",
    "id" : 693959371466895362,
    "created_at" : "2016-02-01 00:49:41 +0000",
    "user" : {
      "name" : "tim cornwell",
      "screen_name" : "247razz",
      "protected" : false,
      "id_str" : "272175633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426424424368463873\/HZ8rm5x1_normal.jpeg",
      "id" : 272175633,
      "verified" : false
    }
  },
  "id" : 694175024605990912,
  "created_at" : "2016-02-01 15:06:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]