Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109005018400690176",
  "geo" : { },
  "id_str" : "109007467169583105",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awww.. big ((hugs))",
  "id" : 109007467169583105,
  "in_reply_to_status_id" : 109005018400690176,
  "created_at" : "2011-08-31 20:59:40 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/CtamsuL",
      "expanded_url" : "http:\/\/flic.kr\/p\/ai7ySA",
      "display_url" : "flic.kr\/p\/ai7ySA"
    } ]
  },
  "geo" : { },
  "id_str" : "108974009126883328",
  "text" : "Three anteater pile up http:\/\/t.co\/CtamsuL",
  "id" : 108974009126883328,
  "created_at" : "2011-08-31 18:46:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Patty Townley",
      "screen_name" : "PattyTownley",
      "indices" : [ 14, 27 ],
      "id_str" : "64420689",
      "id" : 64420689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108718414327070720",
  "geo" : { },
  "id_str" : "108724955281235968",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves @PattyTownley I like that.. I wld amend that to God uses it to get you back to Himself.",
  "id" : 108724955281235968,
  "in_reply_to_status_id" : 108718414327070720,
  "created_at" : "2011-08-31 02:17:04 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108359960336928769",
  "text" : "RT @DoreenVirtue444: Always, Heaven reminds you to make choices based on love and not fear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108358866676355072",
    "text" : "Always, Heaven reminds you to make choices based on love and not fear.",
    "id" : 108358866676355072,
    "created_at" : "2011-08-30 02:02:21 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 108359960336928769,
  "created_at" : "2011-08-30 02:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 50 ],
      "url" : "http:\/\/t.co\/kR3KX9j",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "108352904229953536",
  "text" : "i've got a pretty cool blog at http:\/\/t.co\/kR3KX9j",
  "id" : 108352904229953536,
  "created_at" : "2011-08-30 01:38:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108352200694181889",
  "text" : "flying squirrel in the speaker! he's sort of a tenant here. he comes and goes..lol",
  "id" : 108352200694181889,
  "created_at" : "2011-08-30 01:35:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/PQT7HpY",
      "expanded_url" : "http:\/\/www.dwaynereaves.net\/2011\/08\/still-looking.html?spref=tw",
      "display_url" : "dwaynereaves.net\/2011\/08\/still-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108344990303920128",
  "text" : "RT @DwayneReaves: This is how you get people not to read your blog, write post like this.&gt; Still looking! http:\/\/t.co\/PQT7HpY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 110 ],
        "url" : "http:\/\/t.co\/PQT7HpY",
        "expanded_url" : "http:\/\/www.dwaynereaves.net\/2011\/08\/still-looking.html?spref=tw",
        "display_url" : "dwaynereaves.net\/2011\/08\/still-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "108344444348141568",
    "text" : "This is how you get people not to read your blog, write post like this.&gt; Still looking! http:\/\/t.co\/PQT7HpY",
    "id" : 108344444348141568,
    "created_at" : "2011-08-30 01:05:03 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 108344990303920128,
  "created_at" : "2011-08-30 01:07:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108292515861508096",
  "text" : "@HEATHENRABBIT you're so awesome..lol.. no worries. all is well here. : )",
  "id" : 108292515861508096,
  "created_at" : "2011-08-29 21:38:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108285425583525888",
  "text" : "RT @earthXplorer: \u201CLife is really simple, but we insist on making it complicated\u201D ~Confucius",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108282820740399105",
    "text" : "\u201CLife is really simple, but we insist on making it complicated\u201D ~Confucius",
    "id" : 108282820740399105,
    "created_at" : "2011-08-29 21:00:10 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 108285425583525888,
  "created_at" : "2011-08-29 21:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/mYRwu4e",
      "expanded_url" : "https:\/\/plus.google.com\/117541072957720579032\/posts\/TFYQpyt4eZ5",
      "display_url" : "plus.google.com\/11754107295772\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107821447782744064",
  "text" : "\u200E*WARNING* As Hurricane Irene prepared to batter the East Coast, federal disaster officials warned that Internet out... http:\/\/t.co\/mYRwu4e",
  "id" : 107821447782744064,
  "created_at" : "2011-08-28 14:26:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107194713328713728",
  "geo" : { },
  "id_str" : "107201187941584896",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench haha.. dont think wenches can fail..",
  "id" : 107201187941584896,
  "in_reply_to_status_id" : 107194713328713728,
  "created_at" : "2011-08-26 21:22:09 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107194713328713728",
  "geo" : { },
  "id_str" : "107201059616866304",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench its good.. im enjoying it. : )",
  "id" : 107201059616866304,
  "in_reply_to_status_id" : 107194713328713728,
  "created_at" : "2011-08-26 21:21:38 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106827400846913536",
  "geo" : { },
  "id_str" : "107194310948163584",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench curious if you got it? I started it last night.",
  "id" : 107194310948163584,
  "in_reply_to_status_id" : 106827400846913536,
  "created_at" : "2011-08-26 20:54:49 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107179170974543872",
  "text" : "RT @thesexyatheist: Some one found $10 on the floor and we asked everyone. The peep got it back. Every one is so honest here. Awesome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107178820167143424",
    "text" : "Some one found $10 on the floor and we asked everyone. The peep got it back. Every one is so honest here. Awesome.",
    "id" : 107178820167143424,
    "created_at" : "2011-08-26 19:53:16 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 107179170974543872,
  "created_at" : "2011-08-26 19:54:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106827400846913536",
  "geo" : { },
  "id_str" : "106845301863759872",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench you have to follow the link. takes you to klout page w offer. I got email from klout offering free ebook.",
  "id" : 106845301863759872,
  "in_reply_to_status_id" : 106827400846913536,
  "created_at" : "2011-08-25 21:47:59 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon & Schuster",
      "screen_name" : "simonschuster",
      "indices" : [ 99, 113 ],
      "id_str" : "24886025",
      "id" : 24886025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mile81",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/NdedeV9",
      "expanded_url" : "http:\/\/klout.com\/perk\/SimonSchuster\/Mile81?passalong=MTAwLzk0OTU1LzI&passalongSig=2e2df02bec2b9a754d0fa9bc26b13c723d63d42eee3dbdf7c75907c19231fab2&n=tw&v=perks_completed",
      "display_url" : "klout.com\/perk\/SimonSchu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "106826357677375488",
  "text" : "I have ONE passalong to share my Stephen King #Mile81 Perk from Klout.1st to claim it gets it! Thx @simonschuster! http:\/\/t.co\/NdedeV9",
  "id" : 106826357677375488,
  "created_at" : "2011-08-25 20:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Creek Pet Hosptl",
      "screen_name" : "BigCreekPetHosp",
      "indices" : [ 3, 19 ],
      "id_str" : "93822388",
      "id" : 93822388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106410368892551169",
  "text" : "RT @BigCreekPetHosp: \"I think dogs are the most amazing creatures; they give unconditional love.  For me they are the role model for bei ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106404169111453696",
    "text" : "\"I think dogs are the most amazing creatures; they give unconditional love.  For me they are the role model for being alive.\" ~Gilda Radner",
    "id" : 106404169111453696,
    "created_at" : "2011-08-24 16:35:05 +0000",
    "user" : {
      "name" : "Big Creek Pet Hosptl",
      "screen_name" : "BigCreekPetHosp",
      "protected" : false,
      "id_str" : "93822388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552852651\/BCPH_Capitals_Logo_normal.jpg",
      "id" : 93822388,
      "verified" : false
    }
  },
  "id" : 106410368892551169,
  "created_at" : "2011-08-24 16:59:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "indices" : [ 3, 8 ],
      "id_str" : "18957524",
      "id" : 18957524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/Rj2ofiG",
      "expanded_url" : "http:\/\/twitpic.com\/3rgx0p",
      "display_url" : "twitpic.com\/3rgx0p"
    } ]
  },
  "geo" : { },
  "id_str" : "106410324747489281",
  "text" : "RT @Syfy: I'm giving away my Syfy branded iPod Nano 8GB to someone who retweets this note by 8\/26 at 5pm PT - http:\/\/t.co\/Rj2ofiG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 119 ],
        "url" : "http:\/\/t.co\/Rj2ofiG",
        "expanded_url" : "http:\/\/twitpic.com\/3rgx0p",
        "display_url" : "twitpic.com\/3rgx0p"
      } ]
    },
    "geo" : { },
    "id_str" : "106406689036709888",
    "text" : "I'm giving away my Syfy branded iPod Nano 8GB to someone who retweets this note by 8\/26 at 5pm PT - http:\/\/t.co\/Rj2ofiG",
    "id" : 106406689036709888,
    "created_at" : "2011-08-24 16:45:06 +0000",
    "user" : {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "protected" : false,
      "id_str" : "18957524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793455496611172352\/4ntFcBSF_normal.jpg",
      "id" : 18957524,
      "verified" : true
    }
  },
  "id" : 106410324747489281,
  "created_at" : "2011-08-24 16:59:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106377541224382464",
  "text" : "RT @Buddhaworld: life is a gift, dont make it a burden.buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106367834430517248",
    "text" : "life is a gift, dont make it a burden.buddha volko.",
    "id" : 106367834430517248,
    "created_at" : "2011-08-24 14:10:42 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 106377541224382464,
  "created_at" : "2011-08-24 14:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifecoach",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106377265864130560",
  "text" : "RT @Buddhaworld: need a kick in the butt, a loving word, a problem solved or created,#lifecoach buddha volko can help.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lifecoach",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106373827612770304",
    "text" : "need a kick in the butt, a loving word, a problem solved or created,#lifecoach buddha volko can help.",
    "id" : 106373827612770304,
    "created_at" : "2011-08-24 14:34:31 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 106377265864130560,
  "created_at" : "2011-08-24 14:48:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Diana Samalot",
      "screen_name" : "dsamalot",
      "indices" : [ 22, 31 ],
      "id_str" : "73278152",
      "id" : 73278152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106376890679431168",
  "text" : "RT @Dwayne_Reaves: RT @dsamalot: \"A brand new life is simply a decision away...\" \u2014Rich German",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Diana Samalot",
        "screen_name" : "dsamalot",
        "indices" : [ 3, 12 ],
        "id_str" : "73278152",
        "id" : 73278152
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106375611106332672",
    "text" : "RT @dsamalot: \"A brand new life is simply a decision away...\" \u2014Rich German",
    "id" : 106375611106332672,
    "created_at" : "2011-08-24 14:41:36 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 106376890679431168,
  "created_at" : "2011-08-24 14:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/WA2nAH3",
      "expanded_url" : "http:\/\/amzn.com\/k\/1A7GD53K2HV6A",
      "display_url" : "amzn.com\/k\/1A7GD53K2HV6A"
    } ]
  },
  "geo" : { },
  "id_str" : "105830926960955392",
  "text" : "http:\/\/t.co\/WA2nAH3 #Kindle",
  "id" : 105830926960955392,
  "created_at" : "2011-08-23 02:37:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105813445936553985",
  "text" : "RT @angelaharms: Kids need loving approval. Pls do what you need to, get your own stuff worked out, so you can enjoy your kids. It can c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105809273182879744",
    "text" : "Kids need loving approval. Pls do what you need to, get your own stuff worked out, so you can enjoy your kids. It can change the world.",
    "id" : 105809273182879744,
    "created_at" : "2011-08-23 01:11:11 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 105813445936553985,
  "created_at" : "2011-08-23 01:27:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105806358363897856",
  "geo" : { },
  "id_str" : "105807930347098113",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves I think we all feel that way at times. Tomorrow will be different!",
  "id" : 105807930347098113,
  "in_reply_to_status_id" : 105806358363897856,
  "created_at" : "2011-08-23 01:05:51 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105789876082978816",
  "geo" : { },
  "id_str" : "105790509158633473",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 omc.. some ppl...",
  "id" : 105790509158633473,
  "in_reply_to_status_id" : 105789876082978816,
  "created_at" : "2011-08-22 23:56:37 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105787622114344960",
  "geo" : { },
  "id_str" : "105789748374798337",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I suppose it depends upon the intonation..but yeah, some parents are rather harsh.",
  "id" : 105789748374798337,
  "in_reply_to_status_id" : 105787622114344960,
  "created_at" : "2011-08-22 23:53:36 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "indices" : [ 3, 18 ],
      "id_str" : "17919174",
      "id" : 17919174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105742189824458752",
  "text" : "RT @Michael_Palmer: try your hand at #thriller writing\u2026 contribute your ideas to my story beginning to win a copy of No Rest for the Dea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/KNEFi5n",
        "expanded_url" : "http:\/\/on.fb.me\/rdSt9f",
        "display_url" : "on.fb.me\/rdSt9f"
      } ]
    },
    "geo" : { },
    "id_str" : "105741281799581696",
    "text" : "try your hand at #thriller writing\u2026 contribute your ideas to my story beginning to win a copy of No Rest for the Dead http:\/\/t.co\/KNEFi5n",
    "id" : 105741281799581696,
    "created_at" : "2011-08-22 20:41:00 +0000",
    "user" : {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "protected" : false,
      "id_str" : "17919174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817290389\/michael_normal.jpg",
      "id" : 17919174,
      "verified" : false
    }
  },
  "id" : 105742189824458752,
  "created_at" : "2011-08-22 20:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105734266566082560",
  "geo" : { },
  "id_str" : "105741032016183296",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I only ate my mom's spaghetti (as adult, as kid I didn't like it) .. havent had good spaghetti in 3 yrs now..sigh.",
  "id" : 105741032016183296,
  "in_reply_to_status_id" : 105734266566082560,
  "created_at" : "2011-08-22 20:40:01 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105732406350331905",
  "geo" : { },
  "id_str" : "105734155597381632",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld heehee.. that is interesting..",
  "id" : 105734155597381632,
  "in_reply_to_status_id" : 105732406350331905,
  "created_at" : "2011-08-22 20:12:41 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 15, 27 ],
      "id_str" : "40560386",
      "id" : 40560386
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 28, 40 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 73, 85 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterdinner",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105731064286298112",
  "text" : "#twitterdinner @buddhaworld @CaroleODell @tragic_pizza @SamsaricWarrior  @angelaharms",
  "id" : 105731064286298112,
  "created_at" : "2011-08-22 20:00:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannyn Moore",
      "screen_name" : "shannynmoore",
      "indices" : [ 3, 16 ],
      "id_str" : "24854688",
      "id" : 24854688
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "twitterdinner",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105729401081167872",
  "text" : "RT @shannynmoore: If you could have dinner with 5 people you follow on #twitter - who would they be? #twitterdinner",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitter",
        "indices" : [ 53, 61 ]
      }, {
        "text" : "twitterdinner",
        "indices" : [ 83, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105524996293656577",
    "text" : "If you could have dinner with 5 people you follow on #twitter - who would they be? #twitterdinner",
    "id" : 105524996293656577,
    "created_at" : "2011-08-22 06:21:34 +0000",
    "user" : {
      "name" : "Shannyn Moore",
      "screen_name" : "shannynmoore",
      "protected" : false,
      "id_str" : "24854688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786461979678380034\/5WMdu9ph_normal.jpg",
      "id" : 24854688,
      "verified" : false
    }
  },
  "id" : 105729401081167872,
  "created_at" : "2011-08-22 19:53:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 38 ],
      "url" : "http:\/\/t.co\/NvtUouv",
      "expanded_url" : "http:\/\/www.lifewithcats.tv\/2011\/08\/22\/8945\/",
      "display_url" : "lifewithcats.tv\/2011\/08\/22\/894\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105690834376208384",
  "text" : "Kitty in the Couch http:\/\/t.co\/NvtUouv",
  "id" : 105690834376208384,
  "created_at" : "2011-08-22 17:20:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/yey1Itb",
      "expanded_url" : "http:\/\/bit.ly\/dkjzBF",
      "display_url" : "bit.ly\/dkjzBF"
    } ]
  },
  "geo" : { },
  "id_str" : "105686422505263104",
  "text" : "RT @thesexyatheist: Help me tweeps. should I become a full fledged angry atheist or stay an http:\/\/t.co\/yey1Itb acomodationalist. I'm si ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 91 ],
        "url" : "http:\/\/t.co\/yey1Itb",
        "expanded_url" : "http:\/\/bit.ly\/dkjzBF",
        "display_url" : "bit.ly\/dkjzBF"
      } ]
    },
    "geo" : { },
    "id_str" : "105685054684004352",
    "text" : "Help me tweeps. should I become a full fledged angry atheist or stay an http:\/\/t.co\/yey1Itb acomodationalist. I'm sitting on the fence.",
    "id" : 105685054684004352,
    "created_at" : "2011-08-22 16:57:35 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 105686422505263104,
  "created_at" : "2011-08-22 17:03:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "SagesandScientists",
      "screen_name" : "SagesScientists",
      "indices" : [ 33, 49 ],
      "id_str" : "4569640454",
      "id" : 4569640454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105681079075217408",
  "text" : "RT @DeepakChopra: Supporting! RT @SagesScientists When you make a choice, you change the future.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SagesandScientists",
        "screen_name" : "SagesScientists",
        "indices" : [ 15, 31 ],
        "id_str" : "4569640454",
        "id" : 4569640454
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105680892323823616",
    "text" : "Supporting! RT @SagesScientists When you make a choice, you change the future.",
    "id" : 105680892323823616,
    "created_at" : "2011-08-22 16:41:02 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 105681079075217408,
  "created_at" : "2011-08-22 16:41:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 34 ],
      "url" : "http:\/\/t.co\/uH1LDQ6",
      "expanded_url" : "http:\/\/gplus.to\/abfabgab",
      "display_url" : "gplus.to\/abfabgab"
    } ]
  },
  "geo" : { },
  "id_str" : "105680922791247872",
  "text" : "FYI: I'm on G+ http:\/\/t.co\/uH1LDQ6",
  "id" : 105680922791247872,
  "created_at" : "2011-08-22 16:41:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105677528932425728",
  "geo" : { },
  "id_str" : "105679684183924736",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld you always brighten my day w your wit & wisdom : )",
  "id" : 105679684183924736,
  "in_reply_to_status_id" : 105677528932425728,
  "created_at" : "2011-08-22 16:36:14 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105669795004944384",
  "text" : "not looking forward to start of school year in 2 weeks.. ugh. cant wait until DD is done.",
  "id" : 105669795004944384,
  "created_at" : "2011-08-22 15:56:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105669562879590401",
  "text" : "did not sleep at all last night...",
  "id" : 105669562879590401,
  "created_at" : "2011-08-22 15:56:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105334554415464448",
  "text" : "RT @Buddhaworld: we all live in our own small head. If we dont poke a hole into it and let the mind fly, no freedom. Buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105331120958222337",
    "text" : "we all live in our own small head. If we dont poke a hole into it and let the mind fly, no freedom. Buddha volko.",
    "id" : 105331120958222337,
    "created_at" : "2011-08-21 17:31:10 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 105334554415464448,
  "created_at" : "2011-08-21 17:44:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Truth",
      "indices" : [ 25, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105317579882631169",
  "text" : "RT @CaroleODell: This is #Truth: 'You can easily judge the character of a man by how he treats those who can do nothing for him.\u201D ~ J. C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Truth",
        "indices" : [ 8, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105315541224390656",
    "text" : "This is #Truth: 'You can easily judge the character of a man by how he treats those who can do nothing for him.\u201D ~ J. C. Watts",
    "id" : 105315541224390656,
    "created_at" : "2011-08-21 16:29:16 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 105317579882631169,
  "created_at" : "2011-08-21 16:37:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105312267909865472",
  "geo" : { },
  "id_str" : "105315397540134913",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms good post. makes sense. : )",
  "id" : 105315397540134913,
  "in_reply_to_status_id" : 105312267909865472,
  "created_at" : "2011-08-21 16:28:42 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105313019076153344",
  "geo" : { },
  "id_str" : "105313853373546497",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld well, you haven't told me yet so I guess I'm ok! ; )",
  "id" : 105313853373546497,
  "in_reply_to_status_id" : 105313019076153344,
  "created_at" : "2011-08-21 16:22:33 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Miller",
      "screen_name" : "lindamiller",
      "indices" : [ 3, 15 ],
      "id_str" : "14825460",
      "id" : 14825460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105308284831006721",
  "text" : "RT @lindamiller: Affirmation:  I am Wealthy and Abundant.  Wealth and Abundance come easily to me. (Say this 400 times a day)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105306382567346176",
    "text" : "Affirmation:  I am Wealthy and Abundant.  Wealth and Abundance come easily to me. (Say this 400 times a day)",
    "id" : 105306382567346176,
    "created_at" : "2011-08-21 15:52:52 +0000",
    "user" : {
      "name" : "Linda Miller",
      "screen_name" : "lindamiller",
      "protected" : false,
      "id_str" : "14825460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835610296\/lindaamega9-2_normal.jpg",
      "id" : 14825460,
      "verified" : false
    }
  },
  "id" : 105308284831006721,
  "created_at" : "2011-08-21 16:00:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105304960236924928",
  "text" : "RT @Buddhaworld: looking up a tree, green with the blue sky above it, that makes my day.buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105304705936261120",
    "text" : "looking up a tree, green with the blue sky above it, that makes my day.buddha volko.",
    "id" : 105304705936261120,
    "created_at" : "2011-08-21 15:46:13 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 105304960236924928,
  "created_at" : "2011-08-21 15:47:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Maiers",
      "screen_name" : "AngelaMaiers",
      "indices" : [ 3, 16 ],
      "id_str" : "9158962",
      "id" : 9158962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105304945019990018",
  "text" : "RT @AngelaMaiers: We r social\/emotional beings yet we continue 2 dismiss role of emotion, passion,inspiration as \"soft\", \"fluff\" \"warm f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Spiritchat",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105297801935716352",
    "text" : "We r social\/emotional beings yet we continue 2 dismiss role of emotion, passion,inspiration as \"soft\", \"fluff\" \"warm fuzzy\"  #Spiritchat",
    "id" : 105297801935716352,
    "created_at" : "2011-08-21 15:18:46 +0000",
    "user" : {
      "name" : "Angela Maiers",
      "screen_name" : "AngelaMaiers",
      "protected" : false,
      "id_str" : "9158962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620397163604869120\/PB4UJxh7_normal.jpg",
      "id" : 9158962,
      "verified" : true
    }
  },
  "id" : 105304945019990018,
  "created_at" : "2011-08-21 15:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/Yg3ECS8",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2011\/08\/louis-ck-why-i-had-to-punch-my-dog\/",
      "display_url" : "lifewithdogs.tv\/2011\/08\/louis-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105302892700897281",
  "text" : "Louis CK: Why I Had to Punch My Dog http:\/\/t.co\/Yg3ECS8 via @nigelbugger",
  "id" : 105302892700897281,
  "created_at" : "2011-08-21 15:39:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105092912928391168",
  "text" : "RT @TrishScott: I don't believe in the friends & enemy's thing - just who I can stand and who I can't - nothing personal\/evil\/good about it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105090892590878720",
    "text" : "I don't believe in the friends & enemy's thing - just who I can stand and who I can't - nothing personal\/evil\/good about it.",
    "id" : 105090892590878720,
    "created_at" : "2011-08-21 01:36:35 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 105092912928391168,
  "created_at" : "2011-08-21 01:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105080496488316929",
  "geo" : { },
  "id_str" : "105083545973825536",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves big ((hugs))",
  "id" : 105083545973825536,
  "in_reply_to_status_id" : 105080496488316929,
  "created_at" : "2011-08-21 01:07:24 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105080104962621440",
  "text" : "RT @SEsever: Please accept my apologies for any inconvenience caused; I\u2019m still under construction.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103140558473670656",
    "text" : "Please accept my apologies for any inconvenience caused; I\u2019m still under construction.",
    "id" : 103140558473670656,
    "created_at" : "2011-08-15 16:26:40 +0000",
    "user" : {
      "name" : "Ela Crain",
      "screen_name" : "elacrain",
      "protected" : false,
      "id_str" : "119183270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777622497520939009\/nT2nwIRB_normal.jpg",
      "id" : 119183270,
      "verified" : false
    }
  },
  "id" : 105080104962621440,
  "created_at" : "2011-08-21 00:53:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "Nathan T. Wright",
      "screen_name" : "nathantwright",
      "indices" : [ 40, 54 ],
      "id_str" : "3267891",
      "id" : 3267891
    }, {
      "name" : "The Frisky",
      "screen_name" : "TheFrisky",
      "indices" : [ 55, 65 ],
      "id_str" : "13220962",
      "id" : 13220962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105079834195132416",
  "text" : "RT @GaribaldiRous: Fear of cuteness? RT @nathantwright @TheFrisky: New Thing I\u2019m Terrified Of: The Capybara http:\/\/ow.ly\/67vir cc @norah ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan T. Wright",
        "screen_name" : "nathantwright",
        "indices" : [ 21, 35 ],
        "id_str" : "3267891",
        "id" : 3267891
      }, {
        "name" : "The Frisky",
        "screen_name" : "TheFrisky",
        "indices" : [ 36, 46 ],
        "id_str" : "13220962",
        "id" : 13220962
      }, {
        "name" : "Norah Carroll",
        "screen_name" : "norahcarroll",
        "indices" : [ 111, 124 ],
        "id_str" : "17071255",
        "id" : 17071255
      }, {
        "name" : "Hillary Ferry",
        "screen_name" : "hillabean",
        "indices" : [ 125, 135 ],
        "id_str" : "14270283",
        "id" : 14270283
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105074179241549825",
    "text" : "Fear of cuteness? RT @nathantwright @TheFrisky: New Thing I\u2019m Terrified Of: The Capybara http:\/\/ow.ly\/67vir cc @norahcarroll @hillabean",
    "id" : 105074179241549825,
    "created_at" : "2011-08-21 00:30:11 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 105079834195132416,
  "created_at" : "2011-08-21 00:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 0, 14 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105078058100330496",
  "geo" : { },
  "id_str" : "105079039781380097",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne_Reaves whoa.. glad you're ok!",
  "id" : 105079039781380097,
  "in_reply_to_status_id" : 105078058100330496,
  "created_at" : "2011-08-21 00:49:30 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments",
      "indices" : [ 3, 15 ],
      "id_str" : "17486629",
      "id" : 17486629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105064825805213696",
  "text" : "RT @Zen_Moments: A free society is a place where it's safe to be unpopular. ~ Adlai Stevenson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.zazzle.com\/zen_moments\" rel=\"nofollow\"\u003EZen Moments Gift Store\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102723197849436160",
    "text" : "A free society is a place where it's safe to be unpopular. ~ Adlai Stevenson",
    "id" : 102723197849436160,
    "created_at" : "2011-08-14 12:48:13 +0000",
    "user" : {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments",
      "protected" : false,
      "id_str" : "17486629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117626620\/circle-1_normal.PNG",
      "id" : 17486629,
      "verified" : false
    }
  },
  "id" : 105064825805213696,
  "created_at" : "2011-08-20 23:53:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105023499453730816",
  "text" : "RT @Buddhaworld: if you are sure about something, it took some time to get there.8uddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105020277980794880",
    "text" : "if you are sure about something, it took some time to get there.8uddha volko.",
    "id" : 105020277980794880,
    "created_at" : "2011-08-20 20:56:00 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 105023499453730816,
  "created_at" : "2011-08-20 21:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 3, 11 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104997402452295680",
  "text" : "RT @arphaus: \"..human behavior is much more under the control of subtle situational forces, in some cases very trivial ones, like ru htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/startgoogleplus.com\" rel=\"nofollow\"\u003ESGPlus\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/BtbqiVe",
        "expanded_url" : "http:\/\/sgp.cm\/fe5eb7",
        "display_url" : "sgp.cm\/fe5eb7"
      } ]
    },
    "geo" : { },
    "id_str" : "104996781301047296",
    "text" : "\"..human behavior is much more under the control of subtle situational forces, in some cases very trivial ones, like ru http:\/\/t.co\/BtbqiVe",
    "id" : 104996781301047296,
    "created_at" : "2011-08-20 19:22:38 +0000",
    "user" : {
      "name" : "Arp Laszlo",
      "screen_name" : "thisisarp",
      "protected" : false,
      "id_str" : "7339162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773529857464688640\/ZPr3v43v_normal.jpg",
      "id" : 7339162,
      "verified" : false
    }
  },
  "id" : 104997402452295680,
  "created_at" : "2011-08-20 19:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104996455365869568",
  "geo" : { },
  "id_str" : "104997248680734720",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope I love woolly bears!",
  "id" : 104997248680734720,
  "in_reply_to_status_id" : 104996455365869568,
  "created_at" : "2011-08-20 19:24:29 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104995263298551808",
  "geo" : { },
  "id_str" : "104996623934951426",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope awwwwww... : )",
  "id" : 104996623934951426,
  "in_reply_to_status_id" : 104995263298551808,
  "created_at" : "2011-08-20 19:22:00 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/yL30jPU",
      "expanded_url" : "http:\/\/unicornbooty.com\/2011\/08\/bachmann-hires-kill-the-gays-bill-supporter-arrested-for-terrorism\/",
      "display_url" : "unicornbooty.com\/2011\/08\/bachma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104983593083867136",
  "text" : "Bachmann Hires \u2018Kill The Gays Bill\u2019 Supporter Arrested for Terrorism http:\/\/t.co\/yL30jPU",
  "id" : 104983593083867136,
  "created_at" : "2011-08-20 18:30:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/xReqNrJ",
      "expanded_url" : "http:\/\/bit.ly\/6pPvcQ",
      "display_url" : "bit.ly\/6pPvcQ"
    } ]
  },
  "geo" : { },
  "id_str" : "104956500161724417",
  "text" : "RT @WestofMars: West of Mars Win a Book is open for business again.  http:\/\/t.co\/xReqNrJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 72 ],
        "url" : "http:\/\/t.co\/xReqNrJ",
        "expanded_url" : "http:\/\/bit.ly\/6pPvcQ",
        "display_url" : "bit.ly\/6pPvcQ"
      } ]
    },
    "geo" : { },
    "id_str" : "104953562714476544",
    "text" : "West of Mars Win a Book is open for business again.  http:\/\/t.co\/xReqNrJ",
    "id" : 104953562714476544,
    "created_at" : "2011-08-20 16:30:53 +0000",
    "user" : {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "protected" : false,
      "id_str" : "34258680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454321783588413442\/gndVsGba_normal.png",
      "id" : 34258680,
      "verified" : false
    }
  },
  "id" : 104956500161724417,
  "created_at" : "2011-08-20 16:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104956485074821120",
  "text" : "RT @OMGFacts: The @ sign was very close to being eliminated from the standard keyboard until 1971, when Ray Tomlinson used it to send th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104953635611492353",
    "text" : "The @ sign was very close to being eliminated from the standard keyboard until 1971, when Ray Tomlinson used it to send the first email.",
    "id" : 104953635611492353,
    "created_at" : "2011-08-20 16:31:11 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 104956485074821120,
  "created_at" : "2011-08-20 16:42:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104940508559851521",
  "text" : "crow on tree made funny noise. like if you turned handle and something clicked. interesting.",
  "id" : 104940508559851521,
  "created_at" : "2011-08-20 15:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 41, 52 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 53, 66 ],
      "id_str" : "42974138",
      "id" : 42974138
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 67, 79 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Kathy Loh",
      "screen_name" : "KathyLoh",
      "indices" : [ 80, 89 ],
      "id_str" : "18706924",
      "id" : 18706924
    }, {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 90, 103 ],
      "id_str" : "124594428",
      "id" : 124594428
    }, {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 104, 119 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 120, 133 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104940272080789505",
  "text" : "wonderful ppl who reply to me \u2665 @XNutsyX @mimismutts @GraveStomper @CaroleODell @KathyLoh @golden_books @MartijnLinssen @joeandrasi93",
  "id" : 104940272080789505,
  "created_at" : "2011-08-20 15:38:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104651231494021120",
  "text" : "@XNutsyX NO! I would not.",
  "id" : 104651231494021120,
  "created_at" : "2011-08-19 20:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/jcyIIO6",
      "expanded_url" : "http:\/\/bit.ly\/r2MLWO",
      "display_url" : "bit.ly\/r2MLWO"
    } ]
  },
  "geo" : { },
  "id_str" : "104629131915964418",
  "text" : "Offer: edirectory installation on your server http:\/\/t.co\/jcyIIO6",
  "id" : 104629131915964418,
  "created_at" : "2011-08-19 19:01:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "indices" : [ 3, 14 ],
      "id_str" : "190004285",
      "id" : 190004285
    }, {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "indices" : [ 46, 57 ],
      "id_str" : "190004285",
      "id" : 190004285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/2C16XPM",
      "expanded_url" : "http:\/\/bit.ly\/qyfh02",
      "display_url" : "bit.ly\/qyfh02"
    } ]
  },
  "geo" : { },
  "id_str" : "104627248899948544",
  "text" : "RT @PixelofInk: [GIVEAWAY] Win a #Kindle from @pixelofink http:\/\/t.co\/2C16XPM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pixel of Ink",
        "screen_name" : "PixelofInk",
        "indices" : [ 30, 41 ],
        "id_str" : "190004285",
        "id" : 190004285
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 61 ],
        "url" : "http:\/\/t.co\/2C16XPM",
        "expanded_url" : "http:\/\/bit.ly\/qyfh02",
        "display_url" : "bit.ly\/qyfh02"
      } ]
    },
    "geo" : { },
    "id_str" : "104626907705905152",
    "text" : "[GIVEAWAY] Win a #Kindle from @pixelofink http:\/\/t.co\/2C16XPM",
    "id" : 104626907705905152,
    "created_at" : "2011-08-19 18:52:53 +0000",
    "user" : {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "protected" : false,
      "id_str" : "190004285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1954428066\/PixelOfInk_Avatar_200x200_normal.png",
      "id" : 190004285,
      "verified" : false
    }
  },
  "id" : 104627248899948544,
  "created_at" : "2011-08-19 18:54:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104626271908139008",
  "text" : "RT @TheGodLight: Action is the cure for frustration, you need to move through negativity, to reach your goal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104626050532769792",
    "text" : "Action is the cure for frustration, you need to move through negativity, to reach your goal.",
    "id" : 104626050532769792,
    "created_at" : "2011-08-19 18:49:28 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 104626271908139008,
  "created_at" : "2011-08-19 18:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104626132485279745",
  "text" : "hubby made friends w a praying mantis..lol",
  "id" : 104626132485279745,
  "created_at" : "2011-08-19 18:49:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104589713775673345",
  "text" : "blog or squeeze page? or both? I need focus (so hard for a pisces!)",
  "id" : 104589713775673345,
  "created_at" : "2011-08-19 16:25:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "migraines",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104584429569187840",
  "text" : "RT @Matth3ous: Does anyone know any foods that help fix #migraines? :(",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "migraines",
        "indices" : [ 41, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104584254800924672",
    "text" : "Does anyone know any foods that help fix #migraines? :(",
    "id" : 104584254800924672,
    "created_at" : "2011-08-19 16:03:24 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 104584429569187840,
  "created_at" : "2011-08-19 16:04:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104584323520413696",
  "text" : "feel like Im on high wire.. my emotions keep swaying. ugh. someone save me from myself.",
  "id" : 104584323520413696,
  "created_at" : "2011-08-19 16:03:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "indices" : [ 3, 16 ],
      "id_str" : "78155553",
      "id" : 78155553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104379329512873984",
  "text" : "RT @angelmagicjp: Anything can be considered a miracle when seen through the eyes of love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104378969171824640",
    "text" : "Anything can be considered a miracle when seen through the eyes of love.",
    "id" : 104378969171824640,
    "created_at" : "2011-08-19 02:27:40 +0000",
    "user" : {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "protected" : false,
      "id_str" : "78155553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1497479357\/Hand_Heart_Sun_2_normal.jpg",
      "id" : 78155553,
      "verified" : false
    }
  },
  "id" : 104379329512873984,
  "created_at" : "2011-08-19 02:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny Coates",
      "screen_name" : "DennyCoates",
      "indices" : [ 3, 15 ],
      "id_str" : "33998869",
      "id" : 33998869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104369101388001280",
  "text" : "RT @DennyCoates: \"Every animal knows more than you do.\" - Native American Proverb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104366307746643968",
    "text" : "\"Every animal knows more than you do.\" - Native American Proverb",
    "id" : 104366307746643968,
    "created_at" : "2011-08-19 01:37:21 +0000",
    "user" : {
      "name" : "Denny Coates",
      "screen_name" : "DennyCoates",
      "protected" : false,
      "id_str" : "33998869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616644668600651776\/oOmY-MhL_normal.jpg",
      "id" : 33998869,
      "verified" : false
    }
  },
  "id" : 104369101388001280,
  "created_at" : "2011-08-19 01:48:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Lain",
      "screen_name" : "DougLain",
      "indices" : [ 3, 12 ],
      "id_str" : "17587951",
      "id" : 17587951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104365263880847360",
  "text" : "RT @DougLain: Any String Theorists following me willing to vet a short essay I wrote about Holographic Universe?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104364009746214913",
    "text" : "Any String Theorists following me willing to vet a short essay I wrote about Holographic Universe?",
    "id" : 104364009746214913,
    "created_at" : "2011-08-19 01:28:13 +0000",
    "user" : {
      "name" : "Douglas Lain",
      "screen_name" : "DougLain",
      "protected" : false,
      "id_str" : "17587951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538209719538561024\/pPo0Ku___normal.jpeg",
      "id" : 17587951,
      "verified" : false
    }
  },
  "id" : 104365263880847360,
  "created_at" : "2011-08-19 01:33:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/RcYDFVa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MGiFg2AB0Zc&feature=share",
      "display_url" : "youtube.com\/watch?v=MGiFg2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104362902991015936",
  "text" : "change is coming. that's what 2012 is all about. change of consciousness. exciting time to be alive.   http:\/\/t.co\/RcYDFVa",
  "id" : 104362902991015936,
  "created_at" : "2011-08-19 01:23:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "Kai Wilson-Viola",
      "screen_name" : "Kaiberie",
      "indices" : [ 44, 53 ],
      "id_str" : "3230021",
      "id" : 3230021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/ebVEu1U",
      "expanded_url" : "http:\/\/fb.me\/19nKI0Ebr",
      "display_url" : "fb.me\/19nKI0Ebr"
    } ]
  },
  "geo" : { },
  "id_str" : "104314912263770112",
  "text" : "RT @CandyTX: Attn Indie writers ---&gt; PRT @Kaiberie:  I've started a FB group 4 indie authors  http:\/\/t.co\/ebVEu1U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kai Wilson-Viola",
        "screen_name" : "Kaiberie",
        "indices" : [ 31, 40 ],
        "id_str" : "3230021",
        "id" : 3230021
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 103 ],
        "url" : "http:\/\/t.co\/ebVEu1U",
        "expanded_url" : "http:\/\/fb.me\/19nKI0Ebr",
        "display_url" : "fb.me\/19nKI0Ebr"
      } ]
    },
    "geo" : { },
    "id_str" : "104313716257992704",
    "text" : "Attn Indie writers ---&gt; PRT @Kaiberie:  I've started a FB group 4 indie authors  http:\/\/t.co\/ebVEu1U",
    "id" : 104313716257992704,
    "created_at" : "2011-08-18 22:08:22 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 104314912263770112,
  "created_at" : "2011-08-18 22:13:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Billy Bigelow",
      "screen_name" : "jsringo",
      "indices" : [ 18, 26 ],
      "id_str" : "25997640",
      "id" : 25997640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truth",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104311135746015233",
  "text" : "RT @CaroleODell: \"@jsringo: A dog will sit beside you while you work. A cat will sit on your work.\"#truth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Billy Bigelow",
        "screen_name" : "jsringo",
        "indices" : [ 1, 9 ],
        "id_str" : "25997640",
        "id" : 25997640
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "truth",
        "indices" : [ 82, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104304919238021122",
    "text" : "\"@jsringo: A dog will sit beside you while you work. A cat will sit on your work.\"#truth",
    "id" : 104304919238021122,
    "created_at" : "2011-08-18 21:33:25 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 104311135746015233,
  "created_at" : "2011-08-18 21:58:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skyla Dawn Cameron",
      "screen_name" : "skyladawn",
      "indices" : [ 3, 13 ],
      "id_str" : "16212768",
      "id" : 16212768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104273460540350464",
  "text" : "RT @skyladawn: If there could be fewer books where every male char wants to fuck the heroine & every other female is evil, that would be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104260363893223424",
    "text" : "If there could be fewer books where every male char wants to fuck the heroine & every other female is evil, that would be great. Love, Skyla",
    "id" : 104260363893223424,
    "created_at" : "2011-08-18 18:36:22 +0000",
    "user" : {
      "name" : "Skyla Dawn Cameron",
      "screen_name" : "skyladawn",
      "protected" : false,
      "id_str" : "16212768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781197569363963904\/UBe6Kwry_normal.jpg",
      "id" : 16212768,
      "verified" : false
    }
  },
  "id" : 104273460540350464,
  "created_at" : "2011-08-18 19:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104229101929373697",
  "text" : "RT @BrianMerritt: I have been dreadfully poor and comfortable.  I prefer comfort.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104223595424780288",
    "text" : "I have been dreadfully poor and comfortable.  I prefer comfort.",
    "id" : 104223595424780288,
    "created_at" : "2011-08-18 16:10:16 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 104229101929373697,
  "created_at" : "2011-08-18 16:32:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104186777346117632",
  "geo" : { },
  "id_str" : "104188486877327360",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books def good. a sense of equality w others. (im always feeling \"less than\")",
  "id" : 104188486877327360,
  "in_reply_to_status_id" : 104186777346117632,
  "created_at" : "2011-08-18 13:50:45 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy Loh",
      "screen_name" : "KathyLoh",
      "indices" : [ 3, 12 ],
      "id_str" : "18706924",
      "id" : 18706924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/61iw69G",
      "expanded_url" : "http:\/\/bit.ly\/noFVLB",
      "display_url" : "bit.ly\/noFVLB"
    } ]
  },
  "geo" : { },
  "id_str" : "104013924634075136",
  "text" : "RT @KathyLoh: Scientists prove DNA can be reprogrammed by words and frequencies http:\/\/t.co\/61iw69G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http:\/\/t.co\/61iw69G",
        "expanded_url" : "http:\/\/bit.ly\/noFVLB",
        "display_url" : "bit.ly\/noFVLB"
      } ]
    },
    "geo" : { },
    "id_str" : "104009170101092354",
    "text" : "Scientists prove DNA can be reprogrammed by words and frequencies http:\/\/t.co\/61iw69G",
    "id" : 104009170101092354,
    "created_at" : "2011-08-18 01:58:13 +0000",
    "user" : {
      "name" : "Kathy Loh",
      "screen_name" : "KathyLoh",
      "protected" : false,
      "id_str" : "18706924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494694002709377024\/kLgpH418_normal.jpeg",
      "id" : 18706924,
      "verified" : false
    }
  },
  "id" : 104013924634075136,
  "created_at" : "2011-08-18 02:17:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103929443977924608",
  "geo" : { },
  "id_str" : "103930658769997824",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell LOL",
  "id" : 103930658769997824,
  "in_reply_to_status_id" : 103929443977924608,
  "created_at" : "2011-08-17 20:46:14 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK Rising",
      "screen_name" : "DKRising",
      "indices" : [ 0, 9 ],
      "id_str" : "716678263855267840",
      "id" : 716678263855267840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103928003100286976",
  "geo" : { },
  "id_str" : "103928570107273216",
  "in_reply_to_user_id" : 28032888,
  "text" : "@DKRising umm.. I never had a fan club...",
  "id" : 103928570107273216,
  "in_reply_to_status_id" : 103928003100286976,
  "created_at" : "2011-08-17 20:37:56 +0000",
  "in_reply_to_screen_name" : "horseandahalf",
  "in_reply_to_user_id_str" : "28032888",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103927038519414785",
  "text" : "today.. just now.. something inside me just shifted. Wow. Amazing when I can recognize those moments of change.",
  "id" : 103927038519414785,
  "created_at" : "2011-08-17 20:31:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canada Good",
      "screen_name" : "CanadaGood",
      "indices" : [ 3, 14 ],
      "id_str" : "15049217",
      "id" : 15049217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103875407387959297",
  "text" : "RT @CanadaGood: DRACO antivirus treatment should be #1 news story. Appears to cure ANY virus including Hepatitis, H1N1, etc etc http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 131 ],
        "url" : "http:\/\/t.co\/Da9kcgC",
        "expanded_url" : "http:\/\/healthland.time.com\/2011\/08\/11\/mit-scientists-develop-a-drug-to-fight-any-viral-infection\/",
        "display_url" : "healthland.time.com\/2011\/08\/11\/mit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "102364080999907328",
    "text" : "DRACO antivirus treatment should be #1 news story. Appears to cure ANY virus including Hepatitis, H1N1, etc etc http:\/\/t.co\/Da9kcgC",
    "id" : 102364080999907328,
    "created_at" : "2011-08-13 13:01:13 +0000",
    "user" : {
      "name" : "Canada Good",
      "screen_name" : "CanadaGood",
      "protected" : false,
      "id_str" : "15049217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3656147869\/323f5465ba0ed87e82bf094bc75aa9d9_normal.jpeg",
      "id" : 15049217,
      "verified" : false
    }
  },
  "id" : 103875407387959297,
  "created_at" : "2011-08-17 17:06:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 43 ],
      "url" : "http:\/\/t.co\/CjNk9Zq",
      "expanded_url" : "http:\/\/www.montrealgazette.com\/technology\/iPads+with+apes\/5262466\/story.html",
      "display_url" : "montrealgazette.com\/technology\/iPa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "103867676933361665",
  "text" : "iPads now hip with apes http:\/\/t.co\/CjNk9Zq",
  "id" : 103867676933361665,
  "created_at" : "2011-08-17 16:35:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103856902148075522",
  "text" : "Happy Birthday @SamsaricWarrior : )",
  "id" : 103856902148075522,
  "created_at" : "2011-08-17 15:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103613501968367617",
  "text" : "@XNutsyX omg'ness I know that feeling so well!",
  "id" : 103613501968367617,
  "created_at" : "2011-08-16 23:45:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inspired Ones",
      "screen_name" : "Inspired_ones",
      "indices" : [ 3, 17 ],
      "id_str" : "1117959518",
      "id" : 1117959518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103610045840891904",
  "text" : "RT @Inspired_Ones: No act of kindness, no matter how small, is ever wasted. -Aesop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99282050913275904",
    "text" : "No act of kindness, no matter how small, is ever wasted. -Aesop",
    "id" : 99282050913275904,
    "created_at" : "2011-08-05 00:54:20 +0000",
    "user" : {
      "name" : "Faith Reel",
      "screen_name" : "FaithReeI",
      "protected" : false,
      "id_str" : "129900508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471264535379054592\/2FTFLX_R_normal.jpeg",
      "id" : 129900508,
      "verified" : false
    }
  },
  "id" : 103610045840891904,
  "created_at" : "2011-08-16 23:32:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Beth Nelson",
      "screen_name" : "northernmagic",
      "indices" : [ 0, 14 ],
      "id_str" : "2556861443",
      "id" : 2556861443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103564509653909504",
  "text" : "@NorthernMagic what about under your rear?",
  "id" : 103564509653909504,
  "created_at" : "2011-08-16 20:31:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 0, 13 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103558690300370944",
  "geo" : { },
  "id_str" : "103559030059962368",
  "in_reply_to_user_id" : 42974138,
  "text" : "@GraveStomper ahh, what a wonderful word! love it!",
  "id" : 103559030059962368,
  "in_reply_to_status_id" : 103558690300370944,
  "created_at" : "2011-08-16 20:09:31 +0000",
  "in_reply_to_screen_name" : "GraveStomper",
  "in_reply_to_user_id_str" : "42974138",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "burdr",
      "screen_name" : "burdr",
      "indices" : [ 3, 9 ],
      "id_str" : "18826472",
      "id" : 18826472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "birding",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "photography",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103549765081505794",
  "text" : "RT @burdr: Tumblr Tuesday: Cuddle http:\/\/ow.ly\/64LTv #birds #birding #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 42, 48 ]
      }, {
        "text" : "birding",
        "indices" : [ 49, 57 ]
      }, {
        "text" : "photography",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103548291794485249",
    "text" : "Tumblr Tuesday: Cuddle http:\/\/ow.ly\/64LTv #birds #birding #photography",
    "id" : 103548291794485249,
    "created_at" : "2011-08-16 19:26:51 +0000",
    "user" : {
      "name" : "burdr",
      "screen_name" : "burdr",
      "protected" : false,
      "id_str" : "18826472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1349213818\/IMG_0448_normal.jpg",
      "id" : 18826472,
      "verified" : false
    }
  },
  "id" : 103549765081505794,
  "created_at" : "2011-08-16 19:32:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103546249789177856",
  "text" : "RT @CaroleODell: Read this for motivation oh WHY you must get your biz off ALL 3rd party sites and OWN it yourself. http:\/\/ow.ly\/64L4f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103545013031538688",
    "text" : "Read this for motivation oh WHY you must get your biz off ALL 3rd party sites and OWN it yourself. http:\/\/ow.ly\/64L4f",
    "id" : 103545013031538688,
    "created_at" : "2011-08-16 19:13:49 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 103546249789177856,
  "created_at" : "2011-08-16 19:18:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103506405222391808",
  "text" : "Yes, I do have something to prove.. to myself. and I won't be truly happy until I do. Therefore, I'll never be truly happy.",
  "id" : 103506405222391808,
  "created_at" : "2011-08-16 16:40:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atira Zeoli",
      "screen_name" : "zeoligirl",
      "indices" : [ 3, 13 ],
      "id_str" : "15005170",
      "id" : 15005170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WTF",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/4Ka821T",
      "expanded_url" : "http:\/\/bit.ly\/p12dTo",
      "display_url" : "bit.ly\/p12dTo"
    } ]
  },
  "geo" : { },
  "id_str" : "103504842235977728",
  "text" : "RT @zeoligirl: #WTF This guy lets parrots nest in walls, starve, DIE & they're gonna let him KEEP the birds? http:\/\/t.co\/4Ka821T #TroyPa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WTF",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "TroyParrots",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "AniPals",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 113 ],
        "url" : "http:\/\/t.co\/4Ka821T",
        "expanded_url" : "http:\/\/bit.ly\/p12dTo",
        "display_url" : "bit.ly\/p12dTo"
      } ]
    },
    "geo" : { },
    "id_str" : "103504486970036225",
    "text" : "#WTF This guy lets parrots nest in walls, starve, DIE & they're gonna let him KEEP the birds? http:\/\/t.co\/4Ka821T #TroyParrots #AniPals",
    "id" : 103504486970036225,
    "created_at" : "2011-08-16 16:32:47 +0000",
    "user" : {
      "name" : "Atira Zeoli",
      "screen_name" : "zeoligirl",
      "protected" : false,
      "id_str" : "15005170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633985786\/twitterProfilePhoto_normal.jpg",
      "id" : 15005170,
      "verified" : false
    }
  },
  "id" : 103504842235977728,
  "created_at" : "2011-08-16 16:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103504752356245504",
  "text" : "have several sites I just cant get right.. sigh",
  "id" : 103504752356245504,
  "created_at" : "2011-08-16 16:33:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 13, 21 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103504389347614721",
  "text" : "I must be in @twitter 's witness protection program.. keep changing my location.. LOL (I amuse myself so!!)",
  "id" : 103504389347614721,
  "created_at" : "2011-08-16 16:32:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farm Sanctuary",
      "screen_name" : "FarmSanctuary",
      "indices" : [ 3, 17 ],
      "id_str" : "16908562",
      "id" : 16908562
    }, {
      "name" : "NPR",
      "screen_name" : "nprnews",
      "indices" : [ 23, 31 ],
      "id_str" : "3386439610",
      "id" : 3386439610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/wSaMXdh",
      "expanded_url" : "http:\/\/n.pr\/mYrK7V",
      "display_url" : "n.pr\/mYrK7V"
    } ]
  },
  "geo" : { },
  "id_str" : "103286838944464896",
  "text" : "RT @FarmSanctuary: Via @nprnews: Yvonne, A Cow Wrapped In A Mystery Inside A Forest | http:\/\/t.co\/wSaMXdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NPR",
        "screen_name" : "nprnews",
        "indices" : [ 4, 12 ],
        "id_str" : "3386439610",
        "id" : 3386439610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 86 ],
        "url" : "http:\/\/t.co\/wSaMXdh",
        "expanded_url" : "http:\/\/n.pr\/mYrK7V",
        "display_url" : "n.pr\/mYrK7V"
      } ]
    },
    "geo" : { },
    "id_str" : "103283674002370560",
    "text" : "Via @nprnews: Yvonne, A Cow Wrapped In A Mystery Inside A Forest | http:\/\/t.co\/wSaMXdh",
    "id" : 103283674002370560,
    "created_at" : "2011-08-16 01:55:21 +0000",
    "user" : {
      "name" : "Farm Sanctuary",
      "screen_name" : "FarmSanctuary",
      "protected" : false,
      "id_str" : "16908562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440957631226580992\/Pk-bFWfT_normal.jpeg",
      "id" : 16908562,
      "verified" : false
    }
  },
  "id" : 103286838944464896,
  "created_at" : "2011-08-16 02:07:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 3, 13 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103285414374293505",
  "text" : "RT @ScottBaio: IF I ever write a book, it will NOT be a tell all about women. It would be a book I'd want my daughter to read & be proud of.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103285083665997824",
    "text" : "IF I ever write a book, it will NOT be a tell all about women. It would be a book I'd want my daughter to read & be proud of.",
    "id" : 103285083665997824,
    "created_at" : "2011-08-16 02:00:57 +0000",
    "user" : {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "protected" : false,
      "id_str" : "82447359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742477919801335816\/O6okGPN6_normal.jpg",
      "id" : 82447359,
      "verified" : true
    }
  },
  "id" : 103285414374293505,
  "created_at" : "2011-08-16 02:02:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103275534787682305",
  "text" : "RT @DeepakChopra: Every person is a God in embryo. Its only desire is to be born.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103273880587735040",
    "text" : "Every person is a God in embryo. Its only desire is to be born.",
    "id" : 103273880587735040,
    "created_at" : "2011-08-16 01:16:26 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 103275534787682305,
  "created_at" : "2011-08-16 01:23:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "103258800844324864",
  "geo" : { },
  "id_str" : "103261299831615488",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell ((hugs)) breathe!",
  "id" : 103261299831615488,
  "in_reply_to_status_id" : 103258800844324864,
  "created_at" : "2011-08-16 00:26:27 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103258242041384960",
  "text" : "RT @SpiritualNurse: What we see depends mainly on what we look for. ~John Lubbock",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103257181679394816",
    "text" : "What we see depends mainly on what we look for. ~John Lubbock",
    "id" : 103257181679394816,
    "created_at" : "2011-08-16 00:10:05 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 103258242041384960,
  "created_at" : "2011-08-16 00:14:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103257596085010432",
  "text" : "RT @Buddhaworld: in spirituality is nothing to learn, but much to unlearn. Buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103245789018595328",
    "text" : "in spirituality is nothing to learn, but much to unlearn. Buddha volko.",
    "id" : 103245789018595328,
    "created_at" : "2011-08-15 23:24:48 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 103257596085010432,
  "created_at" : "2011-08-16 00:11:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103257330677854208",
  "text" : "RT @Buddhaworld: the world consists 100% of opinions.buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103248064063619072",
    "text" : "the world consists 100% of opinions.buddha volko.",
    "id" : 103248064063619072,
    "created_at" : "2011-08-15 23:33:51 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 103257330677854208,
  "created_at" : "2011-08-16 00:10:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103257093951324160",
  "text" : "RT @stevetheseeker: We are prisoners of the past until we see that the key to the open door is inside us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103252090050199553",
    "text" : "We are prisoners of the past until we see that the key to the open door is inside us.",
    "id" : 103252090050199553,
    "created_at" : "2011-08-15 23:49:51 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 103257093951324160,
  "created_at" : "2011-08-16 00:09:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103256870352977920",
  "text" : "RT @mimismutts: A day for kidney stones all from the middle east wars...Joey never went to the middle east but he did get the vaccines t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103253138454233088",
    "text" : "A day for kidney stones all from the middle east wars...Joey never went to the middle east but he did get the vaccines to go...coincidence??",
    "id" : 103253138454233088,
    "created_at" : "2011-08-15 23:54:01 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 103256870352977920,
  "created_at" : "2011-08-16 00:08:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103256858550214657",
  "text" : "RT @mimismutts: Here's something...my son has a kidney stone, both the VA in HI and the VA in TN are backed up with kidney stones...they ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103252509853876225",
    "text" : "Here's something...my son has a kidney stone, both the VA in HI and the VA in TN are backed up with kidney stones...they're treating 10 vets",
    "id" : 103252509853876225,
    "created_at" : "2011-08-15 23:51:31 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 103256858550214657,
  "created_at" : "2011-08-16 00:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 3, 17 ],
      "id_str" : "112762057",
      "id" : 112762057
    }, {
      "name" : "Reader's Digest",
      "screen_name" : "readersdigest",
      "indices" : [ 73, 87 ],
      "id_str" : "15592792",
      "id" : 15592792
    }, {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 106, 120 ],
      "id_str" : "112762057",
      "id" : 112762057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Giveaway",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103237825541058560",
  "text" : "RT @loveofreading: FSB #Giveaway for US\/CANADA: I USED TO KNOW THAT from @ReadersDigest ebooks. RT\/Follow @LoveOfReading today. http:\/\/o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reader's Digest",
        "screen_name" : "readersdigest",
        "indices" : [ 54, 68 ],
        "id_str" : "15592792",
        "id" : 15592792
      }, {
        "name" : "Love of Reading",
        "screen_name" : "loveofreading",
        "indices" : [ 87, 101 ],
        "id_str" : "112762057",
        "id" : 112762057
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Giveaway",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103235785205104640",
    "text" : "FSB #Giveaway for US\/CANADA: I USED TO KNOW THAT from @ReadersDigest ebooks. RT\/Follow @LoveOfReading today. http:\/\/ow.ly\/5XQC6",
    "id" : 103235785205104640,
    "created_at" : "2011-08-15 22:45:03 +0000",
    "user" : {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "protected" : false,
      "id_str" : "112762057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/807514027\/loricon2_normal.jpg",
      "id" : 112762057,
      "verified" : false
    }
  },
  "id" : 103237825541058560,
  "created_at" : "2011-08-15 22:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squirrelers",
      "screen_name" : "squirrelers",
      "indices" : [ 3, 15 ],
      "id_str" : "81271026",
      "id" : 81271026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/uofHtxw",
      "expanded_url" : "http:\/\/bit.ly\/qHRmwd",
      "display_url" : "bit.ly\/qHRmwd"
    } ]
  },
  "geo" : { },
  "id_str" : "103159133494185985",
  "text" : "RT @squirrelers: Squirrelers August Giveaway \u2013 $75 in Amazon Gift Cards http:\/\/t.co\/uofHtxw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 74 ],
        "url" : "http:\/\/t.co\/uofHtxw",
        "expanded_url" : "http:\/\/bit.ly\/qHRmwd",
        "display_url" : "bit.ly\/qHRmwd"
      } ]
    },
    "geo" : { },
    "id_str" : "103135820608843777",
    "text" : "Squirrelers August Giveaway \u2013 $75 in Amazon Gift Cards http:\/\/t.co\/uofHtxw",
    "id" : 103135820608843777,
    "created_at" : "2011-08-15 16:07:50 +0000",
    "user" : {
      "name" : "Squirrelers",
      "screen_name" : "squirrelers",
      "protected" : false,
      "id_str" : "81271026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000692289347\/713c68cde56c1159488f334a769708f8_normal.png",
      "id" : 81271026,
      "verified" : false
    }
  },
  "id" : 103159133494185985,
  "created_at" : "2011-08-15 17:40:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 13, 24 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TroyParrots",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103146556747825152",
  "text" : "RT @SangyeH: @moosebegab Would you please sign our petition to save the #TroyParrots? bit.ly\/nwPdSH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TroyParrots",
        "indices" : [ 59, 71 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "103143822854336512",
    "geo" : { },
    "id_str" : "103144368659111936",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab Would you please sign our petition to save the #TroyParrots? bit.ly\/nwPdSH",
    "id" : 103144368659111936,
    "in_reply_to_status_id" : 103143822854336512,
    "created_at" : "2011-08-15 16:41:48 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 103146556747825152,
  "created_at" : "2011-08-15 16:50:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 30, 38 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kthxbye",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103143822854336512",
  "text" : "Plz stop changing my location @twitter .. #kthxbye",
  "id" : 103143822854336512,
  "created_at" : "2011-08-15 16:39:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 93, 108 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "etsy",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/NKF7mEc",
      "expanded_url" : "http:\/\/bit.ly\/qecRGM",
      "display_url" : "bit.ly\/qecRGM"
    } ]
  },
  "geo" : { },
  "id_str" : "103143506746413057",
  "text" : "Crafty Biz ppl: Market Your Biz & Giveaways Weekly Blog Party  http:\/\/t.co\/NKF7mEc #etsy cc: @PeggySueCusses",
  "id" : 103143506746413057,
  "created_at" : "2011-08-15 16:38:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buddhist Quotes",
      "screen_name" : "BuddhaQuotes",
      "indices" : [ 3, 16 ],
      "id_str" : "89368633",
      "id" : 89368633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102909910450311168",
  "text" : "RT @BuddhaQuotes: The way is not in the sky. The way is in the heart.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102900443025387520",
    "text" : "The way is not in the sky. The way is in the heart.",
    "id" : 102900443025387520,
    "created_at" : "2011-08-15 00:32:32 +0000",
    "user" : {
      "name" : "Buddhist Quotes",
      "screen_name" : "BuddhaQuotes",
      "protected" : false,
      "id_str" : "89368633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577181798\/buddha-enlightenment_normal.jpg",
      "id" : 89368633,
      "verified" : false
    }
  },
  "id" : 102909910450311168,
  "created_at" : "2011-08-15 01:10:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102903966664376321",
  "text" : "RT @brandonrofl: \u201CIt is very sad to me that some people are so intent on leaving their mark on the world that they don\u2019t care if that ma ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102900491050156033",
    "text" : "\u201CIt is very sad to me that some people are so intent on leaving their mark on the world that they don\u2019t care if that mark is a scar.\u201D",
    "id" : 102900491050156033,
    "created_at" : "2011-08-15 00:32:43 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 102903966664376321,
  "created_at" : "2011-08-15 00:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/PauCAMa",
      "expanded_url" : "http:\/\/bit.ly\/nexOsc",
      "display_url" : "bit.ly\/nexOsc"
    } ]
  },
  "geo" : { },
  "id_str" : "102888607399936000",
  "text" : "RT @GaribaldiRous: Are you following my Capybara Photo-of-the-Day? http:\/\/t.co\/PauCAMa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 67 ],
        "url" : "http:\/\/t.co\/PauCAMa",
        "expanded_url" : "http:\/\/bit.ly\/nexOsc",
        "display_url" : "bit.ly\/nexOsc"
      } ]
    },
    "geo" : { },
    "id_str" : "102882557326135296",
    "text" : "Are you following my Capybara Photo-of-the-Day? http:\/\/t.co\/PauCAMa",
    "id" : 102882557326135296,
    "created_at" : "2011-08-14 23:21:27 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 102888607399936000,
  "created_at" : "2011-08-14 23:45:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102875716957372416",
  "geo" : { },
  "id_str" : "102877338156531712",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH aww ((hugs)) been off twitter then vacation. love my tweeps!",
  "id" : 102877338156531712,
  "in_reply_to_status_id" : 102875716957372416,
  "created_at" : "2011-08-14 23:00:43 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "irony",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102877017413926912",
  "text" : "RT @SangyeH: It takes big money to win a campaign in America, and then we complain that our candidates are owned by big money. #irony",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "irony",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102876651305713664",
    "text" : "It takes big money to win a campaign in America, and then we complain that our candidates are owned by big money. #irony",
    "id" : 102876651305713664,
    "created_at" : "2011-08-14 22:57:59 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 102877017413926912,
  "created_at" : "2011-08-14 22:59:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102873992033079296",
  "text" : "I love watching the pingpong of great minds in my stream. So blessed to have wonderful ppl to follow.",
  "id" : 102873992033079296,
  "created_at" : "2011-08-14 22:47:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102872967473672192",
  "text" : "RT @BeasBookNook: I'm looking for authors & bloggers to join in my blog's celebration of Banned Book Week. Email me at beasbooknook@gmai ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102872324486860801",
    "text" : "I'm looking for authors & bloggers to join in my blog's celebration of Banned Book Week. Email me at beasbooknook@gmail.com Please RT",
    "id" : 102872324486860801,
    "created_at" : "2011-08-14 22:40:48 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 102872967473672192,
  "created_at" : "2011-08-14 22:43:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102817358871150592",
  "geo" : { },
  "id_str" : "102825332297580545",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona and sick of ppl saying but money doesn't matter... bleh.",
  "id" : 102825332297580545,
  "in_reply_to_status_id" : 102817358871150592,
  "created_at" : "2011-08-14 19:34:04 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndOfStory",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "poem",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102825204153204737",
  "text" : "RT @CharlesBivona: I'm tired of being poor. # #EndOfStory #poem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EndOfStory",
        "indices" : [ 27, 38 ]
      }, {
        "text" : "poem",
        "indices" : [ 39, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102817358871150592",
    "text" : "I'm tired of being poor. # #EndOfStory #poem",
    "id" : 102817358871150592,
    "created_at" : "2011-08-14 19:02:23 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 102825204153204737,
  "created_at" : "2011-08-14 19:33:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102824706079588355",
  "text" : "RT @Buddhaworld: there is a cow running loose in a german forest since 3 month, everybody is trying to catch her, whats so bad about a f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102817734164873218",
    "text" : "there is a cow running loose in a german forest since 3 month, everybody is trying to catch her, whats so bad about a free cow?",
    "id" : 102817734164873218,
    "created_at" : "2011-08-14 19:03:52 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 102824706079588355,
  "created_at" : "2011-08-14 19:31:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DelightfullyDog.com",
      "screen_name" : "DelightfullyDog",
      "indices" : [ 3, 19 ],
      "id_str" : "235855676",
      "id" : 235855676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102824176020230144",
  "text" : "RT @DelightfullyDog: Go with me on my last journey. Dont say \"I can't bear to watch\" Everything is easier for me if you are there. ~ You ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102812548855894016",
    "text" : "Go with me on my last journey. Dont say \"I can't bear to watch\" Everything is easier for me if you are there. ~ Your Dog http:\/\/ow.ly\/62QwV",
    "id" : 102812548855894016,
    "created_at" : "2011-08-14 18:43:16 +0000",
    "user" : {
      "name" : "DelightfullyDog.com",
      "screen_name" : "DelightfullyDog",
      "protected" : false,
      "id_str" : "235855676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1539240851\/image_normal.jpg",
      "id" : 235855676,
      "verified" : false
    }
  },
  "id" : 102824176020230144,
  "created_at" : "2011-08-14 19:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102814832444702722",
  "text" : "RT @Buddhaworld: see it this way, if god created man, he better get used to him, and stop trying to patch up the mistakes.buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102812473253560321",
    "text" : "see it this way, if god created man, he better get used to him, and stop trying to patch up the mistakes.buddha volko.",
    "id" : 102812473253560321,
    "created_at" : "2011-08-14 18:42:58 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 102814832444702722,
  "created_at" : "2011-08-14 18:52:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/ogquW1r",
      "expanded_url" : "http:\/\/www.threadless.com\/slogans\/2363713",
      "display_url" : "threadless.com\/slogans\/2363713"
    } ]
  },
  "geo" : { },
  "id_str" : "102809572615520256",
  "text" : "RT @Wylieknowords: \"Gangs Happen When Families Don't.\"  please vote for my slogan:\nhttp:\/\/t.co\/ogquW1r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http:\/\/t.co\/ogquW1r",
        "expanded_url" : "http:\/\/www.threadless.com\/slogans\/2363713",
        "display_url" : "threadless.com\/slogans\/2363713"
      } ]
    },
    "geo" : { },
    "id_str" : "102807750823784449",
    "text" : "\"Gangs Happen When Families Don't.\"  please vote for my slogan:\nhttp:\/\/t.co\/ogquW1r",
    "id" : 102807750823784449,
    "created_at" : "2011-08-14 18:24:12 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 102809572615520256,
  "created_at" : "2011-08-14 18:31:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102476225179680770",
  "geo" : { },
  "id_str" : "102476836780507136",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise will you be selling said booklet? cabbage, eh?",
  "id" : 102476836780507136,
  "in_reply_to_status_id" : 102476225179680770,
  "created_at" : "2011-08-13 20:29:16 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/gxWoR3A",
      "expanded_url" : "http:\/\/johnshore.com\/2010\/12\/13\/the-real-reason-people-get-so-crazy-about-gays\/",
      "display_url" : "johnshore.com\/2010\/12\/13\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "102475106714005504",
  "text" : "The Real Reason Christians Get So Crazy About Gays: http:\/\/t.co\/gxWoR3A",
  "id" : 102475106714005504,
  "created_at" : "2011-08-13 20:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 16, 29 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102471770828849152",
  "geo" : { },
  "id_str" : "102472753415864320",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen @GraveStomper glad you reminded me of concept. dont try, BE. Corin wld say: dont try(dream), DO. \u2665 u both!",
  "id" : 102472753415864320,
  "in_reply_to_status_id" : 102471770828849152,
  "created_at" : "2011-08-13 20:13:02 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 16, 29 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102470737880825858",
  "geo" : { },
  "id_str" : "102471433711661056",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen @GraveStomper Martijn, we had this discussion about \"searching\", didn't we? always \"search\", never \"find\"",
  "id" : 102471433711661056,
  "in_reply_to_status_id" : 102470737880825858,
  "created_at" : "2011-08-13 20:07:48 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    }, {
      "name" : "Steve Ramirez",
      "screen_name" : "SteveRamirez",
      "indices" : [ 104, 117 ],
      "id_str" : "14642711",
      "id" : 14642711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102470944752283648",
  "text" : "RT @SpiritualNurse: Feeling good is what you should be doing every day of your life. \u2014 Wayne Dyer   via @SteveRamirez",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Ramirez",
        "screen_name" : "SteveRamirez",
        "indices" : [ 84, 97 ],
        "id_str" : "14642711",
        "id" : 14642711
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102470760639111168",
    "text" : "Feeling good is what you should be doing every day of your life. \u2014 Wayne Dyer   via @SteveRamirez",
    "id" : 102470760639111168,
    "created_at" : "2011-08-13 20:05:07 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 102470944752283648,
  "created_at" : "2011-08-13 20:05:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 20, 31 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102469772872130560",
  "text" : "RT @MartijnLinssen: @moosebegab The kingdom of god lies within you  - just realise all the questions come from outside, and the Answer w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "102466352480124928",
    "geo" : { },
    "id_str" : "102469367358427136",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab The kingdom of god lies within you  - just realise all the questions come from outside, and the Answer will manifest from Inside",
    "id" : 102469367358427136,
    "in_reply_to_status_id" : 102466352480124928,
    "created_at" : "2011-08-13 19:59:35 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 102469772872130560,
  "created_at" : "2011-08-13 20:01:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 62, 68 ]
    }, {
      "text" : "senryu",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102468672693608449",
  "text" : "RT @CoyoteSings: butterfly wings \u2022 slowly opening \u2022 my mind | #haiku #senryu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "senryu",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102468410797080576",
    "text" : "butterfly wings \u2022 slowly opening \u2022 my mind | #haiku #senryu",
    "id" : 102468410797080576,
    "created_at" : "2011-08-13 19:55:47 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 102468672693608449,
  "created_at" : "2011-08-13 19:56:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "quote",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102467483302248448",
  "text" : "RT @ebookfriendly: No two persons ever read the same book. \u2013Edmund Wilson #books #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 55, 61 ]
      }, {
        "text" : "quote",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102466964345200640",
    "text" : "No two persons ever read the same book. \u2013Edmund Wilson #books #quote",
    "id" : 102466964345200640,
    "created_at" : "2011-08-13 19:50:02 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 102467483302248448,
  "created_at" : "2011-08-13 19:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parand Darugar",
      "screen_name" : "parand",
      "indices" : [ 3, 10 ],
      "id_str" : "779137",
      "id" : 779137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102466672069324801",
  "text" : "RT @parand: \"There's no such thing as spending too much. There's only making too little.\" - My dad's (very successful) friend, years ago.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102462519666409472",
    "text" : "\"There's no such thing as spending too much. There's only making too little.\" - My dad's (very successful) friend, years ago.",
    "id" : 102462519666409472,
    "created_at" : "2011-08-13 19:32:23 +0000",
    "user" : {
      "name" : "Parand Darugar",
      "screen_name" : "parand",
      "protected" : false,
      "id_str" : "779137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532977508283461632\/qtla47Kq_normal.png",
      "id" : 779137,
      "verified" : false
    }
  },
  "id" : 102466672069324801,
  "created_at" : "2011-08-13 19:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102465778523181057",
  "geo" : { },
  "id_str" : "102466352480124928",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen each person says something that rings a bell. little by little the door widens.",
  "id" : 102466352480124928,
  "in_reply_to_status_id" : 102465778523181057,
  "created_at" : "2011-08-13 19:47:36 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102466029573255168",
  "text" : "you tweeps keep me on my toes.. you do, you do! muah!",
  "id" : 102466029573255168,
  "created_at" : "2011-08-13 19:46:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102461956220395521",
  "geo" : { },
  "id_str" : "102465465317736448",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen : )",
  "id" : 102465465317736448,
  "in_reply_to_status_id" : 102461956220395521,
  "created_at" : "2011-08-13 19:44:05 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102461393843924994",
  "text" : "RT @GraveStomper: To have traveled miles & realize you still know nothing is not accomplishment nor great wisdom: it's an indication you ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102461253481529344",
    "text" : "To have traveled miles & realize you still know nothing is not accomplishment nor great wisdom: it's an indication you need a better path.",
    "id" : 102461253481529344,
    "created_at" : "2011-08-13 19:27:21 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 102461393843924994,
  "created_at" : "2011-08-13 19:27:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    }, {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 90, 102 ],
      "id_str" : "5520952",
      "id" : 5520952
    }, {
      "name" : "ShireHakel",
      "screen_name" : "ShiCooks",
      "indices" : [ 111, 120 ],
      "id_str" : "16476911",
      "id" : 16476911
    }, {
      "name" : "Matthew Fry",
      "screen_name" : "lovepeaceunity",
      "indices" : [ 122, 137 ],
      "id_str" : "23939797",
      "id" : 23939797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 107, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102437875131490304",
  "text" : "RT @SpiritualNurse: And my angel has said: \"Start moving so that I may start blessing.\" \u2014 @paulocoelho ||  #FF @ShiCooks  @lovepeaceunity \u2661",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paulo Coelho",
        "screen_name" : "paulocoelho",
        "indices" : [ 70, 82 ],
        "id_str" : "5520952",
        "id" : 5520952
      }, {
        "name" : "ShireHakel",
        "screen_name" : "ShiCooks",
        "indices" : [ 91, 100 ],
        "id_str" : "16476911",
        "id" : 16476911
      }, {
        "name" : "Matthew Fry",
        "screen_name" : "lovepeaceunity",
        "indices" : [ 102, 117 ],
        "id_str" : "23939797",
        "id" : 23939797
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 87, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102433247602016256",
    "text" : "And my angel has said: \"Start moving so that I may start blessing.\" \u2014 @paulocoelho ||  #FF @ShiCooks  @lovepeaceunity \u2661",
    "id" : 102433247602016256,
    "created_at" : "2011-08-13 17:36:04 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 102437875131490304,
  "created_at" : "2011-08-13 17:54:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102097979963490305",
  "text" : "good news! my bro is in rehab! I hope this is a new beginning for him!",
  "id" : 102097979963490305,
  "created_at" : "2011-08-12 19:23:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102081671444168704",
  "text" : "bleh. not feeling well. bladder infection and low grade fever. stomach slightly off.",
  "id" : 102081671444168704,
  "created_at" : "2011-08-12 18:19:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 28, 35 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102007024119857153",
  "text" : "RT @gemswinc: Luna Moth via @screek http:\/\/bit.ly\/pyX9Fx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 14, 21 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102006394361888770",
    "text" : "Luna Moth via @screek http:\/\/bit.ly\/pyX9Fx",
    "id" : 102006394361888770,
    "created_at" : "2011-08-12 13:19:54 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 102007024119857153,
  "created_at" : "2011-08-12 13:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/pn42rpl",
      "expanded_url" : "http:\/\/www.threadless.com\/slogans\/2388718",
      "display_url" : "threadless.com\/slogans\/2388718"
    } ]
  },
  "geo" : { },
  "id_str" : "101765529475358721",
  "text" : "RT @Wylieknowords: \"Forgiveness--A Gift You Get When You Give It.\" please vote for my slogan.\nhttp:\/\/t.co\/pn42rpl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 94 ],
        "url" : "http:\/\/t.co\/pn42rpl",
        "expanded_url" : "http:\/\/www.threadless.com\/slogans\/2388718",
        "display_url" : "threadless.com\/slogans\/2388718"
      } ]
    },
    "geo" : { },
    "id_str" : "101765209441574912",
    "text" : "\"Forgiveness--A Gift You Get When You Give It.\" please vote for my slogan.\nhttp:\/\/t.co\/pn42rpl",
    "id" : 101765209441574912,
    "created_at" : "2011-08-11 21:21:31 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 101765529475358721,
  "created_at" : "2011-08-11 21:22:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101743138221203457",
  "geo" : { },
  "id_str" : "101744159538417664",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench yup. same here.",
  "id" : 101744159538417664,
  "in_reply_to_status_id" : 101743138221203457,
  "created_at" : "2011-08-11 19:57:52 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101743602941702144",
  "geo" : { },
  "id_str" : "101743951089909763",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC LOL (at yr comment but not yr headache)",
  "id" : 101743951089909763,
  "in_reply_to_status_id" : 101743602941702144,
  "created_at" : "2011-08-11 19:57:02 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/1Sdt2fX",
      "expanded_url" : "http:\/\/www.collegehumor.com\/video\/6582695",
      "display_url" : "collegehumor.com\/video\/6582695"
    } ]
  },
  "geo" : { },
  "id_str" : "101685444718247936",
  "text" : "Watching John Stamos' Guide To Cuddling on CollegeHumor http:\/\/t.co\/1Sdt2fX",
  "id" : 101685444718247936,
  "created_at" : "2011-08-11 16:04:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101467765931651072",
  "text" : "@tragic_pizza back at ya! ((hugs))",
  "id" : 101467765931651072,
  "created_at" : "2011-08-11 01:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101465172836753408",
  "geo" : { },
  "id_str" : "101467528613736449",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad I highly disagree w whomever said that. That makes me angry. ((hugs))",
  "id" : 101467528613736449,
  "in_reply_to_status_id" : 101465172836753408,
  "created_at" : "2011-08-11 01:38:38 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101462422073778177",
  "text" : "RT @sparklekaz: Everyone is on a spiritual path; most people just don't know it.        Marianne Williamson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101461331303075840",
    "text" : "Everyone is on a spiritual path; most people just don't know it.        Marianne Williamson",
    "id" : 101461331303075840,
    "created_at" : "2011-08-11 01:14:01 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 101462422073778177,
  "created_at" : "2011-08-11 01:18:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101462407641178112",
  "text" : "RT @oshum: Make friends with the Dark.... and the Light will shine even brighter for you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101461305180962816",
    "text" : "Make friends with the Dark.... and the Light will shine even brighter for you.",
    "id" : 101461305180962816,
    "created_at" : "2011-08-11 01:13:54 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 101462407641178112,
  "created_at" : "2011-08-11 01:18:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101458601603903488",
  "text" : "RT @oshum: On the metaphysical plane...a struggle between energies of Fear and energies of Love is taking place...which side do you cont ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101457960391290882",
    "text" : "On the metaphysical plane...a struggle between energies of Fear and energies of Love is taking place...which side do you contribute to?",
    "id" : 101457960391290882,
    "created_at" : "2011-08-11 01:00:37 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 101458601603903488,
  "created_at" : "2011-08-11 01:03:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101390966149230592",
  "geo" : { },
  "id_str" : "101392604331114496",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver not sure I understand... what label?",
  "id" : 101392604331114496,
  "in_reply_to_status_id" : 101390966149230592,
  "created_at" : "2011-08-10 20:40:55 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/DmV79d1",
      "expanded_url" : "http:\/\/thefrugalereader.com\/2011\/08\/10\/anniversary-celebration-a-gift-a-day-day-10-psst-this-includes-the-50-egift-card-giveaway\/#.TkLU7z7vyZ8.twitter",
      "display_url" : "thefrugalereader.com\/2011\/08\/10\/ann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101367529229918210",
  "text" : "Anniversary Celebration: A Gift A Day \u007BDay #10!\u007D \u007BPsst\u2026 This Includes the $50 eGift Card Giveaway!\u007D : http:\/\/t.co\/DmV79d1",
  "id" : 101367529229918210,
  "created_at" : "2011-08-10 19:01:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopthehate",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101352519564935168",
  "text" : "If you're human and hatin' on the human race... WTF?? You're hatin' on yourself!! #stopthehate",
  "id" : 101352519564935168,
  "created_at" : "2011-08-10 18:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kari",
      "screen_name" : "WiltingSoul",
      "indices" : [ 0, 12 ],
      "id_str" : "24330014",
      "id" : 24330014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "101100543803523072",
  "geo" : { },
  "id_str" : "101101309956071424",
  "in_reply_to_user_id" : 24330014,
  "text" : "@WiltingSoul I just figured out you are..hehe. The avatar w ripped shirt.",
  "id" : 101101309956071424,
  "in_reply_to_status_id" : 101100543803523072,
  "created_at" : "2011-08-10 01:23:25 +0000",
  "in_reply_to_screen_name" : "WiltingSoul",
  "in_reply_to_user_id_str" : "24330014",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 3, 13 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100686404018896897",
  "text" : "RT @RuffHaven: We have room for another dog...old and\/or special needs only.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100686102637195264",
    "text" : "We have room for another dog...old and\/or special needs only.",
    "id" : 100686102637195264,
    "created_at" : "2011-08-08 21:53:32 +0000",
    "user" : {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "protected" : false,
      "id_str" : "126764612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459086546319056896\/W1rXvAEz_normal.jpeg",
      "id" : 126764612,
      "verified" : false
    }
  },
  "id" : 100686404018896897,
  "created_at" : "2011-08-08 21:54:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100684974566539264",
  "text" : "RT @neardeathdoc: Why I AM reading End of Suffering: \"A principal healing aid available to everyone is forgiveness. We free ourselves.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100684534336585728",
    "text" : "Why I AM reading End of Suffering: \"A principal healing aid available to everyone is forgiveness. We free ourselves.\"",
    "id" : 100684534336585728,
    "created_at" : "2011-08-08 21:47:18 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 100684974566539264,
  "created_at" : "2011-08-08 21:49:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100617939677491200",
  "text" : "RT @Matth3ous: Sonic screw driver app: $.99. River Song 'Hello, Sweetie' ringtone: free. Having someone who 'gets' the references: price ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100614503804309505",
    "text" : "Sonic screw driver app: $.99. River Song 'Hello, Sweetie' ringtone: free. Having someone who 'gets' the references: priceless. #DoctorWho",
    "id" : 100614503804309505,
    "created_at" : "2011-08-08 17:09:01 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 100617939677491200,
  "created_at" : "2011-08-08 17:22:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gifts of Debbie Ford",
      "screen_name" : "Debbie_Ford",
      "indices" : [ 3, 15 ],
      "id_str" : "22986272",
      "id" : 22986272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100617674404540416",
  "text" : "RT @Debbie_Ford: Blaming has become the disease of our time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.debbieford.com\" rel=\"nofollow\"\u003EDebbie Ford\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100537334822486016",
    "text" : "Blaming has become the disease of our time.",
    "id" : 100537334822486016,
    "created_at" : "2011-08-08 12:02:23 +0000",
    "user" : {
      "name" : "Gifts of Debbie Ford",
      "screen_name" : "Debbie_Ford",
      "protected" : false,
      "id_str" : "22986272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2264955587\/ivhllk9xsf4uqm487sw6_normal.jpeg",
      "id" : 22986272,
      "verified" : true
    }
  },
  "id" : 100617674404540416,
  "created_at" : "2011-08-08 17:21:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100591519144214530",
  "text" : "RT @CaroleODell: Scar tissue is stronger than regular tissue. Realize the strength, move on",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100588184047587329",
    "text" : "Scar tissue is stronger than regular tissue. Realize the strength, move on",
    "id" : 100588184047587329,
    "created_at" : "2011-08-08 15:24:26 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 100591519144214530,
  "created_at" : "2011-08-08 15:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100564085757845504",
  "text" : "When I feel insignificant, I feel significant.",
  "id" : 100564085757845504,
  "created_at" : "2011-08-08 13:48:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 3, 18 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100563732807163904",
  "text" : "RT @VeryShortStory: I woke to a pack of wolves in the kitchen, howling at the fridge. I fed them frozen waffles and one by one they turn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100560362973306880",
    "text" : "I woke to a pack of wolves in the kitchen, howling at the fridge. I fed them frozen waffles and one by one they turned back into my children",
    "id" : 100560362973306880,
    "created_at" : "2011-08-08 13:33:53 +0000",
    "user" : {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "protected" : false,
      "id_str" : "31986700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/141070636\/42291_normal.jpg",
      "id" : 31986700,
      "verified" : false
    }
  },
  "id" : 100563732807163904,
  "created_at" : "2011-08-08 13:47:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/216eTWG",
      "expanded_url" : "http:\/\/bit.ly\/owUSlI",
      "display_url" : "bit.ly\/owUSlI"
    } ]
  },
  "geo" : { },
  "id_str" : "100563561083977728",
  "text" : "RT @hauntedcomputer: Bookstore guilt: Not Interested: http:\/\/t.co\/216eTWG tired of defending your digital preference?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 52 ],
        "url" : "http:\/\/t.co\/216eTWG",
        "expanded_url" : "http:\/\/bit.ly\/owUSlI",
        "display_url" : "bit.ly\/owUSlI"
      } ]
    },
    "geo" : { },
    "id_str" : "100560974964207618",
    "text" : "Bookstore guilt: Not Interested: http:\/\/t.co\/216eTWG tired of defending your digital preference?",
    "id" : 100560974964207618,
    "created_at" : "2011-08-08 13:36:19 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 100563561083977728,
  "created_at" : "2011-08-08 13:46:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "100560993582710785",
  "geo" : { },
  "id_str" : "100562929660866560",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts me, too!",
  "id" : 100562929660866560,
  "in_reply_to_status_id" : 100560993582710785,
  "created_at" : "2011-08-08 13:44:05 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Useless Knowledge",
      "screen_name" : "uselessknowledg",
      "indices" : [ 3, 19 ],
      "id_str" : "37670469",
      "id" : 37670469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100560671304986625",
  "text" : "RT @uselessknowledg: All polar bears are left handed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetfaucet.com\" rel=\"nofollow\"\u003ETweet Faucet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100551847160463361",
    "text" : "All polar bears are left handed",
    "id" : 100551847160463361,
    "created_at" : "2011-08-08 13:00:03 +0000",
    "user" : {
      "name" : "Useless Knowledge",
      "screen_name" : "uselessknowledg",
      "protected" : false,
      "id_str" : "37670469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530985607\/ParkBench_normal.jpg",
      "id" : 37670469,
      "verified" : false
    }
  },
  "id" : 100560671304986625,
  "created_at" : "2011-08-08 13:35:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98879808741715968",
  "geo" : { },
  "id_str" : "100363321097723904",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books I was away all week.. haven't seen babies again, just mom a few times before we went away.",
  "id" : 100363321097723904,
  "in_reply_to_status_id" : 98879808741715968,
  "created_at" : "2011-08-08 00:30:55 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100304809684516864",
  "text" : "home again, home again. love the adirondacks. played lots of mini golf..lol",
  "id" : 100304809684516864,
  "created_at" : "2011-08-07 20:38:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]