Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/whSrusnc",
      "expanded_url" : "http:\/\/youtu.be\/H6b70TUbdfs",
      "display_url" : "youtu.be\/H6b70TUbdfs"
    } ]
  },
  "geo" : { },
  "id_str" : "274686786960240640",
  "text" : "an american govt parable TheTinyDot: http:\/\/t.co\/whSrusnc",
  "id" : 274686786960240640,
  "created_at" : "2012-12-01 01:30:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin",
      "screen_name" : "mrscapra",
      "indices" : [ 0, 9 ],
      "id_str" : "1969965566",
      "id" : 1969965566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274663152287899649",
  "text" : "@mrscapra you're cute! : )",
  "id" : 274663152287899649,
  "created_at" : "2012-11-30 23:56:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victoria Dahl",
      "screen_name" : "VictoriaDahl",
      "indices" : [ 3, 16 ],
      "id_str" : "15567729",
      "id" : 15567729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/r9nVCibS",
      "expanded_url" : "http:\/\/tmblr.co\/ZPJLhxYMrwLR",
      "display_url" : "tmblr.co\/ZPJLhxYMrwLR"
    } ]
  },
  "geo" : { },
  "id_str" : "274650380644802561",
  "text" : "RT @VictoriaDahl: The One Where Victoria Gets Super Personal and Super Pissed About Birth Control: http:\/\/t.co\/r9nVCibS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/r9nVCibS",
        "expanded_url" : "http:\/\/tmblr.co\/ZPJLhxYMrwLR",
        "display_url" : "tmblr.co\/ZPJLhxYMrwLR"
      } ]
    },
    "geo" : { },
    "id_str" : "274634635391143936",
    "text" : "The One Where Victoria Gets Super Personal and Super Pissed About Birth Control: http:\/\/t.co\/r9nVCibS",
    "id" : 274634635391143936,
    "created_at" : "2012-11-30 22:02:54 +0000",
    "user" : {
      "name" : "Victoria Dahl",
      "screen_name" : "VictoriaDahl",
      "protected" : false,
      "id_str" : "15567729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683011644994105344\/bZGzbphS_normal.jpg",
      "id" : 15567729,
      "verified" : false
    }
  },
  "id" : 274650380644802561,
  "created_at" : "2012-11-30 23:05:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274647049822171136",
  "geo" : { },
  "id_str" : "274648368494559233",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep the word \"entitled\" pops up in my head..lol",
  "id" : 274648368494559233,
  "in_reply_to_status_id" : 274647049822171136,
  "created_at" : "2012-11-30 22:57:28 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/2uUSJzVZ",
      "expanded_url" : "http:\/\/amzn.to\/KpZZQ2",
      "display_url" : "amzn.to\/KpZZQ2"
    } ]
  },
  "geo" : { },
  "id_str" : "274646963021033472",
  "text" : "RT @TimGreaton: \"Under-Heaven\" isn't a book for the faint of heart...but the emotional journey will change your heart. http:\/\/t.co\/2uUSJzVZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/2uUSJzVZ",
        "expanded_url" : "http:\/\/amzn.to\/KpZZQ2",
        "display_url" : "amzn.to\/KpZZQ2"
      } ]
    },
    "geo" : { },
    "id_str" : "274637588504141824",
    "text" : "\"Under-Heaven\" isn't a book for the faint of heart...but the emotional journey will change your heart. http:\/\/t.co\/2uUSJzVZ",
    "id" : 274637588504141824,
    "created_at" : "2012-11-30 22:14:38 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 274646963021033472,
  "created_at" : "2012-11-30 22:51:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274622495280230400",
  "text" : "@Skeptical_Lady yup...",
  "id" : 274622495280230400,
  "created_at" : "2012-11-30 21:14:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274614567433293824",
  "text" : "RT @Silvercrone: Decadent Sipping: Egg Nog with Kahlua ....oh my yes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274612236868284416",
    "text" : "Decadent Sipping: Egg Nog with Kahlua ....oh my yes.",
    "id" : 274612236868284416,
    "created_at" : "2012-11-30 20:33:53 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 274614567433293824,
  "created_at" : "2012-11-30 20:43:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274604518816239616",
  "geo" : { },
  "id_str" : "274605909458690048",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog im on gmail: abfabgab",
  "id" : 274605909458690048,
  "in_reply_to_status_id" : 274604518816239616,
  "created_at" : "2012-11-30 20:08:45 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274534414359347200",
  "geo" : { },
  "id_str" : "274601966838099968",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny aww.. does this mean you like me? ; ) lol",
  "id" : 274601966838099968,
  "in_reply_to_status_id" : 274534414359347200,
  "created_at" : "2012-11-30 19:53:05 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 12, 25 ],
      "id_str" : "361815486",
      "id" : 361815486
    }, {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 26, 42 ],
      "id_str" : "111579405",
      "id" : 111579405
    }, {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 43, 52 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 53, 64 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 65, 77 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 78, 92 ],
      "id_str" : "236401429",
      "id" : 236401429
    }, {
      "name" : "Inspired Kathy",
      "screen_name" : "toobusyreading",
      "indices" : [ 93, 108 ],
      "id_str" : "163219408",
      "id" : 163219408
    }, {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 109, 122 ],
      "id_str" : "47618028",
      "id" : 47618028
    }, {
      "name" : "DarkFuse",
      "screen_name" : "darkfuse",
      "indices" : [ 123, 132 ],
      "id_str" : "67377922",
      "id" : 67377922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 8, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274586855092133889",
  "text" : "bookish #FF @bookwiseblog @thDigitalReader @iLivrada @TyrusBooks @DuttonBooks @ebookfriendly @toobusyreading @BeasBookNook @darkfuse",
  "id" : 274586855092133889,
  "created_at" : "2012-11-30 18:53:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "indices" : [ 3, 8 ],
      "id_str" : "18957524",
      "id" : 18957524
    }, {
      "name" : "DVICE",
      "screen_name" : "dvice",
      "indices" : [ 25, 31 ],
      "id_str" : "16002751",
      "id" : 16002751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/7S3olDL6",
      "expanded_url" : "http:\/\/bit.ly\/VbomTE",
      "display_url" : "bit.ly\/VbomTE"
    } ]
  },
  "geo" : { },
  "id_str" : "274571834517766144",
  "text" : "RT @Syfy: It's begun! RT @dvice\nMIT develops miniature shape-shifting robots http:\/\/t.co\/7S3olDL6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DVICE",
        "screen_name" : "dvice",
        "indices" : [ 15, 21 ],
        "id_str" : "16002751",
        "id" : 16002751
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/7S3olDL6",
        "expanded_url" : "http:\/\/bit.ly\/VbomTE",
        "display_url" : "bit.ly\/VbomTE"
      } ]
    },
    "geo" : { },
    "id_str" : "274570479744999424",
    "text" : "It's begun! RT @dvice\nMIT develops miniature shape-shifting robots http:\/\/t.co\/7S3olDL6",
    "id" : 274570479744999424,
    "created_at" : "2012-11-30 17:47:58 +0000",
    "user" : {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "protected" : false,
      "id_str" : "18957524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793455496611172352\/4ntFcBSF_normal.jpg",
      "id" : 18957524,
      "verified" : true
    }
  },
  "id" : 274571834517766144,
  "created_at" : "2012-11-30 17:53:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/eisvek5L",
      "expanded_url" : "http:\/\/www.facebook.com\/photo.php?v=10151247520933901",
      "display_url" : "facebook.com\/photo.php?v=10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274571625582710785",
  "text" : "A deaf-mute girl on a horse that she has ridden for only 3 weeks http:\/\/t.co\/eisvek5L",
  "id" : 274571625582710785,
  "created_at" : "2012-11-30 17:52:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Will Ferrell",
      "screen_name" : "itsWillyFerrell",
      "indices" : [ 3, 19 ],
      "id_str" : "306025835",
      "id" : 306025835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274552145477525504",
  "text" : "RT @itsWillyFerrell: Always be positive. \n*Trips down the stairs* \n\"Wow... I got down those stairs really fast!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274540794243870720",
    "text" : "Always be positive. \n*Trips down the stairs* \n\"Wow... I got down those stairs really fast!\"",
    "id" : 274540794243870720,
    "created_at" : "2012-11-30 15:50:00 +0000",
    "user" : {
      "name" : "Not Will Ferrell",
      "screen_name" : "itsWillyFerrell",
      "protected" : false,
      "id_str" : "306025835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1990249248\/image_normal.jpg",
      "id" : 306025835,
      "verified" : false
    }
  },
  "id" : 274552145477525504,
  "created_at" : "2012-11-30 16:35:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WOW Facts Of Life",
      "screen_name" : "WOWFactsOfLife",
      "indices" : [ 3, 18 ],
      "id_str" : "379961664",
      "id" : 379961664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274274633203716097",
  "text" : "RT @WOWFactsOfLife: If you're having a bad day, just remember, in 1976 Ronald Wayne sold his 10% stake in Apple for $800. Now it's worth ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274274288083800064",
    "text" : "If you're having a bad day, just remember, in 1976 Ronald Wayne sold his 10% stake in Apple for $800. Now it's worth $58,065,210,000.",
    "id" : 274274288083800064,
    "created_at" : "2012-11-29 22:11:00 +0000",
    "user" : {
      "name" : "WOW Facts Of Life",
      "screen_name" : "WOWFactsOfLife",
      "protected" : false,
      "id_str" : "379961664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2247328785\/brain-technology_normal.jpg",
      "id" : 379961664,
      "verified" : false
    }
  },
  "id" : 274274633203716097,
  "created_at" : "2012-11-29 22:12:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/EYzHxTzo",
      "expanded_url" : "http:\/\/youtu.be\/UsJf9NwTFhw",
      "display_url" : "youtu.be\/UsJf9NwTFhw"
    } ]
  },
  "geo" : { },
  "id_str" : "274271457817788416",
  "text" : "What is your dog thinking? Brain scans give glimpse: http:\/\/t.co\/EYzHxTzo via @youtube",
  "id" : 274271457817788416,
  "created_at" : "2012-11-29 21:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/fu1lANuh",
      "expanded_url" : "http:\/\/amzn.to\/p1GFZV",
      "display_url" : "amzn.to\/p1GFZV"
    } ]
  },
  "geo" : { },
  "id_str" : "274266889910378496",
  "text" : "finished Under-Heaven by Tim Greaton http:\/\/t.co\/fu1lANuh",
  "id" : 274266889910378496,
  "created_at" : "2012-11-29 21:41:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274262046823043072",
  "geo" : { },
  "id_str" : "274263293814775808",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses OMG.. lol.. me, too. im very introverted and terrible at small talk..lol.",
  "id" : 274263293814775808,
  "in_reply_to_status_id" : 274262046823043072,
  "created_at" : "2012-11-29 21:27:19 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "indices" : [ 3, 15 ],
      "id_str" : "25090088",
      "id" : 25090088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/THB0nvac",
      "expanded_url" : "http:\/\/fb.me\/MPZ7PBab",
      "display_url" : "fb.me\/MPZ7PBab"
    } ]
  },
  "geo" : { },
  "id_str" : "274234714473238528",
  "text" : "RT @BenMWallace: Looks like planned to nuke the moon at one point in the 50's. http:\/\/t.co\/THB0nvac",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/THB0nvac",
        "expanded_url" : "http:\/\/fb.me\/MPZ7PBab",
        "display_url" : "fb.me\/MPZ7PBab"
      } ]
    },
    "geo" : { },
    "id_str" : "274229250486329344",
    "text" : "Looks like planned to nuke the moon at one point in the 50's. http:\/\/t.co\/THB0nvac",
    "id" : 274229250486329344,
    "created_at" : "2012-11-29 19:12:02 +0000",
    "user" : {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "protected" : false,
      "id_str" : "25090088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560492072914796544\/pPK5ZIrh_normal.png",
      "id" : 25090088,
      "verified" : false
    }
  },
  "id" : 274234714473238528,
  "created_at" : "2012-11-29 19:33:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274205772932579329",
  "text" : "my kindle seems better now.. had 2 items after the archived (last page.) i deleted those and now the normal speed has returned!",
  "id" : 274205772932579329,
  "created_at" : "2012-11-29 17:38:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judy",
      "screen_name" : "jpglavenvalley",
      "indices" : [ 3, 18 ],
      "id_str" : "40329122",
      "id" : 40329122
    }, {
      "name" : "Bev",
      "screen_name" : "Justbirds1",
      "indices" : [ 23, 34 ],
      "id_str" : "291680688",
      "id" : 291680688
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "photography",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/xQfETHs0",
      "expanded_url" : "http:\/\/goo.gl\/OSX7m",
      "display_url" : "goo.gl\/OSX7m"
    } ]
  },
  "geo" : { },
  "id_str" : "274183659312009216",
  "text" : "RT @jpglavenvalley: RT @Justbirds1: Black Swan Preening http:\/\/t.co\/xQfETHs0 #birds #photography:] remember seeing Black  Swan ...Swan R ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bev",
        "screen_name" : "Justbirds1",
        "indices" : [ 3, 14 ],
        "id_str" : "291680688",
        "id" : 291680688
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "photography",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/xQfETHs0",
        "expanded_url" : "http:\/\/goo.gl\/OSX7m",
        "display_url" : "goo.gl\/OSX7m"
      } ]
    },
    "geo" : { },
    "id_str" : "274176227537985536",
    "text" : "RT @Justbirds1: Black Swan Preening http:\/\/t.co\/xQfETHs0 #birds #photography:] remember seeing Black  Swan ...Swan River Perth",
    "id" : 274176227537985536,
    "created_at" : "2012-11-29 15:41:21 +0000",
    "user" : {
      "name" : "Judy",
      "screen_name" : "jpglavenvalley",
      "protected" : false,
      "id_str" : "40329122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723997052288512000\/chpNxq0W_normal.jpg",
      "id" : 40329122,
      "verified" : false
    }
  },
  "id" : 274183659312009216,
  "created_at" : "2012-11-29 16:10:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273927672030191616",
  "text" : "RT @DeepakChopra: Rewire your brain for higher consciousness by paying attention to love, compassion, and joy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273927038002425856",
    "text" : "Rewire your brain for higher consciousness by paying attention to love, compassion, and joy.",
    "id" : 273927038002425856,
    "created_at" : "2012-11-28 23:11:09 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 273927672030191616,
  "created_at" : "2012-11-28 23:13:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273926225142116353",
  "in_reply_to_user_id" : 116807098,
  "text" : "@_CabinGirl what happened to the duck you found at your mailbox? did he turn out ok?",
  "id" : 273926225142116353,
  "created_at" : "2012-11-28 23:07:56 +0000",
  "in_reply_to_screen_name" : "_CabinGirl",
  "in_reply_to_user_id_str" : "116807098",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273925458897301504",
  "text" : "RT @luminanceriver: Remember that you attract what you are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273924669046919169",
    "text" : "Remember that you attract what you are.",
    "id" : 273924669046919169,
    "created_at" : "2012-11-28 23:01:45 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 273925458897301504,
  "created_at" : "2012-11-28 23:04:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273924110185287680",
  "text" : "its officially christmas season... eggnog in the house!",
  "id" : 273924110185287680,
  "created_at" : "2012-11-28 22:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Maxwell",
      "screen_name" : "aDancingDonkey",
      "indices" : [ 3, 18 ],
      "id_str" : "423145788",
      "id" : 423145788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/ad2UsTdw",
      "expanded_url" : "http:\/\/nblo.gs\/FiaSg",
      "display_url" : "nblo.gs\/FiaSg"
    } ]
  },
  "geo" : { },
  "id_str" : "273862969014759425",
  "text" : "RT @aDancingDonkey: Can you find the donkey? http:\/\/t.co\/ad2UsTdw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/ad2UsTdw",
        "expanded_url" : "http:\/\/nblo.gs\/FiaSg",
        "display_url" : "nblo.gs\/FiaSg"
      } ]
    },
    "geo" : { },
    "id_str" : "273862325994405888",
    "text" : "Can you find the donkey? http:\/\/t.co\/ad2UsTdw",
    "id" : 273862325994405888,
    "created_at" : "2012-11-28 18:54:01 +0000",
    "user" : {
      "name" : "Kris Maxwell",
      "screen_name" : "aDancingDonkey",
      "protected" : false,
      "id_str" : "423145788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661369445512646657\/MoCZ2m-Z_normal.jpg",
      "id" : 423145788,
      "verified" : false
    }
  },
  "id" : 273862969014759425,
  "created_at" : "2012-11-28 18:56:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273862456839917568",
  "text" : "RT @brandonrofl: The powerball jackpot is at 550 million. Money doesn't buy happiness but 550 million dollars would be a decent start",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273861942823755776",
    "text" : "The powerball jackpot is at 550 million. Money doesn't buy happiness but 550 million dollars would be a decent start",
    "id" : 273861942823755776,
    "created_at" : "2012-11-28 18:52:29 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 273862456839917568,
  "created_at" : "2012-11-28 18:54:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/sGTY1MOK",
      "expanded_url" : "http:\/\/i.imgur.com\/eG638.jpg",
      "display_url" : "i.imgur.com\/eG638.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "273854976550383616",
  "text" : "RT @aliceinthewater: Please don't make me take a bath: http:\/\/t.co\/sGTY1MOK (Via Reddit)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/sGTY1MOK",
        "expanded_url" : "http:\/\/i.imgur.com\/eG638.jpg",
        "display_url" : "i.imgur.com\/eG638.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "273848398245937152",
    "text" : "Please don't make me take a bath: http:\/\/t.co\/sGTY1MOK (Via Reddit)",
    "id" : 273848398245937152,
    "created_at" : "2012-11-28 17:58:40 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 273854976550383616,
  "created_at" : "2012-11-28 18:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "encouragement",
      "indices" : [ 58, 72 ]
    }, {
      "text" : "inspiration",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "nature",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "photography",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/T0lZVKyq",
      "expanded_url" : "http:\/\/ow.ly\/f66Z1",
      "display_url" : "ow.ly\/f66Z1"
    } ]
  },
  "geo" : { },
  "id_str" : "273845502678810624",
  "text" : "RT @KerriFar: ~ Believe You Can ~ http:\/\/t.co\/T0lZVKyq  ~ #encouragement  #inspiration #nature #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "encouragement",
        "indices" : [ 44, 58 ]
      }, {
        "text" : "inspiration",
        "indices" : [ 60, 72 ]
      }, {
        "text" : "nature",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "photography",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/T0lZVKyq",
        "expanded_url" : "http:\/\/ow.ly\/f66Z1",
        "display_url" : "ow.ly\/f66Z1"
      } ]
    },
    "geo" : { },
    "id_str" : "273844987882528768",
    "text" : "~ Believe You Can ~ http:\/\/t.co\/T0lZVKyq  ~ #encouragement  #inspiration #nature #photography",
    "id" : 273844987882528768,
    "created_at" : "2012-11-28 17:45:07 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 273845502678810624,
  "created_at" : "2012-11-28 17:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "indices" : [ 3, 19 ],
      "id_str" : "29251361",
      "id" : 29251361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273843007592210433",
  "text" : "RT @WorldOfJoeRiggs: Always put six lock on your door then lock every other one. No matter how long someone tries to pick them, they are ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273832821276168192",
    "text" : "Always put six lock on your door then lock every other one. No matter how long someone tries to pick them, they are always locking three.",
    "id" : 273832821276168192,
    "created_at" : "2012-11-28 16:56:46 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 273843007592210433,
  "created_at" : "2012-11-28 17:37:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273842894190813184",
  "text" : "@Skeptical_Lady my issue my whole life has been trying to avoid being important to family. scares the crap out of me! LOL",
  "id" : 273842894190813184,
  "created_at" : "2012-11-28 17:36:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273842561016266752",
  "text" : "@Skeptical_Lady hit the nail on the head there, lady..lol.",
  "id" : 273842561016266752,
  "created_at" : "2012-11-28 17:35:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ATA",
      "indices" : [ 36, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273841889294295040",
  "text" : "@Skeptical_Lady look for your local #ATA school. usually offer 2 week free trial and free uniform.",
  "id" : 273841889294295040,
  "created_at" : "2012-11-28 17:32:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hgtv",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273816608592498688",
  "text" : "love it or list it #hgtv &lt;3",
  "id" : 273816608592498688,
  "created_at" : "2012-11-28 15:52:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Mitchell",
      "screen_name" : "GregMitch",
      "indices" : [ 3, 13 ],
      "id_str" : "25913058",
      "id" : 25913058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/R25YC8mP",
      "expanded_url" : "http:\/\/bit.ly\/1174t3o",
      "display_url" : "bit.ly\/1174t3o"
    } ]
  },
  "geo" : { },
  "id_str" : "273609992626638848",
  "text" : "RT @GregMitch: I've added full (frontal) NSFW video to photos of nude protesters inside John Boehner's office today. http:\/\/t.co\/R25YC8mP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/R25YC8mP",
        "expanded_url" : "http:\/\/bit.ly\/1174t3o",
        "display_url" : "bit.ly\/1174t3o"
      } ]
    },
    "geo" : { },
    "id_str" : "273609072757059585",
    "text" : "I've added full (frontal) NSFW video to photos of nude protesters inside John Boehner's office today. http:\/\/t.co\/R25YC8mP",
    "id" : 273609072757059585,
    "created_at" : "2012-11-28 02:07:41 +0000",
    "user" : {
      "name" : "Greg Mitchell",
      "screen_name" : "GregMitch",
      "protected" : false,
      "id_str" : "25913058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853560224\/Img2690c_normal.jpg",
      "id" : 25913058,
      "verified" : false
    }
  },
  "id" : 273609992626638848,
  "created_at" : "2012-11-28 02:11:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "54V4G\u00A3",
      "screen_name" : "AnonSavage",
      "indices" : [ 3, 14 ],
      "id_str" : "891995863",
      "id" : 891995863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273606488973524992",
  "text" : "RT @AnonSavage: Property is theft. Nobody \u201Cowns\u201D anything. When you die, it all stays here.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273605590666842112",
    "text" : "Property is theft. Nobody \u201Cowns\u201D anything. When you die, it all stays here.",
    "id" : 273605590666842112,
    "created_at" : "2012-11-28 01:53:50 +0000",
    "user" : {
      "name" : "54V4G\u00A3",
      "screen_name" : "AnonSavage",
      "protected" : false,
      "id_str" : "891995863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675104953275424769\/9EkZXaMs_normal.jpg",
      "id" : 891995863,
      "verified" : false
    }
  },
  "id" : 273606488973524992,
  "created_at" : "2012-11-28 01:57:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin",
      "screen_name" : "mrscapra",
      "indices" : [ 0, 9 ],
      "id_str" : "1969965566",
      "id" : 1969965566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273602157117337600",
  "text" : "@MrsCapra blink blink ; )",
  "id" : 273602157117337600,
  "created_at" : "2012-11-28 01:40:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H. Cohen",
      "screen_name" : "alanhcohen",
      "indices" : [ 3, 14 ],
      "id_str" : "84404420",
      "id" : 84404420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273601785023832064",
  "text" : "RT @alanhcohen: It is not your job to make anyone happy. It is your job to be happy. Then u r in the perfect position to uplift everyone ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271005176280805377",
    "text" : "It is not your job to make anyone happy. It is your job to be happy. Then u r in the perfect position to uplift everyone u meet. ~Alan Cohen",
    "id" : 271005176280805377,
    "created_at" : "2012-11-20 21:40:43 +0000",
    "user" : {
      "name" : "Alan H. Cohen",
      "screen_name" : "alanhcohen",
      "protected" : false,
      "id_str" : "84404420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484904745\/Alan_Cohen_head_shot_web_use_normal.jpg",
      "id" : 84404420,
      "verified" : false
    }
  },
  "id" : 273601785023832064,
  "created_at" : "2012-11-28 01:38:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273578416614297600",
  "text" : "i dont like the word \"bitch\"",
  "id" : 273578416614297600,
  "created_at" : "2012-11-28 00:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273578053295288322",
  "text" : ". @1stCitizenKane yup.. just about sums up my life at the moment... sigh.",
  "id" : 273578053295288322,
  "created_at" : "2012-11-28 00:04:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273573182802374656",
  "geo" : { },
  "id_str" : "273577814563905536",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker say WHAT???",
  "id" : 273577814563905536,
  "in_reply_to_status_id" : 273573182802374656,
  "created_at" : "2012-11-28 00:03:28 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 57, 70 ]
    }, {
      "text" : "nature",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "photo",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/Nhb1kPQT",
      "expanded_url" : "http:\/\/ow.ly\/fAU5I",
      "display_url" : "ow.ly\/fAU5I"
    } ]
  },
  "geo" : { },
  "id_str" : "273547712367054849",
  "text" : "RT @KerriFar: #Bluebird Couple ~ http:\/\/t.co\/Nhb1kPQT  ~ #birdwatching #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 43, 56 ]
      }, {
        "text" : "nature",
        "indices" : [ 57, 64 ]
      }, {
        "text" : "photo",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/Nhb1kPQT",
        "expanded_url" : "http:\/\/ow.ly\/fAU5I",
        "display_url" : "ow.ly\/fAU5I"
      } ]
    },
    "geo" : { },
    "id_str" : "273543013626679297",
    "text" : "#Bluebird Couple ~ http:\/\/t.co\/Nhb1kPQT  ~ #birdwatching #nature #photo",
    "id" : 273543013626679297,
    "created_at" : "2012-11-27 21:45:11 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 273547712367054849,
  "created_at" : "2012-11-27 22:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 77, 84 ]
    }, {
      "text" : "photography",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/jxIz7TqT",
      "expanded_url" : "http:\/\/ow.ly\/fAU36",
      "display_url" : "ow.ly\/fAU36"
    } ]
  },
  "geo" : { },
  "id_str" : "273531766977994754",
  "text" : "RT @KerriFar: I LOVE it when they look right at me ~ http:\/\/t.co\/jxIz7TqT  ~ #nature #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "photography",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/jxIz7TqT",
        "expanded_url" : "http:\/\/ow.ly\/fAU36",
        "display_url" : "ow.ly\/fAU36"
      } ]
    },
    "geo" : { },
    "id_str" : "273527930410381312",
    "text" : "I LOVE it when they look right at me ~ http:\/\/t.co\/jxIz7TqT  ~ #nature #photography",
    "id" : 273527930410381312,
    "created_at" : "2012-11-27 20:45:15 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 273531766977994754,
  "created_at" : "2012-11-27 21:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273487289320079361",
  "text" : "RT @LSFProgram: May we trust that life is unfolding exactly the way it's meant to be for the greater good, even when we don't quite unde ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273485923616952320",
    "text" : "May we trust that life is unfolding exactly the way it's meant to be for the greater good, even when we don't quite understand why.",
    "id" : 273485923616952320,
    "created_at" : "2012-11-27 17:58:19 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 273487289320079361,
  "created_at" : "2012-11-27 18:03:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryTing",
      "screen_name" : "MaryTing",
      "indices" : [ 64, 73 ],
      "id_str" : "250992675",
      "id" : 250992675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/2jg0QVEa",
      "expanded_url" : "http:\/\/mindingspot.blogspot.com\/2012\/11\/crossroads-by-mary-ting-100-amazon-or.html",
      "display_url" : "mindingspot.blogspot.com\/2012\/11\/crossr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273485805224329216",
  "text" : "Enter to win a $100 Amazon Gift Card or Paypal Cash from Author @MaryTing http:\/\/t.co\/2jg0QVEa",
  "id" : 273485805224329216,
  "created_at" : "2012-11-27 17:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273483787785080832",
  "geo" : { },
  "id_str" : "273484563643260928",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench this is hubby's yearly week of hell. boss's xmas party on saturday.. hubby preps for it and works it.",
  "id" : 273484563643260928,
  "in_reply_to_status_id" : 273483787785080832,
  "created_at" : "2012-11-27 17:52:55 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 46, 55 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canhappentoyou",
      "indices" : [ 107, 122 ]
    }, {
      "text" : "bringnickhome",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273484124986146816",
  "text" : "it pisses me off that its been 7 months since @AniKnits son was stolen from her by DSS for no good reason! #canhappentoyou #bringnickhome",
  "id" : 273484124986146816,
  "created_at" : "2012-11-27 17:51:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273482655100719105",
  "text" : "RT @SpiritMaterial: Never does the human soul become so strong as when it dares to forgive an injury.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273482150215573504",
    "text" : "Never does the human soul become so strong as when it dares to forgive an injury.",
    "id" : 273482150215573504,
    "created_at" : "2012-11-27 17:43:20 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 273482655100719105,
  "created_at" : "2012-11-27 17:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273482121170014208",
  "text" : "RT @DoreenVirtue444: Set your intention throughout the day to spread happy feelings, and it is done.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273471302512300032",
    "text" : "Set your intention throughout the day to spread happy feelings, and it is done.",
    "id" : 273471302512300032,
    "created_at" : "2012-11-27 17:00:14 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 273482121170014208,
  "created_at" : "2012-11-27 17:43:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Capria",
      "screen_name" : "MrFornicator",
      "indices" : [ 3, 16 ],
      "id_str" : "184221744",
      "id" : 184221744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273480808101183488",
  "text" : "RT @MrFornicator: When someone says no pain no gain, I like to punch them in the face so they gain a valuable lesson about saying stupid ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273474435586080768",
    "text" : "When someone says no pain no gain, I like to punch them in the face so they gain a valuable lesson about saying stupid shit to me.",
    "id" : 273474435586080768,
    "created_at" : "2012-11-27 17:12:41 +0000",
    "user" : {
      "name" : "Jamie Capria",
      "screen_name" : "MrFornicator",
      "protected" : false,
      "id_str" : "184221744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543689744148742144\/OfD_JUwQ_normal.png",
      "id" : 184221744,
      "verified" : false
    }
  },
  "id" : 273480808101183488,
  "created_at" : "2012-11-27 17:38:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273470304519598080",
  "text" : "RT @richarddoetsch: Nothing warms the heart like a simple act of kindness...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273469680377810946",
    "text" : "Nothing warms the heart like a simple act of kindness...",
    "id" : 273469680377810946,
    "created_at" : "2012-11-27 16:53:47 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 273470304519598080,
  "created_at" : "2012-11-27 16:56:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273469400705822721",
  "text" : "@Skeptical_Lady aww.. love them!",
  "id" : 273469400705822721,
  "created_at" : "2012-11-27 16:52:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273465964815863808",
  "text" : "i have books to read, a kindle fire, a kindle, an ipod touch, a laptop. #gratitude",
  "id" : 273465964815863808,
  "created_at" : "2012-11-27 16:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273465379110678528",
  "text" : "i have a roof over my head complete w heat, electric. tv\/internet\/phone connected. #gratitude",
  "id" : 273465379110678528,
  "created_at" : "2012-11-27 16:36:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273464651646377984",
  "text" : "my 17yo DD loves spending time with me and hubby. she is a sweet and caring person. #gratitude",
  "id" : 273464651646377984,
  "created_at" : "2012-11-27 16:33:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273464090981187584",
  "text" : "i am not in pain today. i am not nauseous. i have use of all my limbs. #gratitude",
  "id" : 273464090981187584,
  "created_at" : "2012-11-27 16:31:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273463730677895168",
  "text" : "i married a good, good man #gratitude",
  "id" : 273463730677895168,
  "created_at" : "2012-11-27 16:30:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273463418957205504",
  "text" : "the dog is alive and apparently uninjured #gratitude",
  "id" : 273463418957205504,
  "created_at" : "2012-11-27 16:28:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273462895990419457",
  "text" : "i need to do some gratitude today...",
  "id" : 273462895990419457,
  "created_at" : "2012-11-27 16:26:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273460687102173184",
  "geo" : { },
  "id_str" : "273462592658358272",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords retweeted this to see if you get it in your gmail.",
  "id" : 273462592658358272,
  "in_reply_to_status_id" : 273460687102173184,
  "created_at" : "2012-11-27 16:25:37 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273462441495629824",
  "text" : "RT @Wylieknowords: I love the internet. I'm going to RehabRich,VA to learn to walk &amp; yesterday I sold a slogan to a business in Belg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273460687102173184",
    "text" : "I love the internet. I'm going to RehabRich,VA to learn to walk &amp; yesterday I sold a slogan to a business in Belgium. I've never been there.",
    "id" : 273460687102173184,
    "created_at" : "2012-11-27 16:18:03 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 273462441495629824,
  "created_at" : "2012-11-27 16:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273455369194442752",
  "geo" : { },
  "id_str" : "273461959507181569",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth i hated doing research papers.. well.. ALL of school was difficult for me..",
  "id" : 273461959507181569,
  "in_reply_to_status_id" : 273455369194442752,
  "created_at" : "2012-11-27 16:23:06 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273454582737289216",
  "text" : "RT @bend_time: everything is complex, simplicity especially. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273452437300473856",
    "text" : "everything is complex, simplicity especially. :)",
    "id" : 273452437300473856,
    "created_at" : "2012-11-27 15:45:16 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 273454582737289216,
  "created_at" : "2012-11-27 15:53:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ontario Nature",
      "screen_name" : "OntarioNature",
      "indices" : [ 3, 17 ],
      "id_str" : "86989960",
      "id" : 86989960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TO5jDgQa",
      "expanded_url" : "http:\/\/ontarionature.tumblr.com\/",
      "display_url" : "ontarionature.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "273454284283199488",
  "text" : "RT @OntarioNature: Let it snow, says the moose. http:\/\/t.co\/TO5jDgQa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/TO5jDgQa",
        "expanded_url" : "http:\/\/ontarionature.tumblr.com\/",
        "display_url" : "ontarionature.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "273452984661319681",
    "text" : "Let it snow, says the moose. http:\/\/t.co\/TO5jDgQa",
    "id" : 273452984661319681,
    "created_at" : "2012-11-27 15:47:26 +0000",
    "user" : {
      "name" : "Ontario Nature",
      "screen_name" : "OntarioNature",
      "protected" : false,
      "id_str" : "86989960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2280867541\/xg1hhg1b3rtg724bk3fd_normal.jpeg",
      "id" : 86989960,
      "verified" : false
    }
  },
  "id" : 273454284283199488,
  "created_at" : "2012-11-27 15:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 3, 13 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273454131581161472",
  "text" : "RT @UberFacts: Maple Syrup actually contains anti-oxidants and 54 beneficial compounds than can help you fight cancer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273453078605348864",
    "text" : "Maple Syrup actually contains anti-oxidants and 54 beneficial compounds than can help you fight cancer.",
    "id" : 273453078605348864,
    "created_at" : "2012-11-27 15:47:49 +0000",
    "user" : {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "protected" : false,
      "id_str" : "95023423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615696617165885440\/JDbUuo9H_normal.jpg",
      "id" : 95023423,
      "verified" : true
    }
  },
  "id" : 273454131581161472,
  "created_at" : "2012-11-27 15:52:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 0, 10 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273453407824642048",
  "geo" : { },
  "id_str" : "273454088891547648",
  "in_reply_to_user_id" : 126764612,
  "text" : "@RuffHaven softness!",
  "id" : 273454088891547648,
  "in_reply_to_status_id" : 273453407824642048,
  "created_at" : "2012-11-27 15:51:49 +0000",
  "in_reply_to_screen_name" : "RuffHaven",
  "in_reply_to_user_id_str" : "126764612",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 3, 13 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/ob3ISFfO",
      "expanded_url" : "http:\/\/yfrog.com\/o09mqhyzj",
      "display_url" : "yfrog.com\/o09mqhyzj"
    } ]
  },
  "geo" : { },
  "id_str" : "273453972839333889",
  "text" : "RT @RuffHaven: I love my old dog http:\/\/t.co\/ob3ISFfO Dutch loves the kitchen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.htc.com\" rel=\"nofollow\"\u003E  HTC Peep\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/ob3ISFfO",
        "expanded_url" : "http:\/\/yfrog.com\/o09mqhyzj",
        "display_url" : "yfrog.com\/o09mqhyzj"
      } ]
    },
    "geo" : { },
    "id_str" : "273453407824642048",
    "text" : "I love my old dog http:\/\/t.co\/ob3ISFfO Dutch loves the kitchen",
    "id" : 273453407824642048,
    "created_at" : "2012-11-27 15:49:07 +0000",
    "user" : {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "protected" : false,
      "id_str" : "126764612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459086546319056896\/W1rXvAEz_normal.jpeg",
      "id" : 126764612,
      "verified" : false
    }
  },
  "id" : 273453972839333889,
  "created_at" : "2012-11-27 15:51:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273451983443226624",
  "geo" : { },
  "id_str" : "273453492427952128",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time thats what im trying to focus on...",
  "id" : 273453492427952128,
  "in_reply_to_status_id" : 273451983443226624,
  "created_at" : "2012-11-27 15:49:27 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 2, 12 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273449876665294848",
  "geo" : { },
  "id_str" : "273452212934553600",
  "in_reply_to_user_id" : 48215218,
  "text" : ". @bend_time sometimes i feel like im back at the starting line.. like i havent learned a thing.. like im no better off than before.",
  "id" : 273452212934553600,
  "in_reply_to_status_id" : 273449876665294848,
  "created_at" : "2012-11-27 15:44:22 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273451726374309888",
  "text" : "RT @bend_time: WHO ARE YOU? YOU DECIDE. AND STICK TO IT. (hint: ego isnt involved)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273450191439425537",
    "text" : "WHO ARE YOU? YOU DECIDE. AND STICK TO IT. (hint: ego isnt involved)",
    "id" : 273450191439425537,
    "created_at" : "2012-11-27 15:36:20 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 273451726374309888,
  "created_at" : "2012-11-27 15:42:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/2FiVrW6A",
      "expanded_url" : "http:\/\/youtu.be\/Za1UW7Vpv_I",
      "display_url" : "youtu.be\/Za1UW7Vpv_I"
    } ]
  },
  "geo" : { },
  "id_str" : "273451659366113280",
  "text" : "RT @SenSanders: I get very nervous when I hear the president talk about \u201Centitlement reform.\u201D That could mean cuts. http:\/\/t.co\/2FiVrW6A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiscalCliff",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/2FiVrW6A",
        "expanded_url" : "http:\/\/youtu.be\/Za1UW7Vpv_I",
        "display_url" : "youtu.be\/Za1UW7Vpv_I"
      } ]
    },
    "geo" : { },
    "id_str" : "273450289934262273",
    "text" : "I get very nervous when I hear the president talk about \u201Centitlement reform.\u201D That could mean cuts. http:\/\/t.co\/2FiVrW6A #FiscalCliff",
    "id" : 273450289934262273,
    "created_at" : "2012-11-27 15:36:44 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 273451659366113280,
  "created_at" : "2012-11-27 15:42:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273451462678441985",
  "text" : "the birds are pissed.. no food. breaks my heart watching them...",
  "id" : 273451462678441985,
  "created_at" : "2012-11-27 15:41:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273451024461733888",
  "text" : "i didnt go to the door. that choice allowed an event to happen that could have turned out fatal.",
  "id" : 273451024461733888,
  "created_at" : "2012-11-27 15:39:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273448989859385344",
  "text" : "life sucks and then you die",
  "id" : 273448989859385344,
  "created_at" : "2012-11-27 15:31:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/273192684921950208\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/CvULcowQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8qTTK0CYAAEWMv.jpg",
      "id_str" : "273192684938747904",
      "id" : 273192684938747904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8qTTK0CYAAEWMv.jpg",
      "sizes" : [ {
        "h" : 594,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 586
      } ],
      "display_url" : "pic.twitter.com\/CvULcowQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273194324823531522",
  "text" : "RT @petsalive: Now we just need to fatten her up and find her a good home. http:\/\/t.co\/CvULcowQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/273192684921950208\/photo\/1",
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/CvULcowQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A8qTTK0CYAAEWMv.jpg",
        "id_str" : "273192684938747904",
        "id" : 273192684938747904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8qTTK0CYAAEWMv.jpg",
        "sizes" : [ {
          "h" : 594,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 586
        } ],
        "display_url" : "pic.twitter.com\/CvULcowQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273192684921950208",
    "text" : "Now we just need to fatten her up and find her a good home. http:\/\/t.co\/CvULcowQ",
    "id" : 273192684921950208,
    "created_at" : "2012-11-26 22:33:06 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 273194324823531522,
  "created_at" : "2012-11-26 22:39:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273158175530815488",
  "text" : "RT @bunnybuddhism: My thoughts when I stumble greatly influence the outcome of my next hop.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273157043345559552",
    "text" : "My thoughts when I stumble greatly influence the outcome of my next hop.",
    "id" : 273157043345559552,
    "created_at" : "2012-11-26 20:11:28 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 273158175530815488,
  "created_at" : "2012-11-26 20:15:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "179732982",
      "id" : 179732982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/3TyBDsJw",
      "expanded_url" : "http:\/\/thinkbynumbers.org\/government-spending\/corporate-welfare\/corporate-welfare-statistics-vs-social-welfare-statistics\/",
      "display_url" : "thinkbynumbers.org\/government-spe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273150132495712256",
  "text" : "RT @TheDailyEdge: The next time a CEO tells you we need to starve the poor to cut the deficit, tell him to fuck off http:\/\/t.co\/3TyBDsJw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corporatewelfare",
        "indices" : [ 119, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/3TyBDsJw",
        "expanded_url" : "http:\/\/thinkbynumbers.org\/government-spending\/corporate-welfare\/corporate-welfare-statistics-vs-social-welfare-statistics\/",
        "display_url" : "thinkbynumbers.org\/government-spe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "273098666120736769",
    "text" : "The next time a CEO tells you we need to starve the poor to cut the deficit, tell him to fuck off http:\/\/t.co\/3TyBDsJw #corporatewelfare",
    "id" : 273098666120736769,
    "created_at" : "2012-11-26 16:19:30 +0000",
    "user" : {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "protected" : false,
      "id_str" : "179732982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655073745510510592\/FX6VgfRw_normal.png",
      "id" : 179732982,
      "verified" : false
    }
  },
  "id" : 273150132495712256,
  "created_at" : "2012-11-26 19:44:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne K Wellings",
      "screen_name" : "AnneKatwoman",
      "indices" : [ 0, 13 ],
      "id_str" : "799727408",
      "id" : 799727408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273143861960929280",
  "geo" : { },
  "id_str" : "273147035681685504",
  "in_reply_to_user_id" : 799727408,
  "text" : "@AnneKatwoman thank you but it wasnt me. i followed his story on facebook. looked like he was beginning to recover but wasnt to be.",
  "id" : 273147035681685504,
  "in_reply_to_status_id" : 273143861960929280,
  "created_at" : "2012-11-26 19:31:42 +0000",
  "in_reply_to_screen_name" : "AnneKatwoman",
  "in_reply_to_user_id_str" : "799727408",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arya",
      "screen_name" : "wildwhispers",
      "indices" : [ 3, 16 ],
      "id_str" : "2421262108",
      "id" : 2421262108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/RW3nAwRE",
      "expanded_url" : "http:\/\/bit.ly\/10ir7qd",
      "display_url" : "bit.ly\/10ir7qd"
    } ]
  },
  "geo" : { },
  "id_str" : "273141654897168384",
  "text" : "RT @WildWhispers: Looking for that perfect Xmas gift? Take a look at our Nest Box Cams - Fantastic bits of kit! http:\/\/t.co\/RW3nAwRE #Xm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "XmasGiftIdea",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/RW3nAwRE",
        "expanded_url" : "http:\/\/bit.ly\/10ir7qd",
        "display_url" : "bit.ly\/10ir7qd"
      } ]
    },
    "geo" : { },
    "id_str" : "273139671071064064",
    "text" : "Looking for that perfect Xmas gift? Take a look at our Nest Box Cams - Fantastic bits of kit! http:\/\/t.co\/RW3nAwRE #XmasGiftIdea",
    "id" : 273139671071064064,
    "created_at" : "2012-11-26 19:02:26 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 273141654897168384,
  "created_at" : "2012-11-26 19:10:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/58Ub3LDU",
      "expanded_url" : "http:\/\/www.facebook.com\/WildHeartRanch\/posts\/10151177415694091",
      "display_url" : "facebook.com\/WildHeartRanch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273137413197549568",
  "text" : "RIP little meth raccoon \"Tweak\" http:\/\/t.co\/58Ub3LDU",
  "id" : 273137413197549568,
  "created_at" : "2012-11-26 18:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273113448278265856",
  "geo" : { },
  "id_str" : "273117093040369664",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords cool beans!! congratulations! ((confettifalling))",
  "id" : 273117093040369664,
  "in_reply_to_status_id" : 273113448278265856,
  "created_at" : "2012-11-26 17:32:43 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/vPWjG1Tk",
      "expanded_url" : "http:\/\/www.littlehouseliving.com\/olive-oil-candles.html",
      "display_url" : "littlehouseliving.com\/olive-oil-cand\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273102388288712705",
  "text" : "Olive Oil Candles http:\/\/t.co\/vPWjG1Tk",
  "id" : 273102388288712705,
  "created_at" : "2012-11-26 16:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273077036543799297",
  "text" : "\"the birds\" in my yard! didnt get a pic but oh so awesome.. all these black birds flying down to yard then back into trees! what a gift!",
  "id" : 273077036543799297,
  "created_at" : "2012-11-26 14:53:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272865083678396416",
  "text" : "my 2 advil, 2 es tylenol combo not lasting 12 hours... (tylenol says only take 2 in 24 hours)",
  "id" : 272865083678396416,
  "created_at" : "2012-11-26 00:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    }, {
      "name" : "Ayesha Priest",
      "screen_name" : "amazonlocal",
      "indices" : [ 97, 109 ],
      "id_str" : "4607198955",
      "id" : 4607198955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/8mJMPLMv",
      "expanded_url" : "http:\/\/bit.ly\/UmjigO",
      "display_url" : "bit.ly\/UmjigO"
    } ]
  },
  "geo" : { },
  "id_str" : "272772074039279616",
  "text" : "RT @amazonmp3: Get a free voucher to purchase one top holiday album for $1.99 at Amazon MP3 from @amazonlocal: http:\/\/t.co\/8mJMPLMv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ayesha Priest",
        "screen_name" : "amazonlocal",
        "indices" : [ 82, 94 ],
        "id_str" : "4607198955",
        "id" : 4607198955
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/8mJMPLMv",
        "expanded_url" : "http:\/\/bit.ly\/UmjigO",
        "display_url" : "bit.ly\/UmjigO"
      } ]
    },
    "geo" : { },
    "id_str" : "272771537877204992",
    "text" : "Get a free voucher to purchase one top holiday album for $1.99 at Amazon MP3 from @amazonlocal: http:\/\/t.co\/8mJMPLMv",
    "id" : 272771537877204992,
    "created_at" : "2012-11-25 18:39:37 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 272772074039279616,
  "created_at" : "2012-11-25 18:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALit",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/NHfPXDER",
      "expanded_url" : "http:\/\/www.thebooksnoop.com\/p\/about-me.html?spref=tw",
      "display_url" : "thebooksnoop.com\/p\/about-me.htm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272757402556854272",
  "text" : "RT @JAScribbles: Love reading YA titles? Contribute to my blog. Read the 'About' tab first, then 'Contribute' http:\/\/t.co\/NHfPXDER #YALit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YALit",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/NHfPXDER",
        "expanded_url" : "http:\/\/www.thebooksnoop.com\/p\/about-me.html?spref=tw",
        "display_url" : "thebooksnoop.com\/p\/about-me.htm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "272756304886521857",
    "text" : "Love reading YA titles? Contribute to my blog. Read the 'About' tab first, then 'Contribute' http:\/\/t.co\/NHfPXDER #YALit",
    "id" : 272756304886521857,
    "created_at" : "2012-11-25 17:39:05 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 272757402556854272,
  "created_at" : "2012-11-25 17:43:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272746005433286658",
  "text" : "@Skeptical_Lady aww.. im sorry you're coming across that behavior. ppl like that obv have issues. ((hugs))",
  "id" : 272746005433286658,
  "created_at" : "2012-11-25 16:58:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272734503515066368",
  "text" : "not feeling well at all...",
  "id" : 272734503515066368,
  "created_at" : "2012-11-25 16:12:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/HNka8PDh",
      "expanded_url" : "http:\/\/amzn.to\/U6HDoI",
      "display_url" : "amzn.to\/U6HDoI"
    } ]
  },
  "geo" : { },
  "id_str" : "272554665466535936",
  "text" : "finished DRO2WN by Joshua Wright http:\/\/t.co\/HNka8PDh",
  "id" : 272554665466535936,
  "created_at" : "2012-11-25 04:17:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "nature",
      "indices" : [ 56, 63 ]
    }, {
      "text" : "outdoors",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "birds",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/ynfxcRMw",
      "expanded_url" : "http:\/\/ow.ly\/fwOBX",
      "display_url" : "ow.ly\/fwOBX"
    } ]
  },
  "geo" : { },
  "id_str" : "272397192076087297",
  "text" : "RT @KerriFar: #Bluebird Family ~ http:\/\/t.co\/ynfxcRMw ~ #nature #outdoors #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "nature",
        "indices" : [ 42, 49 ]
      }, {
        "text" : "outdoors",
        "indices" : [ 50, 59 ]
      }, {
        "text" : "birds",
        "indices" : [ 60, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/ynfxcRMw",
        "expanded_url" : "http:\/\/ow.ly\/fwOBX",
        "display_url" : "ow.ly\/fwOBX"
      } ]
    },
    "geo" : { },
    "id_str" : "272395429486948353",
    "text" : "#Bluebird Family ~ http:\/\/t.co\/ynfxcRMw ~ #nature #outdoors #birds",
    "id" : 272395429486948353,
    "created_at" : "2012-11-24 17:45:05 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 272397192076087297,
  "created_at" : "2012-11-24 17:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272379144262787073",
  "text" : "RT @mindymayhem: As for their health insurance... Well, how can someone making less than minimum wage afford the first $1,000 in care be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272378712035586048",
    "text" : "As for their health insurance... Well, how can someone making less than minimum wage afford the first $1,000 in care before it kicks in?",
    "id" : 272378712035586048,
    "created_at" : "2012-11-24 16:38:40 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 272379144262787073,
  "created_at" : "2012-11-24 16:40:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272358751061815296",
  "text" : ". @1stCitizenKane actually this is how I view \"God\" and how we should seek to see each other.",
  "id" : 272358751061815296,
  "created_at" : "2012-11-24 15:19:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/stjIPy8r",
      "expanded_url" : "http:\/\/huff.to\/10w0Wwp",
      "display_url" : "huff.to\/10w0Wwp"
    } ]
  },
  "geo" : { },
  "id_str" : "272352310397632512",
  "text" : "RT @HuffPostWeird: 'Turkey Fairy's' act of kindness will make your day http:\/\/t.co\/stjIPy8r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/stjIPy8r",
        "expanded_url" : "http:\/\/huff.to\/10w0Wwp",
        "display_url" : "huff.to\/10w0Wwp"
      } ]
    },
    "geo" : { },
    "id_str" : "272350131976798209",
    "text" : "'Turkey Fairy's' act of kindness will make your day http:\/\/t.co\/stjIPy8r",
    "id" : 272350131976798209,
    "created_at" : "2012-11-24 14:45:06 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 272352310397632512,
  "created_at" : "2012-11-24 14:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallStNYC",
      "indices" : [ 3, 19 ],
      "id_str" : "335972576",
      "id" : 335972576
    }, {
      "name" : "Walmart",
      "screen_name" : "Walmart",
      "indices" : [ 25, 33 ],
      "id_str" : "17137891",
      "id" : 17137891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272161469334953984",
  "text" : "RT @OccupyWallStNYC: For @Walmart, profiting off workers during life isn't enough. It secretly profited from their deaths: http:\/\/t.co\/k ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Walmart",
        "screen_name" : "Walmart",
        "indices" : [ 4, 12 ],
        "id_str" : "17137891",
        "id" : 17137891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/kaNLiEAh",
        "expanded_url" : "http:\/\/insurancenewsnet.com\/article.aspx?id=273059&isrc=fen",
        "display_url" : "insurancenewsnet.com\/article.aspx?i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "272156165452992512",
    "text" : "For @Walmart, profiting off workers during life isn't enough. It secretly profited from their deaths: http:\/\/t.co\/kaNLiEAh",
    "id" : 272156165452992512,
    "created_at" : "2012-11-24 01:54:20 +0000",
    "user" : {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallStNYC",
      "protected" : false,
      "id_str" : "335972576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567403358772662272\/BxNhe6D1_normal.jpeg",
      "id" : 335972576,
      "verified" : false
    }
  },
  "id" : 272161469334953984,
  "created_at" : "2012-11-24 02:15:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272138932186140673",
  "text" : "RT @DeepakChopra: Life is a continuum of \"now\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272138562126876672",
    "text" : "Life is a continuum of \"now\"",
    "id" : 272138562126876672,
    "created_at" : "2012-11-24 00:44:23 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 272138932186140673,
  "created_at" : "2012-11-24 00:45:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272131576672956416",
  "geo" : { },
  "id_str" : "272132497758900224",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 hello, kitty. : )",
  "id" : 272132497758900224,
  "in_reply_to_status_id" : 272131576672956416,
  "created_at" : "2012-11-24 00:20:18 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272132401503797249",
  "text" : "@HEATHENRABBIT nice.. soft and warm. is that the massage version? lol",
  "id" : 272132401503797249,
  "created_at" : "2012-11-24 00:19:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272118303621779456",
  "text" : "@ryanholt94 : (",
  "id" : 272118303621779456,
  "created_at" : "2012-11-23 23:23:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kristenp17",
      "screen_name" : "kristenp17",
      "indices" : [ 3, 14 ],
      "id_str" : "2520593647",
      "id" : 2520593647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "walmart",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272087061744459776",
  "text" : "RT @kristenp17: A single parent could work 2 full time #walmart slave wage jobs (80 hours a week) and still not earn enough to survive T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "walmart",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272066768581832704",
    "text" : "A single parent could work 2 full time #walmart slave wage jobs (80 hours a week) and still not earn enough to survive THAT IS SLAVE LABOR",
    "id" : 272066768581832704,
    "created_at" : "2012-11-23 19:59:07 +0000",
    "user" : {
      "name" : "Free (R) women",
      "screen_name" : "KristinP22",
      "protected" : false,
      "id_str" : "616458683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2334756526\/cvg2lpy6mvjuxnnlnxhv_normal.jpeg",
      "id" : 616458683,
      "verified" : false
    }
  },
  "id" : 272087061744459776,
  "created_at" : "2012-11-23 21:19:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ClouDrop for iOS",
      "screen_name" : "ClouDrop",
      "indices" : [ 3, 12 ],
      "id_str" : "581532978",
      "id" : 581532978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/nCrIjM9F",
      "expanded_url" : "http:\/\/cl.ly\/L7wR",
      "display_url" : "cl.ly\/L7wR"
    } ]
  },
  "geo" : { },
  "id_str" : "272071107182489600",
  "text" : "RT @ClouDrop: Only FREE for one more hour! Hurry and let everyone know about the best Cloudapp client, ClouDrop! http:\/\/t.co\/nCrIjM9F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/nCrIjM9F",
        "expanded_url" : "http:\/\/cl.ly\/L7wR",
        "display_url" : "cl.ly\/L7wR"
      } ]
    },
    "geo" : { },
    "id_str" : "272067893116674049",
    "text" : "Only FREE for one more hour! Hurry and let everyone know about the best Cloudapp client, ClouDrop! http:\/\/t.co\/nCrIjM9F",
    "id" : 272067893116674049,
    "created_at" : "2012-11-23 20:03:35 +0000",
    "user" : {
      "name" : "ClouDrop for iOS",
      "screen_name" : "ClouDrop",
      "protected" : false,
      "id_str" : "581532978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414296288004284416\/IeviNLg1_normal.png",
      "id" : 581532978,
      "verified" : false
    }
  },
  "id" : 272071107182489600,
  "created_at" : "2012-11-23 20:16:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272065137853214720",
  "geo" : { },
  "id_str" : "272066397910212608",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie try 2 advils w 1 es tylenol.. is working for me w tooth pain.",
  "id" : 272066397910212608,
  "in_reply_to_status_id" : 272065137853214720,
  "created_at" : "2012-11-23 19:57:38 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272063503685263361",
  "geo" : { },
  "id_str" : "272064528504721408",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny sigh...",
  "id" : 272064528504721408,
  "in_reply_to_status_id" : 272063503685263361,
  "created_at" : "2012-11-23 19:50:12 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272055679714484224",
  "geo" : { },
  "id_str" : "272062894215155713",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny mmm.. smells good!",
  "id" : 272062894215155713,
  "in_reply_to_status_id" : 272055679714484224,
  "created_at" : "2012-11-23 19:43:43 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272044691959214080",
  "geo" : { },
  "id_str" : "272046224352370688",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny LOL.. interesting idea...",
  "id" : 272046224352370688,
  "in_reply_to_status_id" : 272044691959214080,
  "created_at" : "2012-11-23 18:37:28 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272045851545841666",
  "text" : "i love my kindle but getting frustrated with it. i need more book info on the device when choosing what to read...",
  "id" : 272045851545841666,
  "created_at" : "2012-11-23 18:36:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272043746667921409",
  "geo" : { },
  "id_str" : "272045130385604608",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields says i have 2917 MB free which doesnt sound like much..lol.. UGH. the thing is im a searcher to find what i want to read.",
  "id" : 272045130385604608,
  "in_reply_to_status_id" : 272043746667921409,
  "created_at" : "2012-11-23 18:33:08 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272040104615346177",
  "geo" : { },
  "id_str" : "272041950968958976",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny did you get your grass cut? my niece made thin mints .. ritz crackers dipped in mint choc chips.. omg'ness YUM!",
  "id" : 272041950968958976,
  "in_reply_to_status_id" : 272040104615346177,
  "created_at" : "2012-11-23 18:20:30 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272041399489286144",
  "text" : "omg.. my kindle 3 (3G\/wifi) is getting increasingly slower! 10 collections, 14 pgs of books.",
  "id" : 272041399489286144,
  "created_at" : "2012-11-23 18:18:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mavireck",
      "screen_name" : "mavireck",
      "indices" : [ 3, 12 ],
      "id_str" : "730172730012618752",
      "id" : 730172730012618752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/WQwviiAO",
      "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2012\/11\/121122095433.htm#.UK-qyFIlcQk.twitter",
      "display_url" : "sciencedaily.com\/releases\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272022878579466241",
  "text" : "RT @mavireck: Blind patient reads words stimulated directly onto retina: device uses implant to project visual braille:\nhttp:\/\/t.co\/WQwviiAO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/WQwviiAO",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2012\/11\/121122095433.htm#.UK-qyFIlcQk.twitter",
        "display_url" : "sciencedaily.com\/releases\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "272021288162308096",
    "text" : "Blind patient reads words stimulated directly onto retina: device uses implant to project visual braille:\nhttp:\/\/t.co\/WQwviiAO",
    "id" : 272021288162308096,
    "created_at" : "2012-11-23 16:58:23 +0000",
    "user" : {
      "name" : "Ivan",
      "screen_name" : "StarStuff_ivan",
      "protected" : false,
      "id_str" : "27268080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889357120\/er3_normal.gif",
      "id" : 27268080,
      "verified" : false
    }
  },
  "id" : 272022878579466241,
  "created_at" : "2012-11-23 17:04:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kobo",
      "screen_name" : "kobo",
      "indices" : [ 3, 8 ],
      "id_str" : "17348224",
      "id" : 17348224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KoboMini",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/dtHVyt4Q",
      "expanded_url" : "http:\/\/bit.ly\/Umy0CE?awid=6772833390514442341-3752",
      "display_url" : "bit.ly\/Umy0CE?awid=67\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272022308938457088",
  "text" : "RT @kobo: If it's not at the top of your list it should be \u2013 the #KoboMini is only $49.99 today! ...http:\/\/t.co\/dtHVyt4Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.awarenessnetworks.com\/home\/\" rel=\"nofollow\"\u003ESocial Marketing Hub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KoboMini",
        "indices" : [ 55, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/dtHVyt4Q",
        "expanded_url" : "http:\/\/bit.ly\/Umy0CE?awid=6772833390514442341-3752",
        "display_url" : "bit.ly\/Umy0CE?awid=67\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "272021976841846785",
    "text" : "If it's not at the top of your list it should be \u2013 the #KoboMini is only $49.99 today! ...http:\/\/t.co\/dtHVyt4Q",
    "id" : 272021976841846785,
    "created_at" : "2012-11-23 17:01:07 +0000",
    "user" : {
      "name" : "Kobo",
      "screen_name" : "kobo",
      "protected" : false,
      "id_str" : "17348224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729704254613508096\/O-HKidTQ_normal.jpg",
      "id" : 17348224,
      "verified" : true
    }
  },
  "id" : 272022308938457088,
  "created_at" : "2012-11-23 17:02:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "indices" : [ 3, 16 ],
      "id_str" : "74399881",
      "id" : 74399881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272020065447186432",
  "text" : "RT @pamelamarie8: Do you keep a gratitude journal? Need help getting started? Contact me at Justimaginecoach@gmail.com no risk or obliga ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272019811872161792",
    "text" : "Do you keep a gratitude journal? Need help getting started? Contact me at Justimaginecoach@gmail.com no risk or obligation.",
    "id" : 272019811872161792,
    "created_at" : "2012-11-23 16:52:31 +0000",
    "user" : {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "protected" : false,
      "id_str" : "74399881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445924023600287744\/sh9pRUES_normal.jpeg",
      "id" : 74399881,
      "verified" : false
    }
  },
  "id" : 272020065447186432,
  "created_at" : "2012-11-23 16:53:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 120, 133 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/5o1kDJW4",
      "expanded_url" : "http:\/\/bookwi.se.com",
      "display_url" : "bookwi.se.com"
    } ]
  },
  "geo" : { },
  "id_str" : "272011355920408576",
  "text" : "i like http:\/\/t.co\/5o1kDJW4 blog .. if you're going to buy books (or ebooks) use their amazon link to support them! : ) @bookwiseblog",
  "id" : 272011355920408576,
  "created_at" : "2012-11-23 16:18:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/bip440PD",
      "expanded_url" : "http:\/\/bookwi.se\/black-friday-kindle-books-sale-1-99\/",
      "display_url" : "bookwi.se\/black-friday-k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272010334917758976",
  "text" : "Black Friday Kindle Books Sale - $1.99 http:\/\/t.co\/bip440PD",
  "id" : 272010334917758976,
  "created_at" : "2012-11-23 16:14:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "indices" : [ 0, 9 ],
      "id_str" : "46375814",
      "id" : 46375814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272002144268324864",
  "geo" : { },
  "id_str" : "272005821125238784",
  "in_reply_to_user_id" : 46375814,
  "text" : "@GB_Witch glad it was something relatively minor... (having gallbladder issues, often felt like i was dying..lol..ugh)",
  "id" : 272005821125238784,
  "in_reply_to_status_id" : 272002144268324864,
  "created_at" : "2012-11-23 15:56:56 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Gray",
      "screen_name" : "GB_Witch",
      "indices" : [ 0, 9 ],
      "id_str" : "46375814",
      "id" : 46375814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271998243909541888",
  "geo" : { },
  "id_str" : "272001139594117120",
  "in_reply_to_user_id" : 46375814,
  "text" : "@GB_Witch wth? hope you are recovering from whatever sent you to ER. sorry about your thanksgiving : ( ((hugs))",
  "id" : 272001139594117120,
  "in_reply_to_status_id" : 271998243909541888,
  "created_at" : "2012-11-23 15:38:19 +0000",
  "in_reply_to_screen_name" : "GB_Witch",
  "in_reply_to_user_id_str" : "46375814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271785933047730176",
  "text" : "puppy sooo happy we're home.. we missed her so.",
  "id" : 271785933047730176,
  "created_at" : "2012-11-23 01:23:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271785349322268672",
  "text" : "survived the day.. haha. 2 wee ones were sooo cute!",
  "id" : 271785349322268672,
  "created_at" : "2012-11-23 01:20:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271660786701717504",
  "geo" : { },
  "id_str" : "271661129296670720",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen sleep it off!! : )",
  "id" : 271661129296670720,
  "in_reply_to_status_id" : 271660786701717504,
  "created_at" : "2012-11-22 17:07:15 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271661002460913664",
  "text" : "@iEyeAyes : )",
  "id" : 271661002460913664,
  "created_at" : "2012-11-22 17:06:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271660673304502272",
  "text" : "have a good day peeps. see you later...",
  "id" : 271660673304502272,
  "created_at" : "2012-11-22 17:05:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271659861190770688",
  "text" : "breaks my heart to leave dog at home... normally she goes but small space, too many ppl and 2 wee ones... sigh...",
  "id" : 271659861190770688,
  "created_at" : "2012-11-22 17:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271659364178350082",
  "text" : "RT @ShipsofSong: Do not fear fear, for it is the fear of fear that empowers it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271658480732102659",
    "text" : "Do not fear fear, for it is the fear of fear that empowers it.",
    "id" : 271658480732102659,
    "created_at" : "2012-11-22 16:56:43 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 271659364178350082,
  "created_at" : "2012-11-22 17:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271659084288233472",
  "text" : "RT @atheistlady76: Happy Thanksgiving to all my tweeps. I'm thankful for each and every one of you. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271657986450128897",
    "text" : "Happy Thanksgiving to all my tweeps. I'm thankful for each and every one of you. :)",
    "id" : 271657986450128897,
    "created_at" : "2012-11-22 16:54:45 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 271659084288233472,
  "created_at" : "2012-11-22 16:59:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271655883073794048",
  "text" : "@1stCitizenKane : (",
  "id" : 271655883073794048,
  "created_at" : "2012-11-22 16:46:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notagoodidea",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271655552201940992",
  "text" : "why am i wearing jeans on thanksgiving?? lol #notagoodidea",
  "id" : 271655552201940992,
  "created_at" : "2012-11-22 16:45:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271645836839116800",
  "geo" : { },
  "id_str" : "271655278515216384",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker nice...",
  "id" : 271655278515216384,
  "in_reply_to_status_id" : 271645836839116800,
  "created_at" : "2012-11-22 16:44:00 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BETH WAREHAM",
      "screen_name" : "GiantSweetTart",
      "indices" : [ 3, 18 ],
      "id_str" : "154546567",
      "id" : 154546567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271655049648812032",
  "text" : "RT @GiantSweetTart: Go ahead, tell the internet. Tell it everything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222414843695730688",
    "text" : "Go ahead, tell the internet. Tell it everything.",
    "id" : 222414843695730688,
    "created_at" : "2012-07-09 19:40:05 +0000",
    "user" : {
      "name" : "BETH WAREHAM",
      "screen_name" : "GiantSweetTart",
      "protected" : false,
      "id_str" : "154546567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800440772256563200\/v2Hkv4aD_normal.jpg",
      "id" : 154546567,
      "verified" : false
    }
  },
  "id" : 271655049648812032,
  "created_at" : "2012-11-22 16:43:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "indices" : [ 3, 10 ],
      "id_str" : "18089695",
      "id" : 18089695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271654650963439617",
  "text" : "RT @rynedp: Gobble Gobble.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271651285713944576",
    "text" : "Gobble Gobble.",
    "id" : 271651285713944576,
    "created_at" : "2012-11-22 16:28:08 +0000",
    "user" : {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "protected" : false,
      "id_str" : "18089695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458711316874555392\/8GSsda5g_normal.jpeg",
      "id" : 18089695,
      "verified" : false
    }
  },
  "id" : 271654650963439617,
  "created_at" : "2012-11-22 16:41:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271642352836292608",
  "geo" : { },
  "id_str" : "271643329106677760",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 yup.. mine are pretty awesome, too. : )",
  "id" : 271643329106677760,
  "in_reply_to_status_id" : 271642352836292608,
  "created_at" : "2012-11-22 15:56:31 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 0, 15 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271640365486989312",
  "geo" : { },
  "id_str" : "271640992237629440",
  "in_reply_to_user_id" : 466879335,
  "text" : "@ThatOtherChris my DD approves this tweet..lol",
  "id" : 271640992237629440,
  "in_reply_to_status_id" : 271640365486989312,
  "created_at" : "2012-11-22 15:47:14 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271640773525655552",
  "text" : "my sis called last night, chatted my ear off for 2 hours..lol. she misses mom and dad terribly...",
  "id" : 271640773525655552,
  "created_at" : "2012-11-22 15:46:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271634753176879104",
  "text" : "you do know i dont like holidays, right??? ugh",
  "id" : 271634753176879104,
  "created_at" : "2012-11-22 15:22:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271431921270149120",
  "geo" : { },
  "id_str" : "271632063503941632",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i love the smell of fresh cut grass! &lt;3",
  "id" : 271632063503941632,
  "in_reply_to_status_id" : 271431921270149120,
  "created_at" : "2012-11-22 15:11:45 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271444636843769856",
  "text" : "RT @TheOracle13: I wish all of my Twitter Family a peaceful Thanksgiving.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271444331091619840",
    "text" : "I wish all of my Twitter Family a peaceful Thanksgiving.",
    "id" : 271444331091619840,
    "created_at" : "2012-11-22 02:45:46 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 271444636843769856,
  "created_at" : "2012-11-22 02:46:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271431146460573696",
  "geo" : { },
  "id_str" : "271431468776050689",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous sounds sooo cute..lol",
  "id" : 271431468776050689,
  "in_reply_to_status_id" : 271431146460573696,
  "created_at" : "2012-11-22 01:54:39 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271429804107112448",
  "geo" : { },
  "id_str" : "271430923281633280",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves you, too, Dwayne!",
  "id" : 271430923281633280,
  "in_reply_to_status_id" : 271429804107112448,
  "created_at" : "2012-11-22 01:52:29 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271429772830199808",
  "geo" : { },
  "id_str" : "271430694096482304",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny hope you have a good holiday tomorrow : )",
  "id" : 271430694096482304,
  "in_reply_to_status_id" : 271429772830199808,
  "created_at" : "2012-11-22 01:51:35 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271428260787785730",
  "text" : "RT @DharmaTalks: There is no boundary between you and those around you, yet we do not need to take in the drama others may generate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271427815600181248",
    "text" : "There is no boundary between you and those around you, yet we do not need to take in the drama others may generate",
    "id" : 271427815600181248,
    "created_at" : "2012-11-22 01:40:08 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 271428260787785730,
  "created_at" : "2012-11-22 01:41:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271425692003074048",
  "geo" : { },
  "id_str" : "271427993954570240",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous : )",
  "id" : 271427993954570240,
  "in_reply_to_status_id" : 271425692003074048,
  "created_at" : "2012-11-22 01:40:51 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271374076403130369",
  "geo" : { },
  "id_str" : "271377023006543873",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses my DD is like that, too.. she prefers being home and likes being w us.",
  "id" : 271377023006543873,
  "in_reply_to_status_id" : 271374076403130369,
  "created_at" : "2012-11-21 22:18:18 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 0, 12 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271365061950443521",
  "geo" : { },
  "id_str" : "271367471653584897",
  "in_reply_to_user_id" : 18694547,
  "text" : "@brandonrofl LOL",
  "id" : 271367471653584897,
  "in_reply_to_status_id" : 271365061950443521,
  "created_at" : "2012-11-21 21:40:21 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/M1LypiXO",
      "expanded_url" : "http:\/\/youtu.be\/qrq4gUm_Y8s",
      "display_url" : "youtu.be\/qrq4gUm_Y8s"
    } ]
  },
  "geo" : { },
  "id_str" : "271301210592645120",
  "text" : "SONGAHM STYLE (Music Video) \"Gangnam Style\" Parody: http:\/\/t.co\/M1LypiXO",
  "id" : 271301210592645120,
  "created_at" : "2012-11-21 17:17:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shay Stewart Bouley",
      "screen_name" : "blackgirlinmain",
      "indices" : [ 3, 19 ],
      "id_str" : "25178222",
      "id" : 25178222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271293142286876672",
  "text" : "RT @blackgirlinmain: I am not sure why we rush life, did we not all get the memo, that the end goal is death. So why do we rush living?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271283694164131840",
    "text" : "I am not sure why we rush life, did we not all get the memo, that the end goal is death. So why do we rush living?",
    "id" : 271283694164131840,
    "created_at" : "2012-11-21 16:07:27 +0000",
    "user" : {
      "name" : "Shay Stewart Bouley",
      "screen_name" : "blackgirlinmain",
      "protected" : false,
      "id_str" : "25178222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766397566061772801\/2jS-YuqS_normal.jpg",
      "id" : 25178222,
      "verified" : true
    }
  },
  "id" : 271293142286876672,
  "created_at" : "2012-11-21 16:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/JaCdgPD6",
      "expanded_url" : "http:\/\/via.me\/-756lrjs",
      "display_url" : "via.me\/-756lrjs"
    } ]
  },
  "geo" : { },
  "id_str" : "271289099116216320",
  "text" : "Love notes : ) http:\/\/t.co\/JaCdgPD6",
  "id" : 271289099116216320,
  "created_at" : "2012-11-21 16:28:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271268389211738114",
  "geo" : { },
  "id_str" : "271281513503551488",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous awww ((hugs))",
  "id" : 271281513503551488,
  "in_reply_to_status_id" : 271268389211738114,
  "created_at" : "2012-11-21 15:58:47 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271271150435323904",
  "text" : "im addicted to HGTV...",
  "id" : 271271150435323904,
  "created_at" : "2012-11-21 15:17:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271081751558889472",
  "geo" : { },
  "id_str" : "271084857399078913",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell oh she's cute! smooches, Annie! my DD has a black cat. she's an indoor baby, too.. except she does go on porch.",
  "id" : 271084857399078913,
  "in_reply_to_status_id" : 271081751558889472,
  "created_at" : "2012-11-21 02:57:21 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "HuffPost Science",
      "screen_name" : "HuffPostScience",
      "indices" : [ 116, 132 ],
      "id_str" : "195897346",
      "id" : 195897346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/4fmRp1T1",
      "expanded_url" : "http:\/\/huff.to\/100funI",
      "display_url" : "huff.to\/100funI"
    } ]
  },
  "geo" : { },
  "id_str" : "271077026478292992",
  "text" : "RT @gemswinc: MTv@goingthroughell: Gene Predicts Hour, but not Day of Death Study Suggests http:\/\/t.co\/4fmRp1T1 via @HuffPostScience\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Science",
        "screen_name" : "HuffPostScience",
        "indices" : [ 102, 118 ],
        "id_str" : "195897346",
        "id" : 195897346
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/4fmRp1T1",
        "expanded_url" : "http:\/\/huff.to\/100funI",
        "display_url" : "huff.to\/100funI"
      } ]
    },
    "geo" : { },
    "id_str" : "271076150502125568",
    "text" : "MTv@goingthroughell: Gene Predicts Hour, but not Day of Death Study Suggests http:\/\/t.co\/4fmRp1T1 via @HuffPostScience\u201D",
    "id" : 271076150502125568,
    "created_at" : "2012-11-21 02:22:45 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 271077026478292992,
  "created_at" : "2012-11-21 02:26:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271072524022976513",
  "geo" : { },
  "id_str" : "271075019990376449",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awwww",
  "id" : 271075019990376449,
  "in_reply_to_status_id" : 271072524022976513,
  "created_at" : "2012-11-21 02:18:15 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271071504559636481",
  "geo" : { },
  "id_str" : "271072204320563200",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell lol... im getting neurotic lately looking for my stray cat and possum.. making sure they get their food.. driving myself nuts!",
  "id" : 271072204320563200,
  "in_reply_to_status_id" : 271071504559636481,
  "created_at" : "2012-11-21 02:07:04 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271071039889477632",
  "text" : "i love it when possum comes by for a meal : ) sometimes i have to refill kibble after the raccoons (those little piggies..lol)",
  "id" : 271071039889477632,
  "created_at" : "2012-11-21 02:02:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271059095539290112",
  "geo" : { },
  "id_str" : "271062374117683201",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth ewwww...lol",
  "id" : 271062374117683201,
  "in_reply_to_status_id" : 271059095539290112,
  "created_at" : "2012-11-21 01:28:00 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271060034308411392",
  "geo" : { },
  "id_str" : "271062184082165761",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 LOL",
  "id" : 271062184082165761,
  "in_reply_to_status_id" : 271060034308411392,
  "created_at" : "2012-11-21 01:27:15 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271037484945797121",
  "geo" : { },
  "id_str" : "271038765009608705",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous screw the eyeglasses.. I want electronic eyes!!",
  "id" : 271038765009608705,
  "in_reply_to_status_id" : 271037484945797121,
  "created_at" : "2012-11-20 23:54:11 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271001443086000128",
  "text" : "watching ppl quibble over 2K in house deals making me boil.. ugh! just buy the damn house!",
  "id" : 271001443086000128,
  "created_at" : "2012-11-20 21:25:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270997478705336321",
  "text" : "tired of ppl spouting rules, etc. If i dont fit into your \"system\" just delete me!",
  "id" : 270997478705336321,
  "created_at" : "2012-11-20 21:10:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270979312562360322",
  "geo" : { },
  "id_str" : "270980161569161217",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth sounds like a great subject for a thesis paper or something like that..lol",
  "id" : 270980161569161217,
  "in_reply_to_status_id" : 270979312562360322,
  "created_at" : "2012-11-20 20:01:19 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    }, {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 122, 136 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270978921577717760",
  "geo" : { },
  "id_str" : "270979628020166656",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth yeah.. the claim part is weird. my gut tells me there is some divine order to the world but i cant prove. @atheistlady76",
  "id" : 270979628020166656,
  "in_reply_to_status_id" : 270978921577717760,
  "created_at" : "2012-11-20 19:59:12 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270977318225313792",
  "geo" : { },
  "id_str" : "270978426125578240",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker sounds like a fun adventure! lol",
  "id" : 270978426125578240,
  "in_reply_to_status_id" : 270977318225313792,
  "created_at" : "2012-11-20 19:54:25 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 72, 87 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gnostic",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Gs0n3NJq",
      "expanded_url" : "http:\/\/blog.beliefnet.com\/areasontosmile\/2011\/11\/gnostic-theism-or-digital-spirituality.html",
      "display_url" : "blog.beliefnet.com\/areasontosmile\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "270976674215124992",
  "geo" : { },
  "id_str" : "270978242729607168",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 huh, seems thats where i am i think http:\/\/t.co\/Gs0n3NJq @LoveHonorTruth #gnostic theist",
  "id" : 270978242729607168,
  "in_reply_to_status_id" : 270976674215124992,
  "created_at" : "2012-11-20 19:53:42 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 74, 89 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270974523250208768",
  "geo" : { },
  "id_str" : "270976192138596353",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 gnostic theist.. why stupidly? (im looking it up now..lol) @LoveHonorTruth",
  "id" : 270976192138596353,
  "in_reply_to_status_id" : 270974523250208768,
  "created_at" : "2012-11-20 19:45:33 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270972262751014913",
  "geo" : { },
  "id_str" : "270972568943595520",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker thats a house? looks like office building. too contemporary for me..lol",
  "id" : 270972568943595520,
  "in_reply_to_status_id" : 270972262751014913,
  "created_at" : "2012-11-20 19:31:09 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270970643565121536",
  "geo" : { },
  "id_str" : "270971702417170432",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth welllll.. i disagree. i think ppl can be in the middle not feeling strongly one way or another. it's a shade of gray.",
  "id" : 270971702417170432,
  "in_reply_to_status_id" : 270970643565121536,
  "created_at" : "2012-11-20 19:27:42 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270969430069092352",
  "geo" : { },
  "id_str" : "270970991881117697",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen thank you, martijn. i have to find a job or way to make income. but as an unskilled introvert? sigh.",
  "id" : 270970991881117697,
  "in_reply_to_status_id" : 270969430069092352,
  "created_at" : "2012-11-20 19:24:53 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270968900542398464",
  "text" : "he's a good man and deserves better than this life...",
  "id" : 270968900542398464,
  "created_at" : "2012-11-20 19:16:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270968100449562625",
  "text" : "prayers for finances appreciated. hubby's half a paycheck in the hole o-O",
  "id" : 270968100449562625,
  "created_at" : "2012-11-20 19:13:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    }, {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 15, 30 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/9RbrrYD4",
      "expanded_url" : "http:\/\/wh.gov\/XAVa",
      "display_url" : "wh.gov\/XAVa"
    } ]
  },
  "geo" : { },
  "id_str" : "270927157990150146",
  "text" : "RT @ShhDragon: @stevetheseeker \nconsider this:\nCreate a permanent cabinet-level Department of Peace. http:\/\/t.co\/9RbrrYD4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Larsen",
        "screen_name" : "stevetheseeker",
        "indices" : [ 0, 15 ],
        "id_str" : "23193505",
        "id" : 23193505
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/9RbrrYD4",
        "expanded_url" : "http:\/\/wh.gov\/XAVa",
        "display_url" : "wh.gov\/XAVa"
      } ]
    },
    "in_reply_to_status_id_str" : "270924090519474176",
    "geo" : { },
    "id_str" : "270924494141534208",
    "in_reply_to_user_id" : 23193505,
    "text" : "@stevetheseeker \nconsider this:\nCreate a permanent cabinet-level Department of Peace. http:\/\/t.co\/9RbrrYD4",
    "id" : 270924494141534208,
    "in_reply_to_status_id" : 270924090519474176,
    "created_at" : "2012-11-20 16:20:07 +0000",
    "in_reply_to_screen_name" : "stevetheseeker",
    "in_reply_to_user_id_str" : "23193505",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 270927157990150146,
  "created_at" : "2012-11-20 16:30:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270918329647124480",
  "text" : "personally \"health insurance\" goes against my \"religion\"",
  "id" : 270918329647124480,
  "created_at" : "2012-11-20 15:55:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayor",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270917658411692032",
  "text" : "health care should not be linked w employment! #singlepayor",
  "id" : 270917658411692032,
  "created_at" : "2012-11-20 15:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/f6Q1HLSN",
      "expanded_url" : "http:\/\/www.facebook.com\/photo.php?v=10151172212251185",
      "display_url" : "facebook.com\/photo.php?v=10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270915789719216128",
  "text" : "oh that face! : ) &gt;&gt; Update on burn raccoon: http:\/\/t.co\/f6Q1HLSN",
  "id" : 270915789719216128,
  "created_at" : "2012-11-20 15:45:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270710082684190720",
  "geo" : { },
  "id_str" : "270710875751600129",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 you're so cruel to post that pic! ((drooling))",
  "id" : 270710875751600129,
  "in_reply_to_status_id" : 270710082684190720,
  "created_at" : "2012-11-20 02:11:17 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270689822031626240",
  "geo" : { },
  "id_str" : "270691122160992256",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 how's your tummy? i'd say tea...",
  "id" : 270691122160992256,
  "in_reply_to_status_id" : 270689822031626240,
  "created_at" : "2012-11-20 00:52:47 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bringnickhome",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270684775398924288",
  "text" : "@zen_kitty november... and you still dont have your kid back!!! since may, right? CRAZY and so so so wrong! ((hugs)) #bringnickhome",
  "id" : 270684775398924288,
  "created_at" : "2012-11-20 00:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270669736017285120",
  "geo" : { },
  "id_str" : "270672494116102144",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench ohh that looks good! yum!",
  "id" : 270672494116102144,
  "in_reply_to_status_id" : 270669736017285120,
  "created_at" : "2012-11-19 23:38:46 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270670301845671937",
  "geo" : { },
  "id_str" : "270671544647303168",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld i saw part of it.. scary...",
  "id" : 270671544647303168,
  "in_reply_to_status_id" : 270670301845671937,
  "created_at" : "2012-11-19 23:34:59 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270668780496109568",
  "geo" : { },
  "id_str" : "270669538373271554",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld except 4 my teeth acting up, i am good. poor hubs tho, seems to be working 24\/7 these days (property caretaker)",
  "id" : 270669538373271554,
  "in_reply_to_status_id" : 270668780496109568,
  "created_at" : "2012-11-19 23:27:01 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 0, 14 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270668360084234240",
  "geo" : { },
  "id_str" : "270669020343201794",
  "in_reply_to_user_id" : 28863804,
  "text" : "@Wylieknowords i usually dont get many RT or comments.. but ive noticed twitter sometimes \"holding\" tweets",
  "id" : 270669020343201794,
  "in_reply_to_status_id" : 270668360084234240,
  "created_at" : "2012-11-19 23:24:57 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270668225891667968",
  "text" : "RT @Buddhaworld: The only difference in people is there screwed up mind. When are u gonna learn it starts :n our heads?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270666670970920963",
    "text" : "The only difference in people is there screwed up mind. When are u gonna learn it starts :n our heads?",
    "id" : 270666670970920963,
    "created_at" : "2012-11-19 23:15:37 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 270668225891667968,
  "created_at" : "2012-11-19 23:21:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uniquelyqualified",
      "indices" : [ 72, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270664803083771904",
  "geo" : { },
  "id_str" : "270666183500525571",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny ive heard that expression WAY too much the past few months #uniquelyqualified .. plz never use it again, pretty plz?",
  "id" : 270666183500525571,
  "in_reply_to_status_id" : 270664803083771904,
  "created_at" : "2012-11-19 23:13:41 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 70, 85 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270649108853837826",
  "geo" : { },
  "id_str" : "270663656155512832",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 huh.. always thought it was the gay ppl's fault... ; ) @LoveHonorTruth",
  "id" : 270663656155512832,
  "in_reply_to_status_id" : 270649108853837826,
  "created_at" : "2012-11-19 23:03:38 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270650032968048640",
  "geo" : { },
  "id_str" : "270663168852889600",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 oh god, me, too. been having tooth pain and i remind myself \"could be worse, could be nauseaous\" ((hugs))",
  "id" : 270663168852889600,
  "in_reply_to_status_id" : 270650032968048640,
  "created_at" : "2012-11-19 23:01:42 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270652062050709504",
  "geo" : { },
  "id_str" : "270661962923401216",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 : ( its all downhill after 30..",
  "id" : 270661962923401216,
  "in_reply_to_status_id" : 270652062050709504,
  "created_at" : "2012-11-19 22:56:55 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270653640174358528",
  "geo" : { },
  "id_str" : "270661257592463362",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth i think it does. christmas is christmas. some ppl celebrate it w a religious perspective, some w secular.",
  "id" : 270661257592463362,
  "in_reply_to_status_id" : 270653640174358528,
  "created_at" : "2012-11-19 22:54:07 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 0, 10 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270654386856923136",
  "geo" : { },
  "id_str" : "270660654694793216",
  "in_reply_to_user_id" : 15572724,
  "text" : "@ShhDragon how is my boy Saki? give him smooches from me!",
  "id" : 270660654694793216,
  "in_reply_to_status_id" : 270654386856923136,
  "created_at" : "2012-11-19 22:51:43 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/dgwevC5Z",
      "expanded_url" : "http:\/\/WhiteHouse.gov",
      "display_url" : "WhiteHouse.gov"
    }, {
      "indices" : [ 79, 100 ],
      "url" : "https:\/\/t.co\/SoeZM72z",
      "expanded_url" : "https:\/\/petitions.whitehouse.gov\/petition\/create-permanent-cabinet-level-department-peace\/1Z3JQyJN",
      "display_url" : "petitions.whitehouse.gov\/petition\/creat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270660503083294721",
  "text" : "RT @ShhDragon: My petition on http:\/\/t.co\/dgwevC5Z to create a Dept. of Peace.\nhttps:\/\/t.co\/SoeZM72z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/dgwevC5Z",
        "expanded_url" : "http:\/\/WhiteHouse.gov",
        "display_url" : "WhiteHouse.gov"
      }, {
        "indices" : [ 64, 85 ],
        "url" : "https:\/\/t.co\/SoeZM72z",
        "expanded_url" : "https:\/\/petitions.whitehouse.gov\/petition\/create-permanent-cabinet-level-department-peace\/1Z3JQyJN",
        "display_url" : "petitions.whitehouse.gov\/petition\/creat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "270654386856923136",
    "text" : "My petition on http:\/\/t.co\/dgwevC5Z to create a Dept. of Peace.\nhttps:\/\/t.co\/SoeZM72z",
    "id" : 270654386856923136,
    "created_at" : "2012-11-19 22:26:49 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 270660503083294721,
  "created_at" : "2012-11-19 22:51:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270655510431293441",
  "geo" : { },
  "id_str" : "270660234178072578",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth LOLOL",
  "id" : 270660234178072578,
  "in_reply_to_status_id" : 270655510431293441,
  "created_at" : "2012-11-19 22:50:03 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270655751620542465",
  "geo" : { },
  "id_str" : "270660072412160001",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray interesting. rat with a paint brush? and funny way to spell ART? like it.",
  "id" : 270660072412160001,
  "in_reply_to_status_id" : 270655751620542465,
  "created_at" : "2012-11-19 22:49:24 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270639626019024897",
  "geo" : { },
  "id_str" : "270640244309757953",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 ick. hope no more emesis. feel better!",
  "id" : 270640244309757953,
  "in_reply_to_status_id" : 270639626019024897,
  "created_at" : "2012-11-19 21:30:37 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270631545579130880",
  "text" : "income property guy is hot, too..lol",
  "id" : 270631545579130880,
  "created_at" : "2012-11-19 20:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 86, 95 ],
      "id_str" : "352053266",
      "id" : 352053266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinkagain",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 143 ],
      "url" : "https:\/\/t.co\/5JtamULN",
      "expanded_url" : "https:\/\/www.coursera.org\/course\/thinkagain",
      "display_url" : "coursera.org\/course\/thinkag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270630857100890112",
  "text" : "starts mon nov 26! &gt;&gt; Think Again: How to Reason and Argue #thinkagain - a free @coursera online class. Join me at  https:\/\/t.co\/5JtamULN",
  "id" : 270630857100890112,
  "created_at" : "2012-11-19 20:53:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270619816551936000",
  "text" : "@SamsaricWarrior it's awesome!",
  "id" : 270619816551936000,
  "created_at" : "2012-11-19 20:09:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270615052657258496",
  "text" : "RT @UndertheNeonSky: Try viewing everyone who comes into your life as a teacher.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270614515123646464",
    "text" : "Try viewing everyone who comes into your life as a teacher.",
    "id" : 270614515123646464,
    "created_at" : "2012-11-19 19:48:22 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 270615052657258496,
  "created_at" : "2012-11-19 19:50:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Emrys",
      "screen_name" : "merlinemrys66",
      "indices" : [ 0, 14 ],
      "id_str" : "937393992",
      "id" : 937393992
    }, {
      "name" : "VJH",
      "screen_name" : "vickiehenshaw",
      "indices" : [ 74, 88 ],
      "id_str" : "766929900",
      "id" : 766929900
    }, {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 89, 103 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270602168145412096",
  "geo" : { },
  "id_str" : "270602957735751680",
  "in_reply_to_user_id" : 937393992,
  "text" : "@merlinemrys66 lol.. no worries. ive reserved a spot for you in MY heaven @vickiehenshaw @atheistlady76",
  "id" : 270602957735751680,
  "in_reply_to_status_id" : 270602168145412096,
  "created_at" : "2012-11-19 19:02:27 +0000",
  "in_reply_to_screen_name" : "merlinemrys66",
  "in_reply_to_user_id_str" : "937393992",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Emrys",
      "screen_name" : "merlinemrys66",
      "indices" : [ 0, 14 ],
      "id_str" : "937393992",
      "id" : 937393992
    }, {
      "name" : "VJH",
      "screen_name" : "vickiehenshaw",
      "indices" : [ 95, 109 ],
      "id_str" : "766929900",
      "id" : 766929900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270600918733565953",
  "geo" : { },
  "id_str" : "270601782290444288",
  "in_reply_to_user_id" : 937393992,
  "text" : "@merlinemrys66 not a physical one, silly..lol. my heart is what tells me you're a good egg ; ) @vickiehenshaw",
  "id" : 270601782290444288,
  "in_reply_to_status_id" : 270600918733565953,
  "created_at" : "2012-11-19 18:57:47 +0000",
  "in_reply_to_screen_name" : "merlinemrys66",
  "in_reply_to_user_id_str" : "937393992",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youcanbreathenow",
      "indices" : [ 13, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270599508235280384",
  "geo" : { },
  "id_str" : "270600464373002240",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings #youcanbreathenow &lt;&lt; yup! i was holding my breath...",
  "id" : 270600464373002240,
  "in_reply_to_status_id" : 270599508235280384,
  "created_at" : "2012-11-19 18:52:32 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "VJH",
      "screen_name" : "vickiehenshaw",
      "indices" : [ 67, 81 ],
      "id_str" : "766929900",
      "id" : 766929900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270592939682566145",
  "geo" : { },
  "id_str" : "270596945586831360",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i agree w vicki on this one... follow your heart! : ) @vickiehenshaw",
  "id" : 270596945586831360,
  "in_reply_to_status_id" : 270592939682566145,
  "created_at" : "2012-11-19 18:38:33 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socool",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270565095887732738",
  "geo" : { },
  "id_str" : "270565720390246400",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny we are one w everything! : ) its all connected... #socool",
  "id" : 270565720390246400,
  "in_reply_to_status_id" : 270565095887732738,
  "created_at" : "2012-11-19 16:34:29 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270563581798518785",
  "text" : "meth raccoon is doing better. he should  make a good recovery! : )",
  "id" : 270563581798518785,
  "created_at" : "2012-11-19 16:25:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freeeducation",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270562821870342145",
  "text" : "WTF are textbooks sooo expensive?? #freeeducation",
  "id" : 270562821870342145,
  "created_at" : "2012-11-19 16:22:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 10, 24 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/V4iEnOG1",
      "expanded_url" : "http:\/\/huff.to\/RODxkU",
      "display_url" : "huff.to\/RODxkU"
    } ]
  },
  "in_reply_to_status_id_str" : "270562105374171137",
  "geo" : { },
  "id_str" : "270562455086837762",
  "in_reply_to_user_id" : 125567504,
  "text" : "Nooo!! RT @HuffPostWeird San Francisco may ban public nudity once and for all http:\/\/t.co\/V4iEnOG1",
  "id" : 270562455086837762,
  "in_reply_to_status_id" : 270562105374171137,
  "created_at" : "2012-11-19 16:21:30 +0000",
  "in_reply_to_screen_name" : "HuffPostWeird",
  "in_reply_to_user_id_str" : "125567504",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "VJH",
      "screen_name" : "vickiehenshaw",
      "indices" : [ 47, 61 ],
      "id_str" : "766929900",
      "id" : 766929900
    }, {
      "name" : "Cinnanun",
      "screen_name" : "notcreative388",
      "indices" : [ 62, 77 ],
      "id_str" : "272659909",
      "id" : 272659909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270560354365501440",
  "text" : "RT @VirgoJohnny: Why can't you be rational? RT @vickiehenshaw @notcreative388 Why can't u believe?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VJH",
        "screen_name" : "vickiehenshaw",
        "indices" : [ 30, 44 ],
        "id_str" : "766929900",
        "id" : 766929900
      }, {
        "name" : "Cinnanun",
        "screen_name" : "notcreative388",
        "indices" : [ 45, 60 ],
        "id_str" : "272659909",
        "id" : 272659909
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "270558013104988161",
    "geo" : { },
    "id_str" : "270559042898915329",
    "in_reply_to_user_id" : 766929900,
    "text" : "Why can't you be rational? RT @vickiehenshaw @notcreative388 Why can't u believe?",
    "id" : 270559042898915329,
    "in_reply_to_status_id" : 270558013104988161,
    "created_at" : "2012-11-19 16:07:57 +0000",
    "in_reply_to_screen_name" : "vickiehenshaw",
    "in_reply_to_user_id_str" : "766929900",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 270560354365501440,
  "created_at" : "2012-11-19 16:13:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270559042898915329",
  "geo" : { },
  "id_str" : "270560293233491968",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny lol. im not good at doing rational... ; )",
  "id" : 270560293233491968,
  "in_reply_to_status_id" : 270559042898915329,
  "created_at" : "2012-11-19 16:12:55 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270559744496918529",
  "text" : "@Skeptical_Lady lets have Mystery Gift Day instead! : )",
  "id" : 270559744496918529,
  "created_at" : "2012-11-19 16:10:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270547510685229057",
  "text" : "frankly, i dont care about morals, ethics, etc. i just want yummy stuff to eat and be entertained and have no pain.",
  "id" : 270547510685229057,
  "created_at" : "2012-11-19 15:22:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne K Wellings",
      "screen_name" : "AnneKatwoman",
      "indices" : [ 0, 13 ],
      "id_str" : "799727408",
      "id" : 799727408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270345476879048706",
  "geo" : { },
  "id_str" : "270529041763803136",
  "in_reply_to_user_id" : 799727408,
  "text" : "@AnneKatwoman we've sprayed her hot spots w medicated spray B4 and we have to tackle her to do it..lol. i think its the spray noise...",
  "id" : 270529041763803136,
  "in_reply_to_status_id" : 270345476879048706,
  "created_at" : "2012-11-19 14:08:44 +0000",
  "in_reply_to_screen_name" : "AnneKatwoman",
  "in_reply_to_user_id_str" : "799727408",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/MSjuhYsh",
      "expanded_url" : "http:\/\/bit.ly\/TSvK5A",
      "display_url" : "bit.ly\/TSvK5A"
    } ]
  },
  "geo" : { },
  "id_str" : "270355816815673345",
  "text" : "RT @FreeRangeKids: Unsupervised children overpower helpless dog, play with him for hours. http:\/\/t.co\/MSjuhYsh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/MSjuhYsh",
        "expanded_url" : "http:\/\/bit.ly\/TSvK5A",
        "display_url" : "bit.ly\/TSvK5A"
      } ]
    },
    "geo" : { },
    "id_str" : "270354341687332864",
    "text" : "Unsupervised children overpower helpless dog, play with him for hours. http:\/\/t.co\/MSjuhYsh",
    "id" : 270354341687332864,
    "created_at" : "2012-11-19 02:34:32 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 270355816815673345,
  "created_at" : "2012-11-19 02:40:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270322805105651714",
  "text" : "dog dove under sofa when i came in room w spray bottle (to clean up spilled coffee) .. lol",
  "id" : 270322805105651714,
  "created_at" : "2012-11-19 00:29:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senryu",
      "indices" : [ 72, 79 ]
    }, {
      "text" : "haiku",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270279509272580097",
  "text" : "RT @CoyoteSings: I skip church \u2022 to sit in an empty pew \u2022 in the park | #senryu #haiku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "senryu",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "haiku",
        "indices" : [ 63, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270278864561917952",
    "text" : "I skip church \u2022 to sit in an empty pew \u2022 in the park | #senryu #haiku",
    "id" : 270278864561917952,
    "created_at" : "2012-11-18 21:34:37 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 270279509272580097,
  "created_at" : "2012-11-18 21:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270278735285088258",
  "text" : "RT @AnnotatedBible: Do you prefer the NIV, ESV, NASB, NLT, NRSV, or NET Bible? Out of those, which do you use? Comment here on why: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bible",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/W8U2sY6F",
        "expanded_url" : "http:\/\/fusiontheism.blogspot.com\/2012\/11\/the-scriptures.html?m=0",
        "display_url" : "fusiontheism.blogspot.com\/2012\/11\/the-sc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "270271488911884288",
    "text" : "Do you prefer the NIV, ESV, NASB, NLT, NRSV, or NET Bible? Out of those, which do you use? Comment here on why: http:\/\/t.co\/W8U2sY6F #Bible",
    "id" : 270271488911884288,
    "created_at" : "2012-11-18 21:05:19 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 270278735285088258,
  "created_at" : "2012-11-18 21:34:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270263391770259456",
  "text" : "rehab i follow on FB got raccoon from  meth lab. poor thing was high, burnt feet from walking thru chems. : (",
  "id" : 270263391770259456,
  "created_at" : "2012-11-18 20:33:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270258951608745984",
  "geo" : { },
  "id_str" : "270261299185864704",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker cool idea.. i like it!",
  "id" : 270261299185864704,
  "in_reply_to_status_id" : 270258951608745984,
  "created_at" : "2012-11-18 20:24:49 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270256484665933825",
  "text" : "oh god.. its christmas village time..",
  "id" : 270256484665933825,
  "created_at" : "2012-11-18 20:05:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270245012577587200",
  "text" : "RT @damienechols: I'm writing my new book entirely on my iPhone, using that little note pad app. \n\nNot joking.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270239142074515457",
    "text" : "I'm writing my new book entirely on my iPhone, using that little note pad app. \n\nNot joking.",
    "id" : 270239142074515457,
    "created_at" : "2012-11-18 18:56:46 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 270245012577587200,
  "created_at" : "2012-11-18 19:20:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Picture",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/8y6UqABr",
      "expanded_url" : "http:\/\/i.imgur.com\/wiShE.png",
      "display_url" : "i.imgur.com\/wiShE.png"
    } ]
  },
  "geo" : { },
  "id_str" : "270217414304751617",
  "text" : "RT @UnseeingEyes: What do you see, a Rooster or Map? http:\/\/t.co\/8y6UqABr #Picture",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Picture",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/8y6UqABr",
        "expanded_url" : "http:\/\/i.imgur.com\/wiShE.png",
        "display_url" : "i.imgur.com\/wiShE.png"
      } ]
    },
    "geo" : { },
    "id_str" : "270215396647387137",
    "text" : "What do you see, a Rooster or Map? http:\/\/t.co\/8y6UqABr #Picture",
    "id" : 270215396647387137,
    "created_at" : "2012-11-18 17:22:25 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 270217414304751617,
  "created_at" : "2012-11-18 17:30:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "indices" : [ 3, 19 ],
      "id_str" : "478216296",
      "id" : 478216296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270189833358548992",
  "text" : "RT @JesusWithIssues: It's a WHOLE day people! With sun coming up and everything. Also, I will throw in a free sunset.  Act now!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270189444957626368",
    "text" : "It's a WHOLE day people! With sun coming up and everything. Also, I will throw in a free sunset.  Act now!",
    "id" : 270189444957626368,
    "created_at" : "2012-11-18 15:39:18 +0000",
    "user" : {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "protected" : false,
      "id_str" : "478216296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2229020646\/jesus_leopard_normal.jpg",
      "id" : 478216296,
      "verified" : false
    }
  },
  "id" : 270189833358548992,
  "created_at" : "2012-11-18 15:40:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270186165129334785",
  "text" : "the chickadees are hysterical.. all the hopping, wing-flapping \"fear me!\" lol",
  "id" : 270186165129334785,
  "created_at" : "2012-11-18 15:26:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270173570569752576",
  "geo" : { },
  "id_str" : "270185750451085312",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray awwww! : )",
  "id" : 270185750451085312,
  "in_reply_to_status_id" : 270173570569752576,
  "created_at" : "2012-11-18 15:24:37 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheOffice",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/r1vtmqKF",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Kelly_Kapoor",
      "display_url" : "en.wikipedia.org\/wiki\/Kelly_Kap\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "269979514459791361",
  "geo" : { },
  "id_str" : "269980522070028288",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses #TheOffice http:\/\/t.co\/r1vtmqKF",
  "id" : 269980522070028288,
  "in_reply_to_status_id" : 269979514459791361,
  "created_at" : "2012-11-18 01:49:07 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269980066337931264",
  "text" : "RT @TheOracle13: Accept and detach. Repeat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269978369544843265",
    "text" : "Accept and detach. Repeat.",
    "id" : 269978369544843265,
    "created_at" : "2012-11-18 01:40:33 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 269980066337931264,
  "created_at" : "2012-11-18 01:47:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269978566740029441",
  "geo" : { },
  "id_str" : "269979988948828160",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields yeah, im not crazy about those...",
  "id" : 269979988948828160,
  "in_reply_to_status_id" : 269978566740029441,
  "created_at" : "2012-11-18 01:47:00 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269975666500448257",
  "text" : "RT @Silvercrone: Does not tomorrow begin now? Each act can be one of improvement no matter how small the step-it is a beginning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269974958346743808",
    "text" : "Does not tomorrow begin now? Each act can be one of improvement no matter how small the step-it is a beginning.",
    "id" : 269974958346743808,
    "created_at" : "2012-11-18 01:27:00 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 269975666500448257,
  "created_at" : "2012-11-18 01:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269955261723209728",
  "text" : "RT @JALpalyul: You have to cultivate such compassion that your enemy becomes exactly the same weight as your friend.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269954654333435904",
    "text" : "You have to cultivate such compassion that your enemy becomes exactly the same weight as your friend.",
    "id" : 269954654333435904,
    "created_at" : "2012-11-18 00:06:19 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 269955261723209728,
  "created_at" : "2012-11-18 00:08:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl",
      "screen_name" : "MiHeart_Speaks",
      "indices" : [ 3, 18 ],
      "id_str" : "1140861931",
      "id" : 1140861931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269954885888385024",
  "text" : "RT @MiHeart_Speaks: Some battles aren't meant to be won, some are meant for you to learn from them",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitdrip.com\" rel=\"nofollow\"\u003ETwitDrip\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269951822238740480",
    "text" : "Some battles aren't meant to be won, some are meant for you to learn from them",
    "id" : 269951822238740480,
    "created_at" : "2012-11-17 23:55:04 +0000",
    "user" : {
      "name" : "What Girls Want \uD83D\uDC8B",
      "screen_name" : "TheBossGirls",
      "protected" : false,
      "id_str" : "173727516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782326316548796416\/kbkKwucO_normal.jpg",
      "id" : 173727516,
      "verified" : false
    }
  },
  "id" : 269954885888385024,
  "created_at" : "2012-11-18 00:07:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269948578674405377",
  "text" : "RT @CoyoteSings: \"The coyote killing 'contest' being hosted this weekend by Gunhawk Firearms in Los Lunas is a disgrace...\" http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coyote",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/l8KzHSkt",
        "expanded_url" : "http:\/\/www.abqjournal.com\/main\/2012\/11\/15\/opinion\/slaughter-of-coyotes-an-abomination-against-nature.html",
        "display_url" : "abqjournal.com\/main\/2012\/11\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "269947675758190593",
    "text" : "\"The coyote killing 'contest' being hosted this weekend by Gunhawk Firearms in Los Lunas is a disgrace...\" http:\/\/t.co\/l8KzHSkt #coyote",
    "id" : 269947675758190593,
    "created_at" : "2012-11-17 23:38:35 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 269948578674405377,
  "created_at" : "2012-11-17 23:42:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269935645840011264",
  "geo" : { },
  "id_str" : "269937871648063488",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny now i know where you live... muhahaha ; )",
  "id" : 269937871648063488,
  "in_reply_to_status_id" : 269935645840011264,
  "created_at" : "2012-11-17 22:59:38 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269920019717189634",
  "text" : "no official tylenol at cvs so hubby got cvs acetaminophen.. WITH sleep aid.. no plain..lol",
  "id" : 269920019717189634,
  "created_at" : "2012-11-17 21:48:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sosensitive",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269919274414514176",
  "text" : "17yo DD touched hot glass pan w chicken. it fell on floor and broke. she starts crying! #sosensitive",
  "id" : 269919274414514176,
  "created_at" : "2012-11-17 21:45:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269909942574645248",
  "geo" : { },
  "id_str" : "269916085686521856",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt ((hugs))",
  "id" : 269916085686521856,
  "in_reply_to_status_id" : 269909942574645248,
  "created_at" : "2012-11-17 21:33:04 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269914255048994816",
  "text" : "hubby's off to get my tylenol and then dinner soon. watching the property brothers.. cool show, hot guys..lol",
  "id" : 269914255048994816,
  "created_at" : "2012-11-17 21:25:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Budget",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269907510322950144",
  "text" : "RT @SenSanders: Corporations today are making record profits while their effective tax rate is at or near a 60-year low. #Budget #Fiscal ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Budget",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "FiscalCliff",
        "indices" : [ 113, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269907316109897728",
    "text" : "Corporations today are making record profits while their effective tax rate is at or near a 60-year low. #Budget #FiscalCliff",
    "id" : 269907316109897728,
    "created_at" : "2012-11-17 20:58:13 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 269907510322950144,
  "created_at" : "2012-11-17 20:58:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magic Laura",
      "screen_name" : "LauraShezBar",
      "indices" : [ 3, 16 ],
      "id_str" : "376402312",
      "id" : 376402312
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 27, 38 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269907271583154176",
  "text" : "RT @LauraShezBar: Actually @MittRomney dental care SHOULD be covered under health care cause lack of dental care can cause many medical  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 9, 20 ],
        "id_str" : "50055701",
        "id" : 50055701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269906578260508672",
    "text" : "Actually @MittRomney dental care SHOULD be covered under health care cause lack of dental care can cause many medical problems",
    "id" : 269906578260508672,
    "created_at" : "2012-11-17 20:55:17 +0000",
    "user" : {
      "name" : "Magic Laura",
      "screen_name" : "LauraShezBar",
      "protected" : false,
      "id_str" : "376402312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695050742818856960\/IxafbJye_normal.jpg",
      "id" : 376402312,
      "verified" : false
    }
  },
  "id" : 269907271583154176,
  "created_at" : "2012-11-17 20:58:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appoday",
      "screen_name" : "appoday",
      "indices" : [ 3, 11 ],
      "id_str" : "480327055",
      "id" : 480327055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269894605653278721",
  "text" : "RT @appoday: Life is but a mystery, said some wise person - Get Disney's Blackwood and Bell Mysteries TODAY via Appoday (SAVE $4.99) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/PEzFJsod",
        "expanded_url" : "http:\/\/bit.ly\/ThJHtJ",
        "display_url" : "bit.ly\/ThJHtJ"
      } ]
    },
    "geo" : { },
    "id_str" : "269892714257080320",
    "text" : "Life is but a mystery, said some wise person - Get Disney's Blackwood and Bell Mysteries TODAY via Appoday (SAVE $4.99) http:\/\/t.co\/PEzFJsod",
    "id" : 269892714257080320,
    "created_at" : "2012-11-17 20:00:12 +0000",
    "user" : {
      "name" : "Appoday",
      "screen_name" : "appoday",
      "protected" : false,
      "id_str" : "480327055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1850118594\/Twitter_icon_normal.png",
      "id" : 480327055,
      "verified" : true
    }
  },
  "id" : 269894605653278721,
  "created_at" : "2012-11-17 20:07:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Melissa Penta",
      "screen_name" : "mydigitalmind",
      "indices" : [ 17, 31 ],
      "id_str" : "15259604",
      "id" : 15259604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "birding",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "photography",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/Nqt4VkXE",
      "expanded_url" : "http:\/\/flic.kr\/p\/dpSnRP",
      "display_url" : "flic.kr\/p\/dpSnRP"
    } ]
  },
  "geo" : { },
  "id_str" : "269892334123102208",
  "text" : "RT @KerriFar: RT @mydigitalmind: Eastern Bluebird on Sumac #birds #birding #wildlife #photography http:\/\/t.co\/Nqt4VkXE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa Penta",
        "screen_name" : "mydigitalmind",
        "indices" : [ 3, 17 ],
        "id_str" : "15259604",
        "id" : 15259604
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "birding",
        "indices" : [ 52, 60 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 61, 70 ]
      }, {
        "text" : "photography",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/Nqt4VkXE",
        "expanded_url" : "http:\/\/flic.kr\/p\/dpSnRP",
        "display_url" : "flic.kr\/p\/dpSnRP"
      } ]
    },
    "geo" : { },
    "id_str" : "269887663228723203",
    "text" : "RT @mydigitalmind: Eastern Bluebird on Sumac #birds #birding #wildlife #photography http:\/\/t.co\/Nqt4VkXE",
    "id" : 269887663228723203,
    "created_at" : "2012-11-17 19:40:07 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 269892334123102208,
  "created_at" : "2012-11-17 19:58:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/GfRDBqg1",
      "expanded_url" : "http:\/\/www.knowords.com",
      "display_url" : "knowords.com"
    } ]
  },
  "geo" : { },
  "id_str" : "269885939390746624",
  "text" : "RT @Wylieknowords: ATTENTION RICH &amp; FAMOUS FOLLOWERS: If you want to write a blurb for my book: http:\/\/t.co\/GfRDBqg1, I will charge  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/GfRDBqg1",
        "expanded_url" : "http:\/\/www.knowords.com",
        "display_url" : "knowords.com"
      } ]
    },
    "geo" : { },
    "id_str" : "269885688625909760",
    "text" : "ATTENTION RICH &amp; FAMOUS FOLLOWERS: If you want to write a blurb for my book: http:\/\/t.co\/GfRDBqg1, I will charge you no fee for doing it.",
    "id" : 269885688625909760,
    "created_at" : "2012-11-17 19:32:17 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 269885939390746624,
  "created_at" : "2012-11-17 19:33:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 3, 18 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269876975605256193",
  "text" : "RT @JulianneGarska: Me: \"I'm a ninja!\" Friend: \"No you're not.\" Me: \"Did you see that!?\" Friend: \"See what?\" Me: \"Exactly.\" -- Funny Twe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laughing",
        "screen_name" : "ComedyTruth",
        "indices" : [ 121, 133 ],
        "id_str" : "102862303",
        "id" : 102862303
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269873508719415297",
    "text" : "Me: \"I'm a ninja!\" Friend: \"No you're not.\" Me: \"Did you see that!?\" Friend: \"See what?\" Me: \"Exactly.\" -- Funny Tweets (@ComedyTruth)",
    "id" : 269873508719415297,
    "created_at" : "2012-11-17 18:43:53 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 269876975605256193,
  "created_at" : "2012-11-17 18:57:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269869872891174914",
  "text" : "looks like mrs hairy woodpecker back at feeder.. so she's ok! : ) wish i got pic of her in hubby's hand.. so precious, magical.",
  "id" : 269869872891174914,
  "created_at" : "2012-11-17 18:29:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269867232786538497",
  "geo" : { },
  "id_str" : "269868451978420225",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles LOLOL ; )",
  "id" : 269868451978420225,
  "in_reply_to_status_id" : 269867232786538497,
  "created_at" : "2012-11-17 18:23:47 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269863348374470656",
  "text" : "lady hairy woodpecker knocked herself on our door. hubby moved her to a safe branch where she could recover.",
  "id" : 269863348374470656,
  "created_at" : "2012-11-17 18:03:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269844359841738753",
  "geo" : { },
  "id_str" : "269858431345762304",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH thank you Ani ((hugs))",
  "id" : 269858431345762304,
  "in_reply_to_status_id" : 269844359841738753,
  "created_at" : "2012-11-17 17:43:58 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tucson",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "aurora",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/JyWL9HCP",
      "expanded_url" : "http:\/\/livewire.talkingpointsmemo.com\/entry\/arizona-gun-store-no-obama-voters-allowed",
      "display_url" : "livewire.talkingpointsmemo.com\/entry\/arizona-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269856994444328961",
  "text" : "RT @SangyeH: AZ Gun Store: No Obama Voters Allowed http:\/\/t.co\/JyWL9HCP &lt;&lt;&lt; But sociopaths are still welcome. #tucson #aurora",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tucson",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "aurora",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/JyWL9HCP",
        "expanded_url" : "http:\/\/livewire.talkingpointsmemo.com\/entry\/arizona-gun-store-no-obama-voters-allowed",
        "display_url" : "livewire.talkingpointsmemo.com\/entry\/arizona-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "269856278396956672",
    "text" : "AZ Gun Store: No Obama Voters Allowed http:\/\/t.co\/JyWL9HCP &lt;&lt;&lt; But sociopaths are still welcome. #tucson #aurora",
    "id" : 269856278396956672,
    "created_at" : "2012-11-17 17:35:25 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 269856994444328961,
  "created_at" : "2012-11-17 17:38:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 10, 18 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 19, 31 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 32, 44 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269844175829213185",
  "text" : "thank you @sangyeh @angelaharms @virgojohnny .. hubby will get me tylenol and i will check out that link VJ. muah!",
  "id" : 269844175829213185,
  "created_at" : "2012-11-17 16:47:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269611502561021952",
  "geo" : { },
  "id_str" : "269612655264813057",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH teeth pain past 2 days. When hubby gets Xmas bonus (in Jan) they are coming out. As many as I can afford...",
  "id" : 269612655264813057,
  "in_reply_to_status_id" : 269611502561021952,
  "created_at" : "2012-11-17 01:27:20 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269611058807844864",
  "text" : "The pain switches from top jaw to lower jaw. 2 advils &amp; 2 aspirins are not cutting it...",
  "id" : 269611058807844864,
  "created_at" : "2012-11-17 01:21:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269538564092608513",
  "text" : "RT @andrewtshaffer: NEW CONTEST: First person to live-tweet from beyond the grave wins!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269534271688044544",
    "text" : "NEW CONTEST: First person to live-tweet from beyond the grave wins!",
    "id" : 269534271688044544,
    "created_at" : "2012-11-16 20:15:52 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 269538564092608513,
  "created_at" : "2012-11-16 20:32:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/0VwNRiuB",
      "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwXP2tBx",
      "display_url" : "tmblr.co\/ZYrEZwXP2tBx"
    } ]
  },
  "geo" : { },
  "id_str" : "269520883557736448",
  "text" : "RT @GeneDoucette: Holy what the fuck. http:\/\/t.co\/0VwNRiuB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/0VwNRiuB",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwXP2tBx",
        "display_url" : "tmblr.co\/ZYrEZwXP2tBx"
      } ]
    },
    "geo" : { },
    "id_str" : "269519841436766209",
    "text" : "Holy what the fuck. http:\/\/t.co\/0VwNRiuB",
    "id" : 269519841436766209,
    "created_at" : "2012-11-16 19:18:32 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 269520883557736448,
  "created_at" : "2012-11-16 19:22:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269515219972288514",
  "text" : "anyone familiar w Care Credit? looking at their website...",
  "id" : 269515219972288514,
  "created_at" : "2012-11-16 19:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269470250565767168",
  "geo" : { },
  "id_str" : "269471989746524160",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray LOL",
  "id" : 269471989746524160,
  "in_reply_to_status_id" : 269470250565767168,
  "created_at" : "2012-11-16 16:08:23 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269471540842741761",
  "text" : "all i want for christmas is my teeth pulled out, my teeth pulled out, my teeth pulled out...",
  "id" : 269471540842741761,
  "created_at" : "2012-11-16 16:06:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269471079263764480",
  "text" : "RT @earthXplorer: \"you are what you tweet\" ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269464860239208450",
    "text" : "\"you are what you tweet\" ;)",
    "id" : 269464860239208450,
    "created_at" : "2012-11-16 15:40:03 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 269471079263764480,
  "created_at" : "2012-11-16 16:04:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0435\u043F\u043E\u043C\u043D\u044F\u0449\u0438\u0445 \u0412\u0438\u043A\u0442\u043E\u0440",
      "screen_name" : "glassdimlyfaith",
      "indices" : [ 0, 16 ],
      "id_str" : "2826504890",
      "id" : 2826504890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269466516792152064",
  "geo" : { },
  "id_str" : "269469520123539457",
  "in_reply_to_user_id" : 247971836,
  "text" : "@glassdimlyfaith hmm..",
  "id" : 269469520123539457,
  "in_reply_to_status_id" : 269466516792152064,
  "created_at" : "2012-11-16 15:58:34 +0000",
  "in_reply_to_screen_name" : "glassdimly",
  "in_reply_to_user_id_str" : "247971836",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269458402877517824",
  "geo" : { },
  "id_str" : "269460829953474560",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 (((hugs)))",
  "id" : 269460829953474560,
  "in_reply_to_status_id" : 269458402877517824,
  "created_at" : "2012-11-16 15:24:02 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/FtqqbLZE",
      "expanded_url" : "http:\/\/www.motherjones.com\/mojo\/2012\/11\/target-walmart-and-other-big-box-stores-abolish-thanksgiving",
      "display_url" : "motherjones.com\/mojo\/2012\/11\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269225628061028353",
  "text" : "RT @Jamiastar: Target, Walmart, and Other Big-Box Stores Abolish Thanksgiving | Mother Jones http:\/\/t.co\/FtqqbLZE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/FtqqbLZE",
        "expanded_url" : "http:\/\/www.motherjones.com\/mojo\/2012\/11\/target-walmart-and-other-big-box-stores-abolish-thanksgiving",
        "display_url" : "motherjones.com\/mojo\/2012\/11\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "269225117878452225",
    "text" : "Target, Walmart, and Other Big-Box Stores Abolish Thanksgiving | Mother Jones http:\/\/t.co\/FtqqbLZE",
    "id" : 269225117878452225,
    "created_at" : "2012-11-15 23:47:24 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 269225628061028353,
  "created_at" : "2012-11-15 23:49:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269202029283532800",
  "geo" : { },
  "id_str" : "269203917370441728",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell cool...",
  "id" : 269203917370441728,
  "in_reply_to_status_id" : 269202029283532800,
  "created_at" : "2012-11-15 22:23:10 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269190031799885824",
  "geo" : { },
  "id_str" : "269202236318564352",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous : ( ((hugs))",
  "id" : 269202236318564352,
  "in_reply_to_status_id" : 269190031799885824,
  "created_at" : "2012-11-15 22:16:29 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greentree",
      "screen_name" : "3xistential",
      "indices" : [ 0, 12 ],
      "id_str" : "495202171",
      "id" : 495202171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269189522355519488",
  "geo" : { },
  "id_str" : "269201985931194369",
  "in_reply_to_user_id" : 495202171,
  "text" : "@3xistential you can have afterlife without religion. regardless, one should live the life they have now.. enjoy it.",
  "id" : 269201985931194369,
  "in_reply_to_status_id" : 269189522355519488,
  "created_at" : "2012-11-15 22:15:29 +0000",
  "in_reply_to_screen_name" : "3xistential",
  "in_reply_to_user_id_str" : "495202171",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269138646303657984",
  "geo" : { },
  "id_str" : "269144518555750400",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 LOL : )",
  "id" : 269144518555750400,
  "in_reply_to_status_id" : 269138646303657984,
  "created_at" : "2012-11-15 18:27:08 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 12, 25 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "mimi madeira ",
      "screen_name" : "mimimadeira",
      "indices" : [ 31, 43 ],
      "id_str" : "632206027",
      "id" : 632206027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269131384965185537",
  "geo" : { },
  "id_str" : "269134022809116672",
  "in_reply_to_user_id" : 946353775,
  "text" : "do you mean @MimiMadeira1 ? or @mimimadeira ?",
  "id" : 269134022809116672,
  "in_reply_to_status_id" : 269131384965185537,
  "created_at" : "2012-11-15 17:45:25 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269125448544444416",
  "text" : "RT @DarciaHelle: I'm doing a blog series on Justice &amp; looking for guest posts or Q&amp;A sessions with criminal lawyers, cops (activ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269125066787270657",
    "text" : "I'm doing a blog series on Justice &amp; looking for guest posts or Q&amp;A sessions with criminal lawyers, cops (active or retired), and P.I.s.",
    "id" : 269125066787270657,
    "created_at" : "2012-11-15 17:09:50 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 269125448544444416,
  "created_at" : "2012-11-15 17:11:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269110593649254400",
  "text" : "@zen_kitty its funny.. cuz same w me..",
  "id" : 269110593649254400,
  "created_at" : "2012-11-15 16:12:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269105269986955265",
  "geo" : { },
  "id_str" : "269109272510611456",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell LOL : )",
  "id" : 269109272510611456,
  "in_reply_to_status_id" : 269105269986955265,
  "created_at" : "2012-11-15 16:07:05 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269092813269004288",
  "text" : "@Skeptical_Lady i know.. can you imagine just wanting to be treated like regular ppl? geez",
  "id" : 269092813269004288,
  "created_at" : "2012-11-15 15:01:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "indices" : [ 22, 35 ],
      "id_str" : "21611239",
      "id" : 21611239
    }, {
      "name" : "Shindig Events",
      "screen_name" : "ShindigEvents",
      "indices" : [ 116, 130 ],
      "id_str" : "137847017",
      "id" : 137847017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269083718755442689",
  "text" : "RT @DuttonBooks: Join @seanmcarroll today in an interactive web event about THE PARTICLE AT THE END OF THE UNIVERSE @ShindigEvents http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Carroll",
        "screen_name" : "seanmcarroll",
        "indices" : [ 5, 18 ],
        "id_str" : "21611239",
        "id" : 21611239
      }, {
        "name" : "Shindig Events",
        "screen_name" : "ShindigEvents",
        "indices" : [ 99, 113 ],
        "id_str" : "137847017",
        "id" : 137847017
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/bSwXjy1p",
        "expanded_url" : "http:\/\/ow.ly\/fhyDy",
        "display_url" : "ow.ly\/fhyDy"
      } ]
    },
    "geo" : { },
    "id_str" : "269082904586502144",
    "text" : "Join @seanmcarroll today in an interactive web event about THE PARTICLE AT THE END OF THE UNIVERSE @ShindigEvents http:\/\/t.co\/bSwXjy1p",
    "id" : 269082904586502144,
    "created_at" : "2012-11-15 14:22:18 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 269083718755442689,
  "created_at" : "2012-11-15 14:25:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269080223373459456",
  "text" : "RT @BasharETcontact: The thing that you discount is how much Help each of you are just by being yourself. You think you have to do somet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269071368660873217",
    "text" : "The thing that you discount is how much Help each of you are just by being yourself. You think you have to do something SPECIAL  .~ bashar",
    "id" : 269071368660873217,
    "created_at" : "2012-11-15 13:36:28 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 269080223373459456,
  "created_at" : "2012-11-15 14:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "indices" : [ 3, 12 ],
      "id_str" : "116786271",
      "id" : 116786271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prayer",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268875802811199490",
  "text" : "RT @AniArene: May all beings have homes, food, safety, love, warmth and peace. #prayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prayer",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268872715535011840",
    "text" : "May all beings have homes, food, safety, love, warmth and peace. #prayer",
    "id" : 268872715535011840,
    "created_at" : "2012-11-15 00:27:05 +0000",
    "user" : {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "protected" : false,
      "id_str" : "116786271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797875002725036032\/G_rxW-Dq_normal.jpg",
      "id" : 116786271,
      "verified" : false
    }
  },
  "id" : 268875802811199490,
  "created_at" : "2012-11-15 00:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268867845805465600",
  "text" : "glad i put out more kibble. possum came by for a meal.",
  "id" : 268867845805465600,
  "created_at" : "2012-11-15 00:07:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/i6xYjWrd",
      "expanded_url" : "http:\/\/bookwi.se\/20-top-teen-books-of-2012-according-to-amazon\/",
      "display_url" : "bookwi.se\/20-top-teen-bo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268825113745571840",
  "text" : "RT @adamrshields: 20 Top Teen Books of 2012 (According to Amazon) http:\/\/t.co\/i6xYjWrd I have only read one.  Anyone else read many from ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/i6xYjWrd",
        "expanded_url" : "http:\/\/bookwi.se\/20-top-teen-books-of-2012-according-to-amazon\/",
        "display_url" : "bookwi.se\/20-top-teen-bo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "268822063563816961",
    "text" : "20 Top Teen Books of 2012 (According to Amazon) http:\/\/t.co\/i6xYjWrd I have only read one.  Anyone else read many from the list?",
    "id" : 268822063563816961,
    "created_at" : "2012-11-14 21:05:49 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 268825113745571840,
  "created_at" : "2012-11-14 21:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268808026620837888",
  "text" : "@ThePlushGourmet aww.. mine has gone wacky on me. suddenly, if i look at him he runs.. sigh.",
  "id" : 268808026620837888,
  "created_at" : "2012-11-14 20:10:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cynthia Boaz",
      "screen_name" : "cynthiaboaz",
      "indices" : [ 3, 15 ],
      "id_str" : "21735063",
      "id" : 21735063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268801349079166976",
  "text" : "RT @cynthiaboaz: US is not &amp; wasn't designed to be, a \"Christian nation.\" It's a secular dem republic where ppl of all faiths (or no ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 138, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268799240501870592",
    "text" : "US is not &amp; wasn't designed to be, a \"Christian nation.\" It's a secular dem republic where ppl of all faiths (or no faith) are equal. #tcot",
    "id" : 268799240501870592,
    "created_at" : "2012-11-14 19:35:07 +0000",
    "user" : {
      "name" : "Cynthia Boaz",
      "screen_name" : "cynthiaboaz",
      "protected" : false,
      "id_str" : "21735063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797350400756105216\/zQU-TjWd_normal.jpg",
      "id" : 21735063,
      "verified" : true
    }
  },
  "id" : 268801349079166976,
  "created_at" : "2012-11-14 19:43:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 26, 40 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268796996977045504",
  "text" : "plz send good thoughts to @GaribaldiRous .. a sweet capybara facing a medical crisis : (",
  "id" : 268796996977045504,
  "created_at" : "2012-11-14 19:26:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268780725128548352",
  "text" : "@Skeptical_Lady LOLOL",
  "id" : 268780725128548352,
  "created_at" : "2012-11-14 18:21:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268554172239081473",
  "geo" : { },
  "id_str" : "268745968944574464",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i thought it was quiet around here! i see you've been hard at work saving the world w your super powers! :D",
  "id" : 268745968944574464,
  "in_reply_to_status_id" : 268554172239081473,
  "created_at" : "2012-11-14 16:03:26 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268737161988300800",
  "text" : "my heart is certainly getting a workout with diff animal friends getting ill...",
  "id" : 268737161988300800,
  "created_at" : "2012-11-14 15:28:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/AmxUYiHE",
      "expanded_url" : "http:\/\/wp.me\/pM8rt-fa",
      "display_url" : "wp.me\/pM8rt-fa"
    } ]
  },
  "geo" : { },
  "id_str" : "268538486359998465",
  "text" : "RT @atheistlady76: Galway Pro-choice statement re the death of Savita Praveen http:\/\/t.co\/AmxUYiHE via @Sharrrow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/AmxUYiHE",
        "expanded_url" : "http:\/\/wp.me\/pM8rt-fa",
        "display_url" : "wp.me\/pM8rt-fa"
      } ]
    },
    "geo" : { },
    "id_str" : "268537648979800065",
    "text" : "Galway Pro-choice statement re the death of Savita Praveen http:\/\/t.co\/AmxUYiHE via @Sharrrow",
    "id" : 268537648979800065,
    "created_at" : "2012-11-14 02:15:39 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 268538486359998465,
  "created_at" : "2012-11-14 02:18:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268531824542748673",
  "text" : "my mother's getting her revenge..",
  "id" : 268531824542748673,
  "created_at" : "2012-11-14 01:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268520400726671361",
  "geo" : { },
  "id_str" : "268520842600800258",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 *muah* : )",
  "id" : 268520842600800258,
  "in_reply_to_status_id" : 268520400726671361,
  "created_at" : "2012-11-14 01:08:52 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 17, 28 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 75, 88 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268520109742632962",
  "text" : "anyone following @mimismutts .. she's having account issues. follow her at @MimiMadeira1",
  "id" : 268520109742632962,
  "created_at" : "2012-11-14 01:05:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "indices" : [ 3, 16 ],
      "id_str" : "74399881",
      "id" : 74399881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268518948906078208",
  "text" : "RT @pamelamarie8: Forgive everyone, including yourself, for everything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268518240093892608",
    "text" : "Forgive everyone, including yourself, for everything.",
    "id" : 268518240093892608,
    "created_at" : "2012-11-14 00:58:31 +0000",
    "user" : {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "protected" : false,
      "id_str" : "74399881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445924023600287744\/sh9pRUES_normal.jpeg",
      "id" : 74399881,
      "verified" : false
    }
  },
  "id" : 268518948906078208,
  "created_at" : "2012-11-14 01:01:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "NYC85539266  \u05D9\u05D4\u05D5\u05D3\u05D4",
      "screen_name" : "NYC8539266",
      "indices" : [ 121, 132 ],
      "id_str" : "298856339",
      "id" : 298856339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "war",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268517346665181184",
  "text" : "RT @CharlesBivona: U.S. #war is a bullshit story: poor people fight and die to defend the corporate profits of the rich. @NYC8539266 @NA ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NYC85539266  \u05D9\u05D4\u05D5\u05D3\u05D4",
        "screen_name" : "NYC8539266",
        "indices" : [ 102, 113 ],
        "id_str" : "298856339",
        "id" : 298856339
      }, {
        "name" : "DIANA LYNN BLOKZYL",
        "screen_name" : "NANDEE218",
        "indices" : [ 114, 124 ],
        "id_str" : "34824802",
        "id" : 34824802
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "war",
        "indices" : [ 5, 9 ]
      }, {
        "text" : "njpoet",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "268514217437585408",
    "geo" : { },
    "id_str" : "268515352604979200",
    "in_reply_to_user_id" : 298856339,
    "text" : "U.S. #war is a bullshit story: poor people fight and die to defend the corporate profits of the rich. @NYC8539266 @NANDEE218 #njpoet",
    "id" : 268515352604979200,
    "in_reply_to_status_id" : 268514217437585408,
    "created_at" : "2012-11-14 00:47:03 +0000",
    "in_reply_to_screen_name" : "NYC8539266",
    "in_reply_to_user_id_str" : "298856339",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 268517346665181184,
  "created_at" : "2012-11-14 00:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268511471737122816",
  "geo" : { },
  "id_str" : "268511896464928768",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind plz.. wth is a mandate?? i keep hearing this and dont understand...",
  "id" : 268511896464928768,
  "in_reply_to_status_id" : 268511471737122816,
  "created_at" : "2012-11-14 00:33:19 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268505976934658048",
  "text" : "omg... uti's are not from sleeping around!! sigh",
  "id" : 268505976934658048,
  "created_at" : "2012-11-14 00:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/lvM2j4nt",
      "expanded_url" : "http:\/\/thedancingdonkey.blogspot.com\/2012\/11\/change-of-plans.html",
      "display_url" : "thedancingdonkey.blogspot.com\/2012\/11\/change\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268502366746189824",
  "text" : "poor ramsay was doing better but had a setback http:\/\/t.co\/lvM2j4nt",
  "id" : 268502366746189824,
  "created_at" : "2012-11-13 23:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268497942715957249",
  "text" : "what does \"mandate\" mean in ref to the election (pres obama has mandate?)",
  "id" : 268497942715957249,
  "created_at" : "2012-11-13 23:37:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268488559604948993",
  "text" : "possum is so cute.. comes up and grabs a crust, runs off w it. comes back, grabs another..lol",
  "id" : 268488559604948993,
  "created_at" : "2012-11-13 23:00:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268480178701877248",
  "text" : "RT @UnseeingEyes: When 2 patterns of vibration are similar they tend to vibrate together, just as when 2 sounds are similar they tend to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268471468533366784",
    "text" : "When 2 patterns of vibration are similar they tend to vibrate together, just as when 2 sounds are similar they tend to reinforce each other.",
    "id" : 268471468533366784,
    "created_at" : "2012-11-13 21:52:40 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 268480178701877248,
  "created_at" : "2012-11-13 22:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268477512546390016",
  "geo" : { },
  "id_str" : "268479786148560897",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous i miss summer...",
  "id" : 268479786148560897,
  "in_reply_to_status_id" : 268477512546390016,
  "created_at" : "2012-11-13 22:25:43 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 0, 12 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268468715266379777",
  "geo" : { },
  "id_str" : "268469330134568962",
  "in_reply_to_user_id" : 40585382,
  "text" : "@ReverendSue LOL ((highfive))",
  "id" : 268469330134568962,
  "in_reply_to_status_id" : 268468715266379777,
  "created_at" : "2012-11-13 21:44:10 +0000",
  "in_reply_to_screen_name" : "ReverendSue",
  "in_reply_to_user_id_str" : "40585382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RED FRILL COAT",
      "screen_name" : "ghouldreams",
      "indices" : [ 0, 12 ],
      "id_str" : "4674991088",
      "id" : 4674991088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268468546252709889",
  "text" : "@GhoulDreams i am sorry about yr friend...",
  "id" : 268468546252709889,
  "created_at" : "2012-11-13 21:41:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268418994824957952",
  "geo" : { },
  "id_str" : "268458359806627841",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell my MIL complains all the time about going to bible study (no time! lol) but she's the one that got me into it..lol",
  "id" : 268458359806627841,
  "in_reply_to_status_id" : 268418994824957952,
  "created_at" : "2012-11-13 21:00:35 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268456320053686274",
  "geo" : { },
  "id_str" : "268457017750994944",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone i saw that article.. not sure i want to know how aware these ppl are.. scary thought...",
  "id" : 268457017750994944,
  "in_reply_to_status_id" : 268456320053686274,
  "created_at" : "2012-11-13 20:55:15 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspirational",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268455758574792704",
  "text" : "RT @UndertheNeonSky: It is never too late to be what you might have been. George Eliot #inspirational",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inspirational",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268455049938735104",
    "text" : "It is never too late to be what you might have been. George Eliot #inspirational",
    "id" : 268455049938735104,
    "created_at" : "2012-11-13 20:47:26 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 268455758574792704,
  "created_at" : "2012-11-13 20:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268452160033923072",
  "geo" : { },
  "id_str" : "268454116571897857",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone ((hugs)) thanks for the reminder!",
  "id" : 268454116571897857,
  "in_reply_to_status_id" : 268452160033923072,
  "created_at" : "2012-11-13 20:43:43 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268450765146832896",
  "text" : "im an awful role model for my DD.. sigh. im a lump doing nothing w my life living off DH meager earning.",
  "id" : 268450765146832896,
  "created_at" : "2012-11-13 20:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268449406221692930",
  "text" : "i cant drink anymore so i watch crappy tv shows...",
  "id" : 268449406221692930,
  "created_at" : "2012-11-13 20:25:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 0, 13 ],
      "id_str" : "358311362",
      "id" : 358311362
    }, {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 26, 38 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/qFbCkkTC",
      "expanded_url" : "http:\/\/www.facebook.com\/darcia.helle\/posts\/3532967702296",
      "display_url" : "facebook.com\/darcia.helle\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268432933059170305",
  "in_reply_to_user_id" : 358311362,
  "text" : "@damienechols FYI: author @darciahelle looking for ppl to guest blog on \"Justice\" http:\/\/t.co\/qFbCkkTC",
  "id" : 268432933059170305,
  "created_at" : "2012-11-13 19:19:33 +0000",
  "in_reply_to_screen_name" : "damienechols",
  "in_reply_to_user_id_str" : "358311362",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 3, 18 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268425991679008768",
  "text" : "RT @LoveHonorTruth: There is so much variability within each gender and also a lot of overlap between the two.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268424405292564482",
    "text" : "There is so much variability within each gender and also a lot of overlap between the two.",
    "id" : 268424405292564482,
    "created_at" : "2012-11-13 18:45:39 +0000",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "protected" : false,
      "id_str" : "167958125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525129289336107008\/HMsrT9oV_normal.jpeg",
      "id" : 167958125,
      "verified" : false
    }
  },
  "id" : 268425991679008768,
  "created_at" : "2012-11-13 18:51:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268415889081249792",
  "text" : "RT @oshum: Under the guise of flesh...we all are....the same.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268414285523324928",
    "text" : "Under the guise of flesh...we all are....the same.",
    "id" : 268414285523324928,
    "created_at" : "2012-11-13 18:05:27 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 268415889081249792,
  "created_at" : "2012-11-13 18:11:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HolidaySolutions",
      "indices" : [ 19, 36 ]
    }, {
      "text" : "njpoet",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268415671212331012",
  "text" : "RT @CharlesBivona: #HolidaySolutions: Medically Induced Coma #njpoet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HolidaySolutions",
        "indices" : [ 0, 17 ]
      }, {
        "text" : "njpoet",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268415498411208704",
    "text" : "#HolidaySolutions: Medically Induced Coma #njpoet",
    "id" : 268415498411208704,
    "created_at" : "2012-11-13 18:10:16 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 268415671212331012,
  "created_at" : "2012-11-13 18:10:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268415565100630017",
  "text" : "no bible study next week due to thanksgiving week.. bleh. i dont like holidays!",
  "id" : 268415565100630017,
  "created_at" : "2012-11-13 18:10:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268359983467483137",
  "text" : "RT @BasharETcontact: a place, a circumstance may attract you, like no other, Only to get you moving. Not because you\u2019re supposed to stay ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268359762687713280",
    "text" : "a place, a circumstance may attract you, like no other, Only to get you moving. Not because you\u2019re supposed to stay there",
    "id" : 268359762687713280,
    "created_at" : "2012-11-13 14:28:47 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 268359983467483137,
  "created_at" : "2012-11-13 14:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/PhPkfjJa",
      "expanded_url" : "http:\/\/amzn.to\/n0bAux",
      "display_url" : "amzn.to\/n0bAux"
    } ]
  },
  "geo" : { },
  "id_str" : "268352280540098561",
  "text" : "finished Wool by Hugh Howey http:\/\/t.co\/PhPkfjJa #Kindle",
  "id" : 268352280540098561,
  "created_at" : "2012-11-13 13:59:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/GPJrwAAR",
      "expanded_url" : "http:\/\/amzn.to\/HnlNIY",
      "display_url" : "amzn.to\/HnlNIY"
    } ]
  },
  "geo" : { },
  "id_str" : "268351415347458048",
  "text" : "finished On Unfaithful Wings (An Icarus Fell Novel) by Bruce Blake http:\/\/t.co\/GPJrwAAR #Kindle",
  "id" : 268351415347458048,
  "created_at" : "2012-11-13 13:55:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/ZouTW6bf",
      "expanded_url" : "http:\/\/bbc.in\/TwVQuW",
      "display_url" : "bbc.in\/TwVQuW"
    } ]
  },
  "geo" : { },
  "id_str" : "268173706864492545",
  "text" : "BBC News - Vegetative patient Scott Routley says 'I'm not in pain' http:\/\/t.co\/ZouTW6bf",
  "id" : 268173706864492545,
  "created_at" : "2012-11-13 02:09:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268164779531722752",
  "text" : "RT @CaroleODell: You know all those mistakes you made today? And all those things left undone? Guess what. Tomorrow is a new day. Do it  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268164241494781952",
    "text" : "You know all those mistakes you made today? And all those things left undone? Guess what. Tomorrow is a new day. Do it better.",
    "id" : 268164241494781952,
    "created_at" : "2012-11-13 01:31:52 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 268164779531722752,
  "created_at" : "2012-11-13 01:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/268158357439934464\/photo\/1",
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/cQ5IL3jc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7iwmvcCcAEFg_Z.jpg",
      "id_str" : "268158357444128769",
      "id" : 268158357444128769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7iwmvcCcAEFg_Z.jpg",
      "sizes" : [ {
        "h" : 215,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 503
      } ],
      "display_url" : "pic.twitter.com\/cQ5IL3jc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268158815843794945",
  "text" : "RT @atheistlady76: LMAO! Can you imagine how hilarious this would be??? http:\/\/t.co\/cQ5IL3jc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/268158357439934464\/photo\/1",
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/cQ5IL3jc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7iwmvcCcAEFg_Z.jpg",
        "id_str" : "268158357444128769",
        "id" : 268158357444128769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7iwmvcCcAEFg_Z.jpg",
        "sizes" : [ {
          "h" : 215,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 145,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 503
        } ],
        "display_url" : "pic.twitter.com\/cQ5IL3jc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268158357439934464",
    "text" : "LMAO! Can you imagine how hilarious this would be??? http:\/\/t.co\/cQ5IL3jc",
    "id" : 268158357439934464,
    "created_at" : "2012-11-13 01:08:29 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 268158815843794945,
  "created_at" : "2012-11-13 01:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268152424869539841",
  "text" : "@iEyeAyes aww.. poor kitty. hope he feels better soon.",
  "id" : 268152424869539841,
  "created_at" : "2012-11-13 00:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268131175111991297",
  "geo" : { },
  "id_str" : "268131764713713664",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH big (((hug)))",
  "id" : 268131764713713664,
  "in_reply_to_status_id" : 268131175111991297,
  "created_at" : "2012-11-12 23:22:49 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268119327260155905",
  "text" : "RT @VirginTease: I can't help but wonder about everything",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268115527023595520",
    "text" : "I can't help but wonder about everything",
    "id" : 268115527023595520,
    "created_at" : "2012-11-12 22:18:17 +0000",
    "user" : {
      "name" : "Snow White",
      "screen_name" : "HalfSanePrness",
      "protected" : false,
      "id_str" : "400415766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457350933379153920\/krJFDs8C_normal.jpeg",
      "id" : 400415766,
      "verified" : false
    }
  },
  "id" : 268119327260155905,
  "created_at" : "2012-11-12 22:33:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268095189619470337",
  "text" : "@AnarchoXtian show off!! : P",
  "id" : 268095189619470337,
  "created_at" : "2012-11-12 20:57:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "indices" : [ 63, 76 ],
      "id_str" : "21611239",
      "id" : 21611239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/QHax4Mne",
      "expanded_url" : "http:\/\/ow.ly\/f27eo",
      "display_url" : "ow.ly\/f27eo"
    } ]
  },
  "geo" : { },
  "id_str" : "268081388404752386",
  "text" : "RT @DuttonBooks: Follow us &amp; RT to enter to #win a copy of @seanmcarroll's Higgs Boson book! US only. Rules: http:\/\/t.co\/QHax4Mne #M ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Carroll",
        "screen_name" : "seanmcarroll",
        "indices" : [ 46, 59 ],
        "id_str" : "21611239",
        "id" : 21611239
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 31, 35 ]
      }, {
        "text" : "Mondaygiveaway",
        "indices" : [ 117, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/QHax4Mne",
        "expanded_url" : "http:\/\/ow.ly\/f27eo",
        "display_url" : "ow.ly\/f27eo"
      } ]
    },
    "geo" : { },
    "id_str" : "268080967527313408",
    "text" : "Follow us &amp; RT to enter to #win a copy of @seanmcarroll's Higgs Boson book! US only. Rules: http:\/\/t.co\/QHax4Mne #Mondaygiveaway",
    "id" : 268080967527313408,
    "created_at" : "2012-11-12 20:00:58 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 268081388404752386,
  "created_at" : "2012-11-12 20:02:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/BDSKYH8N",
      "expanded_url" : "http:\/\/500px.com\/photo\/17989251",
      "display_url" : "500px.com\/photo\/17989251"
    } ]
  },
  "geo" : { },
  "id_str" : "268058260861505536",
  "text" : "RT @screek: Photo \u201CBaby Rabbit\u201D by Steve Creek http:\/\/t.co\/BDSKYH8N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/BDSKYH8N",
        "expanded_url" : "http:\/\/500px.com\/photo\/17989251",
        "display_url" : "500px.com\/photo\/17989251"
      } ]
    },
    "geo" : { },
    "id_str" : "268057221152256001",
    "text" : "Photo \u201CBaby Rabbit\u201D by Steve Creek http:\/\/t.co\/BDSKYH8N",
    "id" : 268057221152256001,
    "created_at" : "2012-11-12 18:26:36 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 268058260861505536,
  "created_at" : "2012-11-12 18:30:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Picard",
      "screen_name" : "picardonhealth",
      "indices" : [ 3, 18 ],
      "id_str" : "252794509",
      "id" : 252794509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/6RfD8Blq",
      "expanded_url" : "http:\/\/bit.ly\/UD2y1e",
      "display_url" : "bit.ly\/UD2y1e"
    } ]
  },
  "geo" : { },
  "id_str" : "268031539248500736",
  "text" : "RT @picardonhealth: \"NO RUNNING AT RECESS\" - a stupid school rule. And we wonder why kids are unhealthy? http:\/\/t.co\/6RfD8Blq via @FreeR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lenore Skenazy",
        "screen_name" : "FreeRangeKids",
        "indices" : [ 110, 124 ],
        "id_str" : "20349823",
        "id" : 20349823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/6RfD8Blq",
        "expanded_url" : "http:\/\/bit.ly\/UD2y1e",
        "display_url" : "bit.ly\/UD2y1e"
      } ]
    },
    "geo" : { },
    "id_str" : "267998779846828032",
    "text" : "\"NO RUNNING AT RECESS\" - a stupid school rule. And we wonder why kids are unhealthy? http:\/\/t.co\/6RfD8Blq via @FreeRangeKids",
    "id" : 267998779846828032,
    "created_at" : "2012-11-12 14:34:22 +0000",
    "user" : {
      "name" : "Andr\u00E9 Picard",
      "screen_name" : "picardonhealth",
      "protected" : false,
      "id_str" : "252794509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799341245646524416\/65q9B59n_normal.jpg",
      "id" : 252794509,
      "verified" : true
    }
  },
  "id" : 268031539248500736,
  "created_at" : "2012-11-12 16:44:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268030555474513920",
  "text" : "RT @ShipsofSong: Assist those U C suffering that are within your reach.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268029767134085120",
    "text" : "Assist those U C suffering that are within your reach.",
    "id" : 268029767134085120,
    "created_at" : "2012-11-12 16:37:30 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 268030555474513920,
  "created_at" : "2012-11-12 16:40:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "indices" : [ 103, 116 ],
      "id_str" : "21611239",
      "id" : 21611239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268025236555972608",
  "text" : "RT @DuttonBooks: We'll be giving away the fascinating book: THE PARTICLE AT THE END OF THE UNIVERSE by @seanmcarroll, today at 3pm EST.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Carroll",
        "screen_name" : "seanmcarroll",
        "indices" : [ 86, 99 ],
        "id_str" : "21611239",
        "id" : 21611239
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mondaygiveaway",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268020368910999552",
    "text" : "We'll be giving away the fascinating book: THE PARTICLE AT THE END OF THE UNIVERSE by @seanmcarroll, today at 3pm EST. #Mondaygiveaway",
    "id" : 268020368910999552,
    "created_at" : "2012-11-12 16:00:10 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 268025236555972608,
  "created_at" : "2012-11-12 16:19:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268023055043944448",
  "geo" : { },
  "id_str" : "268024310474608640",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible exactly.. and until we know.. we dont know...",
  "id" : 268024310474608640,
  "in_reply_to_status_id" : 268023055043944448,
  "created_at" : "2012-11-12 16:15:49 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Night Vale podcast",
      "screen_name" : "NightValeRadio",
      "indices" : [ 3, 18 ],
      "id_str" : "740895416",
      "id" : 740895416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268016967305293825",
  "text" : "RT @NightValeRadio: When a person dies and no one will miss them, the mourning is assigned to a random human. This is why you sometimes  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268013658825703424",
    "text" : "When a person dies and no one will miss them, the mourning is assigned to a random human. This is why you sometimes just feel sad.",
    "id" : 268013658825703424,
    "created_at" : "2012-11-12 15:33:30 +0000",
    "user" : {
      "name" : "Night Vale podcast",
      "screen_name" : "NightValeRadio",
      "protected" : false,
      "id_str" : "740895416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2475298881\/3rpcqsb8czp108cme88f_normal.gif",
      "id" : 740895416,
      "verified" : false
    }
  },
  "id" : 268016967305293825,
  "created_at" : "2012-11-12 15:46:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 4, 17 ],
      "id_str" : "361815486",
      "id" : 361815486
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 30, 41 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268015100395417600",
  "geo" : { },
  "id_str" : "268015874433241088",
  "in_reply_to_user_id" : 67336993,
  "text" : "hey @bookwiseblog &gt;&gt; RT @TyrusBooks Audiobook suggestions...go!",
  "id" : 268015874433241088,
  "in_reply_to_status_id" : 268015100395417600,
  "created_at" : "2012-11-12 15:42:18 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268015121803128832",
  "text" : "the dominoes are swaying : )",
  "id" : 268015121803128832,
  "created_at" : "2012-11-12 15:39:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268014859453620224",
  "text" : "RT @TheDailyHug: Do not allow yourself to be burdened by negative people and situations. You get to choose. CHOOSE happy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268014592628776960",
    "text" : "Do not allow yourself to be burdened by negative people and situations. You get to choose. CHOOSE happy.",
    "id" : 268014592628776960,
    "created_at" : "2012-11-12 15:37:13 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 268014859453620224,
  "created_at" : "2012-11-12 15:38:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268013652446158848",
  "text" : "@Skeptical_Lady but sex ed and bc would make ppl less fearful about sex and that would be BAD..lol",
  "id" : 268013652446158848,
  "created_at" : "2012-11-12 15:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268009786266771456",
  "text" : "RT @bookwiseblog: A Kindle for Christmas?: If you are thinking about giving a kindle for Christmas your options are going to be li... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/lN8bYLlA",
        "expanded_url" : "http:\/\/bit.ly\/Sfl5Ad",
        "display_url" : "bit.ly\/Sfl5Ad"
      } ]
    },
    "geo" : { },
    "id_str" : "268008082150412288",
    "text" : "A Kindle for Christmas?: If you are thinking about giving a kindle for Christmas your options are going to be li... http:\/\/t.co\/lN8bYLlA",
    "id" : 268008082150412288,
    "created_at" : "2012-11-12 15:11:20 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 268009786266771456,
  "created_at" : "2012-11-12 15:18:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268006099595169792",
  "text" : "RT @TheGoldenMirror: We're all human. We're all on the same side.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268005071344766977",
    "text" : "We're all human. We're all on the same side.",
    "id" : 268005071344766977,
    "created_at" : "2012-11-12 14:59:22 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 268006099595169792,
  "created_at" : "2012-11-12 15:03:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268002839094255616",
  "text" : "i love watching the birds at the feeder, on the porch. lightens my mood considerably..lol",
  "id" : 268002839094255616,
  "created_at" : "2012-11-12 14:50:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickDutchTarot+more",
      "screen_name" : "nickdutchtarot",
      "indices" : [ 10, 25 ],
      "id_str" : "23281686",
      "id" : 23281686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267999769446735872",
  "geo" : { },
  "id_str" : "268001205807091713",
  "in_reply_to_user_id" : 23281686,
  "text" : "NOOO!! RT @nickdutchtarot My Tarot said that the world isn't going to end next month. Sorry to disappoint you.",
  "id" : 268001205807091713,
  "in_reply_to_status_id" : 267999769446735872,
  "created_at" : "2012-11-12 14:44:01 +0000",
  "in_reply_to_screen_name" : "nickdutchtarot",
  "in_reply_to_user_id_str" : "23281686",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/467qpQrY",
      "expanded_url" : "http:\/\/ow.ly\/f9YAn",
      "display_url" : "ow.ly\/f9YAn"
    } ]
  },
  "geo" : { },
  "id_str" : "267794616055635969",
  "text" : "RT @davidpakmanshow: Have you subscribed to new interviews channel? Lt Col Karen Kwiatkowski interview is compelling http:\/\/t.co\/467qpQrY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/467qpQrY",
        "expanded_url" : "http:\/\/ow.ly\/f9YAn",
        "display_url" : "ow.ly\/f9YAn"
      } ]
    },
    "geo" : { },
    "id_str" : "267778871133347840",
    "text" : "Have you subscribed to new interviews channel? Lt Col Karen Kwiatkowski interview is compelling http:\/\/t.co\/467qpQrY",
    "id" : 267778871133347840,
    "created_at" : "2012-11-12 00:00:32 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 267794616055635969,
  "created_at" : "2012-11-12 01:03:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267770874470469632",
  "text" : "RT @mbekezm: There is no hope, for the human race....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267769735855357952",
    "text" : "There is no hope, for the human race....",
    "id" : 267769735855357952,
    "created_at" : "2012-11-11 23:24:14 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 267770874470469632,
  "created_at" : "2012-11-11 23:28:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267768649622900736",
  "text" : "RT @mbekezm: For all you guys wearing skinny jeans..  I think you too the phrase \"Getting into her pants\" the wrong way..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267767737391132672",
    "text" : "For all you guys wearing skinny jeans..  I think you too the phrase \"Getting into her pants\" the wrong way..",
    "id" : 267767737391132672,
    "created_at" : "2012-11-11 23:16:18 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 267768649622900736,
  "created_at" : "2012-11-11 23:19:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267768488133812224",
  "text" : "looking back, i can see i had severe social anxiety issues. kept my bag (with coat in it) with me so i didnt have to use locker, etc.",
  "id" : 267768488133812224,
  "created_at" : "2012-11-11 23:19:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267768136290430976",
  "text" : "when i was in high school, i had same eating anxiety. so i would read during lunch and eat when i got home.",
  "id" : 267768136290430976,
  "created_at" : "2012-11-11 23:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267766482472144896",
  "text" : "we need to do something nice for our niece who has taken DD to 2 cons so far...",
  "id" : 267766482472144896,
  "created_at" : "2012-11-11 23:11:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267765627144527873",
  "text" : "DD had a fantastic time at the comic con.. she made more new friends! and.. she ate with them (she doesnt eat at school due to anxiety)",
  "id" : 267765627144527873,
  "created_at" : "2012-11-11 23:07:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Garden",
      "screen_name" : "WildlifeGarden",
      "indices" : [ 3, 18 ],
      "id_str" : "171979247",
      "id" : 171979247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WildlifeGarden",
      "indices" : [ 53, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/VSE35Cnd",
      "expanded_url" : "http:\/\/bit.ly\/LdDkm9",
      "display_url" : "bit.ly\/LdDkm9"
    } ]
  },
  "geo" : { },
  "id_str" : "267739687475630080",
  "text" : "RT @WildlifeGarden: Tiny Toads http:\/\/t.co\/VSE35Cnd\n #WildlifeGarden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WildlifeGarden",
        "indices" : [ 33, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/VSE35Cnd",
        "expanded_url" : "http:\/\/bit.ly\/LdDkm9",
        "display_url" : "bit.ly\/LdDkm9"
      } ]
    },
    "geo" : { },
    "id_str" : "267738106969591809",
    "text" : "Tiny Toads http:\/\/t.co\/VSE35Cnd\n #WildlifeGarden",
    "id" : 267738106969591809,
    "created_at" : "2012-11-11 21:18:33 +0000",
    "user" : {
      "name" : "Wildlife Garden",
      "screen_name" : "WildlifeGarden",
      "protected" : false,
      "id_str" : "171979247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000044473348\/a554cca187a67fb5dbddb776da62ce0e_normal.jpeg",
      "id" : 171979247,
      "verified" : false
    }
  },
  "id" : 267739687475630080,
  "created_at" : "2012-11-11 21:24:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "indices" : [ 3, 18 ],
      "id_str" : "7622122",
      "id" : 7622122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/tq1NkeXp",
      "expanded_url" : "http:\/\/IndieBizChicks.com",
      "display_url" : "IndieBizChicks.com"
    }, {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/jv2RUkpr",
      "expanded_url" : "http:\/\/ow.ly\/fbznc",
      "display_url" : "ow.ly\/fbznc"
    } ]
  },
  "geo" : { },
  "id_str" : "267726735745896448",
  "text" : "RT @indiebizchicks: Advertise your biz on http:\/\/t.co\/tq1NkeXp for just $10 - please RT! http:\/\/t.co\/jv2RUkpr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/tq1NkeXp",
        "expanded_url" : "http:\/\/IndieBizChicks.com",
        "display_url" : "IndieBizChicks.com"
      }, {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/jv2RUkpr",
        "expanded_url" : "http:\/\/ow.ly\/fbznc",
        "display_url" : "ow.ly\/fbznc"
      } ]
    },
    "geo" : { },
    "id_str" : "267720919903006721",
    "text" : "Advertise your biz on http:\/\/t.co\/tq1NkeXp for just $10 - please RT! http:\/\/t.co\/jv2RUkpr",
    "id" : 267720919903006721,
    "created_at" : "2012-11-11 20:10:15 +0000",
    "user" : {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "protected" : false,
      "id_str" : "7622122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653393257959936001\/6VMDqhz3_normal.jpg",
      "id" : 7622122,
      "verified" : false
    }
  },
  "id" : 267726735745896448,
  "created_at" : "2012-11-11 20:33:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267726387618664449",
  "text" : "@zen_kitty i get you...",
  "id" : 267726387618664449,
  "created_at" : "2012-11-11 20:31:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267725722062311425",
  "text" : "RT @worldtreeman: rock the boat! rock the boat! as the boat is falling off the edge of the world!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267725568273944576",
    "text" : "rock the boat! rock the boat! as the boat is falling off the edge of the world!!",
    "id" : 267725568273944576,
    "created_at" : "2012-11-11 20:28:44 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 267725722062311425,
  "created_at" : "2012-11-11 20:29:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267693099051012096",
  "text" : "the poor dog.. the things we do to her.. lol. had to trick her so hubby could grab her for bath. i feel so bad!",
  "id" : 267693099051012096,
  "created_at" : "2012-11-11 18:19:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267685645315629056",
  "geo" : { },
  "id_str" : "267688368350052353",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth lol.. i do that.. (too often o-O)",
  "id" : 267688368350052353,
  "in_reply_to_status_id" : 267685645315629056,
  "created_at" : "2012-11-11 18:00:55 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267671390705045504",
  "geo" : { },
  "id_str" : "267675451575640066",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater doesnt matter.. he left his family and all he knew to serve his country, to help. Bless his heart. He deserves honor.",
  "id" : 267675451575640066,
  "in_reply_to_status_id" : 267671390705045504,
  "created_at" : "2012-11-11 17:09:35 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267668341446017024",
  "text" : "@SamsaricWarrior heehee",
  "id" : 267668341446017024,
  "created_at" : "2012-11-11 16:41:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "indices" : [ 3, 18 ],
      "id_str" : "7622122",
      "id" : 7622122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/NVK4hp3Q",
      "expanded_url" : "http:\/\/ow.ly\/fbzvm",
      "display_url" : "ow.ly\/fbzvm"
    } ]
  },
  "geo" : { },
  "id_str" : "267661596451565569",
  "text" : "RT @indiebizchicks: Market Your Craft Biz Online (and offline) Without Going Broke - register for this webinar, just $5 http:\/\/t.co\/NVK4hp3Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/NVK4hp3Q",
        "expanded_url" : "http:\/\/ow.ly\/fbzvm",
        "display_url" : "ow.ly\/fbzvm"
      } ]
    },
    "geo" : { },
    "id_str" : "267659318676037632",
    "text" : "Market Your Craft Biz Online (and offline) Without Going Broke - register for this webinar, just $5 http:\/\/t.co\/NVK4hp3Q",
    "id" : 267659318676037632,
    "created_at" : "2012-11-11 16:05:29 +0000",
    "user" : {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "protected" : false,
      "id_str" : "7622122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653393257959936001\/6VMDqhz3_normal.jpg",
      "id" : 7622122,
      "verified" : false
    }
  },
  "id" : 267661596451565569,
  "created_at" : "2012-11-11 16:14:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267660633502257152",
  "text" : "watching real estate shows... watched Love It or List It last night. RE agents really have to have good shell to deal w ppl..lol",
  "id" : 267660633502257152,
  "created_at" : "2012-11-11 16:10:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee PurrpleCatmama",
      "screen_name" : "PurrpleCatMama",
      "indices" : [ 3, 18 ],
      "id_str" : "235738761",
      "id" : 235738761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267658783545782272",
  "text" : "RT @PurrpleCatMama: Everyone gets to evolve.  Everyone.  In their own time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267649540318957568",
    "text" : "Everyone gets to evolve.  Everyone.  In their own time.",
    "id" : 267649540318957568,
    "created_at" : "2012-11-11 15:26:37 +0000",
    "user" : {
      "name" : "Renee PurrpleCatmama",
      "screen_name" : "PurrpleCatMama",
      "protected" : false,
      "id_str" : "235738761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1249883489\/rainbow_fist_normal.jpg",
      "id" : 235738761,
      "verified" : false
    }
  },
  "id" : 267658783545782272,
  "created_at" : "2012-11-11 16:03:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "indices" : [ 3, 12 ],
      "id_str" : "8234572",
      "id" : 8234572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/0akfIIy4",
      "expanded_url" : "http:\/\/www.eso.org\/public\/images\/eso1242a\/",
      "display_url" : "eso.org\/public\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "267653971265601536",
  "text" : "RT @cantrell: A nearly nine billion pixel picture of the center of our galaxy. http:\/\/t.co\/0akfIIy4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/0akfIIy4",
        "expanded_url" : "http:\/\/www.eso.org\/public\/images\/eso1242a\/",
        "display_url" : "eso.org\/public\/images\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "267652088123777024",
    "text" : "A nearly nine billion pixel picture of the center of our galaxy. http:\/\/t.co\/0akfIIy4",
    "id" : 267652088123777024,
    "created_at" : "2012-11-11 15:36:45 +0000",
    "user" : {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "protected" : false,
      "id_str" : "8234572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3466700371\/ca68118063303c7fe19a3cf79e68a9f8_normal.jpeg",
      "id" : 8234572,
      "verified" : true
    }
  },
  "id" : 267653971265601536,
  "created_at" : "2012-11-11 15:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267650611472920577",
  "text" : "RT @DoreenVirtue444: Prayer is an internal form of meditation, which is essential to help one escape from fear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267642845945544706",
    "text" : "Prayer is an internal form of meditation, which is essential to help one escape from fear.",
    "id" : 267642845945544706,
    "created_at" : "2012-11-11 15:00:01 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 267650611472920577,
  "created_at" : "2012-11-11 15:30:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267461948852023296",
  "text" : "RT @morsemusings: You are love. Some forgot. Let them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267461019402633216",
    "text" : "You are love. Some forgot. Let them.",
    "id" : 267461019402633216,
    "created_at" : "2012-11-11 02:57:30 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 267461948852023296,
  "created_at" : "2012-11-11 03:01:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267438672222248963",
  "geo" : { },
  "id_str" : "267440105789206529",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist you're never too old for mommy! \u2665",
  "id" : 267440105789206529,
  "in_reply_to_status_id" : 267438672222248963,
  "created_at" : "2012-11-11 01:34:24 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267418520395063296",
  "geo" : { },
  "id_str" : "267421922650902529",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses nice looking family there! : )",
  "id" : 267421922650902529,
  "in_reply_to_status_id" : 267418520395063296,
  "created_at" : "2012-11-11 00:22:09 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267404021260775424",
  "geo" : { },
  "id_str" : "267405705059917824",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench hope we get to see pics when you're done..lol",
  "id" : 267405705059917824,
  "in_reply_to_status_id" : 267404021260775424,
  "created_at" : "2012-11-10 23:17:42 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 74 ],
      "url" : "https:\/\/t.co\/x2tYj2tw",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/guess!\/id548393760?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/guess!\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "267400102153441281",
  "text" : "if you want to play, im abfabgab on Guess (wordgame) https:\/\/t.co\/x2tYj2tw",
  "id" : 267400102153441281,
  "created_at" : "2012-11-10 22:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267317825134280704",
  "text" : "you know that restless leg feeling? that is exactly what my soul feels like!",
  "id" : 267317825134280704,
  "created_at" : "2012-11-10 17:28:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267317232667881472",
  "geo" : { },
  "id_str" : "267317561488707584",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin cant come soon enough for me.. ugh.",
  "id" : 267317561488707584,
  "in_reply_to_status_id" : 267317232667881472,
  "created_at" : "2012-11-10 17:27:27 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267316937984450561",
  "text" : "i want to give in to the black void.. just so tired of #2012",
  "id" : 267316937984450561,
  "created_at" : "2012-11-10 17:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267309116781903872",
  "geo" : { },
  "id_str" : "267310634323025921",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell yes, it is difficult to see.. and so confusing. i cant seem to keep emotional balance.. pulled this way and that..",
  "id" : 267310634323025921,
  "in_reply_to_status_id" : 267309116781903872,
  "created_at" : "2012-11-10 16:59:56 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayor",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267304777090752513",
  "geo" : { },
  "id_str" : "267307096788324352",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell i dont like the forced buying either. im hoping somehow it will evolve into #singlepayor or some kind of universal access.",
  "id" : 267307096788324352,
  "in_reply_to_status_id" : 267304777090752513,
  "created_at" : "2012-11-10 16:45:52 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267305844478201856",
  "text" : ". @1stCitizenKane ahh, yes.. quantum science. we are just at the tip of understanding it!",
  "id" : 267305844478201856,
  "created_at" : "2012-11-10 16:40:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 2, 15 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267304083692613633",
  "geo" : { },
  "id_str" : "267305398149709825",
  "in_reply_to_user_id" : 94619438,
  "text" : ". @micahjmurray darn.. sorry i didnt catch that. i try to check B4 i post. thanks for correcting me!",
  "id" : 267305398149709825,
  "in_reply_to_status_id" : 267304083692613633,
  "created_at" : "2012-11-10 16:39:07 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267303391275929600",
  "text" : "chickadees are funny. they are like the terriers of the bird world..lol",
  "id" : 267303391275929600,
  "created_at" : "2012-11-10 16:31:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 3, 15 ],
      "id_str" : "14979481",
      "id" : 14979481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267300265558941696",
  "text" : "RT @RonJeffries: I really believe that the \"we are totally right, they are totally wrong, we are good, they are evil\" approach is never  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267298316881121280",
    "text" : "I really believe that the \"we are totally right, they are totally wrong, we are good, they are evil\" approach is never going to help. Stop.",
    "id" : 267298316881121280,
    "created_at" : "2012-11-10 16:10:59 +0000",
    "user" : {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "protected" : false,
      "id_str" : "14979481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479052206260244480\/WQA0NXQT_normal.jpeg",
      "id" : 14979481,
      "verified" : false
    }
  },
  "id" : 267300265558941696,
  "created_at" : "2012-11-10 16:18:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267139160752652288",
  "geo" : { },
  "id_str" : "267300069441687553",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind im not good at funny but i can give a ((hug)) ...",
  "id" : 267300069441687553,
  "in_reply_to_status_id" : 267139160752652288,
  "created_at" : "2012-11-10 16:17:57 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267293630270676992",
  "text" : "sooo.. santorum says the gay community rigged the election...",
  "id" : 267293630270676992,
  "created_at" : "2012-11-10 15:52:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 27, 41 ],
      "id_str" : "183854047",
      "id" : 183854047
    }, {
      "name" : "Jenny",
      "screen_name" : "gennepher",
      "indices" : [ 64, 74 ],
      "id_str" : "62311852",
      "id" : 62311852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/267288555053797377\/photo\/1",
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/xO7rTHYO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7WZhlDCUAA6rZ6.jpg",
      "id_str" : "267288555057991680",
      "id" : 267288555057991680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7WZhlDCUAA6rZ6.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 359
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 359
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 359
      } ],
      "display_url" : "pic.twitter.com\/xO7rTHYO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267289040364113920",
  "text" : "RT @CoyoteSings: rofl!! RT @CatFoodBreath: http:\/\/t.co\/xO7rTHYO @gennepher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cat Food Breath",
        "screen_name" : "CatFoodBreath",
        "indices" : [ 10, 24 ],
        "id_str" : "183854047",
        "id" : 183854047
      }, {
        "name" : "Jenny",
        "screen_name" : "gennepher",
        "indices" : [ 47, 57 ],
        "id_str" : "62311852",
        "id" : 62311852
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/267288555053797377\/photo\/1",
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/xO7rTHYO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7WZhlDCUAA6rZ6.jpg",
        "id_str" : "267288555057991680",
        "id" : 267288555057991680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7WZhlDCUAA6rZ6.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 359
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 359
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 359
        } ],
        "display_url" : "pic.twitter.com\/xO7rTHYO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267288720762355712",
    "text" : "rofl!! RT @CatFoodBreath: http:\/\/t.co\/xO7rTHYO @gennepher",
    "id" : 267288720762355712,
    "created_at" : "2012-11-10 15:32:51 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 267289040364113920,
  "created_at" : "2012-11-10 15:34:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhys Morgan",
      "screen_name" : "rhysmorgan",
      "indices" : [ 3, 14 ],
      "id_str" : "15040935",
      "id" : 15040935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267096225420025856",
  "text" : "RT @rhysmorgan: Twitter needs two types of retweet. One is an \"I agree with this\" retweet and then a \"Jesus Christ what the fuck is this ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266983902881665024",
    "text" : "Twitter needs two types of retweet. One is an \"I agree with this\" retweet and then a \"Jesus Christ what the fuck is this shit ;_;\" RT",
    "id" : 266983902881665024,
    "created_at" : "2012-11-09 19:21:37 +0000",
    "user" : {
      "name" : "Rhys Morgan",
      "screen_name" : "rhysmorgan",
      "protected" : false,
      "id_str" : "15040935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762970937952182272\/PSXQ_Ttc_normal.jpg",
      "id" : 15040935,
      "verified" : true
    }
  },
  "id" : 267096225420025856,
  "created_at" : "2012-11-10 02:47:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "taschekats",
      "screen_name" : "taschekats",
      "indices" : [ 0, 11 ],
      "id_str" : "74211986",
      "id" : 74211986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267079732397498369",
  "geo" : { },
  "id_str" : "267080870505115648",
  "in_reply_to_user_id" : 74211986,
  "text" : "@taschekats RIP dear Hobo",
  "id" : 267080870505115648,
  "in_reply_to_status_id" : 267079732397498369,
  "created_at" : "2012-11-10 01:46:56 +0000",
  "in_reply_to_screen_name" : "taschekats",
  "in_reply_to_user_id_str" : "74211986",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/N8gZsx0Y",
      "expanded_url" : "http:\/\/tinyurl.com\/75q2u2e",
      "display_url" : "tinyurl.com\/75q2u2e"
    } ]
  },
  "geo" : { },
  "id_str" : "267062641208475648",
  "text" : "RT @Soulseedzforall: No act of kindness, no matter how small, is ever wasted. Aesop, http:\/\/t.co\/N8gZsx0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/N8gZsx0Y",
        "expanded_url" : "http:\/\/tinyurl.com\/75q2u2e",
        "display_url" : "tinyurl.com\/75q2u2e"
      } ]
    },
    "geo" : { },
    "id_str" : "267062318507114497",
    "text" : "No act of kindness, no matter how small, is ever wasted. Aesop, http:\/\/t.co\/N8gZsx0Y",
    "id" : 267062318507114497,
    "created_at" : "2012-11-10 00:33:13 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 267062641208475648,
  "created_at" : "2012-11-10 00:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Bella Allen",
      "screen_name" : "MsBellaF",
      "indices" : [ 9, 18 ],
      "id_str" : "29227739",
      "id" : 29227739
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 19, 29 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267061806734917632",
  "geo" : { },
  "id_str" : "267062345241600000",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH @MsBellaF @JALpalyul i mean how can that be bad? we get blessed to death or something? lol",
  "id" : 267062345241600000,
  "in_reply_to_status_id" : 267061806734917632,
  "created_at" : "2012-11-10 00:33:19 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Bella Allen",
      "screen_name" : "MsBellaF",
      "indices" : [ 45, 54 ],
      "id_str" : "29227739",
      "id" : 29227739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/v7SpcFHJ",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2012\/11\/03\/1155004\/-Romney-Ohio-Rally-Supporters-Must-See-Video",
      "display_url" : "dailykos.com\/story\/2012\/11\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "267057748838072321",
  "geo" : { },
  "id_str" : "267060407087267840",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH http:\/\/t.co\/v7SpcFHJ at approx 7:26 @MsBellaF",
  "id" : 267060407087267840,
  "in_reply_to_status_id" : 267057748838072321,
  "created_at" : "2012-11-10 00:25:37 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267044913621909505",
  "text" : "RT @Adenovir: Can we just bury the myth of the \"Job Creator\" once and for all. Demand creates jobs. No demand, no jobs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266982166091673600",
    "text" : "Can we just bury the myth of the \"Job Creator\" once and for all. Demand creates jobs. No demand, no jobs.",
    "id" : 266982166091673600,
    "created_at" : "2012-11-09 19:14:43 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 267044913621909505,
  "created_at" : "2012-11-09 23:24:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267043744111529985",
  "geo" : { },
  "id_str" : "267044654992740352",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska ouch! glad you're ok!",
  "id" : 267044654992740352,
  "in_reply_to_status_id" : 267043744111529985,
  "created_at" : "2012-11-09 23:23:01 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267020227622100992",
  "text" : "RT @abandontheherd: F____ it: The mantra of surrender",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267019827720359937",
    "text" : "F____ it: The mantra of surrender",
    "id" : 267019827720359937,
    "created_at" : "2012-11-09 21:44:22 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 267020227622100992,
  "created_at" : "2012-11-09 21:45:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267011045292392448",
  "text" : "RT @davidpakmanshow: We are having a huge copyright issue with a video. Please help, it's the newest post on Facebook for all the info:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/3fPZqxO2",
        "expanded_url" : "http:\/\/ow.ly\/faxde",
        "display_url" : "ow.ly\/faxde"
      } ]
    },
    "geo" : { },
    "id_str" : "267008287021600768",
    "text" : "We are having a huge copyright issue with a video. Please help, it's the newest post on Facebook for all the info: http:\/\/t.co\/3fPZqxO2",
    "id" : 267008287021600768,
    "created_at" : "2012-11-09 20:58:31 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 267011045292392448,
  "created_at" : "2012-11-09 21:09:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipodtouch",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "itunes",
      "indices" : [ 85, 92 ]
    }, {
      "text" : "apple",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266977392432652288",
  "text" : "looking for voice recorder app to make lists and be able to add to lists? #ipodtouch #itunes #apple",
  "id" : 266977392432652288,
  "created_at" : "2012-11-09 18:55:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266964615785771011",
  "geo" : { },
  "id_str" : "266965391484530688",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench oh, it's cute! congratulations!!! : )",
  "id" : 266965391484530688,
  "in_reply_to_status_id" : 266964615785771011,
  "created_at" : "2012-11-09 18:08:03 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "indices" : [ 3, 12 ],
      "id_str" : "17304367",
      "id" : 17304367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266958758150803457",
  "text" : "RT @bookpage: A mystifying disease with seemingly no diagnosis makes for a fascinating memoir of madness in BRAIN ON FIRE: http:\/\/t.co\/J ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susannah Cahalan",
        "screen_name" : "scahalan",
        "indices" : [ 130, 139 ],
        "id_str" : "14247287",
        "id" : 14247287
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/Jrv7R912",
        "expanded_url" : "http:\/\/ht.ly\/eHHht",
        "display_url" : "ht.ly\/eHHht"
      } ]
    },
    "geo" : { },
    "id_str" : "266956111297527808",
    "text" : "A mystifying disease with seemingly no diagnosis makes for a fascinating memoir of madness in BRAIN ON FIRE: http:\/\/t.co\/Jrv7R912 @scahalan",
    "id" : 266956111297527808,
    "created_at" : "2012-11-09 17:31:11 +0000",
    "user" : {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "protected" : false,
      "id_str" : "17304367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793482805435068416\/rGBg6Wdr_normal.jpg",
      "id" : 17304367,
      "verified" : false
    }
  },
  "id" : 266958758150803457,
  "created_at" : "2012-11-09 17:41:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266947766343839744",
  "text" : "RT @CoyoteSings: All of Congress, who gets the best medical care for free, need to stop talking about \"entitlements.\" Trying being poor  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266947268953915392",
    "text" : "All of Congress, who gets the best medical care for free, need to stop talking about \"entitlements.\" Trying being poor and sick, assholes.",
    "id" : 266947268953915392,
    "created_at" : "2012-11-09 16:56:03 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 266947766343839744,
  "created_at" : "2012-11-09 16:58:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iAppCreation",
      "screen_name" : "iAppCreation",
      "indices" : [ 3, 16 ],
      "id_str" : "122610723",
      "id" : 122610723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "app",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/8KBa1pMy",
      "expanded_url" : "http:\/\/goo.gl\/7deUl",
      "display_url" : "goo.gl\/7deUl"
    } ]
  },
  "geo" : { },
  "id_str" : "266945973744451585",
  "text" : "RT @iAppCreation: Now Free VOT: Voice To-dos Download Now Before Price Goes Up (Was $1.99) http:\/\/t.co\/8KBa1pMy #iPhone #app",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iPhone",
        "indices" : [ 94, 101 ]
      }, {
        "text" : "app",
        "indices" : [ 102, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/8KBa1pMy",
        "expanded_url" : "http:\/\/goo.gl\/7deUl",
        "display_url" : "goo.gl\/7deUl"
      } ]
    },
    "geo" : { },
    "id_str" : "266944590152622081",
    "text" : "Now Free VOT: Voice To-dos Download Now Before Price Goes Up (Was $1.99) http:\/\/t.co\/8KBa1pMy #iPhone #app",
    "id" : 266944590152622081,
    "created_at" : "2012-11-09 16:45:24 +0000",
    "user" : {
      "name" : "iAppCreation",
      "screen_name" : "iAppCreation",
      "protected" : false,
      "id_str" : "122610723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494366188634263552\/4wBKdDSA_normal.png",
      "id" : 122610723,
      "verified" : false
    }
  },
  "id" : 266945973744451585,
  "created_at" : "2012-11-09 16:50:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imcrazy",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266943735072448512",
  "text" : "my aura is all riled up and i hate this feeling.. so my tweets could be \/ will be .. weird... #imcrazy",
  "id" : 266943735072448512,
  "created_at" : "2012-11-09 16:42:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266942355624566785",
  "text" : ". @iEyeAyes im sure he'd want to shoot me...",
  "id" : 266942355624566785,
  "created_at" : "2012-11-09 16:36:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266941827981144064",
  "text" : "\"Life? Don't talk to me about life!\" - Marvin",
  "id" : 266941827981144064,
  "created_at" : "2012-11-09 16:34:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 2, 18 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266933732152336384",
  "geo" : { },
  "id_str" : "266941468210507776",
  "in_reply_to_user_id" : 17489079,
  "text" : ". @aliceinthewater half? try all... there is no light. it's just an illusion, a mirage.",
  "id" : 266941468210507776,
  "in_reply_to_status_id" : 266933732152336384,
  "created_at" : "2012-11-09 16:33:00 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Unknown",
      "screen_name" : "3_finker",
      "indices" : [ 2, 11 ],
      "id_str" : "261787241",
      "id" : 261787241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266892547908063232",
  "geo" : { },
  "id_str" : "266940949073117184",
  "in_reply_to_user_id" : 261787241,
  "text" : ". @3_finker either way, who cares? i dont give a damn anymore...",
  "id" : 266940949073117184,
  "in_reply_to_status_id" : 266892547908063232,
  "created_at" : "2012-11-09 16:30:56 +0000",
  "in_reply_to_screen_name" : "3_finker",
  "in_reply_to_user_id_str" : "261787241",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266940266680832002",
  "text" : "RT @CoyoteSings: This country is split in half. It is not the politicians fault. They reflect us. We are split in our ideology with no c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266936972944232448",
    "text" : "This country is split in half. It is not the politicians fault. They reflect us. We are split in our ideology with no compromise in sight.",
    "id" : 266936972944232448,
    "created_at" : "2012-11-09 16:15:08 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 266940266680832002,
  "created_at" : "2012-11-09 16:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 2, 14 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266937816993370112",
  "geo" : { },
  "id_str" : "266940206169600000",
  "in_reply_to_user_id" : 118573185,
  "text" : ". @CoyoteSings im tired of this whole damn world arguing, arguing, arguing. the whole gd world sucks... sigh.",
  "id" : 266940206169600000,
  "in_reply_to_status_id" : 266937816993370112,
  "created_at" : "2012-11-09 16:27:59 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna White Glaser",
      "screen_name" : "readdonnaglaser",
      "indices" : [ 3, 19 ],
      "id_str" : "174919515",
      "id" : 174919515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/xqExvLAY",
      "expanded_url" : "http:\/\/fb.me\/KQ2NrrMV",
      "display_url" : "fb.me\/KQ2NrrMV"
    } ]
  },
  "geo" : { },
  "id_str" : "266925219627810816",
  "text" : "RT @readdonnaglaser: It's easy to misinterpret someone. http:\/\/t.co\/xqExvLAY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/xqExvLAY",
        "expanded_url" : "http:\/\/fb.me\/KQ2NrrMV",
        "display_url" : "fb.me\/KQ2NrrMV"
      } ]
    },
    "geo" : { },
    "id_str" : "266923352738910210",
    "text" : "It's easy to misinterpret someone. http:\/\/t.co\/xqExvLAY",
    "id" : 266923352738910210,
    "created_at" : "2012-11-09 15:21:01 +0000",
    "user" : {
      "name" : "Donna White Glaser",
      "screen_name" : "readdonnaglaser",
      "protected" : false,
      "id_str" : "174919515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1493489633\/D06F9042ret-comp_normal.jpg",
      "id" : 174919515,
      "verified" : false
    }
  },
  "id" : 266925219627810816,
  "created_at" : "2012-11-09 15:28:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266924845932085248",
  "text" : "RT @LaughingBaba: Being angry only disturbs your own state of mind...it seldom affects who you are angry with.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266923765655535616",
    "text" : "Being angry only disturbs your own state of mind...it seldom affects who you are angry with.",
    "id" : 266923765655535616,
    "created_at" : "2012-11-09 15:22:39 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 266924845932085248,
  "created_at" : "2012-11-09 15:26:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266924779318153216",
  "text" : "RT @oshum: Love is not so much about Giving or Receiving...but about BEING Love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266924236608782337",
    "text" : "Love is not so much about Giving or Receiving...but about BEING Love.",
    "id" : 266924236608782337,
    "created_at" : "2012-11-09 15:24:31 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 266924779318153216,
  "created_at" : "2012-11-09 15:26:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/266923981087580160\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4FsppwEn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7RN8lNCIAA2xmA.jpg",
      "id_str" : "266923981095968768",
      "id" : 266923981095968768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7RN8lNCIAA2xmA.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/4FsppwEn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266924579115638786",
  "text" : "RT @petsalive: Why ANY adopter would do that when they know all our dogs can come back here at any time, is beyond me. http:\/\/t.co\/4FsppwEn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/266923981087580160\/photo\/1",
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/4FsppwEn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7RN8lNCIAA2xmA.jpg",
        "id_str" : "266923981095968768",
        "id" : 266923981095968768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7RN8lNCIAA2xmA.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/4FsppwEn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266923981087580160",
    "text" : "Why ANY adopter would do that when they know all our dogs can come back here at any time, is beyond me. http:\/\/t.co\/4FsppwEn",
    "id" : 266923981087580160,
    "created_at" : "2012-11-09 15:23:31 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 266924579115638786,
  "created_at" : "2012-11-09 15:25:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266924258582724608",
  "text" : "RT @sparklekaz: \"Never speak out of anger, Never act out of fear, Never choose from impatience, But wait, and peace will appear.\" Guy Finley",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266924130589343746",
    "text" : "\"Never speak out of anger, Never act out of fear, Never choose from impatience, But wait, and peace will appear.\" Guy Finley",
    "id" : 266924130589343746,
    "created_at" : "2012-11-09 15:24:06 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 266924258582724608,
  "created_at" : "2012-11-09 15:24:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266924143654617088",
  "text" : "@Skeptical_Lady depends on intent. if you're having medical issues, someone might say \"i'll pray for you\" as a sign of support.",
  "id" : 266924143654617088,
  "created_at" : "2012-11-09 15:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266923352495648769",
  "text" : "this world is hopeless...",
  "id" : 266923352495648769,
  "created_at" : "2012-11-09 15:21:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blessed",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266908137490096128",
  "text" : "RT @CharlesBivona: Mmmmm. Coffee. #blessed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blessed",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266908019575648256",
    "text" : "Mmmmm. Coffee. #blessed",
    "id" : 266908019575648256,
    "created_at" : "2012-11-09 14:20:05 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 266908137490096128,
  "created_at" : "2012-11-09 14:20:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rockon",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/MbMsDrFq",
      "expanded_url" : "http:\/\/youtu.be\/7ehGIYyjVDs",
      "display_url" : "youtu.be\/7ehGIYyjVDs"
    } ]
  },
  "geo" : { },
  "id_str" : "266905640176340992",
  "text" : "Nice! &gt;&gt; MattRach - Adele \"Someone like you\" Guitar Cover: http:\/\/t.co\/MbMsDrFq #rockon",
  "id" : 266905640176340992,
  "created_at" : "2012-11-09 14:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WhiteHousePressCorps",
      "screen_name" : "whpresscorps",
      "indices" : [ 3, 16 ],
      "id_str" : "19416225",
      "id" : 19416225
    }, {
      "name" : "Dylan Byers",
      "screen_name" : "DylanByers",
      "indices" : [ 21, 32 ],
      "id_str" : "236026761",
      "id" : 236026761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Kpcr3hSB",
      "expanded_url" : "http:\/\/bit.ly\/Q0Af0V",
      "display_url" : "bit.ly\/Q0Af0V"
    } ]
  },
  "geo" : { },
  "id_str" : "266713675488968705",
  "text" : "RT @whpresscorps: RT @DylanByers: WOW. President Obama starts crying addressing volunteers at campaign headquarters http:\/\/t.co\/Kpcr3hSB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dylan Byers",
        "screen_name" : "DylanByers",
        "indices" : [ 3, 14 ],
        "id_str" : "236026761",
        "id" : 236026761
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/Kpcr3hSB",
        "expanded_url" : "http:\/\/bit.ly\/Q0Af0V",
        "display_url" : "bit.ly\/Q0Af0V"
      } ]
    },
    "geo" : { },
    "id_str" : "266705384406937602",
    "text" : "RT @DylanByers: WOW. President Obama starts crying addressing volunteers at campaign headquarters http:\/\/t.co\/Kpcr3hSB",
    "id" : 266705384406937602,
    "created_at" : "2012-11-09 00:54:53 +0000",
    "user" : {
      "name" : "WhiteHousePressCorps",
      "screen_name" : "whpresscorps",
      "protected" : false,
      "id_str" : "19416225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3671084906\/23debcfe919f678a81e8354e1ee0cf43_normal.jpeg",
      "id" : 19416225,
      "verified" : false
    }
  },
  "id" : 266713675488968705,
  "created_at" : "2012-11-09 01:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 3, 16 ],
      "id_str" : "145890580",
      "id" : 145890580
    }, {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 39, 50 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266709561287790592",
  "text" : "RT @AmyRBromberg: Listen up people! RT @corybooker: Be kind to one another. We are all more fragile than we let on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Booker",
        "screen_name" : "CoryBooker",
        "indices" : [ 21, 32 ],
        "id_str" : "15808765",
        "id" : 15808765
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266708694811684865",
    "text" : "Listen up people! RT @corybooker: Be kind to one another. We are all more fragile than we let on.",
    "id" : 266708694811684865,
    "created_at" : "2012-11-09 01:08:02 +0000",
    "user" : {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "protected" : false,
      "id_str" : "145890580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754371483720376320\/lPjb2W1B_normal.jpg",
      "id" : 145890580,
      "verified" : false
    }
  },
  "id" : 266709561287790592,
  "created_at" : "2012-11-09 01:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266695767211769856",
  "geo" : { },
  "id_str" : "266696399456976896",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hubby's beef stew earlier. now waiting on PB cookies in a few minutes.",
  "id" : 266696399456976896,
  "in_reply_to_status_id" : 266695767211769856,
  "created_at" : "2012-11-09 00:19:11 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266647650131120129",
  "geo" : { },
  "id_str" : "266649696045522947",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 oh my.. that is precious! : )",
  "id" : 266649696045522947,
  "in_reply_to_status_id" : 266647650131120129,
  "created_at" : "2012-11-08 21:13:36 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CJ Lyons",
      "screen_name" : "cjlyonswriter",
      "indices" : [ 3, 17 ],
      "id_str" : "17312174",
      "id" : 17312174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/T9JtwYmz",
      "expanded_url" : "http:\/\/ow.ly\/f7SkM",
      "display_url" : "ow.ly\/f7SkM"
    } ]
  },
  "geo" : { },
  "id_str" : "266592430084726784",
  "text" : "RT @cjlyonswriter: How one Roadmap student sold a million books on Kindle http:\/\/t.co\/T9JtwYmz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/T9JtwYmz",
        "expanded_url" : "http:\/\/ow.ly\/f7SkM",
        "display_url" : "ow.ly\/f7SkM"
      } ]
    },
    "geo" : { },
    "id_str" : "266568331362959360",
    "text" : "How one Roadmap student sold a million books on Kindle http:\/\/t.co\/T9JtwYmz",
    "id" : 266568331362959360,
    "created_at" : "2012-11-08 15:50:17 +0000",
    "user" : {
      "name" : "CJ Lyons",
      "screen_name" : "cjlyonswriter",
      "protected" : false,
      "id_str" : "17312174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1188960586\/CJheadshotlores_normal.jpg",
      "id" : 17312174,
      "verified" : false
    }
  },
  "id" : 266592430084726784,
  "created_at" : "2012-11-08 17:26:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266580509910515714",
  "text" : "RT @brandonrofl: I just really think it's funny how our own elections divide us, yet we're supposed to be united",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266577555463737344",
    "text" : "I just really think it's funny how our own elections divide us, yet we're supposed to be united",
    "id" : 266577555463737344,
    "created_at" : "2012-11-08 16:26:56 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 266580509910515714,
  "created_at" : "2012-11-08 16:38:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas",
      "screen_name" : "dan_verg_",
      "indices" : [ 44, 54 ],
      "id_str" : "3160564380",
      "id" : 3160564380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266568896297988097",
  "geo" : { },
  "id_str" : "266572578934648834",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker wow.. what a sad angry man.. @dan_verg_",
  "id" : 266572578934648834,
  "in_reply_to_status_id" : 266568896297988097,
  "created_at" : "2012-11-08 16:07:10 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266565966920548352",
  "text" : "sometimes it all seems so hopeless.. billions of ppl, each one w unique perception of life causing strife.",
  "id" : 266565966920548352,
  "created_at" : "2012-11-08 15:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 15, 30 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266564929232969731",
  "text" : "@DuluenFSM LOL @LoveHonorTruth",
  "id" : 266564929232969731,
  "created_at" : "2012-11-08 15:36:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blasted Heathens",
      "screen_name" : "BlastedHeathens",
      "indices" : [ 3, 19 ],
      "id_str" : "389019977",
      "id" : 389019977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/YvW17nv8",
      "expanded_url" : "http:\/\/eepurl.com\/rxUBj",
      "display_url" : "eepurl.com\/rxUBj"
    } ]
  },
  "geo" : { },
  "id_str" : "266562325132238849",
  "text" : "RT @BlastedHeathens: Two free books from Blasted Heath - http:\/\/t.co\/YvW17nv8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.mailchimp.com\" rel=\"nofollow\"\u003EMailChimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/YvW17nv8",
        "expanded_url" : "http:\/\/eepurl.com\/rxUBj",
        "display_url" : "eepurl.com\/rxUBj"
      } ]
    },
    "geo" : { },
    "id_str" : "266555309647081474",
    "text" : "Two free books from Blasted Heath - http:\/\/t.co\/YvW17nv8",
    "id" : 266555309647081474,
    "created_at" : "2012-11-08 14:58:32 +0000",
    "user" : {
      "name" : "Blasted Heathens",
      "screen_name" : "BlastedHeathens",
      "protected" : false,
      "id_str" : "389019977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2586468246\/115w64f6okiq2o4hfg95_normal.jpeg",
      "id" : 389019977,
      "verified" : false
    }
  },
  "id" : 266562325132238849,
  "created_at" : "2012-11-08 15:26:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 0, 10 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266536136539795456",
  "geo" : { },
  "id_str" : "266555628426780672",
  "in_reply_to_user_id" : 15395727,
  "text" : "@AppAdvice Woohoo! Thank you! : )",
  "id" : 266555628426780672,
  "in_reply_to_status_id" : 266536136539795456,
  "created_at" : "2012-11-08 14:59:48 +0000",
  "in_reply_to_screen_name" : "AppAdvice",
  "in_reply_to_user_id_str" : "15395727",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0418\u043D\u0433\u0430 \u0421\u0430\u043C\u0430\u0440\u0438\u043D\u0430 \u041A\u043E\u043D\u0444\u0435\u0442",
      "screen_name" : "psychic_live",
      "indices" : [ 3, 16 ],
      "id_str" : "80937373",
      "id" : 80937373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266541655702765569",
  "text" : "RT @psychic_live: No act of kindness, no matter how small, is ever wasted: Aesop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266517258216566784",
    "text" : "No act of kindness, no matter how small, is ever wasted: Aesop",
    "id" : 266517258216566784,
    "created_at" : "2012-11-08 12:27:20 +0000",
    "user" : {
      "name" : "ZODIAC FOX",
      "screen_name" : "ZodiacFox",
      "protected" : false,
      "id_str" : "906143616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494532558709719040\/pC2SaYpg_normal.png",
      "id" : 906143616,
      "verified" : false
    }
  },
  "id" : 266541655702765569,
  "created_at" : "2012-11-08 14:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/GcJFj2ZV",
      "expanded_url" : "http:\/\/getapp.cc\/app\/568485351",
      "display_url" : "getapp.cc\/app\/568485351"
    } ]
  },
  "geo" : { },
  "id_str" : "266536535913033730",
  "text" : "RT @AppAdvice: Retweet now for a chance to win universal panda-themed puzzle game Pandoodle (http:\/\/t.co\/GcJFj2ZV)!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/GcJFj2ZV",
        "expanded_url" : "http:\/\/getapp.cc\/app\/568485351",
        "display_url" : "getapp.cc\/app\/568485351"
      } ]
    },
    "geo" : { },
    "id_str" : "266536136539795456",
    "text" : "Retweet now for a chance to win universal panda-themed puzzle game Pandoodle (http:\/\/t.co\/GcJFj2ZV)!",
    "id" : 266536136539795456,
    "created_at" : "2012-11-08 13:42:21 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 266536535913033730,
  "created_at" : "2012-11-08 13:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 3, 14 ],
      "id_str" : "15314194",
      "id" : 15314194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266306355332272128",
  "text" : "RT @dee_carney: When you feel the need to drop the f-bomb a lot at your two year old, while in public, perhaps there's something wrong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266305704992837634",
    "text" : "When you feel the need to drop the f-bomb a lot at your two year old, while in public, perhaps there's something wrong.",
    "id" : 266305704992837634,
    "created_at" : "2012-11-07 22:26:42 +0000",
    "user" : {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "protected" : false,
      "id_str" : "15314194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649739435890839552\/00nSuPH-_normal.jpg",
      "id" : 15314194,
      "verified" : false
    }
  },
  "id" : 266306355332272128,
  "created_at" : "2012-11-07 22:29:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cookiesaregood",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266299017456136192",
  "geo" : { },
  "id_str" : "266299817725140993",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH no,no,no! need to buy them in bulk! #cookiesaregood",
  "id" : 266299817725140993,
  "in_reply_to_status_id" : 266299017456136192,
  "created_at" : "2012-11-07 22:03:18 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Challis",
      "screen_name" : "tesschallis",
      "indices" : [ 3, 15 ],
      "id_str" : "59968519",
      "id" : 59968519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266252513831952386",
  "text" : "RT @tesschallis: Spread love everywhere you go. Let no one ever come to you without leaving happier. ~Mother Teresa #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266250818473295872",
    "text" : "Spread love everywhere you go. Let no one ever come to you without leaving happier. ~Mother Teresa #quote",
    "id" : 266250818473295872,
    "created_at" : "2012-11-07 18:48:36 +0000",
    "user" : {
      "name" : "Tess Challis",
      "screen_name" : "tesschallis",
      "protected" : false,
      "id_str" : "59968519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708285115781099520\/k5W8b1mr_normal.jpg",
      "id" : 59968519,
      "verified" : false
    }
  },
  "id" : 266252513831952386,
  "created_at" : "2012-11-07 18:55:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266240883538677760",
  "geo" : { },
  "id_str" : "266246857250979841",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell awww ((blush)) i think you're pretty awesome, too : )",
  "id" : 266246857250979841,
  "in_reply_to_status_id" : 266240883538677760,
  "created_at" : "2012-11-07 18:32:52 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266239866478665728",
  "geo" : { },
  "id_str" : "266240658082234368",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell lol.. i say that (or similar) to myself often. great truth in \"if not nice, dont say it\" ((hugs))",
  "id" : 266240658082234368,
  "in_reply_to_status_id" : 266239866478665728,
  "created_at" : "2012-11-07 18:08:14 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266239508134113280",
  "text" : "RT @CaroleODell: Courtesy. Kindness. Love. These will win over disrespect, selfishness and hatred every time. Be classy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266239092851884032",
    "text" : "Courtesy. Kindness. Love. These will win over disrespect, selfishness and hatred every time. Be classy.",
    "id" : 266239092851884032,
    "created_at" : "2012-11-07 18:02:00 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 266239508134113280,
  "created_at" : "2012-11-07 18:03:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266238135040614401",
  "geo" : { },
  "id_str" : "266239337384009728",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell agreed. gloating is not pretty.",
  "id" : 266239337384009728,
  "in_reply_to_status_id" : 266238135040614401,
  "created_at" : "2012-11-07 18:02:59 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Butler Bass",
      "screen_name" : "dianabutlerbass",
      "indices" : [ 3, 19 ],
      "id_str" : "118735458",
      "id" : 118735458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266227495148326913",
  "text" : "RT @dianabutlerbass: Dear God, please let those who are angry &amp; fearful understand that we really are one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266072663296974850",
    "text" : "Dear God, please let those who are angry &amp; fearful understand that we really are one.",
    "id" : 266072663296974850,
    "created_at" : "2012-11-07 07:00:40 +0000",
    "user" : {
      "name" : "Diana Butler Bass",
      "screen_name" : "dianabutlerbass",
      "protected" : false,
      "id_str" : "118735458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624239258237304832\/91K85v4W_normal.jpg",
      "id" : 118735458,
      "verified" : false
    }
  },
  "id" : 266227495148326913,
  "created_at" : "2012-11-07 17:15:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266227266541977601",
  "text" : "RT @morsemusings: You don't get to pick what expands your heart. God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266227000216260608",
    "text" : "You don't get to pick what expands your heart. God.",
    "id" : 266227000216260608,
    "created_at" : "2012-11-07 17:13:57 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 266227266541977601,
  "created_at" : "2012-11-07 17:15:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266225932178710528",
  "text" : "RT @AnnotatedBible: Cory Booker for President in 2016.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266220395852599296",
    "text" : "Cory Booker for President in 2016.",
    "id" : 266220395852599296,
    "created_at" : "2012-11-07 16:47:43 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 266225932178710528,
  "created_at" : "2012-11-07 17:09:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 2, 17 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266221218372399104",
  "geo" : { },
  "id_str" : "266225614128820224",
  "in_reply_to_user_id" : 242204735,
  "text" : ". @AnnotatedBible hmm.. do you thnk Jesus would have agreed w this? everyone needs to eat...",
  "id" : 266225614128820224,
  "in_reply_to_status_id" : 266221218372399104,
  "created_at" : "2012-11-07 17:08:27 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galina Leighton",
      "screen_name" : "GalinaLeighton",
      "indices" : [ 3, 18 ],
      "id_str" : "230537105",
      "id" : 230537105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/HQquTQjW",
      "expanded_url" : "http:\/\/ow.ly\/f01e0",
      "display_url" : "ow.ly\/f01e0"
    } ]
  },
  "geo" : { },
  "id_str" : "266211692118167552",
  "text" : "RT @GalinaLeighton: Photo of the Day - Canada Geese Family http:\/\/t.co\/HQquTQjW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/HQquTQjW",
        "expanded_url" : "http:\/\/ow.ly\/f01e0",
        "display_url" : "ow.ly\/f01e0"
      } ]
    },
    "geo" : { },
    "id_str" : "265180466276073472",
    "text" : "Photo of the Day - Canada Geese Family http:\/\/t.co\/HQquTQjW",
    "id" : 265180466276073472,
    "created_at" : "2012-11-04 19:55:24 +0000",
    "user" : {
      "name" : "Galina Leighton",
      "screen_name" : "GalinaLeighton",
      "protected" : false,
      "id_str" : "230537105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1198822855\/Galina1-Edit-2_normal.jpg",
      "id" : 230537105,
      "verified" : false
    }
  },
  "id" : 266211692118167552,
  "created_at" : "2012-11-07 16:13:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266209749027139584",
  "text" : "RT @OMGFacts: Showing people FACTS that contradict their BELIEFS actually REINFORCES THEM them! Check out this study ---&gt; http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/eVkVQpXL",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/Hlx",
        "display_url" : "omgf.ac\/ts\/Hlx"
      } ]
    },
    "geo" : { },
    "id_str" : "266208530682490881",
    "text" : "Showing people FACTS that contradict their BELIEFS actually REINFORCES THEM them! Check out this study ---&gt; http:\/\/t.co\/eVkVQpXL",
    "id" : 266208530682490881,
    "created_at" : "2012-11-07 16:00:34 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 266209749027139584,
  "created_at" : "2012-11-07 16:05:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "indices" : [ 3, 16 ],
      "id_str" : "42481335",
      "id" : 42481335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266205387647246336",
  "text" : "RT @LegionAvalon: It's not what you look at that matters, it's what you see. ~ Thoreau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erased1519040.com\" rel=\"nofollow\"\u003Eerased1519040\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266202839334920193",
    "text" : "It's not what you look at that matters, it's what you see. ~ Thoreau",
    "id" : 266202839334920193,
    "created_at" : "2012-11-07 15:37:57 +0000",
    "user" : {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "protected" : false,
      "id_str" : "42481335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3391327613\/c795db5eaa583c2e7f3d9799771ff3c3_normal.jpeg",
      "id" : 42481335,
      "verified" : false
    }
  },
  "id" : 266205387647246336,
  "created_at" : "2012-11-07 15:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266205115365617666",
  "text" : "this could explain my wishy-washyness.. why i find it difficult to \"take sides\"...",
  "id" : 266205115365617666,
  "created_at" : "2012-11-07 15:47:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266204821617516544",
  "text" : "my gift is my curse. i can often empathize w the opposite view.",
  "id" : 266204821617516544,
  "created_at" : "2012-11-07 15:45:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266204393123217408",
  "text" : "we are one. when we poke at each other, we are just creating more pain for all.",
  "id" : 266204393123217408,
  "created_at" : "2012-11-07 15:44:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266204049794277376",
  "text" : "my joy of results is tempered by compassion for those who see it differently.",
  "id" : 266204049794277376,
  "created_at" : "2012-11-07 15:42:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266199721503256576",
  "geo" : { },
  "id_str" : "266203291044687873",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska awww.. thanks for rt. ((hugs))",
  "id" : 266203291044687873,
  "in_reply_to_status_id" : 266199721503256576,
  "created_at" : "2012-11-07 15:39:45 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266201384234414080",
  "text" : "RT @JALpalyul: There can only be darkness where the light is not. You are the light. Be then everywhere",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266194234074349569",
    "text" : "There can only be darkness where the light is not. You are the light. Be then everywhere",
    "id" : 266194234074349569,
    "created_at" : "2012-11-07 15:03:45 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 266201384234414080,
  "created_at" : "2012-11-07 15:32:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266200592312061952",
  "text" : "RT @SheilaWalsh: The enemy has no weapon in his arsenal to combat the power of forgiveness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266197033361231872",
    "text" : "The enemy has no weapon in his arsenal to combat the power of forgiveness",
    "id" : 266197033361231872,
    "created_at" : "2012-11-07 15:14:53 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 266200592312061952,
  "created_at" : "2012-11-07 15:29:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266199580914372608",
  "text" : "asking angels to help us come together and bring peace to those who are fearful. thank you.",
  "id" : 266199580914372608,
  "created_at" : "2012-11-07 15:25:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy",
      "screen_name" : "NYTupelo7",
      "indices" : [ 3, 13 ],
      "id_str" : "38723680",
      "id" : 38723680
    }, {
      "name" : "We Got Ed",
      "screen_name" : "WeGotEd",
      "indices" : [ 18, 26 ],
      "id_str" : "3113887713",
      "id" : 3113887713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265970412599513089",
  "text" : "RT @NYTupelo7: RT @WeGotEd: NBC News declares Bernie Sanders the projected winner in Vermont Senate Race &lt;--Good News. Bernie Sanders ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We Got Ed",
        "screen_name" : "WeGotEd",
        "indices" : [ 3, 11 ],
        "id_str" : "3113887713",
        "id" : 3113887713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265968371441483776",
    "text" : "RT @WeGotEd: NBC News declares Bernie Sanders the projected winner in Vermont Senate Race &lt;--Good News. Bernie Sanders is the MAN!!",
    "id" : 265968371441483776,
    "created_at" : "2012-11-07 00:06:15 +0000",
    "user" : {
      "name" : "Tracy",
      "screen_name" : "NYTupelo7",
      "protected" : false,
      "id_str" : "38723680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1561724072\/161658_1005716263_7356156_n_normal.jpg",
      "id" : 38723680,
      "verified" : false
    }
  },
  "id" : 265970412599513089,
  "created_at" : "2012-11-07 00:14:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265967845488332801",
  "text" : "i totally agree w gypsy taub (previous RT w link) #freedom",
  "id" : 265967845488332801,
  "created_at" : "2012-11-07 00:04:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/E9QuPF0S",
      "expanded_url" : "http:\/\/huff.to\/Rf4rCm",
      "display_url" : "huff.to\/Rf4rCm"
    } ]
  },
  "geo" : { },
  "id_str" : "265965586176163840",
  "text" : "RT @HuffPostWeird: WATCH: Woman gets naked at San Francisco Supervisors' nudity hearing (NSFW video) http:\/\/t.co\/E9QuPF0S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/E9QuPF0S",
        "expanded_url" : "http:\/\/huff.to\/Rf4rCm",
        "display_url" : "huff.to\/Rf4rCm"
      } ]
    },
    "geo" : { },
    "id_str" : "265964309677481985",
    "text" : "WATCH: Woman gets naked at San Francisco Supervisors' nudity hearing (NSFW video) http:\/\/t.co\/E9QuPF0S",
    "id" : 265964309677481985,
    "created_at" : "2012-11-06 23:50:07 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 265965586176163840,
  "created_at" : "2012-11-06 23:55:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debby Herbenick, PhD",
      "screen_name" : "DebbyHerbenick",
      "indices" : [ 3, 18 ],
      "id_str" : "17948615",
      "id" : 17948615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265963792985358337",
  "text" : "RT @DebbyHerbenick: Voting is easiest for those w\/resources - flexible jobs, luxury of not working, childcare, a car. Hardest for those  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265959096845488128",
    "text" : "Voting is easiest for those w\/resources - flexible jobs, luxury of not working, childcare, a car. Hardest for those who most need a voice.",
    "id" : 265959096845488128,
    "created_at" : "2012-11-06 23:29:24 +0000",
    "user" : {
      "name" : "Debby Herbenick, PhD",
      "screen_name" : "DebbyHerbenick",
      "protected" : false,
      "id_str" : "17948615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784725974516690945\/JYBNrHSH_normal.jpg",
      "id" : 17948615,
      "verified" : false
    }
  },
  "id" : 265963792985358337,
  "created_at" : "2012-11-06 23:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265952806446456832",
  "text" : "RT @AnnotatedBible: Retweet if America should get rid of the Electoral College and elect Presidents based on the popular vote.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265949645576994816",
    "text" : "Retweet if America should get rid of the Electoral College and elect Presidents based on the popular vote.",
    "id" : 265949645576994816,
    "created_at" : "2012-11-06 22:51:51 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 265952806446456832,
  "created_at" : "2012-11-06 23:04:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovechain",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265922047530643459",
  "text" : "RT @worldtreeman: lets get a #lovechain forming round the globe...take my hand....(RT and get the love going...)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lovechain",
        "indices" : [ 11, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265920054258974720",
    "text" : "lets get a #lovechain forming round the globe...take my hand....(RT and get the love going...)",
    "id" : 265920054258974720,
    "created_at" : "2012-11-06 20:54:16 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 265922047530643459,
  "created_at" : "2012-11-06 21:02:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265914886465392640",
  "text" : "RT @ShipsofSong: All fear comes from the lack of self love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265914320402132992",
    "text" : "All fear comes from the lack of self love.",
    "id" : 265914320402132992,
    "created_at" : "2012-11-06 20:31:29 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 265914886465392640,
  "created_at" : "2012-11-06 20:33:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265912981924233217",
  "geo" : { },
  "id_str" : "265913790258888705",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 we have a birdfeeder on the porch along with a suet dish so the birds are right outside the door by my chair. fun to watch!",
  "id" : 265913790258888705,
  "in_reply_to_status_id" : 265912981924233217,
  "created_at" : "2012-11-06 20:29:22 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "precious",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265911798245494784",
  "text" : "tufted titmouse just landed on door and peered in at me! : ) #precious",
  "id" : 265911798245494784,
  "created_at" : "2012-11-06 20:21:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265887585933615104",
  "text" : "i think it was a female blue jay.. so pretty",
  "id" : 265887585933615104,
  "created_at" : "2012-11-06 18:45:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265884663829102593",
  "text" : "RT @grouchypuppy: Feeling anxious today? Every day (hour?) is better after a spoonful of Cleo &lt;3 Share her photos with anyone who...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/y3qFFWiQ",
        "expanded_url" : "http:\/\/fb.me\/zwH5jpzq",
        "display_url" : "fb.me\/zwH5jpzq"
      } ]
    },
    "geo" : { },
    "id_str" : "265878827627077632",
    "text" : "Feeling anxious today? Every day (hour?) is better after a spoonful of Cleo &lt;3 Share her photos with anyone who... http:\/\/t.co\/y3qFFWiQ",
    "id" : 265878827627077632,
    "created_at" : "2012-11-06 18:10:26 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 265884663829102593,
  "created_at" : "2012-11-06 18:33:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Ripman",
      "screen_name" : "joshuaripman",
      "indices" : [ 3, 16 ],
      "id_str" : "139006528",
      "id" : 139006528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/ILBUkz6N",
      "expanded_url" : "http:\/\/instagr.am\/p\/RsN_Q2gESW\/",
      "display_url" : "instagr.am\/p\/RsN_Q2gESW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "265820683781672960",
  "text" : "RT @joshuaripman: Donkey yeti.   @ The Donkey Sanctuary http:\/\/t.co\/ILBUkz6N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/ILBUkz6N",
        "expanded_url" : "http:\/\/instagr.am\/p\/RsN_Q2gESW\/",
        "display_url" : "instagr.am\/p\/RsN_Q2gESW\/"
      } ]
    },
    "geo" : { },
    "id_str" : "265818280500006912",
    "text" : "Donkey yeti.   @ The Donkey Sanctuary http:\/\/t.co\/ILBUkz6N",
    "id" : 265818280500006912,
    "created_at" : "2012-11-06 14:09:51 +0000",
    "user" : {
      "name" : "Joshua Ripman",
      "screen_name" : "joshuaripman",
      "protected" : false,
      "id_str" : "139006528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000258586124\/7796c2e2d6975301cd7a83d709d64354_normal.jpeg",
      "id" : 139006528,
      "verified" : false
    }
  },
  "id" : 265820683781672960,
  "created_at" : "2012-11-06 14:19:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mohan pande",
      "screen_name" : "DoctorMP",
      "indices" : [ 3, 12 ],
      "id_str" : "60193717",
      "id" : 60193717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265812248772108289",
  "text" : "RT @DoctorMP: If you don't find God in the next person you meet, it is a waste of time looking for him further.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265807216509063169",
    "text" : "If you don't find God in the next person you meet, it is a waste of time looking for him further.",
    "id" : 265807216509063169,
    "created_at" : "2012-11-06 13:25:53 +0000",
    "user" : {
      "name" : "mohan pande",
      "screen_name" : "DoctorMP",
      "protected" : false,
      "id_str" : "60193717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459189041506680832\/GETk_w-p_normal.jpeg",
      "id" : 60193717,
      "verified" : false
    }
  },
  "id" : 265812248772108289,
  "created_at" : "2012-11-06 13:45:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265799671400787968",
  "text" : "and this whole democrat \/ republican thing .. its just a pendulum.",
  "id" : 265799671400787968,
  "created_at" : "2012-11-06 12:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265798775556169728",
  "text" : "i just dont get the electoral college...",
  "id" : 265798775556169728,
  "created_at" : "2012-11-06 12:52:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265798182217326593",
  "text" : "chickadee does not like titmouse..",
  "id" : 265798182217326593,
  "created_at" : "2012-11-06 12:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "neardeathexperience",
      "indices" : [ 114, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265618917203013632",
  "text" : "RT @ificouldtellu: Near-death accounts suggest that unconditional #love is the\nhighest form of religion there is. #neardeathexperience",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 47, 52 ]
      }, {
        "text" : "neardeathexperience",
        "indices" : [ 95, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265616784126795777",
    "text" : "Near-death accounts suggest that unconditional #love is the\nhighest form of religion there is. #neardeathexperience",
    "id" : 265616784126795777,
    "created_at" : "2012-11-06 00:49:10 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 265618917203013632,
  "created_at" : "2012-11-06 00:57:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Toomajian",
      "screen_name" : "zarhooie",
      "indices" : [ 3, 12 ],
      "id_str" : "2390121",
      "id" : 2390121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265602732008820736",
  "text" : "RT @zarhooie: Jeopardy totally just had a clue that said \"this creature doesn't care\" and the answer was honey badger.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265583185205800960",
    "text" : "Jeopardy totally just had a clue that said \"this creature doesn't care\" and the answer was honey badger.",
    "id" : 265583185205800960,
    "created_at" : "2012-11-05 22:35:40 +0000",
    "user" : {
      "name" : "Kat Toomajian",
      "screen_name" : "zarhooie",
      "protected" : false,
      "id_str" : "2390121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681303441373818881\/1VcXtxml_normal.jpg",
      "id" : 2390121,
      "verified" : false
    }
  },
  "id" : 265602732008820736,
  "created_at" : "2012-11-05 23:53:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 0, 12 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265597507768307712",
  "geo" : { },
  "id_str" : "265599449219342337",
  "in_reply_to_user_id" : 16691399,
  "text" : "@fearfuldogs yup...",
  "id" : 265599449219342337,
  "in_reply_to_status_id" : 265597507768307712,
  "created_at" : "2012-11-05 23:40:17 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265590400549531649",
  "geo" : { },
  "id_str" : "265590775117647874",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater YES! : )",
  "id" : 265590775117647874,
  "in_reply_to_status_id" : 265590400549531649,
  "created_at" : "2012-11-05 23:05:49 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265589318058401792",
  "geo" : { },
  "id_str" : "265590340235444224",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater stick w the relieved feeling. think of it as new start.",
  "id" : 265590340235444224,
  "in_reply_to_status_id" : 265589318058401792,
  "created_at" : "2012-11-05 23:04:06 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265589190597677056",
  "geo" : { },
  "id_str" : "265589712268443648",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oh wow.. im sorry..",
  "id" : 265589712268443648,
  "in_reply_to_status_id" : 265589190597677056,
  "created_at" : "2012-11-05 23:01:36 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265580338275823616",
  "text" : "some ppl are just so... i dunno... scary.",
  "id" : 265580338275823616,
  "created_at" : "2012-11-05 22:24:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265573644900659202",
  "text" : "RT @worldtreeman: we will be ok:)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265571587628101633",
    "text" : "we will be ok:)",
    "id" : 265571587628101633,
    "created_at" : "2012-11-05 21:49:35 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 265573644900659202,
  "created_at" : "2012-11-05 21:57:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 77, 84 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265556588713091073",
  "text" : "RT @MartijnLinssen: Plus it's an either-or system, always polarising &gt; RT @berkun: Seven Problems with American Elections http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Berkun",
        "screen_name" : "berkun",
        "indices" : [ 57, 64 ],
        "id_str" : "30495974",
        "id" : 30495974
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "election2012",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/ON7kCYRN",
        "expanded_url" : "http:\/\/bit.ly\/SPSPpd",
        "display_url" : "bit.ly\/SPSPpd"
      } ]
    },
    "geo" : { },
    "id_str" : "265553536249651201",
    "text" : "Plus it's an either-or system, always polarising &gt; RT @berkun: Seven Problems with American Elections http:\/\/t.co\/ON7kCYRN #election2012",
    "id" : 265553536249651201,
    "created_at" : "2012-11-05 20:37:51 +0000",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 265556588713091073,
  "created_at" : "2012-11-05 20:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/SX57lIRY",
      "expanded_url" : "http:\/\/huff.to\/R9qcDI",
      "display_url" : "huff.to\/R9qcDI"
    } ]
  },
  "geo" : { },
  "id_str" : "265542290360115200",
  "text" : "RT @HuffPostWeird: Butterfly gets free plane ride south http:\/\/t.co\/SX57lIRY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/SX57lIRY",
        "expanded_url" : "http:\/\/huff.to\/R9qcDI",
        "display_url" : "huff.to\/R9qcDI"
      } ]
    },
    "geo" : { },
    "id_str" : "265541538115887104",
    "text" : "Butterfly gets free plane ride south http:\/\/t.co\/SX57lIRY",
    "id" : 265541538115887104,
    "created_at" : "2012-11-05 19:50:10 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 265542290360115200,
  "created_at" : "2012-11-05 19:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265541641203482624",
  "geo" : { },
  "id_str" : "265542035702951936",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous click gear \/ Direct messages \/ New message",
  "id" : 265542035702951936,
  "in_reply_to_status_id" : 265541641203482624,
  "created_at" : "2012-11-05 19:52:09 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "momsnightmare",
      "indices" : [ 18, 32 ]
    }, {
      "text" : "mustread",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/TZoeUEt0",
      "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/p\/help-bring-nick-home.html",
      "display_url" : "thesimpleboxcar.com\/p\/help-bring-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265541713400066048",
  "text" : "Do you have kids? #momsnightmare #mustread http:\/\/t.co\/TZoeUEt0",
  "id" : 265541713400066048,
  "created_at" : "2012-11-05 19:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ohmyhead",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265540399534321665",
  "text" : "swirling, twirling energies.. like a rollercoaster.. #2012 #ohmyhead",
  "id" : 265540399534321665,
  "created_at" : "2012-11-05 19:45:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265540206478897152",
  "text" : "some of you ppl are so darn negative i wanna slap you.. but then again.. ive had many of those days..",
  "id" : 265540206478897152,
  "created_at" : "2012-11-05 19:44:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Kitty",
      "screen_name" : "ZeN_KiTtY",
      "indices" : [ 0, 10 ],
      "id_str" : "1362680798",
      "id" : 1362680798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265539791033102336",
  "text" : "@zen_kitty ((hugs))",
  "id" : 265539791033102336,
  "created_at" : "2012-11-05 19:43:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "indices" : [ 3, 18 ],
      "id_str" : "299413847",
      "id" : 299413847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265539396231626753",
  "text" : "RT @InjusticeFacts: There are more than 1 million African Americans in prison in the U.S, more than the number of prisoners in all of Af ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264878680797491200",
    "text" : "There are more than 1 million African Americans in prison in the U.S, more than the number of prisoners in all of Africa.",
    "id" : 264878680797491200,
    "created_at" : "2012-11-03 23:56:13 +0000",
    "user" : {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "protected" : false,
      "id_str" : "299413847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554067441\/injustice_normal.jpg",
      "id" : 299413847,
      "verified" : false
    }
  },
  "id" : 265539396231626753,
  "created_at" : "2012-11-05 19:41:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265520454578614272",
  "geo" : { },
  "id_str" : "265523204217520128",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth omg.. that pesky hunger thing..lol",
  "id" : 265523204217520128,
  "in_reply_to_status_id" : 265520454578614272,
  "created_at" : "2012-11-05 18:37:19 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265478075322605568",
  "geo" : { },
  "id_str" : "265479162112921600",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind but I can bite you!!",
  "id" : 265479162112921600,
  "in_reply_to_status_id" : 265478075322605568,
  "created_at" : "2012-11-05 15:42:19 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alec Ross",
      "screen_name" : "AlecJRoss",
      "indices" : [ 3, 13 ],
      "id_str" : "82282572",
      "id" : 82282572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265479005187227648",
  "text" : "RT @AlecJRoss: 140 years ago today, women's rights leader Susan B. Anthony broke the law by voting. She was arrested &amp; fined $100. C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265450482842103808",
    "text" : "140 years ago today, women's rights leader Susan B. Anthony broke the law by voting. She was arrested &amp; fined $100. Courts upheld conviction",
    "id" : 265450482842103808,
    "created_at" : "2012-11-05 13:48:21 +0000",
    "user" : {
      "name" : "Alec Ross",
      "screen_name" : "AlecJRoss",
      "protected" : false,
      "id_str" : "82282572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684824809335701504\/CUe0wi86_normal.jpg",
      "id" : 82282572,
      "verified" : true
    }
  },
  "id" : 265479005187227648,
  "created_at" : "2012-11-05 15:41:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265478824333041664",
  "text" : "just realized tomorrow is bible study AND election day.. oh dear.. maybe i should stay in bed instead.",
  "id" : 265478824333041664,
  "created_at" : "2012-11-05 15:40:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265469139425050625",
  "text" : "RT @LaughingBaba: No one is in charge of your happiness \rbut you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265468306968936448",
    "text" : "No one is in charge of your happiness \rbut you.",
    "id" : 265468306968936448,
    "created_at" : "2012-11-05 14:59:11 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 265469139425050625,
  "created_at" : "2012-11-05 15:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/iTFbnAuc",
      "expanded_url" : "http:\/\/tinyurl.com\/4y85qdq",
      "display_url" : "tinyurl.com\/4y85qdq"
    } ]
  },
  "geo" : { },
  "id_str" : "265469036018671616",
  "text" : "RT @Seeds4Parents: What the world needs is YOU living and loving fully, speaking your authentic truth. Article http:\/\/t.co\/iTFbnAuc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/iTFbnAuc",
        "expanded_url" : "http:\/\/tinyurl.com\/4y85qdq",
        "display_url" : "tinyurl.com\/4y85qdq"
      } ]
    },
    "geo" : { },
    "id_str" : "265468848201953280",
    "text" : "What the world needs is YOU living and loving fully, speaking your authentic truth. Article http:\/\/t.co\/iTFbnAuc",
    "id" : 265468848201953280,
    "created_at" : "2012-11-05 15:01:20 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 265469036018671616,
  "created_at" : "2012-11-05 15:02:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itsalotofwork",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265465106920521728",
  "text" : "so many ppl saying so many diff things.. its confusing my aura. need to re-focus again and again. #itsalotofwork",
  "id" : 265465106920521728,
  "created_at" : "2012-11-05 14:46:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265457704951242752",
  "geo" : { },
  "id_str" : "265461728282824704",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous uh-oh!",
  "id" : 265461728282824704,
  "in_reply_to_status_id" : 265457704951242752,
  "created_at" : "2012-11-05 14:33:02 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265456968917979136",
  "text" : "RT @mbekezm: Has Bionic Leg, Will Take The Stairs: An amputee climbed 103 floors on a thought-controlled prosthetic.If you li... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/8LsMD3v2",
        "expanded_url" : "http:\/\/bit.ly\/SNGQsa",
        "display_url" : "bit.ly\/SNGQsa"
      } ]
    },
    "geo" : { },
    "id_str" : "265451130643947520",
    "text" : "Has Bionic Leg, Will Take The Stairs: An amputee climbed 103 floors on a thought-controlled prosthetic.If you li... http:\/\/t.co\/8LsMD3v2",
    "id" : 265451130643947520,
    "created_at" : "2012-11-05 13:50:56 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 265456968917979136,
  "created_at" : "2012-11-05 14:14:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265272683678294016",
  "text" : "@SamsaricWarrior looks like giant orb there..cool",
  "id" : 265272683678294016,
  "created_at" : "2012-11-05 02:01:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265261168820625409",
  "text" : "@statue_dog awww.. smooches!",
  "id" : 265261168820625409,
  "created_at" : "2012-11-05 01:16:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 0, 13 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265216265621209089",
  "geo" : { },
  "id_str" : "265216882783694849",
  "in_reply_to_user_id" : 45450889,
  "text" : "@Squirrely007 LOL",
  "id" : 265216882783694849,
  "in_reply_to_status_id" : 265216265621209089,
  "created_at" : "2012-11-04 22:20:07 +0000",
  "in_reply_to_screen_name" : "Squirrely007",
  "in_reply_to_user_id_str" : "45450889",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265208407768825856",
  "geo" : { },
  "id_str" : "265211002000400384",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth lol.. my mom hated that.. \"pick up your feet!\"",
  "id" : 265211002000400384,
  "in_reply_to_status_id" : 265208407768825856,
  "created_at" : "2012-11-04 21:56:44 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265192755322568704",
  "text" : "@SamsaricWarrior you look mahhhvelous!",
  "id" : 265192755322568704,
  "created_at" : "2012-11-04 20:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0415\u043B\u0438\u0437\u0430\u0432\u0435\u0442\u0430 \u0420\u0443\u0434\u0430\u0441",
      "screen_name" : "mataharikrishna",
      "indices" : [ 3, 19 ],
      "id_str" : "155620799",
      "id" : 155620799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 21, 27 ]
    }, {
      "text" : "msnbc",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265184436243554304",
  "text" : "RT @mataharikrishna: #Sandy telethon viewers donated nearly $23M! That is such wonderful news. #msnbc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "msnbc",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265182484688408576",
    "text" : "#Sandy telethon viewers donated nearly $23M! That is such wonderful news. #msnbc",
    "id" : 265182484688408576,
    "created_at" : "2012-11-04 20:03:25 +0000",
    "user" : {
      "name" : "atam",
      "screen_name" : "Hlandeast",
      "protected" : false,
      "id_str" : "177070701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796809926651756544\/hhQPddb3_normal.jpg",
      "id" : 177070701,
      "verified" : false
    }
  },
  "id" : 265184436243554304,
  "created_at" : "2012-11-04 20:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265156953746075648",
  "text" : "birds outside my door keeping me sane. chirping, flitting about...",
  "id" : 265156953746075648,
  "created_at" : "2012-11-04 18:21:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265150786974126080",
  "geo" : { },
  "id_str" : "265156688502484992",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible dont get caught up in it. live in the world.. enjoy it but dont take it so seriously. its just a microcosm of \"ALL\"",
  "id" : 265156688502484992,
  "in_reply_to_status_id" : 265150786974126080,
  "created_at" : "2012-11-04 18:20:55 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatsme",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265156309698093056",
  "text" : "@1stCitizenKane so far left, you've fallen off the edge? lol #thatsme",
  "id" : 265156309698093056,
  "created_at" : "2012-11-04 18:19:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "indices" : [ 3, 13 ],
      "id_str" : "410135192",
      "id" : 410135192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265155769308160000",
  "text" : "RT @laprofe63: Watching \"Koch Brothers Exposed\" 2 better understand how they've hijacked the #USA.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USA",
        "indices" : [ 78, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265153668263837696",
    "text" : "Watching \"Koch Brothers Exposed\" 2 better understand how they've hijacked the #USA.",
    "id" : 265153668263837696,
    "created_at" : "2012-11-04 18:08:55 +0000",
    "user" : {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "protected" : false,
      "id_str" : "410135192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528579278326095872\/RQTxr53H_normal.jpeg",
      "id" : 410135192,
      "verified" : false
    }
  },
  "id" : 265155769308160000,
  "created_at" : "2012-11-04 18:17:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 37, 52 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cookielove",
      "indices" : [ 13, 24 ]
    }, {
      "text" : "chickensofinstagram",
      "indices" : [ 73, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/63GmEefH",
      "expanded_url" : "http:\/\/instagr.am\/p\/RnZGaOBH6S\/",
      "display_url" : "instagr.am\/p\/RnZGaOBH6S\/"
    } ]
  },
  "geo" : { },
  "id_str" : "265147430062936064",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH LOL #cookielove &gt;&gt; RT @ducksandclucks Behold! The cookie! #chickensofinstagram http:\/\/t.co\/63GmEefH",
  "id" : 265147430062936064,
  "created_at" : "2012-11-04 17:44:08 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 0, 15 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265143560582602753",
  "geo" : { },
  "id_str" : "265144102360866816",
  "in_reply_to_user_id" : 272595921,
  "text" : "@ducksandclucks aww.. what a dear girl..lol",
  "id" : 265144102360866816,
  "in_reply_to_status_id" : 265143560582602753,
  "created_at" : "2012-11-04 17:30:54 +0000",
  "in_reply_to_screen_name" : "ducksandclucks",
  "in_reply_to_user_id_str" : "272595921",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 55, 61 ]
    }, {
      "text" : "landscapes",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "farms",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/dUrqxu0m",
      "expanded_url" : "http:\/\/bit.ly\/VnVuuG",
      "display_url" : "bit.ly\/VnVuuG"
    } ]
  },
  "geo" : { },
  "id_str" : "265134084479660032",
  "text" : "RT @MartinBelan: Peacham, Vermont http:\/\/t.co\/dUrqxu0m #photo #landscapes #farms",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 38, 44 ]
      }, {
        "text" : "landscapes",
        "indices" : [ 45, 56 ]
      }, {
        "text" : "farms",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/dUrqxu0m",
        "expanded_url" : "http:\/\/bit.ly\/VnVuuG",
        "display_url" : "bit.ly\/VnVuuG"
      } ]
    },
    "geo" : { },
    "id_str" : "265125757712474113",
    "text" : "Peacham, Vermont http:\/\/t.co\/dUrqxu0m #photo #landscapes #farms",
    "id" : 265125757712474113,
    "created_at" : "2012-11-04 16:18:01 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 265134084479660032,
  "created_at" : "2012-11-04 16:51:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura",
      "screen_name" : "beeebzzz",
      "indices" : [ 3, 12 ],
      "id_str" : "29083939",
      "id" : 29083939
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/beeebzzz\/status\/265120069917474816\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/uQuCp3ql",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A63lTIcCAAATtrG.jpg",
      "id_str" : "265120069930057728",
      "id" : 265120069930057728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A63lTIcCAAATtrG.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/uQuCp3ql"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265132531735752705",
  "text" : "RT @beeebzzz: This never gets old - hand feeding Black-capped Chickadees! http:\/\/t.co\/uQuCp3ql",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/beeebzzz\/status\/265120069917474816\/photo\/1",
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/uQuCp3ql",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A63lTIcCAAATtrG.jpg",
        "id_str" : "265120069930057728",
        "id" : 265120069930057728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A63lTIcCAAATtrG.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/uQuCp3ql"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265120069917474816",
    "text" : "This never gets old - hand feeding Black-capped Chickadees! http:\/\/t.co\/uQuCp3ql",
    "id" : 265120069917474816,
    "created_at" : "2012-11-04 15:55:26 +0000",
    "user" : {
      "name" : "Laura",
      "screen_name" : "beeebzzz",
      "protected" : false,
      "id_str" : "29083939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/123510032\/ME_Lupines_2_normal.jpg",
      "id" : 29083939,
      "verified" : false
    }
  },
  "id" : 265132531735752705,
  "created_at" : "2012-11-04 16:44:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265113488077250560",
  "geo" : { },
  "id_str" : "265115501389312001",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver you know when you see ppl mutate on tv shows.. that's what this all feels like..lol",
  "id" : 265115501389312001,
  "in_reply_to_status_id" : 265113488077250560,
  "created_at" : "2012-11-04 15:37:15 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve",
      "screen_name" : "StevesNotHere",
      "indices" : [ 0, 14 ],
      "id_str" : "386035314",
      "id" : 386035314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265109510111256576",
  "geo" : { },
  "id_str" : "265114603795664896",
  "in_reply_to_user_id" : 386035314,
  "text" : "@StevesNotHere i saw that.. im like \"why???\" i just dont get it.. sigh.",
  "id" : 265114603795664896,
  "in_reply_to_status_id" : 265109510111256576,
  "created_at" : "2012-11-04 15:33:41 +0000",
  "in_reply_to_screen_name" : "StevesNotHere",
  "in_reply_to_user_id_str" : "386035314",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265113002058080256",
  "geo" : { },
  "id_str" : "265114056288006144",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind ohhh, all the better ; )",
  "id" : 265114056288006144,
  "in_reply_to_status_id" : 265113002058080256,
  "created_at" : "2012-11-04 15:31:31 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265113211987165184",
  "text" : "RT @SheilaWalsh: I can hear a poor wee puppy crying in the cargo-hold under the plane. Makes me so sad. I offered to swop places but the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265110725217890305",
    "text" : "I can hear a poor wee puppy crying in the cargo-hold under the plane. Makes me so sad. I offered to swop places but they're not keen",
    "id" : 265110725217890305,
    "created_at" : "2012-11-04 15:18:17 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 265113211987165184,
  "created_at" : "2012-11-04 15:28:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265110987076694017",
  "geo" : { },
  "id_str" : "265112636155367427",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind have to start with catchy headline..lol",
  "id" : 265112636155367427,
  "in_reply_to_status_id" : 265110987076694017,
  "created_at" : "2012-11-04 15:25:52 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265110153639129088",
  "geo" : { },
  "id_str" : "265110786563788800",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind twitlonger and copy\/paste",
  "id" : 265110786563788800,
  "in_reply_to_status_id" : 265110153639129088,
  "created_at" : "2012-11-04 15:18:31 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChooseHope",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265109216673538048",
  "text" : "RT @CoryBooker: Hope no matter how unreasonable is always more preferable than despair no matter how justified. #ChooseHope",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChooseHope",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265108192181223424",
    "text" : "Hope no matter how unreasonable is always more preferable than despair no matter how justified. #ChooseHope",
    "id" : 265108192181223424,
    "created_at" : "2012-11-04 15:08:13 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 265109216673538048,
  "created_at" : "2012-11-04 15:12:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 32, 37 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "SandyNJ",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "NJ",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/rqZHY0UQ",
      "expanded_url" : "http:\/\/www.fema.gov\/sandy",
      "display_url" : "fema.gov\/sandy"
    } ]
  },
  "geo" : { },
  "id_str" : "264894517025591296",
  "text" : "RT @fema: (11\/2) Rumor Control: @fema is *NOT* hiring clean up crews in South Jersey. http:\/\/t.co\/rqZHY0UQ #Sandy #SandyNJ #NJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 22, 27 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 97, 103 ]
      }, {
        "text" : "SandyNJ",
        "indices" : [ 104, 112 ]
      }, {
        "text" : "NJ",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/rqZHY0UQ",
        "expanded_url" : "http:\/\/www.fema.gov\/sandy",
        "display_url" : "fema.gov\/sandy"
      } ]
    },
    "geo" : { },
    "id_str" : "264560890546909184",
    "text" : "(11\/2) Rumor Control: @fema is *NOT* hiring clean up crews in South Jersey. http:\/\/t.co\/rqZHY0UQ #Sandy #SandyNJ #NJ",
    "id" : 264560890546909184,
    "created_at" : "2012-11-03 02:53:26 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 264894517025591296,
  "created_at" : "2012-11-04 00:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264863565939367937",
  "geo" : { },
  "id_str" : "264864724741681152",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep aww.. santa's little helper..teehee",
  "id" : 264864724741681152,
  "in_reply_to_status_id" : 264863565939367937,
  "created_at" : "2012-11-03 23:00:45 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Bommerez",
      "screen_name" : "thetaoofflow",
      "indices" : [ 3, 16 ],
      "id_str" : "338015597",
      "id" : 338015597
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOW",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "fb",
      "indices" : [ 116, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264863028892295168",
  "text" : "RT @thetaoofflow: It is not the place, nor the condition, but the mind that will put you in heaven or in hell #FLOW #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mbono.net\" rel=\"nofollow\"\u003EMbono.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FLOW",
        "indices" : [ 92, 97 ]
      }, {
        "text" : "fb",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264861270543589376",
    "text" : "It is not the place, nor the condition, but the mind that will put you in heaven or in hell #FLOW #fb",
    "id" : 264861270543589376,
    "created_at" : "2012-11-03 22:47:02 +0000",
    "user" : {
      "name" : "Jan Bommerez",
      "screen_name" : "thetaoofflow",
      "protected" : false,
      "id_str" : "338015597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472019761866366977\/QkWAFMjJ_normal.jpeg",
      "id" : 338015597,
      "verified" : false
    }
  },
  "id" : 264863028892295168,
  "created_at" : "2012-11-03 22:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264820261327609856",
  "geo" : { },
  "id_str" : "264821114881052672",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms oh no.. feel better hun! ((hugs))",
  "id" : 264821114881052672,
  "in_reply_to_status_id" : 264820261327609856,
  "created_at" : "2012-11-03 20:07:28 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 0, 15 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264814871638593536",
  "geo" : { },
  "id_str" : "264815071690121216",
  "in_reply_to_user_id" : 272595921,
  "text" : "@ducksandclucks such a pretty girl!",
  "id" : 264815071690121216,
  "in_reply_to_status_id" : 264814871638593536,
  "created_at" : "2012-11-03 19:43:27 +0000",
  "in_reply_to_screen_name" : "ducksandclucks",
  "in_reply_to_user_id_str" : "272595921",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264813499870498816",
  "geo" : { },
  "id_str" : "264814624585682944",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields niiice pic!",
  "id" : 264814624585682944,
  "in_reply_to_status_id" : 264813499870498816,
  "created_at" : "2012-11-03 19:41:41 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264814021880971265",
  "text" : "at least the birds are happy. hubby put up a bird feeder off porch. plus there's cat kibble and a suet mix.",
  "id" : 264814021880971265,
  "created_at" : "2012-11-03 19:39:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264797720169046016",
  "text" : "if i hadnt married, i'd be in an institution. i am emotionally unable to care for myself. i may be 46 but my mind is like 12.",
  "id" : 264797720169046016,
  "created_at" : "2012-11-03 18:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Maxwell",
      "screen_name" : "aDancingDonkey",
      "indices" : [ 3, 18 ],
      "id_str" : "423145788",
      "id" : 423145788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/4QQ0Xw4d",
      "expanded_url" : "http:\/\/nblo.gs\/EgtO2",
      "display_url" : "nblo.gs\/EgtO2"
    } ]
  },
  "geo" : { },
  "id_str" : "264796223716855808",
  "text" : "RT @aDancingDonkey: A very VERY Sick Donkey http:\/\/t.co\/4QQ0Xw4d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/4QQ0Xw4d",
        "expanded_url" : "http:\/\/nblo.gs\/EgtO2",
        "display_url" : "nblo.gs\/EgtO2"
      } ]
    },
    "geo" : { },
    "id_str" : "264598182636441600",
    "text" : "A very VERY Sick Donkey http:\/\/t.co\/4QQ0Xw4d",
    "id" : 264598182636441600,
    "created_at" : "2012-11-03 05:21:37 +0000",
    "user" : {
      "name" : "Kris Maxwell",
      "screen_name" : "aDancingDonkey",
      "protected" : false,
      "id_str" : "423145788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661369445512646657\/MoCZ2m-Z_normal.jpg",
      "id" : 423145788,
      "verified" : false
    }
  },
  "id" : 264796223716855808,
  "created_at" : "2012-11-03 18:28:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264783386516803584",
  "text" : "my negative chi is overflowing today : (",
  "id" : 264783386516803584,
  "created_at" : "2012-11-03 17:37:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264781109152342017",
  "geo" : { },
  "id_str" : "264782090325880833",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous wth are \"cooking\" chopsticks??",
  "id" : 264782090325880833,
  "in_reply_to_status_id" : 264781109152342017,
  "created_at" : "2012-11-03 17:32:24 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264775104091787264",
  "geo" : { },
  "id_str" : "264779212668432385",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu i like him cuz he seems like he really cared about ppl.. wanted to do good...",
  "id" : 264779212668432385,
  "in_reply_to_status_id" : 264775104091787264,
  "created_at" : "2012-11-03 17:20:58 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264774361741918208",
  "text" : "i didnt know abraham lincoln was repub until recently. he's always been one of my fave ppl.",
  "id" : 264774361741918208,
  "created_at" : "2012-11-03 17:01:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264773441612296194",
  "text" : "all he does is freakin work 7 freakin days a freakin week... ARRGGHH",
  "id" : 264773441612296194,
  "created_at" : "2012-11-03 16:58:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264772655901720577",
  "geo" : { },
  "id_str" : "264773007870930945",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin ohhh.. one of hubby's pet peeves..lol",
  "id" : 264773007870930945,
  "in_reply_to_status_id" : 264772655901720577,
  "created_at" : "2012-11-03 16:56:18 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molly Wood",
      "screen_name" : "mollywood",
      "indices" : [ 3, 13 ],
      "id_str" : "6476742",
      "id" : 6476742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/cOjACTLQ",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/mobileweb\/2012\/11\/02\/george-lucas-donate-4-billion_n_2067145.html?utm_hp_ref=tw",
      "display_url" : "huffingtonpost.com\/mobileweb\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264757404699340802",
  "text" : "RT @mollywood: Wow. I am suddenly ok with Disney buying LucasFilm. Lucas will donate all $4B to education.  http:\/\/t.co\/cOjACTLQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/cOjACTLQ",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/mobileweb\/2012\/11\/02\/george-lucas-donate-4-billion_n_2067145.html?utm_hp_ref=tw",
        "display_url" : "huffingtonpost.com\/mobileweb\/2012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264555626540171264",
    "text" : "Wow. I am suddenly ok with Disney buying LucasFilm. Lucas will donate all $4B to education.  http:\/\/t.co\/cOjACTLQ",
    "id" : 264555626540171264,
    "created_at" : "2012-11-03 02:32:31 +0000",
    "user" : {
      "name" : "Molly Wood",
      "screen_name" : "mollywood",
      "protected" : false,
      "id_str" : "6476742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425798691257974785\/HBqsDhbx_normal.jpeg",
      "id" : 6476742,
      "verified" : true
    }
  },
  "id" : 264757404699340802,
  "created_at" : "2012-11-03 15:54:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264730082810146816",
  "geo" : { },
  "id_str" : "264750366795649024",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska ((hugs)) you're a loving person and that is sooo important!",
  "id" : 264750366795649024,
  "in_reply_to_status_id" : 264730082810146816,
  "created_at" : "2012-11-03 15:26:20 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264728062611038208",
  "geo" : { },
  "id_str" : "264749184278728705",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin hmmm..",
  "id" : 264749184278728705,
  "in_reply_to_status_id" : 264728062611038208,
  "created_at" : "2012-11-03 15:21:38 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greytdog",
      "screen_name" : "Greytdog",
      "indices" : [ 3, 12 ],
      "id_str" : "17141349",
      "id" : 17141349
    }, {
      "name" : "Steve Weinstein",
      "screen_name" : "steveweinstein",
      "indices" : [ 17, 32 ],
      "id_str" : "47728859",
      "id" : 47728859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/MVwJ9pVs",
      "expanded_url" : "http:\/\/tinyurl.com\/ahqfyv9",
      "display_url" : "tinyurl.com\/ahqfyv9"
    } ]
  },
  "geo" : { },
  "id_str" : "264538407995338753",
  "text" : "RT @Greytdog: RT @steveweinstein: I want to donate to FEMA instead of the Red Cross. Can I do that?\/here http:\/\/t.co\/MVwJ9pVs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Weinstein",
        "screen_name" : "steveweinstein",
        "indices" : [ 3, 18 ],
        "id_str" : "47728859",
        "id" : 47728859
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/MVwJ9pVs",
        "expanded_url" : "http:\/\/tinyurl.com\/ahqfyv9",
        "display_url" : "tinyurl.com\/ahqfyv9"
      } ]
    },
    "geo" : { },
    "id_str" : "264533769938141184",
    "text" : "RT @steveweinstein: I want to donate to FEMA instead of the Red Cross. Can I do that?\/here http:\/\/t.co\/MVwJ9pVs",
    "id" : 264533769938141184,
    "created_at" : "2012-11-03 01:05:40 +0000",
    "user" : {
      "name" : "Greytdog",
      "screen_name" : "Greytdog",
      "protected" : false,
      "id_str" : "17141349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800712966274478082\/4hurAvEV_normal.jpg",
      "id" : 17141349,
      "verified" : false
    }
  },
  "id" : 264538407995338753,
  "created_at" : "2012-11-03 01:24:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Mitzvah Circle",
      "screen_name" : "MitzvahCircle",
      "indices" : [ 22, 36 ],
      "id_str" : "126492276",
      "id" : 126492276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandyNJ",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "website",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "Help",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264538328370671616",
  "text" : "RT @CharlesBivona: RT @MitzvahCircle: Please tell #SandyNJ people: go to our #website &amp; click on Get #Help and give us an address: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitzvah Circle",
        "screen_name" : "MitzvahCircle",
        "indices" : [ 3, 17 ],
        "id_str" : "126492276",
        "id" : 126492276
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SandyNJ",
        "indices" : [ 31, 39 ]
      }, {
        "text" : "website",
        "indices" : [ 58, 66 ]
      }, {
        "text" : "Help",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/OmtlmDc5",
        "expanded_url" : "http:\/\/mitzvahcircle.org",
        "display_url" : "mitzvahcircle.org"
      } ]
    },
    "geo" : { },
    "id_str" : "264537429246099456",
    "text" : "RT @MitzvahCircle: Please tell #SandyNJ people: go to our #website &amp; click on Get #Help and give us an address: http:\/\/t.co\/OmtlmDc5 MT!",
    "id" : 264537429246099456,
    "created_at" : "2012-11-03 01:20:12 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 264538328370671616,
  "created_at" : "2012-11-03 01:23:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/XviTsSS0",
      "expanded_url" : "http:\/\/huff.to\/Y6ZvDm",
      "display_url" : "huff.to\/Y6ZvDm"
    } ]
  },
  "geo" : { },
  "id_str" : "264519555664183296",
  "text" : "RT @RevDebra: Heartbeat: My Involuntary Miscarriage and 'Voluntary Abortion' in Ohio http:\/\/t.co\/XviTsSS0  This story made me weep and a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/XviTsSS0",
        "expanded_url" : "http:\/\/huff.to\/Y6ZvDm",
        "display_url" : "huff.to\/Y6ZvDm"
      } ]
    },
    "geo" : { },
    "id_str" : "264517124083564545",
    "text" : "Heartbeat: My Involuntary Miscarriage and 'Voluntary Abortion' in Ohio http:\/\/t.co\/XviTsSS0  This story made me weep and angry.",
    "id" : 264517124083564545,
    "created_at" : "2012-11-02 23:59:31 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 264519555664183296,
  "created_at" : "2012-11-03 00:09:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donnie Wahlberg",
      "screen_name" : "DonnieWahlberg",
      "indices" : [ 3, 18 ],
      "id_str" : "24776235",
      "id" : 24776235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264516378114023426",
  "text" : "RT @DonnieWahlberg: Spread LOVE and LOVE will spread!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264515239712800769",
    "text" : "Spread LOVE and LOVE will spread!",
    "id" : 264515239712800769,
    "created_at" : "2012-11-02 23:52:02 +0000",
    "user" : {
      "name" : "Donnie Wahlberg",
      "screen_name" : "DonnieWahlberg",
      "protected" : false,
      "id_str" : "24776235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801100264954593281\/MPPVF7aC_normal.jpg",
      "id" : 24776235,
      "verified" : true
    }
  },
  "id" : 264516378114023426,
  "created_at" : "2012-11-02 23:56:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264482481581998080",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 happy birthday dear kitty! smooches!",
  "id" : 264482481581998080,
  "created_at" : "2012-11-02 21:41:52 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 87, 98 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/9yu35Yec",
      "expanded_url" : "http:\/\/dlvr.it\/2QWDD3",
      "display_url" : "dlvr.it\/2QWDD3"
    } ]
  },
  "geo" : { },
  "id_str" : "264470154119888898",
  "text" : "RT @angelaharms: You guys, no way. Baby echidna video. SQUEE. http:\/\/t.co\/9yu35Yec via @BoingBoing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boing Boing",
        "screen_name" : "BoingBoing",
        "indices" : [ 70, 81 ],
        "id_str" : "5971922",
        "id" : 5971922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/9yu35Yec",
        "expanded_url" : "http:\/\/dlvr.it\/2QWDD3",
        "display_url" : "dlvr.it\/2QWDD3"
      } ]
    },
    "geo" : { },
    "id_str" : "264462080990646272",
    "text" : "You guys, no way. Baby echidna video. SQUEE. http:\/\/t.co\/9yu35Yec via @BoingBoing",
    "id" : 264462080990646272,
    "created_at" : "2012-11-02 20:20:48 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 264470154119888898,
  "created_at" : "2012-11-02 20:52:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/VLoBraVI",
      "expanded_url" : "http:\/\/www.flixxy.com\/humpback-whale-gives-show-after-being-saved.htm",
      "display_url" : "flixxy.com\/humpback-whale\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264468639518957568",
  "text" : "RT @Squirrely007: Click here: Humpback Whale Gives Show After Being Saved http:\/\/t.co\/VLoBraVI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/VLoBraVI",
        "expanded_url" : "http:\/\/www.flixxy.com\/humpback-whale-gives-show-after-being-saved.htm",
        "display_url" : "flixxy.com\/humpback-whale\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264456230209191936",
    "text" : "Click here: Humpback Whale Gives Show After Being Saved http:\/\/t.co\/VLoBraVI",
    "id" : 264456230209191936,
    "created_at" : "2012-11-02 19:57:33 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 264468639518957568,
  "created_at" : "2012-11-02 20:46:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/5AFayOBm",
      "expanded_url" : "http:\/\/www.sanders.senate.gov\/",
      "display_url" : "sanders.senate.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "264452333033910272",
  "text" : "RT @SenSanders: Election Day should be a national holiday so that everyone has the opportunity to vote. http:\/\/t.co\/5AFayOBm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/5AFayOBm",
        "expanded_url" : "http:\/\/www.sanders.senate.gov\/",
        "display_url" : "sanders.senate.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "264448834288119808",
    "text" : "Election Day should be a national holiday so that everyone has the opportunity to vote. http:\/\/t.co\/5AFayOBm",
    "id" : 264448834288119808,
    "created_at" : "2012-11-02 19:28:09 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 264452333033910272,
  "created_at" : "2012-11-02 19:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264450546189103104",
  "text" : "RT @neiltyson: Just an FYI: The number of unlikely things that can happen is so large, you can be assured that unlikely things are likely.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264447534628495360",
    "text" : "Just an FYI: The number of unlikely things that can happen is so large, you can be assured that unlikely things are likely.",
    "id" : 264447534628495360,
    "created_at" : "2012-11-02 19:23:00 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 264450546189103104,
  "created_at" : "2012-11-02 19:34:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "indices" : [ 3, 15 ],
      "id_str" : "406759668",
      "id" : 406759668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264446535364911104",
  "text" : "RT @yoursMukund: Who are you? You are an expression of God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264445278227152896",
    "text" : "Who are you? You are an expression of God.",
    "id" : 264445278227152896,
    "created_at" : "2012-11-02 19:14:02 +0000",
    "user" : {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "protected" : false,
      "id_str" : "406759668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000454898275\/fc674ec400b510e4ab53f191238a2664_normal.jpeg",
      "id" : 406759668,
      "verified" : false
    }
  },
  "id" : 264446535364911104,
  "created_at" : "2012-11-02 19:19:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eagles 5-4",
      "screen_name" : "KPSWORLD",
      "indices" : [ 3, 12 ],
      "id_str" : "77811841",
      "id" : 77811841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264442469406613504",
  "text" : "RT @KPSWORLD: ATTENTION: If you need work, Fema needs clean up crews for South Jersey. It's $1000 for 7 days, hotel and food included. C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264434560496975872",
    "text" : "ATTENTION: If you need work, Fema needs clean up crews for South Jersey. It's $1000 for 7 days, hotel and food included. Call 904-797-5998.",
    "id" : 264434560496975872,
    "created_at" : "2012-11-02 18:31:26 +0000",
    "user" : {
      "name" : "Eagles 5-4",
      "screen_name" : "KPSWORLD",
      "protected" : false,
      "id_str" : "77811841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800681165757841408\/lvyMGzyw_normal.jpg",
      "id" : 77811841,
      "verified" : false
    }
  },
  "id" : 264442469406613504,
  "created_at" : "2012-11-02 19:02:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole Di Tosti",
      "screen_name" : "mercedeskat45",
      "indices" : [ 3, 17 ],
      "id_str" : "30304785",
      "id" : 30304785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/Oda95rD1",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/11\/02\/nyc-marathon-runner-penny-krakoff-will-boycott-own-race-volunteer-instead-urges-others-to-join-her_n_2064625.html?1351872171",
      "display_url" : "huffingtonpost.com\/2012\/11\/02\/nyc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264437746490302464",
  "text" : "RT @mercedeskat45: NYC Marathon Runner Penny Krakoff To Boycott The Race To Volunteer, Urges Others To Join Her http:\/\/t.co\/Oda95rD1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Oda95rD1",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/11\/02\/nyc-marathon-runner-penny-krakoff-will-boycott-own-race-volunteer-instead-urges-others-to-join-her_n_2064625.html?1351872171",
        "display_url" : "huffingtonpost.com\/2012\/11\/02\/nyc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264437005100920833",
    "text" : "NYC Marathon Runner Penny Krakoff To Boycott The Race To Volunteer, Urges Others To Join Her http:\/\/t.co\/Oda95rD1",
    "id" : 264437005100920833,
    "created_at" : "2012-11-02 18:41:09 +0000",
    "user" : {
      "name" : "Carole Di Tosti",
      "screen_name" : "mercedeskat45",
      "protected" : false,
      "id_str" : "30304785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431310391394582529\/LPHJwiW8_normal.jpeg",
      "id" : 30304785,
      "verified" : false
    }
  },
  "id" : 264437746490302464,
  "created_at" : "2012-11-02 18:44:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brianne Manz",
      "screen_name" : "strollerincity",
      "indices" : [ 3, 18 ],
      "id_str" : "262271317",
      "id" : 262271317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264421602903601152",
  "text" : "RT @strollerincity: Please RT! Staten Island In need of BABY SUPPLIES: Clothing, Diapers &amp; Formula Monsignor Farrell 2900 Amboy rd S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264416478588178432",
    "text" : "Please RT! Staten Island In need of BABY SUPPLIES: Clothing, Diapers &amp; Formula Monsignor Farrell 2900 Amboy rd SI, NY 10306",
    "id" : 264416478588178432,
    "created_at" : "2012-11-02 17:19:35 +0000",
    "user" : {
      "name" : "Brianne Manz",
      "screen_name" : "strollerincity",
      "protected" : false,
      "id_str" : "262271317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728713733455925248\/Fo9fpfTz_normal.jpg",
      "id" : 262271317,
      "verified" : true
    }
  },
  "id" : 264421602903601152,
  "created_at" : "2012-11-02 17:39:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soulseeds",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264418221967417344",
  "text" : "RT @Seeds4Parents: You never know the full extent of the love and hope you add to every life you touch. #soulseeds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "soulseeds",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264413557444206592",
    "text" : "You never know the full extent of the love and hope you add to every life you touch. #soulseeds",
    "id" : 264413557444206592,
    "created_at" : "2012-11-02 17:07:59 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 264418221967417344,
  "created_at" : "2012-11-02 17:26:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 96, 109 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/4GDn2Vhc",
      "expanded_url" : "http:\/\/wp.me\/s2k1XC-answers",
      "display_url" : "wp.me\/s2k1XC-answers"
    } ]
  },
  "geo" : { },
  "id_str" : "264410028834951169",
  "text" : "THIS!&gt;&gt; \"It\u2019s about trusting something that transcends knowledge\" http:\/\/t.co\/4GDn2Vhc by @micahjmurray",
  "id" : 264410028834951169,
  "created_at" : "2012-11-02 16:53:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264402442819629057",
  "text" : "we cut fur out where she was itching.. dog has hot spot. she doesnt like the spray, though. we have to be sneaky!",
  "id" : 264402442819629057,
  "created_at" : "2012-11-02 16:23:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 0, 12 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264375069717979136",
  "geo" : { },
  "id_str" : "264378026874241025",
  "in_reply_to_user_id" : 17592150,
  "text" : "@tommysalami ohh just read description.. looks good. added to my wish list!",
  "id" : 264378026874241025,
  "in_reply_to_status_id" : 264375069717979136,
  "created_at" : "2012-11-02 14:46:48 +0000",
  "in_reply_to_screen_name" : "thomaspluck",
  "in_reply_to_user_id_str" : "17592150",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Tatchell",
      "screen_name" : "PeterTatchell",
      "indices" : [ 3, 17 ],
      "id_str" : "31135856",
      "id" : 31135856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "pride",
      "indices" : [ 122, 128 ]
    }, {
      "text" : "gay",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/As9zw4GR",
      "expanded_url" : "http:\/\/bit.ly\/RyJDDG",
      "display_url" : "bit.ly\/RyJDDG"
    } ]
  },
  "geo" : { },
  "id_str" : "264373327433453568",
  "text" : "RT @PeterTatchell: Why I'm no longer Gay but still want to marry a man, by Chris Morris. READ: http:\/\/t.co\/As9zw4GR #lgbt #pride #gay #g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lgbt",
        "indices" : [ 97, 102 ]
      }, {
        "text" : "pride",
        "indices" : [ 103, 109 ]
      }, {
        "text" : "gay",
        "indices" : [ 110, 114 ]
      }, {
        "text" : "glbt",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "queer",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "lesbian",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/As9zw4GR",
        "expanded_url" : "http:\/\/bit.ly\/RyJDDG",
        "display_url" : "bit.ly\/RyJDDG"
      } ]
    },
    "geo" : { },
    "id_str" : "264358867234869249",
    "text" : "Why I'm no longer Gay but still want to marry a man, by Chris Morris. READ: http:\/\/t.co\/As9zw4GR #lgbt #pride #gay #glbt #queer #lesbian",
    "id" : 264358867234869249,
    "created_at" : "2012-11-02 13:30:40 +0000",
    "user" : {
      "name" : "Peter Tatchell",
      "screen_name" : "PeterTatchell",
      "protected" : false,
      "id_str" : "31135856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2930765203\/f33396076c1ebcdb9be3bf1aa2c80505_normal.jpeg",
      "id" : 31135856,
      "verified" : false
    }
  },
  "id" : 264373327433453568,
  "created_at" : "2012-11-02 14:28:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264178209233457152",
  "geo" : { },
  "id_str" : "264178848277622784",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos wonderful! ((hugs)) keep moving forward! : )",
  "id" : 264178848277622784,
  "in_reply_to_status_id" : 264178209233457152,
  "created_at" : "2012-11-02 01:35:20 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "105926473",
      "id" : 105926473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264152831051849729",
  "text" : "RT @consciousbridge: Acts of Kindness: I always like to notice acts of kindness. The more I notice them, the more there tends to be s... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/xTs7uq3n",
        "expanded_url" : "http:\/\/bit.ly\/Vg8kek",
        "display_url" : "bit.ly\/Vg8kek"
      } ]
    },
    "geo" : { },
    "id_str" : "264145205136072704",
    "text" : "Acts of Kindness: I always like to notice acts of kindness. The more I notice them, the more there tends to be s... http:\/\/t.co\/xTs7uq3n",
    "id" : 264145205136072704,
    "created_at" : "2012-11-01 23:21:39 +0000",
    "user" : {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "protected" : false,
      "id_str" : "105926473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200394907\/172_normal.JPG",
      "id" : 105926473,
      "verified" : false
    }
  },
  "id" : 264152831051849729,
  "created_at" : "2012-11-01 23:51:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264147005738188800",
  "geo" : { },
  "id_str" : "264152429950545920",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl ((hugs)) you're awesome : )",
  "id" : 264152429950545920,
  "in_reply_to_status_id" : 264147005738188800,
  "created_at" : "2012-11-01 23:50:21 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 3, 13 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264152055508254720",
  "text" : "RT @RuffHaven: Lose your home to #Sandy?  We have room to temporarily house 2 dogs. \nPlease Retweet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264149526842064897",
    "text" : "Lose your home to #Sandy?  We have room to temporarily house 2 dogs. \nPlease Retweet",
    "id" : 264149526842064897,
    "created_at" : "2012-11-01 23:38:49 +0000",
    "user" : {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "protected" : false,
      "id_str" : "126764612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459086546319056896\/W1rXvAEz_normal.jpeg",
      "id" : 126764612,
      "verified" : false
    }
  },
  "id" : 264152055508254720,
  "created_at" : "2012-11-01 23:48:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juliet Harrison",
      "screen_name" : "lecheval",
      "indices" : [ 0, 9 ],
      "id_str" : "17257283",
      "id" : 17257283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264150773892521985",
  "geo" : { },
  "id_str" : "264151764390006784",
  "in_reply_to_user_id" : 17257283,
  "text" : "@lecheval he is beautiful.. i am so sorry for your loss..",
  "id" : 264151764390006784,
  "in_reply_to_status_id" : 264150773892521985,
  "created_at" : "2012-11-01 23:47:42 +0000",
  "in_reply_to_screen_name" : "lecheval",
  "in_reply_to_user_id_str" : "17257283",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 98, 105 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/1QE9uHd1",
      "expanded_url" : "http:\/\/pulse.me\/s\/eXgkH",
      "display_url" : "pulse.me\/s\/eXgkH"
    } ]
  },
  "geo" : { },
  "id_str" : "264133834105294849",
  "text" : "RT @Silvercrone: Humans Can't Be Empathetic And Logical At The Same Time http:\/\/t.co\/1QE9uHd1 via @PopSci",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Popular Science",
        "screen_name" : "PopSci",
        "indices" : [ 81, 88 ],
        "id_str" : "19722699",
        "id" : 19722699
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/1QE9uHd1",
        "expanded_url" : "http:\/\/pulse.me\/s\/eXgkH",
        "display_url" : "pulse.me\/s\/eXgkH"
      } ]
    },
    "geo" : { },
    "id_str" : "264133556983447554",
    "text" : "Humans Can't Be Empathetic And Logical At The Same Time http:\/\/t.co\/1QE9uHd1 via @PopSci",
    "id" : 264133556983447554,
    "created_at" : "2012-11-01 22:35:22 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 264133834105294849,
  "created_at" : "2012-11-01 22:36:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrietta",
      "screen_name" : "nonnydee",
      "indices" : [ 3, 12 ],
      "id_str" : "27109121",
      "id" : 27109121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/bOBzBjbh",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/11\/01\/cory-booker-neighbors-hurricane-sandy_n_2059971.html",
      "display_url" : "huffingtonpost.com\/2012\/11\/01\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264131983888764928",
  "text" : "RT @nonnydee: Cory Booker, Newark, New Jersey Mayor, Invites Hurricane Sandy Victims To His House http:\/\/t.co\/bOBzBjbh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/bOBzBjbh",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/11\/01\/cory-booker-neighbors-hurricane-sandy_n_2059971.html",
        "display_url" : "huffingtonpost.com\/2012\/11\/01\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264123990375800832",
    "text" : "Cory Booker, Newark, New Jersey Mayor, Invites Hurricane Sandy Victims To His House http:\/\/t.co\/bOBzBjbh",
    "id" : 264123990375800832,
    "created_at" : "2012-11-01 21:57:21 +0000",
    "user" : {
      "name" : "Henrietta",
      "screen_name" : "nonnydee",
      "protected" : false,
      "id_str" : "27109121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731485998991872000\/WBQcgDJo_normal.jpg",
      "id" : 27109121,
      "verified" : false
    }
  },
  "id" : 264131983888764928,
  "created_at" : "2012-11-01 22:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 67, 79 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264119541368508416",
  "text" : "just finished ARC of Line of Fire by Stephen White that I won from @duttonbooks .. Excellent.. loved it!",
  "id" : 264119541368508416,
  "created_at" : "2012-11-01 21:39:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYC ARECS",
      "screen_name" : "nycarecs",
      "indices" : [ 3, 12 ],
      "id_str" : "35220556",
      "id" : 35220556
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nycarecs\/status\/264102129176825856\/photo\/1",
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/I6aX0OHc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6pHfLpCUAATZxt.jpg",
      "id_str" : "264102129181020160",
      "id" : 264102129181020160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6pHfLpCUAATZxt.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/I6aX0OHc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264103232979210240",
  "text" : "RT @nycarecs: http:\/\/t.co\/I6aX0OHc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nycarecs\/status\/264102129176825856\/photo\/1",
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/I6aX0OHc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6pHfLpCUAATZxt.jpg",
        "id_str" : "264102129181020160",
        "id" : 264102129181020160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6pHfLpCUAATZxt.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/I6aX0OHc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264102129176825856",
    "text" : "http:\/\/t.co\/I6aX0OHc",
    "id" : 264102129176825856,
    "created_at" : "2012-11-01 20:30:30 +0000",
    "user" : {
      "name" : "NYC ARECS",
      "screen_name" : "nycarecs",
      "protected" : false,
      "id_str" : "35220556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1848834939\/nyc-arecs_logo_normal.gif",
      "id" : 35220556,
      "verified" : false
    }
  },
  "id" : 264103232979210240,
  "created_at" : "2012-11-01 20:34:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 15, 24 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264099518184816641",
  "text" : "@akicktotheeye @Pandeism no i didnt...",
  "id" : 264099518184816641,
  "created_at" : "2012-11-01 20:20:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264091085855416321",
  "geo" : { },
  "id_str" : "264099032744484865",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings your birthday? will there be cupcakes? hope it's a wonderful day for you! : )",
  "id" : 264099032744484865,
  "in_reply_to_status_id" : 264091085855416321,
  "created_at" : "2012-11-01 20:18:10 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264097456453730304",
  "text" : "@1stCitizenKane me, too.. (insanity)",
  "id" : 264097456453730304,
  "created_at" : "2012-11-01 20:11:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "indices" : [ 3, 15 ],
      "id_str" : "216299334",
      "id" : 216299334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264096557773758465",
  "text" : "RT @piersmorgan: Very impressed by Obama\/Christie. True bi-partisan leadership. But Romney must be tearing his hair out - can't help his ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263746629457289216",
    "text" : "Very impressed by Obama\/Christie. True bi-partisan leadership. But Romney must be tearing his hair out - can't help his election chances.",
    "id" : 263746629457289216,
    "created_at" : "2012-10-31 20:57:51 +0000",
    "user" : {
      "name" : "Piers Morgan",
      "screen_name" : "piersmorgan",
      "protected" : false,
      "id_str" : "216299334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778941595164999680\/923GrEp1_normal.jpg",
      "id" : 216299334,
      "verified" : true
    }
  },
  "id" : 264096557773758465,
  "created_at" : "2012-11-01 20:08:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264096170064883712",
  "text" : "RT @ChristianDems: Jesus called us to love our neighbor, stand against injustice and show compassion to ALL!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264095831068639232",
    "text" : "Jesus called us to love our neighbor, stand against injustice and show compassion to ALL!",
    "id" : 264095831068639232,
    "created_at" : "2012-11-01 20:05:27 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 264096170064883712,
  "created_at" : "2012-11-01 20:06:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "indices" : [ 2, 11 ],
      "id_str" : "8234572",
      "id" : 8234572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264085478142263296",
  "geo" : { },
  "id_str" : "264086512348561408",
  "in_reply_to_user_id" : 8234572,
  "text" : ". @cantrell i enjoyed \"Containment\" .. kept my attention. thought it was interesting!",
  "id" : 264086512348561408,
  "in_reply_to_status_id" : 264085478142263296,
  "created_at" : "2012-11-01 19:28:25 +0000",
  "in_reply_to_screen_name" : "cantrell",
  "in_reply_to_user_id_str" : "8234572",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 0, 9 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264082500530339840",
  "geo" : { },
  "id_str" : "264083276241715200",
  "in_reply_to_user_id" : 215045056,
  "text" : "@Pandeism @akicktotheeye MSNBC's \"election\" page &lt;&lt; what I googled (\"test data\" comment in description before i clicked link)",
  "id" : 264083276241715200,
  "in_reply_to_status_id" : 264082500530339840,
  "created_at" : "2012-11-01 19:15:34 +0000",
  "in_reply_to_screen_name" : "Pandeism",
  "in_reply_to_user_id_str" : "215045056",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264082122086707200",
  "text" : "RT @WTBuster: I've been asking since Monday, WHY IS Staten Island getting shafted in media attention, and aide? People are wet, hungry,  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264081214141505537",
    "text" : "I've been asking since Monday, WHY IS Staten Island getting shafted in media attention, and aide? People are wet, hungry, homeless, dying.",
    "id" : 264081214141505537,
    "created_at" : "2012-11-01 19:07:22 +0000",
    "user" : {
      "name" : "We R Gonna Fix This",
      "screen_name" : "wtb6chiny",
      "protected" : false,
      "id_str" : "204947822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787487931212718080\/lpOT5NLK_normal.jpg",
      "id" : 204947822,
      "verified" : false
    }
  },
  "id" : 264082122086707200,
  "created_at" : "2012-11-01 19:10:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 0, 9 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264080335720022016",
  "geo" : { },
  "id_str" : "264081694305447936",
  "in_reply_to_user_id" : 215045056,
  "text" : "@Pandeism @akicktotheeye googling it in chrome shows \"This page contains TEST DATA ONLY and does not reflect actual results\"",
  "id" : 264081694305447936,
  "in_reply_to_status_id" : 264080335720022016,
  "created_at" : "2012-11-01 19:09:16 +0000",
  "in_reply_to_screen_name" : "Pandeism",
  "in_reply_to_user_id_str" : "215045056",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Soulseeds",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/f6XcRoPz",
      "expanded_url" : "http:\/\/tinyurl.com\/bm7c73r",
      "display_url" : "tinyurl.com\/bm7c73r"
    } ]
  },
  "geo" : { },
  "id_str" : "264046493957255168",
  "text" : "RT @Soulseedzforall: Care for the prickly ones, #Soulseeds http:\/\/t.co\/f6XcRoPz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Soulseeds",
        "indices" : [ 27, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/f6XcRoPz",
        "expanded_url" : "http:\/\/tinyurl.com\/bm7c73r",
        "display_url" : "tinyurl.com\/bm7c73r"
      } ]
    },
    "geo" : { },
    "id_str" : "264041222857957376",
    "text" : "Care for the prickly ones, #Soulseeds http:\/\/t.co\/f6XcRoPz",
    "id" : 264041222857957376,
    "created_at" : "2012-11-01 16:28:27 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 264046493957255168,
  "created_at" : "2012-11-01 16:49:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264044093041156097",
  "text" : "RT @Buddhaworld: Nobody can save you. Grasp this and the problem is solved. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264041477628375040",
    "text" : "Nobody can save you. Grasp this and the problem is solved. Volko",
    "id" : 264041477628375040,
    "created_at" : "2012-11-01 16:29:28 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 264044093041156097,
  "created_at" : "2012-11-01 16:39:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264040745042857984",
  "text" : "RT @AnnotatedBible: If we condemn all religion for the religious bad people and crackpots, then shouldn't we condemn all science for the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264040233824313346",
    "text" : "If we condemn all religion for the religious bad people and crackpots, then shouldn't we condemn all science for the scientific crackpots?",
    "id" : 264040233824313346,
    "created_at" : "2012-11-01 16:24:32 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 264040745042857984,
  "created_at" : "2012-11-01 16:26:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ResistTrump",
      "screen_name" : "liberalandold",
      "indices" : [ 3, 17 ],
      "id_str" : "196640692",
      "id" : 196640692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264021728097878016",
  "text" : "RT @liberalandold: I am so lucky to be sitting in a warm room with power. so lucky to have food and water. I try to remember this every day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264009974135521280",
    "text" : "I am so lucky to be sitting in a warm room with power. so lucky to have food and water. I try to remember this every day.",
    "id" : 264009974135521280,
    "created_at" : "2012-11-01 14:24:17 +0000",
    "user" : {
      "name" : "ResistTrump",
      "screen_name" : "liberalandold",
      "protected" : false,
      "id_str" : "196640692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799079170760392707\/OJs83Maz_normal.jpg",
      "id" : 196640692,
      "verified" : false
    }
  },
  "id" : 264021728097878016,
  "created_at" : "2012-11-01 15:10:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]