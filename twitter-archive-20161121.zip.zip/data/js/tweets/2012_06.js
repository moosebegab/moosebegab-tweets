Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219230633203994626",
  "text" : "RT @ZachsMind: So long as they have you believing your vote still counts, they got you. This is a corporate oligarchy. The democratic re ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219229861661777920",
    "text" : "So long as they have you believing your vote still counts, they got you. This is a corporate oligarchy. The democratic republic is a front.",
    "id" : 219229861661777920,
    "created_at" : "2012-07-01 00:44:06 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 219230633203994626,
  "created_at" : "2012-07-01 00:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219204288902217728",
  "text" : "survived the family reunion and might have even enjoyed myself..lol",
  "id" : 219204288902217728,
  "created_at" : "2012-06-30 23:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/3mY0JNnO",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/i-hate-this-landlord-will-not-stop.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/i-hate\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "219079121987305473",
  "geo" : { },
  "id_str" : "219082043051622400",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves I hate this! Landlord will not stop! http:\/\/t.co\/3mY0JNnO",
  "id" : 219082043051622400,
  "in_reply_to_status_id" : 219079121987305473,
  "created_at" : "2012-06-30 14:56:44 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219081462304088066",
  "text" : "going to family reunion today. have nothing cool to wear.. or anything that looks half decent on me. ugh...",
  "id" : 219081462304088066,
  "created_at" : "2012-06-30 14:54:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Z3ztpBWR",
      "expanded_url" : "http:\/\/twitpic.com\/a21rr9",
      "display_url" : "twitpic.com\/a21rr9"
    } ]
  },
  "geo" : { },
  "id_str" : "218889020430761985",
  "text" : "RT @ducksandclucks: My cute park buddy today. http:\/\/t.co\/Z3ztpBWR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/Z3ztpBWR",
        "expanded_url" : "http:\/\/twitpic.com\/a21rr9",
        "display_url" : "twitpic.com\/a21rr9"
      } ]
    },
    "geo" : { },
    "id_str" : "218887519331303424",
    "text" : "My cute park buddy today. http:\/\/t.co\/Z3ztpBWR",
    "id" : 218887519331303424,
    "created_at" : "2012-06-30 02:03:45 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 218889020430761985,
  "created_at" : "2012-06-30 02:09:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218761933275414529",
  "geo" : { },
  "id_str" : "218763278434828288",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater awww.. sweet. DDs cat loves boxes, too.",
  "id" : 218763278434828288,
  "in_reply_to_status_id" : 218761933275414529,
  "created_at" : "2012-06-29 17:50:04 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218762875475476480",
  "text" : "@Skeptical_Lady LOL",
  "id" : 218762875475476480,
  "created_at" : "2012-06-29 17:48:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 34, 47 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/hkDzEz3Y",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/friday-can-you-help-me-find-someone-to.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/friday\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218707995050254337",
  "geo" : { },
  "id_str" : "218749064295092224",
  "in_reply_to_user_id" : 73908822,
  "text" : "He will be homeless on Sunday! RT @DwayneReaves Friday, can you help me find someone to help me? http:\/\/t.co\/hkDzEz3Y",
  "id" : 218749064295092224,
  "in_reply_to_status_id" : 218707995050254337,
  "created_at" : "2012-06-29 16:53:35 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218742847581585408",
  "geo" : { },
  "id_str" : "218745405956038657",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater beautiful kitty! siamese? we had 2 brothers years ago, 1 fat, 1 skinny. such mischief! lol",
  "id" : 218745405956038657,
  "in_reply_to_status_id" : 218742847581585408,
  "created_at" : "2012-06-29 16:39:03 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218446874695311360",
  "text" : "RT @AppAdvice: MacPhun wants your help in renewing Color Splash Studio, and they're offering up some great incentives to do so: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/appadvice.com\" rel=\"nofollow\"\u003EAppAdvice Website\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/CIFStSxN",
        "expanded_url" : "http:\/\/bit.ly\/MB3t28",
        "display_url" : "bit.ly\/MB3t28"
      } ]
    },
    "geo" : { },
    "id_str" : "218103139843313664",
    "text" : "MacPhun wants your help in renewing Color Splash Studio, and they're offering up some great incentives to do so: http:\/\/t.co\/CIFStSxN",
    "id" : 218103139843313664,
    "created_at" : "2012-06-27 22:06:55 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 218446874695311360,
  "created_at" : "2012-06-28 20:52:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "indices" : [ 44, 54 ],
      "id_str" : "21636840",
      "id" : 21636840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218443620133515267",
  "text" : "O.M.G. I think I'm hooked on Fruit Ninja by @Halfbrick .. LOL .. who knew slicing fruit could be so much fun? : )",
  "id" : 218443620133515267,
  "created_at" : "2012-06-28 20:39:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/whtyYTC6",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/bullying-bullied-by-landlord.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/bullyi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218363825202794496",
  "geo" : { },
  "id_str" : "218430406507245568",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves Bullying, bullied by the landlord? http:\/\/t.co\/whtyYTC6",
  "id" : 218430406507245568,
  "in_reply_to_status_id" : 218363825202794496,
  "created_at" : "2012-06-28 19:47:21 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/CqJVjsFH",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/my-last-days.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/my-las\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218331722444582912",
  "geo" : { },
  "id_str" : "218429942789177344",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves My last days http:\/\/t.co\/CqJVjsFH",
  "id" : 218429942789177344,
  "in_reply_to_status_id" : 218331722444582912,
  "created_at" : "2012-06-28 19:45:31 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218384199269351424",
  "geo" : { },
  "id_str" : "218387076910026752",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell you go, girl! : )",
  "id" : 218387076910026752,
  "in_reply_to_status_id" : 218384199269351424,
  "created_at" : "2012-06-28 16:55:11 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218375125886705666",
  "text" : "RT @JosephRanseth: Most of the problems you worry about will stop being problems the moment you stop worrying about them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218374926112006146",
    "text" : "Most of the problems you worry about will stop being problems the moment you stop worrying about them.",
    "id" : 218374926112006146,
    "created_at" : "2012-06-28 16:06:54 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 218375125886705666,
  "created_at" : "2012-06-28 16:07:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218372638999977984",
  "text" : "obamacare is not socialized medicine. it's forcing you to pay the \"for-profit\" insurance companies to screw you over!",
  "id" : 218372638999977984,
  "created_at" : "2012-06-28 15:57:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "indices" : [ 3, 11 ],
      "id_str" : "20479813",
      "id" : 20479813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218310263009583104",
  "text" : "RT @MMFlint: No matter what the Supreme Court says in the morning, they can't alter this 1 truth: It is blatantly immoral 2 profit off s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218168184992309249",
    "text" : "No matter what the Supreme Court says in the morning, they can't alter this 1 truth: It is blatantly immoral 2 profit off someone's illness.",
    "id" : 218168184992309249,
    "created_at" : "2012-06-28 02:25:23 +0000",
    "user" : {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "protected" : false,
      "id_str" : "20479813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440557378027520000\/DTvD2bbr_normal.jpeg",
      "id" : 20479813,
      "verified" : true
    }
  },
  "id" : 218310263009583104,
  "created_at" : "2012-06-28 11:49:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gofundme",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/YICI9Csz",
      "expanded_url" : "http:\/\/www.gofundme.com\/r1p8g",
      "display_url" : "gofundme.com\/r1p8g"
    } ]
  },
  "in_reply_to_status_id_str" : "218144966982115329",
  "geo" : { },
  "id_str" : "218154285781889024",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves If nothing else, at least say a prayer for me, I truly don't feel very well right now! http:\/\/t.co\/YICI9Csz #gofundme",
  "id" : 218154285781889024,
  "in_reply_to_status_id" : 218144966982115329,
  "created_at" : "2012-06-28 01:30:09 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218094959188901890",
  "geo" : { },
  "id_str" : "218096031542423552",
  "in_reply_to_user_id" : 419534932,
  "text" : "@Boonearang yeah.. hubby and I are fairly free-range, too.. drove grandma crazy (and still does..lol)",
  "id" : 218096031542423552,
  "in_reply_to_status_id" : 218094959188901890,
  "created_at" : "2012-06-27 21:38:40 +0000",
  "in_reply_to_screen_name" : "JediMasterJason",
  "in_reply_to_user_id_str" : "419534932",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218090587696541696",
  "geo" : { },
  "id_str" : "218092087449620480",
  "in_reply_to_user_id" : 419534932,
  "text" : "@Boonearang kids are funny like that..lol",
  "id" : 218092087449620480,
  "in_reply_to_status_id" : 218090587696541696,
  "created_at" : "2012-06-27 21:23:00 +0000",
  "in_reply_to_screen_name" : "JediMasterJason",
  "in_reply_to_user_id_str" : "419534932",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218087955523321857",
  "geo" : { },
  "id_str" : "218091744233914369",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles oh..and prob nerves, too..lol. even as a kid had sensitive stomach, was picky eater.",
  "id" : 218091744233914369,
  "in_reply_to_status_id" : 218087955523321857,
  "created_at" : "2012-06-27 21:21:38 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218087955523321857",
  "geo" : { },
  "id_str" : "218091199565791234",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles i seem to pick up stomach flu more often than the average bear, also.. very weird..",
  "id" : 218091199565791234,
  "in_reply_to_status_id" : 218087955523321857,
  "created_at" : "2012-06-27 21:19:28 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218087955523321857",
  "geo" : { },
  "id_str" : "218090994233655301",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles i had my GB removed years ago overflowing w stones so I think the bile from my liver (TMI? lol)",
  "id" : 218090994233655301,
  "in_reply_to_status_id" : 218087955523321857,
  "created_at" : "2012-06-27 21:18:39 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Science",
      "screen_name" : "HuffPostScience",
      "indices" : [ 73, 89 ],
      "id_str" : "195897346",
      "id" : 195897346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/zr1fHrSV",
      "expanded_url" : "http:\/\/huff.to\/LQyCwy",
      "display_url" : "huff.to\/LQyCwy"
    } ]
  },
  "geo" : { },
  "id_str" : "218083301041246208",
  "text" : "Rats Laugh When Tickled, Scientists Say (VIDEO) http:\/\/t.co\/zr1fHrSV via @HuffPostScience",
  "id" : 218083301041246208,
  "created_at" : "2012-06-27 20:48:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/FRIvD5l3",
      "expanded_url" : "http:\/\/gopetfriendlyblog.com\/dog-camping-heaven-in-upstate-new-york\/",
      "display_url" : "gopetfriendlyblog.com\/dog-camping-he\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218079229575827457",
  "text" : "Dog Camping Heaven in Upstate New York http:\/\/t.co\/FRIvD5l3",
  "id" : 218079229575827457,
  "created_at" : "2012-06-27 20:31:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 30, 43 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/TXwW1QSh",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/3-days-left-and-begging.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/3-days\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218065664454311936",
  "geo" : { },
  "id_str" : "218067031222784000",
  "in_reply_to_user_id" : 73908822,
  "text" : "this is breaking my heart! RT @DwayneReaves 3 days left and begging http:\/\/t.co\/TXwW1QSh",
  "id" : 218067031222784000,
  "in_reply_to_status_id" : 218065664454311936,
  "created_at" : "2012-06-27 19:43:26 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218061735461007360",
  "geo" : { },
  "id_str" : "218066114402459649",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles yeah.. i'm w you on that one!",
  "id" : 218066114402459649,
  "in_reply_to_status_id" : 218061735461007360,
  "created_at" : "2012-06-27 19:39:47 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/pyeJwM8B",
      "expanded_url" : "http:\/\/krissthesexyatheist.blogspot.com\/2012\/06\/time-to-kill.html?spref=tw",
      "display_url" : "krissthesexyatheist.blogspot.com\/2012\/06\/time-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218044904419500032",
  "text" : "RT @thesexyatheist: krissthesexyatheist: A Time To Kill http:\/\/t.co\/pyeJwM8B Is there ever a time to kill, or is it always turn the othe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/pyeJwM8B",
        "expanded_url" : "http:\/\/krissthesexyatheist.blogspot.com\/2012\/06\/time-to-kill.html?spref=tw",
        "display_url" : "krissthesexyatheist.blogspot.com\/2012\/06\/time-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "218041057563250688",
    "text" : "krissthesexyatheist: A Time To Kill http:\/\/t.co\/pyeJwM8B Is there ever a time to kill, or is it always turn the other cheek. i don't know.",
    "id" : 218041057563250688,
    "created_at" : "2012-06-27 18:00:13 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 218044904419500032,
  "created_at" : "2012-06-27 18:15:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218041002731118592",
  "text" : "I think it was on Sunday, driving home, we ran thru a murder of crows. Hubby said they were young as they struggled to get out of way.",
  "id" : 218041002731118592,
  "created_at" : "2012-06-27 18:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/p2uVAm2q",
      "expanded_url" : "http:\/\/via.me\/-2fz3cfw",
      "display_url" : "via.me\/-2fz3cfw"
    } ]
  },
  "geo" : { },
  "id_str" : "218032048999366657",
  "text" : "Hi.. It's just me.. http:\/\/t.co\/p2uVAm2q",
  "id" : 218032048999366657,
  "created_at" : "2012-06-27 17:24:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/TO1PRPcd",
      "expanded_url" : "http:\/\/via.me\/-2fz2eha",
      "display_url" : "via.me\/-2fz2eha"
    } ]
  },
  "geo" : { },
  "id_str" : "218031776654823424",
  "text" : "Nice view! http:\/\/t.co\/TO1PRPcd",
  "id" : 218031776654823424,
  "created_at" : "2012-06-27 17:23:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/qKMO7T38",
      "expanded_url" : "http:\/\/via.me\/-2fz1esi",
      "display_url" : "via.me\/-2fz1esi"
    } ]
  },
  "geo" : { },
  "id_str" : "218031468016963584",
  "text" : "My feet with Kindle in lap. http:\/\/t.co\/qKMO7T38",
  "id" : 218031468016963584,
  "created_at" : "2012-06-27 17:22:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michaK",
      "screen_name" : "michaK",
      "indices" : [ 0, 7 ],
      "id_str" : "14683895",
      "id" : 14683895
    }, {
      "name" : "Kirefly",
      "screen_name" : "KireflyonGC",
      "indices" : [ 85, 97 ],
      "id_str" : "458637846",
      "id" : 458637846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215960218524336130",
  "geo" : { },
  "id_str" : "218024207362162688",
  "in_reply_to_user_id" : 14683895,
  "text" : "@michaK froggle looks good. you should have a mail list for those waiting for it : ) @KireflyonGC",
  "id" : 218024207362162688,
  "in_reply_to_status_id" : 215960218524336130,
  "created_at" : "2012-06-27 16:53:16 +0000",
  "in_reply_to_screen_name" : "michaK",
  "in_reply_to_user_id_str" : "14683895",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "indices" : [ 3, 18 ],
      "id_str" : "29574025",
      "id" : 29574025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217993738293743617",
  "text" : "RT @KindleObsessed: Looking 4 a new Kindle case or skin? I currently have 7 accessory giveaways going on over @ the blog Stop by &amp; s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/FOYiyOq1",
        "expanded_url" : "http:\/\/www.kindleobsessed.com\/category\/accessory-corner\/",
        "display_url" : "kindleobsessed.com\/category\/acces\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217992439909191680",
    "text" : "Looking 4 a new Kindle case or skin? I currently have 7 accessory giveaways going on over @ the blog Stop by &amp; sign up! http:\/\/t.co\/FOYiyOq1",
    "id" : 217992439909191680,
    "created_at" : "2012-06-27 14:47:02 +0000",
    "user" : {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "protected" : false,
      "id_str" : "29574025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526178477213380608\/oLhvSdVV_normal.jpeg",
      "id" : 29574025,
      "verified" : false
    }
  },
  "id" : 217993738293743617,
  "created_at" : "2012-06-27 14:52:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Lq0wfSV2",
      "expanded_url" : "http:\/\/bit.ly\/LBlJZ0",
      "display_url" : "bit.ly\/LBlJZ0"
    } ]
  },
  "geo" : { },
  "id_str" : "217986252811669504",
  "text" : "RT @AppAdvice: Want a pirate puzzle game? http:\/\/t.co\/Lq0wfSV2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/appadvice.com\" rel=\"nofollow\"\u003EAppAdvice Website\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/Lq0wfSV2",
        "expanded_url" : "http:\/\/bit.ly\/LBlJZ0",
        "display_url" : "bit.ly\/LBlJZ0"
      } ]
    },
    "geo" : { },
    "id_str" : "217980331565907971",
    "text" : "Want a pirate puzzle game? http:\/\/t.co\/Lq0wfSV2",
    "id" : 217980331565907971,
    "created_at" : "2012-06-27 13:58:55 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 217986252811669504,
  "created_at" : "2012-06-27 14:22:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "...",
      "screen_name" : "PinayNoire",
      "indices" : [ 3, 14 ],
      "id_str" : "111080166",
      "id" : 111080166
    }, {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 54, 63 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringNickHome",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217983508449206275",
  "text" : "RT @PinayNoire: As a mom, this hurts.  Prayers w\/ you @AniKnits.\"Blogging to #BringNickHome-When Your Blog is Used Against You\": http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "aniknits",
        "screen_name" : "AniKnits",
        "indices" : [ 38, 47 ],
        "id_str" : "184401626",
        "id" : 184401626
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 61, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/TdH3ozye",
        "expanded_url" : "http:\/\/bit.ly\/LLC6AW",
        "display_url" : "bit.ly\/LLC6AW"
      } ]
    },
    "geo" : { },
    "id_str" : "217977530093801472",
    "text" : "As a mom, this hurts.  Prayers w\/ you @AniKnits.\"Blogging to #BringNickHome-When Your Blog is Used Against You\": http:\/\/t.co\/TdH3ozye",
    "id" : 217977530093801472,
    "created_at" : "2012-06-27 13:47:47 +0000",
    "user" : {
      "name" : "...",
      "screen_name" : "PinayNoire",
      "protected" : false,
      "id_str" : "111080166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625782370688495616\/jTSPD-NW_normal.jpg",
      "id" : 111080166,
      "verified" : false
    }
  },
  "id" : 217983508449206275,
  "created_at" : "2012-06-27 14:11:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Ms. D",
      "screen_name" : "EdgeOnEd",
      "indices" : [ 35, 44 ],
      "id_str" : "593956863",
      "id" : 593956863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217960909199515649",
  "text" : "RT @DeepakChopra: Weird is ok :)RT @EdgeOnEd: Sometimes it's frightening how much I GET what you're saying. You know you come off weird  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ms. D",
        "screen_name" : "EdgeOnEd",
        "indices" : [ 17, 26 ],
        "id_str" : "593956863",
        "id" : 593956863
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217958995527344128",
    "text" : "Weird is ok :)RT @EdgeOnEd: Sometimes it's frightening how much I GET what you're saying. You know you come off weird to some people.",
    "id" : 217958995527344128,
    "created_at" : "2012-06-27 12:34:08 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 217960909199515649,
  "created_at" : "2012-06-27 12:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "Nina Garcia",
      "screen_name" : "ninagarcia",
      "indices" : [ 17, 28 ],
      "id_str" : "158128894",
      "id" : 158128894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217789585969790976",
  "text" : "RT @AniKnits: RT @ninagarcia \u201CAbove all, be the heroine of your life, not the victim.\u201D  RIP Nora Ephron",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nina Garcia",
        "screen_name" : "ninagarcia",
        "indices" : [ 3, 14 ],
        "id_str" : "158128894",
        "id" : 158128894
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217789124382437376",
    "text" : "RT @ninagarcia \u201CAbove all, be the heroine of your life, not the victim.\u201D  RIP Nora Ephron",
    "id" : 217789124382437376,
    "created_at" : "2012-06-27 01:19:08 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 217789585969790976,
  "created_at" : "2012-06-27 01:20:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217788288143073280",
  "text" : "RT @AniKnits: Paulo Coelho writes about being sent to a mental hospital three times, then quotes another of my favorite authors. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/sBaP1EGT",
        "expanded_url" : "http:\/\/bit.ly\/gFXHFm",
        "display_url" : "bit.ly\/gFXHFm"
      } ]
    },
    "geo" : { },
    "id_str" : "217787490927521792",
    "text" : "Paulo Coelho writes about being sent to a mental hospital three times, then quotes another of my favorite authors. http:\/\/t.co\/sBaP1EGT",
    "id" : 217787490927521792,
    "created_at" : "2012-06-27 01:12:38 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 217788288143073280,
  "created_at" : "2012-06-27 01:15:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 3, 16 ],
      "id_str" : "43298413",
      "id" : 43298413
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 45, 57 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BarackObama\/status\/217773759644450818\/photo\/1",
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/LChd4pr3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwWwFKKCQAITdiT.jpg",
      "id_str" : "217773759669616642",
      "id" : 217773759669616642,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwWwFKKCQAITdiT.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LChd4pr3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217786487276699648",
  "text" : "RT @NathanDunbar: Shut. The. Front. Door. RT @BarackObama: Thank you for being a friend: http:\/\/t.co\/LChd4pr3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 27, 39 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BarackObama\/status\/217773759644450818\/photo\/1",
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/LChd4pr3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AwWwFKKCQAITdiT.jpg",
        "id_str" : "217773759669616642",
        "id" : 217773759669616642,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwWwFKKCQAITdiT.jpg",
        "sizes" : [ {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LChd4pr3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217774602552750080",
    "text" : "Shut. The. Front. Door. RT @BarackObama: Thank you for being a friend: http:\/\/t.co\/LChd4pr3",
    "id" : 217774602552750080,
    "created_at" : "2012-06-27 00:21:25 +0000",
    "user" : {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "protected" : false,
      "id_str" : "43298413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683069342842503169\/t-eR15ya_normal.jpg",
      "id" : 43298413,
      "verified" : false
    }
  },
  "id" : 217786487276699648,
  "created_at" : "2012-06-27 01:08:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/IR99QaYa",
      "expanded_url" : "http:\/\/twitpic.com\/a0x42z",
      "display_url" : "twitpic.com\/a0x42z"
    } ]
  },
  "in_reply_to_status_id_str" : "217777087149375488",
  "geo" : { },
  "id_str" : "217786034577092608",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves Of course they had to leave me another letter also, guess they think I want to live in a jeep! http:\/\/t.co\/IR99QaYa",
  "id" : 217786034577092608,
  "in_reply_to_status_id" : 217777087149375488,
  "created_at" : "2012-06-27 01:06:51 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/YICI9Csz",
      "expanded_url" : "http:\/\/www.gofundme.com\/r1p8g",
      "display_url" : "gofundme.com\/r1p8g"
    } ]
  },
  "in_reply_to_status_id_str" : "217761025620049923",
  "geo" : { },
  "id_str" : "217761572393721856",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves I have 4 days to come up with an answer http:\/\/t.co\/YICI9Csz",
  "id" : 217761572393721856,
  "in_reply_to_status_id" : 217761025620049923,
  "created_at" : "2012-06-26 23:29:39 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 0, 10 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217715063392444417",
  "geo" : { },
  "id_str" : "217722193642143744",
  "in_reply_to_user_id" : 529048622,
  "text" : "@alanhdawe : )",
  "id" : 217722193642143744,
  "in_reply_to_status_id" : 217715063392444417,
  "created_at" : "2012-06-26 20:53:10 +0000",
  "in_reply_to_screen_name" : "alanhdawe",
  "in_reply_to_user_id_str" : "529048622",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birders",
      "indices" : [ 23, 31 ]
    }, {
      "text" : "birdwatchers",
      "indices" : [ 32, 45 ]
    }, {
      "text" : "nature",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217705481270079488",
  "text" : "RT @petersonguides: OK #birders #birdwatchers &amp; #nature lovers in general\u2014we need 102 more Facebook Likes to top 3000!! Go. Now. Lik ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birders",
        "indices" : [ 3, 11 ]
      }, {
        "text" : "birdwatchers",
        "indices" : [ 12, 25 ]
      }, {
        "text" : "nature",
        "indices" : [ 32, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/2cxUZBCy",
        "expanded_url" : "http:\/\/on.fb.me\/jY2lMZ",
        "display_url" : "on.fb.me\/jY2lMZ"
      } ]
    },
    "geo" : { },
    "id_str" : "217701819038695427",
    "text" : "OK #birders #birdwatchers &amp; #nature lovers in general\u2014we need 102 more Facebook Likes to top 3000!! Go. Now. Like us! http:\/\/t.co\/2cxUZBCy",
    "id" : 217701819038695427,
    "created_at" : "2012-06-26 19:32:13 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 217705481270079488,
  "created_at" : "2012-06-26 19:46:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/tcNsJOaP",
      "expanded_url" : "http:\/\/EzineArticles.com\/7129704",
      "display_url" : "EzineArticles.com\/7129704"
    } ]
  },
  "geo" : { },
  "id_str" : "217667504275849216",
  "text" : "RT @alanhdawe: A Universe from Nothing? Has Lawrence M. Krauss Missed the Point?: http:\/\/t.co\/tcNsJOaP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ezinearticles.com\" rel=\"nofollow\"\u003EEzineArticles\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/tcNsJOaP",
        "expanded_url" : "http:\/\/EzineArticles.com\/7129704",
        "display_url" : "EzineArticles.com\/7129704"
      } ]
    },
    "geo" : { },
    "id_str" : "217663367706451968",
    "text" : "A Universe from Nothing? Has Lawrence M. Krauss Missed the Point?: http:\/\/t.co\/tcNsJOaP",
    "id" : 217663367706451968,
    "created_at" : "2012-06-26 16:59:25 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 217667504275849216,
  "created_at" : "2012-06-26 17:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 133, 143 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/LBbxi1pn",
      "expanded_url" : "http:\/\/bit.ly\/Or3SqJ",
      "display_url" : "bit.ly\/Or3SqJ"
    } ]
  },
  "geo" : { },
  "id_str" : "217667366484574208",
  "text" : "Magic? LOL &gt;&gt; if there were nothing, absolutely nothing at all, how would anything ever have got started? http:\/\/t.co\/LBbxi1pn @alanhdawe",
  "id" : 217667366484574208,
  "created_at" : "2012-06-26 17:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/MauKhtHc",
      "expanded_url" : "http:\/\/goo.gl\/fb\/VRjqv",
      "display_url" : "goo.gl\/fb\/VRjqv"
    } ]
  },
  "geo" : { },
  "id_str" : "217634756861509633",
  "text" : "RT @Mahala: The Temperature's Rising, And I Ain't Talkin' 'Bout the Weather http:\/\/t.co\/MauKhtHc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/MauKhtHc",
        "expanded_url" : "http:\/\/goo.gl\/fb\/VRjqv",
        "display_url" : "goo.gl\/fb\/VRjqv"
      } ]
    },
    "geo" : { },
    "id_str" : "217633609383804928",
    "text" : "The Temperature's Rising, And I Ain't Talkin' 'Bout the Weather http:\/\/t.co\/MauKhtHc",
    "id" : 217633609383804928,
    "created_at" : "2012-06-26 15:01:10 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 217634756861509633,
  "created_at" : "2012-06-26 15:05:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 87, 100 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217632282062761987",
  "text" : "\"I\u2019m not concerned about the very poor; we have a safety net there.\" (Romney) Where is @dwaynereaves safety net??",
  "id" : 217632282062761987,
  "created_at" : "2012-06-26 14:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/YICI9Csz",
      "expanded_url" : "http:\/\/www.gofundme.com\/r1p8g",
      "display_url" : "gofundme.com\/r1p8g"
    } ]
  },
  "geo" : { },
  "id_str" : "217630348031426560",
  "text" : "Honesty? Does it have a value? http:\/\/t.co\/YICI9Csz",
  "id" : 217630348031426560,
  "created_at" : "2012-06-26 14:48:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 26, 39 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Po1AsLAP",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/",
      "display_url" : "mrreaves.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "217630010545156099",
  "text" : "Do u have a job or home 4 @dwaynereaves ? After THIS weekend, he'll likely b offline, living in his vehicle.. http:\/\/t.co\/Po1AsLAP",
  "id" : 217630010545156099,
  "created_at" : "2012-06-26 14:46:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217448288209747968",
  "geo" : { },
  "id_str" : "217628944055279616",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves Life isn't all glorious on my end, I have five days to figure out how to get tags on my jeep so I can live in it",
  "id" : 217628944055279616,
  "in_reply_to_status_id" : 217448288209747968,
  "created_at" : "2012-06-26 14:42:38 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/KWKppvdH",
      "expanded_url" : "http:\/\/bookwi.se\/new-kindles-july\/",
      "display_url" : "bookwi.se\/new-kindles-ju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217606028844474368",
  "text" : "RT @adamrshields: CNet and Digitimes are reporting that new kindles may be released or announced in July. http:\/\/t.co\/KWKppvdH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/KWKppvdH",
        "expanded_url" : "http:\/\/bookwi.se\/new-kindles-july\/",
        "display_url" : "bookwi.se\/new-kindles-ju\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217596886197080064",
    "text" : "CNet and Digitimes are reporting that new kindles may be released or announced in July. http:\/\/t.co\/KWKppvdH",
    "id" : 217596886197080064,
    "created_at" : "2012-06-26 12:35:15 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 217606028844474368,
  "created_at" : "2012-06-26 13:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217596644332539906",
  "text" : "RT @Floridaline: How the hell does a man worth $430 million get to bitch about firefighters, cops and teachers having it too good? http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/4on4wzht",
        "expanded_url" : "http:\/\/bit.ly\/MoIVsl",
        "display_url" : "bit.ly\/MoIVsl"
      } ]
    },
    "geo" : { },
    "id_str" : "217399577475686402",
    "text" : "How the hell does a man worth $430 million get to bitch about firefighters, cops and teachers having it too good? http:\/\/t.co\/4on4wzht",
    "id" : 217399577475686402,
    "created_at" : "2012-06-25 23:31:13 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 217596644332539906,
  "created_at" : "2012-06-26 12:34:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217589827829383170",
  "geo" : { },
  "id_str" : "217591133725917184",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt sighhh.. lovely.",
  "id" : 217591133725917184,
  "in_reply_to_status_id" : 217589827829383170,
  "created_at" : "2012-06-26 12:12:23 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217585773237633024",
  "text" : "RT @RevDebra: May I bring love to everything I do today -- and to everyone I meet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217580120037265409",
    "text" : "May I bring love to everything I do today -- and to everyone I meet.",
    "id" : 217580120037265409,
    "created_at" : "2012-06-26 11:28:37 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 217585773237633024,
  "created_at" : "2012-06-26 11:51:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217424840393629697",
  "text" : "@BeaEdyson many older ppl have gone further into their views, being overwhelmed w world changes...",
  "id" : 217424840393629697,
  "created_at" : "2012-06-26 01:11:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217419503766745088",
  "text" : "@Skeptical_Lady congrats on 15 yrs 4 days ago..lol.. Cheers!",
  "id" : 217419503766745088,
  "created_at" : "2012-06-26 00:50:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Teevens",
      "screen_name" : "CindyTeevens",
      "indices" : [ 3, 16 ],
      "id_str" : "49857989",
      "id" : 49857989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/giqIgCnQ",
      "expanded_url" : "http:\/\/ht.ly\/9V5fI",
      "display_url" : "ht.ly\/9V5fI"
    } ]
  },
  "geo" : { },
  "id_str" : "217418917478531072",
  "text" : "RT @CindyTeevens: Don't think positively--feel good first. 2 questions that will shift your state: http:\/\/t.co\/giqIgCnQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/giqIgCnQ",
        "expanded_url" : "http:\/\/ht.ly\/9V5fI",
        "display_url" : "ht.ly\/9V5fI"
      } ]
    },
    "geo" : { },
    "id_str" : "217418193130622977",
    "text" : "Don't think positively--feel good first. 2 questions that will shift your state: http:\/\/t.co\/giqIgCnQ",
    "id" : 217418193130622977,
    "created_at" : "2012-06-26 00:45:11 +0000",
    "user" : {
      "name" : "Cindy Teevens",
      "screen_name" : "CindyTeevens",
      "protected" : false,
      "id_str" : "49857989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/277670878\/MeNew_normal.jpg",
      "id" : 49857989,
      "verified" : false
    }
  },
  "id" : 217418917478531072,
  "created_at" : "2012-06-26 00:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217417307390095360",
  "text" : "Raccoon on porch getting his evening meal.",
  "id" : 217417307390095360,
  "created_at" : "2012-06-26 00:41:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217401562656542721",
  "text" : "RT @brandonrofl: Fuck what everyone says. If you can't live your life the way you want to, then it's all for nothing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217401238269083648",
    "text" : "Fuck what everyone says. If you can't live your life the way you want to, then it's all for nothing.",
    "id" : 217401238269083648,
    "created_at" : "2012-06-25 23:37:48 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 217401562656542721,
  "created_at" : "2012-06-25 23:39:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/MCZSJ5Dt",
      "expanded_url" : "http:\/\/tinyurl.com\/89dl48v",
      "display_url" : "tinyurl.com\/89dl48v"
    } ]
  },
  "geo" : { },
  "id_str" : "217389352668508160",
  "text" : "RT @Seeds4Parents: Young sloths grab their own arms and legs instead of tree limbs, and fall out of trees. D Adams, http:\/\/t.co\/MCZSJ5Dt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/MCZSJ5Dt",
        "expanded_url" : "http:\/\/tinyurl.com\/89dl48v",
        "display_url" : "tinyurl.com\/89dl48v"
      } ]
    },
    "geo" : { },
    "id_str" : "217387987552579584",
    "text" : "Young sloths grab their own arms and legs instead of tree limbs, and fall out of trees. D Adams, http:\/\/t.co\/MCZSJ5Dt",
    "id" : 217387987552579584,
    "created_at" : "2012-06-25 22:45:09 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 217389352668508160,
  "created_at" : "2012-06-25 22:50:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "indices" : [ 21, 26 ],
      "id_str" : "18957524",
      "id" : 18957524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217379001231093762",
  "text" : "watching The Mist on @syfy (based on Stephen King's novella) creepy! lol",
  "id" : 217379001231093762,
  "created_at" : "2012-06-25 22:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/21JqaXl1",
      "expanded_url" : "http:\/\/fb.me\/1CRUNWzlY",
      "display_url" : "fb.me\/1CRUNWzlY"
    } ]
  },
  "geo" : { },
  "id_str" : "217358595866632195",
  "text" : "RT @petersonguides: More fun with crows. Have more respect for these birds everyday. http:\/\/t.co\/21JqaXl1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/21JqaXl1",
        "expanded_url" : "http:\/\/fb.me\/1CRUNWzlY",
        "display_url" : "fb.me\/1CRUNWzlY"
      } ]
    },
    "geo" : { },
    "id_str" : "217357391375777792",
    "text" : "More fun with crows. Have more respect for these birds everyday. http:\/\/t.co\/21JqaXl1",
    "id" : 217357391375777792,
    "created_at" : "2012-06-25 20:43:35 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 217358595866632195,
  "created_at" : "2012-06-25 20:48:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217346351124586497",
  "text" : "the soft tapping of the bluebird at my bedroom window each morning comforts me. he is a blessing to me.",
  "id" : 217346351124586497,
  "created_at" : "2012-06-25 19:59:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wade Cosner",
      "screen_name" : "WadeCosner",
      "indices" : [ 3, 14 ],
      "id_str" : "25433187",
      "id" : 25433187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217345194855628800",
  "text" : "RT @WadeCosner: Just started a new iTunesU course: Yale University, Autism &amp; Related Disorders. If your child has autism, take this  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Free",
        "indices" : [ 130, 135 ]
      }, {
        "text" : "iTunesU",
        "indices" : [ 136, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213656052825206784",
    "text" : "Just started a new iTunesU course: Yale University, Autism &amp; Related Disorders. If your child has autism, take this course!!! #Free #iTunesU",
    "id" : 213656052825206784,
    "created_at" : "2012-06-15 15:35:47 +0000",
    "user" : {
      "name" : "Wade Cosner",
      "screen_name" : "WadeCosner",
      "protected" : false,
      "id_str" : "25433187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043035412\/Photo_2_normal.jpg",
      "id" : 25433187,
      "verified" : false
    }
  },
  "id" : 217345194855628800,
  "created_at" : "2012-06-25 19:55:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217341227685773312",
  "geo" : { },
  "id_str" : "217344380028203010",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth for some reason, for storms, our dog will leave our room and go to DD's room and try to climb in top bunk w her..lol",
  "id" : 217344380028203010,
  "in_reply_to_status_id" : 217341227685773312,
  "created_at" : "2012-06-25 19:51:52 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217341227685773312",
  "geo" : { },
  "id_str" : "217344085206380546",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth oh too cute! hehe",
  "id" : 217344085206380546,
  "in_reply_to_status_id" : 217341227685773312,
  "created_at" : "2012-06-25 19:50:42 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "indices" : [ 3, 17 ],
      "id_str" : "69318532",
      "id" : 69318532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217341780134334465",
  "text" : "RT @MyBizPresence: People are pointing out that FB has changed everyone's default contact info email on the personal profiles to... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/guJaXZEk",
        "expanded_url" : "http:\/\/fb.me\/zvhNhq5r",
        "display_url" : "fb.me\/zvhNhq5r"
      } ]
    },
    "geo" : { },
    "id_str" : "217340045751889922",
    "text" : "People are pointing out that FB has changed everyone's default contact info email on the personal profiles to... http:\/\/t.co\/guJaXZEk",
    "id" : 217340045751889922,
    "created_at" : "2012-06-25 19:34:39 +0000",
    "user" : {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "protected" : false,
      "id_str" : "69318532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748607898406645761\/us3mLEKn_normal.jpg",
      "id" : 69318532,
      "verified" : false
    }
  },
  "id" : 217341780134334465,
  "created_at" : "2012-06-25 19:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217322341179461632",
  "geo" : { },
  "id_str" : "217324872462893056",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise : ( poor thing .. (i remember as a kid thinking no chemo for me)",
  "id" : 217324872462893056,
  "in_reply_to_status_id" : 217322341179461632,
  "created_at" : "2012-06-25 18:34:21 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "There are no gods",
      "screen_name" : "god_sucks",
      "indices" : [ 0, 10 ],
      "id_str" : "442249363",
      "id" : 442249363
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 26, 40 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217315734211145728",
  "geo" : { },
  "id_str" : "217324011116437504",
  "in_reply_to_user_id" : 442249363,
  "text" : "@god_sucks jeepers... : ( @BibleAlsoSays",
  "id" : 217324011116437504,
  "in_reply_to_status_id" : 217315734211145728,
  "created_at" : "2012-06-25 18:30:56 +0000",
  "in_reply_to_screen_name" : "god_sucks",
  "in_reply_to_user_id_str" : "442249363",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/PggIMghA",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/i-am-not-proud-i-wish-i-could-make.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/i-am-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217318508621611008",
  "text" : "Mr Reaves: I am NOT proud, I wish I could make a difference! http:\/\/t.co\/PggIMghA",
  "id" : 217318508621611008,
  "created_at" : "2012-06-25 18:09:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217318120770109444",
  "text" : "@BibleAlsoSays ; )",
  "id" : 217318120770109444,
  "created_at" : "2012-06-25 18:07:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 15, 29 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/zq5VpzkE",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/06\/25\/animal-intelligence-dolphins-dogs-elephants_n_1624367.html?ref=topbar",
      "display_url" : "huffingtonpost.com\/2012\/06\/25\/ani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217316163288432642",
  "text" : "well, duh!! RT @BibleAlsoSays Animal Intelligence: Dolphins, Dogs, Elephants Smarter Than Some Realize http:\/\/t.co\/zq5VpzkE",
  "id" : 217316163288432642,
  "created_at" : "2012-06-25 17:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/5wV5sqH7",
      "expanded_url" : "http:\/\/twitpic.com\/a0g7th",
      "display_url" : "twitpic.com\/a0g7th"
    } ]
  },
  "geo" : { },
  "id_str" : "217293642757455873",
  "text" : "RT @ducksandclucks: What's up, chicken butt? http:\/\/t.co\/5wV5sqH7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/5wV5sqH7",
        "expanded_url" : "http:\/\/twitpic.com\/a0g7th",
        "display_url" : "twitpic.com\/a0g7th"
      } ]
    },
    "geo" : { },
    "id_str" : "217293471583707138",
    "text" : "What's up, chicken butt? http:\/\/t.co\/5wV5sqH7",
    "id" : 217293471583707138,
    "created_at" : "2012-06-25 16:29:35 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 217293642757455873,
  "created_at" : "2012-06-25 16:30:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 50, 64 ],
      "id_str" : "54202981",
      "id" : 54202981
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 65, 80 ],
      "id_str" : "544382308",
      "id" : 544382308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Pg01mw7Y",
      "expanded_url" : "http:\/\/endtimesbookoflife.blogspot.com\/2012\/04\/proof.html",
      "display_url" : "endtimesbookoflife.blogspot.com\/2012\/04\/proof.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217293294596665344",
  "text" : "@BibleAlsoSays try this one: http:\/\/t.co\/Pg01mw7Y @ChristReturns @gospelguidance @retiredfreeman",
  "id" : 217293294596665344,
  "created_at" : "2012-06-25 16:28:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mondaygiveaway",
      "indices" : [ 25, 40 ]
    }, {
      "text" : "summerreads",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217283665686827009",
  "text" : "RT @DuttonBooks: Today's #Mondaygiveaway will make an excellent addition to your #summerreads pile: a new thriller by bestseller Stephen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mondaygiveaway",
        "indices" : [ 8, 23 ]
      }, {
        "text" : "summerreads",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217282281205800960",
    "text" : "Today's #Mondaygiveaway will make an excellent addition to your #summerreads pile: a new thriller by bestseller Stephen White. 3:30pm EST.",
    "id" : 217282281205800960,
    "created_at" : "2012-06-25 15:45:07 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 217283665686827009,
  "created_at" : "2012-06-25 15:50:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Patrick Harris",
      "screen_name" : "ActuallyNPH",
      "indices" : [ 3, 15 ],
      "id_str" : "90420314",
      "id" : 90420314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/B4UYjnHL",
      "expanded_url" : "http:\/\/tinyurl.com\/7mefogs",
      "display_url" : "tinyurl.com\/7mefogs"
    } ]
  },
  "geo" : { },
  "id_str" : "217282978324299777",
  "text" : "RT @ActuallyNPH: Just saw a most creative and inspiring music video. Love it! Gotta watch:  http:\/\/t.co\/B4UYjnHL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/B4UYjnHL",
        "expanded_url" : "http:\/\/tinyurl.com\/7mefogs",
        "display_url" : "tinyurl.com\/7mefogs"
      } ]
    },
    "geo" : { },
    "id_str" : "215668214305275905",
    "text" : "Just saw a most creative and inspiring music video. Love it! Gotta watch:  http:\/\/t.co\/B4UYjnHL",
    "id" : 215668214305275905,
    "created_at" : "2012-06-21 04:51:23 +0000",
    "user" : {
      "name" : "Neil Patrick Harris",
      "screen_name" : "ActuallyNPH",
      "protected" : false,
      "id_str" : "90420314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794749304003039232\/I1wn8Awo_normal.jpg",
      "id" : 90420314,
      "verified" : true
    }
  },
  "id" : 217282978324299777,
  "created_at" : "2012-06-25 15:47:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 3, 13 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217282116407406593",
  "text" : "RT @ScottBaio: Woke up to my kid singing \"Nationwide is on your side\" over &amp; over.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217278471745970177",
    "text" : "Woke up to my kid singing \"Nationwide is on your side\" over &amp; over.",
    "id" : 217278471745970177,
    "created_at" : "2012-06-25 15:29:59 +0000",
    "user" : {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "protected" : false,
      "id_str" : "82447359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742477919801335816\/O6okGPN6_normal.jpg",
      "id" : 82447359,
      "verified" : true
    }
  },
  "id" : 217282116407406593,
  "created_at" : "2012-06-25 15:44:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/wY7MnvbM",
      "expanded_url" : "http:\/\/buff.ly\/Q3ikm1",
      "display_url" : "buff.ly\/Q3ikm1"
    } ]
  },
  "geo" : { },
  "id_str" : "217281747484803073",
  "text" : "RT @rachelheldevans: NEW POST: Is the Bible, like Christ, both human and divine? http:\/\/t.co\/wY7MnvbM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/wY7MnvbM",
        "expanded_url" : "http:\/\/buff.ly\/Q3ikm1",
        "display_url" : "buff.ly\/Q3ikm1"
      } ]
    },
    "geo" : { },
    "id_str" : "217279577876201475",
    "text" : "NEW POST: Is the Bible, like Christ, both human and divine? http:\/\/t.co\/wY7MnvbM",
    "id" : 217279577876201475,
    "created_at" : "2012-06-25 15:34:22 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 217281747484803073,
  "created_at" : "2012-06-25 15:43:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217280855574454273",
  "text" : "RT @ShipsofSong: In the kingdom of Consciousness there is only joy, peace, harmony and balance, and oh, yes, love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217275809788997633",
    "text" : "In the kingdom of Consciousness there is only joy, peace, harmony and balance, and oh, yes, love.",
    "id" : 217275809788997633,
    "created_at" : "2012-06-25 15:19:24 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 217280855574454273,
  "created_at" : "2012-06-25 15:39:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "indices" : [ 3, 11 ],
      "id_str" : "124176955",
      "id" : 124176955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217275523582275584",
  "text" : "RT @G5games: FREE for one day only - Paranormal Agency for Kindle Fire! Get involved into this eerie Hidden Object game! Play FREE! http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/yoMnB557",
        "expanded_url" : "http:\/\/www.amazon.com\/gp\/mas\/dl\/android?p=com.g5e.paranormal.amzn.full",
        "display_url" : "amazon.com\/gp\/mas\/dl\/andr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217200226937741312",
    "text" : "FREE for one day only - Paranormal Agency for Kindle Fire! Get involved into this eerie Hidden Object game! Play FREE! http:\/\/t.co\/yoMnB557",
    "id" : 217200226937741312,
    "created_at" : "2012-06-25 10:19:04 +0000",
    "user" : {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "protected" : false,
      "id_str" : "124176955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554687863338438656\/TlbHHhe4_normal.png",
      "id" : 124176955,
      "verified" : false
    }
  },
  "id" : 217275523582275584,
  "created_at" : "2012-06-25 15:18:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217274121753591810",
  "text" : "RT @DwayneReaves: Have you ever been nervous? Scared? I am both of those along with angry also. I just need on freaking break in life!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217021446386487297",
    "text" : "Have you ever been nervous? Scared? I am both of those along with angry also. I just need on freaking break in life!",
    "id" : 217021446386487297,
    "created_at" : "2012-06-24 22:28:39 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 217274121753591810,
  "created_at" : "2012-06-25 15:12:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217274101109235713",
  "text" : "RT @DwayneReaves: It doesn't matter who the next President is going to be either, what happens a year from now, two years from now isn't ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217020921737773056",
    "text" : "It doesn't matter who the next President is going to be either, what happens a year from now, two years from now isn't going to stop the NOW",
    "id" : 217020921737773056,
    "created_at" : "2012-06-24 22:26:34 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 217274101109235713,
  "created_at" : "2012-06-25 15:12:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217274044104454144",
  "text" : "RT @DwayneReaves: Everyone has their own expert opinion about my life but that opinion doesn't change a damn thing about my situation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217020740548046848",
    "text" : "Everyone has their own expert opinion about my life but that opinion doesn't change a damn thing about my situation.",
    "id" : 217020740548046848,
    "created_at" : "2012-06-24 22:25:51 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 217274044104454144,
  "created_at" : "2012-06-25 15:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217274000475291648",
  "text" : "RT @DwayneReaves: Most people seem to look at me in a way that I can't understand anymore. I have no idea what people think I am suppose ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217020602576408577",
    "text" : "Most people seem to look at me in a way that I can't understand anymore. I have no idea what people think I am suppose to do.",
    "id" : 217020602576408577,
    "created_at" : "2012-06-24 22:25:18 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 217274000475291648,
  "created_at" : "2012-06-25 15:12:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217273958041518081",
  "text" : "RT @DwayneReaves: I don't want to die, I love living! But I am totally sick of living the way I am living. I don't want to do it anymore.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217020420094824448",
    "text" : "I don't want to die, I love living! But I am totally sick of living the way I am living. I don't want to do it anymore.",
    "id" : 217020420094824448,
    "created_at" : "2012-06-24 22:24:34 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 217273958041518081,
  "created_at" : "2012-06-25 15:12:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/lArWLUjT",
      "expanded_url" : "http:\/\/nyti.ms\/LMfNOm",
      "display_url" : "nyti.ms\/LMfNOm"
    } ]
  },
  "geo" : { },
  "id_str" : "217271123254054912",
  "text" : "RT @aliceinthewater: How My View on Gay Marriage Changed.\nhttp:\/\/t.co\/lArWLUjT #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 58, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/lArWLUjT",
        "expanded_url" : "http:\/\/nyti.ms\/LMfNOm",
        "display_url" : "nyti.ms\/LMfNOm"
      } ]
    },
    "geo" : { },
    "id_str" : "217269222844276736",
    "text" : "How My View on Gay Marriage Changed.\nhttp:\/\/t.co\/lArWLUjT #lam",
    "id" : 217269222844276736,
    "created_at" : "2012-06-25 14:53:14 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 217271123254054912,
  "created_at" : "2012-06-25 15:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217269683508879361",
  "text" : "RT @TrishScott: I think a twitter re-union with people we've never met face to face would be an OUTSTANDING event.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217265821779636226",
    "text" : "I think a twitter re-union with people we've never met face to face would be an OUTSTANDING event.",
    "id" : 217265821779636226,
    "created_at" : "2012-06-25 14:39:43 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 217269683508879361,
  "created_at" : "2012-06-25 14:55:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica La Porta",
      "screen_name" : "momilp",
      "indices" : [ 3, 10 ],
      "id_str" : "228291048",
      "id" : 228291048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slavery",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "matriarch",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/GTdwlZ6E",
      "expanded_url" : "http:\/\/bit.ly\/monica_thepriest",
      "display_url" : "bit.ly\/monica_theprie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217268346041794560",
  "text" : "RT @momilp: What if love between a woman and a man was considered a sin? Find out in The Priest http:\/\/t.co\/GTdwlZ6E #slavery #matriarch ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "slavery",
        "indices" : [ 105, 113 ]
      }, {
        "text" : "matriarch",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "dystopian",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/GTdwlZ6E",
        "expanded_url" : "http:\/\/bit.ly\/monica_thepriest",
        "display_url" : "bit.ly\/monica_theprie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "215870133095251969",
    "text" : "What if love between a woman and a man was considered a sin? Find out in The Priest http:\/\/t.co\/GTdwlZ6E #slavery #matriarch #dystopian",
    "id" : 215870133095251969,
    "created_at" : "2012-06-21 18:13:45 +0000",
    "user" : {
      "name" : "Monica La Porta",
      "screen_name" : "momilp",
      "protected" : false,
      "id_str" : "228291048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1853528775\/Monica_contrasto_per_twitter_normal.jpg",
      "id" : 228291048,
      "verified" : false
    }
  },
  "id" : 217268346041794560,
  "created_at" : "2012-06-25 14:49:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merritt Bookstore",
      "screen_name" : "MerrittBooks",
      "indices" : [ 3, 16 ],
      "id_str" : "156659744",
      "id" : 156659744
    }, {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 96, 112 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/6bhNrIVL",
      "expanded_url" : "https:\/\/www.facebook.com\/events\/406828816030758\/",
      "display_url" : "facebook.com\/events\/4068288\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "217262701620109312",
  "geo" : { },
  "id_str" : "217267780829974528",
  "in_reply_to_user_id" : 156659744,
  "text" : "RT @MerrittBooks Get ready to FIND WALDO IN MILLBROOK, starting July 1st! https:\/\/t.co\/6bhNrIVL @TheHudsonValley",
  "id" : 217267780829974528,
  "in_reply_to_status_id" : 217262701620109312,
  "created_at" : "2012-06-25 14:47:30 +0000",
  "in_reply_to_screen_name" : "MerrittBooks",
  "in_reply_to_user_id_str" : "156659744",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/JnILs4fw",
      "expanded_url" : "http:\/\/lukeromyn.com\/blog\/2012\/06\/15\/the-tragic-loss-of-a-smile\/",
      "display_url" : "lukeromyn.com\/blog\/2012\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217265662475771904",
  "text" : "The Tragic Loss of a Smile http:\/\/t.co\/JnILs4fw",
  "id" : 217265662475771904,
  "created_at" : "2012-06-25 14:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Notebook",
      "screen_name" : "Notebook",
      "indices" : [ 3, 12 ],
      "id_str" : "233430873",
      "id" : 233430873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217264111543783424",
  "text" : "RT @Notebook: The only person you should try to be better than, is the person you were yesterday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217239016867770368",
    "text" : "The only person you should try to be better than, is the person you were yesterday.",
    "id" : 217239016867770368,
    "created_at" : "2012-06-25 12:53:12 +0000",
    "user" : {
      "name" : "The Notebook",
      "screen_name" : "Notebook",
      "protected" : false,
      "id_str" : "233430873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493162440176054273\/rvrJdREI_normal.jpeg",
      "id" : 233430873,
      "verified" : true
    }
  },
  "id" : 217264111543783424,
  "created_at" : "2012-06-25 14:32:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217066603043487744",
  "text" : "@BibleAlsoSays god knows what this drug has done to me.. Bleh.",
  "id" : 217066603043487744,
  "created_at" : "2012-06-25 01:28:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/DOfEt0Cw",
      "expanded_url" : "http:\/\/parkstepp.tumblr.com\/post\/25812785516\/haumealand-r-i-p-lonesome-george-lonesome",
      "display_url" : "parkstepp.tumblr.com\/post\/258127855\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217035185600991233",
  "text" : "RT @parkstepp: Lonesome George has died--  http:\/\/t.co\/DOfEt0Cw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/DOfEt0Cw",
        "expanded_url" : "http:\/\/parkstepp.tumblr.com\/post\/25812785516\/haumealand-r-i-p-lonesome-george-lonesome",
        "display_url" : "parkstepp.tumblr.com\/post\/258127855\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 36.8869301, -86.02591061 ]
    },
    "id_str" : "217034407859597313",
    "text" : "Lonesome George has died--  http:\/\/t.co\/DOfEt0Cw",
    "id" : 217034407859597313,
    "created_at" : "2012-06-24 23:20:09 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 217035185600991233,
  "created_at" : "2012-06-24 23:23:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/US06ZTC2",
      "expanded_url" : "http:\/\/www.abfabgab.com",
      "display_url" : "abfabgab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "217031470060011520",
  "text" : "Have you seen my blog lately? http:\/\/t.co\/US06ZTC2 - I need to relax what I post about and post more often..lol",
  "id" : 217031470060011520,
  "created_at" : "2012-06-24 23:08:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Bereczky",
      "screen_name" : "tessbereczky",
      "indices" : [ 0, 13 ],
      "id_str" : "25448196",
      "id" : 25448196
    }, {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 47, 61 ],
      "id_str" : "54202981",
      "id" : 54202981
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 62, 76 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216978925744697346",
  "geo" : { },
  "id_str" : "216995889695297536",
  "in_reply_to_user_id" : 25448196,
  "text" : "@tessbereczky been on effexor 10+ yrs ((hugs)) @christreturns @biblealsosays",
  "id" : 216995889695297536,
  "in_reply_to_status_id" : 216978925744697346,
  "created_at" : "2012-06-24 20:47:06 +0000",
  "in_reply_to_screen_name" : "tessbereczky",
  "in_reply_to_user_id_str" : "25448196",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Wesley Williams",
      "screen_name" : "WesleyGW",
      "indices" : [ 79, 88 ],
      "id_str" : "18194655",
      "id" : 18194655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216977372224831488",
  "geo" : { },
  "id_str" : "216979510044803074",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny  you're so awesome. that's why I follow you! ((hugs)) @Mscalli0pe @wesleygw",
  "id" : 216979510044803074,
  "in_reply_to_status_id" : 216977372224831488,
  "created_at" : "2012-06-24 19:42:01 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "autism",
      "indices" : [ 93, 100 ]
    }, {
      "text" : "aspie",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "add",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "adhd",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/WaX48NPl",
      "expanded_url" : "http:\/\/bit.ly\/MhQnrn",
      "display_url" : "bit.ly\/MhQnrn"
    } ]
  },
  "geo" : { },
  "id_str" : "216979027083280386",
  "text" : "If I'm not autistic, what's wrong with me? Part 1 (of 2) - Derek's blog http:\/\/t.co\/WaX48NPl #autism #aspie #add #adhd",
  "id" : 216979027083280386,
  "created_at" : "2012-06-24 19:40:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adhd",
      "indices" : [ 70, 75 ]
    }, {
      "text" : "aspergers",
      "indices" : [ 76, 86 ]
    }, {
      "text" : "autism",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "suicide",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "ritalin",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/JjLFx1Xj",
      "expanded_url" : "http:\/\/derekthomas005.magix.net\/blog\/dereks-blog\/archives\/592-If-Im-not-autistic,-whats-wrong-with-me-Part-II.html",
      "display_url" : "derekthomas005.magix.net\/blog\/dereks-bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216977522611597314",
  "text" : "RT @derekrootboy: Why doctors have let me down:  http:\/\/t.co\/JjLFx1Xj #adhd #aspergers #autism #suicide #ritalin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "adhd",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "aspergers",
        "indices" : [ 58, 68 ]
      }, {
        "text" : "autism",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "suicide",
        "indices" : [ 77, 85 ]
      }, {
        "text" : "ritalin",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/JjLFx1Xj",
        "expanded_url" : "http:\/\/derekthomas005.magix.net\/blog\/dereks-blog\/archives\/592-If-Im-not-autistic,-whats-wrong-with-me-Part-II.html",
        "display_url" : "derekthomas005.magix.net\/blog\/dereks-bl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "216977057257766913",
    "text" : "Why doctors have let me down:  http:\/\/t.co\/JjLFx1Xj #adhd #aspergers #autism #suicide #ritalin",
    "id" : 216977057257766913,
    "created_at" : "2012-06-24 19:32:16 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 216977522611597314,
  "created_at" : "2012-06-24 19:34:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 0, 14 ],
      "id_str" : "54202981",
      "id" : 54202981
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 80, 94 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216975294165286912",
  "geo" : { },
  "id_str" : "216976483804131328",
  "in_reply_to_user_id" : 54202981,
  "text" : "@ChristReturns absolutely! I believe in the impossible (ergo my \"insanity\" lol) @biblealsosays",
  "id" : 216976483804131328,
  "in_reply_to_status_id" : 216975294165286912,
  "created_at" : "2012-06-24 19:29:59 +0000",
  "in_reply_to_screen_name" : "ChristReturns",
  "in_reply_to_user_id_str" : "54202981",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Wesley Williams",
      "screen_name" : "WesleyGW",
      "indices" : [ 44, 53 ],
      "id_str" : "18194655",
      "id" : 18194655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216975455033634817",
  "geo" : { },
  "id_str" : "216976113853939712",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny thank you VG!! : ) @Mscalli0pe @wesleyGW",
  "id" : 216976113853939712,
  "in_reply_to_status_id" : 216975455033634817,
  "created_at" : "2012-06-24 19:28:31 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Tess Bereczky",
      "screen_name" : "tessbereczky",
      "indices" : [ 52, 65 ],
      "id_str" : "25448196",
      "id" : 25448196
    }, {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 66, 80 ],
      "id_str" : "54202981",
      "id" : 54202981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216975861524606977",
  "text" : "@BibleAlsoSays yeah, I have many special areas..lol @tessbereczky @christreturns",
  "id" : 216975861524606977,
  "created_at" : "2012-06-24 19:27:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 0, 9 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216974348261654528",
  "geo" : { },
  "id_str" : "216975740074340352",
  "in_reply_to_user_id" : 215045056,
  "text" : "@Pandeism lol.. love it!",
  "id" : 216975740074340352,
  "in_reply_to_status_id" : 216974348261654528,
  "created_at" : "2012-06-24 19:27:02 +0000",
  "in_reply_to_screen_name" : "Pandeism",
  "in_reply_to_user_id_str" : "215045056",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Bereczky",
      "screen_name" : "tessbereczky",
      "indices" : [ 0, 13 ],
      "id_str" : "25448196",
      "id" : 25448196
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 73, 87 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 88, 102 ],
      "id_str" : "54202981",
      "id" : 54202981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216943745168453635",
  "geo" : { },
  "id_str" : "216971569480732673",
  "in_reply_to_user_id" : 25448196,
  "text" : "@tessbereczky well, he sides w sane ppl.. im not sane.. so i was curious @biblealsosays @christreturns",
  "id" : 216971569480732673,
  "in_reply_to_status_id" : 216943745168453635,
  "created_at" : "2012-06-24 19:10:27 +0000",
  "in_reply_to_screen_name" : "tessbereczky",
  "in_reply_to_user_id_str" : "25448196",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bassey Official",
      "screen_name" : "basseyworldlive",
      "indices" : [ 3, 19 ],
      "id_str" : "718011212",
      "id" : 718011212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216941192141742080",
  "text" : "RT @BasseyworldLive: I'm reading comments and people are suggesting you sell your cell phone to make ends meet. Um... it's not 1983.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216927809615048705",
    "text" : "I'm reading comments and people are suggesting you sell your cell phone to make ends meet. Um... it's not 1983.",
    "id" : 216927809615048705,
    "created_at" : "2012-06-24 16:16:34 +0000",
    "user" : {
      "name" : "Bassey",
      "screen_name" : "Basseyworld",
      "protected" : false,
      "id_str" : "135684302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759960857052901376\/-wnoQuuX_normal.jpg",
      "id" : 135684302,
      "verified" : true
    }
  },
  "id" : 216941192141742080,
  "created_at" : "2012-06-24 17:09:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bassey Official",
      "screen_name" : "basseyworldlive",
      "indices" : [ 3, 19 ],
      "id_str" : "718011212",
      "id" : 718011212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216941169043714048",
  "text" : "RT @BasseyworldLive: I really dont' understand this notion that people on public assistance of any kind shouldn't be allowed to own anyt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216927230650097666",
    "text" : "I really dont' understand this notion that people on public assistance of any kind shouldn't be allowed to own anything \"nice\".",
    "id" : 216927230650097666,
    "created_at" : "2012-06-24 16:14:16 +0000",
    "user" : {
      "name" : "Bassey",
      "screen_name" : "Basseyworld",
      "protected" : false,
      "id_str" : "135684302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759960857052901376\/-wnoQuuX_normal.jpg",
      "id" : 135684302,
      "verified" : true
    }
  },
  "id" : 216941169043714048,
  "created_at" : "2012-06-24 17:09:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216937044981723137",
  "geo" : { },
  "id_str" : "216940933978136577",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott cool..lol",
  "id" : 216940933978136577,
  "in_reply_to_status_id" : 216937044981723137,
  "created_at" : "2012-06-24 17:08:43 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Rogen",
      "screen_name" : "Seth_Rogen_",
      "indices" : [ 3, 15 ],
      "id_str" : "1215484860",
      "id" : 1215484860
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 97, 111 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216923041941303298",
  "geo" : { },
  "id_str" : "216926849383661570",
  "in_reply_to_user_id" : 509283913,
  "text" : "RT @Seth_Rogen_  I look at people sometimes &amp; think \u2018really, that\u2019s the sperm that won? (for @BibleAlsoSays .. LOL)",
  "id" : 216926849383661570,
  "in_reply_to_status_id" : 216923041941303298,
  "created_at" : "2012-06-24 16:12:45 +0000",
  "in_reply_to_screen_name" : "CauseWeAreGeeks",
  "in_reply_to_user_id_str" : "509283913",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 60, 74 ],
      "id_str" : "54202981",
      "id" : 54202981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216926475104944129",
  "text" : "@BibleAlsoSays hmm.. interesting.. like what circumstances? @ChristReturns",
  "id" : 216926475104944129,
  "created_at" : "2012-06-24 16:11:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "James David Selby",
      "screen_name" : "ChristReturns",
      "indices" : [ 85, 99 ],
      "id_str" : "54202981",
      "id" : 54202981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216924919408230400",
  "text" : "@BibleAlsoSays hey BAS, if you and I in boat, I fall out, would you help me back in? @ChristReturns",
  "id" : 216924919408230400,
  "created_at" : "2012-06-24 16:05:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 128 ],
      "url" : "https:\/\/t.co\/8znAZTN6",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/115871435203005258364\/posts\/1ymYaVxNB1A",
      "display_url" : "plus.google.com\/u\/0\/1158714352\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216923644788604929",
  "text" : "This is not a story about a duck. Or a goose. It's about a small miraculous event with a boy named Robbie. https:\/\/t.co\/8znAZTN6",
  "id" : 216923644788604929,
  "created_at" : "2012-06-24 16:00:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "Zite",
      "screen_name" : "Zite",
      "indices" : [ 78, 83 ],
      "id_str" : "110558385",
      "id" : 110558385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/GZVN93w2",
      "expanded_url" : "http:\/\/zite.to\/MbPTTI",
      "display_url" : "zite.to\/MbPTTI"
    } ]
  },
  "geo" : { },
  "id_str" : "216919567300173824",
  "text" : "RT @DawnFine: The 9 weirdest animal penises on Earth http:\/\/t.co\/GZVN93w2 via @zite",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/zite-personalized-magazine\/id419752338?mt=8&uo=4\" rel=\"nofollow\"\u003EZite Personalized Magazine\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zite",
        "screen_name" : "Zite",
        "indices" : [ 64, 69 ],
        "id_str" : "110558385",
        "id" : 110558385
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/GZVN93w2",
        "expanded_url" : "http:\/\/zite.to\/MbPTTI",
        "display_url" : "zite.to\/MbPTTI"
      } ]
    },
    "geo" : { },
    "id_str" : "216914172477325312",
    "text" : "The 9 weirdest animal penises on Earth http:\/\/t.co\/GZVN93w2 via @zite",
    "id" : 216914172477325312,
    "created_at" : "2012-06-24 15:22:23 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 216919567300173824,
  "created_at" : "2012-06-24 15:43:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/7vzYEJOK",
      "expanded_url" : "http:\/\/bit.ly\/birdapp",
      "display_url" : "bit.ly\/birdapp"
    } ]
  },
  "geo" : { },
  "id_str" : "216918410334973953",
  "text" : "RT @petersonguides: Get it while it's hot! Peterson Birds for iPhone &amp; iPad on sale for 99\u00A2 (reg. $14.99) http:\/\/t.co\/7vzYEJOK #bird ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 111, 117 ]
      }, {
        "text" : "nature",
        "indices" : [ 118, 125 ]
      }, {
        "text" : "gardening",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/7vzYEJOK",
        "expanded_url" : "http:\/\/bit.ly\/birdapp",
        "display_url" : "bit.ly\/birdapp"
      } ]
    },
    "geo" : { },
    "id_str" : "216914898947547136",
    "text" : "Get it while it's hot! Peterson Birds for iPhone &amp; iPad on sale for 99\u00A2 (reg. $14.99) http:\/\/t.co\/7vzYEJOK #birds #nature #gardening",
    "id" : 216914898947547136,
    "created_at" : "2012-06-24 15:25:16 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 216918410334973953,
  "created_at" : "2012-06-24 15:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Steven B",
      "screen_name" : "_isolar_",
      "indices" : [ 24, 33 ],
      "id_str" : "124166373",
      "id" : 124166373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216908880297463808",
  "text" : "RT @TrishScott: Wow! RT @_isolar_: I can see two swans through the reeds. They are dancing. Spinning in the water. Together dancing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven B",
        "screen_name" : "_isolar_",
        "indices" : [ 8, 17 ],
        "id_str" : "124166373",
        "id" : 124166373
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216908271242584064",
    "text" : "Wow! RT @_isolar_: I can see two swans through the reeds. They are dancing. Spinning in the water. Together dancing.",
    "id" : 216908271242584064,
    "created_at" : "2012-06-24 14:58:56 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 216908880297463808,
  "created_at" : "2012-06-24 15:01:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216897831359873024",
  "text" : "ugh. coffee not right this am. must be regular, not vanilla...",
  "id" : 216897831359873024,
  "created_at" : "2012-06-24 14:17:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216894861578739714",
  "text" : ". @Skeptical_Lady sheep get such a bad rap.. so much nicer than goats who are all bouncy. sheep are calm. i like calm.",
  "id" : 216894861578739714,
  "created_at" : "2012-06-24 14:05:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SkepticalOfSkeptics",
      "screen_name" : "SkepticalOfYou",
      "indices" : [ 3, 18 ],
      "id_str" : "565530890",
      "id" : 565530890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216894215030968322",
  "text" : "RT @SkepticalOfYou: Sometimes when God closes a door, He blows out a wall.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216893808900714496",
    "text" : "Sometimes when God closes a door, He blows out a wall.",
    "id" : 216893808900714496,
    "created_at" : "2012-06-24 14:01:28 +0000",
    "user" : {
      "name" : "SkepticalOfSkeptics",
      "screen_name" : "SkepticalOfYou",
      "protected" : false,
      "id_str" : "565530890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2172953072\/huh_normal.jpg",
      "id" : 565530890,
      "verified" : false
    }
  },
  "id" : 216894215030968322,
  "created_at" : "2012-06-24 14:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/O4T3LdUG",
      "expanded_url" : "http:\/\/via.me\/-2bviv0u",
      "display_url" : "via.me\/-2bviv0u"
    } ]
  },
  "geo" : { },
  "id_str" : "216713352427216896",
  "text" : "My stray kitty http:\/\/t.co\/O4T3LdUG",
  "id" : 216713352427216896,
  "created_at" : "2012-06-24 02:04:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Resig",
      "screen_name" : "megresig",
      "indices" : [ 3, 12 ],
      "id_str" : "108802744",
      "id" : 108802744
    }, {
      "name" : "Paul Siebenthal",
      "screen_name" : "aspienaut",
      "indices" : [ 27, 37 ],
      "id_str" : "335896144",
      "id" : 335896144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216593570306605056",
  "text" : "RT @megresig: Woo! YES! RT @Aspienaut: Just because I am Pro-Aspie, Pro-autism, Pro-the Differently Wired doesn't mean I'm not Pro-NT to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Siebenthal",
        "screen_name" : "aspienaut",
        "indices" : [ 13, 23 ],
        "id_str" : "335896144",
        "id" : 335896144
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216584633716977665",
    "text" : "Woo! YES! RT @Aspienaut: Just because I am Pro-Aspie, Pro-autism, Pro-the Differently Wired doesn't mean I'm not Pro-NT too. We all ROCK!!!!",
    "id" : 216584633716977665,
    "created_at" : "2012-06-23 17:32:55 +0000",
    "user" : {
      "name" : "Megan Resig",
      "screen_name" : "megresig",
      "protected" : false,
      "id_str" : "108802744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720071220658614272\/ub4XzvuJ_normal.jpg",
      "id" : 108802744,
      "verified" : false
    }
  },
  "id" : 216593570306605056,
  "created_at" : "2012-06-23 18:08:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216582580408033280",
  "geo" : { },
  "id_str" : "216585092431224832",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX I love how you think..LOL. Rock on, Miss Candy! : )",
  "id" : 216585092431224832,
  "in_reply_to_status_id" : 216582580408033280,
  "created_at" : "2012-06-23 17:34:44 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/q6vvwoZe",
      "expanded_url" : "http:\/\/via.me\/-2afc6am",
      "display_url" : "via.me\/-2afc6am"
    } ]
  },
  "geo" : { },
  "id_str" : "216331699234156544",
  "text" : "Macaroni &amp; cheese on the menu this evening http:\/\/t.co\/q6vvwoZe",
  "id" : 216331699234156544,
  "created_at" : "2012-06-23 00:47:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 0, 16 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216317290604527616",
  "geo" : { },
  "id_str" : "216319818113093633",
  "in_reply_to_user_id" : 30077179,
  "text" : "@simonwoodwrites oh no.. hope your pup feels better soon!",
  "id" : 216319818113093633,
  "in_reply_to_status_id" : 216317290604527616,
  "created_at" : "2012-06-23 00:00:38 +0000",
  "in_reply_to_screen_name" : "simonwoodwrites",
  "in_reply_to_user_id_str" : "30077179",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216319451832913920",
  "text" : "ooohhh.. I have 1111 followers.. isn't that, like, a magical number?",
  "id" : 216319451832913920,
  "created_at" : "2012-06-22 23:59:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "indices" : [ 68, 73 ],
      "id_str" : "18957524",
      "id" : 18957524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216255906080497664",
  "text" : "just watched fun movie: Cirque du Freak: The Vampire's Assistant on @Syfy",
  "id" : 216255906080497664,
  "created_at" : "2012-06-22 19:46:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Uetricht",
      "screen_name" : "micahuetricht",
      "indices" : [ 3, 17 ],
      "id_str" : "195631270",
      "id" : 195631270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/5sAI5vaZ",
      "expanded_url" : "http:\/\/www.republicreport.org\/2012\/how-big-corporations-cash-in-on-food-assistance-programs\/",
      "display_url" : "republicreport.org\/2012\/how-big-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216240974245007361",
  "text" : "RT @micahuetricht: JP Morgan makes huge amounts of money from the federal food stamps program. http:\/\/t.co\/5sAI5vaZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/5sAI5vaZ",
        "expanded_url" : "http:\/\/www.republicreport.org\/2012\/how-big-corporations-cash-in-on-food-assistance-programs\/",
        "display_url" : "republicreport.org\/2012\/how-big-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "216239658739318787",
    "text" : "JP Morgan makes huge amounts of money from the federal food stamps program. http:\/\/t.co\/5sAI5vaZ",
    "id" : 216239658739318787,
    "created_at" : "2012-06-22 18:42:06 +0000",
    "user" : {
      "name" : "Micah Uetricht",
      "screen_name" : "micahuetricht",
      "protected" : false,
      "id_str" : "195631270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723971310313840640\/TH38j7GS_normal.jpg",
      "id" : 195631270,
      "verified" : false
    }
  },
  "id" : 216240974245007361,
  "created_at" : "2012-06-22 18:47:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela",
      "screen_name" : "FiendishlyFab",
      "indices" : [ 0, 14 ],
      "id_str" : "498724504",
      "id" : 498724504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216222590665101312",
  "geo" : { },
  "id_str" : "216223777338568707",
  "in_reply_to_user_id" : 498724504,
  "text" : "@FiendishlyFab maybe put up a poll of most likely to play game: game, book, itunes app, fire app, android app... : )",
  "id" : 216223777338568707,
  "in_reply_to_status_id" : 216222590665101312,
  "created_at" : "2012-06-22 17:39:00 +0000",
  "in_reply_to_screen_name" : "FiendishlyFab",
  "in_reply_to_user_id_str" : "498724504",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WitchinWebs \u263E",
      "screen_name" : "WitchinWebs",
      "indices" : [ 3, 15 ],
      "id_str" : "33900739",
      "id" : 33900739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216222584000360448",
  "text" : "RT @WitchinWebs: Hudson Valley's very own \"Pawn Stars\" cool, get a loan, sell gold or buy jewelry, clothes &amp; all kinds of neat stuff ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/SeGx6uK3",
        "expanded_url" : "http:\/\/hvpawn.com",
        "display_url" : "hvpawn.com"
      } ]
    },
    "geo" : { },
    "id_str" : "216220451335180288",
    "text" : "Hudson Valley's very own \"Pawn Stars\" cool, get a loan, sell gold or buy jewelry, clothes &amp; all kinds of neat stuff... http:\/\/t.co\/SeGx6uK3",
    "id" : 216220451335180288,
    "created_at" : "2012-06-22 17:25:47 +0000",
    "user" : {
      "name" : "WitchinWebs \u263E",
      "screen_name" : "WitchinWebs",
      "protected" : false,
      "id_str" : "33900739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2825062281\/5af4585de71515ca828c742b1326704b_normal.jpeg",
      "id" : 33900739,
      "verified" : false
    }
  },
  "id" : 216222584000360448,
  "created_at" : "2012-06-22 17:34:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Crown",
      "screen_name" : "Sarah_Crown",
      "indices" : [ 3, 15 ],
      "id_str" : "47580953",
      "id" : 47580953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216217077143437313",
  "text" : "RT @Sarah_Crown: God bless JK Rowling: gladly paying taxes bc 'when my life hit rock bottom [the welf state]was there to break the fall' ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/9iZn2N2C",
        "expanded_url" : "http:\/\/ind.pn\/MJybFE",
        "display_url" : "ind.pn\/MJybFE"
      } ]
    },
    "geo" : { },
    "id_str" : "216156846250147840",
    "text" : "God bless JK Rowling: gladly paying taxes bc 'when my life hit rock bottom [the welf state]was there to break the fall' http:\/\/t.co\/9iZn2N2C",
    "id" : 216156846250147840,
    "created_at" : "2012-06-22 13:13:02 +0000",
    "user" : {
      "name" : "Sarah Crown",
      "screen_name" : "Sarah_Crown",
      "protected" : false,
      "id_str" : "47580953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/270986151\/sarah_crown_normal.jpg",
      "id" : 47580953,
      "verified" : false
    }
  },
  "id" : 216217077143437313,
  "created_at" : "2012-06-22 17:12:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No Kill Nation, Inc.",
      "screen_name" : "NoKillNation",
      "indices" : [ 3, 16 ],
      "id_str" : "90349161",
      "id" : 90349161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216214560720433152",
  "text" : "RT @NoKillNation: In 2010, PETA impounded 1,553 cats. They killed 1,507 and found homes for only 28. Another 9 were transferred to... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/41N2YF8M",
        "expanded_url" : "http:\/\/fb.me\/1w019MpRs",
        "display_url" : "fb.me\/1w019MpRs"
      } ]
    },
    "geo" : { },
    "id_str" : "216211527529807874",
    "text" : "In 2010, PETA impounded 1,553 cats. They killed 1,507 and found homes for only 28. Another 9 were transferred to... http:\/\/t.co\/41N2YF8M",
    "id" : 216211527529807874,
    "created_at" : "2012-06-22 16:50:19 +0000",
    "user" : {
      "name" : "No Kill Nation, Inc.",
      "screen_name" : "NoKillNation",
      "protected" : false,
      "id_str" : "90349161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2388560123\/oggbcidl6ub44evxv9b8_normal.jpeg",
      "id" : 90349161,
      "verified" : false
    }
  },
  "id" : 216214560720433152,
  "created_at" : "2012-06-22 17:02:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Kathan",
      "screen_name" : "StephanieKathan",
      "indices" : [ 3, 19 ],
      "id_str" : "42990074",
      "id" : 42990074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216212334383861760",
  "text" : "RT @StephanieKathan: If you're life is sucking right now..... ONLY YOU can make the decision to change it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216211825098883073",
    "text" : "If you're life is sucking right now..... ONLY YOU can make the decision to change it.",
    "id" : 216211825098883073,
    "created_at" : "2012-06-22 16:51:30 +0000",
    "user" : {
      "name" : "Stephanie Kathan",
      "screen_name" : "StephanieKathan",
      "protected" : false,
      "id_str" : "42990074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779137503206998016\/P3KDquOf_normal.jpg",
      "id" : 42990074,
      "verified" : false
    }
  },
  "id" : 216212334383861760,
  "created_at" : "2012-06-22 16:53:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 3, 14 ],
      "id_str" : "94608663",
      "id" : 94608663
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 16, 27 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/rO1OSqGD",
      "expanded_url" : "http:\/\/www.facebook.com\/photo.php?fbid=10150875720601947&set=a.209276626946.133097.190018231946&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216205286019575808",
  "text" : "RT @MEDGESTORE: @moosebegab my bad! Here it is: http:\/\/t.co\/rO1OSqGD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/rO1OSqGD",
        "expanded_url" : "http:\/\/www.facebook.com\/photo.php?fbid=10150875720601947&set=a.209276626946.133097.190018231946&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "216204299070476290",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab my bad! Here it is: http:\/\/t.co\/rO1OSqGD",
    "id" : 216204299070476290,
    "created_at" : "2012-06-22 16:21:36 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "protected" : false,
      "id_str" : "94608663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684834758027681792\/AxmlNGOl_normal.jpg",
      "id" : 94608663,
      "verified" : false
    }
  },
  "id" : 216205286019575808,
  "created_at" : "2012-06-22 16:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 0, 11 ],
      "id_str" : "94608663",
      "id" : 94608663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216200201176756224",
  "geo" : { },
  "id_str" : "216203208043921408",
  "in_reply_to_user_id" : 94608663,
  "text" : "@MEDGESTORE was there a link or pic attached? did not show up... regardless, im excited you'll be offering touch covers : )",
  "id" : 216203208043921408,
  "in_reply_to_status_id" : 216200201176756224,
  "created_at" : "2012-06-22 16:17:16 +0000",
  "in_reply_to_screen_name" : "MEDGESTORE",
  "in_reply_to_user_id_str" : "94608663",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 34, 45 ],
      "id_str" : "94608663",
      "id" : 94608663
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipodtouch",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216200201176756224",
  "geo" : { },
  "id_str" : "216201257306701824",
  "in_reply_to_user_id" : 94608663,
  "text" : "yay! cant wait! : ) #ipodtouch RT @MEDGESTORE they are coming soon! Check it out:",
  "id" : 216201257306701824,
  "in_reply_to_status_id" : 216200201176756224,
  "created_at" : "2012-06-22 16:09:31 +0000",
  "in_reply_to_screen_name" : "MEDGESTORE",
  "in_reply_to_user_id_str" : "94608663",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 5, 16 ],
      "id_str" : "94608663",
      "id" : 94608663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216197108301172736",
  "text" : "darn @MEDGESTORE you dont have ipod touch covers? (i have 2 of yr covers.. for my KK3 and KF.. love them!)",
  "id" : 216197108301172736,
  "created_at" : "2012-06-22 15:53:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Lemick",
      "screen_name" : "BrettTheIntern",
      "indices" : [ 3, 18 ],
      "id_str" : "15478976",
      "id" : 15478976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216195711467913216",
  "text" : "RT @BrettTheIntern: Okay, good news &amp; bad news: Bad News - I have no good news BUT Good News - I have no bad news!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216055943086088192",
    "text" : "Okay, good news &amp; bad news: Bad News - I have no good news BUT Good News - I have no bad news!",
    "id" : 216055943086088192,
    "created_at" : "2012-06-22 06:32:05 +0000",
    "user" : {
      "name" : "Brett Lemick",
      "screen_name" : "BrettTheIntern",
      "protected" : false,
      "id_str" : "15478976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769676656386510848\/pk8jIlun_normal.jpg",
      "id" : 15478976,
      "verified" : false
    }
  },
  "id" : 216195711467913216,
  "created_at" : "2012-06-22 15:47:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216193462893150208",
  "geo" : { },
  "id_str" : "216195034637279232",
  "in_reply_to_user_id" : 18538833,
  "text" : "oh @ZeitgeistGhost thx 4 reminding me of that song! need to add to my ipod! : )",
  "id" : 216195034637279232,
  "in_reply_to_status_id" : 216193462893150208,
  "created_at" : "2012-06-22 15:44:47 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216189106064080896",
  "geo" : { },
  "id_str" : "216189867732910080",
  "in_reply_to_user_id" : 419534932,
  "text" : "@Boonearang yay! i love good news! : )",
  "id" : 216189867732910080,
  "in_reply_to_status_id" : 216189106064080896,
  "created_at" : "2012-06-22 15:24:15 +0000",
  "in_reply_to_screen_name" : "JediMasterJason",
  "in_reply_to_user_id_str" : "419534932",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yorai Ben Yahudah",
      "screen_name" : "Justicecold1",
      "indices" : [ 2, 15 ],
      "id_str" : "277847029",
      "id" : 277847029
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 63, 75 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216183639757688832",
  "geo" : { },
  "id_str" : "216187539416023041",
  "in_reply_to_user_id" : 277847029,
  "text" : ". @Justicecold1 there are many points you can cross the street @ReverendSue",
  "id" : 216187539416023041,
  "in_reply_to_status_id" : 216183639757688832,
  "created_at" : "2012-06-22 15:15:00 +0000",
  "in_reply_to_screen_name" : "Justicecold1",
  "in_reply_to_user_id_str" : "277847029",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216176280771633153",
  "text" : "RT @DwayneReaves: Someone asked if I hadn't shaved because I was depressed, NO, I haven't shaved because I can't afford a razor!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215990355944931330",
    "text" : "Someone asked if I hadn't shaved because I was depressed, NO, I haven't shaved because I can't afford a razor!!",
    "id" : 215990355944931330,
    "created_at" : "2012-06-22 02:11:28 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 216176280771633153,
  "created_at" : "2012-06-22 14:30:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 35, 46 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216175757389611008",
  "text" : "RT @tommysalami: You should follow @TyrusBooks because he loves books and music so much he gives them away. He puts his money where his  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyrus Books",
        "screen_name" : "TyrusBooks",
        "indices" : [ 18, 29 ],
        "id_str" : "67336993",
        "id" : 67336993
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 129, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216173637282168834",
    "text" : "You should follow @TyrusBooks because he loves books and music so much he gives them away. He puts his money where his mouth is. #FF",
    "id" : 216173637282168834,
    "created_at" : "2012-06-22 14:19:46 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 216175757389611008,
  "created_at" : "2012-06-22 14:28:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Hardin",
      "screen_name" : "Det_JohnDrake",
      "indices" : [ 3, 17 ],
      "id_str" : "83130695",
      "id" : 83130695
    }, {
      "name" : "Detjon",
      "screen_name" : "Det_John",
      "indices" : [ 35, 44 ],
      "id_str" : "2250308808",
      "id" : 2250308808
    }, {
      "name" : "Peggy A. Edelheit",
      "screen_name" : "samanthajamison",
      "indices" : [ 73, 89 ],
      "id_str" : "329745107",
      "id" : 329745107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216175618570715136",
  "text" : "RT @Det_JohnDrake: Last day to get @Det_John-Drake 's A TIME TO LIE  and @samanthajamison 's A LETHAL TIME #FREE for your Kindle! http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Detjon",
        "screen_name" : "Det_John",
        "indices" : [ 16, 25 ],
        "id_str" : "2250308808",
        "id" : 2250308808
      }, {
        "name" : "Peggy A. Edelheit",
        "screen_name" : "samanthajamison",
        "indices" : [ 54, 70 ],
        "id_str" : "329745107",
        "id" : 329745107
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FREE",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/KXh0ZBwm",
        "expanded_url" : "http:\/\/www.dwhardin.com\/Free.html",
        "display_url" : "dwhardin.com\/Free.html"
      } ]
    },
    "geo" : { },
    "id_str" : "216174942490865664",
    "text" : "Last day to get @Det_John-Drake 's A TIME TO LIE  and @samanthajamison 's A LETHAL TIME #FREE for your Kindle! http:\/\/t.co\/KXh0ZBwm",
    "id" : 216174942490865664,
    "created_at" : "2012-06-22 14:24:57 +0000",
    "user" : {
      "name" : "Doug Hardin",
      "screen_name" : "Det_JohnDrake",
      "protected" : false,
      "id_str" : "83130695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2145825033\/twitter1_normal.jpg",
      "id" : 83130695,
      "verified" : false
    }
  },
  "id" : 216175618570715136,
  "created_at" : "2012-06-22 14:27:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/7vzYEJOK",
      "expanded_url" : "http:\/\/bit.ly\/birdapp",
      "display_url" : "bit.ly\/birdapp"
    } ]
  },
  "geo" : { },
  "id_str" : "216175573322563584",
  "text" : "RT @petersonguides: Summer Solstice Sale. Peterson Birds for iPhone and iPad now on sale for 99\u00A2 (reg. $14.99) http:\/\/t.co\/7vzYEJOK #bir ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birders",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "nature",
        "indices" : [ 121, 128 ]
      }, {
        "text" : "gardening",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/7vzYEJOK",
        "expanded_url" : "http:\/\/bit.ly\/birdapp",
        "display_url" : "bit.ly\/birdapp"
      } ]
    },
    "geo" : { },
    "id_str" : "216175023810019330",
    "text" : "Summer Solstice Sale. Peterson Birds for iPhone and iPad now on sale for 99\u00A2 (reg. $14.99) http:\/\/t.co\/7vzYEJOK #birders #nature #gardening",
    "id" : 216175023810019330,
    "created_at" : "2012-06-22 14:25:16 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 216175573322563584,
  "created_at" : "2012-06-22 14:27:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela",
      "screen_name" : "FiendishlyFab",
      "indices" : [ 32, 46 ],
      "id_str" : "498724504",
      "id" : 498724504
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "app",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216172201479639040",
  "text" : "hey word game lovers, check out @FiendishlyFab .. would make a great #app !",
  "id" : 216172201479639040,
  "created_at" : "2012-06-22 14:14:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela",
      "screen_name" : "FiendishlyFab",
      "indices" : [ 0, 14 ],
      "id_str" : "498724504",
      "id" : 498724504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216170572722352128",
  "in_reply_to_user_id" : 498724504,
  "text" : "@FiendishlyFab yes, make an app! I'd love your game on my iPod Touch (or Kindle Fire)",
  "id" : 216170572722352128,
  "created_at" : "2012-06-22 14:07:35 +0000",
  "in_reply_to_screen_name" : "FiendishlyFab",
  "in_reply_to_user_id_str" : "498724504",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215934242943807490",
  "text" : "RT @TheEntertainer: Die with NO regrets. Do what  calls you NOW, and what you must SAY NOW Or you will regret it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215933848050089984",
    "text" : "Die with NO regrets. Do what  calls you NOW, and what you must SAY NOW Or you will regret it.",
    "id" : 215933848050089984,
    "created_at" : "2012-06-21 22:26:55 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 215934242943807490,
  "created_at" : "2012-06-21 22:28:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 59, 72 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Exfwu2VG",
      "expanded_url" : "http:\/\/goo.gl\/kz07A",
      "display_url" : "goo.gl\/kz07A"
    } ]
  },
  "geo" : { },
  "id_str" : "215824564926676993",
  "text" : "RT @Matth3ous: I'm going to have a tomato now. With salt. \u201C@mental_floss: Using Sex Toys to Grow Tomatoes \u2014 http:\/\/t.co\/Exfwu2VG\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mental Floss",
        "screen_name" : "mental_floss",
        "indices" : [ 44, 57 ],
        "id_str" : "20065936",
        "id" : 20065936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Exfwu2VG",
        "expanded_url" : "http:\/\/goo.gl\/kz07A",
        "display_url" : "goo.gl\/kz07A"
      } ]
    },
    "geo" : { },
    "id_str" : "215820590194507777",
    "text" : "I'm going to have a tomato now. With salt. \u201C@mental_floss: Using Sex Toys to Grow Tomatoes \u2014 http:\/\/t.co\/Exfwu2VG\u201D",
    "id" : 215820590194507777,
    "created_at" : "2012-06-21 14:56:53 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 215824564926676993,
  "created_at" : "2012-06-21 15:12:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215797983474749441",
  "text" : "@deucehartley you are living the life! bless you for sharing. bad news gets old real quick. : )",
  "id" : 215797983474749441,
  "created_at" : "2012-06-21 13:27:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215795010120060929",
  "text" : "RT @DeepakChopra: Violent adults are frequently the victims of child abuse. To prevent violence we must love all children unconditionally.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215791145920364544",
    "text" : "Violent adults are frequently the victims of child abuse. To prevent violence we must love all children unconditionally.",
    "id" : 215791145920364544,
    "created_at" : "2012-06-21 12:59:53 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 215795010120060929,
  "created_at" : "2012-06-21 13:15:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215794841261580289",
  "text" : "RT @OMGFacts: In WWII, a soldier volunteered to go into Auschwitz and escape to prove the Holocaust was real! Story here ---&gt; http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/5tm9Rj1N",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/ezB",
        "display_url" : "omgf.ac\/ts\/ezB"
      } ]
    },
    "geo" : { },
    "id_str" : "215791767063244800",
    "text" : "In WWII, a soldier volunteered to go into Auschwitz and escape to prove the Holocaust was real! Story here ---&gt; http:\/\/t.co\/5tm9Rj1N",
    "id" : 215791767063244800,
    "created_at" : "2012-06-21 13:02:21 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 215794841261580289,
  "created_at" : "2012-06-21 13:14:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215617664595394560",
  "text" : "damn.. couldnt get a pic but raccoon stood up at door and peered in at least 3X! (after he had left then came back)",
  "id" : 215617664595394560,
  "created_at" : "2012-06-21 01:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215607846480510977",
  "geo" : { },
  "id_str" : "215609094441156609",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 yup, loves bones. doesnt take long to chomp down..lol. hes a lot braver when stray cat is there.",
  "id" : 215609094441156609,
  "in_reply_to_status_id" : 215607846480510977,
  "created_at" : "2012-06-21 00:56:28 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/inWZlp0A",
      "expanded_url" : "http:\/\/via.me\/-2887au4",
      "display_url" : "via.me\/-2887au4"
    } ]
  },
  "geo" : { },
  "id_str" : "215606708230303744",
  "text" : "Raccoon with his bone http:\/\/t.co\/inWZlp0A",
  "id" : 215606708230303744,
  "created_at" : "2012-06-21 00:46:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215592809380585475",
  "text" : "RT @CaroleODell: Just keep smiling.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215582588377628674",
    "text" : "Just keep smiling.",
    "id" : 215582588377628674,
    "created_at" : "2012-06-20 23:11:09 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 215592809380585475,
  "created_at" : "2012-06-20 23:51:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215542222056202241",
  "text" : "bleh.. still feeling ill. thought it was gallbladder issues but must be virus instead as head involved.",
  "id" : 215542222056202241,
  "created_at" : "2012-06-20 20:30:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "indices" : [ 3, 12 ],
      "id_str" : "11575102",
      "id" : 11575102
    }, {
      "name" : "craignewmark",
      "screen_name" : "craignewmark",
      "indices" : [ 100, 113 ],
      "id_str" : "14368074",
      "id" : 14368074
    }, {
      "name" : "METRO CROW",
      "screen_name" : "MetroCrow",
      "indices" : [ 114, 124 ],
      "id_str" : "539998256",
      "id" : 539998256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215506766656569344",
  "text" : "RT @tifotter: \"Yeah, I'm a baby crow.\" He's back! Beak sides are darkening but eyes are still blue. @craignewmark @MetroCrow http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "craignewmark",
        "screen_name" : "craignewmark",
        "indices" : [ 86, 99 ],
        "id_str" : "14368074",
        "id" : 14368074
      }, {
        "name" : "METRO CROW",
        "screen_name" : "MetroCrow",
        "indices" : [ 100, 110 ],
        "id_str" : "539998256",
        "id" : 539998256
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tifotter\/status\/215503980850200577\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/2F2ext56",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av2fupLCQAIGxkn.jpg",
        "id_str" : "215503980858589186",
        "id" : 215503980858589186,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av2fupLCQAIGxkn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1033,
          "resize" : "fit",
          "w" : 1550
        } ],
        "display_url" : "pic.twitter.com\/2F2ext56"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215503980850200577",
    "text" : "\"Yeah, I'm a baby crow.\" He's back! Beak sides are darkening but eyes are still blue. @craignewmark @MetroCrow http:\/\/t.co\/2F2ext56",
    "id" : 215503980850200577,
    "created_at" : "2012-06-20 17:58:48 +0000",
    "user" : {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "protected" : false,
      "id_str" : "11575102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579777071850737664\/0bwnd0kt_normal.jpg",
      "id" : 11575102,
      "verified" : false
    }
  },
  "id" : 215506766656569344,
  "created_at" : "2012-06-20 18:09:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Williamson",
      "screen_name" : "MattWilliamson",
      "indices" : [ 3, 18 ],
      "id_str" : "853443896",
      "id" : 853443896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 112 ],
      "url" : "https:\/\/t.co\/XzMDG9cv",
      "expanded_url" : "https:\/\/duckduckgo.com\/",
      "display_url" : "duckduckgo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "215500268840828928",
  "text" : "RT @mattwilliamson: Also, stop using Google, Yahoo, Bing\u2026 They track you. ONLY search with https:\/\/t.co\/XzMDG9cv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 92 ],
        "url" : "https:\/\/t.co\/XzMDG9cv",
        "expanded_url" : "https:\/\/duckduckgo.com\/",
        "display_url" : "duckduckgo.com"
      } ]
    },
    "geo" : { },
    "id_str" : "215492453606752256",
    "text" : "Also, stop using Google, Yahoo, Bing\u2026 They track you. ONLY search with https:\/\/t.co\/XzMDG9cv",
    "id" : 215492453606752256,
    "created_at" : "2012-06-20 17:12:59 +0000",
    "user" : {
      "name" : "Matthew Williamson",
      "screen_name" : "vajramatt",
      "protected" : false,
      "id_str" : "14117768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785846592314146816\/sJHQsbxP_normal.jpg",
      "id" : 14117768,
      "verified" : false
    }
  },
  "id" : 215500268840828928,
  "created_at" : "2012-06-20 17:44:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215482774948282369",
  "text" : "RT @derekrootboy: If anyone unfollows me because they think there's no smoke without fire and I couldn't be sectioned if I wasn't insane ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215482653166682114",
    "text" : "If anyone unfollows me because they think there's no smoke without fire and I couldn't be sectioned if I wasn't insane, have a nice life.",
    "id" : 215482653166682114,
    "created_at" : "2012-06-20 16:34:02 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 215482774948282369,
  "created_at" : "2012-06-20 16:34:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse Pheathers",
      "screen_name" : "HorsePheathers",
      "indices" : [ 3, 18 ],
      "id_str" : "47515266",
      "id" : 47515266
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 20, 32 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215482147002253312",
  "text" : "RT @HorsePheathers: @ReverendSue Maybe. I just don't see why falling short is such a huge big deal to begin with. We're human, we make m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reverend Sue",
        "screen_name" : "ReverendSue",
        "indices" : [ 0, 12 ],
        "id_str" : "40585382",
        "id" : 40585382
      }, {
        "name" : "Stephen E. Pryor",
        "screen_name" : "stephenepryor",
        "indices" : [ 125, 139 ],
        "id_str" : "2194961259",
        "id" : 2194961259
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "215480427106930688",
    "geo" : { },
    "id_str" : "215480957904494592",
    "in_reply_to_user_id" : 40585382,
    "text" : "@ReverendSue Maybe. I just don't see why falling short is such a huge big deal to begin with. We're human, we make mistakes. @stephenepryor",
    "id" : 215480957904494592,
    "in_reply_to_status_id" : 215480427106930688,
    "created_at" : "2012-06-20 16:27:18 +0000",
    "in_reply_to_screen_name" : "ReverendSue",
    "in_reply_to_user_id_str" : "40585382",
    "user" : {
      "name" : "Horse Pheathers",
      "screen_name" : "HorsePheathers",
      "protected" : false,
      "id_str" : "47515266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1720766942\/horse-pheathers_normal.jpg",
      "id" : 47515266,
      "verified" : false
    }
  },
  "id" : 215482147002253312,
  "created_at" : "2012-06-20 16:32:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215481850360107010",
  "text" : "RT @derekrootboy: My followers are dropping like nine-pins. Excellent. It's all going according to plan.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215479935916187648",
    "text" : "My followers are dropping like nine-pins. Excellent. It's all going according to plan.",
    "id" : 215479935916187648,
    "created_at" : "2012-06-20 16:23:14 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 215481850360107010,
  "created_at" : "2012-06-20 16:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 17, 29 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215481463242625024",
  "text" : "RT @deistlady76: @ReverendSue Hate is the only \"sin\" and all crimes against humanity both personal and impersonal come from it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reverend Sue",
        "screen_name" : "ReverendSue",
        "indices" : [ 0, 12 ],
        "id_str" : "40585382",
        "id" : 40585382
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "215478932479287296",
    "geo" : { },
    "id_str" : "215479284633055232",
    "in_reply_to_user_id" : 40585382,
    "text" : "@ReverendSue Hate is the only \"sin\" and all crimes against humanity both personal and impersonal come from it.",
    "id" : 215479284633055232,
    "in_reply_to_status_id" : 215478932479287296,
    "created_at" : "2012-06-20 16:20:39 +0000",
    "in_reply_to_screen_name" : "ReverendSue",
    "in_reply_to_user_id_str" : "40585382",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 215481463242625024,
  "created_at" : "2012-06-20 16:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/fWKzmCKA",
      "expanded_url" : "http:\/\/bit.ly\/LDEB6r",
      "display_url" : "bit.ly\/LDEB6r"
    } ]
  },
  "geo" : { },
  "id_str" : "215479782652121088",
  "text" : "\"I truly cannot imagine how people without insurance ever manage to stay alive, let alone healthy.\"  http:\/\/t.co\/fWKzmCKA",
  "id" : 215479782652121088,
  "created_at" : "2012-06-20 16:22:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Bierko",
      "screen_name" : "MrCraigBierko",
      "indices" : [ 3, 17 ],
      "id_str" : "105570240",
      "id" : 105570240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215476955280183296",
  "text" : "RT @MrCraigBierko: Escaping the oppressive heat of NYC to enjoy the oppressive heat of Poughkeepsie!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215476727751774210",
    "text" : "Escaping the oppressive heat of NYC to enjoy the oppressive heat of Poughkeepsie!",
    "id" : 215476727751774210,
    "created_at" : "2012-06-20 16:10:29 +0000",
    "user" : {
      "name" : "Craig Bierko",
      "screen_name" : "MrCraigBierko",
      "protected" : false,
      "id_str" : "105570240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750190326929887232\/hczmuUWc_normal.jpg",
      "id" : 105570240,
      "verified" : true
    }
  },
  "id" : 215476955280183296,
  "created_at" : "2012-06-20 16:11:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215254416364814337",
  "text" : "RT @Seeds4Parents: When the student is ready, the teacher appears, whether the teacher is a person, a bird, an event, whatever. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/DmKB5xYV",
        "expanded_url" : "http:\/\/tinyurl.com\/6agkoun",
        "display_url" : "tinyurl.com\/6agkoun"
      } ]
    },
    "geo" : { },
    "id_str" : "215250403724505088",
    "text" : "When the student is ready, the teacher appears, whether the teacher is a person, a bird, an event, whatever. http:\/\/t.co\/DmKB5xYV",
    "id" : 215250403724505088,
    "created_at" : "2012-06-20 01:11:10 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 215254416364814337,
  "created_at" : "2012-06-20 01:27:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    }, {
      "name" : "Amy Oscar",
      "screen_name" : "AmyOscar",
      "indices" : [ 42, 51 ],
      "id_str" : "19552126",
      "id" : 19552126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ciJXRbMo",
      "expanded_url" : "http:\/\/buff.ly\/PmzhYc",
      "display_url" : "buff.ly\/PmzhYc"
    } ]
  },
  "geo" : { },
  "id_str" : "215228303412436993",
  "text" : "RT @lisarobbinyoung: A solstice gift from @amyoscar - free copy of Sea of Miracles: A book about angels and you http:\/\/t.co\/ciJXRbMo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy Oscar",
        "screen_name" : "AmyOscar",
        "indices" : [ 21, 30 ],
        "id_str" : "19552126",
        "id" : 19552126
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/ciJXRbMo",
        "expanded_url" : "http:\/\/buff.ly\/PmzhYc",
        "display_url" : "buff.ly\/PmzhYc"
      } ]
    },
    "geo" : { },
    "id_str" : "215217171587018753",
    "text" : "A solstice gift from @amyoscar - free copy of Sea of Miracles: A book about angels and you http:\/\/t.co\/ciJXRbMo",
    "id" : 215217171587018753,
    "created_at" : "2012-06-19 22:59:06 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 215228303412436993,
  "created_at" : "2012-06-19 23:43:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "capitalism",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/BhKd7MVA",
      "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2006\/07\/store-of-free-and-just.html",
      "display_url" : "midnightfire.blogspot.no\/2006\/07\/store-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215187571347689472",
  "text" : "RT @HoodedMan: Walmart: Store of the Free and the Just http:\/\/t.co\/BhKd7MVA bullies with lots of money #capitalism",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "capitalism",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/BhKd7MVA",
        "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2006\/07\/store-of-free-and-just.html",
        "display_url" : "midnightfire.blogspot.no\/2006\/07\/store-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "215186157393289216",
    "text" : "Walmart: Store of the Free and the Just http:\/\/t.co\/BhKd7MVA bullies with lots of money #capitalism",
    "id" : 215186157393289216,
    "created_at" : "2012-06-19 20:55:52 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 215187571347689472,
  "created_at" : "2012-06-19 21:01:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/spZGTGWz",
      "expanded_url" : "http:\/\/goo.gl\/fb\/sLckO",
      "display_url" : "goo.gl\/fb\/sLckO"
    } ]
  },
  "geo" : { },
  "id_str" : "215187069591494656",
  "text" : "RT @Mahala: Hopeless http:\/\/t.co\/spZGTGWz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http:\/\/t.co\/spZGTGWz",
        "expanded_url" : "http:\/\/goo.gl\/fb\/sLckO",
        "display_url" : "goo.gl\/fb\/sLckO"
      } ]
    },
    "geo" : { },
    "id_str" : "215186178389975040",
    "text" : "Hopeless http:\/\/t.co\/spZGTGWz",
    "id" : 215186178389975040,
    "created_at" : "2012-06-19 20:55:57 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 215187069591494656,
  "created_at" : "2012-06-19 20:59:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215114980754849792",
  "text" : "RT @bend_time: i am so weary of mistreatment b\/c i have no power, read: MONEY. money gets you everything. w\/o it, we are worthless. no o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215113442527424513",
    "text" : "i am so weary of mistreatment b\/c i have no power, read: MONEY. money gets you everything. w\/o it, we are worthless. no one has to care.",
    "id" : 215113442527424513,
    "created_at" : "2012-06-19 16:06:55 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 215114980754849792,
  "created_at" : "2012-06-19 16:13:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gosztola",
      "screen_name" : "kgosztola",
      "indices" : [ 3, 13 ],
      "id_str" : "15808218",
      "id" : 15808218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215106518754934786",
  "text" : "RT @kgosztola: Pelican Bay prison has 500 men who've been in solitary for 10 yrs, 100 for 20 yrs (since facility opened in 1989) #StopSo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopSolitary",
        "indices" : [ 114, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215104341164572673",
    "text" : "Pelican Bay prison has 500 men who've been in solitary for 10 yrs, 100 for 20 yrs (since facility opened in 1989) #StopSolitary",
    "id" : 215104341164572673,
    "created_at" : "2012-06-19 15:30:46 +0000",
    "user" : {
      "name" : "Kevin Gosztola",
      "screen_name" : "kgosztola",
      "protected" : false,
      "id_str" : "15808218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627951363847098369\/ZwlkM7_C_normal.jpg",
      "id" : 15808218,
      "verified" : true
    }
  },
  "id" : 215106518754934786,
  "created_at" : "2012-06-19 15:39:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215100033211699201",
  "text" : "still ill from yesterday.. missed last day of bible study.",
  "id" : 215100033211699201,
  "created_at" : "2012-06-19 15:13:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scharffen Berger",
      "screen_name" : "ScharffenBerger",
      "indices" : [ 3, 19 ],
      "id_str" : "144957005",
      "id" : 144957005
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScharffenBerger",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214726484131201024",
  "text" : "RT @ScharffenBerger: Make Monday a little brighter, and RT by 1p ET for the chance to win #ScharffenBerger chocolate!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScharffenBerger",
        "indices" : [ 69, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214721849035206658",
    "text" : "Make Monday a little brighter, and RT by 1p ET for the chance to win #ScharffenBerger chocolate!",
    "id" : 214721849035206658,
    "created_at" : "2012-06-18 14:10:52 +0000",
    "user" : {
      "name" : "Scharffen Berger",
      "screen_name" : "ScharffenBerger",
      "protected" : false,
      "id_str" : "144957005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972261741\/SB_Logo_normal.jpg",
      "id" : 144957005,
      "verified" : true
    }
  },
  "id" : 214726484131201024,
  "created_at" : "2012-06-18 14:29:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "indices" : [ 3, 13 ],
      "id_str" : "90893629",
      "id" : 90893629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/VNgDTozl",
      "expanded_url" : "http:\/\/mbist.ro\/MZJff0",
      "display_url" : "mbist.ro\/MZJff0"
    } ]
  },
  "geo" : { },
  "id_str" : "214726010552328192",
  "text" : "RT @AppNewser: Tablet app market hits $2.6 billion this year http:\/\/t.co\/VNgDTozl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/VNgDTozl",
        "expanded_url" : "http:\/\/mbist.ro\/MZJff0",
        "display_url" : "mbist.ro\/MZJff0"
      } ]
    },
    "geo" : { },
    "id_str" : "214722809031704576",
    "text" : "Tablet app market hits $2.6 billion this year http:\/\/t.co\/VNgDTozl",
    "id" : 214722809031704576,
    "created_at" : "2012-06-18 14:14:41 +0000",
    "user" : {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "protected" : false,
      "id_str" : "90893629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461987151496744960\/7LSAvXUw_normal.png",
      "id" : 90893629,
      "verified" : false
    }
  },
  "id" : 214726010552328192,
  "created_at" : "2012-06-18 14:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/LG2hzrJZ",
      "expanded_url" : "http:\/\/sports.yahoo.com\/news\/ncaaf--father%E2%80%99s-day-is-bittersweet-for-ole-miss-assistant-dan-werner--a-single-dad-molded-by-football-and-tragedy.html",
      "display_url" : "sports.yahoo.com\/news\/ncaaf--fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214710889444683776",
  "text" : "Father\u2019s Day is bittersweet for Ole Miss assistant Dan Werner, single dad molded by football, tragedy - Yahoo! Sports http:\/\/t.co\/LG2hzrJZ",
  "id" : 214710889444683776,
  "created_at" : "2012-06-18 13:27:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214424876340084738",
  "geo" : { },
  "id_str" : "214510913640857600",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope bluebird. he's a gift from heaven. he started coming round early May? I think. makes my heart sing. : )",
  "id" : 214510913640857600,
  "in_reply_to_status_id" : 214424876340084738,
  "created_at" : "2012-06-18 00:12:41 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214413955240701953",
  "text" : "my bird came to visit me today. he is so beautiful and precious and reminds me about miracles.",
  "id" : 214413955240701953,
  "created_at" : "2012-06-17 17:47:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 53, 66 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/wR0DZbhH",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/46-years-old-today.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/46-yea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "214349643532877825",
  "geo" : { },
  "id_str" : "214351820577972225",
  "in_reply_to_user_id" : 73908822,
  "text" : "Happy Birthday! im older by 3 months, 3 days! : ) RT @DwayneReaves 46 years old today http:\/\/t.co\/wR0DZbhH",
  "id" : 214351820577972225,
  "in_reply_to_status_id" : 214349643532877825,
  "created_at" : "2012-06-17 13:40:31 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214162270215872513",
  "text" : "RT @OMGFacts: Gravity is weaker in North America than in Europe, East Asia, Australia, and North Africa. Deets here ---&gt; http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/tHVZjbOu",
        "expanded_url" : "http:\/\/spartz.me\/dia\/oWt",
        "display_url" : "spartz.me\/dia\/oWt"
      } ]
    },
    "geo" : { },
    "id_str" : "214153074225315841",
    "text" : "Gravity is weaker in North America than in Europe, East Asia, Australia, and North Africa. Deets here ---&gt; http:\/\/t.co\/tHVZjbOu",
    "id" : 214153074225315841,
    "created_at" : "2012-06-17 00:30:46 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 214162270215872513,
  "created_at" : "2012-06-17 01:07:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "indices" : [ 3, 17 ],
      "id_str" : "8833312",
      "id" : 8833312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214148923147816961",
  "text" : "RT @MicheleKnight: Pictured: The UFO-shaped object found at the bottom of the Baltic Sea... covered in soot, with... http:\/\/t.co\/M2GyohR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Mail Online",
        "screen_name" : "MailOnline",
        "indices" : [ 123, 134 ],
        "id_str" : "15438913",
        "id" : 15438913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/M2GyohR2",
        "expanded_url" : "http:\/\/bit.ly\/MFVMTW",
        "display_url" : "bit.ly\/MFVMTW"
      } ]
    },
    "geo" : { },
    "id_str" : "214148081418121217",
    "text" : "Pictured: The UFO-shaped object found at the bottom of the Baltic Sea... covered in soot, with... http:\/\/t.co\/M2GyohR2 via @MailOnline",
    "id" : 214148081418121217,
    "created_at" : "2012-06-17 00:10:55 +0000",
    "user" : {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "protected" : false,
      "id_str" : "8833312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616164060292337664\/DM_Io58r_normal.jpg",
      "id" : 8833312,
      "verified" : false
    }
  },
  "id" : 214148923147816961,
  "created_at" : "2012-06-17 00:14:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214120072254459904",
  "text" : "RT @CaroleODell: Waiting...sometimes it is so hard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214113792571883520",
    "text" : "Waiting...sometimes it is so hard.",
    "id" : 214113792571883520,
    "created_at" : "2012-06-16 21:54:40 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 214120072254459904,
  "created_at" : "2012-06-16 22:19:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Send Fudge",
      "screen_name" : "send_fudge",
      "indices" : [ 71, 82 ],
      "id_str" : "540320151",
      "id" : 540320151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/d99i5lBV",
      "expanded_url" : "http:\/\/blog.rafflecopter.com\/2012\/06\/rbs-send-fudge\/",
      "display_url" : "blog.rafflecopter.com\/2012\/06\/rbs-se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214102039616163840",
  "text" : "Rafflecopter Brand Showcase: Win 1 of 5 boxes of gourmet fudge via the @send_fudge #giveaway. Check it out: http:\/\/t.co\/d99i5lBV",
  "id" : 214102039616163840,
  "created_at" : "2012-06-16 21:07:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafflecopter",
      "screen_name" : "rafflecopter",
      "indices" : [ 3, 16 ],
      "id_str" : "264897818",
      "id" : 264897818
    }, {
      "name" : "Send Fudge",
      "screen_name" : "send_fudge",
      "indices" : [ 99, 110 ],
      "id_str" : "540320151",
      "id" : 540320151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214100451459735553",
  "text" : "RT @rafflecopter: Did you know today is National Fudge Day?! Win 1 of 5 boxes of gourmet fudge via @send_fudge. Check it out: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Send Fudge",
        "screen_name" : "send_fudge",
        "indices" : [ 81, 92 ],
        "id_str" : "540320151",
        "id" : 540320151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nomnom",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/QUnvAklV",
        "expanded_url" : "http:\/\/bit.ly\/KuvBFK",
        "display_url" : "bit.ly\/KuvBFK"
      } ]
    },
    "geo" : { },
    "id_str" : "214097423524569089",
    "text" : "Did you know today is National Fudge Day?! Win 1 of 5 boxes of gourmet fudge via @send_fudge. Check it out: http:\/\/t.co\/QUnvAklV #nomnom",
    "id" : 214097423524569089,
    "created_at" : "2012-06-16 20:49:38 +0000",
    "user" : {
      "name" : "Rafflecopter",
      "screen_name" : "rafflecopter",
      "protected" : false,
      "id_str" : "264897818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454126572635574272\/LI9WeXKT_normal.png",
      "id" : 264897818,
      "verified" : false
    }
  },
  "id" : 214100451459735553,
  "created_at" : "2012-06-16 21:01:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/tYK63VlX",
      "expanded_url" : "http:\/\/ducksandclucks.com\/blog\/2012\/06\/16\/babysitting\/",
      "display_url" : "ducksandclucks.com\/blog\/2012\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214096247412367360",
  "text" : "RT @ducksandclucks: Read all about my unexpected crow fledgling babysitting gig this morning. http:\/\/t.co\/tYK63VlX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/tYK63VlX",
        "expanded_url" : "http:\/\/ducksandclucks.com\/blog\/2012\/06\/16\/babysitting\/",
        "display_url" : "ducksandclucks.com\/blog\/2012\/06\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "214093764292116480",
    "text" : "Read all about my unexpected crow fledgling babysitting gig this morning. http:\/\/t.co\/tYK63VlX",
    "id" : 214093764292116480,
    "created_at" : "2012-06-16 20:35:05 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 214096247412367360,
  "created_at" : "2012-06-16 20:44:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bible",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214086255724597248",
  "text" : "RT @AnnotatedBible: *Who* determined the Canon of the #Bible, and *what* was their criteria? Which books were *almost* accepted or *almo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bible",
        "indices" : [ 34, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214079976197193729",
    "text" : "*Who* determined the Canon of the #Bible, and *what* was their criteria? Which books were *almost* accepted or *almost* rejected?",
    "id" : 214079976197193729,
    "created_at" : "2012-06-16 19:40:18 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 214086255724597248,
  "created_at" : "2012-06-16 20:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214085782166716416",
  "text" : "RT @TheGodLight: Things often get worse before they get better, for what you cling to hurts you more &amp; more until you learn to let go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214085625266184193",
    "text" : "Things often get worse before they get better, for what you cling to hurts you more &amp; more until you learn to let go.",
    "id" : 214085625266184193,
    "created_at" : "2012-06-16 20:02:45 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 214085782166716416,
  "created_at" : "2012-06-16 20:03:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214077132027072512",
  "text" : "in ref to prev tweet about scenes.. life is like that.. just many tiny scenes all connected...",
  "id" : 214077132027072512,
  "created_at" : "2012-06-16 19:29:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214076702496788480",
  "text" : "RT @Wylieknowords: Do you remember the day it suddenly hit you that a 2-hour movie was just 10 or 20 scenes connected by the verbal\/visu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214067344849371136",
    "text" : "Do you remember the day it suddenly hit you that a 2-hour movie was just 10 or 20 scenes connected by the verbal\/visual links?Scenes, Scenes",
    "id" : 214067344849371136,
    "created_at" : "2012-06-16 18:50:06 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 214076702496788480,
  "created_at" : "2012-06-16 19:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214076471407427585",
  "text" : "RT @ShhDragon: In every way we are different.\nIn every way we are the same.\n~ShhDragon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214069367007215617",
    "text" : "In every way we are different.\nIn every way we are the same.\n~ShhDragon",
    "id" : 214069367007215617,
    "created_at" : "2012-06-16 18:58:08 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 214076471407427585,
  "created_at" : "2012-06-16 19:26:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214060644868161539",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: There is no \"right path\" to God. Our choices are unrestricted, our opportunities are unlimited, our pat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214057561786294272",
    "text" : "RT @_NealeDWalsch: There is no \"right path\" to God. Our choices are unrestricted, our opportunities are unlimited, our paths are unending.",
    "id" : 214057561786294272,
    "created_at" : "2012-06-16 18:11:14 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 214060644868161539,
  "created_at" : "2012-06-16 18:23:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    }, {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "indices" : [ 72, 86 ],
      "id_str" : "30038832",
      "id" : 30038832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/SiDdNgNO",
      "expanded_url" : "http:\/\/www.ereaderiq.com\/pricewatch\/",
      "display_url" : "ereaderiq.com\/pricewatch\/"
    } ]
  },
  "in_reply_to_status_id_str" : "214039627743502337",
  "geo" : { },
  "id_str" : "214040415370883073",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise http:\/\/t.co\/SiDdNgNO will tell you when price drops. love it! @LilithsPriest #kindle",
  "id" : 214040415370883073,
  "in_reply_to_status_id" : 214039627743502337,
  "created_at" : "2012-06-16 17:03:06 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 3, 14 ],
      "id_str" : "15314194",
      "id" : 15314194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/Vp9zsbUj",
      "expanded_url" : "http:\/\/youtu.be\/QuNihdGBu8k",
      "display_url" : "youtu.be\/QuNihdGBu8k"
    } ]
  },
  "geo" : { },
  "id_str" : "214039679006289921",
  "text" : "RT @dee_carney: The pet possum commercial for those who haven't seen it: http:\/\/t.co\/Vp9zsbUj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/Vp9zsbUj",
        "expanded_url" : "http:\/\/youtu.be\/QuNihdGBu8k",
        "display_url" : "youtu.be\/QuNihdGBu8k"
      } ]
    },
    "geo" : { },
    "id_str" : "214038943623163904",
    "text" : "The pet possum commercial for those who haven't seen it: http:\/\/t.co\/Vp9zsbUj",
    "id" : 214038943623163904,
    "created_at" : "2012-06-16 16:57:15 +0000",
    "user" : {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "protected" : false,
      "id_str" : "15314194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649739435890839552\/00nSuPH-_normal.jpg",
      "id" : 15314194,
      "verified" : false
    }
  },
  "id" : 214039679006289921,
  "created_at" : "2012-06-16 17:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0632\u0647\u0631\u0629 \u0627\u0644\u062E\u0644\u064A\u062D",
      "screen_name" : "fricandeau",
      "indices" : [ 3, 14 ],
      "id_str" : "4148995389",
      "id" : 4148995389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cobaincase",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/bJmEEghc",
      "expanded_url" : "http:\/\/twitpic.com\/9x44q3",
      "display_url" : "twitpic.com\/9x44q3"
    } ]
  },
  "geo" : { },
  "id_str" : "214036147331006465",
  "text" : "RT @Fricandeau: This note was found in Courtney's backpack just days after Kurt Cobain was found dead! #cobaincase http:\/\/t.co\/bJmEEghc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cobaincase",
        "indices" : [ 87, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/bJmEEghc",
        "expanded_url" : "http:\/\/twitpic.com\/9x44q3",
        "display_url" : "twitpic.com\/9x44q3"
      } ]
    },
    "geo" : { },
    "id_str" : "214025652721037313",
    "text" : "This note was found in Courtney's backpack just days after Kurt Cobain was found dead! #cobaincase http:\/\/t.co\/bJmEEghc",
    "id" : 214025652721037313,
    "created_at" : "2012-06-16 16:04:26 +0000",
    "user" : {
      "name" : "CoffeeAndKurt",
      "screen_name" : "BleachTheLies",
      "protected" : false,
      "id_str" : "382465150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634267791487451138\/XYKCFmO8_normal.png",
      "id" : 382465150,
      "verified" : false
    }
  },
  "id" : 214036147331006465,
  "created_at" : "2012-06-16 16:46:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    }, {
      "name" : "Joel Johnson",
      "screen_name" : "zeninmotion",
      "indices" : [ 49, 61 ],
      "id_str" : "1456965044",
      "id" : 1456965044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214030721839411200",
  "geo" : { },
  "id_str" : "214035959782719490",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl so good to hear that, my sweets! : ) @ZenInMotion",
  "id" : 214035959782719490,
  "in_reply_to_status_id" : 214030721839411200,
  "created_at" : "2012-06-16 16:45:24 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fisheswithfeet",
      "screen_name" : "Fisheswithfeet",
      "indices" : [ 0, 15 ],
      "id_str" : "239314039",
      "id" : 239314039
    }, {
      "name" : "BtheCalvinist",
      "screen_name" : "BtheCalvinist",
      "indices" : [ 108, 122 ],
      "id_str" : "344230025",
      "id" : 344230025
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 123, 137 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213714795868848128",
  "geo" : { },
  "id_str" : "214035686750302208",
  "in_reply_to_user_id" : 239314039,
  "text" : "@Fisheswithfeet its the people using religion (like guns...) religion magnifies a person's thinking process @BtheCalvinist @BibleAlsoSays",
  "id" : 214035686750302208,
  "in_reply_to_status_id" : 213714795868848128,
  "created_at" : "2012-06-16 16:44:18 +0000",
  "in_reply_to_screen_name" : "Fisheswithfeet",
  "in_reply_to_user_id_str" : "239314039",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Bierko",
      "screen_name" : "MrCraigBierko",
      "indices" : [ 3, 17 ],
      "id_str" : "105570240",
      "id" : 105570240
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrCraigBierko\/status\/214021015565639681\/photo\/1",
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ZiEVX2jY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Avha-tACIAEGJXZ.jpg",
      "id_str" : "214021015578222593",
      "id" : 214021015578222593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Avha-tACIAEGJXZ.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZiEVX2jY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214021450141663233",
  "text" : "RT @MrCraigBierko: Vagina. http:\/\/t.co\/ZiEVX2jY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrCraigBierko\/status\/214021015565639681\/photo\/1",
        "indices" : [ 8, 28 ],
        "url" : "http:\/\/t.co\/ZiEVX2jY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Avha-tACIAEGJXZ.jpg",
        "id_str" : "214021015578222593",
        "id" : 214021015578222593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Avha-tACIAEGJXZ.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZiEVX2jY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214021015565639681",
    "text" : "Vagina. http:\/\/t.co\/ZiEVX2jY",
    "id" : 214021015565639681,
    "created_at" : "2012-06-16 15:46:01 +0000",
    "user" : {
      "name" : "Craig Bierko",
      "screen_name" : "MrCraigBierko",
      "protected" : false,
      "id_str" : "105570240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750190326929887232\/hczmuUWc_normal.jpg",
      "id" : 105570240,
      "verified" : true
    }
  },
  "id" : 214021450141663233,
  "created_at" : "2012-06-16 15:47:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214014507322851329",
  "geo" : { },
  "id_str" : "214018357962342400",
  "in_reply_to_user_id" : 419534932,
  "text" : ". @Boonearang twitter has been wonderful therapy for me.. i love twitter. : )",
  "id" : 214018357962342400,
  "in_reply_to_status_id" : 214014507322851329,
  "created_at" : "2012-06-16 15:35:27 +0000",
  "in_reply_to_screen_name" : "JediMasterJason",
  "in_reply_to_user_id_str" : "419534932",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Siebenthal",
      "screen_name" : "aspienaut",
      "indices" : [ 3, 13 ],
      "id_str" : "335896144",
      "id" : 335896144
    }, {
      "name" : "Paul Siebenthal",
      "screen_name" : "aspienaut",
      "indices" : [ 25, 35 ],
      "id_str" : "335896144",
      "id" : 335896144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/uLASsqZ9",
      "expanded_url" : "http:\/\/aspienaut.tumblr.com",
      "display_url" : "aspienaut.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "213991094684352512",
  "text" : "RT @Aspienaut: I created @aspienaut &amp; http:\/\/t.co\/uLASsqZ9 to share what it is like to be on the spectrum and to help others underst ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Siebenthal",
        "screen_name" : "aspienaut",
        "indices" : [ 10, 20 ],
        "id_str" : "335896144",
        "id" : 335896144
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aspie",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/uLASsqZ9",
        "expanded_url" : "http:\/\/aspienaut.tumblr.com",
        "display_url" : "aspienaut.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "213989953259048960",
    "text" : "I created @aspienaut &amp; http:\/\/t.co\/uLASsqZ9 to share what it is like to be on the spectrum and to help others understand. #aspie Pls RT",
    "id" : 213989953259048960,
    "created_at" : "2012-06-16 13:42:35 +0000",
    "user" : {
      "name" : "Paul Siebenthal",
      "screen_name" : "aspienaut",
      "protected" : false,
      "id_str" : "335896144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552244235370381312\/mz35xqsC_normal.jpeg",
      "id" : 335896144,
      "verified" : false
    }
  },
  "id" : 213991094684352512,
  "created_at" : "2012-06-16 13:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 27, 38 ],
      "id_str" : "15314194",
      "id" : 15314194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213983761346469889",
  "text" : "finished \"Keeping Pace\" by @dee_carney yesterday.. what a steamy, fun read!!",
  "id" : 213983761346469889,
  "created_at" : "2012-06-16 13:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buddha",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213982458616619008",
  "text" : "RT @AnAmericanMonk: No one saves us but ourselves. No one can and no one may. We ourselves must walk the path. #Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buddha",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213980566142459904",
    "text" : "No one saves us but ourselves. No one can and no one may. We ourselves must walk the path. #Buddha",
    "id" : 213980566142459904,
    "created_at" : "2012-06-16 13:05:17 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 213982458616619008,
  "created_at" : "2012-06-16 13:12:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213813672672362497",
  "text" : "oh and kitty took piece of cheese from my fingers. still hisses a bit. and wouldn't do it again. tried to keep raccoon away but that face!",
  "id" : 213813672672362497,
  "created_at" : "2012-06-16 02:02:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213810235045982209",
  "geo" : { },
  "id_str" : "213813237957931009",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny ur 46? me, too. (((hugs)))",
  "id" : 213813237957931009,
  "in_reply_to_status_id" : 213810235045982209,
  "created_at" : "2012-06-16 02:00:23 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213812743256555521",
  "text" : "stray cat came by. he looks a bit better than last night. gave him cheese, steak and raw bacon. raccoon came by also. both on porch.",
  "id" : 213812743256555521,
  "created_at" : "2012-06-16 01:58:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213792682349305856",
  "geo" : { },
  "id_str" : "213798303429701632",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt ((hugs))",
  "id" : 213798303429701632,
  "in_reply_to_status_id" : 213792682349305856,
  "created_at" : "2012-06-16 01:01:02 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213781354662473728",
  "text" : "im worried about my stray cat. i hope he comes by tonight. i'll give him cheese.",
  "id" : 213781354662473728,
  "created_at" : "2012-06-15 23:53:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/JqFQu3JA",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/15-days-and-counting.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/15-day\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213780273639342080",
  "text" : "RT @DwayneReaves: 15 days and counting. http:\/\/t.co\/JqFQu3JA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/JqFQu3JA",
        "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/15-days-and-counting.html?spref=tw",
        "display_url" : "mrreaves.blogspot.com\/2012\/06\/15-day\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "213779430106071042",
    "text" : "15 days and counting. http:\/\/t.co\/JqFQu3JA",
    "id" : 213779430106071042,
    "created_at" : "2012-06-15 23:46:02 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 213780273639342080,
  "created_at" : "2012-06-15 23:49:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213776791918227456",
  "text" : "RT @sparklekaz: Seeing death as the end of life is like seeing the Horizon as the end of the ocean.\nDavid Searls",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213770244957798402",
    "text" : "Seeing death as the end of life is like seeing the Horizon as the end of the ocean.\nDavid Searls",
    "id" : 213770244957798402,
    "created_at" : "2012-06-15 23:09:32 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 213776791918227456,
  "created_at" : "2012-06-15 23:35:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213776733860667392",
  "text" : "RT @TheGodLight: The stars like God shine for all of us, not just some of us, no matter who you are or what you have done, God loves you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213770584591577089",
    "text" : "The stars like God shine for all of us, not just some of us, no matter who you are or what you have done, God loves you.",
    "id" : 213770584591577089,
    "created_at" : "2012-06-15 23:10:53 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 213776733860667392,
  "created_at" : "2012-06-15 23:35:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213775691928444928",
  "text" : "@BeaEdyson my thoughts on universe seem to run concurrent w yours : )",
  "id" : 213775691928444928,
  "created_at" : "2012-06-15 23:31:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213729222131318785",
  "geo" : { },
  "id_str" : "213730319159934976",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu i just saw yr comment on FB about it being 2AM..lol",
  "id" : 213730319159934976,
  "in_reply_to_status_id" : 213729222131318785,
  "created_at" : "2012-06-15 20:30:53 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213721931260760064",
  "geo" : { },
  "id_str" : "213728573050204160",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu  I have to put volume all the way up.. but you have a good voice! : )",
  "id" : 213728573050204160,
  "in_reply_to_status_id" : 213721931260760064,
  "created_at" : "2012-06-15 20:23:57 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213715827332091904",
  "text" : "RT @shanecrash: The concept of \"illegal\" immigration is immoral and generally fueled by racism and discrimination.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213712657298100224",
    "text" : "The concept of \"illegal\" immigration is immoral and generally fueled by racism and discrimination.",
    "id" : 213712657298100224,
    "created_at" : "2012-06-15 19:20:42 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 213715827332091904,
  "created_at" : "2012-06-15 19:33:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213684282101731328",
  "text" : "i tried collectorz db for organizing ebooks but dont like it. i need something just for ebooks.",
  "id" : 213684282101731328,
  "created_at" : "2012-06-15 17:27:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213683780727214080",
  "text" : "i really dislike amazon's database of my kindle books. hard to search. and when books are taken off kindle for loan. i forget which ones.",
  "id" : 213683780727214080,
  "created_at" : "2012-06-15 17:25:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RED FRILL COAT",
      "screen_name" : "ghouldreams",
      "indices" : [ 0, 12 ],
      "id_str" : "4674991088",
      "id" : 4674991088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213682326708830209",
  "text" : "@GhoulDreams hope you feel better real soon!",
  "id" : 213682326708830209,
  "created_at" : "2012-06-15 17:20:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213663898941915136",
  "geo" : { },
  "id_str" : "213669056253927424",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl ((huggles)) : )",
  "id" : 213669056253927424,
  "in_reply_to_status_id" : 213663898941915136,
  "created_at" : "2012-06-15 16:27:27 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213666361522659328",
  "text" : "RT @BeaEdyson Because they cannot see the light (why humans r afraid of the end?)",
  "id" : 213666361522659328,
  "created_at" : "2012-06-15 16:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213665863881080832",
  "text" : "RT @BeaEdyson Everything in the universe is made of the same energy. The collective conscious that inhabits humanity is no exception.",
  "id" : 213665863881080832,
  "created_at" : "2012-06-15 16:14:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213458767679995906",
  "text" : "RT @TheEntertainer: There is ALWAYS a Divine Solution NO MATTER WHAT.\n\nIn the midst of turmoil, EVEN when it looks like the bottom,... h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/MLW5LKGJ",
        "expanded_url" : "http:\/\/fb.me\/1FlevfuTt",
        "display_url" : "fb.me\/1FlevfuTt"
      } ]
    },
    "geo" : { },
    "id_str" : "213458504269316096",
    "text" : "There is ALWAYS a Divine Solution NO MATTER WHAT.\n\nIn the midst of turmoil, EVEN when it looks like the bottom,... http:\/\/t.co\/MLW5LKGJ",
    "id" : 213458504269316096,
    "created_at" : "2012-06-15 02:30:47 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 213458767679995906,
  "created_at" : "2012-06-15 02:31:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "indices" : [ 3, 14 ],
      "id_str" : "129845242",
      "id" : 129845242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213457600338075648",
  "text" : "RT @Inspire_Us: No act of kindness, no matter how small, is ever wasted. -Aesop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209174060595294208",
    "text" : "No act of kindness, no matter how small, is ever wasted. -Aesop",
    "id" : 209174060595294208,
    "created_at" : "2012-06-03 06:45:56 +0000",
    "user" : {
      "name" : "Inspirational Quotes",
      "screen_name" : "Inspire_Us",
      "protected" : false,
      "id_str" : "129845242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1154181325\/Inspire_Big_Bang_Twitter_Profile_Image555_-_Rounded_Corners_normal.png",
      "id" : 129845242,
      "verified" : false
    }
  },
  "id" : 213457600338075648,
  "created_at" : "2012-06-15 02:27:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213457082022760448",
  "text" : "my stray kitty stopped by tonight. he didnt look good. thinner and had 2 wounds. gave him some meat but he didnt eat a whole lot. : (",
  "id" : 213457082022760448,
  "created_at" : "2012-06-15 02:25:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213090526147264514",
  "text" : "RT @TheGodLight: Misery can pull you to the edge of the abyss, you must never look down, you must always look to the Heavens for assistance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213089524954316801",
    "text" : "Misery can pull you to the edge of the abyss, you must never look down, you must always look to the Heavens for assistance.",
    "id" : 213089524954316801,
    "created_at" : "2012-06-14 02:04:36 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 213090526147264514,
  "created_at" : "2012-06-14 02:08:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213038579620904961",
  "geo" : { },
  "id_str" : "213086866851901441",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope oh no.. : ( we have a few around here. been visiting lately.",
  "id" : 213086866851901441,
  "in_reply_to_status_id" : 213038579620904961,
  "created_at" : "2012-06-14 01:54:02 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213084053014982656",
  "geo" : { },
  "id_str" : "213085663325724672",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope lol..",
  "id" : 213085663325724672,
  "in_reply_to_status_id" : 213084053014982656,
  "created_at" : "2012-06-14 01:49:15 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213079116986060802",
  "text" : "all 3 of us got hair cuts today. hubby's hair on floor looked like when you brush out a dog. bleh.",
  "id" : 213079116986060802,
  "created_at" : "2012-06-14 01:23:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Uw0ZLocj",
      "expanded_url" : "http:\/\/ow.ly\/1kxxdW",
      "display_url" : "ow.ly\/1kxxdW"
    } ]
  },
  "geo" : { },
  "id_str" : "213077297274699777",
  "text" : "RT @grouchypuppy: New: 12 Million Dog March | Cheap Trick singer raises funds for dogs with cancer http:\/\/t.co\/Uw0ZLocj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/Uw0ZLocj",
        "expanded_url" : "http:\/\/ow.ly\/1kxxdW",
        "display_url" : "ow.ly\/1kxxdW"
      } ]
    },
    "geo" : { },
    "id_str" : "213076414168186880",
    "text" : "New: 12 Million Dog March | Cheap Trick singer raises funds for dogs with cancer http:\/\/t.co\/Uw0ZLocj",
    "id" : 213076414168186880,
    "created_at" : "2012-06-14 01:12:30 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 213077297274699777,
  "created_at" : "2012-06-14 01:16:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Appstore",
      "screen_name" : "amazonappstore",
      "indices" : [ 3, 18 ],
      "id_str" : "247483633",
      "id" : 247483633
    }, {
      "name" : "Amazon Appstore",
      "screen_name" : "amazonappstore",
      "indices" : [ 46, 61 ],
      "id_str" : "247483633",
      "id" : 247483633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213030621159763969",
  "text" : "RT @amazonappstore: Explore this week's deals @amazonappstore. Get 93% off OfficeSuite Professional 6--just $0.99. Edit Word, Excel docs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.amazon.com\/ref=tsm_1_tw_s9mapps\" rel=\"nofollow\"\u003ESocial Manager Publisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon Appstore",
        "screen_name" : "amazonappstore",
        "indices" : [ 26, 41 ],
        "id_str" : "247483633",
        "id" : 247483633
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/u5NYGu8C",
        "expanded_url" : "http:\/\/amzn.to\/L5VVEk",
        "display_url" : "amzn.to\/L5VVEk"
      } ]
    },
    "geo" : { },
    "id_str" : "213022981524434946",
    "text" : "Explore this week's deals @amazonappstore. Get 93% off OfficeSuite Professional 6--just $0.99. Edit Word, Excel docs. http:\/\/t.co\/u5NYGu8C",
    "id" : 213022981524434946,
    "created_at" : "2012-06-13 21:40:11 +0000",
    "user" : {
      "name" : "Amazon Appstore",
      "screen_name" : "amazonappstore",
      "protected" : false,
      "id_str" : "247483633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780869599411646464\/DXKKcLuC_normal.jpg",
      "id" : 247483633,
      "verified" : true
    }
  },
  "id" : 213030621159763969,
  "created_at" : "2012-06-13 22:10:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212982454510821376",
  "text" : "RT @alanhdawe: We have enough on our plates in our own universe without all this. Let God-Consciousness sort it out, as it is His Creati ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212980919026462720",
    "text" : "We have enough on our plates in our own universe without all this. Let God-Consciousness sort it out, as it is His Creation anyway. #TGFBook",
    "id" : 212980919026462720,
    "created_at" : "2012-06-13 18:53:02 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 212982454510821376,
  "created_at" : "2012-06-13 18:59:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212978089767092225",
  "text" : "@BibleAlsoSays we all need that time to step back, breathe and regroup...",
  "id" : 212978089767092225,
  "created_at" : "2012-06-13 18:41:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 35, 49 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212977613319315456",
  "text" : "I def do not have a problem w that @BibleAlsoSays the idea of forcing something on you sickens me. freedom for all.",
  "id" : 212977613319315456,
  "created_at" : "2012-06-13 18:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hardtobefemale",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212975766022012930",
  "text" : "im wearing a bra.. this does not make me happy. guys dont know how good they got it! #hardtobefemale",
  "id" : 212975766022012930,
  "created_at" : "2012-06-13 18:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212975277716930563",
  "text" : "the world is NOT black and white.. it is made up of infinite shades..",
  "id" : 212975277716930563,
  "created_at" : "2012-06-13 18:30:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 20, 34 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iminsanesowhat",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212975000376975361",
  "text" : "i dont want to live @BibleAlsoSays in that which you call reality. its pure horror. i prefer my world of unicorns. #iminsanesowhat",
  "id" : 212975000376975361,
  "created_at" : "2012-06-13 18:29:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212974324494241793",
  "text" : "RT @Pandeism: I do not need to be 'redeemed' on account of the fact that I am not a coupon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212969384573026305",
    "text" : "I do not need to be 'redeemed' on account of the fact that I am not a coupon.",
    "id" : 212969384573026305,
    "created_at" : "2012-06-13 18:07:12 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 212974324494241793,
  "created_at" : "2012-06-13 18:26:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212953773683916803",
  "text" : "ive been had.. that last RT was satire.. and I cant delete it! bleh.. should have known better..",
  "id" : 212953773683916803,
  "created_at" : "2012-06-13 17:05:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/ptk970lh",
      "expanded_url" : "http:\/\/amzn.to\/LWLEIb",
      "display_url" : "amzn.to\/LWLEIb"
    } ]
  },
  "geo" : { },
  "id_str" : "212949532173008896",
  "text" : "RT @amazonmp3: We have a $2 credit to celebrate Amazon Cloud Player for iPhone\/iPod Touch. Have you used it yet? http:\/\/t.co\/ptk970lh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/ptk970lh",
        "expanded_url" : "http:\/\/amzn.to\/LWLEIb",
        "display_url" : "amzn.to\/LWLEIb"
      } ]
    },
    "geo" : { },
    "id_str" : "212942858829824000",
    "text" : "We have a $2 credit to celebrate Amazon Cloud Player for iPhone\/iPod Touch. Have you used it yet? http:\/\/t.co\/ptk970lh",
    "id" : 212942858829824000,
    "created_at" : "2012-06-13 16:21:48 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 212949532173008896,
  "created_at" : "2012-06-13 16:48:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn",
      "screen_name" : "carrieinco",
      "indices" : [ 3, 14 ],
      "id_str" : "352508648",
      "id" : 352508648
    }, {
      "name" : "Free Wood Post",
      "screen_name" : "FreeWoodPost",
      "indices" : [ 93, 106 ],
      "id_str" : "366301255",
      "id" : 366301255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/hcd0HHEG",
      "expanded_url" : "http:\/\/p.ost.im\/p\/eWpgvV",
      "display_url" : "p.ost.im\/p\/eWpgvV"
    } ]
  },
  "geo" : { },
  "id_str" : "212949337897054208",
  "text" : "RT @carrieinco: Mitt Romney: \"I was too important to go to Vietnam\" http:\/\/t.co\/hcd0HHEG via @freewoodpost OMG the gall of this man!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Free Wood Post",
        "screen_name" : "FreeWoodPost",
        "indices" : [ 77, 90 ],
        "id_str" : "366301255",
        "id" : 366301255
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/hcd0HHEG",
        "expanded_url" : "http:\/\/p.ost.im\/p\/eWpgvV",
        "display_url" : "p.ost.im\/p\/eWpgvV"
      } ]
    },
    "geo" : { },
    "id_str" : "212938028652576768",
    "text" : "Mitt Romney: \"I was too important to go to Vietnam\" http:\/\/t.co\/hcd0HHEG via @freewoodpost OMG the gall of this man!",
    "id" : 212938028652576768,
    "created_at" : "2012-06-13 16:02:36 +0000",
    "user" : {
      "name" : "Carolyn",
      "screen_name" : "carrieinco",
      "protected" : false,
      "id_str" : "352508648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489996290\/barack-obama-2011-3-8-13-50-27_normal.jpg",
      "id" : 352508648,
      "verified" : false
    }
  },
  "id" : 212949337897054208,
  "created_at" : "2012-06-13 16:47:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212713580536143872",
  "geo" : { },
  "id_str" : "212913655698821120",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl aww.. I was referring to my hubby..lol.. but thank you. you're always so kind to me! \u2665",
  "id" : 212913655698821120,
  "in_reply_to_status_id" : 212713580536143872,
  "created_at" : "2012-06-13 14:25:45 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/oUidlrOd",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/Rj0",
      "display_url" : "omgf.ac\/ts\/Rj0"
    } ]
  },
  "geo" : { },
  "id_str" : "212712368868835331",
  "text" : "RT @OMGFacts: The Netherlands is closing 8 prisons due to a lack of prisoners! Details --&gt; http:\/\/t.co\/oUidlrOd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/oUidlrOd",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/Rj0",
        "display_url" : "omgf.ac\/ts\/Rj0"
      } ]
    },
    "geo" : { },
    "id_str" : "212711241930637314",
    "text" : "The Netherlands is closing 8 prisons due to a lack of prisoners! Details --&gt; http:\/\/t.co\/oUidlrOd",
    "id" : 212711241930637314,
    "created_at" : "2012-06-13 01:01:26 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 212712368868835331,
  "created_at" : "2012-06-13 01:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212704211488604160",
  "geo" : { },
  "id_str" : "212711887455010816",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 thank you... I know there's a lesson in this somewhere... lol ((hugs))",
  "id" : 212711887455010816,
  "in_reply_to_status_id" : 212704211488604160,
  "created_at" : "2012-06-13 01:04:00 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeatheroftheEO",
      "screen_name" : "HeatheroftheEO",
      "indices" : [ 0, 15 ],
      "id_str" : "16050319",
      "id" : 16050319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212685230648209409",
  "geo" : { },
  "id_str" : "212689544892514304",
  "in_reply_to_user_id" : 16050319,
  "text" : "@HeatheroftheEO sounds like scrambled eggs to me...",
  "id" : 212689544892514304,
  "in_reply_to_status_id" : 212685230648209409,
  "created_at" : "2012-06-12 23:35:13 +0000",
  "in_reply_to_screen_name" : "HeatheroftheEO",
  "in_reply_to_user_id_str" : "16050319",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buyingclothesistorture",
      "indices" : [ 18, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212681458702225408",
  "text" : "and... i'm fat!!! #buyingclothesistorture",
  "id" : 212681458702225408,
  "created_at" : "2012-06-12 23:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212681156666195968",
  "text" : "no one ever listens to me...",
  "id" : 212681156666195968,
  "created_at" : "2012-06-12 23:01:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212357263111888898",
  "text" : "RT @TheGodLight: Your attitude towards life attracts people who need to learn a similar lesson to you, know this &amp; you will see more ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212357187199188995",
    "text" : "Your attitude towards life attracts people who need to learn a similar lesson to you, know this &amp; you will see more clearly.",
    "id" : 212357187199188995,
    "created_at" : "2012-06-12 01:34:33 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 212357263111888898,
  "created_at" : "2012-06-12 01:34:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212345413292933120",
  "geo" : { },
  "id_str" : "212356934572048385",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 sorry to hear about Red.. but no better way to go than sleeping w mommy.. ((hugs))",
  "id" : 212356934572048385,
  "in_reply_to_status_id" : 212345413292933120,
  "created_at" : "2012-06-12 01:33:33 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212350733796909056",
  "geo" : { },
  "id_str" : "212356045455097856",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl feel better sweetie ((hugs))",
  "id" : 212356045455097856,
  "in_reply_to_status_id" : 212350733796909056,
  "created_at" : "2012-06-12 01:30:01 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212354912481329155",
  "text" : "on the phone w my sis for 2 hours i think.. omg.. its my mother all over again!!! LOL",
  "id" : 212354912481329155,
  "created_at" : "2012-06-12 01:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "indices" : [ 3, 14 ],
      "id_str" : "15767534",
      "id" : 15767534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/5sdHl3B9",
      "expanded_url" : "http:\/\/bit.ly\/Ol10YR",
      "display_url" : "bit.ly\/Ol10YR"
    } ]
  },
  "geo" : { },
  "id_str" : "212277963381686273",
  "text" : "RT @micahbales: Citibank Doesn't Think You'll Share The Fact That They Are Robbing A Single Mom http:\/\/t.co\/5sdHl3B9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/oojbgadfejifecebmdnhhkbhdjaphole\" rel=\"nofollow\"\u003EDiigo extension for Chrome\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/5sdHl3B9",
        "expanded_url" : "http:\/\/bit.ly\/Ol10YR",
        "display_url" : "bit.ly\/Ol10YR"
      } ]
    },
    "geo" : { },
    "id_str" : "212275327278387201",
    "text" : "Citibank Doesn't Think You'll Share The Fact That They Are Robbing A Single Mom http:\/\/t.co\/5sdHl3B9",
    "id" : 212275327278387201,
    "created_at" : "2012-06-11 20:09:16 +0000",
    "user" : {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "protected" : false,
      "id_str" : "15767534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523109819654230017\/RlmyhCrv_normal.png",
      "id" : 15767534,
      "verified" : false
    }
  },
  "id" : 212277963381686273,
  "created_at" : "2012-06-11 20:19:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212277789557133314",
  "text" : "RT @Wylieknowords: Mitt Romney makes $21million a year for doing absolutely nothing. Do you think he can relate, have empathy, with a co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212273990796984320",
    "text" : "Mitt Romney makes $21million a year for doing absolutely nothing. Do you think he can relate, have empathy, with a cop,teacher,firefighter?",
    "id" : 212273990796984320,
    "created_at" : "2012-06-11 20:03:57 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 212277789557133314,
  "created_at" : "2012-06-11 20:19:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "indices" : [ 3, 19 ],
      "id_str" : "29251361",
      "id" : 29251361
    }, {
      "name" : "PAT BROWN",
      "screen_name" : "ProfilerPatB",
      "indices" : [ 28, 41 ],
      "id_str" : "33248443",
      "id" : 33248443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212209156474671104",
  "text" : "RT @WorldOfJoeRiggs: Follow @ProfilerPatB  Legendary Criminal Profiler, Author of \"The Profiler: My Life Hunting Serial Killers &amp; Ps ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PAT BROWN",
        "screen_name" : "ProfilerPatB",
        "indices" : [ 7, 20 ],
        "id_str" : "33248443",
        "id" : 33248443
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212208451722555393",
    "text" : "Follow @ProfilerPatB  Legendary Criminal Profiler, Author of \"The Profiler: My Life Hunting Serial Killers &amp; Psychopaths.\" I've read 7 times",
    "id" : 212208451722555393,
    "created_at" : "2012-06-11 15:43:32 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 212209156474671104,
  "created_at" : "2012-06-11 15:46:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RhinebeckTweets",
      "screen_name" : "RhinebeckTweets",
      "indices" : [ 3, 19 ],
      "id_str" : "85490306",
      "id" : 85490306
    }, {
      "name" : "Jeremy Vine",
      "screen_name" : "theJeremyVine",
      "indices" : [ 54, 68 ],
      "id_str" : "331672974",
      "id" : 331672974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212208648854839296",
  "text" : "RT @RhinebeckTweets: wow, amazingly rly rly bad ad RT @thejeremyvine: HarveyNicols, do you realise, NO ONE WILL EVER BUY THESE TROUSERS  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Vine",
        "screen_name" : "theJeremyVine",
        "indices" : [ 33, 47 ],
        "id_str" : "331672974",
        "id" : 331672974
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/nMYFtOL8",
        "expanded_url" : "http:\/\/ow.ly\/bv3bB",
        "display_url" : "ow.ly\/bv3bB"
      } ]
    },
    "geo" : { },
    "id_str" : "212207785297973250",
    "text" : "wow, amazingly rly rly bad ad RT @thejeremyvine: HarveyNicols, do you realise, NO ONE WILL EVER BUY THESE TROUSERS NOW http:\/\/t.co\/nMYFtOL8",
    "id" : 212207785297973250,
    "created_at" : "2012-06-11 15:40:53 +0000",
    "user" : {
      "name" : "RhinebeckTweets",
      "screen_name" : "RhinebeckTweets",
      "protected" : false,
      "id_str" : "85490306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801025222765907968\/R2lqG0je_normal.jpg",
      "id" : 85490306,
      "verified" : false
    }
  },
  "id" : 212208648854839296,
  "created_at" : "2012-06-11 15:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Woodhead",
      "screen_name" : "velicion",
      "indices" : [ 3, 12 ],
      "id_str" : "191944475",
      "id" : 191944475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212206572879872002",
  "text" : "RT @velicion: Atheist vampires are tricky to kill. You need a copy of The Origin of Species, and a monkey.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212202548159983617",
    "text" : "Atheist vampires are tricky to kill. You need a copy of The Origin of Species, and a monkey.",
    "id" : 212202548159983617,
    "created_at" : "2012-06-11 15:20:04 +0000",
    "user" : {
      "name" : "Ian Woodhead",
      "screen_name" : "velicion",
      "protected" : false,
      "id_str" : "191944475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1126149175\/me2_normal.jpg",
      "id" : 191944475,
      "verified" : false
    }
  },
  "id" : 212206572879872002,
  "created_at" : "2012-06-11 15:36:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212200503206100993",
  "text" : "RT @ReverendSue: If you're hear to preach that there's only one way to happiness, please move along. Narrow-mindedness NOT accepted here ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "religion",
        "indices" : [ 121, 130 ]
      }, {
        "text" : "atheism",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212192678195118080",
    "text" : "If you're hear to preach that there's only one way to happiness, please move along. Narrow-mindedness NOT accepted here. #religion #atheism",
    "id" : 212192678195118080,
    "created_at" : "2012-06-11 14:40:51 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 212200503206100993,
  "created_at" : "2012-06-11 15:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "indices" : [ 10, 23 ],
      "id_str" : "525383338",
      "id" : 525383338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truth",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211841923009363968",
  "geo" : { },
  "id_str" : "212185094264332288",
  "in_reply_to_user_id" : 525383338,
  "text" : "#truth MT @ClosureForKC You have no idea what my reality is. We're all fighting our own battles.",
  "id" : 212185094264332288,
  "in_reply_to_status_id" : 211841923009363968,
  "created_at" : "2012-06-11 14:10:43 +0000",
  "in_reply_to_screen_name" : "ClosureForKC",
  "in_reply_to_user_id_str" : "525383338",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211979797113475072",
  "text" : "it's times likes these I'm soo glad I didn't let DR put DD on RX at 13yo..",
  "id" : 211979797113475072,
  "created_at" : "2012-06-11 00:34:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211978318390624256",
  "text" : "DAMN! forgot my pill this am. no wonder I was weepy this afternoon. now im messed up 4 a few days..sigh. #effexor",
  "id" : 211978318390624256,
  "created_at" : "2012-06-11 00:29:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211948170358423552",
  "geo" : { },
  "id_str" : "211962223382380546",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt (((hugs)))",
  "id" : 211962223382380546,
  "in_reply_to_status_id" : 211948170358423552,
  "created_at" : "2012-06-10 23:25:06 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u26A1\uFE0FJay Bakker\u26A1\uFE0F",
      "screen_name" : "jaybakker",
      "indices" : [ 3, 13 ],
      "id_str" : "15957907",
      "id" : 15957907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/kLAoL5AW",
      "expanded_url" : "http:\/\/sophia.saved.by",
      "display_url" : "sophia.saved.by"
    }, {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/l5VxnBl3",
      "expanded_url" : "http:\/\/sophiasavedbygrace.blogspot.com\/2012\/06\/thank-you-mr-driscoll.html?spref=tw",
      "display_url" : "sophiasavedbygrace.blogspot.com\/2012\/06\/thank-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211961022066601984",
  "text" : "RT @jaybakker: http:\/\/t.co\/kLAoL5AW.grace: Thank You, Mr. Driscoll http:\/\/t.co\/l5VxnBl3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/kLAoL5AW",
        "expanded_url" : "http:\/\/sophia.saved.by",
        "display_url" : "sophia.saved.by"
      }, {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/l5VxnBl3",
        "expanded_url" : "http:\/\/sophiasavedbygrace.blogspot.com\/2012\/06\/thank-you-mr-driscoll.html?spref=tw",
        "display_url" : "sophiasavedbygrace.blogspot.com\/2012\/06\/thank-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "211951823744008193",
    "text" : "http:\/\/t.co\/kLAoL5AW.grace: Thank You, Mr. Driscoll http:\/\/t.co\/l5VxnBl3",
    "id" : 211951823744008193,
    "created_at" : "2012-06-10 22:43:47 +0000",
    "user" : {
      "name" : "\u26A1\uFE0FJay Bakker\u26A1\uFE0F",
      "screen_name" : "jaybakker",
      "protected" : false,
      "id_str" : "15957907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735129074495070208\/JzkXuQ-D_normal.jpg",
      "id" : 15957907,
      "verified" : true
    }
  },
  "id" : 211961022066601984,
  "created_at" : "2012-06-10 23:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211837975657586689",
  "text" : "RT @OMGFacts: A theory says the longer an Internet discussion goes on, chances of a Hitler or Nazi reference approach 100%! ---&gt; http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/q4KVG3pk",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/URK",
        "display_url" : "omgf.ac\/ts\/URK"
      } ]
    },
    "geo" : { },
    "id_str" : "211835568185819136",
    "text" : "A theory says the longer an Internet discussion goes on, chances of a Hitler or Nazi reference approach 100%! ---&gt; http:\/\/t.co\/q4KVG3pk",
    "id" : 211835568185819136,
    "created_at" : "2012-06-10 15:01:49 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 211837975657586689,
  "created_at" : "2012-06-10 15:11:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "indices" : [ 3, 16 ],
      "id_str" : "525383338",
      "id" : 525383338
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 18, 32 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211837645502955521",
  "text" : "RT @ClosureForKC: @biblealsosays These are spiritual things we are discussing. None of your \"evidence\"will erase my belief in the spirit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BibleAlsoSays",
        "screen_name" : "BibleAlsoSays",
        "indices" : [ 0, 14 ],
        "id_str" : "2511428924",
        "id" : 2511428924
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211835827456708609",
    "text" : "@biblealsosays These are spiritual things we are discussing. None of your \"evidence\"will erase my belief in the spiritual world.",
    "id" : 211835827456708609,
    "created_at" : "2012-06-10 15:02:51 +0000",
    "user" : {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "protected" : false,
      "id_str" : "525383338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2036373342\/Kurt_Cobain_normal_normal.jpg",
      "id" : 525383338,
      "verified" : false
    }
  },
  "id" : 211837645502955521,
  "created_at" : "2012-06-10 15:10:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "indices" : [ 3, 16 ],
      "id_str" : "525383338",
      "id" : 525383338
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 18, 32 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Pandora's Daddy",
      "screen_name" : "sircraig01",
      "indices" : [ 33, 44 ],
      "id_str" : "258584906",
      "id" : 258584906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211823224059727874",
  "text" : "RT @ClosureForKC: @biblealsosays @sircraig01 Why are my beliefs illusions,but yours are freethinking?I am capable of choosing my own pat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BibleAlsoSays",
        "screen_name" : "BibleAlsoSays",
        "indices" : [ 0, 14 ],
        "id_str" : "2511428924",
        "id" : 2511428924
      }, {
        "name" : "Pandora's Daddy",
        "screen_name" : "sircraig01",
        "indices" : [ 15, 26 ],
        "id_str" : "258584906",
        "id" : 258584906
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211806038243020800",
    "text" : "@biblealsosays @sircraig01 Why are my beliefs illusions,but yours are freethinking?I am capable of choosing my own path,as are you.",
    "id" : 211806038243020800,
    "created_at" : "2012-06-10 13:04:29 +0000",
    "user" : {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "protected" : false,
      "id_str" : "525383338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2036373342\/Kurt_Cobain_normal_normal.jpg",
      "id" : 525383338,
      "verified" : false
    }
  },
  "id" : 211823224059727874,
  "created_at" : "2012-06-10 14:12:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211809307988197377",
  "text" : "RT @AniKnits: Being poor is not a crime. Parenting while black is not a crime. Opting out of government schools is not a crime. #BringNi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 114, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211805801642332160",
    "text" : "Being poor is not a crime. Parenting while black is not a crime. Opting out of government schools is not a crime. #BringNickHome!",
    "id" : 211805801642332160,
    "created_at" : "2012-06-10 13:03:32 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 211809307988197377,
  "created_at" : "2012-06-10 13:17:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/uNuyv2nN",
      "expanded_url" : "http:\/\/yfrog.com\/h4q35lkj",
      "display_url" : "yfrog.com\/h4q35lkj"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/xtfqyD8m",
      "expanded_url" : "http:\/\/po.st\/L84VO9",
      "display_url" : "po.st\/L84VO9"
    } ]
  },
  "geo" : { },
  "id_str" : "211809205085147136",
  "text" : "RT @AniKnits: This is what the police\/Social Worker said after the FIRST search warrant! http:\/\/t.co\/uNuyv2nN http:\/\/t.co\/xtfqyD8m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/uNuyv2nN",
        "expanded_url" : "http:\/\/yfrog.com\/h4q35lkj",
        "display_url" : "yfrog.com\/h4q35lkj"
      }, {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/xtfqyD8m",
        "expanded_url" : "http:\/\/po.st\/L84VO9",
        "display_url" : "po.st\/L84VO9"
      } ]
    },
    "geo" : { },
    "id_str" : "211806482595979267",
    "text" : "This is what the police\/Social Worker said after the FIRST search warrant! http:\/\/t.co\/uNuyv2nN http:\/\/t.co\/xtfqyD8m",
    "id" : 211806482595979267,
    "created_at" : "2012-06-10 13:06:15 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 211809205085147136,
  "created_at" : "2012-06-10 13:17:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "veggiexperience",
      "indices" : [ 3, 19 ],
      "id_str" : "19546244",
      "id" : 19546244
    }, {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 21, 30 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211808937907978240",
  "text" : "RT @veggiexperience: @AniKnits Kids should not be stolen from their parents on the basis of opinion. I hope they can live with themselve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "aniknits",
        "screen_name" : "AniKnits",
        "indices" : [ 0, 9 ],
        "id_str" : "184401626",
        "id" : 184401626
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 117, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211806928098164736",
    "in_reply_to_user_id" : 184401626,
    "text" : "@AniKnits Kids should not be stolen from their parents on the basis of opinion. I hope they can live with themselves #BringNickHome",
    "id" : 211806928098164736,
    "created_at" : "2012-06-10 13:08:01 +0000",
    "in_reply_to_screen_name" : "AniKnits",
    "in_reply_to_user_id_str" : "184401626",
    "user" : {
      "name" : "Clare",
      "screen_name" : "veggiexperience",
      "protected" : false,
      "id_str" : "19546244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644106648311713793\/qqZTTrgs_normal.jpg",
      "id" : 19546244,
      "verified" : false
    }
  },
  "id" : 211808937907978240,
  "created_at" : "2012-06-10 13:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringNickHome",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211808768974004224",
  "text" : "RT @AniKnits: Please do what you can to spread the word. The more people know about this injustice the better. #BringNickHome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211807840883580928",
    "text" : "Please do what you can to spread the word. The more people know about this injustice the better. #BringNickHome",
    "id" : 211807840883580928,
    "created_at" : "2012-06-10 13:11:39 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 211808768974004224,
  "created_at" : "2012-06-10 13:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211808712896151552",
  "text" : "RT @AniKnits: There is no way I am going to let him languish in foster care until July 11th. Not when I KNOW the damage that is being do ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211808157629038593",
    "text" : "There is no way I am going to let him languish in foster care until July 11th. Not when I KNOW the damage that is being done. #BringNickHome",
    "id" : 211808157629038593,
    "created_at" : "2012-06-10 13:12:54 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 211808712896151552,
  "created_at" : "2012-06-10 13:15:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 3, 15 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211504032789962752",
  "geo" : { },
  "id_str" : "211507224265244673",
  "in_reply_to_user_id" : 14676842,
  "text" : "oh @muichimotsu I hate that when they won't let you save them..LOL",
  "id" : 211507224265244673,
  "in_reply_to_status_id" : 211504032789962752,
  "created_at" : "2012-06-09 17:17:06 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 32, 44 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211487249047633923",
  "geo" : { },
  "id_str" : "211488184796844034",
  "in_reply_to_user_id" : 14676842,
  "text" : "we're in the information age... @muichimotsu we should be like Star Trek by now... sigh.",
  "id" : 211488184796844034,
  "in_reply_to_status_id" : 211487249047633923,
  "created_at" : "2012-06-09 16:01:27 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211485325262987265",
  "text" : "it's 2012.. everyone should have ez access to internet 24\/7 !!!",
  "id" : 211485325262987265,
  "created_at" : "2012-06-09 15:50:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/zfq1LQOz",
      "expanded_url" : "http:\/\/straighttalk.com",
      "display_url" : "straighttalk.com"
    } ]
  },
  "geo" : { },
  "id_str" : "211474190166007810",
  "text" : "anyone familiar w the phones \/ plans on http:\/\/t.co\/zfq1LQOz? they have unlimited data for 45\/mo ...",
  "id" : 211474190166007810,
  "created_at" : "2012-06-09 15:05:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211464555317035008",
  "text" : "i love it when my bluebird visits me : )",
  "id" : 211464555317035008,
  "created_at" : "2012-06-09 14:27:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211282207048876033",
  "geo" : { },
  "id_str" : "211282962497548288",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell yup...hehe",
  "id" : 211282962497548288,
  "in_reply_to_status_id" : 211282207048876033,
  "created_at" : "2012-06-09 02:25:58 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211271748165967872",
  "geo" : { },
  "id_str" : "211281887824584706",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell hey, that looks just like one of the dishes on my porch..LOL",
  "id" : 211281887824584706,
  "in_reply_to_status_id" : 211271748165967872,
  "created_at" : "2012-06-09 02:21:42 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arya",
      "screen_name" : "wildwhispers",
      "indices" : [ 3, 16 ],
      "id_str" : "2421262108",
      "id" : 2421262108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211196113410199554",
  "text" : "RT @WildWhispers: Seven of these little fellas have made it through their first few weeks. Still hanging around our pond http:\/\/t.co\/Pl3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/Pl3YWQLS",
        "expanded_url" : "http:\/\/twitpic.com\/98yvfu",
        "display_url" : "twitpic.com\/98yvfu"
      } ]
    },
    "geo" : { },
    "id_str" : "211195000858476544",
    "text" : "Seven of these little fellas have made it through their first few weeks. Still hanging around our pond http:\/\/t.co\/Pl3YWQLS",
    "id" : 211195000858476544,
    "created_at" : "2012-06-08 20:36:26 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 211196113410199554,
  "created_at" : "2012-06-08 20:40:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211138172627861504",
  "text" : "@Skeptical_Lady I had to stop looking.. it was making me nauseous.. o-O",
  "id" : 211138172627861504,
  "created_at" : "2012-06-08 16:50:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211132046792327168",
  "text" : "omg'ness @Skeptical_Lady makes me cringe. \"separation of church and state found nowhere in constitution\" ?? (on  \/_timtebow.htm page)",
  "id" : 211132046792327168,
  "created_at" : "2012-06-08 16:26:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 9, 19 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211107146916577280",
  "geo" : { },
  "id_str" : "211108708959264769",
  "in_reply_to_user_id" : 48215218,
  "text" : "gentle.. @bend_time I taught our aussie \"gentle\" .. she knows it means to be gentle, careful, no jump.. such a good girl! : )",
  "id" : 211108708959264769,
  "in_reply_to_status_id" : 211107146916577280,
  "created_at" : "2012-06-08 14:53:33 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 29, 43 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211101962169622530",
  "text" : "I only want ppl to follow me @BibleAlsoSays if they are interested in what I say... not to pad my numbers...",
  "id" : 211101962169622530,
  "created_at" : "2012-06-08 14:26:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211090142851641344",
  "geo" : { },
  "id_str" : "211099319510634498",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time plasma?",
  "id" : 211099319510634498,
  "in_reply_to_status_id" : 211090142851641344,
  "created_at" : "2012-06-08 14:16:14 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211090695606378496",
  "geo" : { },
  "id_str" : "211098785567342593",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time that's got 2B worth something!",
  "id" : 211098785567342593,
  "in_reply_to_status_id" : 211090695606378496,
  "created_at" : "2012-06-08 14:14:07 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210914228259913728",
  "text" : "the world is just crazy...",
  "id" : 210914228259913728,
  "created_at" : "2012-06-08 02:00:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe Ort\u00EDz",
      "screen_name" : "TUSK81",
      "indices" : [ 3, 10 ],
      "id_str" : "14526877",
      "id" : 14526877
    }, {
      "name" : "Manny Pacquiao",
      "screen_name" : "mannypacquiao",
      "indices" : [ 27, 41 ],
      "id_str" : "3281998848",
      "id" : 3281998848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210914081866121216",
  "text" : "RT @TUSK81: Tattooed boxer @MannyPacquiao hates gay \"sin.\" Leviticus 19:28 tells me God hates tattoos. Welcome to the club, Manny.  http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Manny Pacquiao",
        "screen_name" : "mannypacquiao",
        "indices" : [ 15, 29 ],
        "id_str" : "3281998848",
        "id" : 3281998848
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/TYqUjzHc",
        "expanded_url" : "http:\/\/www.towleroad.com\/2012\/06\/manny-pacquiao-i-oppose-gay-sin.html#.T9C-Oi6pydg.twitter",
        "display_url" : "towleroad.com\/2012\/06\/manny-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "210747772977160192",
    "text" : "Tattooed boxer @MannyPacquiao hates gay \"sin.\" Leviticus 19:28 tells me God hates tattoos. Welcome to the club, Manny.  http:\/\/t.co\/TYqUjzHc",
    "id" : 210747772977160192,
    "created_at" : "2012-06-07 14:59:19 +0000",
    "user" : {
      "name" : "Gabe Ort\u00EDz",
      "screen_name" : "TUSK81",
      "protected" : false,
      "id_str" : "14526877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725518568691888130\/_ClkDZ0d_normal.jpg",
      "id" : 14526877,
      "verified" : true
    }
  },
  "id" : 210914081866121216,
  "created_at" : "2012-06-08 02:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210912498633805824",
  "text" : "RT @AniKnits: @raisinglovies I have to have a \"stable home.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "210895400587112449",
    "geo" : { },
    "id_str" : "210900552563957760",
    "in_reply_to_user_id" : 15907290,
    "text" : "@raisinglovies I have to have a \"stable home.\"",
    "id" : 210900552563957760,
    "in_reply_to_status_id" : 210895400587112449,
    "created_at" : "2012-06-08 01:06:24 +0000",
    "in_reply_to_screen_name" : "gypsio",
    "in_reply_to_user_id_str" : "15907290",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 210912498633805824,
  "created_at" : "2012-06-08 01:53:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210794212298473472",
  "text" : "RT @SheilaWalsh: Love is patient and kind. Love is not jealous or boastful or proud or rude. It does not demand its own way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210791305763233792",
    "text" : "Love is patient and kind. Love is not jealous or boastful or proud or rude. It does not demand its own way.",
    "id" : 210791305763233792,
    "created_at" : "2012-06-07 17:52:18 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 210794212298473472,
  "created_at" : "2012-06-07 18:03:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209803968132554752",
  "geo" : { },
  "id_str" : "210786252285415424",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits I hope your son is finally back w you! ((hugs))",
  "id" : 210786252285415424,
  "in_reply_to_status_id" : 209803968132554752,
  "created_at" : "2012-06-07 17:32:13 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pizza Love",
      "screen_name" : "YEStoPizza",
      "indices" : [ 3, 14 ],
      "id_str" : "563436150",
      "id" : 563436150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PIZZA",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210778582451109889",
  "text" : "RT @YEStoPizza: #PIZZA is the answer to all life's questions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PIZZA",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209066237022572544",
    "text" : "#PIZZA is the answer to all life's questions.",
    "id" : 209066237022572544,
    "created_at" : "2012-06-02 23:37:29 +0000",
    "user" : {
      "name" : "Pizza Love",
      "screen_name" : "YEStoPizza",
      "protected" : false,
      "id_str" : "563436150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2166200763\/grappellis_pizza_1_normal.jpg",
      "id" : 563436150,
      "verified" : false
    }
  },
  "id" : 210778582451109889,
  "created_at" : "2012-06-07 17:01:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OMGFacts",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/TXYii3sl",
      "expanded_url" : "http:\/\/www.omg-facts.com\/Science\/Didaskaleinophobia-is-the-fear-of-going\/51422?tweet",
      "display_url" : "omg-facts.com\/Science\/Didask\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210778481712316418",
  "text" : "Didaskaleinophobia is the fear of going to school!   http:\/\/t.co\/TXYii3sl #OMGFacts",
  "id" : 210778481712316418,
  "created_at" : "2012-06-07 17:01:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210778367920840706",
  "text" : "@Skeptical_Lady I appreciate you not getting nitpicky w me. we're all just trying to make our way thru this tough thing called LIFE... : )",
  "id" : 210778367920840706,
  "created_at" : "2012-06-07 17:00:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queer Voices",
      "screen_name" : "huffpostgay",
      "indices" : [ 3, 15 ],
      "id_str" : "4343856743",
      "id" : 4343856743
    }, {
      "name" : "Amelia",
      "screen_name" : "Amelia_blogger",
      "indices" : [ 78, 93 ],
      "id_str" : "400493365",
      "id" : 400493365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210777195638042624",
  "text" : "RT @huffpostgay: Confronted by family &amp; friends about her gay 7 year old, @Amelia_Blogger says her son doesn't need to prove anythin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amelia",
        "screen_name" : "Amelia_blogger",
        "indices" : [ 61, 76 ],
        "id_str" : "400493365",
        "id" : 400493365
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/r33rZkEH",
        "expanded_url" : "http:\/\/huff.to\/KKp0WJ",
        "display_url" : "huff.to\/KKp0WJ"
      } ]
    },
    "geo" : { },
    "id_str" : "210760978831392768",
    "text" : "Confronted by family &amp; friends about her gay 7 year old, @Amelia_Blogger says her son doesn't need to prove anything  http:\/\/t.co\/r33rZkEH",
    "id" : 210760978831392768,
    "created_at" : "2012-06-07 15:51:47 +0000",
    "user" : {
      "name" : "huffpostqueer",
      "screen_name" : "huffpostqueer",
      "protected" : false,
      "id_str" : "366606110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614479428668796928\/XaFrYuE1_normal.png",
      "id" : 366606110,
      "verified" : true
    }
  },
  "id" : 210777195638042624,
  "created_at" : "2012-06-07 16:56:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210774275752341504",
  "text" : "RT @shanecrash: I've never met anyone who wasn't important.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210767479381831682",
    "text" : "I've never met anyone who wasn't important.",
    "id" : 210767479381831682,
    "created_at" : "2012-06-07 16:17:37 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 210774275752341504,
  "created_at" : "2012-06-07 16:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210759223951364097",
  "text" : "@Skeptical_Lady all that matters is whats in your heart.. atheist or not. death is just a continuation of the soul.. not heaven or hell.",
  "id" : 210759223951364097,
  "created_at" : "2012-06-07 15:44:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 28, 40 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Duck",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "photo",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "birds",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/7QVnNyNr",
      "expanded_url" : "http:\/\/www.martinbelan.com\/p738014693\/e1006bc35",
      "display_url" : "martinbelan.com\/p738014693\/e10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210757488822325249",
  "text" : "RT @KerriFar: LOVE this! RT @martinbelan: Wood #Duck Hen with Chicks http:\/\/t.co\/7QVnNyNr #photo #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Belan",
        "screen_name" : "MartinBelan",
        "indices" : [ 14, 26 ],
        "id_str" : "28461779",
        "id" : 28461779
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Duck",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "photo",
        "indices" : [ 76, 82 ]
      }, {
        "text" : "birds",
        "indices" : [ 83, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/7QVnNyNr",
        "expanded_url" : "http:\/\/www.martinbelan.com\/p738014693\/e1006bc35",
        "display_url" : "martinbelan.com\/p738014693\/e10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "210756971266187264",
    "text" : "LOVE this! RT @martinbelan: Wood #Duck Hen with Chicks http:\/\/t.co\/7QVnNyNr #photo #birds",
    "id" : 210756971266187264,
    "created_at" : "2012-06-07 15:35:52 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 210757488822325249,
  "created_at" : "2012-06-07 15:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210754799518494721",
  "text" : "@BibleAlsoSays chicken!! lol.. well, someone ought to get that kid in the right direction!",
  "id" : 210754799518494721,
  "created_at" : "2012-06-07 15:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/Lb0QMxql",
      "expanded_url" : "http:\/\/www.caidencowgerprogram.com\/radio.html",
      "display_url" : "caidencowgerprogram.com\/radio.html"
    } ]
  },
  "geo" : { },
  "id_str" : "210753066155245569",
  "text" : "@biblealsosays http:\/\/t.co\/Lb0QMxql - he's asking for ppl to call in to debate LIVE",
  "id" : 210753066155245569,
  "created_at" : "2012-06-07 15:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210750828494077955",
  "geo" : { },
  "id_str" : "210752454747361281",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields a very specific niche of staunch conservatives who are obsessed w negating homosexuality",
  "id" : 210752454747361281,
  "in_reply_to_status_id" : 210750828494077955,
  "created_at" : "2012-06-07 15:17:55 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210750828494077955",
  "geo" : { },
  "id_str" : "210751718676365312",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields I suppose anyone can have a radio show these days w all the diff tech, etc. the kid is referenced in my prev tweet...",
  "id" : 210751718676365312,
  "in_reply_to_status_id" : 210750828494077955,
  "created_at" : "2012-06-07 15:14:59 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WanderingCatStirFry",
      "screen_name" : "Skwerlbait",
      "indices" : [ 3, 14 ],
      "id_str" : "185346206",
      "id" : 185346206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210749719360704514",
  "text" : "RT @Skwerlbait: My neighbor's pissed at me for feeding my 2 \"pet\" crows because they make noise &amp; poop on his roof. I'd do it myself ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210745893379510273",
    "text" : "My neighbor's pissed at me for feeding my 2 \"pet\" crows because they make noise &amp; poop on his roof. I'd do it myself if my ladder reached.",
    "id" : 210745893379510273,
    "created_at" : "2012-06-07 14:51:51 +0000",
    "user" : {
      "name" : "WanderingCatStirFry",
      "screen_name" : "Skwerlbait",
      "protected" : false,
      "id_str" : "185346206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565394947491512320\/C1ZBkmSP_normal.jpeg",
      "id" : 185346206,
      "verified" : false
    }
  },
  "id" : 210749719360704514,
  "created_at" : "2012-06-07 15:07:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210749475117993987",
  "text" : "he's 14, has a radio show, website, following.. he's on twitter, too.. really thinks gay is a choice bcuz it's encouraged.. OMG..",
  "id" : 210749475117993987,
  "created_at" : "2012-06-07 15:06:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210745856633212931",
  "text" : "RT @abandontheherd: The light within me honors the light within you. Namaste",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210744791053500417",
    "text" : "The light within me honors the light within you. Namaste",
    "id" : 210744791053500417,
    "created_at" : "2012-06-07 14:47:28 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 210745856633212931,
  "created_at" : "2012-06-07 14:51:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Free",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "wildflowers",
      "indices" : [ 64, 76 ]
    }, {
      "text" : "quote",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/Y4YtZ1LC",
      "expanded_url" : "http:\/\/ow.ly\/bq5m3",
      "display_url" : "ow.ly\/bq5m3"
    } ]
  },
  "geo" : { },
  "id_str" : "210739192181960705",
  "text" : "RT @KerriFar: #Free Calendar for June ~ http:\/\/t.co\/Y4YtZ1LC  ~ #wildflowers &amp; #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Free",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "wildflowers",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "quote",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/Y4YtZ1LC",
        "expanded_url" : "http:\/\/ow.ly\/bq5m3",
        "display_url" : "ow.ly\/bq5m3"
      } ]
    },
    "geo" : { },
    "id_str" : "210738015209930754",
    "text" : "#Free Calendar for June ~ http:\/\/t.co\/Y4YtZ1LC  ~ #wildflowers &amp; #quote",
    "id" : 210738015209930754,
    "created_at" : "2012-06-07 14:20:32 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 210739192181960705,
  "created_at" : "2012-06-07 14:25:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "nature",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/r1Y6JfHF",
      "expanded_url" : "http:\/\/ow.ly\/bq7g1",
      "display_url" : "ow.ly\/bq7g1"
    } ]
  },
  "geo" : { },
  "id_str" : "210730444470235137",
  "text" : "RT @KerriFar: Smiling Woodpecker :)  http:\/\/t.co\/r1Y6JfHF  ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 47, 53 ]
      }, {
        "text" : "nature",
        "indices" : [ 54, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/r1Y6JfHF",
        "expanded_url" : "http:\/\/ow.ly\/bq7g1",
        "display_url" : "ow.ly\/bq7g1"
      } ]
    },
    "geo" : { },
    "id_str" : "210729151353733120",
    "text" : "Smiling Woodpecker :)  http:\/\/t.co\/r1Y6JfHF  ~ #birds #nature",
    "id" : 210729151353733120,
    "created_at" : "2012-06-07 13:45:19 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 210730444470235137,
  "created_at" : "2012-06-07 13:50:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210725019658100736",
  "geo" : { },
  "id_str" : "210727913920790529",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen uh-oh.. pissed off your gal, did ya? lol",
  "id" : 210727913920790529,
  "in_reply_to_status_id" : 210725019658100736,
  "created_at" : "2012-06-07 13:40:24 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210536547479584768",
  "geo" : { },
  "id_str" : "210539645925203968",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska sweet waddle butts! : )",
  "id" : 210539645925203968,
  "in_reply_to_status_id" : 210536547479584768,
  "created_at" : "2012-06-07 01:12:17 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210527039973896193",
  "text" : "omg.. girl having legs broken to gain 1 inch! 1 freakin' inch! (taboo on natgeotv)",
  "id" : 210527039973896193,
  "created_at" : "2012-06-07 00:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "posterous",
      "screen_name" : "posterous",
      "indices" : [ 42, 52 ],
      "id_str" : "15503880",
      "id" : 15503880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210515440319987713",
  "text" : "I cant get any picture onto my profile on @posterous .. I click choose file but the pic box does not change..",
  "id" : 210515440319987713,
  "created_at" : "2012-06-06 23:36:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 3, 18 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JulianneGarska\/status\/210511536639315970\/photo\/1",
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/WzbR3Bzc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuvjIJLCEAUAtA1.jpg",
      "id_str" : "210511536643510277",
      "id" : 210511536643510277,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuvjIJLCEAUAtA1.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WzbR3Bzc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210513503046475778",
  "text" : "RT @JulianneGarska: Sneaking up on geese: http:\/\/t.co\/WzbR3Bzc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JulianneGarska\/status\/210511536639315970\/photo\/1",
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/WzbR3Bzc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AuvjIJLCEAUAtA1.jpg",
        "id_str" : "210511536643510277",
        "id" : 210511536643510277,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuvjIJLCEAUAtA1.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WzbR3Bzc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210511536639315970",
    "text" : "Sneaking up on geese: http:\/\/t.co\/WzbR3Bzc",
    "id" : 210511536639315970,
    "created_at" : "2012-06-06 23:20:38 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 210513503046475778,
  "created_at" : "2012-06-06 23:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 23, 39 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "showingtheloveNOT",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/ctOtIKyj",
      "expanded_url" : "http:\/\/bit.ly\/Ky8UAb",
      "display_url" : "bit.ly\/Ky8UAb"
    } ]
  },
  "in_reply_to_status_id_str" : "210508268903215104",
  "geo" : { },
  "id_str" : "210512475987251200",
  "in_reply_to_user_id" : 116009507,
  "text" : "#showingtheloveNOT! RT @ChristnNitemare Pastor John Hagee tells atheists to leave America http:\/\/t.co\/ctOtIKyj",
  "id" : 210512475987251200,
  "in_reply_to_status_id" : 210508268903215104,
  "created_at" : "2012-06-06 23:24:20 +0000",
  "in_reply_to_screen_name" : "ChristnNitemare",
  "in_reply_to_user_id_str" : "116009507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210456941359661057",
  "text" : "aww.. poor deer had been laying in grass after hit by car earlier (had just heard 2 gun shots. hubby went to investigate) : (",
  "id" : 210456941359661057,
  "created_at" : "2012-06-06 19:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WoolyBumblebee \u2718",
      "screen_name" : "WoolyBumblebee",
      "indices" : [ 3, 18 ],
      "id_str" : "97282602",
      "id" : 97282602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210445938383265795",
  "text" : "RT @WoolyBumblebee: I am all for womens rights &amp; being equal. But don't bash men in the process, or you are no better than what u ar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210437971571249152",
    "text" : "I am all for womens rights &amp; being equal. But don't bash men in the process, or you are no better than what u are fighting against.",
    "id" : 210437971571249152,
    "created_at" : "2012-06-06 18:28:16 +0000",
    "user" : {
      "name" : "WoolyBumblebee \u2718",
      "screen_name" : "WoolyBumblebee",
      "protected" : false,
      "id_str" : "97282602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799845160670461952\/IXV4TeTi_normal.jpg",
      "id" : 97282602,
      "verified" : false
    }
  },
  "id" : 210445938383265795,
  "created_at" : "2012-06-06 18:59:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210444910879449089",
  "text" : "RT @Buddhaworld: sometimes its nice to see somebody more fucked up than oneself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210444436847591424",
    "text" : "sometimes its nice to see somebody more fucked up than oneself.",
    "id" : 210444436847591424,
    "created_at" : "2012-06-06 18:53:58 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 210444910879449089,
  "created_at" : "2012-06-06 18:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/lrRqcO0Y",
      "expanded_url" : "http:\/\/bit.ly\/Mkc",
      "display_url" : "bit.ly\/Mkc"
    } ]
  },
  "in_reply_to_status_id_str" : "210394299618181121",
  "geo" : { },
  "id_str" : "210398710226632708",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny did u see this one? made me chuckle! : D http:\/\/t.co\/lrRqcO0Y Creationists believe God put dinosaur bones ...",
  "id" : 210398710226632708,
  "in_reply_to_status_id" : 210394299618181121,
  "created_at" : "2012-06-06 15:52:16 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life With Dogs",
      "screen_name" : "LifeWithDogsTV",
      "indices" : [ 75, 90 ],
      "id_str" : "18418936",
      "id" : 18418936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/CwqQUo2L",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2012\/06\/dog-saves-abandoned-newborn-baby\/",
      "display_url" : "lifewithdogs.tv\/2012\/06\/dog-sa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210396156046475266",
  "text" : "Dog Saves Abandoned Newborn Baby | Life With Dogs http:\/\/t.co\/CwqQUo2L via @LifeWithDogsTV",
  "id" : 210396156046475266,
  "created_at" : "2012-06-06 15:42:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/aYFjNnI9",
      "expanded_url" : "http:\/\/2.adam.pk\/L9UIs1",
      "display_url" : "2.adam.pk\/L9UIs1"
    } ]
  },
  "geo" : { },
  "id_str" : "210386551472009216",
  "text" : "RT @adampknave: You can now get my book STRANGE ANGEL for free, or pay what you want. DRM free epub\/mlobi\/pdf copies. http:\/\/t.co\/aYFjNnI9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/aYFjNnI9",
        "expanded_url" : "http:\/\/2.adam.pk\/L9UIs1",
        "display_url" : "2.adam.pk\/L9UIs1"
      } ]
    },
    "geo" : { },
    "id_str" : "210386002089492483",
    "text" : "You can now get my book STRANGE ANGEL for free, or pay what you want. DRM free epub\/mlobi\/pdf copies. http:\/\/t.co\/aYFjNnI9",
    "id" : 210386002089492483,
    "created_at" : "2012-06-06 15:01:46 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 210386551472009216,
  "created_at" : "2012-06-06 15:03:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210385600010911745",
  "text" : "RT @BrianMerritt: I find myself too often reflecting on the immoral passivity of the church in the face of great economic tragedy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210383221341437953",
    "text" : "I find myself too often reflecting on the immoral passivity of the church in the face of great economic tragedy.",
    "id" : 210383221341437953,
    "created_at" : "2012-06-06 14:50:43 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 210385600010911745,
  "created_at" : "2012-06-06 15:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210385199127732224",
  "text" : "RT @BrianMerritt: What does love your neighbor as yourself look like when they are losing their home?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210384682536275968",
    "text" : "What does love your neighbor as yourself look like when they are losing their home?",
    "id" : 210384682536275968,
    "created_at" : "2012-06-06 14:56:31 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 210385199127732224,
  "created_at" : "2012-06-06 14:58:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 114, 125 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/IEwXDX6W",
      "expanded_url" : "http:\/\/bit.ly\/L1Dv5L",
      "display_url" : "bit.ly\/L1Dv5L"
    } ]
  },
  "geo" : { },
  "id_str" : "210363102078836736",
  "text" : "Meghan Vogel: Inspiring photo shows Ohio runner help carry competitor across finish line http:\/\/t.co\/IEwXDX6W via @MailOnline",
  "id" : 210363102078836736,
  "created_at" : "2012-06-06 13:30:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210360060742877184",
  "text" : "@HEATHENRABBIT what a lovely avatar! i adore donkeys : )",
  "id" : 210360060742877184,
  "created_at" : "2012-06-06 13:18:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210359151417765888",
  "text" : "RT @CoyotesWisdom: Guys, stop arguing over who's right and who's smarter. Chances are, you're both wrong and stupid.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210354109776281601",
    "text" : "Guys, stop arguing over who's right and who's smarter. Chances are, you're both wrong and stupid.",
    "id" : 210354109776281601,
    "created_at" : "2012-06-06 12:55:02 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 210359151417765888,
  "created_at" : "2012-06-06 13:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life With Dogs",
      "screen_name" : "LifeWithDogsTV",
      "indices" : [ 3, 18 ],
      "id_str" : "18418936",
      "id" : 18418936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/ZGGRVvqK",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2012\/06\/hero-k-9-k-9-saves-life-of-handler-deputy\/",
      "display_url" : "lifewithdogs.tv\/2012\/06\/hero-k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210172300115456000",
  "text" : "RT @LifeWithDogsTV: Hero K-9 Saves Life of Handler, Deputy http:\/\/t.co\/ZGGRVvqK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/ZGGRVvqK",
        "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2012\/06\/hero-k-9-k-9-saves-life-of-handler-deputy\/",
        "display_url" : "lifewithdogs.tv\/2012\/06\/hero-k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "210171411216601088",
    "text" : "Hero K-9 Saves Life of Handler, Deputy http:\/\/t.co\/ZGGRVvqK",
    "id" : 210171411216601088,
    "created_at" : "2012-06-06 00:49:03 +0000",
    "user" : {
      "name" : "Life With Dogs",
      "screen_name" : "LifeWithDogsTV",
      "protected" : false,
      "id_str" : "18418936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788959945546993664\/nOy2XTo5_normal.jpg",
      "id" : 18418936,
      "verified" : false
    }
  },
  "id" : 210172300115456000,
  "created_at" : "2012-06-06 00:52:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Frank King",
      "screen_name" : "FrankKingPhotos",
      "indices" : [ 24, 40 ],
      "id_str" : "31593262",
      "id" : 31593262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/7ojByowL",
      "expanded_url" : "http:\/\/bit.ly\/MuAizB",
      "display_url" : "bit.ly\/MuAizB"
    } ]
  },
  "geo" : { },
  "id_str" : "210068027952218113",
  "text" : "RT @KerriFar: Super! RT @FrankKingPhotos:  Look at those ears!  Waterton Lakes National Park, Alberta: http:\/\/t.co\/7ojByowL #photography ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frank King",
        "screen_name" : "FrankKingPhotos",
        "indices" : [ 10, 26 ],
        "id_str" : "31593262",
        "id" : 31593262
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 110, 122 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/7ojByowL",
        "expanded_url" : "http:\/\/bit.ly\/MuAizB",
        "display_url" : "bit.ly\/MuAizB"
      } ]
    },
    "geo" : { },
    "id_str" : "210062336420093952",
    "text" : "Super! RT @FrankKingPhotos:  Look at those ears!  Waterton Lakes National Park, Alberta: http:\/\/t.co\/7ojByowL #photography #wildlife",
    "id" : 210062336420093952,
    "created_at" : "2012-06-05 17:35:38 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 210068027952218113,
  "created_at" : "2012-06-05 17:58:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210067076168171521",
  "text" : "RT @Buddhaworld: fear is mans biggest enemy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210065936244412416",
    "text" : "fear is mans biggest enemy.",
    "id" : 210065936244412416,
    "created_at" : "2012-06-05 17:49:56 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 210067076168171521,
  "created_at" : "2012-06-05 17:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bluebird",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "birds",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "nature",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/iKBCCVjC",
      "expanded_url" : "http:\/\/goo.gl\/Y6yBx",
      "display_url" : "goo.gl\/Y6yBx"
    } ]
  },
  "geo" : { },
  "id_str" : "210050178474971137",
  "text" : "RT @KerriFar: Baby #bluebird  in the blossoms ~ http:\/\/t.co\/iKBCCVjC ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bluebird",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "birds",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "nature",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/iKBCCVjC",
        "expanded_url" : "http:\/\/goo.gl\/Y6yBx",
        "display_url" : "goo.gl\/Y6yBx"
      } ]
    },
    "geo" : { },
    "id_str" : "210049839663288320",
    "text" : "Baby #bluebird  in the blossoms ~ http:\/\/t.co\/iKBCCVjC ~ #birds #nature",
    "id" : 210049839663288320,
    "created_at" : "2012-06-05 16:45:58 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 210050178474971137,
  "created_at" : "2012-06-05 16:47:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210050070664577025",
  "text" : "but the Universe did throw me some bones..",
  "id" : 210050070664577025,
  "created_at" : "2012-06-05 16:46:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210049647782277120",
  "text" : "bible study this am.. it's teaching me \"patience\" .. lol",
  "id" : 210049647782277120,
  "created_at" : "2012-06-05 16:45:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209992079730950145",
  "text" : "RT @Buddhaworld: there is a little hole in your false reality, to find it is up to you. But the rewards are life changing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209985188854366209",
    "text" : "there is a little hole in your false reality, to find it is up to you. But the rewards are life changing.",
    "id" : 209985188854366209,
    "created_at" : "2012-06-05 12:29:05 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 209992079730950145,
  "created_at" : "2012-06-05 12:56:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 3, 17 ],
      "id_str" : "40923520",
      "id" : 40923520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TreeTuesday",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/45lw87x4",
      "expanded_url" : "http:\/\/bit.ly\/M3AH6r",
      "display_url" : "bit.ly\/M3AH6r"
    } ]
  },
  "geo" : { },
  "id_str" : "209991792291090432",
  "text" : "RT @GiveTreeGifts: Tree rings suggest ancient cosmic event http:\/\/t.co\/45lw87x4 #TreeTuesday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TreeTuesday",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/45lw87x4",
        "expanded_url" : "http:\/\/bit.ly\/M3AH6r",
        "display_url" : "bit.ly\/M3AH6r"
      } ]
    },
    "geo" : { },
    "id_str" : "209986947337297920",
    "text" : "Tree rings suggest ancient cosmic event http:\/\/t.co\/45lw87x4 #TreeTuesday",
    "id" : 209986947337297920,
    "created_at" : "2012-06-05 12:36:04 +0000",
    "user" : {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "protected" : false,
      "id_str" : "40923520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/400026192\/Tree-Angel_jpg_normal.jpg",
      "id" : 40923520,
      "verified" : false
    }
  },
  "id" : 209991792291090432,
  "created_at" : "2012-06-05 12:55:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/Er710F89",
      "expanded_url" : "http:\/\/nyti.ms\/KxFHDv",
      "display_url" : "nyti.ms\/KxFHDv"
    } ]
  },
  "geo" : { },
  "id_str" : "209782401063325697",
  "text" : "RT @YourAnonNews: If you get paid min wage in CA, MD, DC, NJ, or NY, you\u2019d need to work 130 hrs\/wk to afford rent http:\/\/t.co\/Er710F89 | ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OWS",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/Er710F89",
        "expanded_url" : "http:\/\/nyti.ms\/KxFHDv",
        "display_url" : "nyti.ms\/KxFHDv"
      } ]
    },
    "geo" : { },
    "id_str" : "209780633654923264",
    "text" : "If you get paid min wage in CA, MD, DC, NJ, or NY, you\u2019d need to work 130 hrs\/wk to afford rent http:\/\/t.co\/Er710F89 | #OWS",
    "id" : 209780633654923264,
    "created_at" : "2012-06-04 22:56:15 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787519608794157057\/dDnFKms0_normal.jpg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 209782401063325697,
  "created_at" : "2012-06-04 23:03:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 9, 21 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209781146198876162",
  "geo" : { },
  "id_str" : "209782323997188096",
  "in_reply_to_user_id" : 71118021,
  "text" : "omg'ness @CaroleODell how cute!",
  "id" : 209782323997188096,
  "in_reply_to_status_id" : 209781146198876162,
  "created_at" : "2012-06-04 23:02:58 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209772246523314176",
  "geo" : { },
  "id_str" : "209780147556057089",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits (((hugs)))",
  "id" : 209780147556057089,
  "in_reply_to_status_id" : 209772246523314176,
  "created_at" : "2012-06-04 22:54:19 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209772717560438784",
  "geo" : { },
  "id_str" : "209779457773412352",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOLOL.. i find them fascinating as well.",
  "id" : 209779457773412352,
  "in_reply_to_status_id" : 209772717560438784,
  "created_at" : "2012-06-04 22:51:34 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Mikey",
      "screen_name" : "fxmikey",
      "indices" : [ 67, 75 ],
      "id_str" : "269257413",
      "id" : 269257413
    }, {
      "name" : "Dyfed Edwards",
      "screen_name" : "dyfededwards",
      "indices" : [ 76, 89 ],
      "id_str" : "263616445",
      "id" : 263616445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209773086411722752",
  "geo" : { },
  "id_str" : "209778995284291584",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem you give that beautiful pup a hug and smooch from me! @fxmikey @dyfededwards",
  "id" : 209778995284291584,
  "in_reply_to_status_id" : 209773086411722752,
  "created_at" : "2012-06-04 22:49:44 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209708037731131392",
  "text" : "bleh.. yesterday and still today stomach feels like lead in it.. ugh.",
  "id" : 209708037731131392,
  "created_at" : "2012-06-04 18:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Giveaway",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "Nook",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "Kobo",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/qE4DdUPR",
      "expanded_url" : "http:\/\/ow.ly\/blaXX",
      "display_url" : "ow.ly\/blaXX"
    } ]
  },
  "geo" : { },
  "id_str" : "209658347299946496",
  "text" : "RT @JAScribbles: Swing by my book blog and enter my #Giveaway.  http:\/\/t.co\/qE4DdUPR  #Kindle #Nook &amp; #Kobo too!!  (even though the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Giveaway",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "Nook",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "Kobo",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/qE4DdUPR",
        "expanded_url" : "http:\/\/ow.ly\/blaXX",
        "display_url" : "ow.ly\/blaXX"
      } ]
    },
    "geo" : { },
    "id_str" : "209651989800435714",
    "text" : "Swing by my book blog and enter my #Giveaway.  http:\/\/t.co\/qE4DdUPR  #Kindle #Nook &amp; #Kobo too!!  (even though the title says Amazon)",
    "id" : 209651989800435714,
    "created_at" : "2012-06-04 14:25:04 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 209658347299946496,
  "created_at" : "2012-06-04 14:50:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EpicKindleThrillers",
      "screen_name" : "EKGthrillers",
      "indices" : [ 3, 16 ],
      "id_str" : "516623203",
      "id" : 516623203
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "kindle",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/AT4cjUb3",
      "expanded_url" : "http:\/\/ow.ly\/blgqy",
      "display_url" : "ow.ly\/blgqy"
    } ]
  },
  "geo" : { },
  "id_str" : "209657659354394624",
  "text" : "RT @EKGthrillers: June 4-5 THE NINTH DISTRICT \"Why rob a bank when you can rob The Fed?\" #free #kindle (US) http:\/\/t.co\/AT4cjUb3  (UK) h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 71, 76 ]
      }, {
        "text" : "kindle",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/AT4cjUb3",
        "expanded_url" : "http:\/\/ow.ly\/blgqy",
        "display_url" : "ow.ly\/blgqy"
      }, {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/ohT7w225",
        "expanded_url" : "http:\/\/ow.ly\/blgqz",
        "display_url" : "ow.ly\/blgqz"
      } ]
    },
    "geo" : { },
    "id_str" : "209634300000342017",
    "text" : "June 4-5 THE NINTH DISTRICT \"Why rob a bank when you can rob The Fed?\" #free #kindle (US) http:\/\/t.co\/AT4cjUb3  (UK) http:\/\/t.co\/ohT7w225...",
    "id" : 209634300000342017,
    "created_at" : "2012-06-04 13:14:46 +0000",
    "user" : {
      "name" : "EpicKindleThrillers",
      "screen_name" : "EKGthrillers",
      "protected" : false,
      "id_str" : "516623203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1877122182\/EKGButton_normal.jpg",
      "id" : 516623203,
      "verified" : false
    }
  },
  "id" : 209657659354394624,
  "created_at" : "2012-06-04 14:47:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209441013977190401",
  "text" : "not sure if I like this new dog trainer guy on tv...",
  "id" : 209441013977190401,
  "created_at" : "2012-06-04 00:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/EAGHo14t",
      "expanded_url" : "http:\/\/bit.ly\/4Tl8rV",
      "display_url" : "bit.ly\/4Tl8rV"
    } ]
  },
  "geo" : { },
  "id_str" : "209433574615687169",
  "text" : "RT @drbloem: Student Suspended And Assaulted For Handing Out ANTI-VACCINE Fliers  http:\/\/t.co\/EAGHo14t #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/EAGHo14t",
        "expanded_url" : "http:\/\/bit.ly\/4Tl8rV",
        "display_url" : "bit.ly\/4Tl8rV"
      } ]
    },
    "geo" : { },
    "id_str" : "209433045235802114",
    "text" : "Student Suspended And Assaulted For Handing Out ANTI-VACCINE Fliers  http:\/\/t.co\/EAGHo14t #health",
    "id" : 209433045235802114,
    "created_at" : "2012-06-03 23:55:03 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 209433574615687169,
  "created_at" : "2012-06-03 23:57:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209425364248838145",
  "geo" : { },
  "id_str" : "209426133295439872",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous heyyyy.. you got a GF now.. you're not supposed to notice cute girls anymore! ; ) LOLOL",
  "id" : 209426133295439872,
  "in_reply_to_status_id" : 209425364248838145,
  "created_at" : "2012-06-03 23:27:35 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 15, 24 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/rbANHGlI",
      "expanded_url" : "http:\/\/www.thebooksnoop.com\/2012\/06\/lets-read-ebook-giveaway.html?utm_source=feedburner&utm_medium=email&utm_campaign=Feed%3A+TheBookSnoop+%28The+Book+Snoop%29",
      "display_url" : "thebooksnoop.com\/2012\/06\/lets-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209396001193197568",
  "text" : "I entered this #giveaway for a chance to win a $10 #Kindle ebook. You should too! -  http:\/\/t.co\/rbANHGlI",
  "id" : 209396001193197568,
  "created_at" : "2012-06-03 21:27:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Heinemann",
      "screen_name" : "KatHeinemann",
      "indices" : [ 3, 16 ],
      "id_str" : "457706092",
      "id" : 457706092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GreedyEvilGOP",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/s2DP3Gev",
      "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2012\/06\/03\/holy-crap-scott-walker-might-have-a-love-child\/#.T8u9fx_qSxs.twitter",
      "display_url" : "rawstory.com\/rs\/2012\/06\/03\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209375234380406784",
  "text" : "RT @KatHeinemann: Pls. RT. Scott Walker might have a love child. #GreedyEvilGOP http:\/\/t.co\/s2DP3Gev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GreedyEvilGOP",
        "indices" : [ 47, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/s2DP3Gev",
        "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2012\/06\/03\/holy-crap-scott-walker-might-have-a-love-child\/#.T8u9fx_qSxs.twitter",
        "display_url" : "rawstory.com\/rs\/2012\/06\/03\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "209372809149952000",
    "text" : "Pls. RT. Scott Walker might have a love child. #GreedyEvilGOP http:\/\/t.co\/s2DP3Gev",
    "id" : 209372809149952000,
    "created_at" : "2012-06-03 19:55:42 +0000",
    "user" : {
      "name" : "Kathleen Heinemann",
      "screen_name" : "KatHeinemann",
      "protected" : false,
      "id_str" : "457706092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482700759876640768\/EJGxOdgc_normal.jpeg",
      "id" : 457706092,
      "verified" : false
    }
  },
  "id" : 209375234380406784,
  "created_at" : "2012-06-03 20:05:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209359052852043777",
  "text" : "RT @ducksandclucks: Chickens don't let grass grow. Chickens have a scorched Earth policy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209351408699441153",
    "text" : "Chickens don't let grass grow. Chickens have a scorched Earth policy.",
    "id" : 209351408699441153,
    "created_at" : "2012-06-03 18:30:40 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 209359052852043777,
  "created_at" : "2012-06-03 19:01:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209326686557310976",
  "geo" : { },
  "id_str" : "209327690929545216",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible LOLOL : D",
  "id" : 209327690929545216,
  "in_reply_to_status_id" : 209326686557310976,
  "created_at" : "2012-06-03 16:56:25 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209326341122822145",
  "text" : "im pretty sure the aliens are having back to back meetings on what to do w us. \"omg, they need 2B contained!\" LOL",
  "id" : 209326341122822145,
  "created_at" : "2012-06-03 16:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209325674656301057",
  "text" : "my DD doent think going to Mars good idea.. \"what if they find something they shouldnt.. then we're ALL in trouble!\" LOL",
  "id" : 209325674656301057,
  "created_at" : "2012-06-03 16:48:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mars One",
      "screen_name" : "MarsOneProject",
      "indices" : [ 3, 18 ],
      "id_str" : "594617548",
      "id" : 594617548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarsOne",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209322947792474112",
  "text" : "RT @MarsOneProject: #MarsOne mentioned on Mashable: One-way Ticket to Mars, Please: Startup Plans Space Colony in 2023 http:\/\/t.co\/o2EKE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 124, 133 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarsOne",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/o2EKEbLz",
        "expanded_url" : "http:\/\/mashable.com\/2012\/06\/02\/mars-one\/",
        "display_url" : "mashable.com\/2012\/06\/02\/mar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "209234154829774850",
    "text" : "#MarsOne mentioned on Mashable: One-way Ticket to Mars, Please: Startup Plans Space Colony in 2023 http:\/\/t.co\/o2EKEbLz via @mashable",
    "id" : 209234154829774850,
    "created_at" : "2012-06-03 10:44:44 +0000",
    "user" : {
      "name" : "Mars One",
      "screen_name" : "MarsOneProject",
      "protected" : false,
      "id_str" : "594617548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2263292962\/Mars_One_fingerprint_normal.png",
      "id" : 594617548,
      "verified" : true
    }
  },
  "id" : 209322947792474112,
  "created_at" : "2012-06-03 16:37:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "indices" : [ 3, 12 ],
      "id_str" : "8234572",
      "id" : 8234572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/NvAS4eln",
      "expanded_url" : "http:\/\/mars-one.com\/",
      "display_url" : "mars-one.com"
    } ]
  },
  "geo" : { },
  "id_str" : "209322005915385857",
  "text" : "RT @cantrell: Somewhat reminiscent of Containment: http:\/\/t.co\/NvAS4eln",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/NvAS4eln",
        "expanded_url" : "http:\/\/mars-one.com\/",
        "display_url" : "mars-one.com"
      } ]
    },
    "geo" : { },
    "id_str" : "209318304328855552",
    "text" : "Somewhat reminiscent of Containment: http:\/\/t.co\/NvAS4eln",
    "id" : 209318304328855552,
    "created_at" : "2012-06-03 16:19:07 +0000",
    "user" : {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "protected" : false,
      "id_str" : "8234572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3466700371\/ca68118063303c7fe19a3cf79e68a9f8_normal.jpeg",
      "id" : 8234572,
      "verified" : true
    }
  },
  "id" : 209322005915385857,
  "created_at" : "2012-06-03 16:33:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 3, 17 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209056741307060225",
  "geo" : { },
  "id_str" : "209062254627397632",
  "in_reply_to_user_id" : 280827427,
  "text" : "MT @deisidiamonia you're a puddle of water after a rainstorm, convinced the hole in the ground was made for you.",
  "id" : 209062254627397632,
  "in_reply_to_status_id" : 209056741307060225,
  "created_at" : "2012-06-02 23:21:40 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 108, 122 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Evan Minton",
      "screen_name" : "JesusFan2009",
      "indices" : [ 123, 136 ],
      "id_str" : "16446153",
      "id" : 16446153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209056741307060225",
  "geo" : { },
  "id_str" : "209061959189004289",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia plonker sounds so much nicer than idiot.. also thats a deep analogy.. love it. will ponder.  @BibleAlsoSays @JesusFan2009",
  "id" : 209061959189004289,
  "in_reply_to_status_id" : 209056741307060225,
  "created_at" : "2012-06-02 23:20:29 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209043068115095552",
  "text" : "umm.. Where is this hand basket going again??",
  "id" : 209043068115095552,
  "created_at" : "2012-06-02 22:05:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White Wolf",
      "screen_name" : "The_WhiteWolf_",
      "indices" : [ 3, 18 ],
      "id_str" : "116065011",
      "id" : 116065011
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dog",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/KkD7GU2B",
      "expanded_url" : "http:\/\/bit.ly\/Amazingdog",
      "display_url" : "bit.ly\/Amazingdog"
    } ]
  },
  "geo" : { },
  "id_str" : "209042105698500608",
  "text" : "RT @The_WhiteWolf_: A true story of unbelievable loyalty one #dog had for his owner http:\/\/t.co\/KkD7GU2B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dog",
        "indices" : [ 41, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/KkD7GU2B",
        "expanded_url" : "http:\/\/bit.ly\/Amazingdog",
        "display_url" : "bit.ly\/Amazingdog"
      } ]
    },
    "geo" : { },
    "id_str" : "209038297475973120",
    "text" : "A true story of unbelievable loyalty one #dog had for his owner http:\/\/t.co\/KkD7GU2B",
    "id" : 209038297475973120,
    "created_at" : "2012-06-02 21:46:28 +0000",
    "user" : {
      "name" : "White Wolf",
      "screen_name" : "The_WhiteWolf_",
      "protected" : false,
      "id_str" : "116065011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708594602\/Arctic_wolf_by_Arctic_Wolf_Alpine_normal.jpg",
      "id" : 116065011,
      "verified" : false
    }
  },
  "id" : 209042105698500608,
  "created_at" : "2012-06-02 22:01:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209026166764474369",
  "text" : "RT @Buddhaworld: there is only one reality, that what you believe in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209024778797973504",
    "text" : "there is only one reality, that what you believe in.",
    "id" : 209024778797973504,
    "created_at" : "2012-06-02 20:52:45 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 209026166764474369,
  "created_at" : "2012-06-02 20:58:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209026087479554049",
  "text" : "RT @AnnotatedBible: Evolution is a \"sacred cow\" to many atheists. You'll be automatically ridiculed for questioning any part of the theory.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209025299088818176",
    "text" : "Evolution is a \"sacred cow\" to many atheists. You'll be automatically ridiculed for questioning any part of the theory.",
    "id" : 209025299088818176,
    "created_at" : "2012-06-02 20:54:49 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 209026087479554049,
  "created_at" : "2012-06-02 20:57:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "racybaldhero",
      "screen_name" : "racybaldhero",
      "indices" : [ 3, 16 ],
      "id_str" : "2542860469",
      "id" : 2542860469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208958952380186626",
  "text" : "RT @racybaldhero: How to explain the Jubilee: \"Two very rich people waving from an expensive car at various events watched by the poor.\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jubileeprotest",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208892452587847680",
    "text" : "How to explain the Jubilee: \"Two very rich people waving from an expensive car at various events watched by the poor.\" #jubileeprotest",
    "id" : 208892452587847680,
    "created_at" : "2012-06-02 12:06:56 +0000",
    "user" : {
      "name" : "Rachel",
      "screen_name" : "racybearhold",
      "protected" : false,
      "id_str" : "126895093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799703033609383936\/Qe-tW3l6_normal.jpg",
      "id" : 126895093,
      "verified" : false
    }
  },
  "id" : 208958952380186626,
  "created_at" : "2012-06-02 16:31:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208957224402423808",
  "text" : "RT @Wylieknowords: \"Dear Bill Gates,many boring, stupid, uninspiring teachers, who kill a child's love of learning have high test scores ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208955241981419520",
    "text" : "\"Dear Bill Gates,many boring, stupid, uninspiring teachers, who kill a child's love of learning have high test scores.STOP TEACHING TO TESTS",
    "id" : 208955241981419520,
    "created_at" : "2012-06-02 16:16:26 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 208957224402423808,
  "created_at" : "2012-06-02 16:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    }, {
      "name" : "matt",
      "screen_name" : "matttammar",
      "indices" : [ 20, 31 ],
      "id_str" : "226736114",
      "id" : 226736114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208954261365727232",
  "text" : "RT @TheOracle13: RT @matttammar In my opinion, terms like \u2018Christian Nation\u2019 can only apply to a Theocracy; never to a true Democracy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "matt",
        "screen_name" : "matttammar",
        "indices" : [ 3, 14 ],
        "id_str" : "226736114",
        "id" : 226736114
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208951483813724161",
    "text" : "RT @matttammar In my opinion, terms like \u2018Christian Nation\u2019 can only apply to a Theocracy; never to a true Democracy.",
    "id" : 208951483813724161,
    "created_at" : "2012-06-02 16:01:30 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 208954261365727232,
  "created_at" : "2012-06-02 16:12:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/mDHMfusB",
      "expanded_url" : "http:\/\/huff.to\/JXgDI0",
      "display_url" : "huff.to\/JXgDI0"
    } ]
  },
  "geo" : { },
  "id_str" : "208954108818894848",
  "text" : "RT @HuffPostWeird: Cow sex ties up traffic in West Pennsylvania http:\/\/t.co\/mDHMfusB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/mDHMfusB",
        "expanded_url" : "http:\/\/huff.to\/JXgDI0",
        "display_url" : "huff.to\/JXgDI0"
      } ]
    },
    "geo" : { },
    "id_str" : "208952875563487232",
    "text" : "Cow sex ties up traffic in West Pennsylvania http:\/\/t.co\/mDHMfusB",
    "id" : 208952875563487232,
    "created_at" : "2012-06-02 16:07:02 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 208954108818894848,
  "created_at" : "2012-06-02 16:11:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208953887296720897",
  "text" : "RT @Wylieknowords: TWITTER SEX: \"Our Tweets sweetly commingled into a Twitter orgasm of mutual mind manipulation and stylish joy.\" Wrote ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208952552966995968",
    "text" : "TWITTER SEX: \"Our Tweets sweetly commingled into a Twitter orgasm of mutual mind manipulation and stylish joy.\" Wrote geek after novel read.",
    "id" : 208952552966995968,
    "created_at" : "2012-06-02 16:05:45 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 208953887296720897,
  "created_at" : "2012-06-02 16:11:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "indices" : [ 3, 19 ],
      "id_str" : "478216296",
      "id" : 478216296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208953243726913538",
  "text" : "RT @JesusWithIssues: I think we can all agree that nothing says \"I love you\" like pushing someone into a big lake of fire.  Glory!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208951121069346816",
    "text" : "I think we can all agree that nothing says \"I love you\" like pushing someone into a big lake of fire.  Glory!",
    "id" : 208951121069346816,
    "created_at" : "2012-06-02 16:00:04 +0000",
    "user" : {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "protected" : false,
      "id_str" : "478216296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2229020646\/jesus_leopard_normal.jpg",
      "id" : 478216296,
      "verified" : false
    }
  },
  "id" : 208953243726913538,
  "created_at" : "2012-06-02 16:08:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208939419401588736",
  "geo" : { },
  "id_str" : "208940526613958657",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver for awhile I was a tad jealous of their relationship. but I realized DH needed her more than I did. she came for him.",
  "id" : 208940526613958657,
  "in_reply_to_status_id" : 208939419401588736,
  "created_at" : "2012-06-02 15:17:58 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/IbhXVDvL",
      "expanded_url" : "http:\/\/bit.ly\/KkpenT",
      "display_url" : "bit.ly\/KkpenT"
    } ]
  },
  "geo" : { },
  "id_str" : "208938979398135808",
  "text" : "RT @ebookfriendly: This is funny: Nook version of War and Peace turns the word \u201Ckindled\u201D into \u201CNookd\u201D http:\/\/t.co\/IbhXVDvL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/IbhXVDvL",
        "expanded_url" : "http:\/\/bit.ly\/KkpenT",
        "display_url" : "bit.ly\/KkpenT"
      } ]
    },
    "geo" : { },
    "id_str" : "208938287941943298",
    "text" : "This is funny: Nook version of War and Peace turns the word \u201Ckindled\u201D into \u201CNookd\u201D http:\/\/t.co\/IbhXVDvL",
    "id" : 208938287941943298,
    "created_at" : "2012-06-02 15:09:04 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 208938979398135808,
  "created_at" : "2012-06-02 15:11:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208938026473226242",
  "geo" : { },
  "id_str" : "208938794425135104",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver she knew DH was hers when we went to get her as 8wk pup. walked right over me to DH! true love ever since!",
  "id" : 208938794425135104,
  "in_reply_to_status_id" : 208938026473226242,
  "created_at" : "2012-06-02 15:11:05 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Hughes",
      "screen_name" : "bobbyhughes5",
      "indices" : [ 3, 16 ],
      "id_str" : "734448796562804736",
      "id" : 734448796562804736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208937481318576128",
  "text" : "RT @BobbyHughes5: Sometimes God shakes your whole world just to wake you up!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208920081621716993",
    "text" : "Sometimes God shakes your whole world just to wake you up!",
    "id" : 208920081621716993,
    "created_at" : "2012-06-02 13:56:43 +0000",
    "user" : {
      "name" : "4Christ Movement",
      "screen_name" : "4ChristMuv",
      "protected" : false,
      "id_str" : "427906770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713237927552098304\/Hec_dz9t_normal.jpg",
      "id" : 427906770,
      "verified" : false
    }
  },
  "id" : 208937481318576128,
  "created_at" : "2012-06-02 15:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovesherdaddytodeath",
      "indices" : [ 60, 81 ]
    }, {
      "text" : "velcrodog",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208937356034715648",
  "text" : "dog is upset that daddy snuck out while she was upstairs... #lovesherdaddytodeath #velcrodog",
  "id" : 208937356034715648,
  "created_at" : "2012-06-02 15:05:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208936717036683264",
  "text" : "@BibleAlsoSays well, thats 2B expected.. you so popular and all. plus im just a wee mouse. : )",
  "id" : 208936717036683264,
  "created_at" : "2012-06-02 15:02:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208936329386536961",
  "text" : "@BibleAlsoSays for some reason was thinking your age in 30's..hehe. you got me beat. only married 24 next Sept. good for you! ((highfive))",
  "id" : 208936329386536961,
  "created_at" : "2012-06-02 15:01:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208929315436498947",
  "text" : "RT @CoyotesWisdom: \"Numbers don't lie\"? Yeah, right. Numbers mislead, obscure, and downright lie ALL the time... Deceitful little b***** ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208926830764376065",
    "text" : "\"Numbers don't lie\"? Yeah, right. Numbers mislead, obscure, and downright lie ALL the time... Deceitful little b******s...",
    "id" : 208926830764376065,
    "created_at" : "2012-06-02 14:23:32 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 208929315436498947,
  "created_at" : "2012-06-02 14:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kjell Hilding",
      "screen_name" : "KjellRules",
      "indices" : [ 3, 14 ],
      "id_str" : "320918087",
      "id" : 320918087
    }, {
      "name" : "ForkZox",
      "screen_name" : "ZorkFox",
      "indices" : [ 16, 24 ],
      "id_str" : "10050372",
      "id" : 10050372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208927932306034689",
  "text" : "RT @KjellRules: @ZorkFox Who cares what ppl believe if they're feeding the hungry and helping the homeless. Deity is irrelevant.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ForkZox",
        "screen_name" : "ZorkFox",
        "indices" : [ 0, 8 ],
        "id_str" : "10050372",
        "id" : 10050372
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "208652598687973377",
    "geo" : { },
    "id_str" : "208654937842913282",
    "in_reply_to_user_id" : 10050372,
    "text" : "@ZorkFox Who cares what ppl believe if they're feeding the hungry and helping the homeless. Deity is irrelevant.",
    "id" : 208654937842913282,
    "in_reply_to_status_id" : 208652598687973377,
    "created_at" : "2012-06-01 20:23:08 +0000",
    "in_reply_to_screen_name" : "ZorkFox",
    "in_reply_to_user_id_str" : "10050372",
    "user" : {
      "name" : "Kjell Hilding",
      "screen_name" : "KjellRules",
      "protected" : false,
      "id_str" : "320918087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1441352897\/gtr_pic_normal.jpg",
      "id" : 320918087,
      "verified" : false
    }
  },
  "id" : 208927932306034689,
  "created_at" : "2012-06-02 14:27:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208926907658543105",
  "text" : "RT @TrishScott: I'm pretty sure too. RT @lumensilta: He was pretty sure he wanted to be photographed. http:\/\/t.co\/zo5qWQEq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/zo5qWQEq",
        "expanded_url" : "http:\/\/instagr.am\/p\/LX0BUKMicm\/",
        "display_url" : "instagr.am\/p\/LX0BUKMicm\/"
      } ]
    },
    "geo" : { },
    "id_str" : "208921651256115201",
    "text" : "I'm pretty sure too. RT @lumensilta: He was pretty sure he wanted to be photographed. http:\/\/t.co\/zo5qWQEq",
    "id" : 208921651256115201,
    "created_at" : "2012-06-02 14:02:57 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 208926907658543105,
  "created_at" : "2012-06-02 14:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Xy",
      "screen_name" : "Chonnymo",
      "indices" : [ 19, 28 ],
      "id_str" : "20875393",
      "id" : 20875393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208926697813323776",
  "text" : "RT @TrishScott: RT @chonnymo: Some kid wants to run around, look at trees and life outside, he needs chemicals.  No, he needs to go outside.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xy",
        "screen_name" : "Chonnymo",
        "indices" : [ 3, 12 ],
        "id_str" : "20875393",
        "id" : 20875393
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208922530038288384",
    "text" : "RT @chonnymo: Some kid wants to run around, look at trees and life outside, he needs chemicals.  No, he needs to go outside.",
    "id" : 208922530038288384,
    "created_at" : "2012-06-02 14:06:27 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 208926697813323776,
  "created_at" : "2012-06-02 14:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208700661607575553",
  "text" : "wonky headache today. allergy pill didnt seem to help. maybe hormones?",
  "id" : 208700661607575553,
  "created_at" : "2012-06-01 23:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heide Devoid",
      "screen_name" : "ExaminerCom",
      "indices" : [ 90, 102 ],
      "id_str" : "730219313064448001",
      "id" : 730219313064448001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/6NX5HMiA",
      "expanded_url" : "http:\/\/www.examiner.com\/article\/sparky-an-adopted-deer-s-killing-exposes-flaws-wildlife-laws",
      "display_url" : "examiner.com\/article\/sparky\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208667898141609986",
  "text" : "Sparky, an adopted deer's killing exposes flaws in Wildlife Laws http:\/\/t.co\/6NX5HMiA via @examinercom",
  "id" : 208667898141609986,
  "created_at" : "2012-06-01 21:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208655240541642752",
  "geo" : { },
  "id_str" : "208656104715063296",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny plzzz.. my head is already wonky...",
  "id" : 208656104715063296,
  "in_reply_to_status_id" : 208655240541642752,
  "created_at" : "2012-06-01 20:27:46 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 0, 13 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208655123713495041",
  "geo" : { },
  "id_str" : "208655931817476096",
  "in_reply_to_user_id" : 18306792,
  "text" : "@morsemusings ohh.. poor babe. ((hugs))",
  "id" : 208655931817476096,
  "in_reply_to_status_id" : 208655123713495041,
  "created_at" : "2012-06-01 20:27:05 +0000",
  "in_reply_to_screen_name" : "morsemusings",
  "in_reply_to_user_id_str" : "18306792",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Kjell Hilding",
      "screen_name" : "KjellRules",
      "indices" : [ 72, 83 ],
      "id_str" : "320918087",
      "id" : 320918087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208654979366531072",
  "text" : "@BibleAlsoSays problem is ppl not letting others have the freedom to be @KjellRules",
  "id" : 208654979366531072,
  "created_at" : "2012-06-01 20:23:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208643307742572544",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: A major shift is occurring on our planet. We are experiencing the Overhaul of Humanity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208642987817832450",
    "text" : "RT @_NealeDWalsch: A major shift is occurring on our planet. We are experiencing the Overhaul of Humanity.",
    "id" : 208642987817832450,
    "created_at" : "2012-06-01 19:35:39 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 208643307742572544,
  "created_at" : "2012-06-01 19:36:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Anita Doll Fiouris",
      "screen_name" : "AnitaDFiouris",
      "indices" : [ 17, 31 ],
      "id_str" : "19253237",
      "id" : 19253237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208643247793381376",
  "text" : "RT @JohnCali: RT @AnitaDFiouris: Sanity is highly overrated! :-D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anita Doll Fiouris",
        "screen_name" : "AnitaDFiouris",
        "indices" : [ 3, 17 ],
        "id_str" : "19253237",
        "id" : 19253237
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208642860508123136",
    "text" : "RT @AnitaDFiouris: Sanity is highly overrated! :-D",
    "id" : 208642860508123136,
    "created_at" : "2012-06-01 19:35:08 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 208643247793381376,
  "created_at" : "2012-06-01 19:36:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/GfRDBqg1",
      "expanded_url" : "http:\/\/www.knowords.com",
      "display_url" : "knowords.com"
    } ]
  },
  "geo" : { },
  "id_str" : "208638995477970944",
  "text" : "RT @Wylieknowords: WORD FREAKS: \"One Kind Word Could Change a Life.\"  N. Wylie Jones http:\/\/t.co\/GfRDBqg1  (I have seen it happen as a t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/GfRDBqg1",
        "expanded_url" : "http:\/\/www.knowords.com",
        "display_url" : "knowords.com"
      } ]
    },
    "geo" : { },
    "id_str" : "208638381662547968",
    "text" : "WORD FREAKS: \"One Kind Word Could Change a Life.\"  N. Wylie Jones http:\/\/t.co\/GfRDBqg1  (I have seen it happen as a teacher. It works.)",
    "id" : 208638381662547968,
    "created_at" : "2012-06-01 19:17:21 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 208638995477970944,
  "created_at" : "2012-06-01 19:19:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Harms",
      "screen_name" : "kaleidic",
      "indices" : [ 3, 12 ],
      "id_str" : "16911769",
      "id" : 16911769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/DQ7aFuJR",
      "expanded_url" : "http:\/\/bit.ly\/Mnu5nT",
      "display_url" : "bit.ly\/Mnu5nT"
    } ]
  },
  "geo" : { },
  "id_str" : "208637590516154368",
  "text" : "RT @kaleidic: \"I plan to clean this up, but I just haven't done anything\" says man who made this video-gaming room: http:\/\/t.co\/DQ7aFuJR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Kohl",
        "screen_name" : "citizen428",
        "indices" : [ 126, 137 ],
        "id_str" : "11980612",
        "id" : 11980612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/DQ7aFuJR",
        "expanded_url" : "http:\/\/bit.ly\/Mnu5nT",
        "display_url" : "bit.ly\/Mnu5nT"
      } ]
    },
    "geo" : { },
    "id_str" : "203086583283458049",
    "text" : "\"I plan to clean this up, but I just haven't done anything\" says man who made this video-gaming room: http:\/\/t.co\/DQ7aFuJR ht @citizen428",
    "id" : 203086583283458049,
    "created_at" : "2012-05-17 11:36:29 +0000",
    "user" : {
      "name" : "Tracy Harms",
      "screen_name" : "kaleidic",
      "protected" : false,
      "id_str" : "16911769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1838856158\/silhouette_normal.GIF",
      "id" : 16911769,
      "verified" : false
    }
  },
  "id" : 208637590516154368,
  "created_at" : "2012-06-01 19:14:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    }, {
      "name" : "Indamnable",
      "screen_name" : "youredamned",
      "indices" : [ 18, 30 ],
      "id_str" : "474535964",
      "id" : 474535964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 14, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208637376652783618",
  "text" : "RT @Pandeism: #FF @youredamned -- damned if you do, damned if you don't, might as well do it!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Indamnable",
        "screen_name" : "youredamned",
        "indices" : [ 4, 16 ],
        "id_str" : "474535964",
        "id" : 474535964
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208636363027906560",
    "text" : "#FF @youredamned -- damned if you do, damned if you don't, might as well do it!!",
    "id" : 208636363027906560,
    "created_at" : "2012-06-01 19:09:19 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 208637376652783618,
  "created_at" : "2012-06-01 19:13:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208635563950088193",
  "geo" : { },
  "id_str" : "208637031188926465",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous I haven't read it but I've heard it's not like Twilight at all. No vampires. I think they are just humans.",
  "id" : 208637031188926465,
  "in_reply_to_status_id" : 208635563950088193,
  "created_at" : "2012-06-01 19:11:59 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Maker House",
      "screen_name" : "maker_house",
      "indices" : [ 29, 41 ],
      "id_str" : "555676581",
      "id" : 555676581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208635934739136512",
  "geo" : { },
  "id_str" : "208636632214155264",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms nice room! cozy @maker_house",
  "id" : 208636632214155264,
  "in_reply_to_status_id" : 208635934739136512,
  "created_at" : "2012-06-01 19:10:24 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208632470025928704",
  "geo" : { },
  "id_str" : "208633359683948545",
  "in_reply_to_user_id" : 419534932,
  "text" : ". @Boonearang my brain does this all the time.. changes words.. its pretty funny!",
  "id" : 208633359683948545,
  "in_reply_to_status_id" : 208632470025928704,
  "created_at" : "2012-06-01 18:57:23 +0000",
  "in_reply_to_screen_name" : "JediMasterJason",
  "in_reply_to_user_id_str" : "419534932",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208626324129067009",
  "text" : "my head feels wonky.. bleh. take an allergy pill I guess..",
  "id" : 208626324129067009,
  "created_at" : "2012-06-01 18:29:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208623857182048257",
  "geo" : { },
  "id_str" : "208624813089095682",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time yup we have 2 raccoons that come by regularly. stray kitty comes by after the raccoons usually. sometimes possum drops by.",
  "id" : 208624813089095682,
  "in_reply_to_status_id" : 208623857182048257,
  "created_at" : "2012-06-01 18:23:26 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208621164971569154",
  "geo" : { },
  "id_str" : "208622388135460864",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time lol.. well, it's HIS plate on our porch. gives me joy to feed the animals. they are all welcome at our porch diner..lol",
  "id" : 208622388135460864,
  "in_reply_to_status_id" : 208621164971569154,
  "created_at" : "2012-06-01 18:13:48 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 33, 43 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208619672617226240",
  "geo" : { },
  "id_str" : "208621229148610561",
  "in_reply_to_user_id" : 48215218,
  "text" : "we have 1 or 2 reg raccoons also @bend_time so I hold the good stuff til I see kitty. he seems to know this..lol",
  "id" : 208621229148610561,
  "in_reply_to_status_id" : 208619672617226240,
  "created_at" : "2012-06-01 18:09:11 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 5, 15 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208619672617226240",
  "geo" : { },
  "id_str" : "208620796325797888",
  "in_reply_to_user_id" : 48215218,
  "text" : "well @bend_time normally he sits a bit away from me. he's been getting closer. it made my heart sing to see that trust. : )",
  "id" : 208620796325797888,
  "in_reply_to_status_id" : 208619672617226240,
  "created_at" : "2012-06-01 18:07:28 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trust",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208618756174385152",
  "text" : "so last night my stray kitty took meat slice off plate WHILE i was cutting up meat on that plate. Amazing! #trust",
  "id" : 208618756174385152,
  "created_at" : "2012-06-01 17:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Kathan",
      "screen_name" : "StephanieKathan",
      "indices" : [ 3, 19 ],
      "id_str" : "42990074",
      "id" : 42990074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208611277805862916",
  "text" : "RT @StephanieKathan: Dear Universe..... Thank You. You know what for. \u2665",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208611092124020736",
    "text" : "Dear Universe..... Thank You. You know what for. \u2665",
    "id" : 208611092124020736,
    "created_at" : "2012-06-01 17:28:54 +0000",
    "user" : {
      "name" : "Stephanie Kathan",
      "screen_name" : "StephanieKathan",
      "protected" : false,
      "id_str" : "42990074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779137503206998016\/P3KDquOf_normal.jpg",
      "id" : 42990074,
      "verified" : false
    }
  },
  "id" : 208611277805862916,
  "created_at" : "2012-06-01 17:29:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208611009420722178",
  "text" : "the story is God saw me struggling so he sent me my DH. but then saw I still needed help so he sent me my DD \u2665",
  "id" : 208611009420722178,
  "created_at" : "2012-06-01 17:28:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208610366379397121",
  "text" : "I would be quite amiss if I did not include my DD in my \"becoming.\" She has had the greatest impact in me stepping up to myself!",
  "id" : 208610366379397121,
  "created_at" : "2012-06-01 17:26:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 15, 27 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 28, 43 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 44, 56 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 57, 68 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alwaysthere",
      "indices" : [ 69, 81 ]
    }, {
      "text" : "mymentors",
      "indices" : [ 82, 92 ]
    }, {
      "text" : "showmetheway",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208608129259278337",
  "text" : "big (((hugs))) @AngelaHarms @MartijnLinssen @CaroleODell @TrishScott #alwaysthere #mymentors #showmetheway",
  "id" : 208608129259278337,
  "created_at" : "2012-06-01 17:17:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208606616327700480",
  "text" : "we all have baggage.. til we choose not to.",
  "id" : 208606616327700480,
  "created_at" : "2012-06-01 17:11:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "indices" : [ 3, 15 ],
      "id_str" : "406759668",
      "id" : 406759668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208606450304552961",
  "text" : "RT @yoursMukund: One is never alone. RT for the spirit of togetherness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208606206737129472",
    "text" : "One is never alone. RT for the spirit of togetherness.",
    "id" : 208606206737129472,
    "created_at" : "2012-06-01 17:09:30 +0000",
    "user" : {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "protected" : false,
      "id_str" : "406759668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000454898275\/fc674ec400b510e4ab53f191238a2664_normal.jpeg",
      "id" : 406759668,
      "verified" : false
    }
  },
  "id" : 208606450304552961,
  "created_at" : "2012-06-01 17:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208604846385926144",
  "text" : "when the student is ready the teacher will come.. its happened over and over again. many teachers here on twitter! \u2665",
  "id" : 208604846385926144,
  "created_at" : "2012-06-01 17:04:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208604233384206336",
  "text" : "nature, music, books, lots of down time to think, TKD and twitter have all helped me to accept myself.",
  "id" : 208604233384206336,
  "created_at" : "2012-06-01 17:01:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208603804764090368",
  "text" : "RT @NewMindMirror: Trying to escape all unhappiness is like trying to walk on one leg.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208602727134138368",
    "text" : "Trying to escape all unhappiness is like trying to walk on one leg.",
    "id" : 208602727134138368,
    "created_at" : "2012-06-01 16:55:40 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 208603804764090368,
  "created_at" : "2012-06-01 16:59:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 3, 16 ],
      "id_str" : "145890580",
      "id" : 145890580
    }, {
      "name" : "Kaira Rouda",
      "screen_name" : "KairaRouda",
      "indices" : [ 27, 38 ],
      "id_str" : "17130180",
      "id" : 17130180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RealYou",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208603584332431364",
  "text" : "RT @AmyRBromberg: AMEN! RT @kairarouda: #RealYou: Don't put yourself down. You need to be your own biggest fan.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kaira Rouda",
        "screen_name" : "KairaRouda",
        "indices" : [ 9, 20 ],
        "id_str" : "17130180",
        "id" : 17130180
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RealYou",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208603150637215744",
    "text" : "AMEN! RT @kairarouda: #RealYou: Don't put yourself down. You need to be your own biggest fan.",
    "id" : 208603150637215744,
    "created_at" : "2012-06-01 16:57:21 +0000",
    "user" : {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "protected" : false,
      "id_str" : "145890580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754371483720376320\/lPjb2W1B_normal.jpg",
      "id" : 145890580,
      "verified" : false
    }
  },
  "id" : 208603584332431364,
  "created_at" : "2012-06-01 16:59:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 15, 27 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208600324586475521",
  "geo" : { },
  "id_str" : "208603399103582211",
  "in_reply_to_user_id" : 71118021,
  "text" : "took me awhile @CaroleODell to figure that out..hehe. even supermodels have their insecurities, their own issues. we all share humanity!",
  "id" : 208603399103582211,
  "in_reply_to_status_id" : 208600324586475521,
  "created_at" : "2012-06-01 16:58:20 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208602672763387907",
  "text" : "I choose to focus on the good memories of the past and on LOVE today.",
  "id" : 208602672763387907,
  "created_at" : "2012-06-01 16:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 20, 31 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208602137385639937",
  "text" : "RT @MartijnLinssen: @moosebegab the past has passed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "208600419973341186",
    "geo" : { },
    "id_str" : "208601503424983040",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab the past has passed",
    "id" : 208601503424983040,
    "in_reply_to_status_id" : 208600419973341186,
    "created_at" : "2012-06-01 16:50:48 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 208602137385639937,
  "created_at" : "2012-06-01 16:53:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 5, 20 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208601503424983040",
  "geo" : { },
  "id_str" : "208602093198655488",
  "in_reply_to_user_id" : 23757784,
  "text" : "yes! @MartijnLinssen it has. amen.. every day is a new beginning! : )",
  "id" : 208602093198655488,
  "in_reply_to_status_id" : 208601503424983040,
  "created_at" : "2012-06-01 16:53:09 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208601454620057600",
  "text" : "as a child, I believed I was evil.. really! I had so much anger. I internalized it mostly.",
  "id" : 208601454620057600,
  "created_at" : "2012-06-01 16:50:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208600878905688064",
  "text" : "I was just lucky to have the right ppl surrounding me.. allowing me to grow. think this is why I have compassion 4 the \"bad\" ppl",
  "id" : 208600878905688064,
  "created_at" : "2012-06-01 16:48:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psycho",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208600419973341186",
  "text" : "I really believe in the right circumstances, I could have become a killer.. feeling such a lack in myself. #psycho",
  "id" : 208600419973341186,
  "created_at" : "2012-06-01 16:46:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208599885757415424",
  "text" : "im a very envious person.. ppl who are smart, accomplished, have skill or talent, are good-looking, have money.. basically everyone..",
  "id" : 208599885757415424,
  "created_at" : "2012-06-01 16:44:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buddha",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208599172717350913",
  "text" : "RT @AnAmericanMonk: People create distinctions out of their own minds and then believe them to be true. #Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buddha",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208598538928668672",
    "text" : "People create distinctions out of their own minds and then believe them to be true. #Buddha",
    "id" : 208598538928668672,
    "created_at" : "2012-06-01 16:39:01 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 208599172717350913,
  "created_at" : "2012-06-01 16:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "BeverlyEverson",
      "screen_name" : "BeverlyEverson",
      "indices" : [ 27, 42 ],
      "id_str" : "15484732",
      "id" : 15484732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Mu8CieuO",
      "expanded_url" : "http:\/\/post.ly\/7ZpQF",
      "display_url" : "post.ly\/7ZpQF"
    } ]
  },
  "geo" : { },
  "id_str" : "208598247885914112",
  "text" : "RT @KerriFar: Sweeeeet! RT @beverlyeverson: Tern Chick and Mother http:\/\/t.co\/Mu8CieuO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BeverlyEverson",
        "screen_name" : "BeverlyEverson",
        "indices" : [ 13, 28 ],
        "id_str" : "15484732",
        "id" : 15484732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/Mu8CieuO",
        "expanded_url" : "http:\/\/post.ly\/7ZpQF",
        "display_url" : "post.ly\/7ZpQF"
      } ]
    },
    "geo" : { },
    "id_str" : "208597604697776129",
    "text" : "Sweeeeet! RT @beverlyeverson: Tern Chick and Mother http:\/\/t.co\/Mu8CieuO",
    "id" : 208597604697776129,
    "created_at" : "2012-06-01 16:35:19 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 208598247885914112,
  "created_at" : "2012-06-01 16:37:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208597801289003008",
  "text" : "RT @stevetheseeker: The never ending battle between good and evil can only exist in duality. Move beyond it by responding to every situa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208596714414817281",
    "text" : "The never ending battle between good and evil can only exist in duality. Move beyond it by responding to every situation with love.",
    "id" : 208596714414817281,
    "created_at" : "2012-06-01 16:31:46 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 208597801289003008,
  "created_at" : "2012-06-01 16:36:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208589995576008705",
  "text" : "all you ppl that think you have the answer to everything. you forget the all those VARIABLES you plonkers!!",
  "id" : 208589995576008705,
  "created_at" : "2012-06-01 16:05:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208581216151150592",
  "text" : ". @Skeptical_Lady bcuz those ppl are too hurt inside to step beyond the borders of their box...",
  "id" : 208581216151150592,
  "created_at" : "2012-06-01 15:30:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208580702705430530",
  "text" : ". @Skeptical_Lady I never liked the \"born that way\" defense.. we are all born that way.. even serial killers.",
  "id" : 208580702705430530,
  "created_at" : "2012-06-01 15:28:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208578703104540674",
  "text" : "@BibleAlsoSays labels are bad when ppl use them to box ppl in...",
  "id" : 208578703104540674,
  "created_at" : "2012-06-01 15:20:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnCali",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208576603255611392",
  "text" : "RT @JohnCali: The purpose of any teacher is to show you IT\u2019S ALL THERE WITHIN YOU. #JohnCali",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JohnCali",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208570882904424449",
    "text" : "The purpose of any teacher is to show you IT\u2019S ALL THERE WITHIN YOU. #JohnCali",
    "id" : 208570882904424449,
    "created_at" : "2012-06-01 14:49:08 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 208576603255611392,
  "created_at" : "2012-06-01 15:11:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnCali",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208576585543065600",
  "text" : "RT @JohnCali: There is nothing to seek, nothing to find, nowhere to go \u2014 except WITHIN. #JohnCali",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JohnCali",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208570876558446592",
    "text" : "There is nothing to seek, nothing to find, nowhere to go \u2014 except WITHIN. #JohnCali",
    "id" : 208570876558446592,
    "created_at" : "2012-06-01 14:49:06 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 208576585543065600,
  "created_at" : "2012-06-01 15:11:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208574327921184769",
  "geo" : { },
  "id_str" : "208575869248212993",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem oh no.. ((hugs)) and smooches to PH. such a good boy..",
  "id" : 208575869248212993,
  "in_reply_to_status_id" : 208574327921184769,
  "created_at" : "2012-06-01 15:08:57 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]