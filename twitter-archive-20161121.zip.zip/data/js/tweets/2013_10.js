Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396076469899628544",
  "geo" : { },
  "id_str" : "396084299742461952",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos its really getting out of hand with the early shopping nonsense...",
  "id" : 396084299742461952,
  "in_reply_to_status_id" : 396076469899628544,
  "created_at" : "2013-11-01 01:20:30 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396071884220944384",
  "geo" : { },
  "id_str" : "396072611064451072",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos aww.. feel better soon.",
  "id" : 396072611064451072,
  "in_reply_to_status_id" : 396071884220944384,
  "created_at" : "2013-11-01 00:34:03 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395999805689712641",
  "text" : "@Skeptical_Lady do tell? it's driving me nuts!",
  "id" : 395999805689712641,
  "created_at" : "2013-10-31 19:44:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Yates",
      "screen_name" : "CaptMikeYates",
      "indices" : [ 3, 17 ],
      "id_str" : "237824238",
      "id" : 237824238
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 24, 32 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 39, 47 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395999534763225088",
  "text" : "RT @CaptMikeYates: Dear @twitter &amp; @support - STOP BEING RETARDED AND TURN OFF AUTO PREVIEWING PHOTOS!!!!!!!!!!!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 5, 13 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "Twitter Support",
        "screen_name" : "Support",
        "indices" : [ 20, 28 ],
        "id_str" : "17874544",
        "id" : 17874544
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395984576159289344",
    "text" : "Dear @twitter &amp; @support - STOP BEING RETARDED AND TURN OFF AUTO PREVIEWING PHOTOS!!!!!!!!!!!!!!",
    "id" : 395984576159289344,
    "created_at" : "2013-10-31 18:44:14 +0000",
    "user" : {
      "name" : "Mike Yates",
      "screen_name" : "CaptMikeYates",
      "protected" : false,
      "id_str" : "237824238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785559321946062848\/oclWIlY4_normal.jpg",
      "id" : 237824238,
      "verified" : false
    }
  },
  "id" : 395999534763225088,
  "created_at" : "2013-10-31 19:43:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395988506717069312",
  "geo" : { },
  "id_str" : "395989203592298496",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos DD has a Shadow messenger bag that she carries her books in for school.",
  "id" : 395989203592298496,
  "in_reply_to_status_id" : 395988506717069312,
  "created_at" : "2013-10-31 19:02:37 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395988755128922112",
  "text" : "DD got complimented all day on her Shadow costume she wore to school. Not many HSers dressed up.",
  "id" : 395988755128922112,
  "created_at" : "2013-10-31 19:00:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "indices" : [ 3, 19 ],
      "id_str" : "191110048",
      "id" : 191110048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "book",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395987016305094657",
  "text" : "RT @ScienceThriller: SciThri new releases Oct 2013 Smallpox, melanoma, a cure for genetic disease, a \"hactivist\" + 3 #book giveaway http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "book",
        "indices" : [ 96, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/jhdOqGWnm2",
        "expanded_url" : "http:\/\/www.sciencethrillers.com\/2013\/scithri-new-releases-october-2013\/",
        "display_url" : "sciencethrillers.com\/2013\/scithri-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395984185128534016",
    "text" : "SciThri new releases Oct 2013 Smallpox, melanoma, a cure for genetic disease, a \"hactivist\" + 3 #book giveaway http:\/\/t.co\/jhdOqGWnm2",
    "id" : 395984185128534016,
    "created_at" : "2013-10-31 18:42:41 +0000",
    "user" : {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "protected" : false,
      "id_str" : "191110048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509554102632587264\/zmyDrP9j_normal.jpeg",
      "id" : 191110048,
      "verified" : false
    }
  },
  "id" : 395987016305094657,
  "created_at" : "2013-10-31 18:53:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395930886447042560",
  "text" : "RT @ChrisCapparell: Keep your conscious mind focused on what is good and true and beautiful. Feed it riddles and mysteries, and your uncons\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395928414231998464",
    "text" : "Keep your conscious mind focused on what is good and true and beautiful. Feed it riddles and mysteries, and your unconscious will make light",
    "id" : 395928414231998464,
    "created_at" : "2013-10-31 15:01:04 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 395930886447042560,
  "created_at" : "2013-10-31 15:10:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395930741651288064",
  "text" : "RT @ChrisCapparell: What we judge, we are guilty of. And in those who abide in Christ there is no in impulse to condemn.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395527340106608640",
    "text" : "What we judge, we are guilty of. And in those who abide in Christ there is no in impulse to condemn.",
    "id" : 395527340106608640,
    "created_at" : "2013-10-30 12:27:21 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 395930741651288064,
  "created_at" : "2013-10-31 15:10:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395930715185225728",
  "text" : "RT @ChrisCapparell: Therefore there is only one criteria: love. And the old technicalities are rendered moot. To deny this is to deny Chris\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395527304421457920",
    "text" : "Therefore there is only one criteria: love. And the old technicalities are rendered moot. To deny this is to deny Christ.",
    "id" : 395527304421457920,
    "created_at" : "2013-10-30 12:27:12 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 395930715185225728,
  "created_at" : "2013-10-31 15:10:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395918971909586944",
  "geo" : { },
  "id_str" : "395920103281143810",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter wonderful!",
  "id" : 395920103281143810,
  "in_reply_to_status_id" : 395918971909586944,
  "created_at" : "2013-10-31 14:28:03 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395917753061629953",
  "text" : "almost had coffee all over counter. started machine with no cup under it :P",
  "id" : 395917753061629953,
  "created_at" : "2013-10-31 14:18:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395710290014507008",
  "text" : "RT @aliceinthewater: It's not that I don't want to see them, but can I not have the pictures pop up in my feed?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395702444723683328",
    "text" : "It's not that I don't want to see them, but can I not have the pictures pop up in my feed?",
    "id" : 395702444723683328,
    "created_at" : "2013-10-31 00:03:09 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 395710290014507008,
  "created_at" : "2013-10-31 00:34:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 4, 12 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395708885559820288",
  "text" : "ugh @twitter I do NOT like pictures showing up in my timeline! change it back, pretty please...",
  "id" : 395708885559820288,
  "created_at" : "2013-10-31 00:28:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Cote",
      "screen_name" : "CTAPinSK",
      "indices" : [ 3, 12 ],
      "id_str" : "25688267",
      "id" : 25688267
    }, {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 14, 27 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395617546730479616",
  "text" : "RT @CTAPinSK: @PisseArtiste but i can control my consumerism, what car i buy etc. it is NOT the same thing as financing illness 2\/2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Random Bystander",
        "screen_name" : "PisseArtiste",
        "indices" : [ 0, 13 ],
        "id_str" : "25221139",
        "id" : 25221139
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395616145186643968",
    "in_reply_to_user_id" : 25221139,
    "text" : "@PisseArtiste but i can control my consumerism, what car i buy etc. it is NOT the same thing as financing illness 2\/2",
    "id" : 395616145186643968,
    "created_at" : "2013-10-30 18:20:13 +0000",
    "in_reply_to_screen_name" : "PisseArtiste",
    "in_reply_to_user_id_str" : "25221139",
    "user" : {
      "name" : "Colleen Cote",
      "screen_name" : "CTAPinSK",
      "protected" : false,
      "id_str" : "25688267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648199767139336192\/B3gCnGqF_normal.jpg",
      "id" : 25688267,
      "verified" : false
    }
  },
  "id" : 395617546730479616,
  "created_at" : "2013-10-30 18:25:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Cote",
      "screen_name" : "CTAPinSK",
      "indices" : [ 3, 12 ],
      "id_str" : "25688267",
      "id" : 25688267
    }, {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 14, 27 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395617529106006016",
  "text" : "RT @CTAPinSK: @PisseArtiste Y do ppl treat healthcare like it is equivalent to financing a new car? 2 b sick is not choice, no control on c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Random Bystander",
        "screen_name" : "PisseArtiste",
        "indices" : [ 0, 13 ],
        "id_str" : "25221139",
        "id" : 25221139
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395615966568009728",
    "in_reply_to_user_id" : 25221139,
    "text" : "@PisseArtiste Y do ppl treat healthcare like it is equivalent to financing a new car? 2 b sick is not choice, no control on cost... 1\/2",
    "id" : 395615966568009728,
    "created_at" : "2013-10-30 18:19:31 +0000",
    "in_reply_to_screen_name" : "PisseArtiste",
    "in_reply_to_user_id_str" : "25221139",
    "user" : {
      "name" : "Colleen Cote",
      "screen_name" : "CTAPinSK",
      "protected" : false,
      "id_str" : "25688267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648199767139336192\/B3gCnGqF_normal.jpg",
      "id" : 25688267,
      "verified" : false
    }
  },
  "id" : 395617529106006016,
  "created_at" : "2013-10-30 18:25:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RayBeckerman",
      "screen_name" : "RayBeckerman",
      "indices" : [ 3, 16 ],
      "id_str" : "15774048",
      "id" : 15774048
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 21, 32 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Budget2014",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395602090275663872",
  "text" : "RT @RayBeckerman: RT @SenSanders: We now spend almost as much as the rest of the world combined on defense. #Budget2014 http:\/\/t.co\/IZtfCOe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Sanders",
        "screen_name" : "SenSanders",
        "indices" : [ 3, 14 ],
        "id_str" : "29442313",
        "id" : 29442313
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSanders\/status\/395574298137468928\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/IZtfCOe78l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX1cunMCIAIsHdG.png",
        "id_str" : "395574298141663234",
        "id" : 395574298141663234,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX1cunMCIAIsHdG.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IZtfCOe78l"
      } ],
      "hashtags" : [ {
        "text" : "Budget2014",
        "indices" : [ 90, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395596195248476160",
    "text" : "RT @SenSanders: We now spend almost as much as the rest of the world combined on defense. #Budget2014 http:\/\/t.co\/IZtfCOe78l",
    "id" : 395596195248476160,
    "created_at" : "2013-10-30 17:00:57 +0000",
    "user" : {
      "name" : "RayBeckerman",
      "screen_name" : "RayBeckerman",
      "protected" : false,
      "id_str" : "15774048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1127885149\/ray_portrait_in_libraryLARGE_normal.JPG",
      "id" : 15774048,
      "verified" : false
    }
  },
  "id" : 395602090275663872,
  "created_at" : "2013-10-30 17:24:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 22, 37 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/395600372716146688\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/R0Lty4vJa2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX10cV0CMAAR81h.jpg",
      "id_str" : "395600372519022592",
      "id" : 395600372519022592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX10cV0CMAAR81h.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 432
      } ],
      "display_url" : "pic.twitter.com\/R0Lty4vJa2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395600372716146688",
  "geo" : { },
  "id_str" : "395601883919687682",
  "in_reply_to_user_id" : 44674382,
  "text" : "inquire within : ) RT @ChrisCapparell http:\/\/t.co\/R0Lty4vJa2",
  "id" : 395601883919687682,
  "in_reply_to_status_id" : 395600372716146688,
  "created_at" : "2013-10-30 17:23:33 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395600372716146688",
  "geo" : { },
  "id_str" : "395601190014029825",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell haha.. good one! :D",
  "id" : 395601190014029825,
  "in_reply_to_status_id" : 395600372716146688,
  "created_at" : "2013-10-30 17:20:48 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395585780220821504",
  "geo" : { },
  "id_str" : "395600911537430528",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter heehee : )",
  "id" : 395600911537430528,
  "in_reply_to_status_id" : 395585780220821504,
  "created_at" : "2013-10-30 17:19:41 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/395565092877524993\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Xi0GnvwYTm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX1UWygCIAAD-Z1.jpg",
      "id_str" : "395565092768456704",
      "id" : 395565092768456704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX1UWygCIAAD-Z1.jpg",
      "sizes" : [ {
        "h" : 392,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Xi0GnvwYTm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395585035212193792",
  "text" : "RT @Chickypoo333: Sweet http:\/\/t.co\/Xi0GnvwYTm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/395565092877524993\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/Xi0GnvwYTm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX1UWygCIAAD-Z1.jpg",
        "id_str" : "395565092768456704",
        "id" : 395565092768456704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX1UWygCIAAD-Z1.jpg",
        "sizes" : [ {
          "h" : 392,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Xi0GnvwYTm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395565092877524993",
    "text" : "Sweet http:\/\/t.co\/Xi0GnvwYTm",
    "id" : 395565092877524993,
    "created_at" : "2013-10-30 14:57:22 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 395585035212193792,
  "created_at" : "2013-10-30 16:16:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 27, 37 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/kW7evDEUrv",
      "expanded_url" : "http:\/\/zachsmind.wordpress.com\/2012\/09\/22\/let-x-equal-x-atheism-skeptic-religion-christian-omgwtf-feminism-bible-etc\/",
      "display_url" : "zachsmind.wordpress.com\/2012\/09\/22\/let\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "395573465547157504",
  "geo" : { },
  "id_str" : "395584689580150784",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce have you seen @ZachsMind post? xx before xy.. cool! http:\/\/t.co\/kW7evDEUrv",
  "id" : 395584689580150784,
  "in_reply_to_status_id" : 395573465547157504,
  "created_at" : "2013-10-30 16:15:14 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395581837587644416",
  "text" : "why is there prayer in congress?? separation of state and church!!",
  "id" : 395581837587644416,
  "created_at" : "2013-10-30 16:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 17, 33 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395581494473007104",
  "text" : "RT @gemswinc: RT @CatskillCritter: Mist, swirling, reaching up the mountain with ghostly fingers. Halloween is coming! #Catskills http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leslie T. Sharpe",
        "screen_name" : "CatskillCritter",
        "indices" : [ 3, 19 ],
        "id_str" : "727056229",
        "id" : 727056229
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/395561795600908288\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/rljxNRgQHU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX1RW2uCAAIvfaM.jpg",
        "id_str" : "395561795366027266",
        "id" : 395561795366027266,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX1RW2uCAAIvfaM.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/rljxNRgQHU"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395573927537549312",
    "text" : "RT @CatskillCritter: Mist, swirling, reaching up the mountain with ghostly fingers. Halloween is coming! #Catskills http:\/\/t.co\/rljxNRgQHU",
    "id" : 395573927537549312,
    "created_at" : "2013-10-30 15:32:28 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 395581494473007104,
  "created_at" : "2013-10-30 16:02:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395561051271344129",
  "text" : "@weakSquare aww.. sweet. : )",
  "id" : 395561051271344129,
  "created_at" : "2013-10-30 14:41:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395346245474340864",
  "text" : "RT @ChickenJen: I keep waiting for the 21st century to wake up and express itself so that I get to see the liberation of earth before I die.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395340782099365888",
    "text" : "I keep waiting for the 21st century to wake up and express itself so that I get to see the liberation of earth before I die.",
    "id" : 395340782099365888,
    "created_at" : "2013-10-30 00:06:02 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 395346245474340864,
  "created_at" : "2013-10-30 00:27:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395344093301047297",
  "text" : "@1stCitizenKane jeepers, thats dark. long after you're dead, they'll read\/study that in high school english class.",
  "id" : 395344093301047297,
  "created_at" : "2013-10-30 00:19:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395312592543293440",
  "text" : "RT @micahjmurray: I don't know what Twitter did to the feed design, but it looks more cluttered and confusing and overwhelming and I don't \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395305408274780160",
    "text" : "I don't know what Twitter did to the feed design, but it looks more cluttered and confusing and overwhelming and I don't like it.",
    "id" : 395305408274780160,
    "created_at" : "2013-10-29 21:45:28 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 395312592543293440,
  "created_at" : "2013-10-29 22:14:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/pllbrOcSR9",
      "expanded_url" : "http:\/\/www.citizenvox.org\/2013\/07\/10\/public-citizen-publishes-road-map-for-states-to-move-toward-single-payer-health-care\/",
      "display_url" : "citizenvox.org\/2013\/07\/10\/pub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395311376539078656",
  "text" : "RT @AllOnMedicare: Public Citizen publishes \u201Croad map\u201D for states to move toward single-payer health care http:\/\/t.co\/pllbrOcSR9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/pllbrOcSR9",
        "expanded_url" : "http:\/\/www.citizenvox.org\/2013\/07\/10\/public-citizen-publishes-road-map-for-states-to-move-toward-single-payer-health-care\/",
        "display_url" : "citizenvox.org\/2013\/07\/10\/pub\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395294266634686464",
    "text" : "Public Citizen publishes \u201Croad map\u201D for states to move toward single-payer health care http:\/\/t.co\/pllbrOcSR9",
    "id" : 395294266634686464,
    "created_at" : "2013-10-29 21:01:12 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 395311376539078656,
  "created_at" : "2013-10-29 22:09:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "indices" : [ 3, 14 ],
      "id_str" : "200405814",
      "id" : 200405814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395276279131688960",
  "text" : "RT @ftcreature: Another new photo of a baby Olinguito; 1st mammal discovered in the Western Hemisphere in 35 years) has emerged!! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/394954481760468992\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/sDVetkkT0k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXspAimIQAINc5x.jpg",
        "id_str" : "394954481588518914",
        "id" : 394954481588518914,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXspAimIQAINc5x.jpg",
        "sizes" : [ {
          "h" : 443,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/sDVetkkT0k"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394954481760468992",
    "text" : "Another new photo of a baby Olinguito; 1st mammal discovered in the Western Hemisphere in 35 years) has emerged!! http:\/\/t.co\/sDVetkkT0k",
    "id" : 394954481760468992,
    "created_at" : "2013-10-28 22:31:01 +0000",
    "user" : {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "protected" : false,
      "id_str" : "200405814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551555671250849792\/OfxvQB_p_normal.png",
      "id" : 200405814,
      "verified" : false
    }
  },
  "id" : 395276279131688960,
  "created_at" : "2013-10-29 19:49:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395252342331015168",
  "text" : "RT @ChrisCapparell: Which is to say, that all those with compassionate hearts who follow their hearts and are led by that compassion are Ch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395251941803978752",
    "text" : "Which is to say, that all those with compassionate hearts who follow their hearts and are led by that compassion are Christ's family.",
    "id" : 395251941803978752,
    "created_at" : "2013-10-29 18:13:01 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 395252342331015168,
  "created_at" : "2013-10-29 18:14:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pain",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/QTGvT8c7Yv",
      "expanded_url" : "http:\/\/medicalxpress.com\/news\/2013-10-ultra-focused-electric-current-brain-curb.html",
      "display_url" : "medicalxpress.com\/news\/2013-10-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395251685083602944",
  "text" : "RT @NewMindMirror: It's shocking: Ultra-focused electric current helps brain curb #pain - Medical Xpress  http:\/\/t.co\/QTGvT8c7Yv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pain",
        "indices" : [ 63, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/QTGvT8c7Yv",
        "expanded_url" : "http:\/\/medicalxpress.com\/news\/2013-10-ultra-focused-electric-current-brain-curb.html",
        "display_url" : "medicalxpress.com\/news\/2013-10-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395251054943563779",
    "text" : "It's shocking: Ultra-focused electric current helps brain curb #pain - Medical Xpress  http:\/\/t.co\/QTGvT8c7Yv",
    "id" : 395251054943563779,
    "created_at" : "2013-10-29 18:09:29 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 395251685083602944,
  "created_at" : "2013-10-29 18:11:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395243691607982080",
  "text" : "i often feel like a wolf in sheep's clothing going to bible study cuz i dont believe the same things (sin, hell, animal souls, etc.)",
  "id" : 395243691607982080,
  "created_at" : "2013-10-29 17:40:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/9IHjtmsLd4",
      "expanded_url" : "http:\/\/dailygalaxy.com",
      "display_url" : "dailygalaxy.com"
    } ]
  },
  "geo" : { },
  "id_str" : "395243109929738241",
  "text" : "RT @dailygalaxy: \"Our Universe is Made Up of Indivisible Building Blocks --Like Tiny Atoms\" http:\/\/t.co\/9IHjtmsLd4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/9IHjtmsLd4",
        "expanded_url" : "http:\/\/dailygalaxy.com",
        "display_url" : "dailygalaxy.com"
      } ]
    },
    "geo" : { },
    "id_str" : "395242406322241536",
    "text" : "\"Our Universe is Made Up of Indivisible Building Blocks --Like Tiny Atoms\" http:\/\/t.co\/9IHjtmsLd4",
    "id" : 395242406322241536,
    "created_at" : "2013-10-29 17:35:07 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 395243109929738241,
  "created_at" : "2013-10-29 17:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 90, 106 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395233220025135104",
  "geo" : { },
  "id_str" : "395241004195803136",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields apparently ppl in bible study believe its historical account. (not my view) @shoeofallcosmos",
  "id" : 395241004195803136,
  "in_reply_to_status_id" : 395233220025135104,
  "created_at" : "2013-10-29 17:29:33 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395235321169723392",
  "geo" : { },
  "id_str" : "395240612116455424",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos its a book made up of several documents written at various times. i dont accept either\/or.",
  "id" : 395240612116455424,
  "in_reply_to_status_id" : 395235321169723392,
  "created_at" : "2013-10-29 17:27:59 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395231737778675712",
  "geo" : { },
  "id_str" : "395238661387595776",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell comfort was asking for observational evidence of evolution and also examples of change of kind.",
  "id" : 395238661387595776,
  "in_reply_to_status_id" : 395231737778675712,
  "created_at" : "2013-10-29 17:20:14 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395232083234127872",
  "geo" : { },
  "id_str" : "395235195281879040",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos well, im not studying it now but yeah, i think all science stuff is cool. just dont remember a lot from school..lol",
  "id" : 395235195281879040,
  "in_reply_to_status_id" : 395232083234127872,
  "created_at" : "2013-10-29 17:06:28 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395232370292301824",
  "geo" : { },
  "id_str" : "395234869950689280",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell ahh.. the law of Love? although i am christanesque, i dont consider myself a christian.",
  "id" : 395234869950689280,
  "in_reply_to_status_id" : 395232370292301824,
  "created_at" : "2013-10-29 17:05:10 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 101, 114 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395232458490527744",
  "geo" : { },
  "id_str" : "395234381398171648",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos disbelieve which one? i believe evolution is true. i dont believe creationist view. @adamrshields",
  "id" : 395234381398171648,
  "in_reply_to_status_id" : 395232458490527744,
  "created_at" : "2013-10-29 17:03:14 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395224365601529856",
  "geo" : { },
  "id_str" : "395231808771457025",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell holding christian theology.. what does that mean.. can you clarify?",
  "id" : 395231808771457025,
  "in_reply_to_status_id" : 395224365601529856,
  "created_at" : "2013-10-29 16:53:00 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395224365601529856",
  "geo" : { },
  "id_str" : "395231646661611520",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell what does?",
  "id" : 395231646661611520,
  "in_reply_to_status_id" : 395224365601529856,
  "created_at" : "2013-10-29 16:52:22 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395231271527256065",
  "text" : "@Skeptical_Lady aww.. thats sweet. : )",
  "id" : 395231271527256065,
  "created_at" : "2013-10-29 16:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395230251522854912",
  "text" : "i dont have a lot of knowledge about evolution so I might have to read up on it to understand what ray comfort was asking the ppl.",
  "id" : 395230251522854912,
  "created_at" : "2013-10-29 16:46:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395229790350737409",
  "text" : "saw evolution vs god video (ray comfort) in bible study today.",
  "id" : 395229790350737409,
  "created_at" : "2013-10-29 16:44:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    }, {
      "name" : "Providence Journal",
      "screen_name" : "projo",
      "indices" : [ 108, 114 ],
      "id_str" : "14354091",
      "id" : 14354091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/akgDzYQ8dW",
      "expanded_url" : "http:\/\/shar.es\/I7ElG",
      "display_url" : "shar.es\/I7ElG"
    } ]
  },
  "geo" : { },
  "id_str" : "394967439198662656",
  "text" : "RT @Wolf_Mommy: Vermont is designing nation\u2019s first universal health-care system http:\/\/t.co\/akgDzYQ8dW via @projo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Providence Journal",
        "screen_name" : "projo",
        "indices" : [ 92, 98 ],
        "id_str" : "14354091",
        "id" : 14354091
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/akgDzYQ8dW",
        "expanded_url" : "http:\/\/shar.es\/I7ElG",
        "display_url" : "shar.es\/I7ElG"
      } ]
    },
    "geo" : { },
    "id_str" : "394965655906033664",
    "text" : "Vermont is designing nation\u2019s first universal health-care system http:\/\/t.co\/akgDzYQ8dW via @projo",
    "id" : 394965655906033664,
    "created_at" : "2013-10-28 23:15:25 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 394967439198662656,
  "created_at" : "2013-10-28 23:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394894974757904384",
  "geo" : { },
  "id_str" : "394897144244473856",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 eww.. oh my..",
  "id" : 394897144244473856,
  "in_reply_to_status_id" : 394894974757904384,
  "created_at" : "2013-10-28 18:43:10 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ymR0Zdlp3B",
      "expanded_url" : "http:\/\/phys.org\/news\/2013-10-quantum-reality-complex-previously-thought.html",
      "display_url" : "phys.org\/news\/2013-10-q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394875174509887488",
  "text" : "RT @knittingknots: Quantum reality more complex than previously thought http:\/\/t.co\/ymR0Zdlp3B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/ymR0Zdlp3B",
        "expanded_url" : "http:\/\/phys.org\/news\/2013-10-quantum-reality-complex-previously-thought.html",
        "display_url" : "phys.org\/news\/2013-10-q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394873470808387584",
    "text" : "Quantum reality more complex than previously thought http:\/\/t.co\/ymR0Zdlp3B",
    "id" : 394873470808387584,
    "created_at" : "2013-10-28 17:09:06 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 394875174509887488,
  "created_at" : "2013-10-28 17:15:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394863264427171840",
  "geo" : { },
  "id_str" : "394864556507279360",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 i think we've been getting raccoons over night as porch dishes strewn about in morn..lol",
  "id" : 394864556507279360,
  "in_reply_to_status_id" : 394863264427171840,
  "created_at" : "2013-10-28 16:33:41 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394850644365824001",
  "text" : "@weakSquare is it? no hangover today? lol",
  "id" : 394850644365824001,
  "created_at" : "2013-10-28 15:38:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hanley",
      "screen_name" : "RyanHanley_Com",
      "indices" : [ 81, 96 ],
      "id_str" : "19114767",
      "id" : 19114767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/eigFXbe2m8",
      "expanded_url" : "http:\/\/www.ryanhanley.com\/5-reasons-pressgram-makes-it-easy-to-delete-instagram\/",
      "display_url" : "ryanhanley.com\/5-reasons-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394834781050925056",
  "text" : "5 Reasons Pressgram Makes it Easy to Delete Instagram http:\/\/t.co\/eigFXbe2m8 via @RyanHanley_com",
  "id" : 394834781050925056,
  "created_at" : "2013-10-28 14:35:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394555103782658048",
  "geo" : { },
  "id_str" : "394827717536788482",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg from what i could find, looks like mostly teens who have no\/bad parental relationships. hope the comments have stopped now.",
  "id" : 394827717536788482,
  "in_reply_to_status_id" : 394555103782658048,
  "created_at" : "2013-10-28 14:07:18 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394577483170729984",
  "text" : "RT @micahjmurray: I\u2019ve chosen to interpret Scripture by love. If my interpretation makes me more loving, it\u2019s good. If it doesn\u2019t, it\u2019s wor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394576956391317504",
    "text" : "I\u2019ve chosen to interpret Scripture by love. If my interpretation makes me more loving, it\u2019s good. If it doesn\u2019t, it\u2019s worthless.",
    "id" : 394576956391317504,
    "created_at" : "2013-10-27 21:30:51 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 394577483170729984,
  "created_at" : "2013-10-27 21:32:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394577093696036864",
  "text" : "RT @micahjmurray: It seems arrogant to say \u201CI believe\/obey what the Bible says, but you twist it to your liking.\u201D We all interpret. Only Go\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394576055467401216",
    "text" : "It seems arrogant to say \u201CI believe\/obey what the Bible says, but you twist it to your liking.\u201D We all interpret. Only God knows our hearts.",
    "id" : 394576055467401216,
    "created_at" : "2013-10-27 21:27:17 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 394577093696036864,
  "created_at" : "2013-10-27 21:31:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394576360959909888",
  "text" : "RT @micahjmurray: No one obeys the Bible. We all obey our interpretation of the Bible. And your interpretaion may be as fallible as my \u201Clog\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394575538267750400",
    "text" : "No one obeys the Bible. We all obey our interpretation of the Bible. And your interpretaion may be as fallible as my \u201Clogic\u201D or \u201Cfeelings\u201D.",
    "id" : 394575538267750400,
    "created_at" : "2013-10-27 21:25:13 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 394576360959909888,
  "created_at" : "2013-10-27 21:28:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394575523026051072",
  "text" : "RT @micahjmurray: Some Christians say \u201CI let the Bible guide my life, instead of feelings\/logic\/culture.\u201D Problem is, the Bible can be made\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394574999102574594",
    "text" : "Some Christians say \u201CI let the Bible guide my life, instead of feelings\/logic\/culture.\u201D Problem is, the Bible can be made to say anything.",
    "id" : 394574999102574594,
    "created_at" : "2013-10-27 21:23:05 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 394575523026051072,
  "created_at" : "2013-10-27 21:25:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Dauntless",
      "screen_name" : "DougDauntless",
      "indices" : [ 3, 17 ],
      "id_str" : "97963881",
      "id" : 97963881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394565833579843584",
  "text" : "RT @DougDauntless: Koffler: Private insurers threatened? Medicaid rolls multiplying? Sounds like a recipe for single-payer to me. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/zUKLwQPlJ4",
        "expanded_url" : "http:\/\/tinyurl.com\/ljgowyj",
        "display_url" : "tinyurl.com\/ljgowyj"
      } ]
    },
    "geo" : { },
    "id_str" : "394564730607513600",
    "text" : "Koffler: Private insurers threatened? Medicaid rolls multiplying? Sounds like a recipe for single-payer to me. http:\/\/t.co\/zUKLwQPlJ4 #tcot",
    "id" : 394564730607513600,
    "created_at" : "2013-10-27 20:42:17 +0000",
    "user" : {
      "name" : "Doug Dauntless",
      "screen_name" : "DougDauntless",
      "protected" : false,
      "id_str" : "97963881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610994009826156544\/WtBtk3cV_normal.jpg",
      "id" : 97963881,
      "verified" : false
    }
  },
  "id" : 394565833579843584,
  "created_at" : "2013-10-27 20:46:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "MichBell",
      "indices" : [ 0, 9 ],
      "id_str" : "14118957",
      "id" : 14118957
    }, {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 10, 23 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394556303055396865",
  "geo" : { },
  "id_str" : "394558056349978624",
  "in_reply_to_user_id" : 14118957,
  "text" : "@MichBell @AmyRBromberg yes, report them.. and if you so desire, feel free to let us know who these punks are. we got your back. : )",
  "id" : 394558056349978624,
  "in_reply_to_status_id" : 394556303055396865,
  "created_at" : "2013-10-27 20:15:45 +0000",
  "in_reply_to_screen_name" : "MichBell",
  "in_reply_to_user_id_str" : "14118957",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394554571605172224",
  "geo" : { },
  "id_str" : "394555616607227904",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg wth? what is wrong with them? jeepers. ppl can be soo weird sometimes.",
  "id" : 394555616607227904,
  "in_reply_to_status_id" : 394554571605172224,
  "created_at" : "2013-10-27 20:06:04 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394554183518789632",
  "text" : "RT @TheGoldenMirror: How we treat those who are different tells us something about how we are as a people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394553893960830976",
    "text" : "How we treat those who are different tells us something about how we are as a people.",
    "id" : 394553893960830976,
    "created_at" : "2013-10-27 19:59:13 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 394554183518789632,
  "created_at" : "2013-10-27 20:00:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394553285023375360",
  "geo" : { },
  "id_str" : "394554044808585217",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg ((hugs)) do not listen to such sad souls. they have some work to do.",
  "id" : 394554044808585217,
  "in_reply_to_status_id" : 394553285023375360,
  "created_at" : "2013-10-27 19:59:49 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394485927365464064",
  "geo" : { },
  "id_str" : "394486197482819584",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell deep...",
  "id" : 394486197482819584,
  "in_reply_to_status_id" : 394485927365464064,
  "created_at" : "2013-10-27 15:30:13 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394483531776143360",
  "geo" : { },
  "id_str" : "394484551252054018",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes lol.. just spit out my coffee.. hehe.",
  "id" : 394484551252054018,
  "in_reply_to_status_id" : 394483531776143360,
  "created_at" : "2013-10-27 15:23:40 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/4kV6qm1Vxk",
      "expanded_url" : "http:\/\/bloggingwizard.com\/giveaway-win-fanciest-author-box-plugin-wordpress\/",
      "display_url" : "bloggingwizard.com\/giveaway-win-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394184484553121792",
  "text" : "Giveaway: Win 1 of 5 Copies of Fanciest Author Box Plugin For WordPress - hurry ends soon! http:\/\/t.co\/4kV6qm1Vxk",
  "id" : 394184484553121792,
  "created_at" : "2013-10-26 19:31:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 78, 89 ]
    }, {
      "text" : "insurance",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/OmAsalr3xm",
      "expanded_url" : "http:\/\/bigstory.ap.org\/article\/health-marketplaces-open-vt-eyes-bigger-goal#overlay-context=article\/sharpton-threatens-store-boycott-over-profile-suit",
      "display_url" : "bigstory.ap.org\/article\/health\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394182879611461632",
  "text" : "RT @NewMindMirror: Vermont plans \"medi-care for all\" program starting in 2017 #healthcare #insurance http:\/\/t.co\/OmAsalr3xm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthcare",
        "indices" : [ 59, 70 ]
      }, {
        "text" : "insurance",
        "indices" : [ 71, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/OmAsalr3xm",
        "expanded_url" : "http:\/\/bigstory.ap.org\/article\/health-marketplaces-open-vt-eyes-bigger-goal#overlay-context=article\/sharpton-threatens-store-boycott-over-profile-suit",
        "display_url" : "bigstory.ap.org\/article\/health\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394182582109474816",
    "text" : "Vermont plans \"medi-care for all\" program starting in 2017 #healthcare #insurance http:\/\/t.co\/OmAsalr3xm",
    "id" : 394182582109474816,
    "created_at" : "2013-10-26 19:23:45 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 394182879611461632,
  "created_at" : "2013-10-26 19:24:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 0, 13 ],
      "id_str" : "926185416",
      "id" : 926185416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/F9NCgEe29x",
      "expanded_url" : "http:\/\/www.mediaite.com\/tv\/dem-rep-goes-off-during-obamacare-hearing-i-will-not-yield-to-this-monkey-court\/",
      "display_url" : "mediaite.com\/tv\/dem-rep-goe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "394169919631159296",
  "geo" : { },
  "id_str" : "394174603641118720",
  "in_reply_to_user_id" : 926185416,
  "text" : "@hoosierworld http:\/\/t.co\/F9NCgEe29x",
  "id" : 394174603641118720,
  "in_reply_to_status_id" : 394169919631159296,
  "created_at" : "2013-10-26 18:52:03 +0000",
  "in_reply_to_screen_name" : "hoosierworld",
  "in_reply_to_user_id_str" : "926185416",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394160803567656961",
  "text" : "RT @AnAmericanMonk: Listen with the ears of tolerance see through the eyes of compassion speak with the language of love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394160624043048960",
    "text" : "Listen with the ears of tolerance see through the eyes of compassion speak with the language of love.",
    "id" : 394160624043048960,
    "created_at" : "2013-10-26 17:56:30 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 394160803567656961,
  "created_at" : "2013-10-26 17:57:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "+",
      "screen_name" : "_sabari",
      "indices" : [ 3, 11 ],
      "id_str" : "36009641",
      "id" : 36009641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394159823325241344",
  "text" : "RT @_sabari: never judge a book by its movie.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394159368121221120",
    "text" : "never judge a book by its movie.",
    "id" : 394159368121221120,
    "created_at" : "2013-10-26 17:51:31 +0000",
    "user" : {
      "name" : "+",
      "screen_name" : "_sabari",
      "protected" : false,
      "id_str" : "36009641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798259212736294913\/6FZLWL97_normal.jpg",
      "id" : 36009641,
      "verified" : false
    }
  },
  "id" : 394159823325241344,
  "created_at" : "2013-10-26 17:53:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394140960269275137",
  "geo" : { },
  "id_str" : "394142355621552128",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell i didnt mean to say 1 better than other. whichever way works for person to relate to whats bigger than us.",
  "id" : 394142355621552128,
  "in_reply_to_status_id" : 394140960269275137,
  "created_at" : "2013-10-26 16:43:55 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Marie",
      "screen_name" : "mythdebunker",
      "indices" : [ 0, 13 ],
      "id_str" : "486346356",
      "id" : 486346356
    }, {
      "name" : "NO! GOP! NO!",
      "screen_name" : "NoGOPNo",
      "indices" : [ 37, 45 ],
      "id_str" : "850633633",
      "id" : 850633633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/HVh803JeYc",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/10\/18\/1248682\/-Lessons-from-Rand-Paul-Misinformation-can-be-very-important",
      "display_url" : "dailykos.com\/story\/2013\/10\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "394129678157365249",
  "geo" : { },
  "id_str" : "394140078605205505",
  "in_reply_to_user_id" : 486346356,
  "text" : "@mythdebunker http:\/\/t.co\/HVh803JeYc @NoGOPNo",
  "id" : 394140078605205505,
  "in_reply_to_status_id" : 394129678157365249,
  "created_at" : "2013-10-26 16:34:52 +0000",
  "in_reply_to_screen_name" : "mythdebunker",
  "in_reply_to_user_id_str" : "486346356",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394137069758734336",
  "geo" : { },
  "id_str" : "394138867067924480",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell yes.. you said it better &gt;&gt; \"reconcile the two concepts\"",
  "id" : 394138867067924480,
  "in_reply_to_status_id" : 394137069758734336,
  "created_at" : "2013-10-26 16:30:03 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394137313842061312",
  "geo" : { },
  "id_str" : "394138561982652416",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell i talk to \"what's out there\" all the time.. usually referred to as (the) Universe. : )",
  "id" : 394138561982652416,
  "in_reply_to_status_id" : 394137313842061312,
  "created_at" : "2013-10-26 16:28:50 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394132966831845376",
  "geo" : { },
  "id_str" : "394134947792818177",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell its taken me years to get past the personified concept of God...",
  "id" : 394134947792818177,
  "in_reply_to_status_id" : 394132966831845376,
  "created_at" : "2013-10-26 16:14:28 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394116543141150720",
  "geo" : { },
  "id_str" : "394120603109568512",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist love it!! LOL",
  "id" : 394120603109568512,
  "in_reply_to_status_id" : 394116543141150720,
  "created_at" : "2013-10-26 15:17:28 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387934413918457856",
  "geo" : { },
  "id_str" : "394118370477359104",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia accrdng2 political compass quiz, im libertarian although i dont consider myself such.. mostly progressive\/anarchist.",
  "id" : 394118370477359104,
  "in_reply_to_status_id" : 387934413918457856,
  "created_at" : "2013-10-26 15:08:36 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dark Poet",
      "screen_name" : "NewbornTight",
      "indices" : [ 0, 13 ],
      "id_str" : "274335684",
      "id" : 274335684
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 14, 28 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388154528685518849",
  "geo" : { },
  "id_str" : "394117482790653952",
  "in_reply_to_user_id" : 274335684,
  "text" : "@NewbornTight @deisidiamonia thumbs up!!",
  "id" : 394117482790653952,
  "in_reply_to_status_id" : 388154528685518849,
  "created_at" : "2013-10-26 15:05:04 +0000",
  "in_reply_to_screen_name" : "NewbornTight",
  "in_reply_to_user_id_str" : "274335684",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cataclysmic Catalyst",
      "screen_name" : "tastypaper",
      "indices" : [ 0, 11 ],
      "id_str" : "26947798",
      "id" : 26947798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393900975809126400",
  "geo" : { },
  "id_str" : "393901577594880000",
  "in_reply_to_user_id" : 26947798,
  "text" : "@tastypaper what's screed? maybe she was having a bad day...",
  "id" : 393901577594880000,
  "in_reply_to_status_id" : 393900975809126400,
  "created_at" : "2013-10-26 00:47:09 +0000",
  "in_reply_to_screen_name" : "tastypaper",
  "in_reply_to_user_id_str" : "26947798",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hardknoxfirst",
      "screen_name" : "hardknoxfirst",
      "indices" : [ 3, 17 ],
      "id_str" : "14027452",
      "id" : 14027452
    }, {
      "name" : "PoliticusUSA",
      "screen_name" : "politicususa",
      "indices" : [ 119, 132 ],
      "id_str" : "14792049",
      "id" : 14792049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/MoTKVEHULm",
      "expanded_url" : "http:\/\/www.politicususa.com\/2013\/10\/25\/allegedly-christi.html",
      "display_url" : "politicususa.com\/2013\/10\/25\/all\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393899891111780352",
  "text" : "RT @hardknoxfirst: Ohio Christian Conservatives Are Fighting to Deny Poor People Healthcare http:\/\/t.co\/MoTKVEHULm via @politicususa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PoliticusUSA",
        "screen_name" : "politicususa",
        "indices" : [ 100, 113 ],
        "id_str" : "14792049",
        "id" : 14792049
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/MoTKVEHULm",
        "expanded_url" : "http:\/\/www.politicususa.com\/2013\/10\/25\/allegedly-christi.html",
        "display_url" : "politicususa.com\/2013\/10\/25\/all\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393894594858864640",
    "text" : "Ohio Christian Conservatives Are Fighting to Deny Poor People Healthcare http:\/\/t.co\/MoTKVEHULm via @politicususa",
    "id" : 393894594858864640,
    "created_at" : "2013-10-26 00:19:24 +0000",
    "user" : {
      "name" : "hardknoxfirst",
      "screen_name" : "hardknoxfirst",
      "protected" : false,
      "id_str" : "14027452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1421050066\/Hendrix_with_cat_avatar_normal.png",
      "id" : 14027452,
      "verified" : false
    }
  },
  "id" : 393899891111780352,
  "created_at" : "2013-10-26 00:40:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393895329885863936",
  "text" : "RT @umairh: Like have billionaires been driven literally insane by money? How can any human give a fuck about being worth, say, 2 billion v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393744825641467904",
    "text" : "Like have billionaires been driven literally insane by money? How can any human give a fuck about being worth, say, 2 billion vs 3 billion?",
    "id" : 393744825641467904,
    "created_at" : "2013-10-25 14:24:16 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 393895329885863936,
  "created_at" : "2013-10-26 00:22:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393895299368116224",
  "text" : "RT @umairh: Like why are billionaires constantly \"Noo! I don't wanna pay taxes!!\"? What the fuck DO they want? There's nothing left to buy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393745286721323009",
    "text" : "Like why are billionaires constantly \"Noo! I don't wanna pay taxes!!\"? What the fuck DO they want? There's nothing left to buy!",
    "id" : 393745286721323009,
    "created_at" : "2013-10-25 14:26:06 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 393895299368116224,
  "created_at" : "2013-10-26 00:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393895279239647232",
  "text" : "RT @umairh: Let's say you had THREE BILLION DOLLARS in the bank. Would you really give a fuck if it was...2.75? That's like counting toilet\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393745757783601153",
    "text" : "Let's say you had THREE BILLION DOLLARS in the bank. Would you really give a fuck if it was...2.75? That's like counting toilet paper!",
    "id" : 393745757783601153,
    "created_at" : "2013-10-25 14:27:58 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 393895279239647232,
  "created_at" : "2013-10-26 00:22:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393895241830653952",
  "text" : "RT @umairh: Let's state the obvious. A billionaire that objects to paying taxes is the closest thing humanity has to a monster.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393746820368568320",
    "text" : "Let's state the obvious. A billionaire that objects to paying taxes is the closest thing humanity has to a monster.",
    "id" : 393746820368568320,
    "created_at" : "2013-10-25 14:32:12 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 393895241830653952,
  "created_at" : "2013-10-26 00:21:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 3, 13 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tree",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/SiRNKRwNXY",
      "expanded_url" : "http:\/\/lonerwolf.com\/4-eccentric-ways-trees-can-heal-you\/",
      "display_url" : "lonerwolf.com\/4-eccentric-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393862856686702592",
  "text" : "RT @LonerW0lf: From the practice of 'Forest Bathing' to the practice of Tree Hugging, trees can heal us: http:\/\/t.co\/SiRNKRwNXY \u263D #tree #tr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tree",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "trees",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "treehugging",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/SiRNKRwNXY",
        "expanded_url" : "http:\/\/lonerwolf.com\/4-eccentric-ways-trees-can-heal-you\/",
        "display_url" : "lonerwolf.com\/4-eccentric-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393858144591286273",
    "text" : "From the practice of 'Forest Bathing' to the practice of Tree Hugging, trees can heal us: http:\/\/t.co\/SiRNKRwNXY \u263D #tree #trees #treehugging",
    "id" : 393858144591286273,
    "created_at" : "2013-10-25 21:54:33 +0000",
    "user" : {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "protected" : false,
      "id_str" : "536104771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776397232455061504\/lKsVf5C5_normal.jpg",
      "id" : 536104771,
      "verified" : false
    }
  },
  "id" : 393862856686702592,
  "created_at" : "2013-10-25 22:13:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duh Health",
      "screen_name" : "DUH4Healthcare",
      "indices" : [ 3, 18 ],
      "id_str" : "959227039",
      "id" : 959227039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/9Kiuy6l3Ci",
      "expanded_url" : "http:\/\/fb.me\/NkjWncpA",
      "display_url" : "fb.me\/NkjWncpA"
    } ]
  },
  "geo" : { },
  "id_str" : "393835004348080128",
  "text" : "RT @DUH4Healthcare: From Obamacare to Single-Payer: An interview with Benjamin Day of Healthcare-NOW! | Mickey Z. http:\/\/t.co\/9Kiuy6l3Ci",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/9Kiuy6l3Ci",
        "expanded_url" : "http:\/\/fb.me\/NkjWncpA",
        "display_url" : "fb.me\/NkjWncpA"
      } ]
    },
    "geo" : { },
    "id_str" : "393819430464933888",
    "text" : "From Obamacare to Single-Payer: An interview with Benjamin Day of Healthcare-NOW! | Mickey Z. http:\/\/t.co\/9Kiuy6l3Ci",
    "id" : 393819430464933888,
    "created_at" : "2013-10-25 19:20:43 +0000",
    "user" : {
      "name" : "Duh Health",
      "screen_name" : "DUH4Healthcare",
      "protected" : false,
      "id_str" : "959227039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688473563712610306\/GoMmLlUJ_normal.png",
      "id" : 959227039,
      "verified" : false
    }
  },
  "id" : 393835004348080128,
  "created_at" : "2013-10-25 20:22:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Aristedes P. DuVal",
      "screen_name" : "AristedesDuVal",
      "indices" : [ 68, 83 ],
      "id_str" : "147672823",
      "id" : 147672823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393811415599157248",
  "text" : "RT @CharlesBivona: There's no such thing as an ILLEGAL human being. @AristedesDuVal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aristedes P. DuVal",
        "screen_name" : "AristedesDuVal",
        "indices" : [ 49, 64 ],
        "id_str" : "147672823",
        "id" : 147672823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "393807804621791232",
    "geo" : { },
    "id_str" : "393810573940768768",
    "in_reply_to_user_id" : 147672823,
    "text" : "There's no such thing as an ILLEGAL human being. @AristedesDuVal",
    "id" : 393810573940768768,
    "in_reply_to_status_id" : 393807804621791232,
    "created_at" : "2013-10-25 18:45:32 +0000",
    "in_reply_to_screen_name" : "AristedesDuVal",
    "in_reply_to_user_id_str" : "147672823",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 393811415599157248,
  "created_at" : "2013-10-25 18:48:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393801632179179520",
  "geo" : { },
  "id_str" : "393810456369831936",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH omg.. that man was sooo nasty to cheryl campbell when questioning her. and grinning like he had the winning card.",
  "id" : 393810456369831936,
  "in_reply_to_status_id" : 393801632179179520,
  "created_at" : "2013-10-25 18:45:04 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farm Sanctuary",
      "screen_name" : "FarmSanctuary",
      "indices" : [ 3, 17 ],
      "id_str" : "16908562",
      "id" : 16908562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/z8Af3JR0Pl",
      "expanded_url" : "http:\/\/shar.es\/IWppZ",
      "display_url" : "shar.es\/IWppZ"
    } ]
  },
  "geo" : { },
  "id_str" : "393809752901578752",
  "text" : "RT @FarmSanctuary: Strange noises turn out to be cows missing their calves http:\/\/t.co\/z8Af3JR0Pl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/z8Af3JR0Pl",
        "expanded_url" : "http:\/\/shar.es\/IWppZ",
        "display_url" : "shar.es\/IWppZ"
      } ]
    },
    "geo" : { },
    "id_str" : "393801928229916672",
    "text" : "Strange noises turn out to be cows missing their calves http:\/\/t.co\/z8Af3JR0Pl",
    "id" : 393801928229916672,
    "created_at" : "2013-10-25 18:11:10 +0000",
    "user" : {
      "name" : "Farm Sanctuary",
      "screen_name" : "FarmSanctuary",
      "protected" : false,
      "id_str" : "16908562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440957631226580992\/Pk-bFWfT_normal.jpeg",
      "id" : 16908562,
      "verified" : false
    }
  },
  "id" : 393809752901578752,
  "created_at" : "2013-10-25 18:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393808718761971712",
  "text" : "@Skeptical_Lady awesome! : )",
  "id" : 393808718761971712,
  "created_at" : "2013-10-25 18:38:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/UwzSnkG8HN",
      "expanded_url" : "http:\/\/tl.gd\/n_1rqd95b",
      "display_url" : "tl.gd\/n_1rqd95b"
    } ]
  },
  "geo" : { },
  "id_str" : "393770789222502400",
  "text" : "Fox News accidentally pro #SinglePayer - \"In Europe, national health care systems deliver coverage for (cont) http:\/\/t.co\/UwzSnkG8HN",
  "id" : 393770789222502400,
  "created_at" : "2013-10-25 16:07:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393769748825382912",
  "text" : "RT @TheChristianLft: Check out the Fox News article which states: \"n Europe, national health care systems deliver coverage for... http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/E2v9xCkziH",
        "expanded_url" : "http:\/\/fb.me\/2rOTxYkwv",
        "display_url" : "fb.me\/2rOTxYkwv"
      } ]
    },
    "geo" : { },
    "id_str" : "393766082957574144",
    "text" : "Check out the Fox News article which states: \"n Europe, national health care systems deliver coverage for... http:\/\/t.co\/E2v9xCkziH",
    "id" : 393766082957574144,
    "created_at" : "2013-10-25 15:48:44 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 393769748825382912,
  "created_at" : "2013-10-25 16:03:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP New York Metro",
      "screen_name" : "PNHPNYMetro",
      "indices" : [ 3, 15 ],
      "id_str" : "385821239",
      "id" : 385821239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393765777993924608",
  "text" : "RT @PNHPNYMetro: \"they will be watching closely to see what happens in states like Vermont and Hawaii, where frameworks for... http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/5GsJShhYX1",
        "expanded_url" : "http:\/\/fb.me\/6wJMfUAli",
        "display_url" : "fb.me\/6wJMfUAli"
      } ]
    },
    "geo" : { },
    "id_str" : "393758678396174336",
    "text" : "\"they will be watching closely to see what happens in states like Vermont and Hawaii, where frameworks for... http:\/\/t.co\/5GsJShhYX1",
    "id" : 393758678396174336,
    "created_at" : "2013-10-25 15:19:19 +0000",
    "user" : {
      "name" : "PNHP New York Metro",
      "screen_name" : "PNHPNYMetro",
      "protected" : false,
      "id_str" : "385821239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614059417\/7be137567ac8c3aeb8539b0fccf128e5_normal.jpeg",
      "id" : 385821239,
      "verified" : false
    }
  },
  "id" : 393765777993924608,
  "created_at" : "2013-10-25 15:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/iPXybMTPJj",
      "expanded_url" : "http:\/\/shar.es\/Iobd7",
      "display_url" : "shar.es\/Iobd7"
    } ]
  },
  "geo" : { },
  "id_str" : "393735776581992449",
  "text" : "RT @AllOnMedicare: Paul F. deLespinasse: Why a single-payer health system would be better than Obamacare http:\/\/t.co\/iPXybMTPJj via @sharet\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 113, 123 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/iPXybMTPJj",
        "expanded_url" : "http:\/\/shar.es\/Iobd7",
        "display_url" : "shar.es\/Iobd7"
      } ]
    },
    "geo" : { },
    "id_str" : "393724586107211777",
    "text" : "Paul F. deLespinasse: Why a single-payer health system would be better than Obamacare http:\/\/t.co\/iPXybMTPJj via @sharethis #singlepayer",
    "id" : 393724586107211777,
    "created_at" : "2013-10-25 13:03:51 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 393735776581992449,
  "created_at" : "2013-10-25 13:48:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393720380591857665",
  "geo" : { },
  "id_str" : "393726995869102081",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare bleh..",
  "id" : 393726995869102081,
  "in_reply_to_status_id" : 393720380591857665,
  "created_at" : "2013-10-25 13:13:25 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insurance",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393513750894215168",
  "text" : "RT @KellyRek: The mandate to buy private #insurance is \"corporate communism\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insurance",
        "indices" : [ 27, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393513342347640832",
    "text" : "The mandate to buy private #insurance is \"corporate communism\"",
    "id" : 393513342347640832,
    "created_at" : "2013-10-24 23:04:26 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 393513750894215168,
  "created_at" : "2013-10-24 23:06:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393493816214183936",
  "text" : "i like Elizabeth Teisberg in the ACA market talk on cspan. she understands ppl concerns. has compassion.",
  "id" : 393493816214183936,
  "created_at" : "2013-10-24 21:46:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393476201496326144",
  "geo" : { },
  "id_str" : "393477780161048576",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni LOL.. i was watching ann coulter describing choosing health ins. like car ins. UGH.",
  "id" : 393477780161048576,
  "in_reply_to_status_id" : 393476201496326144,
  "created_at" : "2013-10-24 20:43:07 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 22, 31 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "MakeDCListen",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393473587589292032",
  "geo" : { },
  "id_str" : "393474602971578368",
  "in_reply_to_user_id" : 309558781,
  "text" : "#SinglePayer now!! RT @KellyRek I don't want a damn middleman between me and my doctor ~~&gt; #MakeDCListen",
  "id" : 393474602971578368,
  "in_reply_to_status_id" : 393473587589292032,
  "created_at" : "2013-10-24 20:30:30 +0000",
  "in_reply_to_screen_name" : "KellyRek",
  "in_reply_to_user_id_str" : "309558781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393463956418723840",
  "text" : "ACK.. health insurance is not similar to car insurance!!",
  "id" : 393463956418723840,
  "created_at" : "2013-10-24 19:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Democrats",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "Republicans",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393459311823060993",
  "text" : "RT @KellyRek: The #Democrats and #Republicans in Congress do not represent the will of \"we the people\" .. they represent the will of corpor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Democrats",
        "indices" : [ 4, 14 ]
      }, {
        "text" : "Republicans",
        "indices" : [ 19, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393458555912605696",
    "text" : "The #Democrats and #Republicans in Congress do not represent the will of \"we the people\" .. they represent the will of corporate lobbyists.",
    "id" : 393458555912605696,
    "created_at" : "2013-10-24 19:26:44 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 393459311823060993,
  "created_at" : "2013-10-24 19:29:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "NJUrbanForest",
      "screen_name" : "NJURBANFOREST",
      "indices" : [ 34, 48 ],
      "id_str" : "120003142",
      "id" : 120003142
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 92, 108 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ST9UGnmYWs",
      "expanded_url" : "http:\/\/ow.ly\/q89QK",
      "display_url" : "ow.ly\/q89QK"
    } ]
  },
  "geo" : { },
  "id_str" : "393453831411236864",
  "text" : "RT @KerriFar: Made Me Smile :) RT @NJURBANFOREST \"An Interesting \"Bird\" at the Feeder \u00A0 via @wordpressdotcom\" http:\/\/t.co\/ST9UGnmYWs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NJUrbanForest",
        "screen_name" : "NJURBANFOREST",
        "indices" : [ 20, 34 ],
        "id_str" : "120003142",
        "id" : 120003142
      }, {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 78, 94 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ST9UGnmYWs",
        "expanded_url" : "http:\/\/ow.ly\/q89QK",
        "display_url" : "ow.ly\/q89QK"
      } ]
    },
    "geo" : { },
    "id_str" : "393453601773072386",
    "text" : "Made Me Smile :) RT @NJURBANFOREST \"An Interesting \"Bird\" at the Feeder \u00A0 via @wordpressdotcom\" http:\/\/t.co\/ST9UGnmYWs",
    "id" : 393453601773072386,
    "created_at" : "2013-10-24 19:07:03 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 393453831411236864,
  "created_at" : "2013-10-24 19:07:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393443039290880000",
  "geo" : { },
  "id_str" : "393443404379471872",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell yeah..",
  "id" : 393443404379471872,
  "in_reply_to_status_id" : 393443039290880000,
  "created_at" : "2013-10-24 18:26:32 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Bryce",
      "screen_name" : "eurekasue49",
      "indices" : [ 3, 15 ],
      "id_str" : "415343898",
      "id" : 415343898
    }, {
      "name" : "Michael Chase Walker",
      "screen_name" : "mchasewalker",
      "indices" : [ 20, 33 ],
      "id_str" : "19698370",
      "id" : 19698370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393435523030986752",
  "text" : "RT @eurekasue49: RT @mchasewalker: Happening NOW: What life in America is like under Tea Party Taliban of Christian RW. http:\/\/t.co\/pfIiY5e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Chase Walker",
        "screen_name" : "mchasewalker",
        "indices" : [ 3, 16 ],
        "id_str" : "19698370",
        "id" : 19698370
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stoprush",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/pfIiY5eR3t",
        "expanded_url" : "http:\/\/www.salon.com\/2013\/10\/24\/in_many_states_fetal_rights_laws_are_putting_pregnant_women_in_jail\/",
        "display_url" : "salon.com\/2013\/10\/24\/in_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393429858199425024",
    "text" : "RT @mchasewalker: Happening NOW: What life in America is like under Tea Party Taliban of Christian RW. http:\/\/t.co\/pfIiY5eR3t \n#stoprush",
    "id" : 393429858199425024,
    "created_at" : "2013-10-24 17:32:42 +0000",
    "user" : {
      "name" : "Sue Bryce",
      "screen_name" : "eurekasue49",
      "protected" : false,
      "id_str" : "415343898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516607735031279616\/l1fvO1gA_normal.jpeg",
      "id" : 415343898,
      "verified" : false
    }
  },
  "id" : 393435523030986752,
  "created_at" : "2013-10-24 17:55:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393425560082599936",
  "text" : "RT @dailygalaxy: The Most Distant Galaxy in the Observable Universe Discovered --30 Billion Light Years from the Milky Way! http:\/\/t.co\/Yuc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/YucGSH1U2A",
        "expanded_url" : "http:\/\/goo.gl\/tZ4vMb",
        "display_url" : "goo.gl\/tZ4vMb"
      } ]
    },
    "geo" : { },
    "id_str" : "393425426501996544",
    "text" : "The Most Distant Galaxy in the Observable Universe Discovered --30 Billion Light Years from the Milky Way! http:\/\/t.co\/YucGSH1U2A",
    "id" : 393425426501996544,
    "created_at" : "2013-10-24 17:15:05 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 393425560082599936,
  "created_at" : "2013-10-24 17:15:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393424463729262592",
  "text" : "RT @AllOnMedicare: @health_citizen Problem is that Americans get gouged TWICE -- since doctor's visit to get prescription is also insanely \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "393422931985842176",
    "geo" : { },
    "id_str" : "393423565162180608",
    "in_reply_to_user_id" : 1485827456,
    "text" : "@health_citizen Problem is that Americans get gouged TWICE -- since doctor's visit to get prescription is also insanely expensive.",
    "id" : 393423565162180608,
    "in_reply_to_status_id" : 393422931985842176,
    "created_at" : "2013-10-24 17:07:42 +0000",
    "in_reply_to_screen_name" : "sterrettlaw",
    "in_reply_to_user_id_str" : "1485827456",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 393424463729262592,
  "created_at" : "2013-10-24 17:11:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393423106645045249",
  "text" : "@Skeptical_Lady sometimes i have trouble expressing myself clearly. often your posts will send my brain on a search (good thing)",
  "id" : 393423106645045249,
  "created_at" : "2013-10-24 17:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393422683183935488",
  "text" : "@Skeptical_Lady gahhh.. im not being pissy. somehow this interaction took a wrong turn. : (",
  "id" : 393422683183935488,
  "created_at" : "2013-10-24 17:04:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393392350229045248",
  "geo" : { },
  "id_str" : "393402976556941312",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare really? (j\/k..) : )",
  "id" : 393402976556941312,
  "in_reply_to_status_id" : 393392350229045248,
  "created_at" : "2013-10-24 15:45:53 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393392045894541312",
  "text" : "@Skeptical_Lady no, no.. i said we can use labels but not be defined by them.",
  "id" : 393392045894541312,
  "created_at" : "2013-10-24 15:02:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 121, 130 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393390432887275520",
  "text" : "RT @SenSanders: A single-payer system, like Medicare, is the cure for America's ailing healthcare - Sen. Bernie Sanders, @guardian: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 105, 114 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8ooW3XFW2g",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/sep\/30\/single-payer-cure-healthcare-reform",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393128777376481280",
    "text" : "A single-payer system, like Medicare, is the cure for America's ailing healthcare - Sen. Bernie Sanders, @guardian: http:\/\/t.co\/8ooW3XFW2g",
    "id" : 393128777376481280,
    "created_at" : "2013-10-23 21:36:19 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 393390432887275520,
  "created_at" : "2013-10-24 14:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393389692667691009",
  "text" : "@Skeptical_Lady i think its a difference of seeing black &amp; white or shades of grey. we can use labels but not be defined by them.",
  "id" : 393389692667691009,
  "created_at" : "2013-10-24 14:53:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 2, 16 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393388115999465472",
  "geo" : { },
  "id_str" : "393388880780476416",
  "in_reply_to_user_id" : 1193933845,
  "text" : ". @CosmicHominid so one can be either believing in science OR having faith? i strongly disagree with that conclusion.",
  "id" : 393388880780476416,
  "in_reply_to_status_id" : 393388115999465472,
  "created_at" : "2013-10-24 14:49:52 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAhearing",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393388017747890177",
  "text" : "wow, some of these questioners are awfully nasty #ACAhearing",
  "id" : 393388017747890177,
  "created_at" : "2013-10-24 14:46:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393387541983789056",
  "text" : "@Skeptical_Lady we all have a sense of feeling superior. no matter what beliefs, due to cognitive bias (thx @weakSquare)",
  "id" : 393387541983789056,
  "created_at" : "2013-10-24 14:44:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393387030345818112",
  "text" : ". @Skeptical_Lady words like \"spirituality\", and even \"God\", are infinitely flexible, capable of accommodating everything &lt;&lt; this!",
  "id" : 393387030345818112,
  "created_at" : "2013-10-24 14:42:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393385502356680704",
  "text" : "i think it comes down to this: either you see healthcare as a right.. or as a privilege. #ACA",
  "id" : 393385502356680704,
  "created_at" : "2013-10-24 14:36:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393382946209808384",
  "text" : "RT @Squirrely007: Judged for not wanting kids, judged for having one too many.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393380849543942144",
    "text" : "Judged for not wanting kids, judged for having one too many.",
    "id" : 393380849543942144,
    "created_at" : "2013-10-24 14:17:57 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 393382946209808384,
  "created_at" : "2013-10-24 14:26:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not John Green",
      "screen_name" : "realjohngreen",
      "indices" : [ 3, 17 ],
      "id_str" : "2796445679",
      "id" : 2796445679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393382732363223040",
  "text" : "RT @realjohngreen: As a reader, I don't feel a story has an obligation to make me happy. I want stories to show me a bigger world than the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393377277594959872",
    "text" : "As a reader, I don't feel a story has an obligation to make me happy. I want stories to show me a bigger world than the one I know.",
    "id" : 393377277594959872,
    "created_at" : "2013-10-24 14:03:46 +0000",
    "user" : {
      "name" : "John Green",
      "screen_name" : "johngreen",
      "protected" : false,
      "id_str" : "18055737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000665706398\/7c29cea2c338c6f5b45d7bcb0af0b79c_normal.png",
      "id" : 18055737,
      "verified" : true
    }
  },
  "id" : 393382732363223040,
  "created_at" : "2013-10-24 14:25:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393378481070800896",
  "text" : "@weakSquare i want to know what's outside the cave, too : )",
  "id" : 393378481070800896,
  "created_at" : "2013-10-24 14:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/zeJUuMcF0h",
      "expanded_url" : "http:\/\/thinkprogress.org\/justice\/2013\/10\/23\/2826451\/barneys-shopping-black\/",
      "display_url" : "thinkprogress.org\/justice\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393377694249136129",
  "text" : "RT @Jamiastar: 19-Year-Old Detained For 'Shopping While Black' At Barneys | ThinkProgress http:\/\/t.co\/zeJUuMcF0h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/zeJUuMcF0h",
        "expanded_url" : "http:\/\/thinkprogress.org\/justice\/2013\/10\/23\/2826451\/barneys-shopping-black\/",
        "display_url" : "thinkprogress.org\/justice\/2013\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393377282443583488",
    "text" : "19-Year-Old Detained For 'Shopping While Black' At Barneys | ThinkProgress http:\/\/t.co\/zeJUuMcF0h",
    "id" : 393377282443583488,
    "created_at" : "2013-10-24 14:03:47 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 393377694249136129,
  "created_at" : "2013-10-24 14:05:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 0, 13 ],
      "id_str" : "926185416",
      "id" : 926185416
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393339024049315841",
  "geo" : { },
  "id_str" : "393363359967346688",
  "in_reply_to_user_id" : 926185416,
  "text" : "@hoosierworld same ppl think its ok to confine preg woman on suspicion of drug abuse #freedom (tbh, im not a fan of mandate)",
  "id" : 393363359967346688,
  "in_reply_to_status_id" : 393339024049315841,
  "created_at" : "2013-10-24 13:08:28 +0000",
  "in_reply_to_screen_name" : "hoosierworld",
  "in_reply_to_user_id_str" : "926185416",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 69, 77 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/6BnRrVvKR1",
      "expanded_url" : "http:\/\/nyti.ms\/1d1IS2P",
      "display_url" : "nyti.ms\/1d1IS2P"
    } ]
  },
  "geo" : { },
  "id_str" : "393360142256713729",
  "text" : "C Wolfe's comment on Case Explores Rights of Fetus Versus Mother via @nytimes http:\/\/t.co\/6BnRrVvKR1",
  "id" : 393360142256713729,
  "created_at" : "2013-10-24 12:55:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393359393301229568",
  "text" : "RT @stream_enterer: You know that spinning symbol on the screen that means 'loading'... that is life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393349609302396928",
    "text" : "You know that spinning symbol on the screen that means 'loading'... that is life.",
    "id" : 393349609302396928,
    "created_at" : "2013-10-24 12:13:49 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 393359393301229568,
  "created_at" : "2013-10-24 12:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393190757643083776",
  "geo" : { },
  "id_str" : "393355584046497792",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 rip precious boy. &lt;3",
  "id" : 393355584046497792,
  "in_reply_to_status_id" : 393190757643083776,
  "created_at" : "2013-10-24 12:37:34 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 3, 13 ],
      "id_str" : "574554751",
      "id" : 574554751
    }, {
      "name" : "Blackfish",
      "screen_name" : "blackfishmovie",
      "indices" : [ 40, 55 ],
      "id_str" : "1007905507",
      "id" : 1007905507
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 62, 66 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "CrueltyFree",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393180604302626816",
  "text" : "RT @CosmoTyme: RT &amp; Spread the word @blackfishmovie is on @CNN this Thursday 24th A must see for everyone:))) #Blackfish #CrueltyFree #Free\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blackfish",
        "screen_name" : "blackfishmovie",
        "indices" : [ 25, 40 ],
        "id_str" : "1007905507",
        "id" : 1007905507
      }, {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 47, 51 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 99, 109 ]
      }, {
        "text" : "CrueltyFree",
        "indices" : [ 110, 122 ]
      }, {
        "text" : "FreeTheOrcas",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392423539208253440",
    "text" : "RT &amp; Spread the word @blackfishmovie is on @CNN this Thursday 24th A must see for everyone:))) #Blackfish #CrueltyFree #FreeTheOrcas",
    "id" : 392423539208253440,
    "created_at" : "2013-10-21 22:53:57 +0000",
    "user" : {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "protected" : false,
      "id_str" : "574554751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500723456317456385\/vX0Jdg1A_normal.jpeg",
      "id" : 574554751,
      "verified" : false
    }
  },
  "id" : 393180604302626816,
  "created_at" : "2013-10-24 01:02:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393165381973864448",
  "geo" : { },
  "id_str" : "393168173819645952",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 btw, how is wallace doing?",
  "id" : 393168173819645952,
  "in_reply_to_status_id" : 393165381973864448,
  "created_at" : "2013-10-24 00:12:52 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393165381973864448",
  "geo" : { },
  "id_str" : "393168032022790144",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 nice pic : )",
  "id" : 393168032022790144,
  "in_reply_to_status_id" : 393165381973864448,
  "created_at" : "2013-10-24 00:12:18 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393161926542245888",
  "geo" : { },
  "id_str" : "393165237764886529",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 he's a keeper! : )",
  "id" : 393165237764886529,
  "in_reply_to_status_id" : 393161926542245888,
  "created_at" : "2013-10-24 00:01:11 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 3, 13 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Test",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393145495860051968",
  "text" : "RT @LonerW0lf: Are you sensitive, thoughtful &amp; moody?  You may be of Melancholic Temperament. Take our free Personality #Test: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Test",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/0rdumDr4Na",
        "expanded_url" : "http:\/\/lonerwolf.com\/melancholic-personality-test\/",
        "display_url" : "lonerwolf.com\/melancholic-pe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393139473191411712",
    "text" : "Are you sensitive, thoughtful &amp; moody?  You may be of Melancholic Temperament. Take our free Personality #Test: http:\/\/t.co\/0rdumDr4Na \u263C",
    "id" : 393139473191411712,
    "created_at" : "2013-10-23 22:18:49 +0000",
    "user" : {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "protected" : false,
      "id_str" : "536104771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776397232455061504\/lKsVf5C5_normal.jpg",
      "id" : 536104771,
      "verified" : false
    }
  },
  "id" : 393145495860051968,
  "created_at" : "2013-10-23 22:42:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 0, 10 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393139473191411712",
  "geo" : { },
  "id_str" : "393145454365388800",
  "in_reply_to_user_id" : 536104771,
  "text" : "@LonerW0lf yup... lol",
  "id" : 393145454365388800,
  "in_reply_to_status_id" : 393139473191411712,
  "created_at" : "2013-10-23 22:42:35 +0000",
  "in_reply_to_screen_name" : "LonerW0lf",
  "in_reply_to_user_id_str" : "536104771",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "indices" : [ 3, 14 ],
      "id_str" : "20016044",
      "id" : 20016044
    }, {
      "name" : "Slashdot",
      "screen_name" : "slashdot",
      "indices" : [ 88, 97 ],
      "id_str" : "1068831",
      "id" : 1068831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/rYO30UWav4",
      "expanded_url" : "http:\/\/science.slashdot.org\/story\/13\/10\/23\/129220\/first-experimental-evidence-that-time-is-an-emergent-quantum-phenomenon",
      "display_url" : "science.slashdot.org\/story\/13\/10\/23\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393102876761149440",
  "text" : "RT @annihilist: First Experimental Evidence That Time Is an Emergent Quantum Phenomenon @slashdot http:\/\/t.co\/rYO30UWav4 &lt; O_O Holy...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slashdot",
        "screen_name" : "slashdot",
        "indices" : [ 72, 81 ],
        "id_str" : "1068831",
        "id" : 1068831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/rYO30UWav4",
        "expanded_url" : "http:\/\/science.slashdot.org\/story\/13\/10\/23\/129220\/first-experimental-evidence-that-time-is-an-emergent-quantum-phenomenon",
        "display_url" : "science.slashdot.org\/story\/13\/10\/23\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393099820295921665",
    "text" : "First Experimental Evidence That Time Is an Emergent Quantum Phenomenon @slashdot http:\/\/t.co\/rYO30UWav4 &lt; O_O Holy...",
    "id" : 393099820295921665,
    "created_at" : "2013-10-23 19:41:15 +0000",
    "user" : {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "protected" : false,
      "id_str" : "20016044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2698857060\/e2abd719f5fec793b3818cdff078c44b_normal.jpeg",
      "id" : 20016044,
      "verified" : false
    }
  },
  "id" : 393102876761149440,
  "created_at" : "2013-10-23 19:53:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393092524358651905",
  "text" : "@weakSquare oh im not a literal bible person. i'm pro-science (well, vaccines.. thats another story..lol) so it should be amusing at least.",
  "id" : 393092524358651905,
  "created_at" : "2013-10-23 19:12:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393090555023863808",
  "text" : "@weakSquare i think this is what we're watching in bible study next wk...",
  "id" : 393090555023863808,
  "created_at" : "2013-10-23 19:04:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Saul",
      "screen_name" : "jonassaul",
      "indices" : [ 3, 13 ],
      "id_str" : "127322699",
      "id" : 127322699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "peaceful",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "calm",
      "indices" : [ 75, 80 ]
    }, {
      "text" : "listening",
      "indices" : [ 81, 91 ]
    }, {
      "text" : "dubstep",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yzZSXZo7oN",
      "expanded_url" : "http:\/\/instagram.com\/p\/f0a0YNJ_QN\/",
      "display_url" : "instagram.com\/p\/f0a0YNJ_QN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "393075939577724929",
  "text" : "RT @jonassaul: Deer having lunch outside my office window. #cool #peaceful #calm #listening to #dubstep as I write. http:\/\/t.co\/yzZSXZo7oN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cool",
        "indices" : [ 44, 49 ]
      }, {
        "text" : "peaceful",
        "indices" : [ 50, 59 ]
      }, {
        "text" : "calm",
        "indices" : [ 60, 65 ]
      }, {
        "text" : "listening",
        "indices" : [ 66, 76 ]
      }, {
        "text" : "dubstep",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/yzZSXZo7oN",
        "expanded_url" : "http:\/\/instagram.com\/p\/f0a0YNJ_QN\/",
        "display_url" : "instagram.com\/p\/f0a0YNJ_QN\/"
      } ]
    },
    "geo" : { },
    "id_str" : "393073894762221568",
    "text" : "Deer having lunch outside my office window. #cool #peaceful #calm #listening to #dubstep as I write. http:\/\/t.co\/yzZSXZo7oN",
    "id" : 393073894762221568,
    "created_at" : "2013-10-23 17:58:14 +0000",
    "user" : {
      "name" : "Jonas Saul",
      "screen_name" : "jonassaul",
      "protected" : false,
      "id_str" : "127322699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1568329636\/Jonas-Saul_normal.jpg",
      "id" : 127322699,
      "verified" : false
    }
  },
  "id" : 393075939577724929,
  "created_at" : "2013-10-23 18:06:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392999373363486720",
  "text" : "RT @marseelee: I am not a human being, i am a human becoming.\n\nOg Mandino",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392999007733440512",
    "text" : "I am not a human being, i am a human becoming.\n\nOg Mandino",
    "id" : 392999007733440512,
    "created_at" : "2013-10-23 13:00:39 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 392999373363486720,
  "created_at" : "2013-10-23 13:02:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/FZlcz0adwA",
      "expanded_url" : "http:\/\/www.newyorker.com\/reporting\/2013\/10\/28\/131028fa_fact_sedaris?currentPage=all?mbid=social_retweet?mbid=social_retweet",
      "display_url" : "newyorker.com\/reporting\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392996937047105536",
  "text" : "Now We Are Five http:\/\/t.co\/FZlcz0adwA",
  "id" : 392996937047105536,
  "created_at" : "2013-10-23 12:52:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "indices" : [ 69, 79 ],
      "id_str" : "14677919",
      "id" : 14677919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/5P4d00i9Lc",
      "expanded_url" : "http:\/\/www.newyorker.com\/reporting\/2013\/10\/28\/131028fa_fact_sedaris?currentPage=all?mbid=social_retweet",
      "display_url" : "newyorker.com\/reporting\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392995530906693632",
  "text" : "David Sedaris: A Big Family, at the Beach http:\/\/t.co\/5P4d00i9Lc via @NewYorker",
  "id" : 392995530906693632,
  "created_at" : "2013-10-23 12:46:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392990172083941376",
  "text" : "RT @nakedpastor: Some use the text to figure out what love means. Others use love to figure out what the text means. Totally different outc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392862459968491520",
    "text" : "Some use the text to figure out what love means. Others use love to figure out what the text means. Totally different outcomes.",
    "id" : 392862459968491520,
    "created_at" : "2013-10-23 03:58:04 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 392990172083941376,
  "created_at" : "2013-10-23 12:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Pravlis Prince",
      "screen_name" : "ProvenMedia",
      "indices" : [ 3, 15 ],
      "id_str" : "24889102",
      "id" : 24889102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CaveCreek",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392800701275209729",
  "text" : "RT @ProvenMedia: Reason 1,287,300 why I love this town? Horse at the Dairy Queen drive-thru window. Only in #CaveCreek. http:\/\/t.co\/D4avonf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ProvenMedia\/status\/372180487189458944\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/D4avonfP2B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSpALmPCcAADrQj.jpg",
        "id_str" : "372180487197847552",
        "id" : 372180487197847552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSpALmPCcAADrQj.jpg",
        "sizes" : [ {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 850
        } ],
        "display_url" : "pic.twitter.com\/D4avonfP2B"
      } ],
      "hashtags" : [ {
        "text" : "CaveCreek",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372180487189458944",
    "text" : "Reason 1,287,300 why I love this town? Horse at the Dairy Queen drive-thru window. Only in #CaveCreek. http:\/\/t.co\/D4avonfP2B",
    "id" : 372180487189458944,
    "created_at" : "2013-08-27 02:15:17 +0000",
    "user" : {
      "name" : "Kim Pravlis Prince",
      "screen_name" : "ProvenMedia",
      "protected" : false,
      "id_str" : "24889102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594750836946808832\/_aEsGnW6_normal.jpg",
      "id" : 24889102,
      "verified" : false
    }
  },
  "id" : 392800701275209729,
  "created_at" : "2013-10-22 23:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tropical Traditions",
      "screen_name" : "Troptraditions",
      "indices" : [ 3, 18 ],
      "id_str" : "21357741",
      "id" : 21357741
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Japan",
      "indices" : [ 20, 26 ]
    }, {
      "text" : "HPV",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "Vaccine",
      "indices" : [ 38, 46 ]
    }, {
      "text" : "HPVVaccine",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LnXpBB00CF",
      "expanded_url" : "http:\/\/ow.ly\/pZQ6W",
      "display_url" : "ow.ly\/pZQ6W"
    } ]
  },
  "geo" : { },
  "id_str" : "392775069942185984",
  "text" : "RT @Troptraditions: #Japan Halts #HPV #Vaccine and Begins Full-Scale Probe over Safety Issues http:\/\/t.co\/LnXpBB00CF #HPVVaccine #VaccineSa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Japan",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "HPV",
        "indices" : [ 13, 17 ]
      }, {
        "text" : "Vaccine",
        "indices" : [ 18, 26 ]
      }, {
        "text" : "HPVVaccine",
        "indices" : [ 97, 108 ]
      }, {
        "text" : "VaccineSafety",
        "indices" : [ 109, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/LnXpBB00CF",
        "expanded_url" : "http:\/\/ow.ly\/pZQ6W",
        "display_url" : "ow.ly\/pZQ6W"
      } ]
    },
    "geo" : { },
    "id_str" : "392773126251352064",
    "text" : "#Japan Halts #HPV #Vaccine and Begins Full-Scale Probe over Safety Issues http:\/\/t.co\/LnXpBB00CF #HPVVaccine #VaccineSafety",
    "id" : 392773126251352064,
    "created_at" : "2013-10-22 22:03:05 +0000",
    "user" : {
      "name" : "Tropical Traditions",
      "screen_name" : "Troptraditions",
      "protected" : false,
      "id_str" : "21357741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/238634656\/logo_2_normal.jpg",
      "id" : 21357741,
      "verified" : false
    }
  },
  "id" : 392775069942185984,
  "created_at" : "2013-10-22 22:10:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 87, 95 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/pvpLZTlibV",
      "expanded_url" : "http:\/\/articles.mercola.com\/sites\/articles\/archive\/2012\/06\/10\/dr-mercola-on-ric-schiff.aspx",
      "display_url" : "articles.mercola.com\/sites\/articles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392769543560388608",
  "text" : "Chemo and Radiation Kills Child | Interview with Ric Schiff http:\/\/t.co\/pvpLZTlibV via @mercola",
  "id" : 392769543560388608,
  "created_at" : "2013-10-22 21:48:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TakePart",
      "screen_name" : "TakePart",
      "indices" : [ 3, 12 ],
      "id_str" : "13451802",
      "id" : 13451802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392764159336919040",
  "text" : "RT @TakePart: Did this gay couple just find a legal loophole all other gay couples could use to get married no matter state law?! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.wildfireapp.com\/?utm_source=Twitter&utm_medium=Tweet&utm_campaign=via%2BWildfire%2BSuite\" rel=\"nofollow\"\u003EWildfire Suite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/wqHLYssHAo",
        "expanded_url" : "http:\/\/goo.gl\/r6pVbg",
        "display_url" : "goo.gl\/r6pVbg"
      } ]
    },
    "geo" : { },
    "id_str" : "392744958048096256",
    "text" : "Did this gay couple just find a legal loophole all other gay couples could use to get married no matter state law?! http:\/\/t.co\/wqHLYssHAo",
    "id" : 392744958048096256,
    "created_at" : "2013-10-22 20:11:09 +0000",
    "user" : {
      "name" : "TakePart",
      "screen_name" : "TakePart",
      "protected" : false,
      "id_str" : "13451802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676547227775467521\/CUZtz7hO_normal.jpg",
      "id" : 13451802,
      "verified" : true
    }
  },
  "id" : 392764159336919040,
  "created_at" : "2013-10-22 21:27:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392763585493213184",
  "text" : "RT @ChrisCapparell: Humanism then, secular or otherwise, is the Love of God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392759228982906880",
    "text" : "Humanism then, secular or otherwise, is the Love of God.",
    "id" : 392759228982906880,
    "created_at" : "2013-10-22 21:07:51 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 392763585493213184,
  "created_at" : "2013-10-22 21:25:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392763556401528832",
  "text" : "RT @ChrisCapparell: To love your fellow man is to know God. Humanism then, is fellowship with the Almighty.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392754935332618240",
    "text" : "To love your fellow man is to know God. Humanism then, is fellowship with the Almighty.",
    "id" : 392754935332618240,
    "created_at" : "2013-10-22 20:50:48 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 392763556401528832,
  "created_at" : "2013-10-22 21:25:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/392754766071095296\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/lWdd4dK8ob",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXNYYPSCQAA4zXS.jpg",
      "id_str" : "392754765953646592",
      "id" : 392754765953646592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXNYYPSCQAA4zXS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/lWdd4dK8ob"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392763538122743808",
  "text" : "RT @ChrisCapparell: All commandments are summed up in the one: love your neighbor as yourself. http:\/\/t.co\/lWdd4dK8ob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/392754766071095296\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/lWdd4dK8ob",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXNYYPSCQAA4zXS.jpg",
        "id_str" : "392754765953646592",
        "id" : 392754765953646592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXNYYPSCQAA4zXS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/lWdd4dK8ob"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392754766071095296",
    "text" : "All commandments are summed up in the one: love your neighbor as yourself. http:\/\/t.co\/lWdd4dK8ob",
    "id" : 392754766071095296,
    "created_at" : "2013-10-22 20:50:07 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 392763538122743808,
  "created_at" : "2013-10-22 21:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392763431029587968",
  "text" : "RT @ChrisCapparell: Moreover, regardless of theological perspective, regardless of anything, whoever loves others as himself is not only sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392754085746974721",
    "text" : "Moreover, regardless of theological perspective, regardless of anything, whoever loves others as himself is not only saved, but perfect.",
    "id" : 392754085746974721,
    "created_at" : "2013-10-22 20:47:25 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 392763431029587968,
  "created_at" : "2013-10-22 21:24:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/392753603892355072\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ksNVwdayxT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXNXUlwCMAEPjRG.jpg",
      "id_str" : "392753603753947137",
      "id" : 392753603753947137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXNXUlwCMAEPjRG.jpg",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ksNVwdayxT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392763406539034624",
  "text" : "RT @ChrisCapparell: There's only one commandment. Therefore whoever loves others as himself knows God and is saved. http:\/\/t.co\/ksNVwdayxT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/392753603892355072\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ksNVwdayxT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXNXUlwCMAEPjRG.jpg",
        "id_str" : "392753603753947137",
        "id" : 392753603753947137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXNXUlwCMAEPjRG.jpg",
        "sizes" : [ {
          "h" : 362,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/ksNVwdayxT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392753603892355072",
    "text" : "There's only one commandment. Therefore whoever loves others as himself knows God and is saved. http:\/\/t.co\/ksNVwdayxT",
    "id" : 392753603892355072,
    "created_at" : "2013-10-22 20:45:30 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 392763406539034624,
  "created_at" : "2013-10-22 21:24:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/0xDMLWIsC4",
      "expanded_url" : "http:\/\/www.themilitantbaker.com\/2013\/03\/things-no-one-will-tell-fat-girls-so-i.html?spref=tw",
      "display_url" : "themilitantbaker.com\/2013\/03\/things\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392754961869574144",
  "text" : "The Militant Baker: THINGS NO ONE WILL TELL FAT GIRLS...SO I WILL http:\/\/t.co\/0xDMLWIsC4",
  "id" : 392754961869574144,
  "created_at" : "2013-10-22 20:50:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/3x9cdddcL0",
      "expanded_url" : "http:\/\/huff.to\/1abqWlS",
      "display_url" : "huff.to\/1abqWlS"
    } ]
  },
  "geo" : { },
  "id_str" : "392754800724430850",
  "text" : "Here are a few of \"excuses\" for not being Maria-Kang fit http:\/\/t.co\/3x9cdddcL0",
  "id" : 392754800724430850,
  "created_at" : "2013-10-22 20:50:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392749134358536192",
  "text" : "RT @Master_Synaps: The arms industries make huge profits on conflict. I guess they are not working for peace.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392747779413393408",
    "text" : "The arms industries make huge profits on conflict. I guess they are not working for peace.",
    "id" : 392747779413393408,
    "created_at" : "2013-10-22 20:22:22 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 392749134358536192,
  "created_at" : "2013-10-22 20:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392745598941921280",
  "text" : "RT @ificouldtellu: God is no one else but the consciousness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392744629059072000",
    "text" : "God is no one else but the consciousness.",
    "id" : 392744629059072000,
    "created_at" : "2013-10-22 20:09:51 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 392745598941921280,
  "created_at" : "2013-10-22 20:13:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392735647783325697",
  "text" : "@1stCitizenKane i don't think there is such a thing as justice...",
  "id" : 392735647783325697,
  "created_at" : "2013-10-22 19:34:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Hart",
      "screen_name" : "michellehart99",
      "indices" : [ 3, 18 ],
      "id_str" : "1180917524",
      "id" : 1180917524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392731137266970624",
  "text" : "RT @michellehart99: Rob Pennell on twitter is adding names of people who are pro-choice to a \"baby killer\" list he's created. Harassing wom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392730245268115456",
    "text" : "Rob Pennell on twitter is adding names of people who are pro-choice to a \"baby killer\" list he's created. Harassing women currently.",
    "id" : 392730245268115456,
    "created_at" : "2013-10-22 19:12:41 +0000",
    "user" : {
      "name" : "Michelle Hart",
      "screen_name" : "michellehart99",
      "protected" : false,
      "id_str" : "1180917524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800462862275616772\/dtys9WDh_normal.jpg",
      "id" : 1180917524,
      "verified" : false
    }
  },
  "id" : 392731137266970624,
  "created_at" : "2013-10-22 19:16:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "Copwatch",
      "screen_name" : "Copwatch",
      "indices" : [ 18, 27 ],
      "id_str" : "116625196",
      "id" : 116625196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392729381573259265",
  "text" : "RT @Jamiastar: RT @Copwatch: Placing someone in a cage for a non-violent offense should be considered anathema to common sense. #restorativ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Copwatch",
        "screen_name" : "Copwatch",
        "indices" : [ 3, 12 ],
        "id_str" : "116625196",
        "id" : 116625196
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "restorativejustice",
        "indices" : [ 113, 132 ]
      }, {
        "text" : "o22",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392725329489313792",
    "text" : "RT @Copwatch: Placing someone in a cage for a non-violent offense should be considered anathema to common sense. #restorativejustice #o22",
    "id" : 392725329489313792,
    "created_at" : "2013-10-22 18:53:09 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 392729381573259265,
  "created_at" : "2013-10-22 19:09:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 0, 9 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392726732987310080",
  "geo" : { },
  "id_str" : "392729085559844864",
  "in_reply_to_user_id" : 309558781,
  "text" : "@KellyRek ann coulter said it was designed to fail to make it easier to get to #singlepayer .. i like to think of it that way.",
  "id" : 392729085559844864,
  "in_reply_to_status_id" : 392726732987310080,
  "created_at" : "2013-10-22 19:08:05 +0000",
  "in_reply_to_screen_name" : "KellyRek",
  "in_reply_to_user_id_str" : "309558781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    }, {
      "name" : "Aloe Academy",
      "screen_name" : "AcademyAloe",
      "indices" : [ 21, 33 ],
      "id_str" : "324849936",
      "id" : 324849936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392721909982699520",
  "text" : "RT @JeffreyGuterman: @AcademyAloe Study not suggesting no discipline: positive parenting  suggested as spanking contributes neg cognitive d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aloe Academy",
        "screen_name" : "AcademyAloe",
        "indices" : [ 0, 12 ],
        "id_str" : "324849936",
        "id" : 324849936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "392588969663143936",
    "geo" : { },
    "id_str" : "392594492374540288",
    "in_reply_to_user_id" : 324849936,
    "text" : "@AcademyAloe Study not suggesting no discipline: positive parenting  suggested as spanking contributes neg cognitive development in children",
    "id" : 392594492374540288,
    "in_reply_to_status_id" : 392588969663143936,
    "created_at" : "2013-10-22 10:13:15 +0000",
    "in_reply_to_screen_name" : "AcademyAloe",
    "in_reply_to_user_id_str" : "324849936",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 392721909982699520,
  "created_at" : "2013-10-22 18:39:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 18, 32 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392705475718152192",
  "text" : "RT @Jamiastar: RT @JohnFugelsang: Every fish you catch and release goes home with an alien abduction story.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Fugelsang",
        "screen_name" : "JohnFugelsang",
        "indices" : [ 3, 17 ],
        "id_str" : "33276161",
        "id" : 33276161
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392686141259804672",
    "text" : "RT @JohnFugelsang: Every fish you catch and release goes home with an alien abduction story.",
    "id" : 392686141259804672,
    "created_at" : "2013-10-22 16:17:26 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 392705475718152192,
  "created_at" : "2013-10-22 17:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DfvMQCzHQ8",
      "expanded_url" : "http:\/\/youtu.be\/lJzcDwZD16Q",
      "display_url" : "youtu.be\/lJzcDwZD16Q"
    } ]
  },
  "geo" : { },
  "id_str" : "392694779823128576",
  "text" : "here it is again&gt;&gt; The Exploding Autoimmune Epidemic with Dr. Tent: It's Not Autoimmune, You Have Viruses: http:\/\/t.co\/DfvMQCzHQ8",
  "id" : 392694779823128576,
  "created_at" : "2013-10-22 16:51:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392693778223337473",
  "text" : "has anyone watched that video i posted yesterday? i still have about 30 min to go. very interesting.",
  "id" : 392693778223337473,
  "created_at" : "2013-10-22 16:47:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392692209251655680",
  "text" : "bible study today we discussed evolution. enough said.",
  "id" : 392692209251655680,
  "created_at" : "2013-10-22 16:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392645077967060992",
  "text" : "RT @Buddhaworld: We all take a long ride to nowhere. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392635092109393920",
    "text" : "We all take a long ride to nowhere. Buddha volko",
    "id" : 392635092109393920,
    "created_at" : "2013-10-22 12:54:35 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 392645077967060992,
  "created_at" : "2013-10-22 13:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/iISo0F3t15",
      "expanded_url" : "http:\/\/youtu.be\/QPKKQnijnsM",
      "display_url" : "youtu.be\/QPKKQnijnsM"
    } ]
  },
  "geo" : { },
  "id_str" : "392425047412858880",
  "text" : "Wealth Inequality in America: http:\/\/t.co\/iISo0F3t15 via @youtube",
  "id" : 392425047412858880,
  "created_at" : "2013-10-21 22:59:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392420489697562624",
  "geo" : { },
  "id_str" : "392421277144600576",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon cool!",
  "id" : 392421277144600576,
  "in_reply_to_status_id" : 392420489697562624,
  "created_at" : "2013-10-21 22:44:57 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 3, 13 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "networking",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "socializing",
      "indices" : [ 97, 109 ]
    }, {
      "text" : "introvert",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392420465886912512",
  "text" : "RT @LonerW0lf: \"Antisocial Networking: Meet and Tweet\". My kind of networking ... :3 #networking #socializing #introvert \u263D http:\/\/t.co\/LitQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LonerW0lf\/status\/392409595521404928\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/LitQxMo9YA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXIecrPCEAAamfH.jpg",
        "id_str" : "392409595525599232",
        "id" : 392409595525599232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXIecrPCEAAamfH.jpg",
        "sizes" : [ {
          "h" : 297,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 549
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 549
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 549
        } ],
        "display_url" : "pic.twitter.com\/LitQxMo9YA"
      } ],
      "hashtags" : [ {
        "text" : "networking",
        "indices" : [ 70, 81 ]
      }, {
        "text" : "socializing",
        "indices" : [ 82, 94 ]
      }, {
        "text" : "introvert",
        "indices" : [ 95, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392409595521404928",
    "text" : "\"Antisocial Networking: Meet and Tweet\". My kind of networking ... :3 #networking #socializing #introvert \u263D http:\/\/t.co\/LitQxMo9YA",
    "id" : 392409595521404928,
    "created_at" : "2013-10-21 21:58:32 +0000",
    "user" : {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "protected" : false,
      "id_str" : "536104771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776397232455061504\/lKsVf5C5_normal.jpg",
      "id" : 536104771,
      "verified" : false
    }
  },
  "id" : 392420465886912512,
  "created_at" : "2013-10-21 22:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insurance",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392391851439030274",
  "text" : "RT @KellyRek: Private #insurance is \"closed network\" restricting choice of doctors. #SinglePayer is \"open network\" with freedom to choose y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insurance",
        "indices" : [ 8, 18 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 70, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392390718594887680",
    "text" : "Private #insurance is \"closed network\" restricting choice of doctors. #SinglePayer is \"open network\" with freedom to choose your OWN doctor.",
    "id" : 392390718594887680,
    "created_at" : "2013-10-21 20:43:32 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 392391851439030274,
  "created_at" : "2013-10-21 20:48:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 0, 15 ],
      "id_str" : "17376893",
      "id" : 17376893
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 16, 28 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392360828227158017",
  "geo" : { },
  "id_str" : "392389230262886400",
  "in_reply_to_user_id" : 17376893,
  "text" : "@RightWingWatch @VirgoJohnny ((head to desk))",
  "id" : 392389230262886400,
  "in_reply_to_status_id" : 392360828227158017,
  "created_at" : "2013-10-21 20:37:37 +0000",
  "in_reply_to_screen_name" : "RightWingWatch",
  "in_reply_to_user_id_str" : "17376893",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392387612427964416",
  "text" : "RT @ZachsMind: this isn't my opinion. it's not my belief. XX b4 XY is scientifically confirmed whether we believe in it or not. i'm not mak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392385624482648064",
    "text" : "this isn't my opinion. it's not my belief. XX b4 XY is scientifically confirmed whether we believe in it or not. i'm not making this shit up",
    "id" : 392385624482648064,
    "created_at" : "2013-10-21 20:23:17 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 392387612427964416,
  "created_at" : "2013-10-21 20:31:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392362691928416256",
  "text" : "look past the idea of God connected to any religion or the afterlife as a stagnant, eternal resting place...",
  "id" : 392362691928416256,
  "created_at" : "2013-10-21 18:52:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ebookporn",
      "screen_name" : "ebookporn",
      "indices" : [ 3, 13 ],
      "id_str" : "268239319",
      "id" : 268239319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392352966348640256",
  "text" : "RT @ebookporn: Wolfram Alpha adds 649 Pokemon to its search database - Wolfram Alpha, the search engine which bills itself... http:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/tILupoTc4B",
        "expanded_url" : "http:\/\/tmblr.co\/ZOFlCyyG6FNM",
        "display_url" : "tmblr.co\/ZOFlCyyG6FNM"
      } ]
    },
    "geo" : { },
    "id_str" : "392350499594596352",
    "text" : "Wolfram Alpha adds 649 Pokemon to its search database - Wolfram Alpha, the search engine which bills itself... http:\/\/t.co\/tILupoTc4B",
    "id" : 392350499594596352,
    "created_at" : "2013-10-21 18:03:43 +0000",
    "user" : {
      "name" : "ebookporn",
      "screen_name" : "ebookporn",
      "protected" : false,
      "id_str" : "268239319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602160548365598720\/0Q3NH41T_normal.png",
      "id" : 268239319,
      "verified" : false
    }
  },
  "id" : 392352966348640256,
  "created_at" : "2013-10-21 18:13:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/oJt7mBHCB4",
      "expanded_url" : "http:\/\/news.google.com\/newspapers?id=GwcrAAAAIBAJ&sjid=TJgFAAAAIBAJ&pg=2043%2C2589024",
      "display_url" : "news.google.com\/newspapers?id=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392352309792886784",
  "text" : "Dr. Ochsner inoculated his own grandchildren. 1 died -but not due to vaccine? http:\/\/t.co\/oJt7mBHCB4",
  "id" : 392352309792886784,
  "created_at" : "2013-10-21 18:10:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/wvWeUwtC9z",
      "expanded_url" : "http:\/\/leftymathprof.wordpress.com\/anarchist-jesus\/",
      "display_url" : "leftymathprof.wordpress.com\/anarchist-jesu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392304780824940544",
  "text" : "one authoritarian explained it to me, \u201Cwe do not obey God because He is good, but rather because He is God.\u201D http:\/\/t.co\/wvWeUwtC9z",
  "id" : 392304780824940544,
  "created_at" : "2013-10-21 15:02:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/wvWeUwtC9z",
      "expanded_url" : "http:\/\/leftymathprof.wordpress.com\/anarchist-jesus\/",
      "display_url" : "leftymathprof.wordpress.com\/anarchist-jesu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392304287755157504",
  "text" : "Jesus the King is worshiped by authoritarians (people who believe that society always needs someone in charge) http:\/\/t.co\/wvWeUwtC9z",
  "id" : 392304287755157504,
  "created_at" : "2013-10-21 15:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 3, 19 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/4x6TWymzTg",
      "expanded_url" : "http:\/\/youtu.be\/lJzcDwZD16Q",
      "display_url" : "youtu.be\/lJzcDwZD16Q"
    } ]
  },
  "geo" : { },
  "id_str" : "392303215448182784",
  "text" : "RT @AlterEgoTrip_se: The Exploding Autoimmune Epidemic with Dr. Tent: It's Not Autoimmune, you have Viruses : http:\/\/t.co\/4x6TWymzTg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/4x6TWymzTg",
        "expanded_url" : "http:\/\/youtu.be\/lJzcDwZD16Q",
        "display_url" : "youtu.be\/lJzcDwZD16Q"
      } ]
    },
    "geo" : { },
    "id_str" : "392296633930506241",
    "text" : "The Exploding Autoimmune Epidemic with Dr. Tent: It's Not Autoimmune, you have Viruses : http:\/\/t.co\/4x6TWymzTg",
    "id" : 392296633930506241,
    "created_at" : "2013-10-21 14:29:40 +0000",
    "user" : {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "protected" : false,
      "id_str" : "344209049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779194958410579968\/qUDtmyLs_normal.jpg",
      "id" : 344209049,
      "verified" : false
    }
  },
  "id" : 392303215448182784,
  "created_at" : "2013-10-21 14:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "indices" : [ 3, 14 ],
      "id_str" : "33773592",
      "id" : 33773592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/cUGnir4cGb",
      "expanded_url" : "https:\/\/www.twitter.com\/AstroKatie\/lists\/women-in-astro-phys-etc\/",
      "display_url" : "twitter.com\/AstroKatie\/lis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392300624039399425",
  "text" : "RT @AstroKatie: Looking for awesome women in physics &amp; astronomy to follow on Twitter? I made a list: https:\/\/t.co\/cUGnir4cGb (incl some re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/cUGnir4cGb",
        "expanded_url" : "https:\/\/www.twitter.com\/AstroKatie\/lists\/women-in-astro-phys-etc\/",
        "display_url" : "twitter.com\/AstroKatie\/lis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392280589165805568",
    "text" : "Looking for awesome women in physics &amp; astronomy to follow on Twitter? I made a list: https:\/\/t.co\/cUGnir4cGb (incl some related fields)",
    "id" : 392280589165805568,
    "created_at" : "2013-10-21 13:25:55 +0000",
    "user" : {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "protected" : false,
      "id_str" : "33773592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2818477708\/0ef050189a11bb7f9cf56306f5d171bf_normal.png",
      "id" : 33773592,
      "verified" : true
    }
  },
  "id" : 392300624039399425,
  "created_at" : "2013-10-21 14:45:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inkbee Publishing",
      "screen_name" : "InkbeeBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "1444909298",
      "id" : 1444909298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392299434996170752",
  "text" : "RT @InkbeeBooks: We're marking the publication of Lives &amp; Times (great Xmas gift!) with a Kobo mini eReader #giveaway. RT once for a chance\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaway",
        "indices" : [ 95, 104 ]
      }, {
        "text" : "win",
        "indices" : [ 130, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392257396326031360",
    "text" : "We're marking the publication of Lives &amp; Times (great Xmas gift!) with a Kobo mini eReader #giveaway. RT once for a chance to #win by 1 Nov.",
    "id" : 392257396326031360,
    "created_at" : "2013-10-21 11:53:45 +0000",
    "user" : {
      "name" : "Inkbee Publishing",
      "screen_name" : "InkbeeBooks",
      "protected" : false,
      "id_str" : "1444909298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3691336751\/c3590a120f2f647dddb96cb7bc94ffa7_normal.jpeg",
      "id" : 1444909298,
      "verified" : false
    }
  },
  "id" : 392299434996170752,
  "created_at" : "2013-10-21 14:40:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/OICScYCast",
      "expanded_url" : "http:\/\/tideliar.blogspot.com\/2013\/09\/in-which-i-feel-nagging-sense-of-unease_11.html",
      "display_url" : "tideliar.blogspot.com\/2013\/09\/in-whi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392297828938047488",
  "text" : "Some Lies: In which I feel a nagging sense of unease and shame http:\/\/t.co\/OICScYCast \"I walked away, making excuses to myself\"",
  "id" : 392297828938047488,
  "created_at" : "2013-10-21 14:34:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392293400168239104",
  "text" : "@Skeptical_Lady \"the 24 hr hell channel on TV\" LOLOL",
  "id" : 392293400168239104,
  "created_at" : "2013-10-21 14:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 88, 97 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/3KyrqmIeHP",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/01\/02\/1175717\/-Why-doesn-t-anyone-ask-Rumsfeld-where-the-2-3-TRILLION-went",
      "display_url" : "dailykos.com\/story\/2013\/01\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392290106532315138",
  "text" : "Why doesn't anyone ask Rumsfeld where the 2.3 TRILLION went? http:\/\/t.co\/3KyrqmIeHP via @dailykos",
  "id" : 392290106532315138,
  "created_at" : "2013-10-21 14:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392285299268538370",
  "text" : "my consciousness is being expanded.. so there's a chance I might go insane shortly.",
  "id" : 392285299268538370,
  "created_at" : "2013-10-21 13:44:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "Cait",
      "screen_name" : "JanuaryCait",
      "indices" : [ 10, 22 ],
      "id_str" : "948471642",
      "id" : 948471642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392047400132411392",
  "geo" : { },
  "id_str" : "392052049417740288",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits @JanuaryCait  Yes, exactly! : )",
  "id" : 392052049417740288,
  "in_reply_to_status_id" : 392047400132411392,
  "created_at" : "2013-10-20 22:17:47 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392039762975932416",
  "geo" : { },
  "id_str" : "392043151147290624",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny LOL",
  "id" : 392043151147290624,
  "in_reply_to_status_id" : 392039762975932416,
  "created_at" : "2013-10-20 21:42:25 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392016788890079232",
  "geo" : { },
  "id_str" : "392018238655062016",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg we're on Taconic often.. to head South toward Pough. or North toward Rhinebeck.",
  "id" : 392018238655062016,
  "in_reply_to_status_id" : 392016788890079232,
  "created_at" : "2013-10-20 20:03:26 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392004201817313280",
  "geo" : { },
  "id_str" : "392005436922015744",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg halfway between NYC and Albany. Close to Rhinebeck or Poughkeepsie.",
  "id" : 392005436922015744,
  "in_reply_to_status_id" : 392004201817313280,
  "created_at" : "2013-10-20 19:12:33 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392001145834835968",
  "geo" : { },
  "id_str" : "392002718899793920",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg nice smiles.. happy, happy, happy. : )",
  "id" : 392002718899793920,
  "in_reply_to_status_id" : 392001145834835968,
  "created_at" : "2013-10-20 19:01:45 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391991199705206784",
  "geo" : { },
  "id_str" : "391992522966196225",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 LOLOL",
  "id" : 391992522966196225,
  "in_reply_to_status_id" : 391991199705206784,
  "created_at" : "2013-10-20 18:21:15 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Czaban",
      "screen_name" : "czabe",
      "indices" : [ 3, 9 ],
      "id_str" : "29205350",
      "id" : 29205350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391981652395958273",
  "text" : "RT @czabe: Let's not get hysterical yet. They'll be plenty of time for that later.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391980759088521216",
    "text" : "Let's not get hysterical yet. They'll be plenty of time for that later.",
    "id" : 391980759088521216,
    "created_at" : "2013-10-20 17:34:30 +0000",
    "user" : {
      "name" : "Steve Czaban",
      "screen_name" : "czabe",
      "protected" : false,
      "id_str" : "29205350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771085630243831808\/BG4UJKkZ_normal.jpg",
      "id" : 29205350,
      "verified" : false
    }
  },
  "id" : 391981652395958273,
  "created_at" : "2013-10-20 17:38:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391968906459746304",
  "geo" : { },
  "id_str" : "391969842896449536",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg Nice!",
  "id" : 391969842896449536,
  "in_reply_to_status_id" : 391968906459746304,
  "created_at" : "2013-10-20 16:51:07 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Warrior Puss\u2122)))",
      "screen_name" : "joan_evans_nyc",
      "indices" : [ 3, 18 ],
      "id_str" : "358277172",
      "id" : 358277172
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/joan_evans_nyc\/status\/391964192401416192\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/1uneUUZ8mU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXCJWyuCcAAYC82.jpg",
      "id_str" : "391964192246231040",
      "id" : 391964192246231040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXCJWyuCcAAYC82.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 427
      } ],
      "display_url" : "pic.twitter.com\/1uneUUZ8mU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391969628064612352",
  "text" : "RT @joan_evans_nyc: my prom dress!\n\n~ http:\/\/t.co\/1uneUUZ8mU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/joan_evans_nyc\/status\/391964192401416192\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/1uneUUZ8mU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXCJWyuCcAAYC82.jpg",
        "id_str" : "391964192246231040",
        "id" : 391964192246231040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXCJWyuCcAAYC82.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        } ],
        "display_url" : "pic.twitter.com\/1uneUUZ8mU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391964192401416192",
    "text" : "my prom dress!\n\n~ http:\/\/t.co\/1uneUUZ8mU",
    "id" : 391964192401416192,
    "created_at" : "2013-10-20 16:28:40 +0000",
    "user" : {
      "name" : "(((Warrior Puss\u2122)))",
      "screen_name" : "joan_evans_nyc",
      "protected" : false,
      "id_str" : "358277172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704806843751727104\/Y1Mo4wwI_normal.jpg",
      "id" : 358277172,
      "verified" : false
    }
  },
  "id" : 391969628064612352,
  "created_at" : "2013-10-20 16:50:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deer",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "nature",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/hPb526ytsg",
      "expanded_url" : "http:\/\/goo.gl\/TyyfJl",
      "display_url" : "goo.gl\/TyyfJl"
    } ]
  },
  "geo" : { },
  "id_str" : "391966999397826560",
  "text" : "RT @KerriFar: \"A Forest Find\" ~ http:\/\/t.co\/hPb526ytsg ~ #deer #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "deer",
        "indices" : [ 43, 48 ]
      }, {
        "text" : "nature",
        "indices" : [ 49, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/hPb526ytsg",
        "expanded_url" : "http:\/\/goo.gl\/TyyfJl",
        "display_url" : "goo.gl\/TyyfJl"
      } ]
    },
    "geo" : { },
    "id_str" : "391965990172778496",
    "text" : "\"A Forest Find\" ~ http:\/\/t.co\/hPb526ytsg ~ #deer #nature",
    "id" : 391965990172778496,
    "created_at" : "2013-10-20 16:35:49 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 391966999397826560,
  "created_at" : "2013-10-20 16:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391960966231261184",
  "text" : "RT @vaxen_var: Ponzi scheme - an investment operation that pays returns to investors from money paid by subsequent investors rather than fr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391960588282109952",
    "text" : "Ponzi scheme - an investment operation that pays returns to investors from money paid by subsequent investors rather than from profit.",
    "id" : 391960588282109952,
    "created_at" : "2013-10-20 16:14:21 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 391960966231261184,
  "created_at" : "2013-10-20 16:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391960925072539648",
  "text" : "RT @vaxen_var: This causes inflation, and the purchasing power you lose to inflation goes into the pockets of the bankers. It's a great fra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391960420908425217",
    "text" : "This causes inflation, and the purchasing power you lose to inflation goes into the pockets of the bankers. It's a great fraud.",
    "id" : 391960420908425217,
    "created_at" : "2013-10-20 16:13:41 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 391960925072539648,
  "created_at" : "2013-10-20 16:15:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391953023574224896",
  "geo" : { },
  "id_str" : "391953664933240832",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH smooches on that sweet nose!",
  "id" : 391953664933240832,
  "in_reply_to_status_id" : 391953023574224896,
  "created_at" : "2013-10-20 15:46:50 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391947348269481984",
  "text" : "i discovered that the Spite &amp; Malice app on my #kindlefire let's me win.. sigh.",
  "id" : 391947348269481984,
  "created_at" : "2013-10-20 15:21:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 0, 12 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "christian",
      "indices" : [ 107, 117 ]
    }, {
      "text" : "prochoice",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/b07cvYcBrB",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-ld",
      "display_url" : "wp.me\/p372Ye-ld"
    } ]
  },
  "geo" : { },
  "id_str" : "391944296410005504",
  "text" : "@HelloPoodle you might like this &gt;&gt; Ordeal of the Bitter Waters series links: http:\/\/t.co\/b07cvYcBrB #christian #prochoice",
  "id" : 391944296410005504,
  "created_at" : "2013-10-20 15:09:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391934754301288448",
  "geo" : { },
  "id_str" : "391935370092228609",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist LOL",
  "id" : 391935370092228609,
  "in_reply_to_status_id" : 391934754301288448,
  "created_at" : "2013-10-20 14:34:08 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prochoice",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391716971760603136",
  "text" : "RT @virtusetveritas: If you'd like to share my Ordeal of the Bitter Waters series, on how I slowly became #prochoice, here's the links: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prochoice",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Pc9olhq8di",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-ld",
        "display_url" : "wp.me\/p372Ye-ld"
      } ]
    },
    "geo" : { },
    "id_str" : "391716147118088192",
    "text" : "If you'd like to share my Ordeal of the Bitter Waters series, on how I slowly became #prochoice, here's the links: http:\/\/t.co\/Pc9olhq8di",
    "id" : 391716147118088192,
    "created_at" : "2013-10-20 00:03:01 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 391716971760603136,
  "created_at" : "2013-10-20 00:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391707586065481729",
  "geo" : { },
  "id_str" : "391710550494695424",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH it's right up there w abortion in terms of a hot topic. ppl get crazy.",
  "id" : 391710550494695424,
  "in_reply_to_status_id" : 391707586065481729,
  "created_at" : "2013-10-19 23:40:47 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391681742719168512",
  "geo" : { },
  "id_str" : "391688567153389568",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste exciting!",
  "id" : 391688567153389568,
  "in_reply_to_status_id" : 391681742719168512,
  "created_at" : "2013-10-19 22:13:26 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myblog",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391670208206622720",
  "text" : "i need to work on my tag cloud.. like the actual tags. there are too many. #myblog",
  "id" : 391670208206622720,
  "created_at" : "2013-10-19 21:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391663227555155968",
  "geo" : { },
  "id_str" : "391666409228357633",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time LOL.. i adore you! xo",
  "id" : 391666409228357633,
  "in_reply_to_status_id" : 391663227555155968,
  "created_at" : "2013-10-19 20:45:23 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ICjvTBJHMa",
      "expanded_url" : "http:\/\/www.moosebegab.com\/lefty\/",
      "display_url" : "moosebegab.com\/lefty\/"
    } ]
  },
  "geo" : { },
  "id_str" : "391661370740981760",
  "text" : "my latest blog post: http:\/\/t.co\/ICjvTBJHMa",
  "id" : 391661370740981760,
  "created_at" : "2013-10-19 20:25:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarrelOfOranges",
      "screen_name" : "BarrelOfOranges",
      "indices" : [ 3, 19 ],
      "id_str" : "2511439430",
      "id" : 2511439430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UNjTcxbgSB",
      "expanded_url" : "http:\/\/www.rolereboot.org\/culture-and-politics\/details\/2013-10-an-anti-abortion-organization-used-the-story-of-my-d#.UmLUHLgT_Bs.twitter",
      "display_url" : "rolereboot.org\/culture-and-po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391646034344284160",
  "text" : "RT @BarrelOfOranges: An Anti-Abortion Organization Used The Story Of My Dying Son: http:\/\/t.co\/UNjTcxbgSB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/UNjTcxbgSB",
        "expanded_url" : "http:\/\/www.rolereboot.org\/culture-and-politics\/details\/2013-10-an-anti-abortion-organization-used-the-story-of-my-d#.UmLUHLgT_Bs.twitter",
        "display_url" : "rolereboot.org\/culture-and-po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391638614402007040",
    "text" : "An Anti-Abortion Organization Used The Story Of My Dying Son: http:\/\/t.co\/UNjTcxbgSB",
    "id" : 391638614402007040,
    "created_at" : "2013-10-19 18:54:56 +0000",
    "user" : {
      "name" : "The Fuckall Feminist",
      "screen_name" : "FuckallFeminist",
      "protected" : false,
      "id_str" : "465051974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/437338659704930304\/8wnjv3oa_normal.jpeg",
      "id" : 465051974,
      "verified" : false
    }
  },
  "id" : 391646034344284160,
  "created_at" : "2013-10-19 19:24:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391601183112310785",
  "geo" : { },
  "id_str" : "391607440917016576",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell looking back, i can see where i have done #3's, some intentional, some not. hopefully, no more of those! : )",
  "id" : 391607440917016576,
  "in_reply_to_status_id" : 391601183112310785,
  "created_at" : "2013-10-19 16:51:04 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391600805734023168",
  "geo" : { },
  "id_str" : "391606796759990272",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell wonderful examples! hmm.. that could be made into a study of sorts.",
  "id" : 391606796759990272,
  "in_reply_to_status_id" : 391600805734023168,
  "created_at" : "2013-10-19 16:48:30 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391593450678022144",
  "geo" : { },
  "id_str" : "391595597603422209",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell if i truly believed this one life was IT.. perhaps i would not be so concerned about my actions (or, moreso, inactions)",
  "id" : 391595597603422209,
  "in_reply_to_status_id" : 391593450678022144,
  "created_at" : "2013-10-19 16:04:00 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391593450678022144",
  "geo" : { },
  "id_str" : "391595017686364160",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell sort of.. but not quite. hard to explain. i think we are here to grow. doing \"the right thing\" helps growth.",
  "id" : 391595017686364160,
  "in_reply_to_status_id" : 391593450678022144,
  "created_at" : "2013-10-19 16:01:42 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391587383655010304",
  "geo" : { },
  "id_str" : "391592673544396800",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell in a way, i believe this of myself. not from fear of hell\/wrath but the idea that im creating more work for myself.",
  "id" : 391592673544396800,
  "in_reply_to_status_id" : 391587383655010304,
  "created_at" : "2013-10-19 15:52:23 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/6mG2EbMZu2",
      "expanded_url" : "http:\/\/youtu.be\/mII9NZ8MMVM",
      "display_url" : "youtu.be\/mII9NZ8MMVM"
    } ]
  },
  "geo" : { },
  "id_str" : "391341629857988609",
  "text" : "The Collapse of The American Dream Explained in Animation: http:\/\/t.co\/6mG2EbMZu2",
  "id" : 391341629857988609,
  "created_at" : "2013-10-18 23:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "montag",
      "screen_name" : "buffaloon",
      "indices" : [ 3, 13 ],
      "id_str" : "133793696",
      "id" : 133793696
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 119, 129 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/wLPkRTKWzi",
      "expanded_url" : "http:\/\/shar.es\/E8Drh",
      "display_url" : "shar.es\/E8Drh"
    } ]
  },
  "geo" : { },
  "id_str" : "391326413422620672",
  "text" : "RT @buffaloon: Cuban Canadian Ted Cruz Is A Grifter Who Believes In Divine Wealth Transfers http:\/\/t.co\/wLPkRTKWzi via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 104, 114 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/wLPkRTKWzi",
        "expanded_url" : "http:\/\/shar.es\/E8Drh",
        "display_url" : "shar.es\/E8Drh"
      } ]
    },
    "geo" : { },
    "id_str" : "391324556540928000",
    "text" : "Cuban Canadian Ted Cruz Is A Grifter Who Believes In Divine Wealth Transfers http:\/\/t.co\/wLPkRTKWzi via @sharethis",
    "id" : 391324556540928000,
    "created_at" : "2013-10-18 22:06:59 +0000",
    "user" : {
      "name" : "montag",
      "screen_name" : "buffaloon",
      "protected" : false,
      "id_str" : "133793696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2172998794\/images_normal.jpg",
      "id" : 133793696,
      "verified" : false
    }
  },
  "id" : 391326413422620672,
  "created_at" : "2013-10-18 22:14:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 0, 13 ],
      "id_str" : "926185416",
      "id" : 926185416
    }, {
      "name" : "Jonathan Jewel",
      "screen_name" : "jonathanjewel",
      "indices" : [ 30, 44 ],
      "id_str" : "401090263",
      "id" : 401090263
    }, {
      "name" : "PoliticusUSA",
      "screen_name" : "politicususa",
      "indices" : [ 45, 58 ],
      "id_str" : "14792049",
      "id" : 14792049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391300036144820224",
  "geo" : { },
  "id_str" : "391305046752653312",
  "in_reply_to_user_id" : 926185416,
  "text" : "@hoosierworld we love bernie! @JonathanJewel @politicususa",
  "id" : 391305046752653312,
  "in_reply_to_status_id" : 391300036144820224,
  "created_at" : "2013-10-18 20:49:27 +0000",
  "in_reply_to_screen_name" : "hoosierworld",
  "in_reply_to_user_id_str" : "926185416",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Kf0JvkPSEE",
      "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/october\/24-million-will-be-permitted-to-remain-uninsured-without-penalty",
      "display_url" : "pnhp.org\/news\/2013\/octo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391304302322810880",
  "text" : "RT @PNHP: The ACA has been touted as universal. About that... http:\/\/t.co\/Kf0JvkPSEE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/Kf0JvkPSEE",
        "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/october\/24-million-will-be-permitted-to-remain-uninsured-without-penalty",
        "display_url" : "pnhp.org\/news\/2013\/octo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391302193556373504",
    "text" : "The ACA has been touted as universal. About that... http:\/\/t.co\/Kf0JvkPSEE",
    "id" : 391302193556373504,
    "created_at" : "2013-10-18 20:38:07 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 391304302322810880,
  "created_at" : "2013-10-18 20:46:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391303339406655489",
  "text" : "oh god.. i hope dh did not poison me..",
  "id" : 391303339406655489,
  "created_at" : "2013-10-18 20:42:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giant George",
      "screen_name" : "GiantGeorgeAZ",
      "indices" : [ 3, 17 ],
      "id_str" : "81468711",
      "id" : 81468711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391275590772621312",
  "text" : "RT @GiantGeorgeAZ: It is with a heavy heart that we announce Giant George died last night. George passed away peacefully surrounded... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/rmVK8lh9i8",
        "expanded_url" : "http:\/\/fb.me\/25fWgZQmr",
        "display_url" : "fb.me\/25fWgZQmr"
      } ]
    },
    "geo" : { },
    "id_str" : "391274865615200256",
    "text" : "It is with a heavy heart that we announce Giant George died last night. George passed away peacefully surrounded... http:\/\/t.co\/rmVK8lh9i8",
    "id" : 391274865615200256,
    "created_at" : "2013-10-18 18:49:32 +0000",
    "user" : {
      "name" : "Giant George",
      "screen_name" : "GiantGeorgeAZ",
      "protected" : false,
      "id_str" : "81468711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640762746\/giant_george_-4_normal.jpg",
      "id" : 81468711,
      "verified" : false
    }
  },
  "id" : 391275590772621312,
  "created_at" : "2013-10-18 18:52:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Lee",
      "screen_name" : "DaylightAtheism",
      "indices" : [ 3, 19 ],
      "id_str" : "417549927",
      "id" : 417549927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/2BNk38Ms5U",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/xx_factor\/2013\/10\/18\/el_salvador_abortion_ban_women_are_showing_up_at_public_hospitals_while.html",
      "display_url" : "slate.com\/blogs\/xx_facto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391274884963508224",
  "text" : "RT @DaylightAtheism: http:\/\/t.co\/2BNk38Ms5U In El Salvador, miscarriage is punishable by prison. This is the inevitable result of abortion \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/2BNk38Ms5U",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/xx_factor\/2013\/10\/18\/el_salvador_abortion_ban_women_are_showing_up_at_public_hospitals_while.html",
        "display_url" : "slate.com\/blogs\/xx_facto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391271719060930560",
    "text" : "http:\/\/t.co\/2BNk38Ms5U In El Salvador, miscarriage is punishable by prison. This is the inevitable result of abortion bans.",
    "id" : 391271719060930560,
    "created_at" : "2013-10-18 18:37:01 +0000",
    "user" : {
      "name" : "Adam Lee",
      "screen_name" : "DaylightAtheism",
      "protected" : false,
      "id_str" : "417549927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564623468130349056\/Br3Z9S29_normal.jpeg",
      "id" : 417549927,
      "verified" : false
    }
  },
  "id" : 391274884963508224,
  "created_at" : "2013-10-18 18:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 109, 124 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391266016040206336",
  "text" : "i have to keep reminding myself that none of this truly matters. life is a game and we are the players. (thx @1stCitizenKane for reminder)",
  "id" : 391266016040206336,
  "created_at" : "2013-10-18 18:14:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prisons",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/cJuB5WZNE4",
      "expanded_url" : "http:\/\/bit.ly\/15S0psv",
      "display_url" : "bit.ly\/15S0psv"
    } ]
  },
  "geo" : { },
  "id_str" : "391252898761691136",
  "text" : "RT @drbloem: Private #prisons demand states maintain maximum capacity or pay fees http:\/\/t.co\/cJuB5WZNE4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prisons",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/cJuB5WZNE4",
        "expanded_url" : "http:\/\/bit.ly\/15S0psv",
        "display_url" : "bit.ly\/15S0psv"
      } ]
    },
    "geo" : { },
    "id_str" : "391239865763102720",
    "text" : "Private #prisons demand states maintain maximum capacity or pay fees http:\/\/t.co\/cJuB5WZNE4",
    "id" : 391239865763102720,
    "created_at" : "2013-10-18 16:30:27 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 391252898761691136,
  "created_at" : "2013-10-18 17:22:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/SqYNtGbD5o",
      "expanded_url" : "http:\/\/wp.me\/p1S5E9-317",
      "display_url" : "wp.me\/p1S5E9-317"
    } ]
  },
  "geo" : { },
  "id_str" : "391235233498296320",
  "text" : "RT @CreativeArtwks: \"Bluebirds-in-Flight\" http:\/\/t.co\/SqYNtGbD5o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/SqYNtGbD5o",
        "expanded_url" : "http:\/\/wp.me\/p1S5E9-317",
        "display_url" : "wp.me\/p1S5E9-317"
      } ]
    },
    "geo" : { },
    "id_str" : "391218176639250433",
    "text" : "\"Bluebirds-in-Flight\" http:\/\/t.co\/SqYNtGbD5o",
    "id" : 391218176639250433,
    "created_at" : "2013-10-18 15:04:16 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 391235233498296320,
  "created_at" : "2013-10-18 16:12:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391233141048115200",
  "text" : "RT @vaxen_var: The creditors own the Congress, they own the Executive, they own the Judiciary and they own all the State governments. Get t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391222035868704768",
    "text" : "The creditors own the Congress, they own the Executive, they own the Judiciary and they own all the State governments. Get the picture yet?",
    "id" : 391222035868704768,
    "created_at" : "2013-10-18 15:19:36 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 391233141048115200,
  "created_at" : "2013-10-18 16:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391206593398054913",
  "text" : "RT @davidpakmanshow: House stenographer loses it and gets dragged off of the House floor screaming about God and Freemasons http:\/\/t.co\/687\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/687FdHQMa9",
        "expanded_url" : "http:\/\/ow.ly\/pWFe6",
        "display_url" : "ow.ly\/pWFe6"
      } ]
    },
    "geo" : { },
    "id_str" : "391202197842968576",
    "text" : "House stenographer loses it and gets dragged off of the House floor screaming about God and Freemasons http:\/\/t.co\/687FdHQMa9",
    "id" : 391202197842968576,
    "created_at" : "2013-10-18 14:00:46 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 391206593398054913,
  "created_at" : "2013-10-18 14:18:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391199890908651520",
  "text" : "RT @Buddhaworld: Serious people have not understood the cosmic joke. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391198997064712192",
    "text" : "Serious people have not understood the cosmic joke. Buddha volko",
    "id" : 391198997064712192,
    "created_at" : "2013-10-18 13:48:03 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 391199890908651520,
  "created_at" : "2013-10-18 13:51:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.S. Guthrie",
      "screen_name" : "rsguthrie",
      "indices" : [ 3, 13 ],
      "id_str" : "358119616",
      "id" : 358119616
    }, {
      "name" : "frederick lee brooke",
      "screen_name" : "frederickbrooke",
      "indices" : [ 55, 71 ],
      "id_str" : "316338221",
      "id" : 316338221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/58p8F0AiZ0",
      "expanded_url" : "http:\/\/goo.gl\/Ie8rQV",
      "display_url" : "goo.gl\/Ie8rQV"
    } ]
  },
  "geo" : { },
  "id_str" : "391011049434284032",
  "text" : "RT @rsguthrie: Swan vs. Dog http:\/\/t.co\/58p8F0AiZ0 via @frederickbrooke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "frederick lee brooke",
        "screen_name" : "frederickbrooke",
        "indices" : [ 40, 56 ],
        "id_str" : "316338221",
        "id" : 316338221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/58p8F0AiZ0",
        "expanded_url" : "http:\/\/goo.gl\/Ie8rQV",
        "display_url" : "goo.gl\/Ie8rQV"
      } ]
    },
    "geo" : { },
    "id_str" : "391009434610040832",
    "text" : "Swan vs. Dog http:\/\/t.co\/58p8F0AiZ0 via @frederickbrooke",
    "id" : 391009434610040832,
    "created_at" : "2013-10-18 01:14:48 +0000",
    "user" : {
      "name" : "R.S. Guthrie",
      "screen_name" : "rsguthrie",
      "protected" : false,
      "id_str" : "358119616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2165923410\/Rob-75x2000-Cropped_normal.jpg",
      "id" : 358119616,
      "verified" : false
    }
  },
  "id" : 391011049434284032,
  "created_at" : "2013-10-18 01:21:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391007327425691648",
  "geo" : { },
  "id_str" : "391010504166363136",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses glad to see yr old avatar back : )",
  "id" : 391010504166363136,
  "in_reply_to_status_id" : 391007327425691648,
  "created_at" : "2013-10-18 01:19:03 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390873707595300864",
  "text" : "i saw the cutest baby woolly bear.. he was sooo tiny. went to take a picture and could not find him.",
  "id" : 390873707595300864,
  "created_at" : "2013-10-17 16:15:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "politics",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390852080266526720",
  "text" : "\"we hope to come to an agreement\" blahblahblah .. wasted words. #politics",
  "id" : 390852080266526720,
  "created_at" : "2013-10-17 14:49:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390843780217065472",
  "text" : "@1stCitizenKane damien echols?",
  "id" : 390843780217065472,
  "created_at" : "2013-10-17 14:16:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medicalskeptic",
      "screen_name" : "medskep",
      "indices" : [ 3, 11 ],
      "id_str" : "133545597",
      "id" : 133545597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/iwZi63h3cv",
      "expanded_url" : "http:\/\/ti.me\/1bWlYww",
      "display_url" : "ti.me\/1bWlYww"
    } ]
  },
  "geo" : { },
  "id_str" : "390826635832066048",
  "text" : "RT @medskep: Attack of the Pharma Babes - TIME http:\/\/t.co\/iwZi63h3cv 2007  Once knew one of these ladies, she oozed with charm.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/iwZi63h3cv",
        "expanded_url" : "http:\/\/ti.me\/1bWlYww",
        "display_url" : "ti.me\/1bWlYww"
      } ]
    },
    "geo" : { },
    "id_str" : "390673743694925824",
    "text" : "Attack of the Pharma Babes - TIME http:\/\/t.co\/iwZi63h3cv 2007  Once knew one of these ladies, she oozed with charm.",
    "id" : 390673743694925824,
    "created_at" : "2013-10-17 03:00:53 +0000",
    "user" : {
      "name" : "Medicalskeptic",
      "screen_name" : "medskep",
      "protected" : false,
      "id_str" : "133545597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1394688432\/IMAG0474-1_normal.jpg",
      "id" : 133545597,
      "verified" : false
    }
  },
  "id" : 390826635832066048,
  "created_at" : "2013-10-17 13:08:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoteden",
      "screen_name" : "Coyoteguy",
      "indices" : [ 0, 10 ],
      "id_str" : "14715669",
      "id" : 14715669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390817052597837824",
  "geo" : { },
  "id_str" : "390825131909459968",
  "in_reply_to_user_id" : 14715669,
  "text" : "@Coyoteguy ((snuggles))",
  "id" : 390825131909459968,
  "in_reply_to_status_id" : 390817052597837824,
  "created_at" : "2013-10-17 13:02:27 +0000",
  "in_reply_to_screen_name" : "Coyoteguy",
  "in_reply_to_user_id_str" : "14715669",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390823554499219456",
  "text" : "RT @CoryBooker: Have great dreams &amp; bold ambition but never forget that the biggest thing you can do in any day is a small act of kindness,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390790657226182656",
    "text" : "Have great dreams &amp; bold ambition but never forget that the biggest thing you can do in any day is a small act of kindness, decency or love.",
    "id" : 390790657226182656,
    "created_at" : "2013-10-17 10:45:27 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 390823554499219456,
  "created_at" : "2013-10-17 12:56:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 3, 13 ],
      "id_str" : "25103",
      "id" : 25103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390600310215151616",
  "text" : "RT @jessitron: If you don't understand why a girl would hush while a man put his hand down her pants unwanted, please read this.\nhttp:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/9wQD0zbbU8",
        "expanded_url" : "http:\/\/www.utne.com\/community\/betrayed-by-the-angel.aspx",
        "display_url" : "utne.com\/community\/betr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390501818536448000",
    "text" : "If you don't understand why a girl would hush while a man put his hand down her pants unwanted, please read this.\nhttp:\/\/t.co\/9wQD0zbbU8",
    "id" : 390501818536448000,
    "created_at" : "2013-10-16 15:37:43 +0000",
    "user" : {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "protected" : false,
      "id_str" : "25103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728251919467057152\/Z2uk49Ww_normal.jpg",
      "id" : 25103,
      "verified" : false
    }
  },
  "id" : 390600310215151616,
  "created_at" : "2013-10-16 22:09:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390583699466899456",
  "geo" : { },
  "id_str" : "390600258872291328",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms perhaps could have been me.. not wanting to cause trouble or draw attention to myself. i just want to hug her.",
  "id" : 390600258872291328,
  "in_reply_to_status_id" : 390583699466899456,
  "created_at" : "2013-10-16 22:08:53 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 0, 15 ],
      "id_str" : "17376893",
      "id" : 17376893
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 16, 28 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390515349130444800",
  "geo" : { },
  "id_str" : "390543136558034944",
  "in_reply_to_user_id" : 17376893,
  "text" : "@RightWingWatch @VirgoJohnny run for the hills.. it's the pagans! they might hug your trees!",
  "id" : 390543136558034944,
  "in_reply_to_status_id" : 390515349130444800,
  "created_at" : "2013-10-16 18:21:54 +0000",
  "in_reply_to_screen_name" : "RightWingWatch",
  "in_reply_to_user_id_str" : "17376893",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/XUGPxujZJX",
      "expanded_url" : "http:\/\/21stcenturywire.com\/2013\/10\/07\/theatre-forget-the-government-shutdown-its-about-shutting-you-down\/",
      "display_url" : "21stcenturywire.com\/2013\/10\/07\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390523573846413313",
  "text" : "RT @vaxen_var: THEATRE: Forget the government shutdown \u2013 it\u2019s about shutting YOU down http:\/\/t.co\/XUGPxujZJX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/XUGPxujZJX",
        "expanded_url" : "http:\/\/21stcenturywire.com\/2013\/10\/07\/theatre-forget-the-government-shutdown-its-about-shutting-you-down\/",
        "display_url" : "21stcenturywire.com\/2013\/10\/07\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390370177314865152",
    "text" : "THEATRE: Forget the government shutdown \u2013 it\u2019s about shutting YOU down http:\/\/t.co\/XUGPxujZJX",
    "id" : 390370177314865152,
    "created_at" : "2013-10-16 06:54:37 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 390523573846413313,
  "created_at" : "2013-10-16 17:04:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/JCwpqCTs6r",
      "expanded_url" : "http:\/\/keystoliberty2.wordpress.com\/tag\/independent-treasury-act-of-1921\/",
      "display_url" : "keystoliberty2.wordpress.com\/tag\/independen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390523256236957696",
  "text" : "RT @vaxen_var: Independent Treasury Act of 1921? http:\/\/t.co\/JCwpqCTs6r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/JCwpqCTs6r",
        "expanded_url" : "http:\/\/keystoliberty2.wordpress.com\/tag\/independent-treasury-act-of-1921\/",
        "display_url" : "keystoliberty2.wordpress.com\/tag\/independen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390517630953463808",
    "text" : "Independent Treasury Act of 1921? http:\/\/t.co\/JCwpqCTs6r",
    "id" : 390517630953463808,
    "created_at" : "2013-10-16 16:40:33 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 390523256236957696,
  "created_at" : "2013-10-16 17:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/390476954308050944\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/OgU4X523E8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWtAuJrCAAEaTLw.jpg",
      "id_str" : "390476954312245249",
      "id" : 390476954312245249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWtAuJrCAAEaTLw.jpg",
      "sizes" : [ {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 585,
        "resize" : "fit",
        "w" : 717
      }, {
        "h" : 585,
        "resize" : "fit",
        "w" : 717
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OgU4X523E8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/2b3Al4vMSC",
      "expanded_url" : "http:\/\/www.takepart.com\/article\/2013\/10\/12\/womens-rights-fat-shaming-week?cmpid=organic-share-twitter",
      "display_url" : "takepart.com\/article\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390478879858913280",
  "text" : "RT @atheistlady76: These next two pics were found here and I screen capped. http:\/\/t.co\/2b3Al4vMSC http:\/\/t.co\/OgU4X523E8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/390476954308050944\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/OgU4X523E8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWtAuJrCAAEaTLw.jpg",
        "id_str" : "390476954312245249",
        "id" : 390476954312245249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWtAuJrCAAEaTLw.jpg",
        "sizes" : [ {
          "h" : 277,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 585,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OgU4X523E8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/2b3Al4vMSC",
        "expanded_url" : "http:\/\/www.takepart.com\/article\/2013\/10\/12\/womens-rights-fat-shaming-week?cmpid=organic-share-twitter",
        "display_url" : "takepart.com\/article\/2013\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390476954308050944",
    "text" : "These next two pics were found here and I screen capped. http:\/\/t.co\/2b3Al4vMSC http:\/\/t.co\/OgU4X523E8",
    "id" : 390476954308050944,
    "created_at" : "2013-10-16 13:58:55 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 390478879858913280,
  "created_at" : "2013-10-16 14:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390258375260647425",
  "geo" : { },
  "id_str" : "390264847742410752",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny thought my TL was missing a little something ; )",
  "id" : 390264847742410752,
  "in_reply_to_status_id" : 390258375260647425,
  "created_at" : "2013-10-15 23:56:05 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/MTqphMrmVV",
      "expanded_url" : "http:\/\/bit.ly\/1giMjXt",
      "display_url" : "bit.ly\/1giMjXt"
    } ]
  },
  "geo" : { },
  "id_str" : "390263867420712960",
  "text" : "RT @Floridaline: Ted Nugent Just Might Run For President - http:\/\/t.co\/MTqphMrmVV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/MTqphMrmVV",
        "expanded_url" : "http:\/\/bit.ly\/1giMjXt",
        "display_url" : "bit.ly\/1giMjXt"
      } ]
    },
    "geo" : { },
    "id_str" : "390259382090760192",
    "text" : "Ted Nugent Just Might Run For President - http:\/\/t.co\/MTqphMrmVV",
    "id" : 390259382090760192,
    "created_at" : "2013-10-15 23:34:22 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 390263867420712960,
  "created_at" : "2013-10-15 23:52:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390242196659920896",
  "geo" : { },
  "id_str" : "390260993164455937",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i love reeses cups. at my previous job, they had reeses cup sundae.. omg, sooo good..lol",
  "id" : 390260993164455937,
  "in_reply_to_status_id" : 390242196659920896,
  "created_at" : "2013-10-15 23:40:46 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "indices" : [ 3, 14 ],
      "id_str" : "417189310",
      "id" : 417189310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Autumn",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390257595099152384",
  "text" : "RT @DianeJReed: Today 15 wild turkeys hovered nearby on my jog, chortling softly. Their totems indicate #Autumn harvest &amp; blessing... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DianeJReed\/status\/390250136741232640\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/GhGGdySeCC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWpyboZCQAEqtW2.jpg",
        "id_str" : "390250136745426945",
        "id" : 390250136745426945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWpyboZCQAEqtW2.jpg",
        "sizes" : [ {
          "h" : 395,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GhGGdySeCC"
      } ],
      "hashtags" : [ {
        "text" : "Autumn",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390250136741232640",
    "text" : "Today 15 wild turkeys hovered nearby on my jog, chortling softly. Their totems indicate #Autumn harvest &amp; blessing... http:\/\/t.co\/GhGGdySeCC",
    "id" : 390250136741232640,
    "created_at" : "2013-10-15 22:57:37 +0000",
    "user" : {
      "name" : "Diane J. Reed",
      "screen_name" : "DianeJReed",
      "protected" : false,
      "id_str" : "417189310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695055759181160448\/du6nVVbQ_normal.jpg",
      "id" : 417189310,
      "verified" : false
    }
  },
  "id" : 390257595099152384,
  "created_at" : "2013-10-15 23:27:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moonlit",
      "screen_name" : "wheeliesmom",
      "indices" : [ 3, 15 ],
      "id_str" : "55949344",
      "id" : 55949344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390233665491714048",
  "text" : "RT @wheeliesmom: The woman who was murdered by DC cops &amp; the man who set himself on fire are just a heartbeat away from being any one of us\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386524844961325056",
    "text" : "The woman who was murdered by DC cops &amp; the man who set himself on fire are just a heartbeat away from being any one of us in crisis.",
    "id" : 386524844961325056,
    "created_at" : "2013-10-05 16:14:38 +0000",
    "user" : {
      "name" : "moonlit",
      "screen_name" : "wheeliesmom",
      "protected" : false,
      "id_str" : "55949344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1896488849\/mongoose_normal.jpg",
      "id" : 55949344,
      "verified" : false
    }
  },
  "id" : 390233665491714048,
  "created_at" : "2013-10-15 21:52:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moonlit",
      "screen_name" : "wheeliesmom",
      "indices" : [ 3, 15 ],
      "id_str" : "55949344",
      "id" : 55949344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390233643454853120",
  "text" : "RT @wheeliesmom: Foreclosure, abuse, legal injustice, injury, fraud, loss, exhaustion are just some of what sets us into a mental illness t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386525429341114368",
    "text" : "Foreclosure, abuse, legal injustice, injury, fraud, loss, exhaustion are just some of what sets us into a mental illness tailspin.",
    "id" : 386525429341114368,
    "created_at" : "2013-10-05 16:16:58 +0000",
    "user" : {
      "name" : "moonlit",
      "screen_name" : "wheeliesmom",
      "protected" : false,
      "id_str" : "55949344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1896488849\/mongoose_normal.jpg",
      "id" : 55949344,
      "verified" : false
    }
  },
  "id" : 390233643454853120,
  "created_at" : "2013-10-15 21:52:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390217532067438592",
  "text" : "@weakSquare LOL.. i still have the one i got for my 13th birthday. rogets pocket thesaurus.",
  "id" : 390217532067438592,
  "created_at" : "2013-10-15 20:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390213715582521344",
  "geo" : { },
  "id_str" : "390214616568958976",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses oh my : ((",
  "id" : 390214616568958976,
  "in_reply_to_status_id" : 390213715582521344,
  "created_at" : "2013-10-15 20:36:29 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390197241883160577",
  "geo" : { },
  "id_str" : "390198236008308736",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone dh likes it so i watch by default as im in the room..lol",
  "id" : 390198236008308736,
  "in_reply_to_status_id" : 390197241883160577,
  "created_at" : "2013-10-15 19:31:23 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390196205545721858",
  "text" : "and Values Voters.. umm.. separation of church and state!!",
  "id" : 390196205545721858,
  "created_at" : "2013-10-15 19:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390194206842429440",
  "text" : "annoyed w \"Bones\" tv show. lady gave hubby holistic herbs. he was found w arsenic in system. obv jab at holistic healing. sigh...",
  "id" : 390194206842429440,
  "created_at" : "2013-10-15 19:15:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390193550173798401",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny poor DH.. they've been playing reruns of values voters on cspan. he cant stand it.. he starts ranting and swearing at tv..lol",
  "id" : 390193550173798401,
  "created_at" : "2013-10-15 19:12:46 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390182726092857344",
  "text" : "OMG.. just got back online. lost internet sunday afternoon.",
  "id" : 390182726092857344,
  "created_at" : "2013-10-15 18:29:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 0, 13 ],
      "id_str" : "926185416",
      "id" : 926185416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/qbxPo0100G",
      "expanded_url" : "http:\/\/politicalcompass.org\/printablegraph?ec=-4.12&soc=-7.59",
      "display_url" : "politicalcompass.org\/printablegraph\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389768932334133249",
  "geo" : { },
  "id_str" : "389783218246807552",
  "in_reply_to_user_id" : 926185416,
  "text" : "@hoosierworld lol.. perhaps not \"fully\" anarchist. liberal, yup. so left i fell off the edge..lol.. then again &gt;&gt; http:\/\/t.co\/qbxPo0100G",
  "id" : 389783218246807552,
  "in_reply_to_status_id" : 389768932334133249,
  "created_at" : "2013-10-14 16:02:15 +0000",
  "in_reply_to_screen_name" : "hoosierworld",
  "in_reply_to_user_id_str" : "926185416",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389781144272920576",
  "text" : "RT @TheDailyHug: Whatever you say in your mind, you are screaming to the world.\nBe kind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389781016220811265",
    "text" : "Whatever you say in your mind, you are screaming to the world.\nBe kind.",
    "id" : 389781016220811265,
    "created_at" : "2013-10-14 15:53:30 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 389781144272920576,
  "created_at" : "2013-10-14 15:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VVS13",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389776589879119872",
  "text" : "direct mail is evil? &gt;&gt; sandy rios at #VVS13 \"those of us in conservative circles know what direct mail is\"",
  "id" : 389776589879119872,
  "created_at" : "2013-10-14 15:35:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389748408602198017",
  "text" : "im a day behind. keep thinking its sunday.",
  "id" : 389748408602198017,
  "created_at" : "2013-10-14 13:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/MVHYX1QXSB",
      "expanded_url" : "http:\/\/amzn.to\/VBBe74",
      "display_url" : "amzn.to\/VBBe74"
    } ]
  },
  "geo" : { },
  "id_str" : "389575246929756160",
  "text" : "finished Proof of Death by Chris Pearson http:\/\/t.co\/MVHYX1QXSB",
  "id" : 389575246929756160,
  "created_at" : "2013-10-14 02:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "MinsMessage",
      "indices" : [ 3, 15 ],
      "id_str" : "415567842",
      "id" : 415567842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "judging",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389544231083470848",
  "text" : "RT @MinsMessage: Our greatest challenge is to stop #judging one another and ourselves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "judging",
        "indices" : [ 34, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389543958826610688",
    "text" : "Our greatest challenge is to stop #judging one another and ourselves.",
    "id" : 389543958826610688,
    "created_at" : "2013-10-14 00:11:31 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "MinsMessage",
      "protected" : false,
      "id_str" : "415567842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645231252\/buddha_light_normal.jpg",
      "id" : 415567842,
      "verified" : false
    }
  },
  "id" : 389544231083470848,
  "created_at" : "2013-10-14 00:12:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389529347595317249",
  "geo" : { },
  "id_str" : "389543419204235264",
  "in_reply_to_user_id" : 99910224,
  "text" : "@PaganGmaSayin hello, toad! : )",
  "id" : 389543419204235264,
  "in_reply_to_status_id" : 389529347595317249,
  "created_at" : "2013-10-14 00:09:23 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 3, 13 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389542768655470592",
  "text" : "RT @CubeMelon: please don't treat a human being with less respect than you would ask for yourself",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389530473069674496",
    "text" : "please don't treat a human being with less respect than you would ask for yourself",
    "id" : 389530473069674496,
    "created_at" : "2013-10-13 23:17:56 +0000",
    "user" : {
      "name" : "\uD83E\uDD87 Q-LUM",
      "screen_name" : "ElectrumCube",
      "protected" : false,
      "id_str" : "16639123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793483483117125632\/XMooPFDV_normal.jpg",
      "id" : 16639123,
      "verified" : false
    }
  },
  "id" : 389542768655470592,
  "created_at" : "2013-10-14 00:06:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389499048232615936",
  "text" : "@1stCitizenKane mystics are chimpanzees?",
  "id" : 389499048232615936,
  "created_at" : "2013-10-13 21:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389497734010392576",
  "text" : "@1stCitizenKane and you have all the answers?",
  "id" : 389497734010392576,
  "created_at" : "2013-10-13 21:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bert van Lamoen",
      "screen_name" : "transarchitect",
      "indices" : [ 3, 18 ],
      "id_str" : "308024976",
      "id" : 308024976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389495700763181056",
  "text" : "RT @transarchitect: Have compassion for where other people are in their lives.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389389085288050688",
    "text" : "Have compassion for where other people are in their lives.",
    "id" : 389389085288050688,
    "created_at" : "2013-10-13 13:56:07 +0000",
    "user" : {
      "name" : "Bert van Lamoen",
      "screen_name" : "transarchitect",
      "protected" : false,
      "id_str" : "308024976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1390184973\/image_normal.jpg",
      "id" : 308024976,
      "verified" : false
    }
  },
  "id" : 389495700763181056,
  "created_at" : "2013-10-13 20:59:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 0, 16 ],
      "id_str" : "140060120",
      "id" : 140060120
    }, {
      "name" : "N. John Shore, Jr.",
      "screen_name" : "johnshore",
      "indices" : [ 30, 40 ],
      "id_str" : "74710075",
      "id" : 74710075
    }, {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 41, 54 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389491942654218240",
  "geo" : { },
  "id_str" : "389495122376671232",
  "in_reply_to_user_id" : 140060120,
  "text" : "@davidpakmanshow &gt;&gt;&gt; @johnshore @micahjmurray",
  "id" : 389495122376671232,
  "in_reply_to_status_id" : 389491942654218240,
  "created_at" : "2013-10-13 20:57:28 +0000",
  "in_reply_to_screen_name" : "davidpakmanshow",
  "in_reply_to_user_id_str" : "140060120",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389494234774265856",
  "text" : "RT @davidpakmanshow: Looking for a recommendation for a progressive Christian voice to appear on our show alongside an extremist Christian \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389491942654218240",
    "text" : "Looking for a recommendation for a progressive Christian voice to appear on our show alongside an extremist Christian voice. Suggestions?",
    "id" : 389491942654218240,
    "created_at" : "2013-10-13 20:44:50 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 389494234774265856,
  "created_at" : "2013-10-13 20:53:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "indices" : [ 3, 18 ],
      "id_str" : "1898566165",
      "id" : 1898566165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/X4nWkK16hT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SEFL8ElXHaU",
      "display_url" : "youtube.com\/watch?v=SEFL8E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389482361609789440",
  "text" : "RT @brownfemipower: Former Nestle CEO saying water is not a human right: http:\/\/t.co\/X4nWkK16hT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/X4nWkK16hT",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SEFL8ElXHaU",
        "display_url" : "youtube.com\/watch?v=SEFL8E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389437641130651649",
    "text" : "Former Nestle CEO saying water is not a human right: http:\/\/t.co\/X4nWkK16hT",
    "id" : 389437641130651649,
    "created_at" : "2013-10-13 17:09:03 +0000",
    "user" : {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "protected" : true,
      "id_str" : "1898566165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000499474902\/5472f3903a09460f9db4bcab1f36970b_normal.jpeg",
      "id" : 1898566165,
      "verified" : false
    }
  },
  "id" : 389482361609789440,
  "created_at" : "2013-10-13 20:06:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "indices" : [ 3, 18 ],
      "id_str" : "1898566165",
      "id" : 1898566165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389481290086752256",
  "text" : "RT @brownfemipower: The criminality is in a system that makes it so people who cook\/make\/grow food for others can't afford to buy their own.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389424788218728449",
    "text" : "The criminality is in a system that makes it so people who cook\/make\/grow food for others can't afford to buy their own.",
    "id" : 389424788218728449,
    "created_at" : "2013-10-13 16:17:59 +0000",
    "user" : {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "protected" : true,
      "id_str" : "1898566165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000499474902\/5472f3903a09460f9db4bcab1f36970b_normal.jpeg",
      "id" : 1898566165,
      "verified" : false
    }
  },
  "id" : 389481290086752256,
  "created_at" : "2013-10-13 20:02:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "indices" : [ 3, 18 ],
      "id_str" : "1898566165",
      "id" : 1898566165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389481260546277376",
  "text" : "RT @brownfemipower: i care about why folks rnt being paid enough to live\/feed families with.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389428622575955968",
    "text" : "i care about why folks rnt being paid enough to live\/feed families with.",
    "id" : 389428622575955968,
    "created_at" : "2013-10-13 16:33:13 +0000",
    "user" : {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "protected" : true,
      "id_str" : "1898566165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000499474902\/5472f3903a09460f9db4bcab1f36970b_normal.jpeg",
      "id" : 1898566165,
      "verified" : false
    }
  },
  "id" : 389481260546277376,
  "created_at" : "2013-10-13 20:02:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "indices" : [ 3, 18 ],
      "id_str" : "1898566165",
      "id" : 1898566165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389481228464029696",
  "text" : "RT @brownfemipower: and i will tell you right now. I don't give a fuck, not one single solitary fuck, if welfare recipient is \"bilking\" i r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389428448772378624",
    "text" : "and i will tell you right now. I don't give a fuck, not one single solitary fuck, if welfare recipient is \"bilking\" i really and truly dont.",
    "id" : 389428448772378624,
    "created_at" : "2013-10-13 16:32:32 +0000",
    "user" : {
      "name" : "brownfemipower",
      "screen_name" : "brownfemipower",
      "protected" : true,
      "id_str" : "1898566165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000499474902\/5472f3903a09460f9db4bcab1f36970b_normal.jpeg",
      "id" : 1898566165,
      "verified" : false
    }
  },
  "id" : 389481228464029696,
  "created_at" : "2013-10-13 20:02:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389416332791259137",
  "geo" : { },
  "id_str" : "389419544189472768",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist im flabbergasted. the govt shutdown was really planned ahead of time...",
  "id" : 389419544189472768,
  "in_reply_to_status_id" : 389416332791259137,
  "created_at" : "2013-10-13 15:57:09 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 3, 16 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/W76X9vSZNr",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0Jd-iaYLO1A&sns=em",
      "display_url" : "youtube.com\/watch?v=0Jd-ia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389418295818203136",
  "text" : "RT @SisterSadist: http:\/\/t.co\/W76X9vSZNr As if Oct 1, 2013 only the speaker of the house can introduce a resolution to re-open the govt. Fu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 124, 139 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/W76X9vSZNr",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0Jd-iaYLO1A&sns=em",
        "display_url" : "youtube.com\/watch?v=0Jd-ia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389416332791259137",
    "text" : "http:\/\/t.co\/W76X9vSZNr As if Oct 1, 2013 only the speaker of the house can introduce a resolution to re-open the govt. Fuck @SpeakerBoehner",
    "id" : 389416332791259137,
    "created_at" : "2013-10-13 15:44:23 +0000",
    "user" : {
      "name" : "Cam",
      "screen_name" : "WrathOfCam",
      "protected" : false,
      "id_str" : "20987411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769322135336652801\/9R_a4UjJ_normal.jpg",
      "id" : 20987411,
      "verified" : false
    }
  },
  "id" : 389418295818203136,
  "created_at" : "2013-10-13 15:52:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389414071474200576",
  "geo" : { },
  "id_str" : "389415820276686848",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 aww, i love &gt;&gt;headbonks&lt;&lt; : ) *smooches*",
  "id" : 389415820276686848,
  "in_reply_to_status_id" : 389414071474200576,
  "created_at" : "2013-10-13 15:42:21 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amadi",
      "screen_name" : "amaditalks",
      "indices" : [ 3, 14 ],
      "id_str" : "23004495",
      "id" : 23004495
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EBT",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389398661345869824",
  "text" : "RT @amaditalks: Complaining about SNAP benefits putting $367 a month on an #EBT card? Verizon gets $3.28 million in tax dollars DAILY. Try \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EBT",
        "indices" : [ 59, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389174830844870656",
    "text" : "Complaining about SNAP benefits putting $367 a month on an #EBT card? Verizon gets $3.28 million in tax dollars DAILY. Try punching upwards.",
    "id" : 389174830844870656,
    "created_at" : "2013-10-12 23:44:44 +0000",
    "user" : {
      "name" : "Amadi",
      "screen_name" : "amaditalks",
      "protected" : false,
      "id_str" : "23004495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745860074833338369\/NUMSudMg_normal.jpg",
      "id" : 23004495,
      "verified" : false
    }
  },
  "id" : 389398661345869824,
  "created_at" : "2013-10-13 14:34:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Macrae",
      "screen_name" : "acidic",
      "indices" : [ 3, 10 ],
      "id_str" : "7704042",
      "id" : 7704042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/KDGuImmp0R",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=r0jArGJnP3U&desktop_uri=%2Fwatch%3Fv%3Dr0jArGJnP3U",
      "display_url" : "m.youtube.com\/watch?v=r0jArG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389206686457942016",
  "text" : "RT @acidic: Slug sex: amazing and so beautiful. I had no idea. http:\/\/t.co\/KDGuImmp0R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/KDGuImmp0R",
        "expanded_url" : "http:\/\/m.youtube.com\/watch?v=r0jArGJnP3U&desktop_uri=%2Fwatch%3Fv%3Dr0jArGJnP3U",
        "display_url" : "m.youtube.com\/watch?v=r0jArG\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389204677486596096",
    "text" : "Slug sex: amazing and so beautiful. I had no idea. http:\/\/t.co\/KDGuImmp0R",
    "id" : 389204677486596096,
    "created_at" : "2013-10-13 01:43:20 +0000",
    "user" : {
      "name" : "Andrew Macrae",
      "screen_name" : "acidic",
      "protected" : false,
      "id_str" : "7704042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615737099862413312\/ell1WBrJ_normal.jpg",
      "id" : 7704042,
      "verified" : false
    }
  },
  "id" : 389206686457942016,
  "created_at" : "2013-10-13 01:51:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 0, 10 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389198530608263168",
  "text" : "@ID_vs_EGO LOLOL",
  "id" : 389198530608263168,
  "created_at" : "2013-10-13 01:18:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389194831391883264",
  "text" : "RT @AllOnMedicare: Why don't private health insurers cover teeth or eyes? Are they not part of one's body? Necessary parts? #SinglePayer #M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 105, 117 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 118, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389193166592565248",
    "text" : "Why don't private health insurers cover teeth or eyes? Are they not part of one's body? Necessary parts? #SinglePayer #MedicareForAll",
    "id" : 389193166592565248,
    "created_at" : "2013-10-13 00:57:36 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 389194831391883264,
  "created_at" : "2013-10-13 01:04:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389177668895535104",
  "geo" : { },
  "id_str" : "389178581026234370",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms love the colors! : )",
  "id" : 389178581026234370,
  "in_reply_to_status_id" : 389177668895535104,
  "created_at" : "2013-10-12 23:59:38 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389175785191272451",
  "geo" : { },
  "id_str" : "389177115435749376",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon your mom is awesome : ) DD is getting new pokemon game tomorrow.",
  "id" : 389177115435749376,
  "in_reply_to_status_id" : 389175785191272451,
  "created_at" : "2013-10-12 23:53:49 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 31, 45 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389168235565690880",
  "geo" : { },
  "id_str" : "389171478442151936",
  "in_reply_to_user_id" : 102651839,
  "text" : "always choose love not fear RT @ificouldtellu Your choices matter. God is Infinite Possibilities",
  "id" : 389171478442151936,
  "in_reply_to_status_id" : 389168235565690880,
  "created_at" : "2013-10-12 23:31:25 +0000",
  "in_reply_to_screen_name" : "ificouldtellu",
  "in_reply_to_user_id_str" : "102651839",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 0, 14 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389170016525905920",
  "geo" : { },
  "id_str" : "389171046982488064",
  "in_reply_to_user_id" : 102651839,
  "text" : "@ificouldtellu oops.. i forgot to add the RT before your name (i hit reply then copy\/paste)",
  "id" : 389171046982488064,
  "in_reply_to_status_id" : 389170016525905920,
  "created_at" : "2013-10-12 23:29:42 +0000",
  "in_reply_to_screen_name" : "ificouldtellu",
  "in_reply_to_user_id_str" : "102651839",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389169058874007553",
  "geo" : { },
  "id_str" : "389170467870744576",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i am similar in that i dont like romance thrown in to a movie if its not a romance movie to begin with..lol",
  "id" : 389170467870744576,
  "in_reply_to_status_id" : 389169058874007553,
  "created_at" : "2013-10-12 23:27:24 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389164375627415552",
  "text" : "watched some Love It or List It then a bunch of Modern Family.",
  "id" : 389164375627415552,
  "created_at" : "2013-10-12 23:03:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389159943594852352",
  "text" : "RT @BrianRathbone: Twitter is many things to many people. For me, Twitter is a place to connect with people who share my interests. #pricel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "priceless",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389159548151672832",
    "text" : "Twitter is many things to many people. For me, Twitter is a place to connect with people who share my interests. #priceless",
    "id" : 389159548151672832,
    "created_at" : "2013-10-12 22:44:01 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 389159943594852352,
  "created_at" : "2013-10-12 22:45:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389154569835401218",
  "geo" : { },
  "id_str" : "389155291217940480",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings yup.. it happens.",
  "id" : 389155291217940480,
  "in_reply_to_status_id" : 389154569835401218,
  "created_at" : "2013-10-12 22:27:06 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 46, 58 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389154339782422528",
  "text" : "RT @AllOnMedicare: Our number one priority as #SinglePayer #MedicareForAll activists should be supporting the creation of a SinglePayer pla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 27, 39 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 40, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389153174285586433",
    "text" : "Our number one priority as #SinglePayer #MedicareForAll activists should be supporting the creation of a SinglePayer plan in California.",
    "id" : 389153174285586433,
    "created_at" : "2013-10-12 22:18:41 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 389154339782422528,
  "created_at" : "2013-10-12 22:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389152360205123584",
  "text" : "RT @AllOnMedicare: Private insurers can't survive without employer-based business in NY and Cali. If single BIG state goes #SinglePayer, re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389149539203948544",
    "text" : "Private insurers can't survive without employer-based business in NY and Cali. If single BIG state goes #SinglePayer, rest of USA follows!",
    "id" : 389149539203948544,
    "created_at" : "2013-10-12 22:04:14 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 389152360205123584,
  "created_at" : "2013-10-12 22:15:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389149539203948544",
  "geo" : { },
  "id_str" : "389151249389477888",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare wow.. really? cuz that would be awesomesauce!!!",
  "id" : 389151249389477888,
  "in_reply_to_status_id" : 389149539203948544,
  "created_at" : "2013-10-12 22:11:02 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389145363065479168",
  "text" : "at least im not watching LMN... sigh...",
  "id" : 389145363065479168,
  "created_at" : "2013-10-12 21:47:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389081956513619968",
  "geo" : { },
  "id_str" : "389089470693117952",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms aww..sweet. mine is 18. out w her daddy at nycomicon today, both dressed in costume..lol.",
  "id" : 389089470693117952,
  "in_reply_to_status_id" : 389081956513619968,
  "created_at" : "2013-10-12 18:05:33 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "karma",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/qkYYYRT6z9",
      "expanded_url" : "http:\/\/tinyurl.com\/6tega8r",
      "display_url" : "tinyurl.com\/6tega8r"
    } ]
  },
  "geo" : { },
  "id_str" : "389056460229189632",
  "text" : "RT @Soulseedzforall: Do a daily #karma cleanse. ALL the things you want in your life, give to others. http:\/\/t.co\/qkYYYRT6z9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "karma",
        "indices" : [ 11, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/qkYYYRT6z9",
        "expanded_url" : "http:\/\/tinyurl.com\/6tega8r",
        "display_url" : "tinyurl.com\/6tega8r"
      } ]
    },
    "geo" : { },
    "id_str" : "389055681258459136",
    "text" : "Do a daily #karma cleanse. ALL the things you want in your life, give to others. http:\/\/t.co\/qkYYYRT6z9",
    "id" : 389055681258459136,
    "created_at" : "2013-10-12 15:51:17 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 389056460229189632,
  "created_at" : "2013-10-12 15:54:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mackenzian",
      "screen_name" : "mackenzian",
      "indices" : [ 3, 14 ],
      "id_str" : "212325799",
      "id" : 212325799
    }, {
      "name" : "David McQueen \u2655",
      "screen_name" : "DavidMcQueen",
      "indices" : [ 19, 32 ],
      "id_str" : "11902142",
      "id" : 11902142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389054867391909888",
  "text" : "RT @mackenzian: MT @DavidMcQueen: Part of navigating my own spirituality is being able to still respect that people believe certain things \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David McQueen \u2655",
        "screen_name" : "DavidMcQueen",
        "indices" : [ 3, 16 ],
        "id_str" : "11902142",
        "id" : 11902142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389039534081441792",
    "text" : "MT @DavidMcQueen: Part of navigating my own spirituality is being able to still respect that people believe certain things I don't anymore.",
    "id" : 389039534081441792,
    "created_at" : "2013-10-12 14:47:07 +0000",
    "user" : {
      "name" : "mackenzian",
      "screen_name" : "mackenzian",
      "protected" : false,
      "id_str" : "212325799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762703771222802432\/2rM1cF41_normal.jpg",
      "id" : 212325799,
      "verified" : false
    }
  },
  "id" : 389054867391909888,
  "created_at" : "2013-10-12 15:48:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389051837778624512",
  "geo" : { },
  "id_str" : "389053101988016129",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer truth..lol @FeyFrau",
  "id" : 389053101988016129,
  "in_reply_to_status_id" : 389051837778624512,
  "created_at" : "2013-10-12 15:41:02 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389052011238285312",
  "geo" : { },
  "id_str" : "389052923985944576",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste nice!",
  "id" : 389052923985944576,
  "in_reply_to_status_id" : 389052011238285312,
  "created_at" : "2013-10-12 15:40:19 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    }, {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 16, 28 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389048436437565440",
  "text" : "RT @MWM4444: To @NancyPelosi: At 10P on 9\/30, Cantor changed the rules. ONLY Cantor is allowed to file any discharge petition!! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nancy Pelosi",
        "screen_name" : "NancyPelosi",
        "indices" : [ 3, 15 ],
        "id_str" : "15764644",
        "id" : 15764644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ziVCCjhTF9",
        "expanded_url" : "http:\/\/talkingpointsmemo.com\/dc\/the-house-gop-s-little-rule-change-that-guaranteed-a-shutdown",
        "display_url" : "talkingpointsmemo.com\/dc\/the-house-g\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "389029822837444609",
    "geo" : { },
    "id_str" : "389047255279206400",
    "in_reply_to_user_id" : 15764644,
    "text" : "To @NancyPelosi: At 10P on 9\/30, Cantor changed the rules. ONLY Cantor is allowed to file any discharge petition!! http:\/\/t.co\/ziVCCjhTF9",
    "id" : 389047255279206400,
    "in_reply_to_status_id" : 389029822837444609,
    "created_at" : "2013-10-12 15:17:48 +0000",
    "in_reply_to_screen_name" : "NancyPelosi",
    "in_reply_to_user_id_str" : "15764644",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 389048436437565440,
  "created_at" : "2013-10-12 15:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389033562298515456",
  "geo" : { },
  "id_str" : "389036592607682561",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 amen!",
  "id" : 389036592607682561,
  "in_reply_to_status_id" : 389033562298515456,
  "created_at" : "2013-10-12 14:35:26 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389033862371627008",
  "geo" : { },
  "id_str" : "389036429063364608",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos omg.. if dd saw this, she'd want one..lol",
  "id" : 389036429063364608,
  "in_reply_to_status_id" : 389033862371627008,
  "created_at" : "2013-10-12 14:34:47 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#Bernie2020",
      "screen_name" : "Datoism",
      "indices" : [ 3, 11 ],
      "id_str" : "115381807",
      "id" : 115381807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389035989538463744",
  "text" : "RT @Datoism: Twitter is one big giant school, &amp; all we're doing is passing folded notes to each other in the classroom &amp; hallways.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389028355321786368",
    "text" : "Twitter is one big giant school, &amp; all we're doing is passing folded notes to each other in the classroom &amp; hallways.",
    "id" : 389028355321786368,
    "created_at" : "2013-10-12 14:02:42 +0000",
    "user" : {
      "name" : "#Bernie2020",
      "screen_name" : "Datoism",
      "protected" : false,
      "id_str" : "115381807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707252458511175680\/foNAdPEy_normal.jpg",
      "id" : 115381807,
      "verified" : false
    }
  },
  "id" : 389035989538463744,
  "created_at" : "2013-10-12 14:33:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389035734360809472",
  "text" : "just me and the dog today while dh &amp; dd are at NYComicCon. hope they have good time.",
  "id" : 389035734360809472,
  "created_at" : "2013-10-12 14:32:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cancer",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "Industry",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "Science",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "Mammograms",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "health",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/EGo7XRvKM3",
      "expanded_url" : "http:\/\/bit.ly\/74RK0z",
      "display_url" : "bit.ly\/74RK0z"
    } ]
  },
  "geo" : { },
  "id_str" : "388813812570533888",
  "text" : "RT @drbloem: #Cancer #Industry Abandons #Science to Keep Pushing #Mammograms That Harm #health http:\/\/t.co\/EGo7XRvKM3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dripita.com\" rel=\"nofollow\"\u003EDripita\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cancer",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Industry",
        "indices" : [ 8, 17 ]
      }, {
        "text" : "Science",
        "indices" : [ 27, 35 ]
      }, {
        "text" : "Mammograms",
        "indices" : [ 52, 63 ]
      }, {
        "text" : "health",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/EGo7XRvKM3",
        "expanded_url" : "http:\/\/bit.ly\/74RK0z",
        "display_url" : "bit.ly\/74RK0z"
      } ]
    },
    "geo" : { },
    "id_str" : "388812702929260546",
    "text" : "#Cancer #Industry Abandons #Science to Keep Pushing #Mammograms That Harm #health http:\/\/t.co\/EGo7XRvKM3",
    "id" : 388812702929260546,
    "created_at" : "2013-10-11 23:45:46 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 388813812570533888,
  "created_at" : "2013-10-11 23:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gardasil",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "Vaccine",
      "indices" : [ 23, 31 ]
    }, {
      "text" : "Cancer",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/yCZSlLRPg9",
      "expanded_url" : "http:\/\/bit.ly\/19hy1PY",
      "display_url" : "bit.ly\/19hy1PY"
    } ]
  },
  "geo" : { },
  "id_str" : "388781372829356032",
  "text" : "RT @drbloem: #Gardasil #Vaccine Dangerous &amp; Completely Useless at Preventing Cervical #Cancer http:\/\/t.co\/yCZSlLRPg9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gardasil",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "Vaccine",
        "indices" : [ 10, 18 ]
      }, {
        "text" : "Cancer",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/yCZSlLRPg9",
        "expanded_url" : "http:\/\/bit.ly\/19hy1PY",
        "display_url" : "bit.ly\/19hy1PY"
      } ]
    },
    "geo" : { },
    "id_str" : "388780599814922240",
    "text" : "#Gardasil #Vaccine Dangerous &amp; Completely Useless at Preventing Cervical #Cancer http:\/\/t.co\/yCZSlLRPg9",
    "id" : 388780599814922240,
    "created_at" : "2013-10-11 21:38:12 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 388781372829356032,
  "created_at" : "2013-10-11 21:41:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388739964722089985",
  "text" : "another weather headache.. blah.",
  "id" : 388739964722089985,
  "created_at" : "2013-10-11 18:56:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388712715276918784",
  "text" : "@Lluminous_ i really dislike those things on facebook that celebrate getting asswhooped as kids and current kids need it.. sigh.",
  "id" : 388712715276918784,
  "created_at" : "2013-10-11 17:08:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388709029205540864",
  "geo" : { },
  "id_str" : "388712077667205120",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl can always count on you to keep me grounded when my ego gets carried away. ((hugs))",
  "id" : 388712077667205120,
  "in_reply_to_status_id" : 388709029205540864,
  "created_at" : "2013-10-11 17:05:55 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prochoice",
      "indices" : [ 94, 104 ]
    }, {
      "text" : "reproductiverights",
      "indices" : [ 106, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/QhKNQQ52PT",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-kj",
      "display_url" : "wp.me\/p372Ye-kj"
    } ]
  },
  "geo" : { },
  "id_str" : "388699494881427456",
  "text" : "RT @virtusetveritas: Part three of my story of how I became pro-choice http:\/\/t.co\/QhKNQQ52PT #prochoice  #reproductiverights",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prochoice",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "reproductiverights",
        "indices" : [ 85, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/QhKNQQ52PT",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-kj",
        "display_url" : "wp.me\/p372Ye-kj"
      } ]
    },
    "geo" : { },
    "id_str" : "388696799210668032",
    "text" : "Part three of my story of how I became pro-choice http:\/\/t.co\/QhKNQQ52PT #prochoice  #reproductiverights",
    "id" : 388696799210668032,
    "created_at" : "2013-10-11 16:05:13 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 388699494881427456,
  "created_at" : "2013-10-11 16:15:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin-Health Nut News",
      "screen_name" : "unhealthytruth",
      "indices" : [ 3, 18 ],
      "id_str" : "18093097",
      "id" : 18093097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388683193635057664",
  "text" : "RT @unhealthytruth: You know, sometimes all you need is twenty seconds of insane courage. Just literally twenty seconds of just embarrassin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388682912435957761",
    "text" : "You know, sometimes all you need is twenty seconds of insane courage. Just literally twenty seconds of just embarrassing bravery.~Matt Damon",
    "id" : 388682912435957761,
    "created_at" : "2013-10-11 15:10:02 +0000",
    "user" : {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "protected" : false,
      "id_str" : "25056239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684904916184256512\/Zr_EBvr0_normal.jpg",
      "id" : 25056239,
      "verified" : false
    }
  },
  "id" : 388683193635057664,
  "created_at" : "2013-10-11 15:11:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vermont",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "photo",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ltdpN5AP6S",
      "expanded_url" : "http:\/\/bit.ly\/VnVuuG",
      "display_url" : "bit.ly\/VnVuuG"
    } ]
  },
  "geo" : { },
  "id_str" : "388682736405581824",
  "text" : "RT @MartinBelan: Peacham, #Vermont http:\/\/t.co\/ltdpN5AP6S #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vermont",
        "indices" : [ 9, 17 ]
      }, {
        "text" : "photo",
        "indices" : [ 41, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/ltdpN5AP6S",
        "expanded_url" : "http:\/\/bit.ly\/VnVuuG",
        "display_url" : "bit.ly\/VnVuuG"
      } ]
    },
    "geo" : { },
    "id_str" : "388681110298693634",
    "text" : "Peacham, #Vermont http:\/\/t.co\/ltdpN5AP6S #photo",
    "id" : 388681110298693634,
    "created_at" : "2013-10-11 15:02:52 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 388682736405581824,
  "created_at" : "2013-10-11 15:09:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388682508872990720",
  "text" : "RT @JALpalyul: All the universe depends on the love that you are at this very moment. #quote JAL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388681216167510016",
    "text" : "All the universe depends on the love that you are at this very moment. #quote JAL",
    "id" : 388681216167510016,
    "created_at" : "2013-10-11 15:03:17 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 388682508872990720,
  "created_at" : "2013-10-11 15:08:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388680549071880192",
  "text" : "RT @TheGoldenMirror: Be careful not to lose your own identity when you adopt the characteristics of a group.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388680259832668160",
    "text" : "Be careful not to lose your own identity when you adopt the characteristics of a group.",
    "id" : 388680259832668160,
    "created_at" : "2013-10-11 14:59:29 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 388680549071880192,
  "created_at" : "2013-10-11 15:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Boudreau",
      "screen_name" : "iboudreau",
      "indices" : [ 3, 13 ],
      "id_str" : "40146181",
      "id" : 40146181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388679819439128576",
  "text" : "RT @iboudreau: Anyone saying they \"believe in American values\" in front of people should have to dodge bricks. It's an insane thing to say.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388672689470066688",
    "text" : "Anyone saying they \"believe in American values\" in front of people should have to dodge bricks. It's an insane thing to say. Means nothing.",
    "id" : 388672689470066688,
    "created_at" : "2013-10-11 14:29:25 +0000",
    "user" : {
      "name" : "Ian Boudreau",
      "screen_name" : "iboudreau",
      "protected" : false,
      "id_str" : "40146181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784193426329698304\/DlI98tNU_normal.jpg",
      "id" : 40146181,
      "verified" : false
    }
  },
  "id" : 388679819439128576,
  "created_at" : "2013-10-11 14:57:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388679560516349952",
  "text" : "RT @PisseArtiste: But of course politics in most cases is nothing more than a series of empty throwaway statements from people who've done \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388678999448113152",
    "text" : "But of course politics in most cases is nothing more than a series of empty throwaway statements from people who've done the math for votes.",
    "id" : 388678999448113152,
    "created_at" : "2013-10-11 14:54:29 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 388679560516349952,
  "created_at" : "2013-10-11 14:56:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yung Demon",
      "screen_name" : "SatansDopeBoy",
      "indices" : [ 3, 17 ],
      "id_str" : "187933275",
      "id" : 187933275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388674684491149312",
  "text" : "RT @SatansDopeBoy: The fact that it's perfectly acceptable to go see a stripper but not acceptable to be a stripper irks me to no end.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388470952947761153",
    "text" : "The fact that it's perfectly acceptable to go see a stripper but not acceptable to be a stripper irks me to no end.",
    "id" : 388470952947761153,
    "created_at" : "2013-10-11 01:07:47 +0000",
    "user" : {
      "name" : "Yung Demon",
      "screen_name" : "SatansDopeBoy",
      "protected" : false,
      "id_str" : "187933275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615655909612724224\/fVesjKrO_normal.jpg",
      "id" : 187933275,
      "verified" : false
    }
  },
  "id" : 388674684491149312,
  "created_at" : "2013-10-11 14:37:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelo Carusone",
      "screen_name" : "GoAngelo",
      "indices" : [ 3, 12 ],
      "id_str" : "53130511",
      "id" : 53130511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388658232727969792",
  "text" : "RT @GoAngelo: Always bemusing me when a senator rants about how evil and dangerous the gov't is, as if he isn't part of that same gov't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388656961949941761",
    "text" : "Always bemusing me when a senator rants about how evil and dangerous the gov't is, as if he isn't part of that same gov't.",
    "id" : 388656961949941761,
    "created_at" : "2013-10-11 13:26:55 +0000",
    "user" : {
      "name" : "Angelo Carusone",
      "screen_name" : "GoAngelo",
      "protected" : false,
      "id_str" : "53130511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1129928335\/SGB_normal.jpeg",
      "id" : 53130511,
      "verified" : true
    }
  },
  "id" : 388658232727969792,
  "created_at" : "2013-10-11 13:31:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Winchester",
      "screen_name" : "ballyhewe",
      "indices" : [ 3, 13 ],
      "id_str" : "14530117",
      "id" : 14530117
    }, {
      "name" : "CBC Nova Scotia",
      "screen_name" : "CBCNS",
      "indices" : [ 65, 71 ],
      "id_str" : "18999952",
      "id" : 18999952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388656751354339328",
  "text" : "RT @ballyhewe: Moose Sex Corridor? Is that place still open?! RT @CBCNS: Maritime moose sex corridor gets $52K from U.S. charity http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBC Nova Scotia",
        "screen_name" : "CBCNS",
        "indices" : [ 50, 56 ],
        "id_str" : "18999952",
        "id" : 18999952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/at8F7IxpqQ",
        "expanded_url" : "http:\/\/bit.ly\/1birN3c",
        "display_url" : "bit.ly\/1birN3c"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 44.6954802492, -63.5789252551 ]
    },
    "id_str" : "388652656765730816",
    "text" : "Moose Sex Corridor? Is that place still open?! RT @CBCNS: Maritime moose sex corridor gets $52K from U.S. charity http:\/\/t.co\/at8F7IxpqQ",
    "id" : 388652656765730816,
    "created_at" : "2013-10-11 13:09:48 +0000",
    "user" : {
      "name" : "Tim Winchester",
      "screen_name" : "ballyhewe",
      "protected" : false,
      "id_str" : "14530117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771314587773788164\/csmnMaB6_normal.jpg",
      "id" : 14530117,
      "verified" : false
    }
  },
  "id" : 388656751354339328,
  "created_at" : "2013-10-11 13:26:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "Flenniken",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388478444788785152",
  "text" : "RT @YourAnonNews: A girl was tied up and raped after #Texas Judge Terry #Flenniken knowingly forced her to live with a sexual predator: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.GroupTweet.com\" rel=\"nofollow\"\u003EGroupTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 35, 41 ]
      }, {
        "text" : "Flenniken",
        "indices" : [ 54, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BszbrDS5gD",
        "expanded_url" : "http:\/\/www.wnd.com\/2013\/10\/girl-raped-after-judge-sends-her-to-sex-offenders-home\/",
        "display_url" : "wnd.com\/2013\/10\/girl-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388450776261357569",
    "text" : "A girl was tied up and raped after #Texas Judge Terry #Flenniken knowingly forced her to live with a sexual predator: http:\/\/t.co\/BszbrDS5gD",
    "id" : 388450776261357569,
    "created_at" : "2013-10-10 23:47:36 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787519608794157057\/dDnFKms0_normal.jpg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 388478444788785152,
  "created_at" : "2013-10-11 01:37:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388465384313331712",
  "text" : "RT @BrianRathbone: I posted an explanation of this protracted medical mystery on FB. If you have unexplained uveitis, give it a look. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/fK3NC5kGdj",
        "expanded_url" : "https:\/\/www.facebook.com\/brian.rathbone\/posts\/10202159879663644",
        "display_url" : "facebook.com\/brian.rathbone\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388459751475904512",
    "text" : "I posted an explanation of this protracted medical mystery on FB. If you have unexplained uveitis, give it a look. https:\/\/t.co\/fK3NC5kGdj",
    "id" : 388459751475904512,
    "created_at" : "2013-10-11 00:23:16 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 388465384313331712,
  "created_at" : "2013-10-11 00:45:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeaniene Frost",
      "screen_name" : "Jeaniene_Frost",
      "indices" : [ 3, 18 ],
      "id_str" : "25837521",
      "id" : 25837521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388392936213602304",
  "text" : "RT @Jeaniene_Frost: A frog has made my mailbox his home. I keep putting him out &amp; he keeps coming back in. Today, I left him. http:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jeaniene_Frost\/status\/388392536802222080\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/VVkdrB3487",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWPY9FZCYAATcpJ.jpg",
        "id_str" : "388392536814804992",
        "id" : 388392536814804992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWPY9FZCYAATcpJ.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/VVkdrB3487"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388392536802222080",
    "text" : "A frog has made my mailbox his home. I keep putting him out &amp; he keeps coming back in. Today, I left him. http:\/\/t.co\/VVkdrB3487",
    "id" : 388392536802222080,
    "created_at" : "2013-10-10 19:56:11 +0000",
    "user" : {
      "name" : "Jeaniene Frost",
      "screen_name" : "Jeaniene_Frost",
      "protected" : false,
      "id_str" : "25837521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1471122348\/Twitter_Pic__508x640__normal.jpg",
      "id" : 25837521,
      "verified" : false
    }
  },
  "id" : 388392936213602304,
  "created_at" : "2013-10-10 19:57:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388387775902265344",
  "text" : "my bad eye is sore today...",
  "id" : 388387775902265344,
  "created_at" : "2013-10-10 19:37:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/N2JWKQyzdY",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-ke",
      "display_url" : "wp.me\/p372Ye-ke"
    } ]
  },
  "geo" : { },
  "id_str" : "388382453305712640",
  "text" : "RT @virtusetveritas: ordeal of the bitter waters: part two of my story on how I became pro-choice. http:\/\/t.co\/N2JWKQyzdY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/N2JWKQyzdY",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-ke",
        "display_url" : "wp.me\/p372Ye-ke"
      } ]
    },
    "geo" : { },
    "id_str" : "388378319357362176",
    "text" : "ordeal of the bitter waters: part two of my story on how I became pro-choice. http:\/\/t.co\/N2JWKQyzdY",
    "id" : 388378319357362176,
    "created_at" : "2013-10-10 18:59:41 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 388382453305712640,
  "created_at" : "2013-10-10 19:16:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388372761141186561",
  "text" : "@weakSquare she is a very wise, old soul.",
  "id" : 388372761141186561,
  "created_at" : "2013-10-10 18:37:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolfram|Alpha",
      "screen_name" : "Wolfram_Alpha",
      "indices" : [ 3, 17 ],
      "id_str" : "35005086",
      "id" : 35005086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PokemonXY",
      "indices" : [ 105, 115 ]
    }, {
      "text" : "Pokemon",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/OTNn7mUtg1",
      "expanded_url" : "http:\/\/wolfr.am\/1aqstSP",
      "display_url" : "wolfr.am\/1aqstSP"
    } ]
  },
  "geo" : { },
  "id_str" : "388372047979888640",
  "text" : "RT @Wolfram_Alpha: Gotta Compute 'Em All! - We just added new data about Pokemon! http:\/\/t.co\/OTNn7mUtg1 #PokemonXY #Pokemon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PokemonXY",
        "indices" : [ 86, 96 ]
      }, {
        "text" : "Pokemon",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/OTNn7mUtg1",
        "expanded_url" : "http:\/\/wolfr.am\/1aqstSP",
        "display_url" : "wolfr.am\/1aqstSP"
      } ]
    },
    "geo" : { },
    "id_str" : "388367267592810496",
    "text" : "Gotta Compute 'Em All! - We just added new data about Pokemon! http:\/\/t.co\/OTNn7mUtg1 #PokemonXY #Pokemon",
    "id" : 388367267592810496,
    "created_at" : "2013-10-10 18:15:46 +0000",
    "user" : {
      "name" : "Wolfram|Alpha",
      "screen_name" : "Wolfram_Alpha",
      "protected" : false,
      "id_str" : "35005086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489803647153217537\/NH6ZQxzT_normal.png",
      "id" : 35005086,
      "verified" : true
    }
  },
  "id" : 388372047979888640,
  "created_at" : "2013-10-10 18:34:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388367175443947520",
  "text" : "@weakSquare filled out application. think our income is too low. waiting for email. (no plans came up, said wait for email.)",
  "id" : 388367175443947520,
  "created_at" : "2013-10-10 18:15:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388362595801239552",
  "text" : "RT @JohnFugelsang: We can't afford $1 Trillion on Health Care to save US lives cos we need to spend $2 Trillion on Defense to save US lives.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388356898132467712",
    "text" : "We can't afford $1 Trillion on Health Care to save US lives cos we need to spend $2 Trillion on Defense to save US lives.",
    "id" : 388356898132467712,
    "created_at" : "2013-10-10 17:34:34 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 388362595801239552,
  "created_at" : "2013-10-10 17:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388341487164862464",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses finally saw one of yr tweets on cspan2..lol",
  "id" : 388341487164862464,
  "created_at" : "2013-10-10 16:33:20 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388329699501297665",
  "geo" : { },
  "id_str" : "388338462400577536",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem i love red : )",
  "id" : 388338462400577536,
  "in_reply_to_status_id" : 388329699501297665,
  "created_at" : "2013-10-10 16:21:19 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388323617937051648",
  "text" : "RT @JohnCali: Quantum physics...reveals a basic oneness of the universe. ~ Erwin Schrodinger",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388315373927288833",
    "text" : "Quantum physics...reveals a basic oneness of the universe. ~ Erwin Schrodinger",
    "id" : 388315373927288833,
    "created_at" : "2013-10-10 14:49:34 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 388323617937051648,
  "created_at" : "2013-10-10 15:22:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388320537082359808",
  "text" : "RT @JohnCali: Let the survivalists hunker in the bunker. I'll be with the thrivalists dancing in the streets. ~ Swami Beyondananda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388315953630437376",
    "text" : "Let the survivalists hunker in the bunker. I'll be with the thrivalists dancing in the streets. ~ Swami Beyondananda",
    "id" : 388315953630437376,
    "created_at" : "2013-10-10 14:51:52 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 388320537082359808,
  "created_at" : "2013-10-10 15:10:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388319603798978560",
  "text" : "@weakSquare : (",
  "id" : 388319603798978560,
  "created_at" : "2013-10-10 15:06:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388111046189522944",
  "text" : "RT @Emmanueldagher: Not everyone will understand your journey. That's okay. Just know it's not their journey to make sense of. It's yours.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388104474754953216",
    "text" : "Not everyone will understand your journey. That's okay. Just know it's not their journey to make sense of. It's yours.",
    "id" : 388104474754953216,
    "created_at" : "2013-10-10 00:51:32 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 388111046189522944,
  "created_at" : "2013-10-10 01:17:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 0, 9 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388106951990603776",
  "geo" : { },
  "id_str" : "388109805937627139",
  "in_reply_to_user_id" : 38948326,
  "text" : "@Mortenrb lol.. yes, you are! : )",
  "id" : 388109805937627139,
  "in_reply_to_status_id" : 388106951990603776,
  "created_at" : "2013-10-10 01:12:43 +0000",
  "in_reply_to_screen_name" : "Mortenrb",
  "in_reply_to_user_id_str" : "38948326",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Badass_Bunny",
      "screen_name" : "Badass_Bunny",
      "indices" : [ 3, 16 ],
      "id_str" : "97596435",
      "id" : 97596435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388099850681978881",
  "text" : "RT @Badass_Bunny: I'm so tired of victim-blaming, slut-shaming, rapist apologists who think women cant make decisions about their own bodie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdhouseapp.com\" rel=\"nofollow\"\u003EBirdhouse\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388081827656658944",
    "text" : "I'm so tired of victim-blaming, slut-shaming, rapist apologists who think women cant make decisions about their own bodies.",
    "id" : 388081827656658944,
    "created_at" : "2013-10-09 23:21:32 +0000",
    "user" : {
      "name" : "Badass_Bunny",
      "screen_name" : "Badass_Bunny",
      "protected" : false,
      "id_str" : "97596435",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580223449\/bad_bunny_normal.jpeg",
      "id" : 97596435,
      "verified" : false
    }
  },
  "id" : 388099850681978881,
  "created_at" : "2013-10-10 00:33:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Zach Briggs",
      "screen_name" : "TheOtherZach",
      "indices" : [ 45, 58 ],
      "id_str" : "29200620",
      "id" : 29200620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/MsOYt6PCpZ",
      "expanded_url" : "http:\/\/theotherzach.com\/writes\/2013\/10\/9\/events",
      "display_url" : "theotherzach.com\/writes\/2013\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388082492630388736",
  "text" : "RT @angelaharms: No words for this post from @TheOtherZach &lt;3  http:\/\/t.co\/MsOYt6PCpZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zach Briggs",
        "screen_name" : "TheOtherZach",
        "indices" : [ 28, 41 ],
        "id_str" : "29200620",
        "id" : 29200620
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/MsOYt6PCpZ",
        "expanded_url" : "http:\/\/theotherzach.com\/writes\/2013\/10\/9\/events",
        "display_url" : "theotherzach.com\/writes\/2013\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388076813135540224",
    "text" : "No words for this post from @TheOtherZach &lt;3  http:\/\/t.co\/MsOYt6PCpZ",
    "id" : 388076813135540224,
    "created_at" : "2013-10-09 23:01:37 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 388082492630388736,
  "created_at" : "2013-10-09 23:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388080241563824128",
  "text" : "the dress is too short as a prom dress anyway and the spaghetti straps a tad too loose.",
  "id" : 388080241563824128,
  "created_at" : "2013-10-09 23:15:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388076886359674880",
  "text" : "so i got a dress, shawl and VS bra for naught. dh has work the day of party. just as well. i was nervous about going.",
  "id" : 388076886359674880,
  "created_at" : "2013-10-09 23:01:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388072127506571264",
  "geo" : { },
  "id_str" : "388073087205269504",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 i am #INFP : )",
  "id" : 388073087205269504,
  "in_reply_to_status_id" : 388072127506571264,
  "created_at" : "2013-10-09 22:46:48 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388067314307854336",
  "text" : "all this negativity is messing with my aura, ppl.. oy!",
  "id" : 388067314307854336,
  "created_at" : "2013-10-09 22:23:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388036059923095552",
  "geo" : { },
  "id_str" : "388042778304737282",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses lol",
  "id" : 388042778304737282,
  "in_reply_to_status_id" : 388036059923095552,
  "created_at" : "2013-10-09 20:46:22 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388012426673029120",
  "geo" : { },
  "id_str" : "388021272241664000",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses \"not opposed to new ideas or ways of behaving that are not traditional or widely accepted\" merriam-webster - this is me.",
  "id" : 388021272241664000,
  "in_reply_to_status_id" : 388012426673029120,
  "created_at" : "2013-10-09 19:20:55 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One World One Ocean",
      "screen_name" : "1World1Ocean",
      "indices" : [ 3, 16 ],
      "id_str" : "252233089",
      "id" : 252233089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387989559436644352",
  "text" : "RT @1World1Ocean: This humpback whale stuck by her entangled companion &amp; leapt for joy after a rescue crew cut her loose! (PHOTOS) http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BeSswpxtyz",
        "expanded_url" : "http:\/\/dailym.ai\/19A5mTv",
        "display_url" : "dailym.ai\/19A5mTv"
      } ]
    },
    "geo" : { },
    "id_str" : "387984005607325696",
    "text" : "This humpback whale stuck by her entangled companion &amp; leapt for joy after a rescue crew cut her loose! (PHOTOS) http:\/\/t.co\/BeSswpxtyz",
    "id" : 387984005607325696,
    "created_at" : "2013-10-09 16:52:49 +0000",
    "user" : {
      "name" : "One World One Ocean",
      "screen_name" : "1World1Ocean",
      "protected" : false,
      "id_str" : "252233089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2449616141\/gdvnblkj2qajw5ko5s62_normal.png",
      "id" : 252233089,
      "verified" : false
    }
  },
  "id" : 387989559436644352,
  "created_at" : "2013-10-09 17:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387982124067741696",
  "text" : "@weakSquare i have to remember to tell DH that one and see if he'll use it sometime..hehe.",
  "id" : 387982124067741696,
  "created_at" : "2013-10-09 16:45:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387981483123568640",
  "text" : "@weakSquare LOLOL",
  "id" : 387981483123568640,
  "created_at" : "2013-10-09 16:42:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/kUkuOWrfAl",
      "expanded_url" : "http:\/\/getapp.cc\/app\/707409923",
      "display_url" : "getapp.cc\/app\/707409923"
    } ]
  },
  "geo" : { },
  "id_str" : "387980382844760064",
  "text" : "RT @AppAdvice: Retweet now for a chance to win universal word game SpellGrid+ (http:\/\/t.co\/kUkuOWrfAl)!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/kUkuOWrfAl",
        "expanded_url" : "http:\/\/getapp.cc\/app\/707409923",
        "display_url" : "getapp.cc\/app\/707409923"
      } ]
    },
    "geo" : { },
    "id_str" : "387974972578476032",
    "text" : "Retweet now for a chance to win universal word game SpellGrid+ (http:\/\/t.co\/kUkuOWrfAl)!",
    "id" : 387974972578476032,
    "created_at" : "2013-10-09 16:16:56 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 387980382844760064,
  "created_at" : "2013-10-09 16:38:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/tGfU1dqzoU",
      "expanded_url" : "http:\/\/n.pr\/19gy4uX",
      "display_url" : "n.pr\/19gy4uX"
    } ]
  },
  "geo" : { },
  "id_str" : "387970550859313152",
  "text" : "RT @SangyeH: Virtual Strangers: A 'Journey' With Anna http:\/\/t.co\/tGfU1dqzoU &lt;&lt;&lt; Worth reading. #kindness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindness",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/tGfU1dqzoU",
        "expanded_url" : "http:\/\/n.pr\/19gy4uX",
        "display_url" : "n.pr\/19gy4uX"
      } ]
    },
    "geo" : { },
    "id_str" : "387962851681267713",
    "text" : "Virtual Strangers: A 'Journey' With Anna http:\/\/t.co\/tGfU1dqzoU &lt;&lt;&lt; Worth reading. #kindness",
    "id" : 387962851681267713,
    "created_at" : "2013-10-09 15:28:46 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 387970550859313152,
  "created_at" : "2013-10-09 15:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387936275484782592",
  "text" : "big pet peeve: righteousness .. (not referring necessarily to religious ppl)",
  "id" : 387936275484782592,
  "created_at" : "2013-10-09 13:43:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387934177028358144",
  "text" : "@Skeptical_Lady gratitude is always a good thing. i often thank the Universe for the blessings in my life. feels good to do so. : )",
  "id" : 387934177028358144,
  "created_at" : "2013-10-09 13:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387744781377732608",
  "geo" : { },
  "id_str" : "387745635169861632",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 that word came up in bible study today..lol",
  "id" : 387745635169861632,
  "in_reply_to_status_id" : 387744781377732608,
  "created_at" : "2013-10-09 01:05:38 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387733754795819008",
  "geo" : { },
  "id_str" : "387735500485705728",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid well for me, yes. thats why its called a belief. : )",
  "id" : 387735500485705728,
  "in_reply_to_status_id" : 387733754795819008,
  "created_at" : "2013-10-09 00:25:21 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387733330822975488",
  "text" : "RT @Emmanueldagher: We will always reflect back to us what we project out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387732678084014080",
    "text" : "We will always reflect back to us what we project out.",
    "id" : 387732678084014080,
    "created_at" : "2013-10-09 00:14:08 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 387733330822975488,
  "created_at" : "2013-10-09 00:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387720928060129281",
  "geo" : { },
  "id_str" : "387732627475537920",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ...and i missed it and ive been watching all day until about 2 hours ago..",
  "id" : 387732627475537920,
  "in_reply_to_status_id" : 387720928060129281,
  "created_at" : "2013-10-09 00:13:56 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387729070530002944",
  "geo" : { },
  "id_str" : "387731053772677120",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid 99.9%? lol.. example..hmm.. hard to say cuz i think our brains ignore conflicting evidence.",
  "id" : 387731053772677120,
  "in_reply_to_status_id" : 387729070530002944,
  "created_at" : "2013-10-09 00:07:41 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387714437471547392",
  "geo" : { },
  "id_str" : "387719239269756928",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid im not saying \"this is how it is\" .. its my current belief.. which can change with new input.",
  "id" : 387719239269756928,
  "in_reply_to_status_id" : 387714437471547392,
  "created_at" : "2013-10-08 23:20:44 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 99, 105 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/wLLlsCK4aJ",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=is-pain-construct-of-mind&WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387718018337611776",
  "text" : "RT @NewMindMirror: Fascinating story of a man's super-strength: Is Pain a Construct of the Mind? - @sciam  http:\/\/t.co\/wLLlsCK4aJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scientific American",
        "screen_name" : "sciam",
        "indices" : [ 80, 86 ],
        "id_str" : "14647570",
        "id" : 14647570
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/wLLlsCK4aJ",
        "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=is-pain-construct-of-mind&WT.mc_id=SA_sharetool_Twitter",
        "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387711610292170752",
    "text" : "Fascinating story of a man's super-strength: Is Pain a Construct of the Mind? - @sciam  http:\/\/t.co\/wLLlsCK4aJ",
    "id" : 387711610292170752,
    "created_at" : "2013-10-08 22:50:25 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 387718018337611776,
  "created_at" : "2013-10-08 23:15:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387710508972777472",
  "text" : "im so tired of seeing all the finger pointing, blaming and arguing. someone just push the damn red button and lets end it all!",
  "id" : 387710508972777472,
  "created_at" : "2013-10-08 22:46:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ICR",
      "screen_name" : "ICRCanada",
      "indices" : [ 3, 13 ],
      "id_str" : "392879606",
      "id" : 392879606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387710039047548928",
  "text" : "RT @ICRCanada: Mythology exists to guide humanity to hidden mental and spiritual laws that lead to a better understanding of oneself http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/yh17nkM4Fv",
        "expanded_url" : "http:\/\/bit.ly\/1cgKqbn",
        "display_url" : "bit.ly\/1cgKqbn"
      } ]
    },
    "geo" : { },
    "id_str" : "386569522700120064",
    "text" : "Mythology exists to guide humanity to hidden mental and spiritual laws that lead to a better understanding of oneself http:\/\/t.co\/yh17nkM4Fv",
    "id" : 386569522700120064,
    "created_at" : "2013-10-05 19:12:10 +0000",
    "user" : {
      "name" : "ICR",
      "screen_name" : "ICRCanada",
      "protected" : false,
      "id_str" : "392879606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1593653022\/logo_2__normal.png",
      "id" : 392879606,
      "verified" : false
    }
  },
  "id" : 387710039047548928,
  "created_at" : "2013-10-08 22:44:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387708301313867776",
  "geo" : { },
  "id_str" : "387709903046860800",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid im not logical thinking like you. my brain doesnt work that way.. my personality doesnt work that way (INFP)",
  "id" : 387709903046860800,
  "in_reply_to_status_id" : 387708301313867776,
  "created_at" : "2013-10-08 22:43:38 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387703405814497280",
  "geo" : { },
  "id_str" : "387706382201262080",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid i dont know how. its quantum physics. its what i believe based on books ive read and what makes sense to me.",
  "id" : 387706382201262080,
  "in_reply_to_status_id" : 387703405814497280,
  "created_at" : "2013-10-08 22:29:39 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387693732461428736",
  "geo" : { },
  "id_str" : "387695419964149760",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid soul is not the mind. it's consciousness which is a finer energy than physical.",
  "id" : 387695419964149760,
  "in_reply_to_status_id" : 387693732461428736,
  "created_at" : "2013-10-08 21:46:05 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387684126922244096",
  "geo" : { },
  "id_str" : "387688597077229569",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid ive seen that clip before.. the soul uses the body to interact in the physical. brain damage=no afterlife or soul?",
  "id" : 387688597077229569,
  "in_reply_to_status_id" : 387684126922244096,
  "created_at" : "2013-10-08 21:18:59 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387680774452830208",
  "geo" : { },
  "id_str" : "387682531862003712",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid i do believe we continue on as consciousness after death of our body.",
  "id" : 387682531862003712,
  "in_reply_to_status_id" : 387680774452830208,
  "created_at" : "2013-10-08 20:54:53 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387679302168215554",
  "geo" : { },
  "id_str" : "387680461499006976",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid agree w that statement but no.. i meant our afterlife is created by how we view and interact w others.",
  "id" : 387680461499006976,
  "in_reply_to_status_id" : 387679302168215554,
  "created_at" : "2013-10-08 20:46:39 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387676275344551936",
  "geo" : { },
  "id_str" : "387676967765409794",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses oh god yes..lol. was always my creal of choice when my mom would let me pick one for a treat!",
  "id" : 387676967765409794,
  "in_reply_to_status_id" : 387676275344551936,
  "created_at" : "2013-10-08 20:32:46 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387674134362075136",
  "geo" : { },
  "id_str" : "387675653677395968",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid my belief is ppl create what they believe to be true.. so some ppl WILL find themselves in \"Hell\" becuz they are miserable.",
  "id" : 387675653677395968,
  "in_reply_to_status_id" : 387674134362075136,
  "created_at" : "2013-10-08 20:27:33 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387664008100454401",
  "text" : "RT @CoyoteSings: Both red and blue will tell everyone that they only want what's best for the country, while totally ignoring what the coun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387663109814358016",
    "text" : "Both red and blue will tell everyone that they only want what's best for the country, while totally ignoring what the country wants, itself.",
    "id" : 387663109814358016,
    "created_at" : "2013-10-08 19:37:42 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 387664008100454401,
  "created_at" : "2013-10-08 19:41:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387656376623067136",
  "text" : "RT @damienechols: You don't need to see the whole path. Just take the first step in faith, and the next step will present itself. Then the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387656272205873152",
    "text" : "You don't need to see the whole path. Just take the first step in faith, and the next step will present itself. Then the next.",
    "id" : 387656272205873152,
    "created_at" : "2013-10-08 19:10:32 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 387656376623067136,
  "created_at" : "2013-10-08 19:10:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZigZiglar",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/X5TFU5m4r7",
      "expanded_url" : "http:\/\/tinyurl.com\/9h3k42u",
      "display_url" : "tinyurl.com\/9h3k42u"
    } ]
  },
  "geo" : { },
  "id_str" : "387655379351789568",
  "text" : "RT @Soulseedzforall: Every obnoxious act is a cry for help. #ZigZiglar http:\/\/t.co\/X5TFU5m4r7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZigZiglar",
        "indices" : [ 39, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/X5TFU5m4r7",
        "expanded_url" : "http:\/\/tinyurl.com\/9h3k42u",
        "display_url" : "tinyurl.com\/9h3k42u"
      } ]
    },
    "geo" : { },
    "id_str" : "387654889716731905",
    "text" : "Every obnoxious act is a cry for help. #ZigZiglar http:\/\/t.co\/X5TFU5m4r7",
    "id" : 387654889716731905,
    "created_at" : "2013-10-08 19:05:02 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 387655379351789568,
  "created_at" : "2013-10-08 19:06:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387654843638095872",
  "text" : "you cant trust anyone. NOT EVEN YOURSELF! what does that leave?",
  "id" : 387654843638095872,
  "created_at" : "2013-10-08 19:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387648343582597120",
  "text" : "my beautiful DD.. such a rebel.. and a protector! she's blooming &lt;3",
  "id" : 387648343582597120,
  "created_at" : "2013-10-08 18:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387646413116829696",
  "geo" : { },
  "id_str" : "387647342930714625",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses truth.",
  "id" : 387647342930714625,
  "in_reply_to_status_id" : 387646413116829696,
  "created_at" : "2013-10-08 18:35:03 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387637750167388160",
  "text" : "@KevinRDaugherty living the good life.. bless her &lt;3",
  "id" : 387637750167388160,
  "created_at" : "2013-10-08 17:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387637073534267392",
  "text" : "RT @HealthRanger: Court rules Amish girl to be forced onto chemotherapy; Akron Children's Hospital predatory medicine http:\/\/t.co\/PdbGNWMTj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthRanger",
        "screen_name" : "HealthRanger",
        "indices" : [ 127, 140 ],
        "id_str" : "15843059",
        "id" : 15843059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/PdbGNWMTjR",
        "expanded_url" : "http:\/\/www.naturalnews.com\/042393_Akron_Childrens_Hospital_Amish_girl_chemotherapy_court_case.html",
        "display_url" : "naturalnews.com\/042393_Akron_C\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387634767232921601",
    "text" : "Court rules Amish girl to be forced onto chemotherapy; Akron Children's Hospital predatory medicine http:\/\/t.co\/PdbGNWMTjR via @HealthRanger",
    "id" : 387634767232921601,
    "created_at" : "2013-10-08 17:45:05 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 387637073534267392,
  "created_at" : "2013-10-08 17:54:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387632508671516672",
  "text" : "dh is smart,handy,productive,honest,kind. in a dire situation, he's the one you'd call!!",
  "id" : 387632508671516672,
  "created_at" : "2013-10-08 17:36:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387631617084116992",
  "text" : "apparently if you do not have a good job (ie. one that has benefits and pays well,) you are lazy, stupid and drain on society. ((screams))",
  "id" : 387631617084116992,
  "created_at" : "2013-10-08 17:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jamie",
      "screen_name" : "gnuman1979",
      "indices" : [ 3, 14 ],
      "id_str" : "257715213",
      "id" : 257715213
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gnuman1979\/status\/387627274737963008\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/0jKpSVZeOT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWEg8-CCUAEQ7nq.jpg",
      "id_str" : "387627274746351617",
      "id" : 387627274746351617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWEg8-CCUAEQ7nq.jpg",
      "sizes" : [ {
        "h" : 980,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 980,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 980,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/0jKpSVZeOT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387628163473608704",
  "text" : "RT @gnuman1979: Angry birds, real life addition. Level expert. http:\/\/t.co\/0jKpSVZeOT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gnuman1979\/status\/387627274737963008\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/0jKpSVZeOT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWEg8-CCUAEQ7nq.jpg",
        "id_str" : "387627274746351617",
        "id" : 387627274746351617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWEg8-CCUAEQ7nq.jpg",
        "sizes" : [ {
          "h" : 980,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 980,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 980,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/0jKpSVZeOT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387627274737963008",
    "text" : "Angry birds, real life addition. Level expert. http:\/\/t.co\/0jKpSVZeOT",
    "id" : 387627274737963008,
    "created_at" : "2013-10-08 17:15:18 +0000",
    "user" : {
      "name" : "jamie",
      "screen_name" : "gnuman1979",
      "protected" : false,
      "id_str" : "257715213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780073557132914693\/JpcA0EwC_normal.jpg",
      "id" : 257715213,
      "verified" : false
    }
  },
  "id" : 387628163473608704,
  "created_at" : "2013-10-08 17:18:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/DX0W1VUGfL",
      "expanded_url" : "http:\/\/usnews.nbcnews.com\/_news\/2013\/10\/07\/20860381-billionaire-couple-donates-10-million-to-head-start-programs-closed-by-us-government-shutdown",
      "display_url" : "usnews.nbcnews.com\/_news\/2013\/10\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387626625593905152",
  "geo" : { },
  "id_str" : "387627753173839872",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses speaking of HeadStart, this was nice &gt;&gt; http:\/\/t.co\/DX0W1VUGfL",
  "id" : 387627753173839872,
  "in_reply_to_status_id" : 387626625593905152,
  "created_at" : "2013-10-08 17:17:12 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387618706353688576",
  "text" : "evolution, climate, hell, the president (well, all democrats) .. sigh.",
  "id" : 387618706353688576,
  "created_at" : "2013-10-08 16:41:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387618176474693633",
  "text" : "i can kinda understand #atheist frustrations w christians when i go to bible study.",
  "id" : 387618176474693633,
  "created_at" : "2013-10-08 16:39:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387617883452223488",
  "text" : "i am where i'm supposed to be but its got me scratching my head...",
  "id" : 387617883452223488,
  "created_at" : "2013-10-08 16:37:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387617636793581568",
  "text" : "i am a wolf in sheep's clothing...",
  "id" : 387617636793581568,
  "created_at" : "2013-10-08 16:37:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387566933542830080",
  "text" : "my brain wont begin working until noon...",
  "id" : 387566933542830080,
  "created_at" : "2013-10-08 13:15:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387562283586846720",
  "text" : "RT @abandontheherd: Instead of trying to achieve something, change the mindset to absolute confidence that you will achieve it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387550102216118272",
    "text" : "Instead of trying to achieve something, change the mindset to absolute confidence that you will achieve it.",
    "id" : 387550102216118272,
    "created_at" : "2013-10-08 12:08:39 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 387562283586846720,
  "created_at" : "2013-10-08 12:57:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387560828335316992",
  "text" : "RT @bend_time: Teachers are supposed to fix everything, make everyone a genius, understand all needs and meet them while obeying state ed m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387558607790686208",
    "text" : "Teachers are supposed to fix everything, make everyone a genius, understand all needs and meet them while obeying state ed mandates. Come ON",
    "id" : 387558607790686208,
    "created_at" : "2013-10-08 12:42:27 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 387560828335316992,
  "created_at" : "2013-10-08 12:51:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/DX0W1VUGfL",
      "expanded_url" : "http:\/\/usnews.nbcnews.com\/_news\/2013\/10\/07\/20860381-billionaire-couple-donates-10-million-to-head-start-programs-closed-by-us-government-shutdown",
      "display_url" : "usnews.nbcnews.com\/_news\/2013\/10\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387347600455647232",
  "geo" : { },
  "id_str" : "387395230049116160",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste http:\/\/t.co\/DX0W1VUGfL",
  "id" : 387395230049116160,
  "in_reply_to_status_id" : 387347600455647232,
  "created_at" : "2013-10-08 01:53:14 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387388575735898112",
  "text" : "RT @DwayneReaves: Watching the news is about like listening to a pack of hound dogs barking in the middle of the night. Nothing but a bunch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387385223840681984",
    "text" : "Watching the news is about like listening to a pack of hound dogs barking in the middle of the night. Nothing but a bunch of noise!",
    "id" : 387385223840681984,
    "created_at" : "2013-10-08 01:13:29 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 387388575735898112,
  "created_at" : "2013-10-08 01:26:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387385355840012288",
  "geo" : { },
  "id_str" : "387388496907751425",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits i didnt know i could get from reg DR for long time. but have been getting #effexor rx from reg DR for sev years now.",
  "id" : 387388496907751425,
  "in_reply_to_status_id" : 387385355840012288,
  "created_at" : "2013-10-08 01:26:29 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "sevenbowie",
      "screen_name" : "sevenbowie",
      "indices" : [ 19, 30 ],
      "id_str" : "85460092",
      "id" : 85460092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MIC",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "CorpratWelfare",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/OF37Yw7dPF",
      "expanded_url" : "http:\/\/www.military.com\/daily-news\/2013\/10\/07\/new-air-force-planes-go-directly-to-boneyard.html",
      "display_url" : "military.com\/daily-news\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387374929555255296",
  "text" : "RT @PisseArtiste: \u201C@sevenbowie: New Air Force Planes Go Directly to 'Boneyard' - http:\/\/t.co\/OF37Yw7dPF #MIC #CorpratWelfare\u201D Wow. Just. Wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "sevenbowie",
        "screen_name" : "sevenbowie",
        "indices" : [ 1, 12 ],
        "id_str" : "85460092",
        "id" : 85460092
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MIC",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "CorpratWelfare",
        "indices" : [ 91, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/OF37Yw7dPF",
        "expanded_url" : "http:\/\/www.military.com\/daily-news\/2013\/10\/07\/new-air-force-planes-go-directly-to-boneyard.html",
        "display_url" : "military.com\/daily-news\/201\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "387370892356898816",
    "geo" : { },
    "id_str" : "387373947064709120",
    "in_reply_to_user_id" : 85460092,
    "text" : "\u201C@sevenbowie: New Air Force Planes Go Directly to 'Boneyard' - http:\/\/t.co\/OF37Yw7dPF #MIC #CorpratWelfare\u201D Wow. Just. Wow.",
    "id" : 387373947064709120,
    "in_reply_to_status_id" : 387370892356898816,
    "created_at" : "2013-10-08 00:28:40 +0000",
    "in_reply_to_screen_name" : "sevenbowie",
    "in_reply_to_user_id_str" : "85460092",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 387374929555255296,
  "created_at" : "2013-10-08 00:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "sevenbowie",
      "screen_name" : "sevenbowie",
      "indices" : [ 25, 36 ],
      "id_str" : "85460092",
      "id" : 85460092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387373947064709120",
  "geo" : { },
  "id_str" : "387374903831191553",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste sickening! @sevenbowie",
  "id" : 387374903831191553,
  "in_reply_to_status_id" : 387373947064709120,
  "created_at" : "2013-10-08 00:32:28 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedicareForAll",
      "indices" : [ 42, 57 ]
    }, {
      "text" : "Medicaid",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387365393360515072",
  "text" : "RT @AllOnMedicare: Letter to NYTimes says #MedicareForAll is solution for dealing with states not expanding #Medicaid: http:\/\/t.co\/o6gsORFr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedicareForAll",
        "indices" : [ 23, 38 ]
      }, {
        "text" : "Medicaid",
        "indices" : [ 89, 98 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/o6gsORFrH7",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/10\/07\/opinion\/without-health-insurance-those-left-behind.html?_r=0",
        "display_url" : "nytimes.com\/2013\/10\/07\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387363999563517953",
    "text" : "Letter to NYTimes says #MedicareForAll is solution for dealing with states not expanding #Medicaid: http:\/\/t.co\/o6gsORFrH7 #SinglePayer",
    "id" : 387363999563517953,
    "created_at" : "2013-10-07 23:49:09 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 387365393360515072,
  "created_at" : "2013-10-07 23:54:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheryl Lorraine",
      "screen_name" : "cherapple",
      "indices" : [ 0, 10 ],
      "id_str" : "18154412",
      "id" : 18154412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387357709017694208",
  "geo" : { },
  "id_str" : "387358458481106944",
  "in_reply_to_user_id" : 18154412,
  "text" : "@cherapple ive seen ones where they will be given coffee and a puppy but chained and sold is not funny.",
  "id" : 387358458481106944,
  "in_reply_to_status_id" : 387357709017694208,
  "created_at" : "2013-10-07 23:27:07 +0000",
  "in_reply_to_screen_name" : "cherapple",
  "in_reply_to_user_id_str" : "18154412",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387357642751868928",
  "text" : "@1stCitizenKane ((hugs)) : )",
  "id" : 387357642751868928,
  "created_at" : "2013-10-07 23:23:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387353316314730496",
  "geo" : { },
  "id_str" : "387354082844766210",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses on tv? how did i miss them? lol",
  "id" : 387354082844766210,
  "in_reply_to_status_id" : 387353316314730496,
  "created_at" : "2013-10-07 23:09:44 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387353452428668928",
  "text" : "RT @umairh: The Swiss are voting on a basic income of $32,000 annually for every citizen. Poverty in America is defined as $12,000.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386897215454982144",
    "text" : "The Swiss are voting on a basic income of $32,000 annually for every citizen. Poverty in America is defined as $12,000.",
    "id" : 386897215454982144,
    "created_at" : "2013-10-06 16:54:19 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 387353452428668928,
  "created_at" : "2013-10-07 23:07:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387340590024630272",
  "geo" : { },
  "id_str" : "387352583834058752",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses wait.. what? you got a tweet on cspan? cool!",
  "id" : 387352583834058752,
  "in_reply_to_status_id" : 387340590024630272,
  "created_at" : "2013-10-07 23:03:47 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387342519693869056",
  "geo" : { },
  "id_str" : "387351967929868289",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses my mom would make pork chops with lima beans..yum",
  "id" : 387351967929868289,
  "in_reply_to_status_id" : 387342519693869056,
  "created_at" : "2013-10-07 23:01:20 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truth",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387350568899198977",
  "text" : "RT @grouchypuppy: ALL dogs are good. The key is matching the individual dog with the right person and family.  #truth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "truth",
        "indices" : [ 93, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387349189551984640",
    "text" : "ALL dogs are good. The key is matching the individual dog with the right person and family.  #truth",
    "id" : 387349189551984640,
    "created_at" : "2013-10-07 22:50:18 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 387350568899198977,
  "created_at" : "2013-10-07 22:55:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387295219999182848",
  "text" : "im playing spite and malice on my kindle fire. its a free app today. i really like it.",
  "id" : 387295219999182848,
  "created_at" : "2013-10-07 19:15:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387289700962021376",
  "text" : "RT @alanhdawe: God-Consciousness is in everything, and is everything; therefore, there cannot truly be an absence of God-Consciousness anyw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387289486956462080",
    "text" : "God-Consciousness is in everything, and is everything; therefore, there cannot truly be an absence of God-Consciousness anywhere. #TGFBook",
    "id" : 387289486956462080,
    "created_at" : "2013-10-07 18:53:03 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 387289700962021376,
  "created_at" : "2013-10-07 18:53:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "indices" : [ 3, 16 ],
      "id_str" : "20015311",
      "id" : 20015311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387286008946888704",
  "text" : "RT @rickygervais: Being offended provides no objective indication of \"right\" &amp; \"wrong\". It's nothing more than a barometer of your own emot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387198758662176768",
    "text" : "Being offended provides no objective indication of \"right\" &amp; \"wrong\". It's nothing more than a barometer of your own emotional control.",
    "id" : 387198758662176768,
    "created_at" : "2013-10-07 12:52:32 +0000",
    "user" : {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "protected" : false,
      "id_str" : "20015311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642744174744313857\/VaPUCm3l_normal.jpg",
      "id" : 20015311,
      "verified" : true
    }
  },
  "id" : 387286008946888704,
  "created_at" : "2013-10-07 18:39:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/RYHDJZdYrZ",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2013\/10\/wolf-gives-kisses-to-woman\/",
      "display_url" : "lifewithdogs.tv\/2013\/10\/wolf-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387268261164761089",
  "text" : "Wolf Gives Kisses to Woman http:\/\/t.co\/RYHDJZdYrZ",
  "id" : 387268261164761089,
  "created_at" : "2013-10-07 17:28:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "io9",
      "screen_name" : "io9",
      "indices" : [ 3, 7 ],
      "id_str" : "13215132",
      "id" : 13215132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/6jkD9DATPD",
      "expanded_url" : "http:\/\/on.io9.com\/hA4jiaW",
      "display_url" : "on.io9.com\/hA4jiaW"
    } ]
  },
  "geo" : { },
  "id_str" : "387259525239029760",
  "text" : "RT @io9: Brain scans show that dogs are as conscious as human children http:\/\/t.co\/6jkD9DATPD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/6jkD9DATPD",
        "expanded_url" : "http:\/\/on.io9.com\/hA4jiaW",
        "display_url" : "on.io9.com\/hA4jiaW"
      } ]
    },
    "geo" : { },
    "id_str" : "387254992589320192",
    "text" : "Brain scans show that dogs are as conscious as human children http:\/\/t.co\/6jkD9DATPD",
    "id" : 387254992589320192,
    "created_at" : "2013-10-07 16:35:59 +0000",
    "user" : {
      "name" : "io9",
      "screen_name" : "io9",
      "protected" : false,
      "id_str" : "13215132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987478150\/f20258fd958408104e415fbc7b57b0bc_normal.png",
      "id" : 13215132,
      "verified" : true
    }
  },
  "id" : 387259525239029760,
  "created_at" : "2013-10-07 16:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob",
      "screen_name" : "rhc047",
      "indices" : [ 0, 7 ],
      "id_str" : "1122147829",
      "id" : 1122147829
    }, {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 29, 38 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387256573036617728",
  "geo" : { },
  "id_str" : "387259087513067520",
  "in_reply_to_user_id" : 1122147829,
  "text" : "@rhc047 I certainly hope so! @Adenovir",
  "id" : 387259087513067520,
  "in_reply_to_status_id" : 387256573036617728,
  "created_at" : "2013-10-07 16:52:16 +0000",
  "in_reply_to_screen_name" : "rhc047",
  "in_reply_to_user_id_str" : "1122147829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/QJ6KsxF7Qe",
      "expanded_url" : "http:\/\/www.healthrates.mid.ms.gov\/",
      "display_url" : "healthrates.mid.ms.gov"
    }, {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/WRp3LsFOQj",
      "expanded_url" : "http:\/\/www.onemississippi.com\/index.php",
      "display_url" : "onemississippi.com\/index.php"
    } ]
  },
  "in_reply_to_status_id_str" : "387250028924121088",
  "geo" : { },
  "id_str" : "387252144765562880",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses oops! lol try these: http:\/\/t.co\/QJ6KsxF7Qe , http:\/\/t.co\/WRp3LsFOQj",
  "id" : 387252144765562880,
  "in_reply_to_status_id" : 387250028924121088,
  "created_at" : "2013-10-07 16:24:40 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Luy6rdvyTL",
      "expanded_url" : "http:\/\/enrollmissouri.org\/choose_your_path\/individual",
      "display_url" : "enrollmissouri.org\/choose_your_pa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387244026610847744",
  "geo" : { },
  "id_str" : "387246325617553408",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses HTH - http:\/\/t.co\/Luy6rdvyTL - do you have excel? if yes, file shows plans.",
  "id" : 387246325617553408,
  "in_reply_to_status_id" : 387244026610847744,
  "created_at" : "2013-10-07 16:01:33 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zgvzXTASbP",
      "expanded_url" : "http:\/\/kff.org\/infographic\/the-requirement-to-buy-coverage-under-the-affordable-care-act\/",
      "display_url" : "kff.org\/infographic\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387242200087547904",
  "text" : "The Requirement to Buy Coverage Under the Affordable Care Act http:\/\/t.co\/zgvzXTASbP",
  "id" : 387242200087547904,
  "created_at" : "2013-10-07 15:45:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 99, 113 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/D8mRdMtyRp",
      "expanded_url" : "https:\/\/www.healthcare.gov\/exemptions",
      "display_url" : "healthcare.gov\/exemptions"
    } ]
  },
  "geo" : { },
  "id_str" : "387241844372807680",
  "text" : "How do I get an exemption from the fee for not having health coverage? https:\/\/t.co\/D8mRdMtyRp via @HealthCareGov",
  "id" : 387241844372807680,
  "created_at" : "2013-10-07 15:43:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/PMwxq3IPfD",
      "expanded_url" : "http:\/\/www.csmonitor.com\/USA\/DC-Decoder\/2013\/1001\/Obamacare-101-What-to-know-if-you-opt-out-of-buying-health-insurance?cmpid=addthis_twitter#.UlLWItUJjtZ.twitter",
      "display_url" : "csmonitor.com\/USA\/DC-Decoder\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387241264749367297",
  "text" : "Obamacare 101: What to know if you opt out of buying health insurance http:\/\/t.co\/PMwxq3IPfD",
  "id" : 387241264749367297,
  "created_at" : "2013-10-07 15:41:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PositiveRippleEffect",
      "screen_name" : "PositiveRipples",
      "indices" : [ 3, 19 ],
      "id_str" : "212687768",
      "id" : 212687768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387239015948120065",
  "text" : "RT @PositiveRipples: \"Extend to each person, no matter how trivial the contact, all the care, kindness, &amp; understanding you can muster.\" - \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387236002802442240",
    "text" : "\"Extend to each person, no matter how trivial the contact, all the care, kindness, &amp; understanding you can muster.\" - Og Mandino #quote",
    "id" : 387236002802442240,
    "created_at" : "2013-10-07 15:20:32 +0000",
    "user" : {
      "name" : "PositiveRippleEffect",
      "screen_name" : "PositiveRipples",
      "protected" : false,
      "id_str" : "212687768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466061355548565506\/ju51P0TT_normal.jpeg",
      "id" : 212687768,
      "verified" : false
    }
  },
  "id" : 387239015948120065,
  "created_at" : "2013-10-07 15:32:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lost Pets of the HV",
      "screen_name" : "LostPetsHV",
      "indices" : [ 3, 14 ],
      "id_str" : "1115387942",
      "id" : 1115387942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387238211476398080",
  "text" : "RT @LostPetsHV: MISSING: Alex from FAIRFIELD, CT. Anyone with any info please contact Hal at 203-917-0778. Please share!! Thank... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/0TX0wtZeWr",
        "expanded_url" : "http:\/\/fb.me\/2KlGaUbGL",
        "display_url" : "fb.me\/2KlGaUbGL"
      } ]
    },
    "geo" : { },
    "id_str" : "387236983762063360",
    "text" : "MISSING: Alex from FAIRFIELD, CT. Anyone with any info please contact Hal at 203-917-0778. Please share!! Thank... http:\/\/t.co\/0TX0wtZeWr",
    "id" : 387236983762063360,
    "created_at" : "2013-10-07 15:24:26 +0000",
    "user" : {
      "name" : "Lost Pets of the HV",
      "screen_name" : "LostPetsHV",
      "protected" : false,
      "id_str" : "1115387942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642547223948038144\/fjMObRsy_normal.jpg",
      "id" : 1115387942,
      "verified" : false
    }
  },
  "id" : 387238211476398080,
  "created_at" : "2013-10-07 15:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387218132772720640",
  "text" : "RT @AllOnMedicare: @VTLeads USA is becoming a country where you have 'choice' of insurer, but no 'choice' of doctor or hospital unless you \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387214386915315712",
    "text" : "@VTLeads USA is becoming a country where you have 'choice' of insurer, but no 'choice' of doctor or hospital unless you are very rich.",
    "id" : 387214386915315712,
    "created_at" : "2013-10-07 13:54:38 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 387218132772720640,
  "created_at" : "2013-10-07 14:09:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calke Abbey",
      "screen_name" : "NTCalkeAbbey",
      "indices" : [ 3, 16 ],
      "id_str" : "274551360",
      "id" : 274551360
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NTCalkeAbbey\/status\/387197221201924096\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/S0PUviuF4e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BV-Z0jwCUAAuf-j.jpg",
      "id_str" : "387197221206118400",
      "id" : 387197221206118400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV-Z0jwCUAAuf-j.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/S0PUviuF4e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387216772476043264",
  "text" : "RT @NTCalkeAbbey: Longhorn cattle milking it this morning and not let us moo've on... http:\/\/t.co\/S0PUviuF4e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NTCalkeAbbey\/status\/387197221201924096\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/S0PUviuF4e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BV-Z0jwCUAAuf-j.jpg",
        "id_str" : "387197221206118400",
        "id" : 387197221206118400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV-Z0jwCUAAuf-j.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/S0PUviuF4e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387197221201924096",
    "text" : "Longhorn cattle milking it this morning and not let us moo've on... http:\/\/t.co\/S0PUviuF4e",
    "id" : 387197221201924096,
    "created_at" : "2013-10-07 12:46:26 +0000",
    "user" : {
      "name" : "Calke Abbey",
      "screen_name" : "NTCalkeAbbey",
      "protected" : false,
      "id_str" : "274551360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705413749344174081\/saiEWWHW_normal.jpg",
      "id" : 274551360,
      "verified" : false
    }
  },
  "id" : 387216772476043264,
  "created_at" : "2013-10-07 14:04:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "indices" : [ 3, 16 ],
      "id_str" : "78155553",
      "id" : 78155553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387006397834997760",
  "text" : "RT @angelmagicjp: If you believe in love, magic and miracles aren't far behind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387005834250571776",
    "text" : "If you believe in love, magic and miracles aren't far behind.",
    "id" : 387005834250571776,
    "created_at" : "2013-10-07 00:05:55 +0000",
    "user" : {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "protected" : false,
      "id_str" : "78155553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1497479357\/Hand_Heart_Sun_2_normal.jpg",
      "id" : 78155553,
      "verified" : false
    }
  },
  "id" : 387006397834997760,
  "created_at" : "2013-10-07 00:08:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387002746143907840",
  "geo" : { },
  "id_str" : "387003505115807744",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses whoawhoawhoa.. take a chill pill.. we don't need you having a heart attack! : ) (mm.. grilled chicken breast sounds good)",
  "id" : 387003505115807744,
  "in_reply_to_status_id" : 387002746143907840,
  "created_at" : "2013-10-06 23:56:40 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/9DRYexoGbw",
      "expanded_url" : "http:\/\/youtu.be\/kWdPXUyMiM8",
      "display_url" : "youtu.be\/kWdPXUyMiM8"
    } ]
  },
  "geo" : { },
  "id_str" : "386993055456194560",
  "text" : "If We Create Our Own Reality, How Do You Explain Suffering?: http:\/\/t.co\/9DRYexoGbw",
  "id" : 386993055456194560,
  "created_at" : "2013-10-06 23:15:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386984762457731072",
  "geo" : { },
  "id_str" : "386985505683824640",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 yes! i also loved hill's \"heart-shaped box\"",
  "id" : 386985505683824640,
  "in_reply_to_status_id" : 386984762457731072,
  "created_at" : "2013-10-06 22:45:09 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/o66NLCsAVV",
      "expanded_url" : "http:\/\/amzn.to\/iarZxK",
      "display_url" : "amzn.to\/iarZxK"
    } ]
  },
  "geo" : { },
  "id_str" : "386960675672965120",
  "text" : "finished Horns: A Novel by Joe Hill http:\/\/t.co\/o66NLCsAVV",
  "id" : 386960675672965120,
  "created_at" : "2013-10-06 21:06:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Effie Mcintosh",
      "screen_name" : "AKbirder",
      "indices" : [ 28, 37 ],
      "id_str" : "4202024795",
      "id" : 4202024795
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AKbirder\/status\/386625136679342080\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/43m7NOQ2Fn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BV2Rg2SCEAAfkF4.jpg",
      "id_str" : "386625136536719360",
      "id" : 386625136536719360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV2Rg2SCEAAfkF4.jpg",
      "sizes" : [ {
        "h" : 443,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 755,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1062,
        "resize" : "fit",
        "w" : 1440
      } ],
      "display_url" : "pic.twitter.com\/43m7NOQ2Fn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386903204752916480",
  "text" : "RT @KerriFar: Love this! RT @AKbirder: Lots of squeaky little goldfinches here in Idaho: http:\/\/t.co\/43m7NOQ2Fn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Effie Mcintosh",
        "screen_name" : "AKbirder",
        "indices" : [ 14, 23 ],
        "id_str" : "4202024795",
        "id" : 4202024795
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AKbirder\/status\/386625136679342080\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/43m7NOQ2Fn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BV2Rg2SCEAAfkF4.jpg",
        "id_str" : "386625136536719360",
        "id" : 386625136536719360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV2Rg2SCEAAfkF4.jpg",
        "sizes" : [ {
          "h" : 443,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 755,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1062,
          "resize" : "fit",
          "w" : 1440
        } ],
        "display_url" : "pic.twitter.com\/43m7NOQ2Fn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386900071285293056",
    "text" : "Love this! RT @AKbirder: Lots of squeaky little goldfinches here in Idaho: http:\/\/t.co\/43m7NOQ2Fn",
    "id" : 386900071285293056,
    "created_at" : "2013-10-06 17:05:39 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 386903204752916480,
  "created_at" : "2013-10-06 17:18:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "indices" : [ 3, 13 ],
      "id_str" : "27142719",
      "id" : 27142719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/m8vviTMpzQ",
      "expanded_url" : "http:\/\/ow.ly\/pxHFe",
      "display_url" : "ow.ly\/pxHFe"
    } ]
  },
  "geo" : { },
  "id_str" : "386893777433927680",
  "text" : "RT @robkroese: Mercury Falls, Mercury Rises, and Mercury Rests are on sale for $1.99 each today! http:\/\/t.co\/m8vviTMpzQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/m8vviTMpzQ",
        "expanded_url" : "http:\/\/ow.ly\/pxHFe",
        "display_url" : "ow.ly\/pxHFe"
      } ]
    },
    "geo" : { },
    "id_str" : "386888021481885696",
    "text" : "Mercury Falls, Mercury Rises, and Mercury Rests are on sale for $1.99 each today! http:\/\/t.co\/m8vviTMpzQ",
    "id" : 386888021481885696,
    "created_at" : "2013-10-06 16:17:47 +0000",
    "user" : {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "protected" : false,
      "id_str" : "27142719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759449467435229184\/Kqa5_jGt_normal.jpg",
      "id" : 27142719,
      "verified" : false
    }
  },
  "id" : 386893777433927680,
  "created_at" : "2013-10-06 16:40:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386872399016108034",
  "text" : "RT @ZachsMind: supporting a political party indirectly supports wherever that party's money came from, which is often hidden or clouded fro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386871723515072514",
    "text" : "supporting a political party indirectly supports wherever that party's money came from, which is often hidden or clouded from public view.",
    "id" : 386871723515072514,
    "created_at" : "2013-10-06 15:13:01 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 386872399016108034,
  "created_at" : "2013-10-06 15:15:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386870878450896897",
  "text" : "RT @DeepakChopra: We have made our world an insane asylum. The choice is to be an inmate or wear a visitors badge. Either way we're in it #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 120, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386870032266821633",
    "text" : "We have made our world an insane asylum. The choice is to be an inmate or wear a visitors badge. Either way we're in it #CosmicConsciousness",
    "id" : 386870032266821633,
    "created_at" : "2013-10-06 15:06:18 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 386870878450896897,
  "created_at" : "2013-10-06 15:09:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386870705008029698",
  "text" : "had a nice day yesterday w friends. didnt get home until midnight. dog had already gone upstairs to bed! lol",
  "id" : 386870705008029698,
  "created_at" : "2013-10-06 15:08:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 72, 84 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Homunculus aka #Hom",
      "screen_name" : "HomunculusLoikm",
      "indices" : [ 85, 101 ],
      "id_str" : "233933230",
      "id" : 233933230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386855661004263424",
  "geo" : { },
  "id_str" : "386869769451757568",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny what a sad site. hurt my aura just reading some of it. : ( @Floridaline @HomunculusLoikm",
  "id" : 386869769451757568,
  "in_reply_to_status_id" : 386855661004263424,
  "created_at" : "2013-10-06 15:05:15 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/BHz5lJjnSx",
      "expanded_url" : "http:\/\/nyti.ms\/178Q3Bs",
      "display_url" : "nyti.ms\/178Q3Bs"
    } ]
  },
  "geo" : { },
  "id_str" : "386867472185311233",
  "text" : "RT @ificouldtellu: Dogs Are People, Too http:\/\/t.co\/BHz5lJjnSx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/BHz5lJjnSx",
        "expanded_url" : "http:\/\/nyti.ms\/178Q3Bs",
        "display_url" : "nyti.ms\/178Q3Bs"
      } ]
    },
    "geo" : { },
    "id_str" : "386857770911145985",
    "text" : "Dogs Are People, Too http:\/\/t.co\/BHz5lJjnSx",
    "id" : 386857770911145985,
    "created_at" : "2013-10-06 14:17:34 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 386867472185311233,
  "created_at" : "2013-10-06 14:56:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386518723101593601",
  "text" : "RT @HoodedMan: We\u2019re fed up with an economic logic that grants wealth to a few while countless others suffer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386515165094481920",
    "text" : "We\u2019re fed up with an economic logic that grants wealth to a few while countless others suffer",
    "id" : 386515165094481920,
    "created_at" : "2013-10-05 15:36:11 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 386518723101593601,
  "created_at" : "2013-10-05 15:50:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386510399710822400",
  "geo" : { },
  "id_str" : "386512234404261888",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 agree! : )",
  "id" : 386512234404261888,
  "in_reply_to_status_id" : 386510399710822400,
  "created_at" : "2013-10-05 15:24:32 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "indices" : [ 3, 13 ],
      "id_str" : "606549103",
      "id" : 606549103
    }, {
      "name" : "CN Bring",
      "screen_name" : "CNBring",
      "indices" : [ 100, 108 ],
      "id_str" : "113706106",
      "id" : 113706106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/uyqMYJaoQb",
      "expanded_url" : "http:\/\/www.e-thriller.com",
      "display_url" : "e-thriller.com"
    } ]
  },
  "geo" : { },
  "id_str" : "386506470264545280",
  "text" : "RT @ethriller: http:\/\/t.co\/uyqMYJaoQb announces its Thrillers Of The Month For Oct, inc The Pact by @CNBring",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CN Bring",
        "screen_name" : "CNBring",
        "indices" : [ 85, 93 ],
        "id_str" : "113706106",
        "id" : 113706106
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/uyqMYJaoQb",
        "expanded_url" : "http:\/\/www.e-thriller.com",
        "display_url" : "e-thriller.com"
      } ]
    },
    "geo" : { },
    "id_str" : "386495565430657024",
    "text" : "http:\/\/t.co\/uyqMYJaoQb announces its Thrillers Of The Month For Oct, inc The Pact by @CNBring",
    "id" : 386495565430657024,
    "created_at" : "2013-10-05 14:18:18 +0000",
    "user" : {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "protected" : false,
      "id_str" : "606549103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2437765921\/ai9fug2o1ypcz1lpcfed_normal.png",
      "id" : 606549103,
      "verified" : false
    }
  },
  "id" : 386506470264545280,
  "created_at" : "2013-10-05 15:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PaxilWithdrawal",
      "screen_name" : "PaxilWithdrawal",
      "indices" : [ 3, 19 ],
      "id_str" : "472334076",
      "id" : 472334076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HjBlN37oyJ",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/10\/04\/us\/dc-shooting-carey-sisters\/index.html?sr=sharebar_twitter",
      "display_url" : "cnn.com\/2013\/10\/04\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386309350434025472",
  "text" : "RT @PaxilWithdrawal: Miriam Carey had recently tapered off her medications. Was she in withdrawal? Perhaps. http:\/\/t.co\/HjBlN37oyJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/HjBlN37oyJ",
        "expanded_url" : "http:\/\/www.cnn.com\/2013\/10\/04\/us\/dc-shooting-carey-sisters\/index.html?sr=sharebar_twitter",
        "display_url" : "cnn.com\/2013\/10\/04\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "386306431416164352",
    "text" : "Miriam Carey had recently tapered off her medications. Was she in withdrawal? Perhaps. http:\/\/t.co\/HjBlN37oyJ",
    "id" : 386306431416164352,
    "created_at" : "2013-10-05 01:46:45 +0000",
    "user" : {
      "name" : "PaxilWithdrawal",
      "screen_name" : "PaxilWithdrawal",
      "protected" : false,
      "id_str" : "472334076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2873847089\/c2907c08ac13c4cd202d51fd37773a65_normal.png",
      "id" : 472334076,
      "verified" : false
    }
  },
  "id" : 386309350434025472,
  "created_at" : "2013-10-05 01:58:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386300757848621056",
  "text" : "RT @johnnyteabag: Exploring the possibilities is much more important the deciding on which one is you think is the truth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385930935465943040",
    "text" : "Exploring the possibilities is much more important the deciding on which one is you think is the truth",
    "id" : 385930935465943040,
    "created_at" : "2013-10-04 00:54:39 +0000",
    "user" : {
      "name" : "j o h n n y i s m",
      "screen_name" : "appleskeed",
      "protected" : false,
      "id_str" : "231288312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797035133563846657\/wm7WuZEx_normal.jpg",
      "id" : 231288312,
      "verified" : false
    }
  },
  "id" : 386300757848621056,
  "created_at" : "2013-10-05 01:24:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386297160608002048",
  "text" : "RT @ZachsMind: it is impossible for a human being to perceive ACTUAL reality, cuz the very shell we call \"self\" is in the way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386295621289644032",
    "text" : "it is impossible for a human being to perceive ACTUAL reality, cuz the very shell we call \"self\" is in the way.",
    "id" : 386295621289644032,
    "created_at" : "2013-10-05 01:03:47 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 386297160608002048,
  "created_at" : "2013-10-05 01:09:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386293702207217664",
  "text" : "@1stCitizenKane you made the world a bit brighter : )",
  "id" : 386293702207217664,
  "created_at" : "2013-10-05 00:56:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 27, 42 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386290239146569728",
  "geo" : { },
  "id_str" : "386293329279090688",
  "in_reply_to_user_id" : 231288312,
  "text" : "@johnnyteabag what's that? @1stCitizenKane",
  "id" : 386293329279090688,
  "in_reply_to_status_id" : 386290239146569728,
  "created_at" : "2013-10-05 00:54:41 +0000",
  "in_reply_to_screen_name" : "appleskeed",
  "in_reply_to_user_id_str" : "231288312",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail US",
      "screen_name" : "DailyMailUS",
      "indices" : [ 125, 137 ],
      "id_str" : "2744812164",
      "id" : 2744812164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/6BUbH6ty1f",
      "expanded_url" : "http:\/\/dailym.ai\/1c7swYk",
      "display_url" : "dailym.ai\/1c7swYk"
    } ]
  },
  "geo" : { },
  "id_str" : "386268727819264000",
  "text" : "Raccoon survives a month at sea on board a ship from Canada to Britain by eating cardboard and... http:\/\/t.co\/6BUbH6ty1f via @DailyMailUS",
  "id" : 386268727819264000,
  "created_at" : "2013-10-04 23:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justwondering",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386238485088051200",
  "text" : "RT @CoyoteSings: Is the government still broke down? Has anyone called a tow truck? #justwondering",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justwondering",
        "indices" : [ 67, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386234060344795136",
    "text" : "Is the government still broke down? Has anyone called a tow truck? #justwondering",
    "id" : 386234060344795136,
    "created_at" : "2013-10-04 20:59:10 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 386238485088051200,
  "created_at" : "2013-10-04 21:16:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EvillySexyBitch\/status\/301794750497964032\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/XQ7RCbZh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDAwugLCQAAI69x.jpg",
      "id_str" : "301794750502158336",
      "id" : 301794750502158336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDAwugLCQAAI69x.jpg",
      "sizes" : [ {
        "h" : 144,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 144,
        "resize" : "crop",
        "w" : 144
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 180
      } ],
      "display_url" : "pic.twitter.com\/XQ7RCbZh"
    } ],
    "hashtags" : [ {
      "text" : "BREAKING",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386237733313597441",
  "text" : "RT @YourAnonNews: #BREAKING - First look at the new flag of The United States of America |  http:\/\/t.co\/XQ7RCbZh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EvillySexyBitch\/status\/301794750497964032\/photo\/1",
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/XQ7RCbZh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDAwugLCQAAI69x.jpg",
        "id_str" : "301794750502158336",
        "id" : 301794750502158336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDAwugLCQAAI69x.jpg",
        "sizes" : [ {
          "h" : 144,
          "resize" : "fit",
          "w" : 180
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 180
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 180
        }, {
          "h" : 144,
          "resize" : "crop",
          "w" : 144
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 180
        } ],
        "display_url" : "pic.twitter.com\/XQ7RCbZh"
      } ],
      "hashtags" : [ {
        "text" : "BREAKING",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301796492828635136",
    "text" : "#BREAKING - First look at the new flag of The United States of America |  http:\/\/t.co\/XQ7RCbZh",
    "id" : 301796492828635136,
    "created_at" : "2013-02-13 20:54:25 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787519608794157057\/dDnFKms0_normal.jpg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 386237733313597441,
  "created_at" : "2013-10-04 21:13:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386157015245942784",
  "text" : "@1stCitizenKane nice! lol",
  "id" : 386157015245942784,
  "created_at" : "2013-10-04 15:53:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NY",
      "indices" : [ 92, 95 ]
    }, {
      "text" : "ACA",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386156619198763008",
  "text" : "i dont have ms excel 2010. i have excel 2007 (not registered.) premium estimator wont work. #NY #ACA",
  "id" : 386156619198763008,
  "created_at" : "2013-10-04 15:51:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigGovt",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "Cspanchat",
      "indices" : [ 79, 89 ]
    }, {
      "text" : "tcot",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386151693412364289",
  "text" : "RT @PeggySueCusses: We gave 37 billion away in foreign aid this year. #BigGovt #Cspanchat #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigGovt",
        "indices" : [ 50, 58 ]
      }, {
        "text" : "Cspanchat",
        "indices" : [ 59, 69 ]
      }, {
        "text" : "tcot",
        "indices" : [ 70, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386149733510545408",
    "text" : "We gave 37 billion away in foreign aid this year. #BigGovt #Cspanchat #tcot",
    "id" : 386149733510545408,
    "created_at" : "2013-10-04 15:24:05 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 386151693412364289,
  "created_at" : "2013-10-04 15:31:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386149733510545408",
  "geo" : { },
  "id_str" : "386150227217883136",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses that could have been spent here.. like for creating jobs.. or healthcare!",
  "id" : 386150227217883136,
  "in_reply_to_status_id" : 386149733510545408,
  "created_at" : "2013-10-04 15:26:03 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 0, 14 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386142480267100160",
  "geo" : { },
  "id_str" : "386144285336141824",
  "in_reply_to_user_id" : 260028159,
  "text" : "@LilMissCoyote heehee",
  "id" : 386144285336141824,
  "in_reply_to_status_id" : 386142480267100160,
  "created_at" : "2013-10-04 15:02:26 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386141977017724928",
  "text" : "i use words and labels to describe myself but not define myself (and others.)",
  "id" : 386141977017724928,
  "created_at" : "2013-10-04 14:53:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386138724892811264",
  "geo" : { },
  "id_str" : "386139265609895936",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i saw some of their comments. they could have disagreed and moved on.",
  "id" : 386139265609895936,
  "in_reply_to_status_id" : 386138724892811264,
  "created_at" : "2013-10-04 14:42:29 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386135450915573761",
  "geo" : { },
  "id_str" : "386138305986711552",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses although, you scared me anyway cuz you're so opinionated.. but there's something about you..lol",
  "id" : 386138305986711552,
  "in_reply_to_status_id" : 386135450915573761,
  "created_at" : "2013-10-04 14:38:40 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386135450915573761",
  "geo" : { },
  "id_str" : "386137481344589825",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i might not have followed you if you had that name then. it would have scared me off..lol.",
  "id" : 386137481344589825,
  "in_reply_to_status_id" : 386135450915573761,
  "created_at" : "2013-10-04 14:35:24 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/386135897227276290\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/QZlN1FFNlt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVvUjX3CMAATusf.jpg",
      "id_str" : "386135897235664896",
      "id" : 386135897235664896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVvUjX3CMAATusf.jpg",
      "sizes" : [ {
        "h" : 690,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/QZlN1FFNlt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386136187984809984",
  "text" : "RT @atheistlady76: Just. Wow. http:\/\/t.co\/QZlN1FFNlt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/386135897227276290\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/QZlN1FFNlt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVvUjX3CMAATusf.jpg",
        "id_str" : "386135897235664896",
        "id" : 386135897235664896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVvUjX3CMAATusf.jpg",
        "sizes" : [ {
          "h" : 690,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QZlN1FFNlt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386135897227276290",
    "text" : "Just. Wow. http:\/\/t.co\/QZlN1FFNlt",
    "id" : 386135897227276290,
    "created_at" : "2013-10-04 14:29:06 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 386136187984809984,
  "created_at" : "2013-10-04 14:30:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386106471643357184",
  "geo" : { },
  "id_str" : "386115466810228736",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC Have a beautiful day with your hubby : )",
  "id" : 386115466810228736,
  "in_reply_to_status_id" : 386106471643357184,
  "created_at" : "2013-10-04 13:07:55 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385939792959397888",
  "text" : "RT @Master_Synaps: Crazy earth apes use more resources fighting for the resources that could be used to end the need for fighting over reso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385937873586757632",
    "text" : "Crazy earth apes use more resources fighting for the resources that could be used to end the need for fighting over resources",
    "id" : 385937873586757632,
    "created_at" : "2013-10-04 01:22:14 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 385939792959397888,
  "created_at" : "2013-10-04 01:29:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 3, 18 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385931830483890176",
  "text" : "RT @JulianneGarska: To all the people who've been nice to me on twitter over the years, I have very much appreciated you.  Xoxo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385930783032356864",
    "text" : "To all the people who've been nice to me on twitter over the years, I have very much appreciated you.  Xoxo",
    "id" : 385930783032356864,
    "created_at" : "2013-10-04 00:54:03 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 385931830483890176,
  "created_at" : "2013-10-04 00:58:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385930783032356864",
  "geo" : { },
  "id_str" : "385931799177609217",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska ((hugs)) i appreciate you. : )",
  "id" : 385931799177609217,
  "in_reply_to_status_id" : 385930783032356864,
  "created_at" : "2013-10-04 00:58:05 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 0, 9 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385929419233034241",
  "geo" : { },
  "id_str" : "385929685357432832",
  "in_reply_to_user_id" : 38948326,
  "text" : "@Mortenrb sounds like you're having fun! lol : )",
  "id" : 385929685357432832,
  "in_reply_to_status_id" : 385929419233034241,
  "created_at" : "2013-10-04 00:49:41 +0000",
  "in_reply_to_screen_name" : "Mortenrb",
  "in_reply_to_user_id_str" : "38948326",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "peggysmoviereviews",
      "indices" : [ 83, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385927214048354305",
  "geo" : { },
  "id_str" : "385928293695766528",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses huh. i was kinda interested in watching but now i think i'll skip. #peggysmoviereviews : )",
  "id" : 385928293695766528,
  "in_reply_to_status_id" : 385927214048354305,
  "created_at" : "2013-10-04 00:44:10 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPshutdown",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/VQ7DSKuEPc",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/rep-bernie-sanders\/a-single-payer-system-lik_b_4021534.html",
      "display_url" : "huffingtonpost.com\/rep-bernie-san\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385925404097138688",
  "text" : "RT @SenSanders: Health care must be recognized as a right, not a privilege. http:\/\/t.co\/VQ7DSKuEPc #GOPshutdown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPshutdown",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/VQ7DSKuEPc",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/rep-bernie-sanders\/a-single-payer-system-lik_b_4021534.html",
        "display_url" : "huffingtonpost.com\/rep-bernie-san\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385749597550682113",
    "text" : "Health care must be recognized as a right, not a privilege. http:\/\/t.co\/VQ7DSKuEPc #GOPshutdown",
    "id" : 385749597550682113,
    "created_at" : "2013-10-03 12:54:05 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 385925404097138688,
  "created_at" : "2013-10-04 00:32:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385916262506704896",
  "text" : "RT @SangyeH: If you're calling people names, ask yourself if it'd be okay if your child called another child that name. #BeTheChangeUWishTo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeTheChangeUWishToSee",
        "indices" : [ 107, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385915535512190977",
    "text" : "If you're calling people names, ask yourself if it'd be okay if your child called another child that name. #BeTheChangeUWishToSee",
    "id" : 385915535512190977,
    "created_at" : "2013-10-03 23:53:28 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 385916262506704896,
  "created_at" : "2013-10-03 23:56:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385865500384714752",
  "geo" : { },
  "id_str" : "385903373444067328",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses not nice!",
  "id" : 385903373444067328,
  "in_reply_to_status_id" : 385865500384714752,
  "created_at" : "2013-10-03 23:05:08 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeanette Borges",
      "screen_name" : "ourrighttoknow2",
      "indices" : [ 3, 19 ],
      "id_str" : "332340557",
      "id" : 332340557
    }, {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 21, 30 ],
      "id_str" : "309558781",
      "id" : 309558781
    }, {
      "name" : "Heritage Foundation",
      "screen_name" : "Heritage",
      "indices" : [ 31, 40 ],
      "id_str" : "10168082",
      "id" : 10168082
    }, {
      "name" : "\u271E\u2655In God I Trust\u2655\u271E",
      "screen_name" : "InGodIDoTrust",
      "indices" : [ 41, 55 ],
      "id_str" : "74841347",
      "id" : 74841347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/npChl2PcDd",
      "expanded_url" : "http:\/\/healthcarereform.procon.org\/sourcefiles\/1989_assuring_affordable_health_care_for_all_americans.pdf",
      "display_url" : "healthcarereform.procon.org\/sourcefiles\/19\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385886043691438080",
  "text" : "RT @ourrighttoknow2: @KellyRek @Heritage @InGodIDoTrust http:\/\/t.co\/npChl2PcDd that's the original plan in case u want for future reference",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kelly Rek",
        "screen_name" : "KellyRek",
        "indices" : [ 0, 9 ],
        "id_str" : "309558781",
        "id" : 309558781
      }, {
        "name" : "Heritage Foundation",
        "screen_name" : "Heritage",
        "indices" : [ 10, 19 ],
        "id_str" : "10168082",
        "id" : 10168082
      }, {
        "name" : "\u271E\u2655In God I Trust\u2655\u271E",
        "screen_name" : "InGodIDoTrust",
        "indices" : [ 20, 34 ],
        "id_str" : "74841347",
        "id" : 74841347
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/npChl2PcDd",
        "expanded_url" : "http:\/\/healthcarereform.procon.org\/sourcefiles\/1989_assuring_affordable_health_care_for_all_americans.pdf",
        "display_url" : "healthcarereform.procon.org\/sourcefiles\/19\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "385881342816165888",
    "geo" : { },
    "id_str" : "385881833751064577",
    "in_reply_to_user_id" : 309558781,
    "text" : "@KellyRek @Heritage @InGodIDoTrust http:\/\/t.co\/npChl2PcDd that's the original plan in case u want for future reference",
    "id" : 385881833751064577,
    "in_reply_to_status_id" : 385881342816165888,
    "created_at" : "2013-10-03 21:39:33 +0000",
    "in_reply_to_screen_name" : "KellyRek",
    "in_reply_to_user_id_str" : "309558781",
    "user" : {
      "name" : "Jeanette Borges",
      "screen_name" : "ourrighttoknow2",
      "protected" : false,
      "id_str" : "332340557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1695481788\/11.10-republic-lost_300_BookFull_normal.jpg",
      "id" : 332340557,
      "verified" : false
    }
  },
  "id" : 385886043691438080,
  "created_at" : "2013-10-03 21:56:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Davis",
      "screen_name" : "charliearchy",
      "indices" : [ 3, 16 ],
      "id_str" : "55411896",
      "id" : 55411896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385884965365235712",
  "text" : "RT @charliearchy: \"However, the shooter's motives remain unknown,\" comes three paragraphs after \"she did not have a weapon.\" http:\/\/t.co\/0M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/0MXIjlph4k",
        "expanded_url" : "http:\/\/www.nbcwashington.com\/news\/breaking\/US-Capitol-Locked-Down-After-Reports-of-Shots-Fired-226338921.html?_osource=SocialFlowTwt_DCBrand",
        "display_url" : "nbcwashington.com\/news\/breaking\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385877434421100544",
    "text" : "\"However, the shooter's motives remain unknown,\" comes three paragraphs after \"she did not have a weapon.\" http:\/\/t.co\/0MXIjlph4k",
    "id" : 385877434421100544,
    "created_at" : "2013-10-03 21:22:04 +0000",
    "user" : {
      "name" : "Charles Davis",
      "screen_name" : "charliearchy",
      "protected" : false,
      "id_str" : "55411896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766380654158352384\/xkFiOVCP_normal.jpg",
      "id" : 55411896,
      "verified" : true
    }
  },
  "id" : 385884965365235712,
  "created_at" : "2013-10-03 21:51:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385877802844569600",
  "geo" : { },
  "id_str" : "385879444474195968",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ahh.. i was wondering what that was..",
  "id" : 385879444474195968,
  "in_reply_to_status_id" : 385877802844569600,
  "created_at" : "2013-10-03 21:30:03 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385879109483495424",
  "text" : "RT @Buddhaworld: Love never is wasted. Love never hurts. Love always is the best choice. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385878826456449025",
    "text" : "Love never is wasted. Love never hurts. Love always is the best choice. Buddha volko",
    "id" : 385878826456449025,
    "created_at" : "2013-10-03 21:27:36 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 385879109483495424,
  "created_at" : "2013-10-03 21:28:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/qWuQoh8bVW",
      "expanded_url" : "http:\/\/bookwi.se\/new-paperwhite-review\/",
      "display_url" : "bookwi.se\/new-paperwhite\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385878678774611968",
  "text" : "RT @adamrshields: My review of the new Kindle Paperwhite http:\/\/t.co\/qWuQoh8bVW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/qWuQoh8bVW",
        "expanded_url" : "http:\/\/bookwi.se\/new-paperwhite-review\/",
        "display_url" : "bookwi.se\/new-paperwhite\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385877265361674240",
    "text" : "My review of the new Kindle Paperwhite http:\/\/t.co\/qWuQoh8bVW",
    "id" : 385877265361674240,
    "created_at" : "2013-10-03 21:21:23 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 385878678774611968,
  "created_at" : "2013-10-03 21:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385873208383004672",
  "text" : "RT @virtusetveritas: Women are not prey because of what we are wear. Women are not prey because of what we wear. WOMEN ARE NOT PREY.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385871656100446208",
    "text" : "Women are not prey because of what we are wear. Women are not prey because of what we wear. WOMEN ARE NOT PREY.",
    "id" : 385871656100446208,
    "created_at" : "2013-10-03 20:59:06 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 385873208383004672,
  "created_at" : "2013-10-03 21:05:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pressgram",
      "screen_name" : "Pressgram",
      "indices" : [ 4, 14 ],
      "id_str" : "1066032464",
      "id" : 1066032464
    }, {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 41, 51 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 15, 27 ]
    }, {
      "text" : "bloggers",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/4pgC6pAfMX",
      "expanded_url" : "http:\/\/apadv.co\/18TTQ9o",
      "display_url" : "apadv.co\/18TTQ9o"
    } ]
  },
  "in_reply_to_status_id_str" : "385869977020284928",
  "geo" : { },
  "id_str" : "385872004382863360",
  "in_reply_to_user_id" : 15395727,
  "text" : "try @Pressgram #photography #bloggers RT @AppAdvice Instagram Users In The U.S. Will Soon Be Seeing Ads http:\/\/t.co\/4pgC6pAfMX",
  "id" : 385872004382863360,
  "in_reply_to_status_id" : 385869977020284928,
  "created_at" : "2013-10-03 21:00:29 +0000",
  "in_reply_to_screen_name" : "AppAdvice",
  "in_reply_to_user_id_str" : "15395727",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 9, 20 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385870056481366017",
  "geo" : { },
  "id_str" : "385871325652197376",
  "in_reply_to_user_id" : 39331231,
  "text" : "Amen! RT @dhammagirl We're all generally trying to do our best.",
  "id" : 385871325652197376,
  "in_reply_to_status_id" : 385870056481366017,
  "created_at" : "2013-10-03 20:57:47 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385864590820532224",
  "geo" : { },
  "id_str" : "385865148000239616",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses insulting ppl does not help get point across.",
  "id" : 385865148000239616,
  "in_reply_to_status_id" : 385864590820532224,
  "created_at" : "2013-10-03 20:33:14 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "Ron Hughes \u0631\u0648\u0646 \u0647\u064A\u0648\u0632",
      "screen_name" : "wherepond",
      "indices" : [ 18, 28 ],
      "id_str" : "703136774",
      "id" : 703136774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/UD6EsoYSCE",
      "expanded_url" : "http:\/\/rt.com\/usa\/pentagon-shutdown-billions-spent-699\/?utm_source=browser&utm_medium=aplication_chrome&utm_campaign=chrome#.Uk3NrnWjwSc.twitter",
      "display_url" : "rt.com\/usa\/pentagon-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385864696202420225",
  "text" : "RT @Jamiastar: RT @wherepond: Pentagon spent $5.5bn only hours before govt shutdown \u2014 RT USA: http:\/\/t.co\/UD6EsoYSCE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ron Hughes \u0631\u0648\u0646 \u0647\u064A\u0648\u0632",
        "screen_name" : "wherepond",
        "indices" : [ 3, 13 ],
        "id_str" : "703136774",
        "id" : 703136774
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/UD6EsoYSCE",
        "expanded_url" : "http:\/\/rt.com\/usa\/pentagon-shutdown-billions-spent-699\/?utm_source=browser&utm_medium=aplication_chrome&utm_campaign=chrome#.Uk3NrnWjwSc.twitter",
        "display_url" : "rt.com\/usa\/pentagon-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385864247684509696",
    "text" : "RT @wherepond: Pentagon spent $5.5bn only hours before govt shutdown \u2014 RT USA: http:\/\/t.co\/UD6EsoYSCE",
    "id" : 385864247684509696,
    "created_at" : "2013-10-03 20:29:40 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 385864696202420225,
  "created_at" : "2013-10-03 20:31:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Burg",
      "screen_name" : "ComradeBurg",
      "indices" : [ 3, 15 ],
      "id_str" : "239506998",
      "id" : 239506998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CapitolShooting",
      "indices" : [ 49, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385862821432401920",
  "text" : "RT @ComradeBurg: Here's an honest summary of the #CapitolShooting :\n\nReports indicated that something happened. We have no fucking clue on \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CapitolShooting",
        "indices" : [ 32, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385861665343819776",
    "text" : "Here's an honest summary of the #CapitolShooting :\n\nReports indicated that something happened. We have no fucking clue on the details.",
    "id" : 385861665343819776,
    "created_at" : "2013-10-03 20:19:24 +0000",
    "user" : {
      "name" : "Christopher Burg",
      "screen_name" : "ComradeBurg",
      "protected" : false,
      "id_str" : "239506998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540534240819961856\/dESxHbE0_normal.jpeg",
      "id" : 239506998,
      "verified" : false
    }
  },
  "id" : 385862821432401920,
  "created_at" : "2013-10-03 20:24:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 27, 42 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385860788553924608",
  "text" : "plan is working then... RT @1stCitizenKane America has become too paranoid for its own fucking good.",
  "id" : 385860788553924608,
  "created_at" : "2013-10-03 20:15:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385858948311416832",
  "text" : "@1stCitizenKane oops.. zooooom!! lol",
  "id" : 385858948311416832,
  "created_at" : "2013-10-03 20:08:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385858717159157760",
  "text" : "@1stCitizenKane but you dont believe in conspiracies... o-O",
  "id" : 385858717159157760,
  "created_at" : "2013-10-03 20:07:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385844571307245568",
  "geo" : { },
  "id_str" : "385848835676712960",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg i think its cuz of the magnetic poles shifting or something like that. makes everyone crazy.",
  "id" : 385848835676712960,
  "in_reply_to_status_id" : 385844571307245568,
  "created_at" : "2013-10-03 19:28:25 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Positively Joan",
      "screen_name" : "PositivelyJoan",
      "indices" : [ 3, 18 ],
      "id_str" : "124896632",
      "id" : 124896632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopMonsanto",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385848320540684288",
  "text" : "RT @PositivelyJoan: Obamacare, any health insurance costly facade long as underlying disease conditions purposely maintained #StopMonsanto \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopMonsanto",
        "indices" : [ 105, 118 ]
      }, {
        "text" : "NoGMO",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385836997220106240",
    "text" : "Obamacare, any health insurance costly facade long as underlying disease conditions purposely maintained #StopMonsanto Protection Act #NoGMO",
    "id" : 385836997220106240,
    "created_at" : "2013-10-03 18:41:23 +0000",
    "user" : {
      "name" : "Positively Joan",
      "screen_name" : "PositivelyJoan",
      "protected" : false,
      "id_str" : "124896632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766418560121843713\/7OllB_7c_normal.jpg",
      "id" : 124896632,
      "verified" : false
    }
  },
  "id" : 385848320540684288,
  "created_at" : "2013-10-03 19:26:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385847107342442496",
  "geo" : { },
  "id_str" : "385848038444388353",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem true.. im just annoyed w ppl thinking its a simple fix. lots of variables.",
  "id" : 385848038444388353,
  "in_reply_to_status_id" : 385847107342442496,
  "created_at" : "2013-10-03 19:25:15 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385842104225656832",
  "text" : "im really tired of hearing fat ppl should just \"eat less, eat right\"",
  "id" : 385842104225656832,
  "created_at" : "2013-10-03 19:01:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "BioMed Central",
      "screen_name" : "BioMedCentral",
      "indices" : [ 30, 44 ],
      "id_str" : "41561657",
      "id" : 41561657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Melatonin",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/BHJdyjVCXH",
      "expanded_url" : "http:\/\/ow.ly\/psvmR",
      "display_url" : "ow.ly\/psvmR"
    } ]
  },
  "geo" : { },
  "id_str" : "385791497250951169",
  "text" : "RT @AlisynGayle: Awesome! :) \u201C@BioMedCentral: #Melatonin -  could it help fight viral infections? Possibly! http:\/\/t.co\/BHJdyjVCXH #virolog\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BioMed Central",
        "screen_name" : "BioMedCentral",
        "indices" : [ 13, 27 ],
        "id_str" : "41561657",
        "id" : 41561657
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Melatonin",
        "indices" : [ 29, 39 ]
      }, {
        "text" : "virology",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/BHJdyjVCXH",
        "expanded_url" : "http:\/\/ow.ly\/psvmR",
        "display_url" : "ow.ly\/psvmR"
      } ]
    },
    "in_reply_to_status_id_str" : "385759549669777408",
    "geo" : { },
    "id_str" : "385789401848356864",
    "in_reply_to_user_id" : 41561657,
    "text" : "Awesome! :) \u201C@BioMedCentral: #Melatonin -  could it help fight viral infections? Possibly! http:\/\/t.co\/BHJdyjVCXH #virology\u201D",
    "id" : 385789401848356864,
    "in_reply_to_status_id" : 385759549669777408,
    "created_at" : "2013-10-03 15:32:15 +0000",
    "in_reply_to_screen_name" : "BioMedCentral",
    "in_reply_to_user_id_str" : "41561657",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 385791497250951169,
  "created_at" : "2013-10-03 15:40:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaime K",
      "screen_name" : "SavetheKales",
      "indices" : [ 3, 16 ],
      "id_str" : "451800041",
      "id" : 451800041
    }, {
      "name" : "Catskill Sanctuary",
      "screen_name" : "CASanctuary",
      "indices" : [ 91, 103 ],
      "id_str" : "27658173",
      "id" : 27658173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385786630121861122",
  "text" : "RT @SavetheKales: This beautiful horse kept \"kissing\" my hand. So, so lovely and sweet. At @CASanctuary in New York. &lt;3 http:\/\/t.co\/KaNhaTH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Catskill Sanctuary",
        "screen_name" : "CASanctuary",
        "indices" : [ 73, 85 ],
        "id_str" : "27658173",
        "id" : 27658173
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SavetheKales\/status\/385205226921549825\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/KaNhaTHadK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BViGHN9IAAAlk_m.jpg",
        "id_str" : "385205226703421440",
        "id" : 385205226703421440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BViGHN9IAAAlk_m.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KaNhaTHadK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385205226921549825",
    "text" : "This beautiful horse kept \"kissing\" my hand. So, so lovely and sweet. At @CASanctuary in New York. &lt;3 http:\/\/t.co\/KaNhaTHadK",
    "id" : 385205226921549825,
    "created_at" : "2013-10-02 00:50:57 +0000",
    "user" : {
      "name" : "Jaime K",
      "screen_name" : "SavetheKales",
      "protected" : false,
      "id_str" : "451800041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780158015576141824\/PMQ7TKJ5_normal.jpg",
      "id" : 451800041,
      "verified" : false
    }
  },
  "id" : 385786630121861122,
  "created_at" : "2013-10-03 15:21:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 17, 32 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cspanchat",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "tcot",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385782934705152002",
  "geo" : { },
  "id_str" : "385786108937637889",
  "in_reply_to_user_id" : 63804234,
  "text" : "good question RT @PeggySueCusses Why is there medical research going on at the Department of Defense? #cspanchat #tcot",
  "id" : 385786108937637889,
  "in_reply_to_status_id" : 385782934705152002,
  "created_at" : "2013-10-03 15:19:10 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo News",
      "screen_name" : "YahooNews",
      "indices" : [ 53, 63 ],
      "id_str" : "7309052",
      "id" : 7309052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/l0aBLe8M4e",
      "expanded_url" : "http:\/\/news.yahoo.com\/blogs\/sideshow\/magician-rahat-is-back-with-another-drive-through-prank--this-time-with-an-assist-from-a-spooky-halloween-skeleton--175732670.html",
      "display_url" : "news.yahoo.com\/blogs\/sideshow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385775962069012481",
  "text" : "Skeletons get hungry, too http:\/\/t.co\/l0aBLe8M4e via @YahooNews",
  "id" : 385775962069012481,
  "created_at" : "2013-10-03 14:38:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385567638694289408",
  "text" : "RT @Jambodhi: Love is the only sane and satisfactory answer to the problem of human existence.  ~ Eric Fromm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385567147021176833",
    "text" : "Love is the only sane and satisfactory answer to the problem of human existence.  ~ Eric Fromm",
    "id" : 385567147021176833,
    "created_at" : "2013-10-03 00:49:06 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 385567638694289408,
  "created_at" : "2013-10-03 00:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RiPPa",
      "screen_name" : "RippDemUp",
      "indices" : [ 3, 13 ],
      "id_str" : "16254215",
      "id" : 16254215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/MDs09LRukL",
      "expanded_url" : "http:\/\/bit.ly\/1bwlxYB",
      "display_url" : "bit.ly\/1bwlxYB"
    } ]
  },
  "geo" : { },
  "id_str" : "385565068714192897",
  "text" : "RT @RippDemUp: #ICYMI: Librarian Fired for Helping Kid Read Too Much http:\/\/t.co\/MDs09LRukL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/MDs09LRukL",
        "expanded_url" : "http:\/\/bit.ly\/1bwlxYB",
        "display_url" : "bit.ly\/1bwlxYB"
      } ]
    },
    "geo" : { },
    "id_str" : "385562580585967617",
    "text" : "#ICYMI: Librarian Fired for Helping Kid Read Too Much http:\/\/t.co\/MDs09LRukL",
    "id" : 385562580585967617,
    "created_at" : "2013-10-03 00:30:57 +0000",
    "user" : {
      "name" : "RiPPa",
      "screen_name" : "RippDemUp",
      "protected" : false,
      "id_str" : "16254215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3039245373\/0ccbd6180b0c810069fbab633c598950_normal.jpeg",
      "id" : 16254215,
      "verified" : false
    }
  },
  "id" : 385565068714192897,
  "created_at" : "2013-10-03 00:40:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385561744053002240",
  "geo" : { },
  "id_str" : "385563460475424768",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid no,from her view you dont have God's love and thats heartbreaking to her. also, teenage girls=emotional. @ElviraintheLuna",
  "id" : 385563460475424768,
  "in_reply_to_status_id" : 385561744053002240,
  "created_at" : "2013-10-03 00:34:27 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385550526651191296",
  "geo" : { },
  "id_str" : "385553119381164032",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid no, you werent. but i dont see where you think she's arrogant. @ElviraintheLuna",
  "id" : 385553119381164032,
  "in_reply_to_status_id" : 385550526651191296,
  "created_at" : "2013-10-02 23:53:21 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 0, 11 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385550095044730882",
  "geo" : { },
  "id_str" : "385552473697419265",
  "in_reply_to_user_id" : 187357122,
  "text" : "@Wolf_Mommy ick! maybe something you ate? or weird quick virus.",
  "id" : 385552473697419265,
  "in_reply_to_status_id" : 385550095044730882,
  "created_at" : "2013-10-02 23:50:47 +0000",
  "in_reply_to_screen_name" : "Wolf_Mommy",
  "in_reply_to_user_id_str" : "187357122",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J",
      "screen_name" : "pueblokc",
      "indices" : [ 3, 12 ],
      "id_str" : "1460971",
      "id" : 1460971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385550343167160320",
  "text" : "RT @pueblokc: The USA summed up: no money for citizens health or education. Endless money for war. No money to run anything but war.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385546999312834560",
    "text" : "The USA summed up: no money for citizens health or education. Endless money for war. No money to run anything but war.",
    "id" : 385546999312834560,
    "created_at" : "2013-10-02 23:29:02 +0000",
    "user" : {
      "name" : "J",
      "screen_name" : "pueblokc",
      "protected" : false,
      "id_str" : "1460971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/283001621\/kc_sparkler_small_normal.jpg",
      "id" : 1460971,
      "verified" : false
    }
  },
  "id" : 385550343167160320,
  "created_at" : "2013-10-02 23:42:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385544933735559169",
  "geo" : { },
  "id_str" : "385546426597400577",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid give her some slack. she's only 17. @ElviraintheLuna",
  "id" : 385546426597400577,
  "in_reply_to_status_id" : 385544933735559169,
  "created_at" : "2013-10-02 23:26:45 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "GreedyBastards",
      "indices" : [ 61, 76 ]
    }, {
      "text" : "insurance",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385543217875152896",
  "text" : "RT @KellyRek: #ObamaCare mandates that we pay money unto the #GreedyBastards of the #insurance cartel ~~&gt; Let's eliminate the middlemen !!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "GreedyBastards",
        "indices" : [ 47, 62 ]
      }, {
        "text" : "insurance",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385541545564205057",
    "text" : "#ObamaCare mandates that we pay money unto the #GreedyBastards of the #insurance cartel ~~&gt; Let's eliminate the middlemen !!",
    "id" : 385541545564205057,
    "created_at" : "2013-10-02 23:07:22 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 385543217875152896,
  "created_at" : "2013-10-02 23:14:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385522231922532352",
  "text" : "@1stCitizenKane hmm.. no. if they were open-minded, they could leave cult. they are insecure and seek a closed system.",
  "id" : 385522231922532352,
  "created_at" : "2013-10-02 21:50:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385521205089804288",
  "text" : "@1stCitizenKane open-minded means flexible thinking.. open to considering new ideas\/concepts.",
  "id" : 385521205089804288,
  "created_at" : "2013-10-02 21:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Tenny",
      "screen_name" : "pwtenny",
      "indices" : [ 3, 11 ],
      "id_str" : "14129584",
      "id" : 14129584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385517950939054080",
  "text" : "RT @pwtenny: I think public-funded sports stadiums should close during a gov shutdown. See how long it lasts then.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385219769911087105",
    "text" : "I think public-funded sports stadiums should close during a gov shutdown. See how long it lasts then.",
    "id" : 385219769911087105,
    "created_at" : "2013-10-02 01:48:44 +0000",
    "user" : {
      "name" : "Paul Tenny",
      "screen_name" : "pwtenny",
      "protected" : false,
      "id_str" : "14129584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668122136410759172\/MoIiWtml_normal.jpg",
      "id" : 14129584,
      "verified" : false
    }
  },
  "id" : 385517950939054080,
  "created_at" : "2013-10-02 21:33:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cataclysmic Catalyst",
      "screen_name" : "tastypaper",
      "indices" : [ 0, 11 ],
      "id_str" : "26947798",
      "id" : 26947798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385515172988981248",
  "geo" : { },
  "id_str" : "385516420533989376",
  "in_reply_to_user_id" : 26947798,
  "text" : "@tastypaper true!",
  "id" : 385516420533989376,
  "in_reply_to_status_id" : 385515172988981248,
  "created_at" : "2013-10-02 21:27:31 +0000",
  "in_reply_to_screen_name" : "tastypaper",
  "in_reply_to_user_id_str" : "26947798",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385514922165030912",
  "text" : "RT @micahjmurray: Obamacare forces those with specific religous beliefs to pay for things they don't believe in? I don't \"believe in\" war b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385513677664698369",
    "text" : "Obamacare forces those with specific religous beliefs to pay for things they don't believe in? I don't \"believe in\" war but I pay taxes.",
    "id" : 385513677664698369,
    "created_at" : "2013-10-02 21:16:37 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 385514922165030912,
  "created_at" : "2013-10-02 21:21:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "indices" : [ 3, 12 ],
      "id_str" : "309558781",
      "id" : 309558781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insurance",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "insurance",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385514309624664064",
  "text" : "RT @KellyRek: It is immoral for #insurance to be the ticket for access to see a doctor ~~&gt; Let us eliminate the #insurance middleman.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insurance",
        "indices" : [ 18, 28 ]
      }, {
        "text" : "insurance",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385511718220095490",
    "text" : "It is immoral for #insurance to be the ticket for access to see a doctor ~~&gt; Let us eliminate the #insurance middleman.",
    "id" : 385511718220095490,
    "created_at" : "2013-10-02 21:08:50 +0000",
    "user" : {
      "name" : "Kelly Rek",
      "screen_name" : "KellyRek",
      "protected" : false,
      "id_str" : "309558781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414434451\/Revised_Icon_normal.jpg",
      "id" : 309558781,
      "verified" : false
    }
  },
  "id" : 385514309624664064,
  "created_at" : "2013-10-02 21:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indamnable",
      "screen_name" : "youredamned",
      "indices" : [ 3, 15 ],
      "id_str" : "474535964",
      "id" : 474535964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385514239567228932",
  "text" : "RT @youredamned: If Satan is constantly attempting to trick us, then is it possible that he was the actual inspiration for the Bible? #athe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheism",
        "indices" : [ 117, 125 ]
      }, {
        "text" : "atheist",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385503490019442688",
    "text" : "If Satan is constantly attempting to trick us, then is it possible that he was the actual inspiration for the Bible? #atheism #atheist",
    "id" : 385503490019442688,
    "created_at" : "2013-10-02 20:36:08 +0000",
    "user" : {
      "name" : "Indamnable",
      "screen_name" : "youredamned",
      "protected" : false,
      "id_str" : "474535964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000697339259\/236520bb022c49aaf36996d887005392_normal.png",
      "id" : 474535964,
      "verified" : false
    }
  },
  "id" : 385514239567228932,
  "created_at" : "2013-10-02 21:18:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer",
      "screen_name" : "HiJCP",
      "indices" : [ 3, 9 ],
      "id_str" : "134019092",
      "id" : 134019092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385513030101921792",
  "text" : "RT @HiJCP: The universe conspires to bring joy to me every day in the most unlikely of places through strangers. I love that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385501343500079104",
    "text" : "The universe conspires to bring joy to me every day in the most unlikely of places through strangers. I love that.",
    "id" : 385501343500079104,
    "created_at" : "2013-10-02 20:27:37 +0000",
    "user" : {
      "name" : "Jennifer",
      "screen_name" : "HiJCP",
      "protected" : false,
      "id_str" : "134019092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2007192867\/1_normal.jpg",
      "id" : 134019092,
      "verified" : false
    }
  },
  "id" : 385513030101921792,
  "created_at" : "2013-10-02 21:14:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Eddy",
      "screen_name" : "MrScottEddy",
      "indices" : [ 0, 12 ],
      "id_str" : "22411342",
      "id" : 22411342
    }, {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 28, 40 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385504382760288256",
  "geo" : { },
  "id_str" : "385506444218335233",
  "in_reply_to_user_id" : 22411342,
  "text" : "@MrScottEddy love this! : ) @oceanshaman",
  "id" : 385506444218335233,
  "in_reply_to_status_id" : 385504382760288256,
  "created_at" : "2013-10-02 20:47:53 +0000",
  "in_reply_to_screen_name" : "MrScottEddy",
  "in_reply_to_user_id_str" : "22411342",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Eddy",
      "screen_name" : "MrScottEddy",
      "indices" : [ 3, 15 ],
      "id_str" : "22411342",
      "id" : 22411342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385506354716106753",
  "text" : "RT @MrScottEddy: Twitter is kinda like having a group hug that you can pull out of your pocket at anytime.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385504382760288256",
    "text" : "Twitter is kinda like having a group hug that you can pull out of your pocket at anytime.",
    "id" : 385504382760288256,
    "created_at" : "2013-10-02 20:39:41 +0000",
    "user" : {
      "name" : "Scott Eddy",
      "screen_name" : "MrScottEddy",
      "protected" : false,
      "id_str" : "22411342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690990247270707200\/nKjuJoAr_normal.jpg",
      "id" : 22411342,
      "verified" : true
    }
  },
  "id" : 385506354716106753,
  "created_at" : "2013-10-02 20:47:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neliza Drew",
      "screen_name" : "nelizadrew",
      "indices" : [ 3, 14 ],
      "id_str" : "93519948",
      "id" : 93519948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385500500268810240",
  "text" : "RT @nelizadrew: It's the kind of day that calls for lots of fluffy, purring cats.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385497433544736768",
    "text" : "It's the kind of day that calls for lots of fluffy, purring cats.",
    "id" : 385497433544736768,
    "created_at" : "2013-10-02 20:12:05 +0000",
    "user" : {
      "name" : "Neliza Drew",
      "screen_name" : "nelizadrew",
      "protected" : false,
      "id_str" : "93519948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682239807368654848\/j53l9fHZ_normal.jpg",
      "id" : 93519948,
      "verified" : false
    }
  },
  "id" : 385500500268810240,
  "created_at" : "2013-10-02 20:24:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385500031291113472",
  "text" : "RT @TheGoldenMirror: True victory lies not in overpowering others. It lies in conquering yourself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385499230154272768",
    "text" : "True victory lies not in overpowering others. It lies in conquering yourself.",
    "id" : 385499230154272768,
    "created_at" : "2013-10-02 20:19:13 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 385500031291113472,
  "created_at" : "2013-10-02 20:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385499772640960512",
  "text" : "bipartisan? no such thing.",
  "id" : 385499772640960512,
  "created_at" : "2013-10-02 20:21:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fascinating Pictures",
      "screen_name" : "Fascinatingpics",
      "indices" : [ 3, 19 ],
      "id_str" : "978908012",
      "id" : 978908012
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Fascinatingpics\/status\/385497495192993792\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/dNAkV7jvig",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVmP7eLIEAAaxvV.jpg",
      "id_str" : "385497494991671296",
      "id" : 385497494991671296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVmP7eLIEAAaxvV.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/dNAkV7jvig"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385498094403481600",
  "text" : "RT @Fascinatingpics: Invisibility Cloak has been made!! http:\/\/t.co\/dNAkV7jvig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fascinatingpics\/status\/385497495192993792\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/dNAkV7jvig",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVmP7eLIEAAaxvV.jpg",
        "id_str" : "385497494991671296",
        "id" : 385497494991671296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVmP7eLIEAAaxvV.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/dNAkV7jvig"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385497495192993792",
    "text" : "Invisibility Cloak has been made!! http:\/\/t.co\/dNAkV7jvig",
    "id" : 385497495192993792,
    "created_at" : "2013-10-02 20:12:19 +0000",
    "user" : {
      "name" : "Fascinating Pictures",
      "screen_name" : "Fascinatingpics",
      "protected" : false,
      "id_str" : "978908012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425946167050911744\/x62a9eBz_normal.jpeg",
      "id" : 978908012,
      "verified" : false
    }
  },
  "id" : 385498094403481600,
  "created_at" : "2013-10-02 20:14:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 0, 16 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385488565343223808",
  "geo" : { },
  "id_str" : "385492214354149377",
  "in_reply_to_user_id" : 189759304,
  "text" : "@virtusetveritas inherently sinful never jibed with me",
  "id" : 385492214354149377,
  "in_reply_to_status_id" : 385488565343223808,
  "created_at" : "2013-10-02 19:51:20 +0000",
  "in_reply_to_screen_name" : "samanthapfield",
  "in_reply_to_user_id_str" : "189759304",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385487056132005888",
  "text" : "@1stCitizenKane why not?",
  "id" : 385487056132005888,
  "created_at" : "2013-10-02 19:30:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385479248729112576",
  "geo" : { },
  "id_str" : "385483763141967872",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld Amen! : )",
  "id" : 385483763141967872,
  "in_reply_to_status_id" : 385479248729112576,
  "created_at" : "2013-10-02 19:17:45 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385483708867686400",
  "text" : "RT @Buddhaworld: Freedom starts in the head. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385479248729112576",
    "text" : "Freedom starts in the head. Buddha volko",
    "id" : 385479248729112576,
    "created_at" : "2013-10-02 18:59:49 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 385483708867686400,
  "created_at" : "2013-10-02 19:17:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/lzvEkBycnV",
      "expanded_url" : "http:\/\/thenewcivilrightsmovement.com\/look-father-disowns-daughter-for-disowning-her-gay-son\/news\/2013\/10\/02\/76144",
      "display_url" : "thenewcivilrightsmovement.com\/look-father-di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385483154653343744",
  "text" : "RT @atheistlady76: Look: Father Disowns Daughter For Disowning Her Gay Son: http:\/\/t.co\/lzvEkBycnV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/lzvEkBycnV",
        "expanded_url" : "http:\/\/thenewcivilrightsmovement.com\/look-father-disowns-daughter-for-disowning-her-gay-son\/news\/2013\/10\/02\/76144",
        "display_url" : "thenewcivilrightsmovement.com\/look-father-di\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385481571412627456",
    "text" : "Look: Father Disowns Daughter For Disowning Her Gay Son: http:\/\/t.co\/lzvEkBycnV",
    "id" : 385481571412627456,
    "created_at" : "2013-10-02 19:09:03 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 385483154653343744,
  "created_at" : "2013-10-02 19:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ActorBuster",
      "screen_name" : "ActorBuster",
      "indices" : [ 3, 15 ],
      "id_str" : "2588026416",
      "id" : 2588026416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385482524274618368",
  "text" : "RT @ActorBuster: Just checking in. What's going on? Are we still screwed?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385482402581069824",
    "text" : "Just checking in. What's going on? Are we still screwed?",
    "id" : 385482402581069824,
    "created_at" : "2013-10-02 19:12:21 +0000",
    "user" : {
      "name" : "We R Gonna Fix This",
      "screen_name" : "wtb6chiny",
      "protected" : false,
      "id_str" : "204947822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787487931212718080\/lpOT5NLK_normal.jpg",
      "id" : 204947822,
      "verified" : false
    }
  },
  "id" : 385482524274618368,
  "created_at" : "2013-10-02 19:12:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 3, 19 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385473873359015936",
  "text" : "RT @AlterEgoTrip_se: It bothers me school has become \"mandatory\" that they capture youth &amp; force them \"learn\" what they are teaching. Mised\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385473408558841856",
    "text" : "It bothers me school has become \"mandatory\" that they capture youth &amp; force them \"learn\" what they are teaching. Miseducation is betrayal.",
    "id" : 385473408558841856,
    "created_at" : "2013-10-02 18:36:37 +0000",
    "user" : {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "protected" : false,
      "id_str" : "344209049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779194958410579968\/qUDtmyLs_normal.jpg",
      "id" : 344209049,
      "verified" : false
    }
  },
  "id" : 385473873359015936,
  "created_at" : "2013-10-02 18:38:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "indices" : [ 3, 17 ],
      "id_str" : "30038832",
      "id" : 30038832
    }, {
      "name" : "GLK",
      "screen_name" : "njlitigator",
      "indices" : [ 22, 34 ],
      "id_str" : "167467927",
      "id" : 167467927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385445617889058816",
  "text" : "RT @LilithsPriest: RT @njlitigator \"Has anybody tried unplugging Congress and then plugging it back in??\" 2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GLK",
        "screen_name" : "njlitigator",
        "indices" : [ 3, 15 ],
        "id_str" : "167467927",
        "id" : 167467927
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385445453179125760",
    "text" : "RT @njlitigator \"Has anybody tried unplugging Congress and then plugging it back in??\" 2014",
    "id" : 385445453179125760,
    "created_at" : "2013-10-02 16:45:31 +0000",
    "user" : {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "protected" : false,
      "id_str" : "30038832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684842001372594176\/nMbJUZ5Q_normal.jpg",
      "id" : 30038832,
      "verified" : false
    }
  },
  "id" : 385445617889058816,
  "created_at" : "2013-10-02 16:46:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlin Dennis",
      "screen_name" : "carlin_dennis",
      "indices" : [ 3, 17 ],
      "id_str" : "409902617",
      "id" : 409902617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385444062670503938",
  "text" : "RT @carlin_dennis: I thought he was supposed to be getting ready to hibernate. Instead he wants what I got on the BBQ. Should I feed him ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/carlin_dennis\/status\/385442061312208896\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zLDiw2StCk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVldgzpCMAAng2F.jpg",
        "id_str" : "385442061316403200",
        "id" : 385442061316403200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVldgzpCMAAng2F.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zLDiw2StCk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385442061312208896",
    "text" : "I thought he was supposed to be getting ready to hibernate. Instead he wants what I got on the BBQ. Should I feed him http:\/\/t.co\/zLDiw2StCk",
    "id" : 385442061312208896,
    "created_at" : "2013-10-02 16:32:03 +0000",
    "user" : {
      "name" : "Carlin Dennis",
      "screen_name" : "carlin_dennis",
      "protected" : false,
      "id_str" : "409902617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2875483008\/69488765b91e259089f0ea39eded5337_normal.jpeg",
      "id" : 409902617,
      "verified" : false
    }
  },
  "id" : 385444062670503938,
  "created_at" : "2013-10-02 16:40:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Stettner",
      "screen_name" : "USHealthcare",
      "indices" : [ 3, 16 ],
      "id_str" : "26290259",
      "id" : 26290259
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 18, 24 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385442162281684992",
  "text" : "RT @USHealthcare: @msnbc The real issue is healthcare and the budget. Single Payer Medicare for All,.One plan, just implementation, no exch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 0, 6 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385429768541179904",
    "in_reply_to_user_id" : 2836421,
    "text" : "@msnbc The real issue is healthcare and the budget. Single Payer Medicare for All,.One plan, just implementation, no exchanges. The savings!",
    "id" : 385429768541179904,
    "created_at" : "2013-10-02 15:43:12 +0000",
    "in_reply_to_screen_name" : "MSNBC",
    "in_reply_to_user_id_str" : "2836421",
    "user" : {
      "name" : "Les Stettner",
      "screen_name" : "USHealthcare",
      "protected" : false,
      "id_str" : "26290259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2339687609\/j7ptn2gv995omx09qdaw_normal.jpeg",
      "id" : 26290259,
      "verified" : false
    }
  },
  "id" : 385442162281684992,
  "created_at" : "2013-10-02 16:32:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    }, {
      "name" : "Ro Khanna",
      "screen_name" : "RoKhannaUSA",
      "indices" : [ 94, 106 ],
      "id_str" : "771152516",
      "id" : 771152516
    }, {
      "name" : "Lynda Upthegrove",
      "screen_name" : "LUpthegrove",
      "indices" : [ 107, 119 ],
      "id_str" : "158023332",
      "id" : 158023332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385439634278215680",
  "text" : "RT @Adenovir: How about we make a govt shutdown trigger new elections like they do in Canada. @RoKhannaUSA @LUpthegrove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ro Khanna",
        "screen_name" : "RoKhannaUSA",
        "indices" : [ 80, 92 ],
        "id_str" : "771152516",
        "id" : 771152516
      }, {
        "name" : "Lynda Upthegrove",
        "screen_name" : "LUpthegrove",
        "indices" : [ 93, 105 ],
        "id_str" : "158023332",
        "id" : 158023332
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "385432238092857344",
    "geo" : { },
    "id_str" : "385438847750139904",
    "in_reply_to_user_id" : 771152516,
    "text" : "How about we make a govt shutdown trigger new elections like they do in Canada. @RoKhannaUSA @LUpthegrove",
    "id" : 385438847750139904,
    "in_reply_to_status_id" : 385432238092857344,
    "created_at" : "2013-10-02 16:19:17 +0000",
    "in_reply_to_screen_name" : "RoKhannaUSA",
    "in_reply_to_user_id_str" : "771152516",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 385439634278215680,
  "created_at" : "2013-10-02 16:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    }, {
      "name" : "Courtney Guertin",
      "screen_name" : "courtstarr",
      "indices" : [ 23, 34 ],
      "id_str" : "6112082",
      "id" : 6112082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ZjC6x4UFqG",
      "expanded_url" : "http:\/\/gizmodo.com\/any-animal-that-touches-this-lethal-lake-turns-to-stone-1436606506",
      "display_url" : "gizmodo.com\/any-animal-tha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385435838873473024",
  "text" : "RT @petersonguides: RT @courtstarr: Crazy! Any animal that touches this lethal lake turns to stone. Great photos. http:\/\/t.co\/ZjC6x4UFqG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Courtney Guertin",
        "screen_name" : "courtstarr",
        "indices" : [ 3, 14 ],
        "id_str" : "6112082",
        "id" : 6112082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ZjC6x4UFqG",
        "expanded_url" : "http:\/\/gizmodo.com\/any-animal-that-touches-this-lethal-lake-turns-to-stone-1436606506",
        "display_url" : "gizmodo.com\/any-animal-tha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385435262911672320",
    "text" : "RT @courtstarr: Crazy! Any animal that touches this lethal lake turns to stone. Great photos. http:\/\/t.co\/ZjC6x4UFqG",
    "id" : 385435262911672320,
    "created_at" : "2013-10-02 16:05:02 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 385435838873473024,
  "created_at" : "2013-10-02 16:07:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385435269115023361",
  "text" : "pulled in so many different directions. so many voices...",
  "id" : 385435269115023361,
  "created_at" : "2013-10-02 16:05:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385434321428819968",
  "text" : "@1stCitizenKane that's deep...",
  "id" : 385434321428819968,
  "created_at" : "2013-10-02 16:01:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385176701912641536",
  "geo" : { },
  "id_str" : "385407598045851648",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses yay! give him a big hug from me..lol",
  "id" : 385407598045851648,
  "in_reply_to_status_id" : 385176701912641536,
  "created_at" : "2013-10-02 14:15:06 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "irene haralabatos",
      "screen_name" : "rini6",
      "indices" : [ 3, 9 ],
      "id_str" : "23386530",
      "id" : 23386530
    }, {
      "name" : "All In w\/Chris Hayes",
      "screen_name" : "allinwithchris",
      "indices" : [ 110, 125 ],
      "id_str" : "1286312880",
      "id" : 1286312880
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inners",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385208078712700928",
  "text" : "RT @rini6: We have an entire office just to fight for reimbursement now. What we need is single payer #inners @allinwithchris",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "All In w\/Chris Hayes",
        "screen_name" : "allinwithchris",
        "indices" : [ 99, 114 ],
        "id_str" : "1286312880",
        "id" : 1286312880
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inners",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385203439472357376",
    "text" : "We have an entire office just to fight for reimbursement now. What we need is single payer #inners @allinwithchris",
    "id" : 385203439472357376,
    "created_at" : "2013-10-02 00:43:51 +0000",
    "user" : {
      "name" : "irene haralabatos",
      "screen_name" : "rini6",
      "protected" : false,
      "id_str" : "23386530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747168444404097024\/2g9qj4uC_normal.jpg",
      "id" : 23386530,
      "verified" : false
    }
  },
  "id" : 385208078712700928,
  "created_at" : "2013-10-02 01:02:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385205484564656129",
  "geo" : { },
  "id_str" : "385207954628415488",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 lol.. sweet! : )",
  "id" : 385207954628415488,
  "in_reply_to_status_id" : 385205484564656129,
  "created_at" : "2013-10-02 01:01:47 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmonic Institute",
      "screen_name" : "caebling",
      "indices" : [ 3, 12 ],
      "id_str" : "22560761",
      "id" : 22560761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Clt0comthl",
      "expanded_url" : "http:\/\/huff.to\/18M8g9x",
      "display_url" : "huff.to\/18M8g9x"
    } ]
  },
  "geo" : { },
  "id_str" : "385200586297462785",
  "text" : "RT @caebling: Drug addition is a public health problem, not a criminal one. Study Proves The War On Drugs Is Failing http:\/\/t.co\/Clt0comthl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Clt0comthl",
        "expanded_url" : "http:\/\/huff.to\/18M8g9x",
        "display_url" : "huff.to\/18M8g9x"
      } ]
    },
    "geo" : { },
    "id_str" : "385197998046605312",
    "text" : "Drug addition is a public health problem, not a criminal one. Study Proves The War On Drugs Is Failing http:\/\/t.co\/Clt0comthl",
    "id" : 385197998046605312,
    "created_at" : "2013-10-02 00:22:14 +0000",
    "user" : {
      "name" : "Gizmonic Institute",
      "screen_name" : "caebling",
      "protected" : false,
      "id_str" : "22560761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667414951036776448\/xKiTAmPo_normal.jpg",
      "id" : 22560761,
      "verified" : false
    }
  },
  "id" : 385200586297462785,
  "created_at" : "2013-10-02 00:32:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385161530037116928",
  "geo" : { },
  "id_str" : "385163855220838400",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses crap! i was wondering how he was doing lately. hopefully he just wandered...",
  "id" : 385163855220838400,
  "in_reply_to_status_id" : 385161530037116928,
  "created_at" : "2013-10-01 22:06:33 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chanukah",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/uomGKmHVUc",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/09\/30\/1242615\/-No-menorahs-at-Hobby-Lobby#",
      "display_url" : "dailykos.com\/story\/2013\/09\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385161996661821440",
  "text" : "RT @Adenovir: No Menorahs at Hobby Lobby. \"We don't cater to you people\" http:\/\/t.co\/uomGKmHVUc #Chanukah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chanukah",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/uomGKmHVUc",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/09\/30\/1242615\/-No-menorahs-at-Hobby-Lobby#",
        "display_url" : "dailykos.com\/story\/2013\/09\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385153818151124992",
    "text" : "No Menorahs at Hobby Lobby. \"We don't cater to you people\" http:\/\/t.co\/uomGKmHVUc #Chanukah",
    "id" : 385153818151124992,
    "created_at" : "2013-10-01 21:26:40 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 385161996661821440,
  "created_at" : "2013-10-01 21:59:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385142426991472642",
  "text" : "RT @PeggySueCusses: Yes we are all acutely aware there is a govt shutdown. Move on already. You won't agree. We won't agree. Let's play Yah\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cspanchat",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385140121848131584",
    "text" : "Yes we are all acutely aware there is a govt shutdown. Move on already. You won't agree. We won't agree. Let's play Yahtzee. #cspanchat",
    "id" : 385140121848131584,
    "created_at" : "2013-10-01 20:32:15 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 385142426991472642,
  "created_at" : "2013-10-01 20:41:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "James Field",
      "screen_name" : "UUJames",
      "indices" : [ 18, 26 ],
      "id_str" : "19199755",
      "id" : 19199755
    }, {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 28, 33 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385138148570697728",
  "text" : "RT @Jamiastar: RT @UUJames: @xeni very medieval how we turn health into a moral issue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Field",
        "screen_name" : "UUJames",
        "indices" : [ 3, 11 ],
        "id_str" : "19199755",
        "id" : 19199755
      }, {
        "name" : "Xeni Jardin",
        "screen_name" : "xeni",
        "indices" : [ 13, 18 ],
        "id_str" : "767",
        "id" : 767
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385137367444500480",
    "text" : "RT @UUJames: @xeni very medieval how we turn health into a moral issue",
    "id" : 385137367444500480,
    "created_at" : "2013-10-01 20:21:18 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 385138148570697728,
  "created_at" : "2013-10-01 20:24:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385133991679893504",
  "geo" : { },
  "id_str" : "385134631902662657",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOLOL",
  "id" : 385134631902662657,
  "in_reply_to_status_id" : 385133991679893504,
  "created_at" : "2013-10-01 20:10:26 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u042F\u0440\u0438\u043B\u0438\u043D \u042F\u0440\u043E\u0441\u043B\u0430\u0432",
      "screen_name" : "cshallwriter",
      "indices" : [ 3, 16 ],
      "id_str" : "2813957569",
      "id" : 2813957569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385030692746190849",
  "text" : "RT @cshallwriter: America was not shut down properly. Would you like to start America in safe mode, with free healthcare and without the gu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384935341318103041",
    "text" : "America was not shut down properly. Would you like to start America in safe mode, with free healthcare and without the guns? (Recommended)",
    "id" : 384935341318103041,
    "created_at" : "2013-10-01 06:58:31 +0000",
    "user" : {
      "name" : "Chris Hall",
      "screen_name" : "ChrisHallBeer",
      "protected" : false,
      "id_str" : "240856746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751910859069353985\/nPv41g___normal.jpg",
      "id" : 240856746,
      "verified" : false
    }
  },
  "id" : 385030692746190849,
  "created_at" : "2013-10-01 13:17:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]