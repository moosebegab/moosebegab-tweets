Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio French",
      "screen_name" : "AntonioFrench",
      "indices" : [ 3, 17 ],
      "id_str" : "14090948",
      "id" : 14090948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671545638560112640",
  "text" : "RT @AntonioFrench: Please read this. We need more understanding &amp; empathy and a lot less hate &amp; fear. Thanks for posting this, Leah. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AntonioFrench\/status\/671530371167739904\/photo\/1",
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/6We9pcSNdH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVHBTuwUsAIm9wZ.jpg",
        "id_str" : "671530364167303170",
        "id" : 671530364167303170,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVHBTuwUsAIm9wZ.jpg",
        "sizes" : [ {
          "h" : 971,
          "resize" : "fit",
          "w" : 983
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 971,
          "resize" : "fit",
          "w" : 983
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6We9pcSNdH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671530371167739904",
    "text" : "Please read this. We need more understanding &amp; empathy and a lot less hate &amp; fear. Thanks for posting this, Leah. https:\/\/t.co\/6We9pcSNdH",
    "id" : 671530371167739904,
    "created_at" : "2015-12-01 03:24:51 +0000",
    "user" : {
      "name" : "Antonio French",
      "screen_name" : "AntonioFrench",
      "protected" : false,
      "id_str" : "14090948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796329366083031040\/7A2lNYOF_normal.jpg",
      "id" : 14090948,
      "verified" : true
    }
  },
  "id" : 671545638560112640,
  "created_at" : "2015-12-01 04:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivian",
      "screen_name" : "VanguardVivian",
      "indices" : [ 3, 18 ],
      "id_str" : "16738904",
      "id" : 16738904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671535195602989056",
  "text" : "RT @VanguardVivian: They\u2019re only allowed to have a certain number of people with access to their app, so revoking access gives someone else\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "671520288220258304",
    "geo" : { },
    "id_str" : "671520403764862976",
    "in_reply_to_user_id" : 16738904,
    "text" : "They\u2019re only allowed to have a certain number of people with access to their app, so revoking access gives someone else a slot!",
    "id" : 671520403764862976,
    "in_reply_to_status_id" : 671520288220258304,
    "created_at" : "2015-12-01 02:45:15 +0000",
    "in_reply_to_screen_name" : "VanguardVivian",
    "in_reply_to_user_id_str" : "16738904",
    "user" : {
      "name" : "Vivian",
      "screen_name" : "VanguardVivian",
      "protected" : false,
      "id_str" : "16738904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797928814013718532\/8LPYG8F4_normal.jpg",
      "id" : 16738904,
      "verified" : false
    }
  },
  "id" : 671535195602989056,
  "created_at" : "2015-12-01 03:44:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivian",
      "screen_name" : "VanguardVivian",
      "indices" : [ 3, 18 ],
      "id_str" : "16738904",
      "id" : 16738904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671535117928669185",
  "text" : "RT @VanguardVivian: Bored things: Twitter \u2192 Settings \u2192 Apps. Tap \u201CRevoke Access\u201D next to apps you don\u2019t use anymore. It helps the people wh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671520288220258304",
    "text" : "Bored things: Twitter \u2192 Settings \u2192 Apps. Tap \u201CRevoke Access\u201D next to apps you don\u2019t use anymore. It helps the people who make the apps.",
    "id" : 671520288220258304,
    "created_at" : "2015-12-01 02:44:47 +0000",
    "user" : {
      "name" : "Vivian",
      "screen_name" : "VanguardVivian",
      "protected" : false,
      "id_str" : "16738904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797928814013718532\/8LPYG8F4_normal.jpg",
      "id" : 16738904,
      "verified" : false
    }
  },
  "id" : 671535117928669185,
  "created_at" : "2015-12-01 03:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671532583382065152",
  "text" : "RT @johnpavlovitz: Pastor Derwin Gray shared a link about homosexuality. I made a respectful reply about how it could be damaging to LGBT p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671525859912777728",
    "text" : "Pastor Derwin Gray shared a link about homosexuality. I made a respectful reply about how it could be damaging to LGBT people. Blocked me.",
    "id" : 671525859912777728,
    "created_at" : "2015-12-01 03:06:56 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 671532583382065152,
  "created_at" : "2015-12-01 03:33:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Lackey",
      "screen_name" : "LackeyMary",
      "indices" : [ 3, 14 ],
      "id_str" : "582747494",
      "id" : 582747494
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LackeyMary\/status\/671521032247750657\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/haweoVKAFw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVG40fXVEAEQ24U.jpg",
      "id_str" : "671521031366971393",
      "id" : 671521031366971393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVG40fXVEAEQ24U.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/haweoVKAFw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671529496592392192",
  "text" : "RT @LackeyMary: The Wild  Turkey,  Closely Observed Displays Beautiful Colorful Feathers https:\/\/t.co\/haweoVKAFw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LackeyMary\/status\/671521032247750657\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/haweoVKAFw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVG40fXVEAEQ24U.jpg",
        "id_str" : "671521031366971393",
        "id" : 671521031366971393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVG40fXVEAEQ24U.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/haweoVKAFw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671521032247750657",
    "text" : "The Wild  Turkey,  Closely Observed Displays Beautiful Colorful Feathers https:\/\/t.co\/haweoVKAFw",
    "id" : 671521032247750657,
    "created_at" : "2015-12-01 02:47:45 +0000",
    "user" : {
      "name" : "Mary Lackey",
      "screen_name" : "LackeyMary",
      "protected" : false,
      "id_str" : "582747494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459014650596564992\/VYYITHXL_normal.jpeg",
      "id" : 582747494,
      "verified" : false
    }
  },
  "id" : 671529496592392192,
  "created_at" : "2015-12-01 03:21:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Propel Women",
      "screen_name" : "PropelWomen",
      "indices" : [ 3, 15 ],
      "id_str" : "2228775182",
      "id" : 2228775182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671523838493085697",
  "text" : "RT @PropelWomen: Leaders are not always extroverts. They\u2019re not always loud or strong-willed or dreamers. God calls the loud AND the quiet.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sharon Hodde Miller",
        "screen_name" : "SHoddeMiller",
        "indices" : [ 123, 136 ],
        "id_str" : "375895083",
        "id" : 375895083
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669593902807040000",
    "text" : "Leaders are not always extroverts. They\u2019re not always loud or strong-willed or dreamers. God calls the loud AND the quiet. @SHoddeMiller",
    "id" : 669593902807040000,
    "created_at" : "2015-11-25 19:10:01 +0000",
    "user" : {
      "name" : "Propel Women",
      "screen_name" : "PropelWomen",
      "protected" : false,
      "id_str" : "2228775182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514118384359714816\/q1kJyrqc_normal.png",
      "id" : 2228775182,
      "verified" : false
    }
  },
  "id" : 671523838493085697,
  "created_at" : "2015-12-01 02:58:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/zd9tF6YKvo",
      "expanded_url" : "https:\/\/twitter.com\/acuriousgal1\/status\/671489257744175106",
      "display_url" : "twitter.com\/acuriousgal1\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671493137790054400",
  "text" : "smoochable!! sweet puffy birdy : ) https:\/\/t.co\/zd9tF6YKvo",
  "id" : 671493137790054400,
  "created_at" : "2015-12-01 00:56:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karoli",
      "screen_name" : "Karoli",
      "indices" : [ 3, 10 ],
      "id_str" : "980611",
      "id" : 980611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/TNzaEOV4Ll",
      "expanded_url" : "https:\/\/twitter.com\/OsborneInk\/status\/671457233008504832",
      "display_url" : "twitter.com\/OsborneInk\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671480265810776064",
  "text" : "RT @Karoli: Terrorism  https:\/\/t.co\/TNzaEOV4Ll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/TNzaEOV4Ll",
        "expanded_url" : "https:\/\/twitter.com\/OsborneInk\/status\/671457233008504832",
        "display_url" : "twitter.com\/OsborneInk\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671464253417590785",
    "text" : "Terrorism  https:\/\/t.co\/TNzaEOV4Ll",
    "id" : 671464253417590785,
    "created_at" : "2015-11-30 23:02:07 +0000",
    "user" : {
      "name" : "Karoli",
      "screen_name" : "Karoli",
      "protected" : false,
      "id_str" : "980611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688475729835593728\/2DWOTDxJ_normal.jpg",
      "id" : 980611,
      "verified" : false
    }
  },
  "id" : 671480265810776064,
  "created_at" : "2015-12-01 00:05:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671440301387460608",
  "geo" : { },
  "id_str" : "671477025534836736",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ohhh.. the bloody pic was from work!!",
  "id" : 671477025534836736,
  "in_reply_to_status_id" : 671440301387460608,
  "created_at" : "2015-11-30 23:52:52 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671453978048069632",
  "geo" : { },
  "id_str" : "671474556188643328",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ummm... wth? did you fall or something???",
  "id" : 671474556188643328,
  "in_reply_to_status_id" : 671453978048069632,
  "created_at" : "2015-11-30 23:43:04 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bette Midler",
      "screen_name" : "BetteMidler",
      "indices" : [ 3, 15 ],
      "id_str" : "139823781",
      "id" : 139823781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 40, 52 ]
    }, {
      "text" : "Apple",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671429205515747328",
  "text" : "RT @BetteMidler: Can we stop calling it #CyberMonday? It\u2019s not catchy. It\nsounds like I\u2019m trying to have Internet sex with #Apple customer \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberMonday",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "Apple",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671427675001516034",
    "text" : "Can we stop calling it #CyberMonday? It\u2019s not catchy. It\nsounds like I\u2019m trying to have Internet sex with #Apple customer service.",
    "id" : 671427675001516034,
    "created_at" : "2015-11-30 20:36:46 +0000",
    "user" : {
      "name" : "Bette Midler",
      "screen_name" : "BetteMidler",
      "protected" : false,
      "id_str" : "139823781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793394076787757056\/Fnx0wN6Q_normal.jpg",
      "id" : 139823781,
      "verified" : true
    }
  },
  "id" : 671429205515747328,
  "created_at" : "2015-11-30 20:42:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 3, 13 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    }, {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "indices" : [ 95, 104 ],
      "id_str" : "3252798247",
      "id" : 3252798247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BsFhWZZ0Qm",
      "expanded_url" : "https:\/\/myou.pub\/b\/445-1000\/",
      "display_url" : "myou.pub\/b\/445-1000\/"
    } ]
  },
  "geo" : { },
  "id_str" : "671424895490899972",
  "text" : "RT @gleneivey: A small post acknowledging the epic face-plant that was the new-users drive for @myou_pub: https:\/\/t.co\/BsFhWZZ0Qm\u2026 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "myou",
        "screen_name" : "myou_pub",
        "indices" : [ 80, 89 ],
        "id_str" : "3252798247",
        "id" : 3252798247
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/BsFhWZZ0Qm",
        "expanded_url" : "https:\/\/myou.pub\/b\/445-1000\/",
        "display_url" : "myou.pub\/b\/445-1000\/"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/TSQJ2aCIHQ",
        "expanded_url" : "https:\/\/myou.pub\/gleneivey\/posts\/2511",
        "display_url" : "myou.pub\/gleneivey\/post\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671423944482668544",
    "text" : "A small post acknowledging the epic face-plant that was the new-users drive for @myou_pub: https:\/\/t.co\/BsFhWZZ0Qm\u2026 https:\/\/t.co\/TSQJ2aCIHQ",
    "id" : 671423944482668544,
    "created_at" : "2015-11-30 20:21:57 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "protected" : false,
      "id_str" : "3083114561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693282117216636928\/88WEWoum_normal.jpg",
      "id" : 3083114561,
      "verified" : false
    }
  },
  "id" : 671424895490899972,
  "created_at" : "2015-11-30 20:25:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAP",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "audioplayers",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/pR74BOeDFv",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2510",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671395576399790080",
  "text" : "AK Jr; iBasso DX50,90,80; FiioX1,3ii,5ii; Pono.. #DAP #audioplayers (from https:\/\/t.co\/pR74BOeDFv)",
  "id" : 671395576399790080,
  "created_at" : "2015-11-30 18:29:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0gNDQQgarf",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2506",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671360107695890433",
  "text" : "apparently americans are smartphone\/ipod music ppl.. player reviews mostly accented. (from https:\/\/t.co\/0gNDQQgarf)",
  "id" : 671360107695890433,
  "created_at" : "2015-11-30 16:08:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Ryan",
      "screen_name" : "drunkitty2000",
      "indices" : [ 3, 17 ],
      "id_str" : "172765058",
      "id" : 172765058
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UltimateSpoonieGiveaway",
      "indices" : [ 40, 64 ]
    }, {
      "text" : "spoonies",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/iwuhR2hPtn",
      "expanded_url" : "http:\/\/countingmyspoons.com\/2015\/11\/the-ultimate-spoonie-giveaway\/",
      "display_url" : "countingmyspoons.com\/2015\/11\/the-ul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671165941154230272",
  "text" : "RT @drunkitty2000: Have you entered the #UltimateSpoonieGiveaway yet? 2 huge prize packs for #spoonies https:\/\/t.co\/iwuhR2hPtn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UltimateSpoonieGiveaway",
        "indices" : [ 21, 45 ]
      }, {
        "text" : "spoonies",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/iwuhR2hPtn",
        "expanded_url" : "http:\/\/countingmyspoons.com\/2015\/11\/the-ultimate-spoonie-giveaway\/",
        "display_url" : "countingmyspoons.com\/2015\/11\/the-ul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671123854207635460",
    "text" : "Have you entered the #UltimateSpoonieGiveaway yet? 2 huge prize packs for #spoonies https:\/\/t.co\/iwuhR2hPtn",
    "id" : 671123854207635460,
    "created_at" : "2015-11-30 00:29:30 +0000",
    "user" : {
      "name" : "Julie Ryan",
      "screen_name" : "drunkitty2000",
      "protected" : false,
      "id_str" : "172765058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000789413762\/41d96644d45ec4a5f39d5439c1cde9ce_normal.jpeg",
      "id" : 172765058,
      "verified" : false
    }
  },
  "id" : 671165941154230272,
  "created_at" : "2015-11-30 03:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/YGrEEBegba",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2484",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671024852120113153",
  "text" : "curr looking at pono player, fiio x1,x3,x5  (from https:\/\/t.co\/YGrEEBegba)",
  "id" : 671024852120113153,
  "created_at" : "2015-11-29 17:56:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAP",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "audioplayers",
      "indices" : [ 22, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/CG3N0pxTjk",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2483",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671023946624466945",
  "text" : "any comments? on #DAP #audioplayers for music also audiobooks,podcasts. max volume, long battery, ez use. (from https:\/\/t.co\/CG3N0pxTjk)",
  "id" : 671023946624466945,
  "created_at" : "2015-11-29 17:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/671002298190032896\/video\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/k1OwY1EtP4",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/671002102269943808\/pu\/img\/bzdqLBxoLQ4yP5wZ.jpg",
      "id_str" : "671002102269943808",
      "id" : 671002102269943808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/671002102269943808\/pu\/img\/bzdqLBxoLQ4yP5wZ.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/k1OwY1EtP4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671004045977509889",
  "text" : "RT @WildlifeGadgets: Snuggle time in the squirrel box. https:\/\/t.co\/k1OwY1EtP4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/671002298190032896\/video\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/k1OwY1EtP4",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/671002102269943808\/pu\/img\/bzdqLBxoLQ4yP5wZ.jpg",
        "id_str" : "671002102269943808",
        "id" : 671002102269943808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/671002102269943808\/pu\/img\/bzdqLBxoLQ4yP5wZ.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/k1OwY1EtP4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671002298190032896",
    "text" : "Snuggle time in the squirrel box. https:\/\/t.co\/k1OwY1EtP4",
    "id" : 671002298190032896,
    "created_at" : "2015-11-29 16:26:29 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 671004045977509889,
  "created_at" : "2015-11-29 16:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audioplayers",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/8kQ5NkQ5Lf",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2482",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670998860471275520",
  "text" : "so apparently #audioplayers are just for music? not audiobooks,podcasts. Stupid!! (from https:\/\/t.co\/8kQ5NkQ5Lf)",
  "id" : 670998860471275520,
  "created_at" : "2015-11-29 16:12:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "indices" : [ 3, 16 ],
      "id_str" : "29995782",
      "id" : 29995782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670824029322915840",
  "text" : "RT @saladinahmed: THERAPIST Now listen to me. Someone should have told you this 20 years ago: You DON'T gotta catch em all. You don't.\n\nASH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670815371977445377",
    "text" : "THERAPIST Now listen to me. Someone should have told you this 20 years ago: You DON'T gotta catch em all. You don't.\n\nASH But...I... :weeps:",
    "id" : 670815371977445377,
    "created_at" : "2015-11-29 04:03:42 +0000",
    "user" : {
      "name" : "Saladin Ahmed",
      "screen_name" : "saladinahmed",
      "protected" : false,
      "id_str" : "29995782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784413705895153665\/1uu0CmXR_normal.jpg",
      "id" : 29995782,
      "verified" : true
    }
  },
  "id" : 670824029322915840,
  "created_at" : "2015-11-29 04:38:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Rall",
      "screen_name" : "katiellen150",
      "indices" : [ 3, 16 ],
      "id_str" : "42218038",
      "id" : 42218038
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/katiellen150\/status\/665181907332816898\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/yq4ikpp3pG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTszaVgWcAAPlpG.jpg",
      "id_str" : "665181897509728256",
      "id" : 665181897509728256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTszaVgWcAAPlpG.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yq4ikpp3pG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670806775378141184",
  "text" : "RT @katiellen150: Believe me when I say my dog thinks she is a cat https:\/\/t.co\/yq4ikpp3pG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/katiellen150\/status\/665181907332816898\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/yq4ikpp3pG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTszaVgWcAAPlpG.jpg",
        "id_str" : "665181897509728256",
        "id" : 665181897509728256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTszaVgWcAAPlpG.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yq4ikpp3pG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665181907332816898",
    "text" : "Believe me when I say my dog thinks she is a cat https:\/\/t.co\/yq4ikpp3pG",
    "id" : 665181907332816898,
    "created_at" : "2015-11-13 14:58:19 +0000",
    "user" : {
      "name" : "Katie Rall",
      "screen_name" : "katiellen150",
      "protected" : false,
      "id_str" : "42218038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793155953378095105\/QnY7n7gq_normal.jpg",
      "id" : 42218038,
      "verified" : false
    }
  },
  "id" : 670806775378141184,
  "created_at" : "2015-11-29 03:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/RK7QG5qe3q",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2473",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670779561043333120",
  "text" : "Huh.. Pono seems 2B controversial.. ppl love it or hate it. (from https:\/\/t.co\/RK7QG5qe3q)",
  "id" : 670779561043333120,
  "created_at" : "2015-11-29 01:41:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 3, 13 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670778507534966784",
  "text" : "RT @gleneivey: I think it's time for another rant about how terrible Twitter's decision to change from \"favorite\" to \"like\" was. \u2026 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/y4gUWgoHiJ",
        "expanded_url" : "https:\/\/myou.pub\/gleneivey\/posts\/2469",
        "display_url" : "myou.pub\/gleneivey\/post\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670710948827566080",
    "text" : "I think it's time for another rant about how terrible Twitter's decision to change from \"favorite\" to \"like\" was. \u2026 https:\/\/t.co\/y4gUWgoHiJ",
    "id" : 670710948827566080,
    "created_at" : "2015-11-28 21:08:46 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "protected" : false,
      "id_str" : "3083114561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693282117216636928\/88WEWoum_normal.jpg",
      "id" : 3083114561,
      "verified" : false
    }
  },
  "id" : 670778507534966784,
  "created_at" : "2015-11-29 01:37:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "indices" : [ 3, 16 ],
      "id_str" : "926185416",
      "id" : 926185416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/pODNnN59qn",
      "expanded_url" : "https:\/\/twitter.com\/SlyFlyAndHigh\/status\/670361096365015040",
      "display_url" : "twitter.com\/SlyFlyAndHigh\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670723975983570944",
  "text" : "RT @hoosierworld: The American Taliban is on twitter. Their message is clear: breed or die.  https:\/\/t.co\/pODNnN59qn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/pODNnN59qn",
        "expanded_url" : "https:\/\/twitter.com\/SlyFlyAndHigh\/status\/670361096365015040",
        "display_url" : "twitter.com\/SlyFlyAndHigh\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670722189264482304",
    "text" : "The American Taliban is on twitter. Their message is clear: breed or die.  https:\/\/t.co\/pODNnN59qn",
    "id" : 670722189264482304,
    "created_at" : "2015-11-28 21:53:25 +0000",
    "user" : {
      "name" : "IndyMama",
      "screen_name" : "hoosierworld",
      "protected" : false,
      "id_str" : "926185416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675149555630022656\/jsP6uwQo_normal.jpg",
      "id" : 926185416,
      "verified" : false
    }
  },
  "id" : 670723975983570944,
  "created_at" : "2015-11-28 22:00:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/670631019737948160\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/pzKxvFJZZn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6PSTSWoAEIR4b.jpg",
      "id_str" : "670630939102453761",
      "id" : 670630939102453761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6PSTSWoAEIR4b.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pzKxvFJZZn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/670631019737948160\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/pzKxvFJZZn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6PUnbXIAAYFNm.jpg",
      "id_str" : "670630978868682752",
      "id" : 670630978868682752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6PUnbXIAAYFNm.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pzKxvFJZZn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/670631019737948160\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/pzKxvFJZZn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6PW4tXAAAZvPv.jpg",
      "id_str" : "670631017867313152",
      "id" : 670631017867313152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6PW4tXAAAZvPv.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pzKxvFJZZn"
    } ],
    "hashtags" : [ {
      "text" : "RiggitGalloways",
      "indices" : [ 89, 105 ]
    }, {
      "text" : "NativeBreeds",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670711858437996544",
  "text" : "RT @SouthYeoEast: Here's some munching cow pics to keep you going. Fiona &amp; Daisy Mae #RiggitGalloways #NativeBreeds https:\/\/t.co\/pzKxvFJZZn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/670631019737948160\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/pzKxvFJZZn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6PSTSWoAEIR4b.jpg",
        "id_str" : "670630939102453761",
        "id" : 670630939102453761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6PSTSWoAEIR4b.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pzKxvFJZZn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/670631019737948160\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/pzKxvFJZZn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6PUnbXIAAYFNm.jpg",
        "id_str" : "670630978868682752",
        "id" : 670630978868682752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6PUnbXIAAYFNm.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pzKxvFJZZn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/670631019737948160\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/pzKxvFJZZn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6PW4tXAAAZvPv.jpg",
        "id_str" : "670631017867313152",
        "id" : 670631017867313152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6PW4tXAAAZvPv.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pzKxvFJZZn"
      } ],
      "hashtags" : [ {
        "text" : "RiggitGalloways",
        "indices" : [ 71, 87 ]
      }, {
        "text" : "NativeBreeds",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670631019737948160",
    "text" : "Here's some munching cow pics to keep you going. Fiona &amp; Daisy Mae #RiggitGalloways #NativeBreeds https:\/\/t.co\/pzKxvFJZZn",
    "id" : 670631019737948160,
    "created_at" : "2015-11-28 15:51:09 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 670711858437996544,
  "created_at" : "2015-11-28 21:12:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audioplayer",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670683393609367552",
  "text" : "Fiio.. hmm.. #audioplayer",
  "id" : 670683393609367552,
  "created_at" : "2015-11-28 19:19:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/0Wq0S1q7D0",
      "expanded_url" : "https:\/\/twitter.com\/thDigitalReader\/status\/670681326165577728",
      "display_url" : "twitter.com\/thDigitalReade\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670682148119158786",
  "text" : "Stupid Facebook. I hate that whole \"real name\" thing. (ps. check out myou) https:\/\/t.co\/0Wq0S1q7D0",
  "id" : 670682148119158786,
  "created_at" : "2015-11-28 19:14:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 15, 26 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/UrZxarWNGS",
      "expanded_url" : "http:\/\/youtu.be\/EUSmiBVYaWU",
      "display_url" : "youtu.be\/EUSmiBVYaWU"
    } ]
  },
  "geo" : { },
  "id_str" : "670676310763655169",
  "text" : "RT @bend_time: @moosebegab \nFood fights, football and family! Happy Thanksgiving \u2764\uFE0F https:\/\/t.co\/UrZxarWNGS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/UrZxarWNGS",
        "expanded_url" : "http:\/\/youtu.be\/EUSmiBVYaWU",
        "display_url" : "youtu.be\/EUSmiBVYaWU"
      } ]
    },
    "geo" : { },
    "id_str" : "670451218859200512",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab \nFood fights, football and family! Happy Thanksgiving \u2764\uFE0F https:\/\/t.co\/UrZxarWNGS",
    "id" : 670451218859200512,
    "created_at" : "2015-11-28 03:56:41 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 670676310763655169,
  "created_at" : "2015-11-28 18:51:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670451218859200512",
  "geo" : { },
  "id_str" : "670676217096445953",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time yay!! that was funny and cute.. I loved it!!",
  "id" : 670676217096445953,
  "in_reply_to_status_id" : 670451218859200512,
  "created_at" : "2015-11-28 18:50:45 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/t9qXyr6lxB",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2463",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670664718101573632",
  "text" : "also, cant seem to get volume high enough. is that a thing now.. limiting volume? gah. (from https:\/\/t.co\/t9qXyr6lxB)",
  "id" : 670664718101573632,
  "created_at" : "2015-11-28 18:05:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/TPPXnGxiRe",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2462",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670664513721470976",
  "text" : "havent listened much to music in car since given up ipod touch. too difficult to get music on 1520 or android. (fr\u2026 https:\/\/t.co\/TPPXnGxiRe",
  "id" : 670664513721470976,
  "created_at" : "2015-11-28 18:04:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PonoPlayer",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "heysanta",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/KCP0iik6nk",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2461",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670663932852350976",
  "text" : "checking out the #PonoPlayer.. love the shape! #heysanta (from https:\/\/t.co\/KCP0iik6nk)",
  "id" : 670663932852350976,
  "created_at" : "2015-11-28 18:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ms Maggie)))",
      "screen_name" : "maggiepriceless",
      "indices" : [ 3, 19 ],
      "id_str" : "233749323",
      "id" : 233749323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/x5a7C8dTVI",
      "expanded_url" : "https:\/\/twitter.com\/JohnFugelsang\/status\/670441066122883072",
      "display_url" : "twitter.com\/JohnFugelsang\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670444326158254080",
  "text" : "RT @maggiepriceless: Bingo. https:\/\/t.co\/x5a7C8dTVI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/x5a7C8dTVI",
        "expanded_url" : "https:\/\/twitter.com\/JohnFugelsang\/status\/670441066122883072",
        "display_url" : "twitter.com\/JohnFugelsang\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670441515437522944",
    "text" : "Bingo. https:\/\/t.co\/x5a7C8dTVI",
    "id" : 670441515437522944,
    "created_at" : "2015-11-28 03:18:08 +0000",
    "user" : {
      "name" : "(((Ms Maggie)))",
      "screen_name" : "maggiepriceless",
      "protected" : false,
      "id_str" : "233749323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797340094042689536\/iYz5ibhq_normal.jpg",
      "id" : 233749323,
      "verified" : false
    }
  },
  "id" : 670444326158254080,
  "created_at" : "2015-11-28 03:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Stevens",
      "screen_name" : "gregstevens",
      "indices" : [ 3, 15 ],
      "id_str" : "15166145",
      "id" : 15166145
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gregstevens\/status\/670432449512366080\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/3YDXztX0Yb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU3awfvVAAEWVte.jpg",
      "id_str" : "670432446236655617",
      "id" : 670432446236655617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU3awfvVAAEWVte.jpg",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/3YDXztX0Yb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670434484324536320",
  "text" : "RT @gregstevens: The definition of \"terrorism\", FYI https:\/\/t.co\/3YDXztX0Yb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gregstevens\/status\/670432449512366080\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/3YDXztX0Yb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU3awfvVAAEWVte.jpg",
        "id_str" : "670432446236655617",
        "id" : 670432446236655617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU3awfvVAAEWVte.jpg",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/3YDXztX0Yb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670432449512366080",
    "text" : "The definition of \"terrorism\", FYI https:\/\/t.co\/3YDXztX0Yb",
    "id" : 670432449512366080,
    "created_at" : "2015-11-28 02:42:06 +0000",
    "user" : {
      "name" : "Greg Stevens",
      "screen_name" : "gregstevens",
      "protected" : false,
      "id_str" : "15166145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793565954852524034\/b0MGStSs_normal.jpg",
      "id" : 15166145,
      "verified" : true
    }
  },
  "id" : 670434484324536320,
  "created_at" : "2015-11-28 02:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670431787567435777",
  "text" : "RT @RustBeltRebel: they feel they have the RIGHT to control women, and so to *terrorize* women who wont be or can't be controlled.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "670428671254077441",
    "geo" : { },
    "id_str" : "670429374483705856",
    "in_reply_to_user_id" : 2382724914,
    "text" : "they feel they have the RIGHT to control women, and so to *terrorize* women who wont be or can't be controlled.",
    "id" : 670429374483705856,
    "in_reply_to_status_id" : 670428671254077441,
    "created_at" : "2015-11-28 02:29:53 +0000",
    "in_reply_to_screen_name" : "RustBeltRebel",
    "in_reply_to_user_id_str" : "2382724914",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 670431787567435777,
  "created_at" : "2015-11-28 02:39:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670429384419975169",
  "text" : "RT @RustBeltRebel: they WANT women to be terrified. they WANT women to be too afraid to say no, too afraid to make their own choices.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "670427556340961280",
    "geo" : { },
    "id_str" : "670427958679613440",
    "in_reply_to_user_id" : 2382724914,
    "text" : "they WANT women to be terrified. they WANT women to be too afraid to say no, too afraid to make their own choices.",
    "id" : 670427958679613440,
    "in_reply_to_status_id" : 670427556340961280,
    "created_at" : "2015-11-28 02:24:15 +0000",
    "in_reply_to_screen_name" : "RustBeltRebel",
    "in_reply_to_user_id_str" : "2382724914",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 670429384419975169,
  "created_at" : "2015-11-28 02:29:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/EliXM1tO39",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2441",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670424234120732674",
  "text" : "Bad heartburn tonight even after taking one of DD's ranitidine pills. Ugh. (from https:\/\/t.co\/EliXM1tO39)",
  "id" : 670424234120732674,
  "created_at" : "2015-11-28 02:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iResist",
      "screen_name" : "ThomboyD",
      "indices" : [ 3, 12 ],
      "id_str" : "117450444",
      "id" : 117450444
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 20, 24 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PlannedParenthood",
      "indices" : [ 40, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670418376938885120",
  "text" : "RT @ThomboyD: Well, @cnn just described #PlannedParenthood shooter as an \"older gentleman.\" Good to know he was polite while gunning down t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 6, 10 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PlannedParenthood",
        "indices" : [ 26, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670405964827234304",
    "text" : "Well, @cnn just described #PlannedParenthood shooter as an \"older gentleman.\" Good to know he was polite while gunning down those cops.",
    "id" : 670405964827234304,
    "created_at" : "2015-11-28 00:56:52 +0000",
    "user" : {
      "name" : "iResist",
      "screen_name" : "ThomboyD",
      "protected" : false,
      "id_str" : "117450444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501132806232092672\/eaTIOTiF_normal.jpeg",
      "id" : 117450444,
      "verified" : false
    }
  },
  "id" : 670418376938885120,
  "created_at" : "2015-11-28 01:46:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Gauvin",
      "screen_name" : "JeffersonObama",
      "indices" : [ 3, 18 ],
      "id_str" : "39609732",
      "id" : 39609732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670400329574449152",
  "text" : "RT @JeffersonObama: Why do white mass murderers always get captured alive by cops? Black people get shot if they answer the wrong way while\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670394243718864896",
    "text" : "Why do white mass murderers always get captured alive by cops? Black people get shot if they answer the wrong way while pulled over??",
    "id" : 670394243718864896,
    "created_at" : "2015-11-28 00:10:17 +0000",
    "user" : {
      "name" : "Jeff Gauvin",
      "screen_name" : "JeffersonObama",
      "protected" : false,
      "id_str" : "39609732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793242602078429184\/zJ0sw_-U_normal.jpg",
      "id" : 39609732,
      "verified" : false
    }
  },
  "id" : 670400329574449152,
  "created_at" : "2015-11-28 00:34:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670390531936100352",
  "text" : "RT @johnpavlovitz: As an American, I'm far less worried about refugees, Muslims, or any foreign threat than I am about angry white guys wit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "terrorism",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670387712168456192",
    "text" : "As an American, I'm far less worried about refugees, Muslims, or any foreign threat than I am about angry white guys with guns. #terrorism",
    "id" : 670387712168456192,
    "created_at" : "2015-11-27 23:44:20 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 670390531936100352,
  "created_at" : "2015-11-27 23:55:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "((( Sue )))",
      "screen_name" : "TwinmomSue",
      "indices" : [ 3, 14 ],
      "id_str" : "2463274765",
      "id" : 2463274765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PP",
      "indices" : [ 74, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670389283128217600",
  "text" : "RT @TwinmomSue: Conservatives need to explain why we need facilities like #PP to save us from the neglect of \"religious\" hospitals https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PP",
        "indices" : [ 58, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/zwDVc6minh",
        "expanded_url" : "https:\/\/twitter.com\/theologop\/status\/670383762086060032",
        "display_url" : "twitter.com\/theologop\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670384600447741952",
    "text" : "Conservatives need to explain why we need facilities like #PP to save us from the neglect of \"religious\" hospitals https:\/\/t.co\/zwDVc6minh",
    "id" : 670384600447741952,
    "created_at" : "2015-11-27 23:31:58 +0000",
    "user" : {
      "name" : "((( Sue )))",
      "screen_name" : "TwinmomSue",
      "protected" : false,
      "id_str" : "2463274765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798256886244118528\/ZvRmkuOy_normal.jpg",
      "id" : 2463274765,
      "verified" : false
    }
  },
  "id" : 670389283128217600,
  "created_at" : "2015-11-27 23:50:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Laning",
      "screen_name" : "_jasonlaning",
      "indices" : [ 3, 16 ],
      "id_str" : "2833352660",
      "id" : 2833352660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670323660784336896",
  "text" : "RT @_jasonlaning: So Bratton's sending the message to his officers that peaceful protesters are potential cop killers. Great. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/RecFmF495h",
        "expanded_url" : "https:\/\/twitter.com\/keegannyc\/status\/669945004744404992",
        "display_url" : "twitter.com\/keegannyc\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670248915220975616",
    "text" : "So Bratton's sending the message to his officers that peaceful protesters are potential cop killers. Great. https:\/\/t.co\/RecFmF495h",
    "id" : 670248915220975616,
    "created_at" : "2015-11-27 14:32:48 +0000",
    "user" : {
      "name" : "Jason Laning",
      "screen_name" : "_jasonlaning",
      "protected" : false,
      "id_str" : "2833352660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664453911483387905\/Hp7QXzC6_normal.jpg",
      "id" : 2833352660,
      "verified" : false
    }
  },
  "id" : 670323660784336896,
  "created_at" : "2015-11-27 19:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProCannabis",
      "screen_name" : "ProCannabis",
      "indices" : [ 3, 15 ],
      "id_str" : "228267111",
      "id" : 228267111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Oqq1gQs5lq",
      "expanded_url" : "http:\/\/ow.ly\/38ppmC",
      "display_url" : "ow.ly\/38ppmC"
    } ]
  },
  "geo" : { },
  "id_str" : "670323619864698880",
  "text" : "RT @ProCannabis: Montana Jury Candidates Refuses To Convict Anyone For Marijuana Possession https:\/\/t.co\/Oqq1gQs5lq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Oqq1gQs5lq",
        "expanded_url" : "http:\/\/ow.ly\/38ppmC",
        "display_url" : "ow.ly\/38ppmC"
      } ]
    },
    "geo" : { },
    "id_str" : "670293882215768065",
    "text" : "Montana Jury Candidates Refuses To Convict Anyone For Marijuana Possession https:\/\/t.co\/Oqq1gQs5lq",
    "id" : 670293882215768065,
    "created_at" : "2015-11-27 17:31:29 +0000",
    "user" : {
      "name" : "ProCannabis",
      "screen_name" : "ProCannabis",
      "protected" : false,
      "id_str" : "228267111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1193915437\/ProCannabis_normal.jpeg",
      "id" : 228267111,
      "verified" : false
    }
  },
  "id" : 670323619864698880,
  "created_at" : "2015-11-27 19:29:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670082153892421633",
  "geo" : { },
  "id_str" : "670087270859411457",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time DAMN.. Prob right b4 I had DH switch channels!",
  "id" : 670087270859411457,
  "in_reply_to_status_id" : 670082153892421633,
  "created_at" : "2015-11-27 03:50:29 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670081385504313344",
  "text" : "RT @TheOracle13: Love is my religion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670080599336554497",
    "text" : "Love is my religion.",
    "id" : 670080599336554497,
    "created_at" : "2015-11-27 03:23:59 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 670081385504313344,
  "created_at" : "2015-11-27 03:27:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/aTcZpV11Mb",
      "expanded_url" : "https:\/\/twitter.com\/thebloggess\/status\/669937205045923840",
      "display_url" : "twitter.com\/thebloggess\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670081059002953729",
  "text" : "RT @onealexharms: \"You are not alone.\" Sharing for folks whose thanksgiving is complicated or otherwise non-idyllic. https:\/\/t.co\/aTcZpV11Mb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/aTcZpV11Mb",
        "expanded_url" : "https:\/\/twitter.com\/thebloggess\/status\/669937205045923840",
        "display_url" : "twitter.com\/thebloggess\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670068870720454656",
    "text" : "\"You are not alone.\" Sharing for folks whose thanksgiving is complicated or otherwise non-idyllic. https:\/\/t.co\/aTcZpV11Mb",
    "id" : 670068870720454656,
    "created_at" : "2015-11-27 02:37:22 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 670081059002953729,
  "created_at" : "2015-11-27 03:25:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670068193738792961",
  "text" : "RT @existentialcoms: It sucks that you have to become an adult. Whose bright idea was that?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670065452991840256",
    "text" : "It sucks that you have to become an adult. Whose bright idea was that?",
    "id" : 670065452991840256,
    "created_at" : "2015-11-27 02:23:47 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 670068193738792961,
  "created_at" : "2015-11-27 02:34:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669934021309165568",
  "geo" : { },
  "id_str" : "670058570839425024",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time i guess it wasnt shown. I tried to keep an eye on tv. i wanted to see it. : (",
  "id" : 670058570839425024,
  "in_reply_to_status_id" : 669934021309165568,
  "created_at" : "2015-11-27 01:56:27 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669928349192450048",
  "geo" : { },
  "id_str" : "669931104384753664",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time did I miss it? anthem starting now. will be leaving shortly.. gah.",
  "id" : 669931104384753664,
  "in_reply_to_status_id" : 669928349192450048,
  "created_at" : "2015-11-26 17:29:56 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/Of6E8gXtSR",
      "expanded_url" : "http:\/\/www.yourholidaymom.com\/",
      "display_url" : "yourholidaymom.com"
    }, {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/BFFkChjNQE",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2425?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669925053086212096",
  "geo" : { },
  "id_str" : "669926837418524672",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 ((hugs)) did you see my earlier link https:\/\/t.co\/Of6E8gXtSR \/\/ discuss at https:\/\/t.co\/BFFkChjNQE",
  "id" : 669926837418524672,
  "in_reply_to_status_id" : 669925053086212096,
  "created_at" : "2015-11-26 17:12:59 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "indices" : [ 3, 15 ],
      "id_str" : "896548279",
      "id" : 896548279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "money",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "disability",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669926068451680256",
  "text" : "RT @NaamaYehuda: Providing people with access to #healthcare, saves lives, and saves #money in the long run in less #disability. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthcare",
        "indices" : [ 32, 43 ]
      }, {
        "text" : "money",
        "indices" : [ 68, 74 ]
      }, {
        "text" : "disability",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Vxk7vIEZM1",
        "expanded_url" : "https:\/\/twitter.com\/nytnational\/status\/669913779837255680",
        "display_url" : "twitter.com\/nytnational\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669925120295743488",
    "text" : "Providing people with access to #healthcare, saves lives, and saves #money in the long run in less #disability. https:\/\/t.co\/Vxk7vIEZM1",
    "id" : 669925120295743488,
    "created_at" : "2015-11-26 17:06:09 +0000",
    "user" : {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "protected" : false,
      "id_str" : "896548279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2748712360\/5665839cb74057117f99ea3245bba181_normal.jpeg",
      "id" : 896548279,
      "verified" : false
    }
  },
  "id" : 669926068451680256,
  "created_at" : "2015-11-26 17:09:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((bebird)))",
      "screen_name" : "bebird",
      "indices" : [ 3, 10 ],
      "id_str" : "15968617",
      "id" : 15968617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669925244287754241",
  "text" : "RT @bebird: Spent my morning feeding wild turkeys cowering near my house it's a tough day for them",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669921560053071872",
    "text" : "Spent my morning feeding wild turkeys cowering near my house it's a tough day for them",
    "id" : 669921560053071872,
    "created_at" : "2015-11-26 16:52:01 +0000",
    "user" : {
      "name" : "(((bebird)))",
      "screen_name" : "bebird",
      "protected" : false,
      "id_str" : "15968617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766034678172311552\/_W6cBNDV_normal.jpg",
      "id" : 15968617,
      "verified" : false
    }
  },
  "id" : 669925244287754241,
  "created_at" : "2015-11-26 17:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 15, 25 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/BjcxcFfHcf",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2424",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669924839281455104",
  "text" : "waiting to see @bend_time in promo at approx 12:15 B4 football game. (from https:\/\/t.co\/BjcxcFfHcf)",
  "id" : 669924839281455104,
  "created_at" : "2015-11-26 17:05:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Shapka",
      "screen_name" : "Macanuck",
      "indices" : [ 3, 12 ],
      "id_str" : "51613545",
      "id" : 51613545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/caWjcF4nOG",
      "expanded_url" : "http:\/\/flip.it\/y-YqW",
      "display_url" : "flip.it\/y-YqW"
    } ]
  },
  "geo" : { },
  "id_str" : "669910549401083908",
  "text" : "RT @Macanuck: Earth's Atmosphere Just Crossed an Epochal Threshold https:\/\/t.co\/caWjcF4nOG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/caWjcF4nOG",
        "expanded_url" : "http:\/\/flip.it\/y-YqW",
        "display_url" : "flip.it\/y-YqW"
      } ]
    },
    "geo" : { },
    "id_str" : "669909768467832832",
    "text" : "Earth's Atmosphere Just Crossed an Epochal Threshold https:\/\/t.co\/caWjcF4nOG",
    "id" : 669909768467832832,
    "created_at" : "2015-11-26 16:05:09 +0000",
    "user" : {
      "name" : "Bob Shapka",
      "screen_name" : "Macanuck",
      "protected" : false,
      "id_str" : "51613545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2771498644\/a85354bfbcfb9ff95f73600831e321c4_normal.png",
      "id" : 51613545,
      "verified" : false
    }
  },
  "id" : 669910549401083908,
  "created_at" : "2015-11-26 16:08:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/669874283305410561\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/TFHfflTB1Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUvfHGsXIAQopsd.jpg",
      "id_str" : "669874282743406596",
      "id" : 669874282743406596,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUvfHGsXIAQopsd.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 418
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 418
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 418
      } ],
      "display_url" : "pic.twitter.com\/TFHfflTB1Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669907485646565376",
  "text" : "RT @CatFoodBreath: Holiday cuteness.  Happy Thanksgiving. https:\/\/t.co\/TFHfflTB1Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/669874283305410561\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/TFHfflTB1Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUvfHGsXIAQopsd.jpg",
        "id_str" : "669874282743406596",
        "id" : 669874282743406596,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUvfHGsXIAQopsd.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 418
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 418
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 418
        } ],
        "display_url" : "pic.twitter.com\/TFHfflTB1Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669874283305410561",
    "text" : "Holiday cuteness.  Happy Thanksgiving. https:\/\/t.co\/TFHfflTB1Y",
    "id" : 669874283305410561,
    "created_at" : "2015-11-26 13:44:09 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 669907485646565376,
  "created_at" : "2015-11-26 15:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/tvx7fNKdES",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2421?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669906269373726720",
  "text" : "(re: https:\/\/t.co\/tvx7fNKdES) I think myou has great potential.. needs a chance. Plus I like the cat.",
  "id" : 669906269373726720,
  "created_at" : "2015-11-26 15:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "indices" : [ 32, 41 ],
      "id_str" : "3252798247",
      "id" : 3252798247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669904802223169536",
  "text" : "RT @joyfuldroid: I'm trying out @myou_pub, an ambitious experiment in better micro-blogging. Hope it gets a chance to follow through on its\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "myou",
        "screen_name" : "myou_pub",
        "indices" : [ 15, 24 ],
        "id_str" : "3252798247",
        "id" : 3252798247
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668526939523710977",
    "text" : "I'm trying out @myou_pub, an ambitious experiment in better micro-blogging. Hope it gets a chance to follow through on its goals.",
    "id" : 668526939523710977,
    "created_at" : "2015-11-22 20:30:17 +0000",
    "user" : {
      "name" : "born unto trouble",
      "screen_name" : "asthesparksfly",
      "protected" : false,
      "id_str" : "450975609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690941083157729280\/8s8-dRxN_normal.jpg",
      "id" : 450975609,
      "verified" : false
    }
  },
  "id" : 669904802223169536,
  "created_at" : "2015-11-26 15:45:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maverynthia",
      "screen_name" : "maverynthia",
      "indices" : [ 3, 15 ],
      "id_str" : "14914245",
      "id" : 14914245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669904637575757825",
  "text" : "RT @maverynthia: Though really myou_pub is good for it's long \"tweets\" in and of itself. No more trying to hack your thoughts up into 140 c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669291461049913344",
    "text" : "Though really myou_pub is good for it's long \"tweets\" in and of itself. No more trying to hack your thoughts up into 140 character bits.",
    "id" : 669291461049913344,
    "created_at" : "2015-11-24 23:08:13 +0000",
    "user" : {
      "name" : "Maverynthia",
      "screen_name" : "maverynthia",
      "protected" : false,
      "id_str" : "14914245",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796381231545888768\/oHubi4M1_normal.png",
      "id" : 14914245,
      "verified" : false
    }
  },
  "id" : 669904637575757825,
  "created_at" : "2015-11-26 15:44:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/5dQbcybqEb",
      "expanded_url" : "https:\/\/twitter.com\/gleneivey\/status\/669734473890578432",
      "display_url" : "twitter.com\/gleneivey\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669904355420717056",
  "text" : "NOOOOO...!! https:\/\/t.co\/5dQbcybqEb",
  "id" : 669904355420717056,
  "created_at" : "2015-11-26 15:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 3, 13 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gleneivey\/status\/669903218025992192\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zFIMEaUR5R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUv5bV0UEAA0N9U.png",
      "id_str" : "669903217702998016",
      "id" : 669903217702998016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUv5bV0UEAA0N9U.png",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/zFIMEaUR5R"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/U133ZBujIi",
      "expanded_url" : "http:\/\/myou.pub",
      "display_url" : "myou.pub"
    }, {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/XXhzhClBzg",
      "expanded_url" : "https:\/\/myou.pub\/b\/little-list-o-links\/",
      "display_url" : "myou.pub\/b\/little-list-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669904080844771328",
  "text" : "RT @gleneivey: https:\/\/t.co\/U133ZBujIi founding member drive open through Sunday https:\/\/t.co\/XXhzhClBzg (Please RT) https:\/\/t.co\/zFIMEaUR5R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gleneivey\/status\/669903218025992192\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/zFIMEaUR5R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUv5bV0UEAA0N9U.png",
        "id_str" : "669903217702998016",
        "id" : 669903217702998016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUv5bV0UEAA0N9U.png",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/zFIMEaUR5R"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/U133ZBujIi",
        "expanded_url" : "http:\/\/myou.pub",
        "display_url" : "myou.pub"
      }, {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/XXhzhClBzg",
        "expanded_url" : "https:\/\/myou.pub\/b\/little-list-o-links\/",
        "display_url" : "myou.pub\/b\/little-list-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669903218025992192",
    "text" : "https:\/\/t.co\/U133ZBujIi founding member drive open through Sunday https:\/\/t.co\/XXhzhClBzg (Please RT) https:\/\/t.co\/zFIMEaUR5R",
    "id" : 669903218025992192,
    "created_at" : "2015-11-26 15:39:08 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "protected" : false,
      "id_str" : "3083114561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693282117216636928\/88WEWoum_normal.jpg",
      "id" : 3083114561,
      "verified" : false
    }
  },
  "id" : 669904080844771328,
  "created_at" : "2015-11-26 15:42:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 3, 13 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/XXhzhClBzg",
      "expanded_url" : "https:\/\/myou.pub\/b\/little-list-o-links\/",
      "display_url" : "myou.pub\/b\/little-list-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669903833083039744",
  "text" : "RT @gleneivey: Hi, all. I've lots to be Thankful for, with all the support I've gotten for this https:\/\/t.co\/XXhzhClBzg Still need a few pe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/XXhzhClBzg",
        "expanded_url" : "https:\/\/myou.pub\/b\/little-list-o-links\/",
        "display_url" : "myou.pub\/b\/little-list-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669879630166253568",
    "text" : "Hi, all. I've lots to be Thankful for, with all the support I've gotten for this https:\/\/t.co\/XXhzhClBzg Still need a few people: Please RT",
    "id" : 669879630166253568,
    "created_at" : "2015-11-26 14:05:24 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "protected" : false,
      "id_str" : "3083114561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693282117216636928\/88WEWoum_normal.jpg",
      "id" : 3083114561,
      "verified" : false
    }
  },
  "id" : 669903833083039744,
  "created_at" : "2015-11-26 15:41:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Tashman",
      "screen_name" : "briantashman",
      "indices" : [ 3, 16 ],
      "id_str" : "348071022",
      "id" : 348071022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maddow",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/wCtlmB1WBO",
      "expanded_url" : "http:\/\/www.rightwingwatch.org\/content\/death-penalty-gays-literature-right-wing-conference",
      "display_url" : "rightwingwatch.org\/content\/death-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669726552112930816",
  "text" : "RT @briantashman: Here's the kill-the-gays pamphlet at the \"religious liberty\" summit featured on #Maddow tonight https:\/\/t.co\/wCtlmB1WBO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Maddow",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/wCtlmB1WBO",
        "expanded_url" : "http:\/\/www.rightwingwatch.org\/content\/death-penalty-gays-literature-right-wing-conference",
        "display_url" : "rightwingwatch.org\/content\/death-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669704082874085376",
    "text" : "Here's the kill-the-gays pamphlet at the \"religious liberty\" summit featured on #Maddow tonight https:\/\/t.co\/wCtlmB1WBO",
    "id" : 669704082874085376,
    "created_at" : "2015-11-26 02:27:50 +0000",
    "user" : {
      "name" : "Brian Tashman",
      "screen_name" : "briantashman",
      "protected" : false,
      "id_str" : "348071022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732306481853431809\/9zeLmDLj_normal.jpg",
      "id" : 348071022,
      "verified" : false
    }
  },
  "id" : 669726552112930816,
  "created_at" : "2015-11-26 03:57:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669725579084767232",
  "text" : "RT @johnpavlovitz: I'm thankful for all good, decent, compassionate people out there fighting for equality, peace, and justice in the world\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669721738134069253",
    "text" : "I'm thankful for all good, decent, compassionate people out there fighting for equality, peace, and justice in the world. Keep living love!",
    "id" : 669721738134069253,
    "created_at" : "2015-11-26 03:37:59 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 669725579084767232,
  "created_at" : "2015-11-26 03:53:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey",
      "screen_name" : "pari_passu",
      "indices" : [ 3, 14 ],
      "id_str" : "53019309",
      "id" : 53019309
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SyrianRefugees",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669709537788747777",
  "text" : "RT @pari_passu: Conservatives are so pissed about #SyrianRefugees they've temporarily forgotten about the gays. If we hurry, we might be ab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SyrianRefugees",
        "indices" : [ 34, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668964949666869248",
    "text" : "Conservatives are so pissed about #SyrianRefugees they've temporarily forgotten about the gays. If we hurry, we might be able to buy a cake.",
    "id" : 668964949666869248,
    "created_at" : "2015-11-24 01:30:47 +0000",
    "user" : {
      "name" : "Casey",
      "screen_name" : "pari_passu",
      "protected" : false,
      "id_str" : "53019309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779713327144460288\/4jZvsZoV_normal.jpg",
      "id" : 53019309,
      "verified" : false
    }
  },
  "id" : 669709537788747777,
  "created_at" : "2015-11-26 02:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blacklivesmatter",
      "indices" : [ 47, 64 ]
    }, {
      "text" : "stopbreakingthelaw",
      "indices" : [ 82, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669708970441969664",
  "text" : "RT @johnpavlovitz: A white guy responded to my #blacklivesmatter post by saying: \"#stopbreakingthelaw and no one will be killed. Simple.\" W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blacklivesmatter",
        "indices" : [ 28, 45 ]
      }, {
        "text" : "stopbreakingthelaw",
        "indices" : [ 63, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669708562160054274",
    "text" : "A white guy responded to my #blacklivesmatter post by saying: \"#stopbreakingthelaw and no one will be killed. Simple.\" Welcome to privilege.",
    "id" : 669708562160054274,
    "created_at" : "2015-11-26 02:45:38 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 669708970441969664,
  "created_at" : "2015-11-26 02:47:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/OPdyUhr0DV",
      "expanded_url" : "https:\/\/twitter.com\/Duke1CA\/status\/669705751351324672",
      "display_url" : "twitter.com\/Duke1CA\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669708677323104260",
  "text" : "o-O https:\/\/t.co\/OPdyUhr0DV",
  "id" : 669708677323104260,
  "created_at" : "2015-11-26 02:46:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 50, 67 ]
    }, {
      "text" : "LaquanMcDonald",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/OJwMICLto2",
      "expanded_url" : "http:\/\/wp.me\/p2h2UO-37N",
      "display_url" : "wp.me\/p2h2UO-37N"
    } ]
  },
  "geo" : { },
  "id_str" : "669708132705296384",
  "text" : "RT @johnpavlovitz: Why Do I Still Have To Explain #BlackLivesMatter To Other White People? https:\/\/t.co\/OJwMICLto2 #LaquanMcDonald",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 31, 48 ]
      }, {
        "text" : "LaquanMcDonald",
        "indices" : [ 96, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/OJwMICLto2",
        "expanded_url" : "http:\/\/wp.me\/p2h2UO-37N",
        "display_url" : "wp.me\/p2h2UO-37N"
      } ]
    },
    "geo" : { },
    "id_str" : "669703556254027776",
    "text" : "Why Do I Still Have To Explain #BlackLivesMatter To Other White People? https:\/\/t.co\/OJwMICLto2 #LaquanMcDonald",
    "id" : 669703556254027776,
    "created_at" : "2015-11-26 02:25:44 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 669708132705296384,
  "created_at" : "2015-11-26 02:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/ozpGnQ0Qkd",
      "expanded_url" : "https:\/\/twitter.com\/BlueDuPage\/status\/669702305957224448",
      "display_url" : "twitter.com\/BlueDuPage\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669703624566693889",
  "text" : "RT @Adenovir: WTF is \"Americanism\"? https:\/\/t.co\/ozpGnQ0Qkd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/ozpGnQ0Qkd",
        "expanded_url" : "https:\/\/twitter.com\/BlueDuPage\/status\/669702305957224448",
        "display_url" : "twitter.com\/BlueDuPage\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669702480356360192",
    "text" : "WTF is \"Americanism\"? https:\/\/t.co\/ozpGnQ0Qkd",
    "id" : 669702480356360192,
    "created_at" : "2015-11-26 02:21:28 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 669703624566693889,
  "created_at" : "2015-11-26 02:26:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 0, 10 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/HJ4YKIkVhX",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2415?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669698201985781760",
  "geo" : { },
  "id_str" : "669703444693823488",
  "in_reply_to_user_id" : 3083114561,
  "text" : "@gleneivey LIKE \/\/ discuss at https:\/\/t.co\/HJ4YKIkVhX",
  "id" : 669703444693823488,
  "in_reply_to_status_id" : 669698201985781760,
  "created_at" : "2015-11-26 02:25:18 +0000",
  "in_reply_to_screen_name" : "gleneivey",
  "in_reply_to_user_id_str" : "3083114561",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669686494198632448",
  "text" : "RT @benjamincorey: A: \"Refugees? We need to help our own at home!\"\nB: \"Well, let's do more to help our own at home then.\"\nA: \"Socialist!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669686045802438660",
    "text" : "A: \"Refugees? We need to help our own at home!\"\nB: \"Well, let's do more to help our own at home then.\"\nA: \"Socialist!\"",
    "id" : 669686045802438660,
    "created_at" : "2015-11-26 01:16:10 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 669686494198632448,
  "created_at" : "2015-11-26 01:17:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 3, 18 ],
      "id_str" : "582993732",
      "id" : 582993732
    }, {
      "name" : "Natalie Greenfield",
      "screen_name" : "NatalieGfield",
      "indices" : [ 44, 58 ],
      "id_str" : "2713070448",
      "id" : 2713070448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669683833059569664",
  "text" : "RT @DefendTheSheep: If Doug Wilson can make @NatalieGfield shut up, then he can get back to \"normal.\" Sorry, Doug, this is your new normal.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Natalie Greenfield",
        "screen_name" : "NatalieGfield",
        "indices" : [ 24, 38 ],
        "id_str" : "2713070448",
        "id" : 2713070448
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669683464308785152",
    "text" : "If Doug Wilson can make @NatalieGfield shut up, then he can get back to \"normal.\" Sorry, Doug, this is your new normal. She's not stopping.",
    "id" : 669683464308785152,
    "created_at" : "2015-11-26 01:05:54 +0000",
    "user" : {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "protected" : false,
      "id_str" : "582993732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719282831931781120\/BB0VrKyw_normal.jpg",
      "id" : 582993732,
      "verified" : false
    }
  },
  "id" : 669683833059569664,
  "created_at" : "2015-11-26 01:07:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "indices" : [ 3, 12 ],
      "id_str" : "265346131",
      "id" : 265346131
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/VpBniBbfOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv2fCUwAAfDEO.jpg",
      "id_str" : "669259370220273664",
      "id" : 669259370220273664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv2fCUwAAfDEO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VpBniBbfOd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/VpBniBbfOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv3BsUsAAmRmD.jpg",
      "id_str" : "669259379523235840",
      "id" : 669259379523235840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv3BsUsAAmRmD.jpg",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 721
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 721
      } ],
      "display_url" : "pic.twitter.com\/VpBniBbfOd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/VpBniBbfOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv3ocUwAAqysr.jpg",
      "id_str" : "669259389925113856",
      "id" : 669259389925113856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv3ocUwAAqysr.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 641
      } ],
      "display_url" : "pic.twitter.com\/VpBniBbfOd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/VpBniBbfOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv4HwUkAAPDnA.jpg",
      "id_str" : "669259398330486784",
      "id" : 669259398330486784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv4HwUkAAPDnA.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 662
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 662
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VpBniBbfOd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669683418536484864",
  "text" : "RT @iauaauoo: Morning Routine https:\/\/t.co\/VpBniBbfOd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/VpBniBbfOd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv2fCUwAAfDEO.jpg",
        "id_str" : "669259370220273664",
        "id" : 669259370220273664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv2fCUwAAfDEO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 697
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 697
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VpBniBbfOd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/VpBniBbfOd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv3BsUsAAmRmD.jpg",
        "id_str" : "669259379523235840",
        "id" : 669259379523235840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv3BsUsAAmRmD.jpg",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 721
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 721
        } ],
        "display_url" : "pic.twitter.com\/VpBniBbfOd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/VpBniBbfOd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv3ocUwAAqysr.jpg",
        "id_str" : "669259389925113856",
        "id" : 669259389925113856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv3ocUwAAqysr.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 641
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 641
        } ],
        "display_url" : "pic.twitter.com\/VpBniBbfOd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/669259406815596544\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/VpBniBbfOd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmv4HwUkAAPDnA.jpg",
        "id_str" : "669259398330486784",
        "id" : 669259398330486784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmv4HwUkAAPDnA.jpg",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VpBniBbfOd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669259406815596544",
    "text" : "Morning Routine https:\/\/t.co\/VpBniBbfOd",
    "id" : 669259406815596544,
    "created_at" : "2015-11-24 21:00:51 +0000",
    "user" : {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "protected" : false,
      "id_str" : "265346131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768291432213774336\/m7AAnnuF_normal.jpg",
      "id" : 265346131,
      "verified" : false
    }
  },
  "id" : 669683418536484864,
  "created_at" : "2015-11-26 01:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Se\u00E1n Gillespie",
      "screen_name" : "SeanDG",
      "indices" : [ 3, 10 ],
      "id_str" : "33839889",
      "id" : 33839889
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SeanDG\/status\/669071972542713856\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/7kxzMg8nYQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUkFYJEU8AAu9db.jpg",
      "id_str" : "669071931950297088",
      "id" : 669071931950297088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUkFYJEU8AAu9db.jpg",
      "sizes" : [ {
        "h" : 1156,
        "resize" : "fit",
        "w" : 1860
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 636,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7kxzMg8nYQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669668067228696576",
  "text" : "RT @SeanDG: The sparrows at my local cafe have figured out how to get into the sugar https:\/\/t.co\/7kxzMg8nYQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SeanDG\/status\/669071972542713856\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/7kxzMg8nYQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUkFYJEU8AAu9db.jpg",
        "id_str" : "669071931950297088",
        "id" : 669071931950297088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUkFYJEU8AAu9db.jpg",
        "sizes" : [ {
          "h" : 1156,
          "resize" : "fit",
          "w" : 1860
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7kxzMg8nYQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669071972542713856",
    "text" : "The sparrows at my local cafe have figured out how to get into the sugar https:\/\/t.co\/7kxzMg8nYQ",
    "id" : 669071972542713856,
    "created_at" : "2015-11-24 08:36:03 +0000",
    "user" : {
      "name" : "Se\u00E1n Gillespie",
      "screen_name" : "SeanDG",
      "protected" : false,
      "id_str" : "33839889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630334132019531776\/iVii-2TA_normal.jpg",
      "id" : 33839889,
      "verified" : false
    }
  },
  "id" : 669668067228696576,
  "created_at" : "2015-11-26 00:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/669621553504612352\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/GO53ugSYWt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUr5QRTU8AEDPOo.jpg",
      "id_str" : "669621552535629825",
      "id" : 669621552535629825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUr5QRTU8AEDPOo.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GO53ugSYWt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669621553504612352",
  "text" : "Bleach burn I think... https:\/\/t.co\/GO53ugSYWt",
  "id" : 669621553504612352,
  "created_at" : "2015-11-25 20:59:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Downpour.com",
      "screen_name" : "downpour_com",
      "indices" : [ 3, 16 ],
      "id_str" : "612905318",
      "id" : 612905318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669613656179671040",
  "text" : "RT @downpour_com: 50% off CD\u2019s &amp; MP3-CDS? Check\n\n50% off Digital Rentals? Check\n\nUp to 70% off downloads? Heck yeah! \n\n#BlackFriday! https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackFriday",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/CwhKEB6ff5",
        "expanded_url" : "http:\/\/bit.ly\/LYNe2q",
        "display_url" : "bit.ly\/LYNe2q"
      } ]
    },
    "geo" : { },
    "id_str" : "669612156560650240",
    "text" : "50% off CD\u2019s &amp; MP3-CDS? Check\n\n50% off Digital Rentals? Check\n\nUp to 70% off downloads? Heck yeah! \n\n#BlackFriday! https:\/\/t.co\/CwhKEB6ff5",
    "id" : 669612156560650240,
    "created_at" : "2015-11-25 20:22:33 +0000",
    "user" : {
      "name" : "Downpour.com",
      "screen_name" : "downpour_com",
      "protected" : false,
      "id_str" : "612905318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556139343933222912\/mmW8HJr4_normal.jpeg",
      "id" : 612905318,
      "verified" : false
    }
  },
  "id" : 669613656179671040,
  "created_at" : "2015-11-25 20:28:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/YggSRpsgG3",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2404",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669607125891444741",
  "text" : "horses like a good butt rub.. who knew??  lol ((grinningfromgivingbuttrub)) (from https:\/\/t.co\/YggSRpsgG3)",
  "id" : 669607125891444741,
  "created_at" : "2015-11-25 20:02:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eagle Eyes",
      "screen_name" : "EagleEyes15",
      "indices" : [ 3, 15 ],
      "id_str" : "593510048",
      "id" : 593510048
    }, {
      "name" : "ana cuyubamba",
      "screen_name" : "garciacg17",
      "indices" : [ 17, 28 ],
      "id_str" : "1463186438",
      "id" : 1463186438
    }, {
      "name" : "Ramphal Kataria",
      "screen_name" : "rpskataria",
      "indices" : [ 29, 40 ],
      "id_str" : "165007075",
      "id" : 165007075
    }, {
      "name" : "Wanda Nicholson",
      "screen_name" : "lynn_nich",
      "indices" : [ 41, 51 ],
      "id_str" : "2946858502",
      "id" : 2946858502
    }, {
      "name" : "BEBETOR",
      "screen_name" : "Bebetor3",
      "indices" : [ 52, 61 ],
      "id_str" : "2937055108",
      "id" : 2937055108
    }, {
      "name" : "\u0627\u0628\u064A\u0644 \u0627\u0644\u062C\u0645\u0627\u0644\u064A",
      "screen_name" : "abelalgamali",
      "indices" : [ 62, 75 ],
      "id_str" : "2154811641",
      "id" : 2154811641
    }, {
      "name" : "Sonia Grolla",
      "screen_name" : "Soniagrolla",
      "indices" : [ 76, 88 ],
      "id_str" : "1852941408",
      "id" : 1852941408
    }, {
      "name" : "Dr. Yaacoub Hallak",
      "screen_name" : "YNHallak",
      "indices" : [ 89, 98 ],
      "id_str" : "49794620",
      "id" : 49794620
    }, {
      "name" : "Alessandra Bedin",
      "screen_name" : "alex4jesus",
      "indices" : [ 99, 110 ],
      "id_str" : "444196482",
      "id" : 444196482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EagleEyes15\/status\/618130827340181504\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/G9APcZzIbe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJQKsGjUcAA4T6M.jpg",
      "id_str" : "618130801645875200",
      "id" : 618130801645875200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJQKsGjUcAA4T6M.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G9APcZzIbe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669606560352608257",
  "text" : "RT @EagleEyes15: @garciacg17 @rpskataria @lynn_nich @Bebetor3 @abelalgamali @Soniagrolla @YNHallak @alex4jesus http:\/\/t.co\/G9APcZzIbe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ana cuyubamba",
        "screen_name" : "garciacg17",
        "indices" : [ 0, 11 ],
        "id_str" : "1463186438",
        "id" : 1463186438
      }, {
        "name" : "Ramphal Kataria",
        "screen_name" : "rpskataria",
        "indices" : [ 12, 23 ],
        "id_str" : "165007075",
        "id" : 165007075
      }, {
        "name" : "Wanda Nicholson",
        "screen_name" : "lynn_nich",
        "indices" : [ 24, 34 ],
        "id_str" : "2946858502",
        "id" : 2946858502
      }, {
        "name" : "BEBETOR",
        "screen_name" : "Bebetor3",
        "indices" : [ 35, 44 ],
        "id_str" : "2937055108",
        "id" : 2937055108
      }, {
        "name" : "\u0627\u0628\u064A\u0644 \u0627\u0644\u062C\u0645\u0627\u0644\u064A",
        "screen_name" : "abelalgamali",
        "indices" : [ 45, 58 ],
        "id_str" : "2154811641",
        "id" : 2154811641
      }, {
        "name" : "Sonia Grolla",
        "screen_name" : "Soniagrolla",
        "indices" : [ 59, 71 ],
        "id_str" : "1852941408",
        "id" : 1852941408
      }, {
        "name" : "Dr. Yaacoub Hallak",
        "screen_name" : "YNHallak",
        "indices" : [ 72, 81 ],
        "id_str" : "49794620",
        "id" : 49794620
      }, {
        "name" : "Alessandra Bedin",
        "screen_name" : "alex4jesus",
        "indices" : [ 82, 93 ],
        "id_str" : "444196482",
        "id" : 444196482
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EagleEyes15\/status\/618130827340181504\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/G9APcZzIbe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJQKsGjUcAA4T6M.jpg",
        "id_str" : "618130801645875200",
        "id" : 618130801645875200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJQKsGjUcAA4T6M.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/G9APcZzIbe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "618128724765057024",
    "geo" : { },
    "id_str" : "618130827340181504",
    "in_reply_to_user_id" : 1463186438,
    "text" : "@garciacg17 @rpskataria @lynn_nich @Bebetor3 @abelalgamali @Soniagrolla @YNHallak @alex4jesus http:\/\/t.co\/G9APcZzIbe",
    "id" : 618130827340181504,
    "in_reply_to_status_id" : 618128724765057024,
    "created_at" : "2015-07-06 18:54:08 +0000",
    "in_reply_to_screen_name" : "garciacg17",
    "in_reply_to_user_id_str" : "1463186438",
    "user" : {
      "name" : "Eagle Eyes",
      "screen_name" : "EagleEyes15",
      "protected" : false,
      "id_str" : "593510048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775739123852279808\/rkAK5v4L_normal.jpg",
      "id" : 593510048,
      "verified" : false
    }
  },
  "id" : 669606560352608257,
  "created_at" : "2015-11-25 20:00:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "indices" : [ 3, 12 ],
      "id_str" : "3252798247",
      "id" : 3252798247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/lzkyrV4DCS",
      "expanded_url" : "http:\/\/myou.pub",
      "display_url" : "myou.pub"
    }, {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Y1NtayR8go",
      "expanded_url" : "https:\/\/myou.pub\/b\/the-story-so-far\/",
      "display_url" : "myou.pub\/b\/the-story-so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669542866922803200",
  "text" : "RT @myou_pub: You haven't signed up for https:\/\/t.co\/lzkyrV4DCS yet (ad-free, anti-abuse; https:\/\/t.co\/Y1NtayR8go) because...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/lzkyrV4DCS",
        "expanded_url" : "http:\/\/myou.pub",
        "display_url" : "myou.pub"
      }, {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/Y1NtayR8go",
        "expanded_url" : "https:\/\/myou.pub\/b\/the-story-so-far\/",
        "display_url" : "myou.pub\/b\/the-story-so\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669526167607574528",
    "text" : "You haven't signed up for https:\/\/t.co\/lzkyrV4DCS yet (ad-free, anti-abuse; https:\/\/t.co\/Y1NtayR8go) because...",
    "id" : 669526167607574528,
    "created_at" : "2015-11-25 14:40:52 +0000",
    "user" : {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "protected" : false,
      "id_str" : "3252798247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615024449092333568\/__RbHV43_normal.png",
      "id" : 3252798247,
      "verified" : false
    }
  },
  "id" : 669542866922803200,
  "created_at" : "2015-11-25 15:47:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "indices" : [ 3, 11 ],
      "id_str" : "995051",
      "id" : 995051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669528488852983809",
  "text" : "RT @dotglen: I feel like I haven't used the phrase \"World War 3\" enough recently. Turkey shots down Russian plane: bad. Russia \u2026 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/YXIiPcydHR",
        "expanded_url" : "https:\/\/myou.pub\/dotglen\/posts\/2389",
        "display_url" : "myou.pub\/dotglen\/posts\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669345473010896896",
    "text" : "I feel like I haven't used the phrase \"World War 3\" enough recently. Turkey shots down Russian plane: bad. Russia \u2026 https:\/\/t.co\/YXIiPcydHR",
    "id" : 669345473010896896,
    "created_at" : "2015-11-25 02:42:51 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "protected" : false,
      "id_str" : "995051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800932804150235136\/YvOXCpR8_normal.jpg",
      "id" : 995051,
      "verified" : false
    }
  },
  "id" : 669528488852983809,
  "created_at" : "2015-11-25 14:50:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhonda Ragsdale",
      "screen_name" : "profragsdale",
      "indices" : [ 3, 16 ],
      "id_str" : "16046375",
      "id" : 16046375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669364769544134656",
  "text" : "RT @profragsdale: I see many people getting so stressed out during holidays, weighed down by expectations to decorate, give, attend events",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669361513442836480",
    "text" : "I see many people getting so stressed out during holidays, weighed down by expectations to decorate, give, attend events",
    "id" : 669361513442836480,
    "created_at" : "2015-11-25 03:46:35 +0000",
    "user" : {
      "name" : "Rhonda Ragsdale",
      "screen_name" : "profragsdale",
      "protected" : false,
      "id_str" : "16046375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799696996432887809\/Na_c4_Da_normal.jpg",
      "id" : 16046375,
      "verified" : false
    }
  },
  "id" : 669364769544134656,
  "created_at" : "2015-11-25 03:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhonda Ragsdale",
      "screen_name" : "profragsdale",
      "indices" : [ 3, 16 ],
      "id_str" : "16046375",
      "id" : 16046375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669364410125852672",
  "text" : "RT @profragsdale: And if friends\/family refuse to accept that there r holiday activities and traditions we don't want to participate in, th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669362344653275137",
    "text" : "And if friends\/family refuse to accept that there r holiday activities and traditions we don't want to participate in, that's on them",
    "id" : 669362344653275137,
    "created_at" : "2015-11-25 03:49:53 +0000",
    "user" : {
      "name" : "Rhonda Ragsdale",
      "screen_name" : "profragsdale",
      "protected" : false,
      "id_str" : "16046375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799696996432887809\/Na_c4_Da_normal.jpg",
      "id" : 16046375,
      "verified" : false
    }
  },
  "id" : 669364410125852672,
  "created_at" : "2015-11-25 03:58:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhonda Ragsdale",
      "screen_name" : "profragsdale",
      "indices" : [ 3, 16 ],
      "id_str" : "16046375",
      "id" : 16046375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669364343943929857",
  "text" : "RT @profragsdale: We have choices to decline to participate in holiday activities that stress us out or don't work for us - friends\/family \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669362096002301952",
    "text" : "We have choices to decline to participate in holiday activities that stress us out or don't work for us - friends\/family will get over it",
    "id" : 669362096002301952,
    "created_at" : "2015-11-25 03:48:54 +0000",
    "user" : {
      "name" : "Rhonda Ragsdale",
      "screen_name" : "profragsdale",
      "protected" : false,
      "id_str" : "16046375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799696996432887809\/Na_c4_Da_normal.jpg",
      "id" : 16046375,
      "verified" : false
    }
  },
  "id" : 669364343943929857,
  "created_at" : "2015-11-25 03:57:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/669362571812601856\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/u173q8XAtB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUoNtmXUAAE9g3z.jpg",
      "id_str" : "669362571661541377",
      "id" : 669362571661541377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUoNtmXUAAE9g3z.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u173q8XAtB"
    } ],
    "hashtags" : [ {
      "text" : "FullMoon",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669364030868430850",
  "text" : "RT @Chickypoo333: My view this evening \n#FullMoon https:\/\/t.co\/u173q8XAtB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/669362571812601856\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/u173q8XAtB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUoNtmXUAAE9g3z.jpg",
        "id_str" : "669362571661541377",
        "id" : 669362571661541377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUoNtmXUAAE9g3z.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/u173q8XAtB"
      } ],
      "hashtags" : [ {
        "text" : "FullMoon",
        "indices" : [ 22, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669362571812601856",
    "text" : "My view this evening \n#FullMoon https:\/\/t.co\/u173q8XAtB",
    "id" : 669362571812601856,
    "created_at" : "2015-11-25 03:50:47 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 669364030868430850,
  "created_at" : "2015-11-25 03:56:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil",
      "screen_name" : "SheppeyWildlife",
      "indices" : [ 3, 19 ],
      "id_str" : "118345168",
      "id" : 118345168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SheppeyWildlife\/status\/668494115353554945\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/igVzg6Heoi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUb32uNXIAI5IdQ.jpg",
      "id_str" : "668494114200166402",
      "id" : 668494114200166402,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUb32uNXIAI5IdQ.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/igVzg6Heoi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669362403096854528",
  "text" : "RT @SheppeyWildlife: I do like watching the sun go down. Tonight was the first reasonable sunset for a week or two. https:\/\/t.co\/igVzg6Heoi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SheppeyWildlife\/status\/668494115353554945\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/igVzg6Heoi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUb32uNXIAI5IdQ.jpg",
        "id_str" : "668494114200166402",
        "id" : 668494114200166402,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUb32uNXIAI5IdQ.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/igVzg6Heoi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668494115353554945",
    "text" : "I do like watching the sun go down. Tonight was the first reasonable sunset for a week or two. https:\/\/t.co\/igVzg6Heoi",
    "id" : 668494115353554945,
    "created_at" : "2015-11-22 18:19:51 +0000",
    "user" : {
      "name" : "Phil",
      "screen_name" : "SheppeyWildlife",
      "protected" : false,
      "id_str" : "118345168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780960937\/Barn_Owl_normal.JPG",
      "id" : 118345168,
      "verified" : false
    }
  },
  "id" : 669362403096854528,
  "created_at" : "2015-11-25 03:50:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil",
      "screen_name" : "SheppeyWildlife",
      "indices" : [ 3, 19 ],
      "id_str" : "118345168",
      "id" : 118345168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SheppeyWildlife\/status\/667819015398494208\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/9CX5mA5mbP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUSR2uMXIAAPI9e.jpg",
      "id_str" : "667819014056517632",
      "id" : 667819014056517632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUSR2uMXIAAPI9e.jpg",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9CX5mA5mbP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669361725045649408",
  "text" : "RT @SheppeyWildlife: A Sheppey Stonechat. https:\/\/t.co\/9CX5mA5mbP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SheppeyWildlife\/status\/667819015398494208\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/9CX5mA5mbP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUSR2uMXIAAPI9e.jpg",
        "id_str" : "667819014056517632",
        "id" : 667819014056517632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUSR2uMXIAAPI9e.jpg",
        "sizes" : [ {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 726,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 851,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9CX5mA5mbP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667819015398494208",
    "text" : "A Sheppey Stonechat. https:\/\/t.co\/9CX5mA5mbP",
    "id" : 667819015398494208,
    "created_at" : "2015-11-20 21:37:15 +0000",
    "user" : {
      "name" : "Phil",
      "screen_name" : "SheppeyWildlife",
      "protected" : false,
      "id_str" : "118345168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780960937\/Barn_Owl_normal.JPG",
      "id" : 118345168,
      "verified" : false
    }
  },
  "id" : 669361725045649408,
  "created_at" : "2015-11-25 03:47:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTQ",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Of6E8gXtSR",
      "expanded_url" : "http:\/\/www.yourholidaymom.com\/",
      "display_url" : "yourholidaymom.com"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/yRyOSfv4hw",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2392",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669349913361158144",
  "text" : "nice! &gt; for #LGBTQ - supportive virtual home for the holidays https:\/\/t.co\/Of6E8gXtSR  (from https:\/\/t.co\/yRyOSfv4hw)",
  "id" : 669349913361158144,
  "created_at" : "2015-11-25 03:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatline",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/RUJKuvH1eq",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2388",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669334008702996480",
  "text" : "\"I am deeply regretting even pulling this thread.\" Dean on The Grinder #greatline (from https:\/\/t.co\/RUJKuvH1eq)",
  "id" : 669334008702996480,
  "created_at" : "2015-11-25 01:57:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CCTV IDIOTS",
      "screen_name" : "cctv_idiots",
      "indices" : [ 58, 70 ],
      "id_str" : "2960062013",
      "id" : 2960062013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/LFT2xXPDbQ",
      "expanded_url" : "https:\/\/vine.co\/v\/iBbWnpgbnx1",
      "display_url" : "vine.co\/v\/iBbWnpgbnx1"
    } ]
  },
  "geo" : { },
  "id_str" : "669319756604940288",
  "text" : "RT @_Ali_Mac: A little light relief and cuteness.        \"@cctv_idiots: They think he's a small cow \uD83D\uDE02 https:\/\/t.co\/LFT2xXPDbQ\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CCTV IDIOTS",
        "screen_name" : "cctv_idiots",
        "indices" : [ 44, 56 ],
        "id_str" : "2960062013",
        "id" : 2960062013
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/LFT2xXPDbQ",
        "expanded_url" : "https:\/\/vine.co\/v\/iBbWnpgbnx1",
        "display_url" : "vine.co\/v\/iBbWnpgbnx1"
      } ]
    },
    "geo" : { },
    "id_str" : "665478370088648705",
    "text" : "A little light relief and cuteness.        \"@cctv_idiots: They think he's a small cow \uD83D\uDE02 https:\/\/t.co\/LFT2xXPDbQ\"",
    "id" : 665478370088648705,
    "created_at" : "2015-11-14 10:36:22 +0000",
    "user" : {
      "name" : "\uD83D\uDC3EAli\uD83D\uDC3E",
      "screen_name" : "Alimac0701",
      "protected" : false,
      "id_str" : "3433238446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793735040681336832\/tfGCFBC3_normal.jpg",
      "id" : 3433238446,
      "verified" : false
    }
  },
  "id" : 669319756604940288,
  "created_at" : "2015-11-25 01:00:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ailsa Craig",
      "screen_name" : "AilsaCraigrock",
      "indices" : [ 34, 49 ],
      "id_str" : "2738153027",
      "id" : 2738153027
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/_Ali_Mac\/status\/667503047283769344\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/qJ0QMuni46",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNyetpWwAAAjle.jpg",
      "id_str" : "667503041755660288",
      "id" : 667503041755660288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNyetpWwAAAjle.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qJ0QMuni46"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669319434721431552",
  "text" : "RT @_Ali_Mac: WOW!!!! Orca Whales @AilsaCraigrock awesomeness ! https:\/\/t.co\/qJ0QMuni46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ailsa Craig",
        "screen_name" : "AilsaCraigrock",
        "indices" : [ 20, 35 ],
        "id_str" : "2738153027",
        "id" : 2738153027
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_Ali_Mac\/status\/667503047283769344\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/qJ0QMuni46",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNyetpWwAAAjle.jpg",
        "id_str" : "667503041755660288",
        "id" : 667503041755660288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNyetpWwAAAjle.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qJ0QMuni46"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667503047283769344",
    "text" : "WOW!!!! Orca Whales @AilsaCraigrock awesomeness ! https:\/\/t.co\/qJ0QMuni46",
    "id" : 667503047283769344,
    "created_at" : "2015-11-20 00:41:42 +0000",
    "user" : {
      "name" : "\uD83D\uDC3EAli\uD83D\uDC3E",
      "screen_name" : "Alimac0701",
      "protected" : false,
      "id_str" : "3433238446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793735040681336832\/tfGCFBC3_normal.jpg",
      "id" : 3433238446,
      "verified" : false
    }
  },
  "id" : 669319434721431552,
  "created_at" : "2015-11-25 00:59:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/dVClTpTB7P",
      "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/669310621238878208",
      "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/XuTimzoYms",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2386",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669318244667297792",
  "text" : "why are they never helped after shot??? https:\/\/t.co\/dVClTpTB7P (from https:\/\/t.co\/XuTimzoYms)",
  "id" : 669318244667297792,
  "created_at" : "2015-11-25 00:54:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paula Abdul",
      "screen_name" : "PaulaAbdul",
      "indices" : [ 3, 14 ],
      "id_str" : "27750488",
      "id" : 27750488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/vEHzTMhCg1",
      "expanded_url" : "http:\/\/on.mash.to\/1QsHJHi",
      "display_url" : "on.mash.to\/1QsHJHi"
    } ]
  },
  "geo" : { },
  "id_str" : "669286850494877696",
  "text" : "RT @PaulaAbdul: Can you see the sheep in this photo? This blew my mind lol! https:\/\/t.co\/vEHzTMhCg1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/vEHzTMhCg1",
        "expanded_url" : "http:\/\/on.mash.to\/1QsHJHi",
        "display_url" : "on.mash.to\/1QsHJHi"
      } ]
    },
    "geo" : { },
    "id_str" : "669251978774642689",
    "text" : "Can you see the sheep in this photo? This blew my mind lol! https:\/\/t.co\/vEHzTMhCg1",
    "id" : 669251978774642689,
    "created_at" : "2015-11-24 20:31:20 +0000",
    "user" : {
      "name" : "Paula Abdul",
      "screen_name" : "PaulaAbdul",
      "protected" : false,
      "id_str" : "27750488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657309439033118721\/_cf4v0qq_normal.jpg",
      "id" : 27750488,
      "verified" : true
    }
  },
  "id" : 669286850494877696,
  "created_at" : "2015-11-24 22:49:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Swanwatch",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "Loving",
      "indices" : [ 113, 120 ]
    }, {
      "text" : "muteswans",
      "indices" : [ 121, 131 ]
    }, {
      "text" : "RT",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669235975768420352",
  "text" : "RT @Swanwhisperer: One Man One Caring and Respecting Person and thats me the Swan Whisperer with solo #Swanwatch #Loving #muteswans #RT htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/669235317086531584\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rqSrQ2iChc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmZ-VEWwAQjNtX.jpg",
        "id_str" : "669235315727581188",
        "id" : 669235315727581188,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmZ-VEWwAQjNtX.jpg",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/rqSrQ2iChc"
      } ],
      "hashtags" : [ {
        "text" : "Swanwatch",
        "indices" : [ 83, 93 ]
      }, {
        "text" : "Loving",
        "indices" : [ 94, 101 ]
      }, {
        "text" : "muteswans",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "RT",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669235317086531584",
    "text" : "One Man One Caring and Respecting Person and thats me the Swan Whisperer with solo #Swanwatch #Loving #muteswans #RT https:\/\/t.co\/rqSrQ2iChc",
    "id" : 669235317086531584,
    "created_at" : "2015-11-24 19:25:08 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 669235975768420352,
  "created_at" : "2015-11-24 19:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 0, 14 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/m8fxBTwSwc",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2377?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669232506714103808",
  "geo" : { },
  "id_str" : "669233697158098944",
  "in_reply_to_user_id" : 272369448,
  "text" : "@Swanwhisperer How cool is that? surrounded by swans! so lovely. im so jealous..lol. \/\/ discuss at https:\/\/t.co\/m8fxBTwSwc",
  "id" : 669233697158098944,
  "in_reply_to_status_id" : 669232506714103808,
  "created_at" : "2015-11-24 19:18:41 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 0, 10 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/PUKBhfSVHw",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2375?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669219994446655488",
  "geo" : { },
  "id_str" : "669221910807343105",
  "in_reply_to_user_id" : 3083114561,
  "text" : "@gleneivey no.. at least not this one.. but looks interesting! \/\/ discuss at https:\/\/t.co\/PUKBhfSVHw",
  "id" : 669221910807343105,
  "in_reply_to_status_id" : 669219994446655488,
  "created_at" : "2015-11-24 18:31:51 +0000",
  "in_reply_to_screen_name" : "gleneivey",
  "in_reply_to_user_id_str" : "3083114561",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/9Jdmee0Z9N",
      "expanded_url" : "http:\/\/huff.to\/1Hj6XVV",
      "display_url" : "huff.to\/1Hj6XVV"
    } ]
  },
  "geo" : { },
  "id_str" : "669218738248540160",
  "text" : "RT @HuffPostWeird: See a real life robot chicken as James the hen rides a Roomba https:\/\/t.co\/9Jdmee0Z9N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/9Jdmee0Z9N",
        "expanded_url" : "http:\/\/huff.to\/1Hj6XVV",
        "display_url" : "huff.to\/1Hj6XVV"
      } ]
    },
    "geo" : { },
    "id_str" : "669216672906113024",
    "text" : "See a real life robot chicken as James the hen rides a Roomba https:\/\/t.co\/9Jdmee0Z9N",
    "id" : 669216672906113024,
    "created_at" : "2015-11-24 18:11:02 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 669218738248540160,
  "created_at" : "2015-11-24 18:19:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 0, 10 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    }, {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "indices" : [ 47, 56 ],
      "id_str" : "3252798247",
      "id" : 3252798247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/T9PPY83WMX",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2371?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669216661761687552",
  "geo" : { },
  "id_str" : "669217553676263424",
  "in_reply_to_user_id" : 3083114561,
  "text" : "@gleneivey alex is awesome. that's how I found @myou_pub \/\/ discuss at https:\/\/t.co\/T9PPY83WMX",
  "id" : 669217553676263424,
  "in_reply_to_status_id" : 669216661761687552,
  "created_at" : "2015-11-24 18:14:32 +0000",
  "in_reply_to_screen_name" : "gleneivey",
  "in_reply_to_user_id_str" : "3083114561",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "indices" : [ 24, 32 ],
      "id_str" : "995051",
      "id" : 995051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/SyaNV2yfei",
      "expanded_url" : "http:\/\/myou.pub",
      "display_url" : "myou.pub"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/1GCPV02fkD",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2369",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669216000169013248",
  "text" : "ohh.. like the new look @dotglen on https:\/\/t.co\/SyaNV2yfei .. not sure whats diff but looks diff..lol (my brain is\u2026 https:\/\/t.co\/1GCPV02fkD",
  "id" : 669216000169013248,
  "created_at" : "2015-11-24 18:08:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kej",
      "screen_name" : "Ogmin",
      "indices" : [ 0, 6 ],
      "id_str" : "18020718",
      "id" : 18020718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "669199121035739136",
  "geo" : { },
  "id_str" : "669200398150934528",
  "in_reply_to_user_id" : 18020718,
  "text" : "@Ogmin hmm.. ((pondersthis))",
  "id" : 669200398150934528,
  "in_reply_to_status_id" : 669199121035739136,
  "created_at" : "2015-11-24 17:06:22 +0000",
  "in_reply_to_screen_name" : "Ogmin",
  "in_reply_to_user_id_str" : "18020718",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "indices" : [ 0, 8 ],
      "id_str" : "995051",
      "id" : 995051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/PTlqYWcL6Q",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2367?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "669196551512719360",
  "geo" : { },
  "id_str" : "669198536559366144",
  "in_reply_to_user_id" : 995051,
  "text" : "@dotglen can the notifications go into a separate panel? instead of at bottom of tweet panel. be annoying to dismi\u2026 https:\/\/t.co\/PTlqYWcL6Q",
  "id" : 669198536559366144,
  "in_reply_to_status_id" : 669196551512719360,
  "created_at" : "2015-11-24 16:58:58 +0000",
  "in_reply_to_screen_name" : "dotglen",
  "in_reply_to_user_id_str" : "995051",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "indices" : [ 3, 11 ],
      "id_str" : "995051",
      "id" : 995051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/nAjVGmpw71",
      "expanded_url" : "http:\/\/myou.pub",
      "display_url" : "myou.pub"
    } ]
  },
  "geo" : { },
  "id_str" : "669196714146979840",
  "text" : "RT @dotglen: Twitter integration! Making your move to https:\/\/t.co\/nAjVGmpw71 easier since July. (tell your friends....) https:\/\/t.co\/OyGky\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/nAjVGmpw71",
        "expanded_url" : "http:\/\/myou.pub",
        "display_url" : "myou.pub"
      }, {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/OyGkyB3xrf",
        "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/669195440110198784",
        "display_url" : "twitter.com\/moosebegab\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669196551512719360",
    "text" : "Twitter integration! Making your move to https:\/\/t.co\/nAjVGmpw71 easier since July. (tell your friends....) https:\/\/t.co\/OyGkyB3xrf",
    "id" : 669196551512719360,
    "created_at" : "2015-11-24 16:51:05 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "protected" : false,
      "id_str" : "995051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800932804150235136\/YvOXCpR8_normal.jpg",
      "id" : 995051,
      "verified" : false
    }
  },
  "id" : 669196714146979840,
  "created_at" : "2015-11-24 16:51:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "indices" : [ 81, 90 ],
      "id_str" : "3252798247",
      "id" : 3252798247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/SyaNV2yfei",
      "expanded_url" : "http:\/\/myou.pub",
      "display_url" : "myou.pub"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/W4eUfhPxw4",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2366",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669195440110198784",
  "text" : "very cool.. got notification of new twitter followers on https:\/\/t.co\/SyaNV2yfei @myou_pub (from https:\/\/t.co\/W4eUfhPxw4)",
  "id" : 669195440110198784,
  "created_at" : "2015-11-24 16:46:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "squirrelbutts",
      "screen_name" : "keisisqrl",
      "indices" : [ 3, 13 ],
      "id_str" : "1484341",
      "id" : 1484341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669188966856433664",
  "text" : "RT @keisisqrl: \"So for all the people who are still confused at this point, they proved what \u2018all lives matter\u2019 meant.\" https:\/\/t.co\/5r00EG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/5r00EG39bA",
        "expanded_url" : "http:\/\/thinkprogress.org\/politics\/2015\/11\/23\/3725051\/trump-protester-beaten\/",
        "display_url" : "thinkprogress.org\/politics\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669157565473775616",
    "text" : "\"So for all the people who are still confused at this point, they proved what \u2018all lives matter\u2019 meant.\" https:\/\/t.co\/5r00EG39bA",
    "id" : 669157565473775616,
    "created_at" : "2015-11-24 14:16:10 +0000",
    "user" : {
      "name" : "squirrelbutts",
      "screen_name" : "keisisqrl",
      "protected" : false,
      "id_str" : "1484341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798596105780875264\/eOEFlLP4_normal.jpg",
      "id" : 1484341,
      "verified" : false
    }
  },
  "id" : 669188966856433664,
  "created_at" : "2015-11-24 16:20:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 3, 13 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/QKDL5Atf1W",
      "expanded_url" : "https:\/\/myou.pub\/b\/the-story-so-far\/",
      "display_url" : "myou.pub\/b\/the-story-so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669187806581948416",
  "text" : "RT @gleneivey: Good: yesterday was our most-signups day yet. Bad: only 7 days left &amp; each must be bigger https:\/\/t.co\/QKDL5Atf1W https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/QKDL5Atf1W",
        "expanded_url" : "https:\/\/myou.pub\/b\/the-story-so-far\/",
        "display_url" : "myou.pub\/b\/the-story-so\u2026"
      }, {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/glnJkYyvrq",
        "expanded_url" : "https:\/\/twitter.com\/joyfuldroid\/status\/668526939523710977",
        "display_url" : "twitter.com\/joyfuldroid\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668902842657173504",
    "text" : "Good: yesterday was our most-signups day yet. Bad: only 7 days left &amp; each must be bigger https:\/\/t.co\/QKDL5Atf1W https:\/\/t.co\/glnJkYyvrq",
    "id" : 668902842657173504,
    "created_at" : "2015-11-23 21:23:59 +0000",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "protected" : false,
      "id_str" : "3083114561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693282117216636928\/88WEWoum_normal.jpg",
      "id" : 3083114561,
      "verified" : false
    }
  },
  "id" : 669187806581948416,
  "created_at" : "2015-11-24 16:16:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Tabor",
      "screen_name" : "AbbyTabor",
      "indices" : [ 3, 13 ],
      "id_str" : "361129276",
      "id" : 361129276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669185019114582017",
  "text" : "RT @AbbyTabor: Wow, this misunderstanding never occurred to me. So instead of \u201Cantibiotic resistance\u201D -&gt; \"drug-resistant infection\u201D https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Hdcx0LAPP7",
        "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/666275907796123648",
        "display_url" : "twitter.com\/edyong209\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666283354392649728",
    "text" : "Wow, this misunderstanding never occurred to me. So instead of \u201Cantibiotic resistance\u201D -&gt; \"drug-resistant infection\u201D https:\/\/t.co\/Hdcx0LAPP7",
    "id" : 666283354392649728,
    "created_at" : "2015-11-16 15:55:05 +0000",
    "user" : {
      "name" : "Abby Tabor",
      "screen_name" : "AbbyTabor",
      "protected" : false,
      "id_str" : "361129276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2221341328\/DSCN1981_normal.JPG",
      "id" : 361129276,
      "verified" : false
    }
  },
  "id" : 669185019114582017,
  "created_at" : "2015-11-24 16:05:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/rTqCMJoPt6",
      "expanded_url" : "https:\/\/twitter.com\/bend_time\/status\/669144701845397504",
      "display_url" : "twitter.com\/bend_time\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669184559951515649",
  "text" : "I hope I don't miss it!! : ) https:\/\/t.co\/rTqCMJoPt6",
  "id" : 669184559951515649,
  "created_at" : "2015-11-24 16:03:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "46213956",
      "id" : 46213956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669184165645000706",
  "text" : "RT @JamilSmith: White men with bulletproof vests shot four civil rights protesters in Minneapolis, and I'm supposed to be more scared of a \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669032719482011648",
    "text" : "White men with bulletproof vests shot four civil rights protesters in Minneapolis, and I'm supposed to be more scared of a Syrian refugee.",
    "id" : 669032719482011648,
    "created_at" : "2015-11-24 06:00:05 +0000",
    "user" : {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "protected" : false,
      "id_str" : "46213956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760482723853168644\/ndDX2s1z_normal.jpg",
      "id" : 46213956,
      "verified" : true
    }
  },
  "id" : 669184165645000706,
  "created_at" : "2015-11-24 16:01:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmandaBlackburn",
      "indices" : [ 22, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/BcjVB1fkDr",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2359",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668938409344274432",
  "text" : "Anyone been following #AmandaBlackburn murder? I watched some of the vids by the husband and he does seem off. \u2026 https:\/\/t.co\/BcjVB1fkDr",
  "id" : 668938409344274432,
  "created_at" : "2015-11-23 23:45:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/RxRX3bKQiT",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.yeuyeuh.niakigame&hl=en",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    }, {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/uZbFPbEl9H",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2358",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668925701521719296",
  "text" : "obsessed with playing Niaki game https:\/\/t.co\/RxRX3bKQiT (from https:\/\/t.co\/uZbFPbEl9H)",
  "id" : 668925701521719296,
  "created_at" : "2015-11-23 22:54:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechnicallyRon",
      "screen_name" : "TechnicallyRon",
      "indices" : [ 3, 18 ],
      "id_str" : "108140114",
      "id" : 108140114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668899717909258240",
  "text" : "RT @TechnicallyRon: Education?\n\"Sorry no money for that\"\nHealth care?\n\"Sorry no money for that\"\nHelping the poor? \n\"Sorry no money for that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668828327608762368",
    "text" : "Education?\n\"Sorry no money for that\"\nHealth care?\n\"Sorry no money for that\"\nHelping the poor? \n\"Sorry no money for that\"\nWar?\n\"OH MY YES\"",
    "id" : 668828327608762368,
    "created_at" : "2015-11-23 16:27:54 +0000",
    "user" : {
      "name" : "TechnicallyRon",
      "screen_name" : "TechnicallyRon",
      "protected" : false,
      "id_str" : "108140114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683972064781463552\/94h64ztN_normal.jpg",
      "id" : 108140114,
      "verified" : true
    }
  },
  "id" : 668899717909258240,
  "created_at" : "2015-11-23 21:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve McEllistrem",
      "screen_name" : "SteveMcEllis",
      "indices" : [ 0, 13 ],
      "id_str" : "2512494217",
      "id" : 2512494217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "philosophy",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Es8N6972lA",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2351?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "668885751753379840",
  "geo" : { },
  "id_str" : "668886886698647558",
  "in_reply_to_user_id" : 2512494217,
  "text" : "@SteveMcEllis now that's something to ponder.. hmm.. #philosophy \/\/ discuss at https:\/\/t.co\/Es8N6972lA",
  "id" : 668886886698647558,
  "in_reply_to_status_id" : 668885751753379840,
  "created_at" : "2015-11-23 20:20:35 +0000",
  "in_reply_to_screen_name" : "SteveMcEllis",
  "in_reply_to_user_id_str" : "2512494217",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/1jVSY2wzWV",
      "expanded_url" : "https:\/\/twitter.com\/dotglen\/status\/667854410093957121",
      "display_url" : "twitter.com\/dotglen\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668886002585493504",
  "text" : "im checking it out. could be interesting. im same username as here. #socialmedia  https:\/\/t.co\/1jVSY2wzWV",
  "id" : 668886002585493504,
  "created_at" : "2015-11-23 20:17:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/xCQNXDVr7v",
      "expanded_url" : "http:\/\/myou.pub\/b\/welcome-to-the-internet\/",
      "display_url" : "myou.pub\/b\/welcome-to-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668881014576562176",
  "text" : "yup. good post. &gt; Welcome to the Internet! https:\/\/t.co\/xCQNXDVr7v",
  "id" : 668881014576562176,
  "created_at" : "2015-11-23 19:57:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/vwnVCOI89a",
      "expanded_url" : "https:\/\/twitter.com\/dotglen\/status\/668806988269096960",
      "display_url" : "twitter.com\/dotglen\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668859436275015680",
  "text" : "RT @onealexharms: Myou could be a cool replacement for twitter. It's getting better all the time. https:\/\/t.co\/vwnVCOI89a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/vwnVCOI89a",
        "expanded_url" : "https:\/\/twitter.com\/dotglen\/status\/668806988269096960",
        "display_url" : "twitter.com\/dotglen\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668820119003332608",
    "text" : "Myou could be a cool replacement for twitter. It's getting better all the time. https:\/\/t.co\/vwnVCOI89a",
    "id" : 668820119003332608,
    "created_at" : "2015-11-23 15:55:17 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 668859436275015680,
  "created_at" : "2015-11-23 18:31:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668820119003332608",
  "geo" : { },
  "id_str" : "668859388111790080",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms i like the idea that its integrated w twitter so not starting all over again.. ((takingalookat it))",
  "id" : 668859388111790080,
  "in_reply_to_status_id" : 668820119003332608,
  "created_at" : "2015-11-23 18:31:19 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 4, 8 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/6S6SFbxZQ0",
      "expanded_url" : "http:\/\/n.pr\/1JLdqnk",
      "display_url" : "n.pr\/1JLdqnk"
    } ]
  },
  "geo" : { },
  "id_str" : "668855781484273664",
  "text" : "Via @NPR: A Sense Of Self: What Happens When Your Brain Says You Don't Exist https:\/\/t.co\/6S6SFbxZQ0",
  "id" : 668855781484273664,
  "created_at" : "2015-11-23 18:16:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/668621241952182272\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/bnisssCOAB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdrehbWoAAo4IS.jpg",
      "id_str" : "668621241801154560",
      "id" : 668621241801154560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdrehbWoAAo4IS.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/bnisssCOAB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668628121940303873",
  "text" : "RT @SciencePorn: Both were filled at the same time with the same water, only one had oysters. https:\/\/t.co\/bnisssCOAB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/668621241952182272\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/bnisssCOAB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdrehbWoAAo4IS.jpg",
        "id_str" : "668621241801154560",
        "id" : 668621241801154560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdrehbWoAAo4IS.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/bnisssCOAB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668621241952182272",
    "text" : "Both were filled at the same time with the same water, only one had oysters. https:\/\/t.co\/bnisssCOAB",
    "id" : 668621241952182272,
    "created_at" : "2015-11-23 02:45:01 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 668628121940303873,
  "created_at" : "2015-11-23 03:12:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sady Doyle",
      "screen_name" : "sadydoyle",
      "indices" : [ 3, 13 ],
      "id_str" : "17634365",
      "id" : 17634365
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sadydoyle\/status\/668615333712916480\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/NoT5JZmKUI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdmGlaWoAAtDDa.jpg",
      "id_str" : "668615332995702784",
      "id" : 668615332995702784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdmGlaWoAAtDDa.jpg",
      "sizes" : [ {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 529
      } ],
      "display_url" : "pic.twitter.com\/NoT5JZmKUI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/sadydoyle\/status\/668615333712916480\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/NoT5JZmKUI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdmGkwW4AQxvxl.jpg",
      "id_str" : "668615332819558404",
      "id" : 668615332819558404,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdmGkwW4AQxvxl.jpg",
      "sizes" : [ {
        "h" : 195,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NoT5JZmKUI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668625290868998149",
  "text" : "RT @sadydoyle: People haaaaated Eleanor Roosevelt, too. For example, on the internment camps: https:\/\/t.co\/NoT5JZmKUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sadydoyle\/status\/668615333712916480\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/NoT5JZmKUI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdmGlaWoAAtDDa.jpg",
        "id_str" : "668615332995702784",
        "id" : 668615332995702784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdmGlaWoAAtDDa.jpg",
        "sizes" : [ {
          "h" : 114,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 529
        } ],
        "display_url" : "pic.twitter.com\/NoT5JZmKUI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/sadydoyle\/status\/668615333712916480\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/NoT5JZmKUI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdmGkwW4AQxvxl.jpg",
        "id_str" : "668615332819558404",
        "id" : 668615332819558404,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdmGkwW4AQxvxl.jpg",
        "sizes" : [ {
          "h" : 195,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 122,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NoT5JZmKUI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668615333712916480",
    "text" : "People haaaaated Eleanor Roosevelt, too. For example, on the internment camps: https:\/\/t.co\/NoT5JZmKUI",
    "id" : 668615333712916480,
    "created_at" : "2015-11-23 02:21:32 +0000",
    "user" : {
      "name" : "Sady Doyle",
      "screen_name" : "sadydoyle",
      "protected" : false,
      "id_str" : "17634365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713844299516022785\/0I1VPE1e_normal.jpg",
      "id" : 17634365,
      "verified" : true
    }
  },
  "id" : 668625290868998149,
  "created_at" : "2015-11-23 03:01:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "indices" : [ 3, 16 ],
      "id_str" : "530935629",
      "id" : 530935629
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/0lET1jD1SV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqKqfUYAAU_Yc.jpg",
      "id_str" : "668619801124691968",
      "id" : 668619801124691968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqKqfUYAAU_Yc.jpg",
      "sizes" : [ {
        "h" : 1266,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1266,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0lET1jD1SV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/0lET1jD1SV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqGKNUsAAzsyt.jpg",
      "id_str" : "668619723739803648",
      "id" : 668619723739803648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqGKNUsAAzsyt.jpg",
      "sizes" : [ {
        "h" : 1380,
        "resize" : "fit",
        "w" : 861
      }, {
        "h" : 962,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1380,
        "resize" : "fit",
        "w" : 861
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/0lET1jD1SV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/0lET1jD1SV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqH9bUYAAhjKV.jpg",
      "id_str" : "668619754668580864",
      "id" : 668619754668580864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqH9bUYAAhjKV.jpg",
      "sizes" : [ {
        "h" : 1036,
        "resize" : "fit",
        "w" : 1194
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0lET1jD1SV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/0lET1jD1SV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqKiUU8AAcEkJ.jpg",
      "id_str" : "668619798931107840",
      "id" : 668619798931107840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqKiUU8AAcEkJ.jpg",
      "sizes" : [ {
        "h" : 1382,
        "resize" : "fit",
        "w" : 1036
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0lET1jD1SV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668624853650546688",
  "text" : "RT @melinawstaal: today https:\/\/t.co\/0lET1jD1SV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/0lET1jD1SV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqKqfUYAAU_Yc.jpg",
        "id_str" : "668619801124691968",
        "id" : 668619801124691968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqKqfUYAAU_Yc.jpg",
        "sizes" : [ {
          "h" : 1266,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1266,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0lET1jD1SV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/0lET1jD1SV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqGKNUsAAzsyt.jpg",
        "id_str" : "668619723739803648",
        "id" : 668619723739803648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqGKNUsAAzsyt.jpg",
        "sizes" : [ {
          "h" : 1380,
          "resize" : "fit",
          "w" : 861
        }, {
          "h" : 962,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1380,
          "resize" : "fit",
          "w" : 861
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/0lET1jD1SV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/0lET1jD1SV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqH9bUYAAhjKV.jpg",
        "id_str" : "668619754668580864",
        "id" : 668619754668580864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqH9bUYAAhjKV.jpg",
        "sizes" : [ {
          "h" : 1036,
          "resize" : "fit",
          "w" : 1194
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 888,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0lET1jD1SV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/melinawstaal\/status\/668619802408148992\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/0lET1jD1SV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUdqKiUU8AAcEkJ.jpg",
        "id_str" : "668619798931107840",
        "id" : 668619798931107840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUdqKiUU8AAcEkJ.jpg",
        "sizes" : [ {
          "h" : 1382,
          "resize" : "fit",
          "w" : 1036
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0lET1jD1SV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668619802408148992",
    "text" : "today https:\/\/t.co\/0lET1jD1SV",
    "id" : 668619802408148992,
    "created_at" : "2015-11-23 02:39:17 +0000",
    "user" : {
      "name" : "melina wade staal",
      "screen_name" : "melinawstaal",
      "protected" : false,
      "id_str" : "530935629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638498065096151042\/DwWC834G_normal.jpg",
      "id" : 530935629,
      "verified" : false
    }
  },
  "id" : 668624853650546688,
  "created_at" : "2015-11-23 02:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668575395596242945",
  "geo" : { },
  "id_str" : "668589666212388864",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time really?? how cool. hope I can catch it!",
  "id" : 668589666212388864,
  "in_reply_to_status_id" : 668575395596242945,
  "created_at" : "2015-11-23 00:39:32 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668504294388314114",
  "text" : "feeling angsty. who am I? going thru old writing of mine.. who was that person? I dont think I like her but yet I want to hug her? maybe?",
  "id" : 668504294388314114,
  "created_at" : "2015-11-22 19:00:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/5727SXcTs1",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/668402417449455616",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668473851366539264",
  "text" : "gorgeous https:\/\/t.co\/5727SXcTs1",
  "id" : 668473851366539264,
  "created_at" : "2015-11-22 16:59:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Madden",
      "screen_name" : "activist360",
      "indices" : [ 3, 15 ],
      "id_str" : "349803020",
      "id" : 349803020
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 40, 48 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Gov. Bobby Jindal",
      "screen_name" : "BobbyJindal",
      "indices" : [ 50, 62 ],
      "id_str" : "17078632",
      "id" : 17078632
    }, {
      "name" : "Gov. Mike Huckabee",
      "screen_name" : "GovMikeHuckabee",
      "indices" : [ 69, 85 ],
      "id_str" : "15416505",
      "id" : 15416505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668280019366617088",
  "text" : "RT @activist360: Do people realize that @TedCruz, @BobbyJindal &amp; @GovMikeHuckabee actually attended a conference promoting the exterminatio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 23, 31 ],
        "id_str" : "23022687",
        "id" : 23022687
      }, {
        "name" : "Gov. Bobby Jindal",
        "screen_name" : "BobbyJindal",
        "indices" : [ 33, 45 ],
        "id_str" : "17078632",
        "id" : 17078632
      }, {
        "name" : "Gov. Mike Huckabee",
        "screen_name" : "GovMikeHuckabee",
        "indices" : [ 52, 68 ],
        "id_str" : "15416505",
        "id" : 15416505
      }, {
        "name" : "Rachel Maddow MSNBC",
        "screen_name" : "maddow",
        "indices" : [ 137, 144 ],
        "id_str" : "16129920",
        "id" : 16129920
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663925102753484800",
    "text" : "Do people realize that @TedCruz, @BobbyJindal &amp; @GovMikeHuckabee actually attended a conference promoting the extermination of gays? @maddow",
    "id" : 663925102753484800,
    "created_at" : "2015-11-10 03:44:14 +0000",
    "user" : {
      "name" : "Bill Madden",
      "screen_name" : "activist360",
      "protected" : false,
      "id_str" : "349803020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659427646540001280\/1sIxdKlD_normal.jpg",
      "id" : 349803020,
      "verified" : false
    }
  },
  "id" : 668280019366617088,
  "created_at" : "2015-11-22 04:09:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razor Cabrone\u26D4",
      "screen_name" : "RazorCabrone",
      "indices" : [ 3, 16 ],
      "id_str" : "3295850985",
      "id" : 3295850985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 21, 31 ]
    }, {
      "text" : "NerdistWho",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668279712083517440",
  "text" : "RT @RazorCabrone: if #DoctorWho's name was really Basil would that make him a Thyme Lord? #NerdistWho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 3, 13 ]
      }, {
        "text" : "NerdistWho",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668275091675844608",
    "text" : "if #DoctorWho's name was really Basil would that make him a Thyme Lord? #NerdistWho",
    "id" : 668275091675844608,
    "created_at" : "2015-11-22 03:49:32 +0000",
    "user" : {
      "name" : "Razor Cabrone\u26D4",
      "screen_name" : "RazorCabrone",
      "protected" : false,
      "id_str" : "3295850985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690047821072850944\/YB4iLbBg_normal.png",
      "id" : 3295850985,
      "verified" : false
    }
  },
  "id" : 668279712083517440,
  "created_at" : "2015-11-22 04:07:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ineffable Cosmos",
      "screen_name" : "IneffableCosmos",
      "indices" : [ 3, 19 ],
      "id_str" : "3304161441",
      "id" : 3304161441
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IneffableCosmos\/status\/668247764267069440\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/CrCSSI7lzT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUYXzQ0XIAAcNQG.jpg",
      "id_str" : "668247764166451200",
      "id" : 668247764166451200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUYXzQ0XIAAcNQG.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/CrCSSI7lzT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668271198615244800",
  "text" : "RT @IneffableCosmos: A perspective of the distance between the earth and moon https:\/\/t.co\/CrCSSI7lzT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IneffableCosmos\/status\/668247764267069440\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/CrCSSI7lzT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUYXzQ0XIAAcNQG.jpg",
        "id_str" : "668247764166451200",
        "id" : 668247764166451200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUYXzQ0XIAAcNQG.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/CrCSSI7lzT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668247764267069440",
    "text" : "A perspective of the distance between the earth and moon https:\/\/t.co\/CrCSSI7lzT",
    "id" : 668247764267069440,
    "created_at" : "2015-11-22 02:00:57 +0000",
    "user" : {
      "name" : "Ineffable Cosmos",
      "screen_name" : "IneffableCosmos",
      "protected" : false,
      "id_str" : "3304161441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728259825126215680\/8k3kpZDV_normal.jpg",
      "id" : 3304161441,
      "verified" : false
    }
  },
  "id" : 668271198615244800,
  "created_at" : "2015-11-22 03:34:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flobot \uD83E\uDD16",
      "screen_name" : "Flosephine",
      "indices" : [ 3, 14 ],
      "id_str" : "20087576",
      "id" : 20087576
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/OxuT5K6cVB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSk6WIAAgFnx.jpg",
      "id_str" : "668016305182744576",
      "id" : 668016305182744576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSk6WIAAgFnx.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OxuT5K6cVB"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/OxuT5K6cVB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSlBWsAAqL1-.jpg",
      "id_str" : "668016305212141568",
      "id" : 668016305212141568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSlBWsAAqL1-.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OxuT5K6cVB"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/OxuT5K6cVB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSlJWIAAEwD8.jpg",
      "id_str" : "668016305245659136",
      "id" : 668016305245659136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSlJWIAAEwD8.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OxuT5K6cVB"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/OxuT5K6cVB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSlVWwAAKDSv.jpg",
      "id_str" : "668016305296031744",
      "id" : 668016305296031744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSlVWwAAKDSv.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OxuT5K6cVB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668249945133158400",
  "text" : "RT @Flosephine: It might be cold outside, but this is guaranteed to warm you from the inside \uD83D\uDC93 https:\/\/t.co\/OxuT5K6cVB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/OxuT5K6cVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSk6WIAAgFnx.jpg",
        "id_str" : "668016305182744576",
        "id" : 668016305182744576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSk6WIAAgFnx.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OxuT5K6cVB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/OxuT5K6cVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSlBWsAAqL1-.jpg",
        "id_str" : "668016305212141568",
        "id" : 668016305212141568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSlBWsAAqL1-.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OxuT5K6cVB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/OxuT5K6cVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSlJWIAAEwD8.jpg",
        "id_str" : "668016305245659136",
        "id" : 668016305245659136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSlJWIAAEwD8.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OxuT5K6cVB"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Flosephine\/status\/668016317535010816\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/OxuT5K6cVB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVFSlVWwAAKDSv.jpg",
        "id_str" : "668016305296031744",
        "id" : 668016305296031744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVFSlVWwAAKDSv.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OxuT5K6cVB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668016317535010816",
    "text" : "It might be cold outside, but this is guaranteed to warm you from the inside \uD83D\uDC93 https:\/\/t.co\/OxuT5K6cVB",
    "id" : 668016317535010816,
    "created_at" : "2015-11-21 10:41:15 +0000",
    "user" : {
      "name" : "Flobot \uD83E\uDD16",
      "screen_name" : "Flosephine",
      "protected" : false,
      "id_str" : "20087576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794603008910913537\/CWij5W1C_normal.jpg",
      "id" : 20087576,
      "verified" : false
    }
  },
  "id" : 668249945133158400,
  "created_at" : "2015-11-22 02:09:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asymptotic Binary",
      "screen_name" : "asymbina",
      "indices" : [ 3, 12 ],
      "id_str" : "93638430",
      "id" : 93638430
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/asymbina\/status\/668215077192007682\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/DuJxRmnjUe",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUX6DEAWsAAw2Ft.png",
      "id_str" : "668215050256166912",
      "id" : 668215050256166912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUX6DEAWsAAw2Ft.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 429
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 429
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 429
      } ],
      "display_url" : "pic.twitter.com\/DuJxRmnjUe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668249164824879104",
  "text" : "RT @asymbina: Just gonna leave this here. https:\/\/t.co\/DuJxRmnjUe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/asymbina\/status\/668215077192007682\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/DuJxRmnjUe",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUX6DEAWsAAw2Ft.png",
        "id_str" : "668215050256166912",
        "id" : 668215050256166912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUX6DEAWsAAw2Ft.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 429
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 429
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 429
        } ],
        "display_url" : "pic.twitter.com\/DuJxRmnjUe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668215077192007682",
    "text" : "Just gonna leave this here. https:\/\/t.co\/DuJxRmnjUe",
    "id" : 668215077192007682,
    "created_at" : "2015-11-21 23:51:03 +0000",
    "user" : {
      "name" : "Asymptotic Binary",
      "screen_name" : "asymbina",
      "protected" : false,
      "id_str" : "93638430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730455380988465152\/Z8lTbsE7_normal.jpg",
      "id" : 93638430,
      "verified" : false
    }
  },
  "id" : 668249164824879104,
  "created_at" : "2015-11-22 02:06:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/xIOYXzC91G",
      "expanded_url" : "https:\/\/youtu.be\/OoNG9Px_meo",
      "display_url" : "youtu.be\/OoNG9Px_meo"
    } ]
  },
  "geo" : { },
  "id_str" : "668153860888899586",
  "text" : "easy-going, melodic song... Hurricane 8 6 15 https:\/\/t.co\/xIOYXzC91G",
  "id" : 668153860888899586,
  "created_at" : "2015-11-21 19:47:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 3, 14 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/668045452319830017\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/cZhRo7W8hl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVfrR1W4AAv8b2.jpg",
      "id_str" : "668045316860600320",
      "id" : 668045316860600320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVfrR1W4AAv8b2.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cZhRo7W8hl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668129881742581760",
  "text" : "RT @PVickerton: Anyone for jenga? https:\/\/t.co\/cZhRo7W8hl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/668045452319830017\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/cZhRo7W8hl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUVfrR1W4AAv8b2.jpg",
        "id_str" : "668045316860600320",
        "id" : 668045316860600320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUVfrR1W4AAv8b2.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cZhRo7W8hl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668045452319830017",
    "text" : "Anyone for jenga? https:\/\/t.co\/cZhRo7W8hl",
    "id" : 668045452319830017,
    "created_at" : "2015-11-21 12:37:02 +0000",
    "user" : {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "protected" : false,
      "id_str" : "1046103560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773840339463438336\/-PvOKg0h_normal.jpg",
      "id" : 1046103560,
      "verified" : false
    }
  },
  "id" : 668129881742581760,
  "created_at" : "2015-11-21 18:12:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Comedy Central UK",
      "screen_name" : "ComedyCentralUK",
      "indices" : [ 3, 19 ],
      "id_str" : "19591858",
      "id" : 19591858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zeve2nznB1",
      "expanded_url" : "https:\/\/vine.co\/v\/iuLuQJOuzrL",
      "display_url" : "vine.co\/v\/iuLuQJOuzrL"
    } ]
  },
  "geo" : { },
  "id_str" : "668129726234550272",
  "text" : "RT @ComedyCentralUK: Want to know how to get your beard really flat? Here's how. https:\/\/t.co\/zeve2nznB1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/zeve2nznB1",
        "expanded_url" : "https:\/\/vine.co\/v\/iuLuQJOuzrL",
        "display_url" : "vine.co\/v\/iuLuQJOuzrL"
      } ]
    },
    "geo" : { },
    "id_str" : "668083625485869056",
    "text" : "Want to know how to get your beard really flat? Here's how. https:\/\/t.co\/zeve2nznB1",
    "id" : 668083625485869056,
    "created_at" : "2015-11-21 15:08:43 +0000",
    "user" : {
      "name" : "Comedy Central UK",
      "screen_name" : "ComedyCentralUK",
      "protected" : false,
      "id_str" : "19591858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719902378212896772\/7W4ZBW4J_normal.jpg",
      "id" : 19591858,
      "verified" : true
    }
  },
  "id" : 668129726234550272,
  "created_at" : "2015-11-21 18:11:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pain News Network",
      "screen_name" : "PainNewsNetwork",
      "indices" : [ 3, 19 ],
      "id_str" : "2590800066",
      "id" : 2590800066
    }, {
      "name" : "ArachnoiditisSociety",
      "screen_name" : "ASAPDawn",
      "indices" : [ 116, 125 ],
      "id_str" : "705942178",
      "id" : 705942178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opioids",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "epidural",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "chronicpain",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667926742389141504",
  "text" : "RT @PainNewsNetwork: An Indiana woman tells how #opioids saved her life after an #epidural gone wrong. #chronicpain @ASAPDawn \nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ArachnoiditisSociety",
        "screen_name" : "ASAPDawn",
        "indices" : [ 95, 104 ],
        "id_str" : "705942178",
        "id" : 705942178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opioids",
        "indices" : [ 27, 35 ]
      }, {
        "text" : "epidural",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "chronicpain",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/QVqRK3losx",
        "expanded_url" : "http:\/\/goo.gl\/9vYJZV",
        "display_url" : "goo.gl\/9vYJZV"
      } ]
    },
    "geo" : { },
    "id_str" : "666324966787280897",
    "text" : "An Indiana woman tells how #opioids saved her life after an #epidural gone wrong. #chronicpain @ASAPDawn \nhttps:\/\/t.co\/QVqRK3losx",
    "id" : 666324966787280897,
    "created_at" : "2015-11-16 18:40:26 +0000",
    "user" : {
      "name" : "Pain News Network",
      "screen_name" : "PainNewsNetwork",
      "protected" : false,
      "id_str" : "2590800066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587328473368174593\/Yuv5iDKh_normal.png",
      "id" : 2590800066,
      "verified" : false
    }
  },
  "id" : 667926742389141504,
  "created_at" : "2015-11-21 04:45:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArachnoiditisSociety",
      "screen_name" : "ASAPDawn",
      "indices" : [ 3, 12 ],
      "id_str" : "705942178",
      "id" : 705942178
    }, {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "indices" : [ 14, 26 ],
      "id_str" : "896548279",
      "id" : 896548279
    }, {
      "name" : "Shannon Tuten",
      "screen_name" : "sctuten",
      "indices" : [ 27, 35 ],
      "id_str" : "402008066",
      "id" : 402008066
    }, {
      "name" : "iPain Foundation",
      "screen_name" : "powerofpain",
      "indices" : [ 36, 48 ],
      "id_str" : "38215965",
      "id" : 38215965
    }, {
      "name" : "Pain News Network",
      "screen_name" : "PainNewsNetwork",
      "indices" : [ 49, 65 ],
      "id_str" : "2590800066",
      "id" : 2590800066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667925738566377472",
  "text" : "RT @ASAPDawn: @NaamaYehuda @sctuten @powerofpain @PainNewsNetwork Opioids are to us like insulin to diabetic.  They do save lives. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Naama Yehuda",
        "screen_name" : "NaamaYehuda",
        "indices" : [ 0, 12 ],
        "id_str" : "896548279",
        "id" : 896548279
      }, {
        "name" : "Shannon Tuten",
        "screen_name" : "sctuten",
        "indices" : [ 13, 21 ],
        "id_str" : "402008066",
        "id" : 402008066
      }, {
        "name" : "iPain Foundation",
        "screen_name" : "powerofpain",
        "indices" : [ 22, 34 ],
        "id_str" : "38215965",
        "id" : 38215965
      }, {
        "name" : "Pain News Network",
        "screen_name" : "PainNewsNetwork",
        "indices" : [ 35, 51 ],
        "id_str" : "2590800066",
        "id" : 2590800066
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wsDYc6XdQw",
        "expanded_url" : "http:\/\/www.practicalpainmanagement.com\/sudden-unexpected-death-chronic-pain-patients",
        "display_url" : "practicalpainmanagement.com\/sudden-unexpec\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "667865234791661568",
    "geo" : { },
    "id_str" : "667911074080038914",
    "in_reply_to_user_id" : 896548279,
    "text" : "@NaamaYehuda @sctuten @powerofpain @PainNewsNetwork Opioids are to us like insulin to diabetic.  They do save lives. https:\/\/t.co\/wsDYc6XdQw",
    "id" : 667911074080038914,
    "in_reply_to_status_id" : 667865234791661568,
    "created_at" : "2015-11-21 03:43:03 +0000",
    "in_reply_to_screen_name" : "NaamaYehuda",
    "in_reply_to_user_id_str" : "896548279",
    "user" : {
      "name" : "ArachnoiditisSociety",
      "screen_name" : "ASAPDawn",
      "protected" : false,
      "id_str" : "705942178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785952980436746240\/4xWc-b0V_normal.jpg",
      "id" : 705942178,
      "verified" : false
    }
  },
  "id" : 667925738566377472,
  "created_at" : "2015-11-21 04:41:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667841341209092096",
  "text" : "found app on google play \"desktop notifications\" perfect.. except pop-up only stays up 25 seconds.. wont do for me.",
  "id" : 667841341209092096,
  "created_at" : "2015-11-20 23:05:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667835002399387648",
  "text" : "i need to figure out how to be aware of texts from DH. I use google voice. I'm usually at my laptop.. maybe a desktop notification? hmm..",
  "id" : 667835002399387648,
  "created_at" : "2015-11-20 22:40:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667755667462217728",
  "text" : "my poor babe.. she looks like hell today. not even getting out of bed today. nausea, anxiety, wonky head, weak #chronicillness",
  "id" : 667755667462217728,
  "created_at" : "2015-11-20 17:25:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/667745174622240769\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/W0Of5F8rka",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUROsirWIAE-bKT.jpg",
      "id_str" : "667745171887497217",
      "id" : 667745171887497217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUROsirWIAE-bKT.jpg",
      "sizes" : [ {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/W0Of5F8rka"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/UOLkTHlq2w",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/11\/jim-elliff-says-avoid-bart-ehrman-he-could-cause-you-to-lose-your-faith\/?_ts=1448037828",
      "display_url" : "brucegerencser.net\/2015\/11\/jim-el\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667745174622240769",
  "text" : "Jim Elliff says, Avoid Bart Ehrman, He Could Cause You To Lose Your Faith! https:\/\/t.co\/UOLkTHlq2w https:\/\/t.co\/W0Of5F8rka",
  "id" : 667745174622240769,
  "created_at" : "2015-11-20 16:43:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "indices" : [ 3, 19 ],
      "id_str" : "492604254",
      "id" : 492604254
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raccoons",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667549832438013952",
  "text" : "RT @naturechronicle: Uh, oh, they saw me! Misha and Arne climb down from their tree for their favorite treat, vanilla cookies. #raccoons ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/naturechronicle\/status\/666635029380923392\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fBcjVloRHX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBdBqmUYAAmU1y.jpg",
        "id_str" : "666635028047093760",
        "id" : 666635028047093760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBdBqmUYAAmU1y.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fBcjVloRHX"
      } ],
      "hashtags" : [ {
        "text" : "raccoons",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666635029380923392",
    "text" : "Uh, oh, they saw me! Misha and Arne climb down from their tree for their favorite treat, vanilla cookies. #raccoons https:\/\/t.co\/fBcjVloRHX",
    "id" : 666635029380923392,
    "created_at" : "2015-11-17 15:12:31 +0000",
    "user" : {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "protected" : false,
      "id_str" : "492604254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3166619966\/e7f8777d0fc93299ea6002d3e754aca8_normal.jpeg",
      "id" : 492604254,
      "verified" : false
    }
  },
  "id" : 667549832438013952,
  "created_at" : "2015-11-20 03:47:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "indices" : [ 3, 12 ],
      "id_str" : "4239367280",
      "id" : 4239367280
    }, {
      "name" : "trutherbotgreen",
      "screen_name" : "trutherbotgreen",
      "indices" : [ 14, 30 ],
      "id_str" : "3260285413",
      "id" : 3260285413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667548215051476993",
  "text" : "RT @PanDeist: @trutherbotgreen if you insert aliens in the holy texts where god(s) and \"angels\" are the books become way more interesting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "trutherbotgreen",
        "screen_name" : "trutherbotgreen",
        "indices" : [ 0, 16 ],
        "id_str" : "3260285413",
        "id" : 3260285413
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667525274733424641",
    "geo" : { },
    "id_str" : "667536655243325440",
    "in_reply_to_user_id" : 3260285413,
    "text" : "@trutherbotgreen if you insert aliens in the holy texts where god(s) and \"angels\" are the books become way more interesting.",
    "id" : 667536655243325440,
    "in_reply_to_status_id" : 667525274733424641,
    "created_at" : "2015-11-20 02:55:15 +0000",
    "in_reply_to_screen_name" : "trutherbotgreen",
    "in_reply_to_user_id_str" : "3260285413",
    "user" : {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "protected" : false,
      "id_str" : "4239367280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670124725876617216\/BIZ3YMxY_normal.jpg",
      "id" : 4239367280,
      "verified" : false
    }
  },
  "id" : 667548215051476993,
  "created_at" : "2015-11-20 03:41:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Jacobs Hendel",
      "screen_name" : "HilaryJHendel",
      "indices" : [ 3, 17 ],
      "id_str" : "3545156062",
      "id" : 3545156062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667527971549421568",
  "text" : "RT @HilaryJHendel: Embrace the good, minimize the bad and when you can't do either try to have compassion for yourself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667320297465344002",
    "text" : "Embrace the good, minimize the bad and when you can't do either try to have compassion for yourself.",
    "id" : 667320297465344002,
    "created_at" : "2015-11-19 12:35:31 +0000",
    "user" : {
      "name" : "Hilary Jacobs Hendel",
      "screen_name" : "HilaryJHendel",
      "protected" : false,
      "id_str" : "3545156062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720686064436965377\/O2ECk3lR_normal.jpg",
      "id" : 3545156062,
      "verified" : false
    }
  },
  "id" : 667527971549421568,
  "created_at" : "2015-11-20 02:20:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facebook",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667527184840581125",
  "text" : "Found a few that had died.. DH said \"I don't think I want to be friends anymore.\" #facebook",
  "id" : 667527184840581125,
  "created_at" : "2015-11-20 02:17:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667526629070151681",
  "text" : "Cleaned out Facebook a bit. Felt bad \"unfriending\" ppl but they weren't friends anyway.",
  "id" : 667526629070151681,
  "created_at" : "2015-11-20 02:15:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Internet Of Things",
      "screen_name" : "abradacabla",
      "indices" : [ 3, 15 ],
      "id_str" : "28654635",
      "id" : 28654635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ZzNA2YhBde",
      "expanded_url" : "https:\/\/twitter.com\/sarahpalinusa\/status\/667375535060684800",
      "display_url" : "twitter.com\/sarahpalinusa\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667398327923789824",
  "text" : "RT @abradacabla: Might want to try reading Matthew 5:39, Sarah.  https:\/\/t.co\/ZzNA2YhBde",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/ZzNA2YhBde",
        "expanded_url" : "https:\/\/twitter.com\/sarahpalinusa\/status\/667375535060684800",
        "display_url" : "twitter.com\/sarahpalinusa\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667388858548531201",
    "text" : "Might want to try reading Matthew 5:39, Sarah.  https:\/\/t.co\/ZzNA2YhBde",
    "id" : 667388858548531201,
    "created_at" : "2015-11-19 17:07:58 +0000",
    "user" : {
      "name" : "Internet Of Things",
      "screen_name" : "abradacabla",
      "protected" : false,
      "id_str" : "28654635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622457879325507584\/QinrpmCu_normal.jpg",
      "id" : 28654635,
      "verified" : false
    }
  },
  "id" : 667398327923789824,
  "created_at" : "2015-11-19 17:45:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dpdr",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667384066312962048",
  "text" : "from DD researching symptoms, we're looking at #dpdr",
  "id" : 667384066312962048,
  "created_at" : "2015-11-19 16:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dad",
      "screen_name" : "joshisneckdeep",
      "indices" : [ 3, 18 ],
      "id_str" : "538506203",
      "id" : 538506203
    }, {
      "name" : "Justin Wedes",
      "screen_name" : "justinwedes",
      "indices" : [ 20, 32 ],
      "id_str" : "66723691",
      "id" : 66723691
    }, {
      "name" : "Yahoo News",
      "screen_name" : "YahooNews",
      "indices" : [ 33, 43 ],
      "id_str" : "7309052",
      "id" : 7309052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/joshisneckdeep\/status\/667344131019169792\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/v9OD1xj4rd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CULh8LvU8AAy4Md.jpg",
      "id_str" : "667344118863949824",
      "id" : 667344118863949824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CULh8LvU8AAy4Md.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/v9OD1xj4rd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667366729752948736",
  "text" : "RT @joshisneckdeep: @justinwedes @YahooNews https:\/\/t.co\/v9OD1xj4rd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justin Wedes",
        "screen_name" : "justinwedes",
        "indices" : [ 0, 12 ],
        "id_str" : "66723691",
        "id" : 66723691
      }, {
        "name" : "Yahoo News",
        "screen_name" : "YahooNews",
        "indices" : [ 13, 23 ],
        "id_str" : "7309052",
        "id" : 7309052
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/joshisneckdeep\/status\/667344131019169792\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/v9OD1xj4rd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CULh8LvU8AAy4Md.jpg",
        "id_str" : "667344118863949824",
        "id" : 667344118863949824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CULh8LvU8AAy4Md.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/v9OD1xj4rd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667339976242106368",
    "geo" : { },
    "id_str" : "667344131019169792",
    "in_reply_to_user_id" : 66723691,
    "text" : "@justinwedes @YahooNews https:\/\/t.co\/v9OD1xj4rd",
    "id" : 667344131019169792,
    "in_reply_to_status_id" : 667339976242106368,
    "created_at" : "2015-11-19 14:10:14 +0000",
    "in_reply_to_screen_name" : "justinwedes",
    "in_reply_to_user_id_str" : "66723691",
    "user" : {
      "name" : "dad",
      "screen_name" : "joshisneckdeep",
      "protected" : false,
      "id_str" : "538506203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796563867765768196\/iydUqCZ9_normal.jpg",
      "id" : 538506203,
      "verified" : false
    }
  },
  "id" : 667366729752948736,
  "created_at" : "2015-11-19 15:40:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667175169857818624",
  "text" : "RT @SpiritualNurse: One of Nation's Largest Catholic Hospital Systems Says It Can Deny Women Emergency Care due2 Religious Affiliation\n htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DPcisPN7tD",
        "expanded_url" : "http:\/\/flip.it\/VTCYU",
        "display_url" : "flip.it\/VTCYU"
      } ]
    },
    "geo" : { },
    "id_str" : "667164425858756608",
    "text" : "One of Nation's Largest Catholic Hospital Systems Says It Can Deny Women Emergency Care due2 Religious Affiliation\n https:\/\/t.co\/DPcisPN7tD",
    "id" : 667164425858756608,
    "created_at" : "2015-11-19 02:16:09 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 667175169857818624,
  "created_at" : "2015-11-19 02:58:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kas Thomas",
      "screen_name" : "kasthomas",
      "indices" : [ 3, 13 ],
      "id_str" : "19539314",
      "id" : 19539314
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kasthomas\/status\/667165359133163520\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/VxvSSpz3lj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUI_W4ZUYAEGczT.jpg",
      "id_str" : "667165357132505089",
      "id" : 667165357132505089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUI_W4ZUYAEGczT.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/VxvSSpz3lj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667173643961688064",
  "text" : "RT @kasthomas: https:\/\/t.co\/VxvSSpz3lj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kasthomas\/status\/667165359133163520\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/VxvSSpz3lj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUI_W4ZUYAEGczT.jpg",
        "id_str" : "667165357132505089",
        "id" : 667165357132505089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUI_W4ZUYAEGczT.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/VxvSSpz3lj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667165359133163520",
    "text" : "https:\/\/t.co\/VxvSSpz3lj",
    "id" : 667165359133163520,
    "created_at" : "2015-11-19 02:19:51 +0000",
    "user" : {
      "name" : "Kas Thomas",
      "screen_name" : "kasthomas",
      "protected" : false,
      "id_str" : "19539314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541293759\/ktinyCrop_normal.jpg",
      "id" : 19539314,
      "verified" : false
    }
  },
  "id" : 667173643961688064,
  "created_at" : "2015-11-19 02:52:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/waOJadKikH",
      "expanded_url" : "https:\/\/twitter.com\/DavidCornDC\/status\/667074943092400129",
      "display_url" : "twitter.com\/DavidCornDC\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667093599939665920",
  "text" : "sickening. (not just him but the whole thing.. all that money that could help ppl) https:\/\/t.co\/waOJadKikH",
  "id" : 667093599939665920,
  "created_at" : "2015-11-18 21:34:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 0, 9 ],
      "id_str" : "215045056",
      "id" : 215045056
    }, {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "indices" : [ 10, 19 ],
      "id_str" : "4239367280",
      "id" : 4239367280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667086859705704449",
  "geo" : { },
  "id_str" : "667092467339165696",
  "in_reply_to_user_id" : 215045056,
  "text" : "@Pandeism @PanDeist hehehehe",
  "id" : 667092467339165696,
  "in_reply_to_status_id" : 667086859705704449,
  "created_at" : "2015-11-18 21:30:12 +0000",
  "in_reply_to_screen_name" : "Pandeism",
  "in_reply_to_user_id_str" : "215045056",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/bpVface7If",
      "expanded_url" : "https:\/\/twitter.com\/randomhero997\/status\/663375304648298496",
      "display_url" : "twitter.com\/randomhero997\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667022883571503104",
  "text" : "no wonder I feel at home here... https:\/\/t.co\/bpVface7If",
  "id" : 667022883571503104,
  "created_at" : "2015-11-18 16:53:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Somerville",
      "screen_name" : "Stuthefarmer",
      "indices" : [ 3, 16 ],
      "id_str" : "274496182",
      "id" : 274496182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/lhadpI4t48",
      "expanded_url" : "https:\/\/twitter.com\/weathernetwork\/status\/666411097684054016",
      "display_url" : "twitter.com\/weathernetwork\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666997799964311553",
  "text" : "RT @Stuthefarmer: I would like to know who determined at what wind speed a cow might be knocked over. https:\/\/t.co\/lhadpI4t48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/lhadpI4t48",
        "expanded_url" : "https:\/\/twitter.com\/weathernetwork\/status\/666411097684054016",
        "display_url" : "twitter.com\/weathernetwork\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666842404943597568",
    "text" : "I would like to know who determined at what wind speed a cow might be knocked over. https:\/\/t.co\/lhadpI4t48",
    "id" : 666842404943597568,
    "created_at" : "2015-11-18 04:56:33 +0000",
    "user" : {
      "name" : "Stuart Somerville",
      "screen_name" : "Stuthefarmer",
      "protected" : false,
      "id_str" : "274496182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784901244435300352\/XQO2UAe0_normal.jpg",
      "id" : 274496182,
      "verified" : false
    }
  },
  "id" : 666997799964311553,
  "created_at" : "2015-11-18 15:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "indices" : [ 0, 9 ],
      "id_str" : "4239367280",
      "id" : 4239367280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666813768802766848",
  "geo" : { },
  "id_str" : "666815809654792192",
  "in_reply_to_user_id" : 4239367280,
  "text" : "@PanDeist thanks",
  "id" : 666815809654792192,
  "in_reply_to_status_id" : 666813768802766848,
  "created_at" : "2015-11-18 03:10:52 +0000",
  "in_reply_to_screen_name" : "PanDeist",
  "in_reply_to_user_id_str" : "4239367280",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "indices" : [ 0, 9 ],
      "id_str" : "4239367280",
      "id" : 4239367280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666459266568470530",
  "geo" : { },
  "id_str" : "666813334503751680",
  "in_reply_to_user_id" : 4239367280,
  "text" : "@PanDeist does this book have a title? Sounds like something I'd like...",
  "id" : 666813334503751680,
  "in_reply_to_status_id" : 666459266568470530,
  "created_at" : "2015-11-18 03:01:02 +0000",
  "in_reply_to_screen_name" : "PanDeist",
  "in_reply_to_user_id_str" : "4239367280",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CosmicDivinity",
      "screen_name" : "C0smicDivinity",
      "indices" : [ 3, 18 ],
      "id_str" : "3233634590",
      "id" : 3233634590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666811063262969857",
  "text" : "RT @C0smicDivinity: As our consciousness expands so does our perspective, enabling us to see clearer than we did previously before.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666800239160881153",
    "text" : "As our consciousness expands so does our perspective, enabling us to see clearer than we did previously before.",
    "id" : 666800239160881153,
    "created_at" : "2015-11-18 02:09:00 +0000",
    "user" : {
      "name" : "CosmicDivinity",
      "screen_name" : "C0smicDivinity",
      "protected" : false,
      "id_str" : "3233634590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605756015292719104\/GkuKwnrG_normal.jpg",
      "id" : 3233634590,
      "verified" : false
    }
  },
  "id" : 666811063262969857,
  "created_at" : "2015-11-18 02:52:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soul",
      "screen_name" : "ReverieHippie",
      "indices" : [ 3, 17 ],
      "id_str" : "1649730020",
      "id" : 1649730020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ReverieHippie\/status\/633842306173394944\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Oywv8rKlWH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMvcNrdUcAIyyuE.jpg",
      "id_str" : "633842300137795586",
      "id" : 633842300137795586,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMvcNrdUcAIyyuE.jpg",
      "sizes" : [ {
        "h" : 553,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Oywv8rKlWH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666810246602596352",
  "text" : "RT @ReverieHippie: Allow nothing to kill your vibe. Be unfuckwithable. http:\/\/t.co\/Oywv8rKlWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ReverieHippie\/status\/633842306173394944\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/Oywv8rKlWH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMvcNrdUcAIyyuE.jpg",
        "id_str" : "633842300137795586",
        "id" : 633842300137795586,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMvcNrdUcAIyyuE.jpg",
        "sizes" : [ {
          "h" : 553,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Oywv8rKlWH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633842306173394944",
    "text" : "Allow nothing to kill your vibe. Be unfuckwithable. http:\/\/t.co\/Oywv8rKlWH",
    "id" : 633842306173394944,
    "created_at" : "2015-08-19 03:25:56 +0000",
    "user" : {
      "name" : "Soul",
      "screen_name" : "ReverieHippie",
      "protected" : false,
      "id_str" : "1649730020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000567537175\/6a6f9a6622d923767a8f4419b80fba11_normal.jpeg",
      "id" : 1649730020,
      "verified" : false
    }
  },
  "id" : 666810246602596352,
  "created_at" : "2015-11-18 02:48:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "indices" : [ 3, 12 ],
      "id_str" : "4239367280",
      "id" : 4239367280
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PanDeist\/status\/666792331882860544\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/K11sPMHitX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUDsFqYUYAAQmJK.jpg",
      "id_str" : "666792326870622208",
      "id" : 666792326870622208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUDsFqYUYAAQmJK.jpg",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 631
      } ],
      "display_url" : "pic.twitter.com\/K11sPMHitX"
    } ],
    "hashtags" : [ {
      "text" : "pandeism",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "pantheism",
      "indices" : [ 24, 34 ]
    }, {
      "text" : "deism",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666805146836406273",
  "text" : "RT @PanDeist: #pandeism #pantheism #deism https:\/\/t.co\/K11sPMHitX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PanDeist\/status\/666792331882860544\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/K11sPMHitX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUDsFqYUYAAQmJK.jpg",
        "id_str" : "666792326870622208",
        "id" : 666792326870622208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUDsFqYUYAAQmJK.jpg",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 631
        } ],
        "display_url" : "pic.twitter.com\/K11sPMHitX"
      } ],
      "hashtags" : [ {
        "text" : "pandeism",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "pantheism",
        "indices" : [ 10, 20 ]
      }, {
        "text" : "deism",
        "indices" : [ 21, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666792331882860544",
    "text" : "#pandeism #pantheism #deism https:\/\/t.co\/K11sPMHitX",
    "id" : 666792331882860544,
    "created_at" : "2015-11-18 01:37:34 +0000",
    "user" : {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "protected" : false,
      "id_str" : "4239367280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670124725876617216\/BIZ3YMxY_normal.jpg",
      "id" : 4239367280,
      "verified" : false
    }
  },
  "id" : 666805146836406273,
  "created_at" : "2015-11-18 02:28:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PanDeist",
      "screen_name" : "PanDeist",
      "indices" : [ 0, 9 ],
      "id_str" : "4239367280",
      "id" : 4239367280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666792331882860544",
  "geo" : { },
  "id_str" : "666804907714965504",
  "in_reply_to_user_id" : 4239367280,
  "text" : "@PanDeist the labels and concepts sound so similar. Hard to get grip on it. Wld be gd as visual chart showing differences.",
  "id" : 666804907714965504,
  "in_reply_to_status_id" : 666792331882860544,
  "created_at" : "2015-11-18 02:27:33 +0000",
  "in_reply_to_screen_name" : "PanDeist",
  "in_reply_to_user_id_str" : "4239367280",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/508315796234584064\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/ibEuu3iW9b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bw3mhfJIcAAdGz9.jpg",
      "id_str" : "508315795932606464",
      "id" : 508315795932606464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bw3mhfJIcAAdGz9.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/ibEuu3iW9b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666802011279634434",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/ibEuu3iW9b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/508315796234584064\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/ibEuu3iW9b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bw3mhfJIcAAdGz9.jpg",
        "id_str" : "508315795932606464",
        "id" : 508315795932606464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bw3mhfJIcAAdGz9.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/ibEuu3iW9b"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666800550869118980",
    "text" : "https:\/\/t.co\/ibEuu3iW9b",
    "id" : 666800550869118980,
    "created_at" : "2015-11-18 02:10:14 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 666802011279634434,
  "created_at" : "2015-11-18 02:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/yZ27uZTAh2",
      "expanded_url" : "http:\/\/www.nais.org\/Magazines-Newsletters\/ISMagazine\/Pages\/What-White-Children-Need-to-Know-About-Race.aspx",
      "display_url" : "nais.org\/Magazines-News\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666724445210460165",
  "text" : "RT @adamrshields: Fascinating article \u201CWhat White Children Need to Know About Race\u201D \nhttps:\/\/t.co\/yZ27uZTAh2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/yZ27uZTAh2",
        "expanded_url" : "http:\/\/www.nais.org\/Magazines-Newsletters\/ISMagazine\/Pages\/What-White-Children-Need-to-Know-About-Race.aspx",
        "display_url" : "nais.org\/Magazines-News\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666705325177905152",
    "text" : "Fascinating article \u201CWhat White Children Need to Know About Race\u201D \nhttps:\/\/t.co\/yZ27uZTAh2",
    "id" : 666705325177905152,
    "created_at" : "2015-11-17 19:51:50 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 666724445210460165,
  "created_at" : "2015-11-17 21:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666710605038882816",
  "geo" : { },
  "id_str" : "666723567812390913",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous glad you had a great time this year. DH would be so jealous. He loves Dr. Who.",
  "id" : 666723567812390913,
  "in_reply_to_status_id" : 666710605038882816,
  "created_at" : "2015-11-17 21:04:20 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Stiefvater",
      "screen_name" : "mstiefvater",
      "indices" : [ 3, 15 ],
      "id_str" : "15231995",
      "id" : 15231995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/HcxqER8aV9",
      "expanded_url" : "http:\/\/maggie-stiefvater.tumblr.com\/post\/133356884371\/i-have-ocd-it-doesnt-rule-my-life-but-it-used",
      "display_url" : "maggie-stiefvater.tumblr.com\/post\/133356884\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666680620802809856",
  "text" : "RT @mstiefvater: And for those who missed it yesterday, my OCD post. Readers asked how I learned to cope: https:\/\/t.co\/HcxqER8aV9 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mstiefvater\/status\/666668536434151425\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0RCB7dGUHT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUB7flNUAAEZ3az.jpg",
        "id_str" : "666668527344943105",
        "id" : 666668527344943105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUB7flNUAAEZ3az.jpg",
        "sizes" : [ {
          "h" : 524,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/0RCB7dGUHT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mstiefvater\/status\/666668536434151425\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0RCB7dGUHT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUB7gEIUYAEWeCy.jpg",
        "id_str" : "666668535645495297",
        "id" : 666668535645495297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUB7gEIUYAEWeCy.jpg",
        "sizes" : [ {
          "h" : 870,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 870,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/0RCB7dGUHT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/HcxqER8aV9",
        "expanded_url" : "http:\/\/maggie-stiefvater.tumblr.com\/post\/133356884371\/i-have-ocd-it-doesnt-rule-my-life-but-it-used",
        "display_url" : "maggie-stiefvater.tumblr.com\/post\/133356884\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666668536434151425",
    "text" : "And for those who missed it yesterday, my OCD post. Readers asked how I learned to cope: https:\/\/t.co\/HcxqER8aV9 https:\/\/t.co\/0RCB7dGUHT",
    "id" : 666668536434151425,
    "created_at" : "2015-11-17 17:25:39 +0000",
    "user" : {
      "name" : "Maggie Stiefvater",
      "screen_name" : "mstiefvater",
      "protected" : false,
      "id_str" : "15231995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722071986810318848\/8sLUUdQQ_normal.jpg",
      "id" : 15231995,
      "verified" : true
    }
  },
  "id" : 666680620802809856,
  "created_at" : "2015-11-17 18:13:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/o6bN4kKU1W",
      "expanded_url" : "https:\/\/youtu.be\/tZNaUD2xmu8",
      "display_url" : "youtu.be\/tZNaUD2xmu8"
    } ]
  },
  "geo" : { },
  "id_str" : "666676725737234432",
  "text" : "keep an eye on your shoes! &gt; Steam Powered Giraffe - Walter Robotics Rap https:\/\/t.co\/o6bN4kKU1W",
  "id" : 666676725737234432,
  "created_at" : "2015-11-17 17:58:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666635880761835520",
  "text" : "its a big responsibility when ppl like you...",
  "id" : 666635880761835520,
  "created_at" : "2015-11-17 15:15:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666446421000851456",
  "text" : "DD: Life is strange. Me: And getting stranger every day. DD: (Opens fan fic) Title? \"Life is stranger\"",
  "id" : 666446421000851456,
  "created_at" : "2015-11-17 02:43:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666412497155526656",
  "text" : "RT @benjamincorey: An hour ago, Franklin Graham posted we need to \"band together\" to \"destroy\" our enemy. \n\nI'm sorry, but this is NOT what\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666411897806286848",
    "text" : "An hour ago, Franklin Graham posted we need to \"band together\" to \"destroy\" our enemy. \n\nI'm sorry, but this is NOT what Jesus taught.",
    "id" : 666411897806286848,
    "created_at" : "2015-11-17 00:25:52 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 666412497155526656,
  "created_at" : "2015-11-17 00:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    }, {
      "name" : "Chittenden Humane",
      "screen_name" : "HSCCVT",
      "indices" : [ 62, 69 ],
      "id_str" : "375596192",
      "id" : 375596192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666384951017922560",
  "text" : "RT @CatFoodBreath: This is Noelle with the human she chose at @HSCCVT   Noelle started napping as soon as the adoption was finalized. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chittenden Humane",
        "screen_name" : "HSCCVT",
        "indices" : [ 43, 50 ],
        "id_str" : "375596192",
        "id" : 375596192
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/666369297527230464\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/uJEbYhx5sh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT9rWCJWwAAS-KT.jpg",
        "id_str" : "666369296151527424",
        "id" : 666369296151527424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT9rWCJWwAAS-KT.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 783
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 783
        } ],
        "display_url" : "pic.twitter.com\/uJEbYhx5sh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666369297527230464",
    "text" : "This is Noelle with the human she chose at @HSCCVT   Noelle started napping as soon as the adoption was finalized. https:\/\/t.co\/uJEbYhx5sh",
    "id" : 666369297527230464,
    "created_at" : "2015-11-16 21:36:35 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 666384951017922560,
  "created_at" : "2015-11-16 22:38:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/666372839033958403\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HGV5pWoRkU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT9ukGTXAAAUyqb.jpg",
      "id_str" : "666372836320280576",
      "id" : 666372836320280576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT9ukGTXAAAUyqb.jpg",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HGV5pWoRkU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/2bVCyF5Fow",
      "expanded_url" : "http:\/\/randalrauser.com\/2015\/11\/why-atheists-shouldnt-object-to-the-call-to-pray-for-paris\/?_ts=1447710636",
      "display_url" : "randalrauser.com\/2015\/11\/why-at\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666372839033958403",
  "text" : "Why atheists shouldn\u2019t object to the call to \u201CPray for Paris\u201D https:\/\/t.co\/2bVCyF5Fow https:\/\/t.co\/HGV5pWoRkU",
  "id" : 666372839033958403,
  "created_at" : "2015-11-16 21:50:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666347335736250372",
  "text" : "RT @adamrshields: Or Illinois, Michigan, Alabama, Louisiana, Arkansas, Mississippi, Massachusetts Christianity. (and prob more now)\n https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/8Z7aunphcC",
        "expanded_url" : "https:\/\/twitter.com\/beardonabike\/status\/666323450512830468",
        "display_url" : "twitter.com\/beardonabike\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666326751073705984",
    "text" : "Or Illinois, Michigan, Alabama, Louisiana, Arkansas, Mississippi, Massachusetts Christianity. (and prob more now)\n https:\/\/t.co\/8Z7aunphcC",
    "id" : 666326751073705984,
    "created_at" : "2015-11-16 18:47:31 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 666347335736250372,
  "created_at" : "2015-11-16 20:09:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/458457627723579392\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/c6dIkJ8hLr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlzEyIeIAAA9xJR.jpg",
      "id_str" : "458457627631288320",
      "id" : 458457627631288320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlzEyIeIAAA9xJR.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/c6dIkJ8hLr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666095197827239937",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/c6dIkJ8hLr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/458457627723579392\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/c6dIkJ8hLr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlzEyIeIAAA9xJR.jpg",
        "id_str" : "458457627631288320",
        "id" : 458457627631288320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlzEyIeIAAA9xJR.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/c6dIkJ8hLr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666093361850425344",
    "text" : "https:\/\/t.co\/c6dIkJ8hLr",
    "id" : 666093361850425344,
    "created_at" : "2015-11-16 03:20:07 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 666095197827239937,
  "created_at" : "2015-11-16 03:27:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    }, {
      "name" : "Ann Coulter",
      "screen_name" : "AnnCoulter",
      "indices" : [ 12, 23 ],
      "id_str" : "196168350",
      "id" : 196168350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666093611952545792",
  "text" : "RT @deray: .@AnnCoulter, Dylann Roof walked into bible study &amp; killed nine black folks in cold blood. He wasn't \"imported.\" https:\/\/t.co\/wO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ann Coulter",
        "screen_name" : "AnnCoulter",
        "indices" : [ 1, 12 ],
        "id_str" : "196168350",
        "id" : 196168350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wOV7b3oKTw",
        "expanded_url" : "https:\/\/twitter.com\/anncoulter\/status\/665332917384699904",
        "display_url" : "twitter.com\/anncoulter\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "665356058131431424",
    "text" : ".@AnnCoulter, Dylann Roof walked into bible study &amp; killed nine black folks in cold blood. He wasn't \"imported.\" https:\/\/t.co\/wOV7b3oKTw",
    "id" : 665356058131431424,
    "created_at" : "2015-11-14 02:30:20 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 666093611952545792,
  "created_at" : "2015-11-16 03:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    }, {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 34, 46 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deadfrog",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/IV106ueT6r",
      "expanded_url" : "http:\/\/www.huffingtonpost.co.uk\/rosie-fletcher\/chronic-illness_b_8474036.html",
      "display_url" : "huffingtonpost.co.uk\/rosie-fletcher\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666092759225401345",
  "text" : "Hey @JourneyTheHedgi #deadfrog RT @AlisynGayle: You Aren't Entitled to an Opinion on My Chronic Illness https:\/\/t.co\/IV106ueT6r",
  "id" : 666092759225401345,
  "created_at" : "2015-11-16 03:17:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "indices" : [ 3, 17 ],
      "id_str" : "255780065",
      "id" : 255780065
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharing",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666091218393292800",
  "text" : "RT @Crowtographer: She flew over to me with a whole piece of pizza in her beak. The others were on it in the blink of an eye. #sharing http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Crowtographer\/status\/666064237714894848\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/f06ybGXBqM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT5V5SiWsAQzd_0.jpg",
        "id_str" : "666064237614247940",
        "id" : 666064237614247940,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT5V5SiWsAQzd_0.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/f06ybGXBqM"
      } ],
      "hashtags" : [ {
        "text" : "sharing",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666064237714894848",
    "text" : "She flew over to me with a whole piece of pizza in her beak. The others were on it in the blink of an eye. #sharing https:\/\/t.co\/f06ybGXBqM",
    "id" : 666064237714894848,
    "created_at" : "2015-11-16 01:24:23 +0000",
    "user" : {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "protected" : false,
      "id_str" : "255780065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737547028062863361\/1tOrY86w_normal.jpg",
      "id" : 255780065,
      "verified" : false
    }
  },
  "id" : 666091218393292800,
  "created_at" : "2015-11-16 03:11:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665891700217356288",
  "text" : "@HEATHENRABBIT aww.. looks so content!",
  "id" : 665891700217356288,
  "created_at" : "2015-11-15 13:58:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Ward",
      "screen_name" : "Crystal11",
      "indices" : [ 3, 13 ],
      "id_str" : "14203843",
      "id" : 14203843
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Crystal11\/status\/665733800316407808\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/6ePhTY9E5U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT0pVbUUYAASVGi.jpg",
      "id_str" : "665733768007671808",
      "id" : 665733768007671808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT0pVbUUYAASVGi.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6ePhTY9E5U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665737613672849408",
  "text" : "RT @Crystal11: Rachel is plugged into my usb port to recharge. https:\/\/t.co\/6ePhTY9E5U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Crystal11\/status\/665733800316407808\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/6ePhTY9E5U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT0pVbUUYAASVGi.jpg",
        "id_str" : "665733768007671808",
        "id" : 665733768007671808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT0pVbUUYAASVGi.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6ePhTY9E5U"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665733800316407808",
    "text" : "Rachel is plugged into my usb port to recharge. https:\/\/t.co\/6ePhTY9E5U",
    "id" : 665733800316407808,
    "created_at" : "2015-11-15 03:31:21 +0000",
    "user" : {
      "name" : "Crystal Ward",
      "screen_name" : "Crystal11",
      "protected" : false,
      "id_str" : "14203843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799779578894053377\/5ZovHuOS_normal.jpg",
      "id" : 14203843,
      "verified" : false
    }
  },
  "id" : 665737613672849408,
  "created_at" : "2015-11-15 03:46:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665736477263941633",
  "text" : "RT @gretchenrubin: To find out if you\u2019re an Upholder, Questioner, Obliger, or Rebel,\ntake the Four Tendencies quiz here. https:\/\/t.co\/dTWtH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/dTWtHxC0Fq",
        "expanded_url" : "http:\/\/buff.ly\/1Mp2qxK",
        "display_url" : "buff.ly\/1Mp2qxK"
      } ]
    },
    "geo" : { },
    "id_str" : "665720638343016449",
    "text" : "To find out if you\u2019re an Upholder, Questioner, Obliger, or Rebel,\ntake the Four Tendencies quiz here. https:\/\/t.co\/dTWtHxC0Fq",
    "id" : 665720638343016449,
    "created_at" : "2015-11-15 02:39:03 +0000",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641679033634172928\/PNHwbpt__normal.jpg",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 665736477263941633,
  "created_at" : "2015-11-15 03:41:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 12, 16 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Tx04m0KVN5",
      "expanded_url" : "http:\/\/goo.gl\/9AzFIF",
      "display_url" : "goo.gl\/9AzFIF"
    } ]
  },
  "geo" : { },
  "id_str" : "665733842158936064",
  "text" : "Adorbs!  RT @5x5: All you cat owners know you want one of these for your kitty https:\/\/t.co\/Tx04m0KVN5  :)",
  "id" : 665733842158936064,
  "created_at" : "2015-11-15 03:31:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AidMyLymeDisease",
      "screen_name" : "AidLymeDisease",
      "indices" : [ 3, 18 ],
      "id_str" : "3149847891",
      "id" : 3149847891
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AidLymeDisease\/status\/664457419829956608\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/DfX3TU8ZMo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTiggJiWIAAQ6cb.jpg",
      "id_str" : "664457419213381632",
      "id" : 664457419213381632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTiggJiWIAAQ6cb.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DfX3TU8ZMo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/VXAmUUrgj2",
      "expanded_url" : "https:\/\/www.facebook.com\/permalink.php?story_fbid=405695972888321&id=343269582464294",
      "display_url" : "facebook.com\/permalink.php?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "665559917361778688",
  "text" : "RT @AidLymeDisease: So True!\nhttps:\/\/t.co\/VXAmUUrgj2 https:\/\/t.co\/DfX3TU8ZMo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AidLymeDisease\/status\/664457419829956608\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/DfX3TU8ZMo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTiggJiWIAAQ6cb.jpg",
        "id_str" : "664457419213381632",
        "id" : 664457419213381632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTiggJiWIAAQ6cb.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DfX3TU8ZMo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/VXAmUUrgj2",
        "expanded_url" : "https:\/\/www.facebook.com\/permalink.php?story_fbid=405695972888321&id=343269582464294",
        "display_url" : "facebook.com\/permalink.php?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664457419829956608",
    "text" : "So True!\nhttps:\/\/t.co\/VXAmUUrgj2 https:\/\/t.co\/DfX3TU8ZMo",
    "id" : 664457419829956608,
    "created_at" : "2015-11-11 14:59:28 +0000",
    "user" : {
      "name" : "AidMyLymeDisease",
      "screen_name" : "AidLymeDisease",
      "protected" : false,
      "id_str" : "3149847891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585996849477103616\/t-PvH3QP_normal.jpg",
      "id" : 3149847891,
      "verified" : false
    }
  },
  "id" : 665559917361778688,
  "created_at" : "2015-11-14 16:00:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unvirtuous Abbey",
      "screen_name" : "UnvirtuousAbbey",
      "indices" : [ 3, 19 ],
      "id_str" : "174526877",
      "id" : 174526877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/UnvirtuousAbbey\/status\/665363391788269568\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/kQ7dE47YRz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvYeWkUwAAO7A7.jpg",
      "id_str" : "665363385932890112",
      "id" : 665363385932890112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvYeWkUwAAO7A7.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kQ7dE47YRz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665371558349795328",
  "text" : "RT @UnvirtuousAbbey: https:\/\/t.co\/kQ7dE47YRz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UnvirtuousAbbey\/status\/665363391788269568\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/kQ7dE47YRz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvYeWkUwAAO7A7.jpg",
        "id_str" : "665363385932890112",
        "id" : 665363385932890112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvYeWkUwAAO7A7.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kQ7dE47YRz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665363391788269568",
    "text" : "https:\/\/t.co\/kQ7dE47YRz",
    "id" : 665363391788269568,
    "created_at" : "2015-11-14 02:59:29 +0000",
    "user" : {
      "name" : "Unvirtuous Abbey",
      "screen_name" : "UnvirtuousAbbey",
      "protected" : false,
      "id_str" : "174526877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714045317461753857\/zPXbzkE4_normal.jpg",
      "id" : 174526877,
      "verified" : false
    }
  },
  "id" : 665371558349795328,
  "created_at" : "2015-11-14 03:31:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "indices" : [ 3, 15 ],
      "id_str" : "896548279",
      "id" : 896548279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hope",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665370897478524934",
  "text" : "RT @NaamaYehuda: Terrorists want to worm their way into your safety to make you feel helpless. Don't play by their rules. Keep #hope. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NaamaYehuda\/status\/665364525995175937\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/alrux3X7d4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvZgg-WoAAexS_.jpg",
        "id_str" : "665364522597785600",
        "id" : 665364522597785600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvZgg-WoAAexS_.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/alrux3X7d4"
      } ],
      "hashtags" : [ {
        "text" : "hope",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665364525995175937",
    "text" : "Terrorists want to worm their way into your safety to make you feel helpless. Don't play by their rules. Keep #hope. https:\/\/t.co\/alrux3X7d4",
    "id" : 665364525995175937,
    "created_at" : "2015-11-14 03:03:59 +0000",
    "user" : {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "protected" : false,
      "id_str" : "896548279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2748712360\/5665839cb74057117f99ea3245bba181_normal.jpeg",
      "id" : 896548279,
      "verified" : false
    }
  },
  "id" : 665370897478524934,
  "created_at" : "2015-11-14 03:29:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/665366602716725248\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/IeU3qKnZdc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvbY9gXIAAaOp3.jpg",
      "id_str" : "665366591840919552",
      "id" : 665366591840919552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvbY9gXIAAaOp3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IeU3qKnZdc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665369213746434050",
  "text" : "RT @5thdimdreamz: https:\/\/t.co\/IeU3qKnZdc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/665366602716725248\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/IeU3qKnZdc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvbY9gXIAAaOp3.jpg",
        "id_str" : "665366591840919552",
        "id" : 665366591840919552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvbY9gXIAAaOp3.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IeU3qKnZdc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665366602716725248",
    "text" : "https:\/\/t.co\/IeU3qKnZdc",
    "id" : 665366602716725248,
    "created_at" : "2015-11-14 03:12:14 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 665369213746434050,
  "created_at" : "2015-11-14 03:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Diaz",
      "screen_name" : "MarioPIX11",
      "indices" : [ 3, 14 ],
      "id_str" : "372082312",
      "id" : 372082312
    }, {
      "name" : "PIX11 News",
      "screen_name" : "PIX11News",
      "indices" : [ 118, 128 ],
      "id_str" : "9542972",
      "id" : 9542972
    }, {
      "name" : "edo",
      "screen_name" : "10",
      "indices" : [ 129, 132 ],
      "id_str" : "7888952",
      "id" : 7888952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UnionSquare",
      "indices" : [ 40, 52 ]
    }, {
      "text" : "Paris",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665368373073747969",
  "text" : "RT @MarioPIX11: RIGHT NOW: the scene at #UnionSquare as New Yorkers hold an impromptu vigil following #Paris attacks. @PIX11News @10 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PIX11 News",
        "screen_name" : "PIX11News",
        "indices" : [ 102, 112 ],
        "id_str" : "9542972",
        "id" : 9542972
      }, {
        "name" : "edo",
        "screen_name" : "10",
        "indices" : [ 113, 116 ],
        "id_str" : "7888952",
        "id" : 7888952
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarioPIX11\/status\/665362996198318082\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ufuaJgtVDC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvYFLQWwAAgtNI.jpg",
        "id_str" : "665362953399615488",
        "id" : 665362953399615488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvYFLQWwAAgtNI.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ufuaJgtVDC"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MarioPIX11\/status\/665362996198318082\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ufuaJgtVDC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvYFLSWEAAVxxQ.jpg",
        "id_str" : "665362953407959040",
        "id" : 665362953407959040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvYFLSWEAAVxxQ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ufuaJgtVDC"
      } ],
      "hashtags" : [ {
        "text" : "UnionSquare",
        "indices" : [ 24, 36 ]
      }, {
        "text" : "Paris",
        "indices" : [ 86, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665362996198318082",
    "text" : "RIGHT NOW: the scene at #UnionSquare as New Yorkers hold an impromptu vigil following #Paris attacks. @PIX11News @10 https:\/\/t.co\/ufuaJgtVDC",
    "id" : 665362996198318082,
    "created_at" : "2015-11-14 02:57:54 +0000",
    "user" : {
      "name" : "Mario Diaz",
      "screen_name" : "MarioPIX11",
      "protected" : false,
      "id_str" : "372082312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750006537452597248\/QyUC9f03_normal.jpg",
      "id" : 372082312,
      "verified" : true
    }
  },
  "id" : 665368373073747969,
  "created_at" : "2015-11-14 03:19:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Bryan",
      "screen_name" : "scottygb",
      "indices" : [ 3, 12 ],
      "id_str" : "15721456",
      "id" : 15721456
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scottygb\/status\/665327035766603776\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/FLZMQd1oHk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTu3aCnWcAAlIC1.jpg",
      "id_str" : "665327027973681152",
      "id" : 665327027973681152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTu3aCnWcAAlIC1.jpg",
      "sizes" : [ {
        "h" : 618,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FLZMQd1oHk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665355046792462337",
  "text" : "RT @scottygb: I always find and share this photo when the news is difficult. Because it is always true https:\/\/t.co\/FLZMQd1oHk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scottygb\/status\/665327035766603776\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/FLZMQd1oHk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTu3aCnWcAAlIC1.jpg",
        "id_str" : "665327027973681152",
        "id" : 665327027973681152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTu3aCnWcAAlIC1.jpg",
        "sizes" : [ {
          "h" : 618,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FLZMQd1oHk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665327035766603776",
    "text" : "I always find and share this photo when the news is difficult. Because it is always true https:\/\/t.co\/FLZMQd1oHk",
    "id" : 665327035766603776,
    "created_at" : "2015-11-14 00:35:01 +0000",
    "user" : {
      "name" : "Scott Bryan",
      "screen_name" : "scottygb",
      "protected" : false,
      "id_str" : "15721456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797345320854233089\/fC17fd6-_normal.jpg",
      "id" : 15721456,
      "verified" : true
    }
  },
  "id" : 665355046792462337,
  "created_at" : "2015-11-14 02:26:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665351238389768192",
  "text" : "RT @ZachsMind: Violence on one of us is violence on our entire species. We're doing this to ourselves. it's not that tribe over there attac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665350893118722050",
    "text" : "Violence on one of us is violence on our entire species. We're doing this to ourselves. it's not that tribe over there attacking this one.",
    "id" : 665350893118722050,
    "created_at" : "2015-11-14 02:09:49 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 665351238389768192,
  "created_at" : "2015-11-14 02:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665348912736247809",
  "text" : "master chef junior.. I love how they console each other... bless their sweet hearts.",
  "id" : 665348912736247809,
  "created_at" : "2015-11-14 02:01:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "indices" : [ 3, 12 ],
      "id_str" : "12642282",
      "id" : 12642282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664993174453112832",
  "text" : "RT @dasparky: I sneezed. The geese heard it and are reacting like I just disrespected their ancestors.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664989550368808960",
    "text" : "I sneezed. The geese heard it and are reacting like I just disrespected their ancestors.",
    "id" : 664989550368808960,
    "created_at" : "2015-11-13 02:13:58 +0000",
    "user" : {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "protected" : false,
      "id_str" : "12642282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650055629004902400\/VG1lD7ep_normal.png",
      "id" : 12642282,
      "verified" : false
    }
  },
  "id" : 664993174453112832,
  "created_at" : "2015-11-13 02:28:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664986777183211520",
  "text" : "In dire need of some #woo .. feeling angsty stressed.",
  "id" : 664986777183211520,
  "created_at" : "2015-11-13 02:02:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LesVaches DuTour",
      "screen_name" : "lesvachesdutour",
      "indices" : [ 3, 19 ],
      "id_str" : "274372551",
      "id" : 274372551
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lesvachesdutour\/status\/664968588957081602\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/LoCedqnnt0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTpxaItUsAEBnZZ.jpg",
      "id_str" : "664968588818690049",
      "id" : 664968588818690049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTpxaItUsAEBnZZ.jpg",
      "sizes" : [ {
        "h" : 883,
        "resize" : "fit",
        "w" : 745
      }, {
        "h" : 883,
        "resize" : "fit",
        "w" : 745
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 711,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LoCedqnnt0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664984923011473408",
  "text" : "RT @lesvachesdutour: I know you shouldn't read the comments, but sometimes it pays off... https:\/\/t.co\/LoCedqnnt0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lesvachesdutour\/status\/664968588957081602\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/LoCedqnnt0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTpxaItUsAEBnZZ.jpg",
        "id_str" : "664968588818690049",
        "id" : 664968588818690049,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTpxaItUsAEBnZZ.jpg",
        "sizes" : [ {
          "h" : 883,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 883,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LoCedqnnt0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664968588957081602",
    "text" : "I know you shouldn't read the comments, but sometimes it pays off... https:\/\/t.co\/LoCedqnnt0",
    "id" : 664968588957081602,
    "created_at" : "2015-11-13 00:50:40 +0000",
    "user" : {
      "name" : "LesVaches DuTour",
      "screen_name" : "lesvachesdutour",
      "protected" : false,
      "id_str" : "274372551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477606312860078080\/U8OywTfg_normal.jpeg",
      "id" : 274372551,
      "verified" : false
    }
  },
  "id" : 664984923011473408,
  "created_at" : "2015-11-13 01:55:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "indices" : [ 3, 16 ],
      "id_str" : "1413936181",
      "id" : 1413936181
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FionaJDavies\/status\/664945387476754433\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/XuGRDTQh2R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTpcSaNWcAEZJUZ.jpg",
      "id_str" : "664945366333288449",
      "id" : 664945366333288449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTpcSaNWcAEZJUZ.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XuGRDTQh2R"
    } ],
    "hashtags" : [ {
      "text" : "Calf",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "HillFarming",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664962088847175680",
  "text" : "RT @FionaJDavies: Our little lodger for the night #Calf #HillFarming all warmed up, most likely an abandoned twin. https:\/\/t.co\/XuGRDTQh2R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FionaJDavies\/status\/664945387476754433\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/XuGRDTQh2R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTpcSaNWcAEZJUZ.jpg",
        "id_str" : "664945366333288449",
        "id" : 664945366333288449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTpcSaNWcAEZJUZ.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XuGRDTQh2R"
      } ],
      "hashtags" : [ {
        "text" : "Calf",
        "indices" : [ 32, 37 ]
      }, {
        "text" : "HillFarming",
        "indices" : [ 38, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664945387476754433",
    "text" : "Our little lodger for the night #Calf #HillFarming all warmed up, most likely an abandoned twin. https:\/\/t.co\/XuGRDTQh2R",
    "id" : 664945387476754433,
    "created_at" : "2015-11-12 23:18:29 +0000",
    "user" : {
      "name" : "Fiona",
      "screen_name" : "FionaJDavies",
      "protected" : false,
      "id_str" : "1413936181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456679350880829440\/z2YfOoH2_normal.jpeg",
      "id" : 1413936181,
      "verified" : false
    }
  },
  "id" : 664962088847175680,
  "created_at" : "2015-11-13 00:24:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "indices" : [ 3, 19 ],
      "id_str" : "364856414",
      "id" : 364856414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664647067067895808",
  "text" : "RT @ThomMoorePhotos: Fast asleep on top of my fresh shirt - you know you're living with a cat when you accept they do whatever they want. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/664636377930186753\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HcjbBzMPQd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTlDQxiVEAEB2kS.jpg",
        "id_str" : "664636375468150785",
        "id" : 664636375468150785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTlDQxiVEAEB2kS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2848,
          "resize" : "fit",
          "w" : 2848
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HcjbBzMPQd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664636377930186753",
    "text" : "Fast asleep on top of my fresh shirt - you know you're living with a cat when you accept they do whatever they want. https:\/\/t.co\/HcjbBzMPQd",
    "id" : 664636377930186753,
    "created_at" : "2015-11-12 02:50:35 +0000",
    "user" : {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "protected" : false,
      "id_str" : "364856414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770204744543563776\/cS24tsF9_normal.jpg",
      "id" : 364856414,
      "verified" : false
    }
  },
  "id" : 664647067067895808,
  "created_at" : "2015-11-12 03:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 3, 12 ],
      "id_str" : "524396430",
      "id" : 524396430
    }, {
      "name" : "American Girl",
      "screen_name" : "American_Girl",
      "indices" : [ 82, 96 ],
      "id_str" : "713044332",
      "id" : 713044332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/w6ftVLwXGS",
      "expanded_url" : "http:\/\/u.pw\/1iV5RDV",
      "display_url" : "u.pw\/1iV5RDV"
    } ]
  },
  "geo" : { },
  "id_str" : "664645489028112384",
  "text" : "RT @Upworthy: The incredible story you didn't hear about the gay dads featured in @American_Girl magazine. https:\/\/t.co\/w6ftVLwXGS https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Girl",
        "screen_name" : "American_Girl",
        "indices" : [ 68, 82 ],
        "id_str" : "713044332",
        "id" : 713044332
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Upworthy\/status\/664624425250267136\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9eA748RvhC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTk4ZIHWcAAYHqp.png",
        "id_str" : "664624424340058112",
        "id" : 664624424340058112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTk4ZIHWcAAYHqp.png",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 624,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9eA748RvhC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/w6ftVLwXGS",
        "expanded_url" : "http:\/\/u.pw\/1iV5RDV",
        "display_url" : "u.pw\/1iV5RDV"
      } ]
    },
    "geo" : { },
    "id_str" : "664624425250267136",
    "text" : "The incredible story you didn't hear about the gay dads featured in @American_Girl magazine. https:\/\/t.co\/w6ftVLwXGS https:\/\/t.co\/9eA748RvhC",
    "id" : 664624425250267136,
    "created_at" : "2015-11-12 02:03:05 +0000",
    "user" : {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "protected" : false,
      "id_str" : "524396430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723597465941766144\/piclWuSr_normal.jpg",
      "id" : 524396430,
      "verified" : true
    }
  },
  "id" : 664645489028112384,
  "created_at" : "2015-11-12 03:26:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss Representation",
      "screen_name" : "RepresentPledge",
      "indices" : [ 3, 19 ],
      "id_str" : "225634187",
      "id" : 225634187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/uRP7hd5bC0",
      "expanded_url" : "http:\/\/bit.ly\/1GX3Bb6",
      "display_url" : "bit.ly\/1GX3Bb6"
    } ]
  },
  "geo" : { },
  "id_str" : "664553340697755648",
  "text" : "RT @RepresentPledge: Bloomingdale\u2019s creepy new catalog suggests drugging your friends this holiday season https:\/\/t.co\/uRP7hd5bC0 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepresentPledge\/status\/664493477518946304\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/SOaDKU7obh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTjBJTnXAAQqkWs.png",
        "id_str" : "664493310665490436",
        "id" : 664493310665490436,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTjBJTnXAAQqkWs.png",
        "sizes" : [ {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 982
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 982
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SOaDKU7obh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/uRP7hd5bC0",
        "expanded_url" : "http:\/\/bit.ly\/1GX3Bb6",
        "display_url" : "bit.ly\/1GX3Bb6"
      } ]
    },
    "geo" : { },
    "id_str" : "664493477518946304",
    "text" : "Bloomingdale\u2019s creepy new catalog suggests drugging your friends this holiday season https:\/\/t.co\/uRP7hd5bC0 https:\/\/t.co\/SOaDKU7obh",
    "id" : 664493477518946304,
    "created_at" : "2015-11-11 17:22:45 +0000",
    "user" : {
      "name" : "Miss Representation",
      "screen_name" : "RepresentPledge",
      "protected" : false,
      "id_str" : "225634187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430496143575773185\/VKilFUkM_normal.jpeg",
      "id" : 225634187,
      "verified" : true
    }
  },
  "id" : 664553340697755648,
  "created_at" : "2015-11-11 21:20:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "The Love Guru",
      "screen_name" : "TheLoveGuru1111",
      "indices" : [ 23, 39 ],
      "id_str" : "2740043592",
      "id" : 2740043592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664456502212694016",
  "text" : "RT @JamiaStarheart: RT @TheLoveGuru1111: Act on the basis of love instead of fear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Love Guru",
        "screen_name" : "TheLoveGuru1111",
        "indices" : [ 3, 19 ],
        "id_str" : "2740043592",
        "id" : 2740043592
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664454195148255233",
    "text" : "RT @TheLoveGuru1111: Act on the basis of love instead of fear.",
    "id" : 664454195148255233,
    "created_at" : "2015-11-11 14:46:39 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 664456502212694016,
  "created_at" : "2015-11-11 14:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/dfGt4iecMd",
      "expanded_url" : "http:\/\/omgspace.net",
      "display_url" : "omgspace.net"
    } ]
  },
  "geo" : { },
  "id_str" : "664456470977773568",
  "text" : "RT @micahjmurray: space is so very very huge and we are all so tiny: https:\/\/t.co\/dfGt4iecMd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/dfGt4iecMd",
        "expanded_url" : "http:\/\/omgspace.net",
        "display_url" : "omgspace.net"
      } ]
    },
    "geo" : { },
    "id_str" : "664454258960371712",
    "text" : "space is so very very huge and we are all so tiny: https:\/\/t.co\/dfGt4iecMd",
    "id" : 664454258960371712,
    "created_at" : "2015-11-11 14:46:54 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 664456470977773568,
  "created_at" : "2015-11-11 14:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/569953449204420609\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/JxHlDv21x6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jhpFxIEAAKMxz.jpg",
      "id_str" : "569953448901480448",
      "id" : 569953448901480448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jhpFxIEAAKMxz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/JxHlDv21x6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664268513608114176",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/JxHlDv21x6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/569953449204420609\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/JxHlDv21x6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jhpFxIEAAKMxz.jpg",
        "id_str" : "569953448901480448",
        "id" : 569953448901480448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jhpFxIEAAKMxz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/JxHlDv21x6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664266315658608640",
    "text" : "https:\/\/t.co\/JxHlDv21x6",
    "id" : 664266315658608640,
    "created_at" : "2015-11-11 02:20:05 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 664268513608114176,
  "created_at" : "2015-11-11 02:28:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664239759942774784",
  "geo" : { },
  "id_str" : "664263131720458240",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley exactly what I am thinking...",
  "id" : 664263131720458240,
  "in_reply_to_status_id" : 664239759942774784,
  "created_at" : "2015-11-11 02:07:26 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "indices" : [ 3, 15 ],
      "id_str" : "14345566",
      "id" : 14345566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/BUz0cxcMuw",
      "expanded_url" : "https:\/\/twitter.com\/oatmeal\/status\/664182093514063876",
      "display_url" : "twitter.com\/oatmeal\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664234946844848128",
  "text" : "RT @TheBloggess: Well done, my friend.  https:\/\/t.co\/BUz0cxcMuw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/BUz0cxcMuw",
        "expanded_url" : "https:\/\/twitter.com\/oatmeal\/status\/664182093514063876",
        "display_url" : "twitter.com\/oatmeal\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664232965229051904",
    "text" : "Well done, my friend.  https:\/\/t.co\/BUz0cxcMuw",
    "id" : 664232965229051904,
    "created_at" : "2015-11-11 00:07:34 +0000",
    "user" : {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "protected" : false,
      "id_str" : "14345566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1459362861\/cheesecake_copy2_normal.jpg",
      "id" : 14345566,
      "verified" : true
    }
  },
  "id" : 664234946844848128,
  "created_at" : "2015-11-11 00:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/q66XgITyfK",
      "expanded_url" : "https:\/\/twitter.com\/Mad_In_America\/status\/664214776613064705",
      "display_url" : "twitter.com\/Mad_In_America\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664232977103249408",
  "text" : "wth?? https:\/\/t.co\/q66XgITyfK",
  "id" : 664232977103249408,
  "created_at" : "2015-11-11 00:07:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mysweetcupcake",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/2MT8WqKV64",
      "expanded_url" : "https:\/\/twitter.com\/JourneyTheHedgi\/status\/664195237967998976",
      "display_url" : "twitter.com\/JourneyTheHedg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664217365526290434",
  "text" : "Isn't she precious? &lt;3 #mysweetcupcake https:\/\/t.co\/2MT8WqKV64",
  "id" : 664217365526290434,
  "created_at" : "2015-11-10 23:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664198843471429632",
  "geo" : { },
  "id_str" : "664216927594815488",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley ohh I like!",
  "id" : 664216927594815488,
  "in_reply_to_status_id" : 664198843471429632,
  "created_at" : "2015-11-10 23:03:50 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664188911418081280",
  "geo" : { },
  "id_str" : "664196375765192704",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe (((hugs)))",
  "id" : 664196375765192704,
  "in_reply_to_status_id" : 664188911418081280,
  "created_at" : "2015-11-10 21:42:10 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664125148786741248",
  "geo" : { },
  "id_str" : "664173617849192449",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater is that a dandelion? nice.",
  "id" : 664173617849192449,
  "in_reply_to_status_id" : 664125148786741248,
  "created_at" : "2015-11-10 20:11:44 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663929458215280640",
  "text" : "RT @benjamincorey: What do I do for a living? Gotta say, the best compliment I've ever received was how my daughter described it today: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/UaK1Nqi0n8",
        "expanded_url" : "https:\/\/www.facebook.com\/benjaminlcorey\/posts\/803349179810989",
        "display_url" : "facebook.com\/benjaminlcorey\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663926218111246336",
    "text" : "What do I do for a living? Gotta say, the best compliment I've ever received was how my daughter described it today: https:\/\/t.co\/UaK1Nqi0n8",
    "id" : 663926218111246336,
    "created_at" : "2015-11-10 03:48:40 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 663929458215280640,
  "created_at" : "2015-11-10 04:01:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "indices" : [ 3, 15 ],
      "id_str" : "1370358499",
      "id" : 1370358499
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/663400152242237440\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/7lXp9oZQE5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTTe5xiWEAETaTG.jpg",
      "id_str" : "663400129261604865",
      "id" : 663400129261604865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTTe5xiWEAETaTG.jpg",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7lXp9oZQE5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/663400152242237440\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/7lXp9oZQE5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTTe57XXIAAmEAw.jpg",
      "id_str" : "663400131899891712",
      "id" : 663400131899891712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTTe57XXIAAmEAw.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7lXp9oZQE5"
    } ],
    "hashtags" : [ {
      "text" : "swans",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "birds",
      "indices" : [ 32, 38 ]
    }, {
      "text" : "nature",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663928469269651460",
  "text" : "RT @lisasardini: Harmony #swans #birds #nature https:\/\/t.co\/7lXp9oZQE5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/663400152242237440\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/7lXp9oZQE5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTTe5xiWEAETaTG.jpg",
        "id_str" : "663400129261604865",
        "id" : 663400129261604865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTTe5xiWEAETaTG.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7lXp9oZQE5"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/663400152242237440\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/7lXp9oZQE5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTTe57XXIAAmEAw.jpg",
        "id_str" : "663400131899891712",
        "id" : 663400131899891712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTTe57XXIAAmEAw.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7lXp9oZQE5"
      } ],
      "hashtags" : [ {
        "text" : "swans",
        "indices" : [ 8, 14 ]
      }, {
        "text" : "birds",
        "indices" : [ 15, 21 ]
      }, {
        "text" : "nature",
        "indices" : [ 22, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663400152242237440",
    "text" : "Harmony #swans #birds #nature https:\/\/t.co\/7lXp9oZQE5",
    "id" : 663400152242237440,
    "created_at" : "2015-11-08 16:58:16 +0000",
    "user" : {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "protected" : false,
      "id_str" : "1370358499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794929677102092289\/U4HUzkeG_normal.jpg",
      "id" : 1370358499,
      "verified" : false
    }
  },
  "id" : 663928469269651460,
  "created_at" : "2015-11-10 03:57:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663926991545069568",
  "text" : "RT @JosephRanseth: Before falling asleep, spend at least 15 minutes filling your mind with thoughts worth marinating your mind in while you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663924521041305600",
    "text" : "Before falling asleep, spend at least 15 minutes filling your mind with thoughts worth marinating your mind in while you sleep.",
    "id" : 663924521041305600,
    "created_at" : "2015-11-10 03:41:55 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 663926991545069568,
  "created_at" : "2015-11-10 03:51:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Marshall",
      "screen_name" : "LaurieMMarshall",
      "indices" : [ 3, 19 ],
      "id_str" : "15600113",
      "id" : 15600113
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 106, 118 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663926873924194305",
  "text" : "RT @LaurieMMarshall: Do you have a planner for 2016 yet? Passion Planner: Get One, Give One is popular on @Kickstarter! https:\/\/t.co\/7HQakq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 85, 97 ],
        "id_str" : "16186995",
        "id" : 16186995
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getbusy",
        "indices" : [ 123, 131 ]
      }, {
        "text" : "newyear",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/7HQakqiXyo",
        "expanded_url" : "http:\/\/kck.st\/1jvL0Ym",
        "display_url" : "kck.st\/1jvL0Ym"
      } ]
    },
    "geo" : { },
    "id_str" : "663911374737698816",
    "text" : "Do you have a planner for 2016 yet? Passion Planner: Get One, Give One is popular on @Kickstarter! https:\/\/t.co\/7HQakqiXyo #getbusy #newyear",
    "id" : 663911374737698816,
    "created_at" : "2015-11-10 02:49:41 +0000",
    "user" : {
      "name" : "Laurie Marshall",
      "screen_name" : "LaurieMMarshall",
      "protected" : false,
      "id_str" : "15600113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755577467377553408\/uYLAE9_h_normal.jpg",
      "id" : 15600113,
      "verified" : false
    }
  },
  "id" : 663926873924194305,
  "created_at" : "2015-11-10 03:51:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663921635641135105",
  "text" : "RT @johnpavlovitz: Most people just want to know that they are heard and seen and that they matter. In this life assure as many people of t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663921308711968768",
    "text" : "Most people just want to know that they are heard and seen and that they matter. In this life assure as many people of this as you are able.",
    "id" : 663921308711968768,
    "created_at" : "2015-11-10 03:29:09 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 663921635641135105,
  "created_at" : "2015-11-10 03:30:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackfish Brigade",
      "screen_name" : "Blackfished",
      "indices" : [ 3, 15 ],
      "id_str" : "2234952033",
      "id" : 2234952033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "ORCAact",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "AB2140",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GThESHoGt4",
      "expanded_url" : "http:\/\/fb.me\/7Pvd9NRVe",
      "display_url" : "fb.me\/7Pvd9NRVe"
    } ]
  },
  "geo" : { },
  "id_str" : "663920638072119296",
  "text" : "RT @Blackfished: CNN said Monday that it plans to air an encore of #Blackfish at 6 p.m. Saturday!! #ORCAact #AB2140 https:\/\/t.co\/GThESHoGt4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "ORCAact",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "AB2140",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/GThESHoGt4",
        "expanded_url" : "http:\/\/fb.me\/7Pvd9NRVe",
        "display_url" : "fb.me\/7Pvd9NRVe"
      } ]
    },
    "geo" : { },
    "id_str" : "663919708706643968",
    "text" : "CNN said Monday that it plans to air an encore of #Blackfish at 6 p.m. Saturday!! #ORCAact #AB2140 https:\/\/t.co\/GThESHoGt4",
    "id" : 663919708706643968,
    "created_at" : "2015-11-10 03:22:48 +0000",
    "user" : {
      "name" : "Blackfish Brigade",
      "screen_name" : "Blackfished",
      "protected" : false,
      "id_str" : "2234952033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738347040170708992\/nW7VFxD1_normal.jpg",
      "id" : 2234952033,
      "verified" : false
    }
  },
  "id" : 663920638072119296,
  "created_at" : "2015-11-10 03:26:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663920015813517312",
  "text" : "RT @Adenovir: Limiting opportunities for voter registration and early voting in no way reduce fraud. This should be clearly illegal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663914956601974785",
    "text" : "Limiting opportunities for voter registration and early voting in no way reduce fraud. This should be clearly illegal.",
    "id" : 663914956601974785,
    "created_at" : "2015-11-10 03:03:55 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 663920015813517312,
  "created_at" : "2015-11-10 03:24:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "wombat1974",
      "indices" : [ 3, 14 ],
      "id_str" : "25795191",
      "id" : 25795191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663919543987937280",
  "text" : "RT @wombat1974: I wish my high school guidance counsellor would have suggested \"hermit\" as a career option. I think I could really commit t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663889778673225728",
    "text" : "I wish my high school guidance counsellor would have suggested \"hermit\" as a career option. I think I could really commit to that",
    "id" : 663889778673225728,
    "created_at" : "2015-11-10 01:23:52 +0000",
    "user" : {
      "name" : "Andrew",
      "screen_name" : "wombat1974",
      "protected" : false,
      "id_str" : "25795191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562020957133352960\/beqLlYfV_normal.jpeg",
      "id" : 25795191,
      "verified" : false
    }
  },
  "id" : 663919543987937280,
  "created_at" : "2015-11-10 03:22:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nora Crest",
      "screen_name" : "1RagingBuddha",
      "indices" : [ 3, 17 ],
      "id_str" : "185374248",
      "id" : 185374248
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TroubleMaker",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/NmF4dVWDLS",
      "expanded_url" : "https:\/\/instagram.com\/p\/94U6OwOh1c\/",
      "display_url" : "instagram.com\/p\/94U6OwOh1c\/"
    } ]
  },
  "geo" : { },
  "id_str" : "663908652592549892",
  "text" : "RT @1RagingBuddha: What?? Do I have something on my shirt? #TroubleMaker https:\/\/t.co\/NmF4dVWDLS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TroubleMaker",
        "indices" : [ 40, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/NmF4dVWDLS",
        "expanded_url" : "https:\/\/instagram.com\/p\/94U6OwOh1c\/",
        "display_url" : "instagram.com\/p\/94U6OwOh1c\/"
      } ]
    },
    "geo" : { },
    "id_str" : "663839044644810752",
    "text" : "What?? Do I have something on my shirt? #TroubleMaker https:\/\/t.co\/NmF4dVWDLS",
    "id" : 663839044644810752,
    "created_at" : "2015-11-09 22:02:16 +0000",
    "user" : {
      "name" : "Nora Crest",
      "screen_name" : "1RagingBuddha",
      "protected" : false,
      "id_str" : "185374248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798217077521727488\/_MCLhGei_normal.jpg",
      "id" : 185374248,
      "verified" : false
    }
  },
  "id" : 663908652592549892,
  "created_at" : "2015-11-10 02:38:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jermaine Warren",
      "screen_name" : "iamjermainew",
      "indices" : [ 3, 16 ],
      "id_str" : "222659560",
      "id" : 222659560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iamjermainew\/status\/663890591139385344\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2LaOqKjng4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTac-Z_WwAAujee.jpg",
      "id_str" : "663890591026167808",
      "id" : 663890591026167808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTac-Z_WwAAujee.jpg",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2LaOqKjng4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663908431489814528",
  "text" : "RT @iamjermainew: when you have people to oppress but didn't take a lunch https:\/\/t.co\/2LaOqKjng4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iamjermainew\/status\/663890591139385344\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/2LaOqKjng4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTac-Z_WwAAujee.jpg",
        "id_str" : "663890591026167808",
        "id" : 663890591026167808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTac-Z_WwAAujee.jpg",
        "sizes" : [ {
          "h" : 439,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/2LaOqKjng4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663890591139385344",
    "text" : "when you have people to oppress but didn't take a lunch https:\/\/t.co\/2LaOqKjng4",
    "id" : 663890591139385344,
    "created_at" : "2015-11-10 01:27:06 +0000",
    "user" : {
      "name" : "Jermaine Warren",
      "screen_name" : "iamjermainew",
      "protected" : false,
      "id_str" : "222659560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769277395236900864\/z3V7raC9_normal.jpg",
      "id" : 222659560,
      "verified" : false
    }
  },
  "id" : 663908431489814528,
  "created_at" : "2015-11-10 02:37:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thedress",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/83ZjqKhEIf",
      "expanded_url" : "http:\/\/www.rethinkinghell.com\/2015\/02\/hell-and-thedress\/",
      "display_url" : "rethinkinghell.com\/2015\/02\/hell-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663893252093968384",
  "text" : "Hell and #thedress | Rethinking HellRethinking Hell https:\/\/t.co\/83ZjqKhEIf",
  "id" : 663893252093968384,
  "created_at" : "2015-11-10 01:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Present & Correct",
      "screen_name" : "presentcorrect",
      "indices" : [ 3, 18 ],
      "id_str" : "20228975",
      "id" : 20228975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/dbir9WNOtv",
      "expanded_url" : "http:\/\/tinyurl.com\/o3kmnm7",
      "display_url" : "tinyurl.com\/o3kmnm7"
    } ]
  },
  "geo" : { },
  "id_str" : "663738813873786880",
  "text" : "RT @presentcorrect: A handwriting book teaching you how to turn letters into animals.\nAnimal Antics, 1955. Pt 1\n\nhttps:\/\/t.co\/dbir9WNOtv ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/presentcorrect\/status\/662702742436212736\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/SgYK568ASG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJkn7ZWIAAT632.jpg",
        "id_str" : "662702732298559488",
        "id" : 662702732298559488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJkn7ZWIAAT632.jpg",
        "sizes" : [ {
          "h" : 626,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 626,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SgYK568ASG"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/presentcorrect\/status\/662702742436212736\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/SgYK568ASG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJkn7dWIAAsBG4.jpg",
        "id_str" : "662702732315336704",
        "id" : 662702732315336704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJkn7dWIAAsBG4.jpg",
        "sizes" : [ {
          "h" : 472,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SgYK568ASG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/dbir9WNOtv",
        "expanded_url" : "http:\/\/tinyurl.com\/o3kmnm7",
        "display_url" : "tinyurl.com\/o3kmnm7"
      } ]
    },
    "geo" : { },
    "id_str" : "662702742436212736",
    "text" : "A handwriting book teaching you how to turn letters into animals.\nAnimal Antics, 1955. Pt 1\n\nhttps:\/\/t.co\/dbir9WNOtv https:\/\/t.co\/SgYK568ASG",
    "id" : 662702742436212736,
    "created_at" : "2015-11-06 18:47:00 +0000",
    "user" : {
      "name" : "Present & Correct",
      "screen_name" : "presentcorrect",
      "protected" : false,
      "id_str" : "20228975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581437413991559168\/rm3l6elr_normal.jpg",
      "id" : 20228975,
      "verified" : false
    }
  },
  "id" : 663738813873786880,
  "created_at" : "2015-11-09 15:23:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel Scenes \u2708\uFE0F",
      "screen_name" : "TheWorldStories",
      "indices" : [ 3, 19 ],
      "id_str" : "284441324",
      "id" : 284441324
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/5yfvtlZjm2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1luOVAAAJdSV.jpg",
      "id_str" : "632462826104225792",
      "id" : 632462826104225792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1luOVAAAJdSV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 579
      } ],
      "display_url" : "pic.twitter.com\/5yfvtlZjm2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/5yfvtlZjm2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1lutUwAEsdHA.jpg",
      "id_str" : "632462826234232833",
      "id" : 632462826234232833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1lutUwAEsdHA.jpg",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5yfvtlZjm2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/5yfvtlZjm2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1lumUEAAxaf3.jpg",
      "id_str" : "632462826204827648",
      "id" : 632462826204827648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1lumUEAAxaf3.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 584
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 584
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 584
      } ],
      "display_url" : "pic.twitter.com\/5yfvtlZjm2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/5yfvtlZjm2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1luzUsAAoCap.jpg",
      "id_str" : "632462826259394560",
      "id" : 632462826259394560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1luzUsAAoCap.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 579
      } ],
      "display_url" : "pic.twitter.com\/5yfvtlZjm2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663564643869302784",
  "text" : "RT @TheWorldStories: Take me to the Wisteria Flower Tunnel in Japan! \uD83D\uDE0D\uD83C\uDF3A\uD83C\uDF38 http:\/\/t.co\/5yfvtlZjm2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5yfvtlZjm2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1luOVAAAJdSV.jpg",
        "id_str" : "632462826104225792",
        "id" : 632462826104225792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1luOVAAAJdSV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/5yfvtlZjm2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5yfvtlZjm2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1lutUwAEsdHA.jpg",
        "id_str" : "632462826234232833",
        "id" : 632462826234232833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1lutUwAEsdHA.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5yfvtlZjm2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5yfvtlZjm2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1lumUEAAxaf3.jpg",
        "id_str" : "632462826204827648",
        "id" : 632462826204827648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1lumUEAAxaf3.jpg",
        "sizes" : [ {
          "h" : 322,
          "resize" : "fit",
          "w" : 584
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 584
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 584
        } ],
        "display_url" : "pic.twitter.com\/5yfvtlZjm2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TheWorldStories\/status\/632462890063167488\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5yfvtlZjm2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMb1luzUsAAoCap.jpg",
        "id_str" : "632462826259394560",
        "id" : 632462826259394560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMb1luzUsAAoCap.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/5yfvtlZjm2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632462890063167488",
    "text" : "Take me to the Wisteria Flower Tunnel in Japan! \uD83D\uDE0D\uD83C\uDF3A\uD83C\uDF38 http:\/\/t.co\/5yfvtlZjm2",
    "id" : 632462890063167488,
    "created_at" : "2015-08-15 08:04:38 +0000",
    "user" : {
      "name" : "Travel Scenes \u2708\uFE0F",
      "screen_name" : "TheWorldStories",
      "protected" : false,
      "id_str" : "284441324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784101013686890496\/AtMkb01T_normal.jpg",
      "id" : 284441324,
      "verified" : false
    }
  },
  "id" : 663564643869302784,
  "created_at" : "2015-11-09 03:51:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Totten",
      "screen_name" : "2LiveUnchained",
      "indices" : [ 3, 18 ],
      "id_str" : "217213819",
      "id" : 217213819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663539074993668096",
  "text" : "RT @2LiveUnchained: What the fuck is \"verbal judo\" training?? Is this training other police across the country get??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "663532064856219648",
    "geo" : { },
    "id_str" : "663535067201994756",
    "in_reply_to_user_id" : 217213819,
    "text" : "What the fuck is \"verbal judo\" training?? Is this training other police across the country get??",
    "id" : 663535067201994756,
    "in_reply_to_status_id" : 663532064856219648,
    "created_at" : "2015-11-09 01:54:22 +0000",
    "in_reply_to_screen_name" : "2LiveUnchained",
    "in_reply_to_user_id_str" : "217213819",
    "user" : {
      "name" : "Erika Totten",
      "screen_name" : "2LiveUnchained",
      "protected" : false,
      "id_str" : "217213819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784546367259697152\/n7l4uaCJ_normal.jpg",
      "id" : 217213819,
      "verified" : false
    }
  },
  "id" : 663539074993668096,
  "created_at" : "2015-11-09 02:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "indices" : [ 3, 15 ],
      "id_str" : "896548279",
      "id" : 896548279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cognitive",
      "indices" : [ 90, 100 ]
    }, {
      "text" : "social",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "Playmatters",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663535789494697984",
  "text" : "RT @NaamaYehuda: Play is the work of childhood. Learning matters but play is essential to #cognitive #social development #Playmatters https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cognitive",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "social",
        "indices" : [ 84, 91 ]
      }, {
        "text" : "Playmatters",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/vjekwlpU8S",
        "expanded_url" : "https:\/\/twitter.com\/kimberlyehart\/status\/663488820541792256",
        "display_url" : "twitter.com\/kimberlyehart\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663533174325157889",
    "text" : "Play is the work of childhood. Learning matters but play is essential to #cognitive #social development #Playmatters https:\/\/t.co\/vjekwlpU8S",
    "id" : 663533174325157889,
    "created_at" : "2015-11-09 01:46:51 +0000",
    "user" : {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "protected" : false,
      "id_str" : "896548279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2748712360\/5665839cb74057117f99ea3245bba181_normal.jpeg",
      "id" : 896548279,
      "verified" : false
    }
  },
  "id" : 663535789494697984,
  "created_at" : "2015-11-09 01:57:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/c74Mb9Sblt",
      "expanded_url" : "https:\/\/twitter.com\/Eden_Eats\/status\/663406175950508032",
      "display_url" : "twitter.com\/Eden_Eats\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663439944606687233",
  "text" : "I didnt smoke but I was an outsider... https:\/\/t.co\/c74Mb9Sblt",
  "id" : 663439944606687233,
  "created_at" : "2015-11-08 19:36:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/663429085926924289\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/MYmMBYPbHT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTT5MtAWwAAJ9NI.jpg",
      "id_str" : "663429041765138432",
      "id" : 663429041765138432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTT5MtAWwAAJ9NI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MYmMBYPbHT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/663429085926924289\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/MYmMBYPbHT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTT5MtkWcAA6YZk.jpg",
      "id_str" : "663429041916112896",
      "id" : 663429041916112896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTT5MtkWcAA6YZk.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MYmMBYPbHT"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663439185613819904",
  "text" : "RT @newlandfarm: Don't you just hate it when you can't quite reach the itch #dailyMorag https:\/\/t.co\/MYmMBYPbHT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/663429085926924289\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/MYmMBYPbHT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTT5MtAWwAAJ9NI.jpg",
        "id_str" : "663429041765138432",
        "id" : 663429041765138432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTT5MtAWwAAJ9NI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MYmMBYPbHT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/663429085926924289\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/MYmMBYPbHT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTT5MtkWcAA6YZk.jpg",
        "id_str" : "663429041916112896",
        "id" : 663429041916112896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTT5MtkWcAA6YZk.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MYmMBYPbHT"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663429085926924289",
    "text" : "Don't you just hate it when you can't quite reach the itch #dailyMorag https:\/\/t.co\/MYmMBYPbHT",
    "id" : 663429085926924289,
    "created_at" : "2015-11-08 18:53:14 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 663439185613819904,
  "created_at" : "2015-11-08 19:33:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WCCO - CBS Minnesota",
      "screen_name" : "WCCO",
      "indices" : [ 3, 8 ],
      "id_str" : "13000872",
      "id" : 13000872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/DxPpFxLmdK",
      "expanded_url" : "http:\/\/cbsloc.al\/1XVfsdE",
      "display_url" : "cbsloc.al\/1XVfsdE"
    } ]
  },
  "geo" : { },
  "id_str" : "662839418064117760",
  "text" : "RT @WCCO: Did you know there are thousands of sandhill cranes passing through Minnesota right now?  | https:\/\/t.co\/DxPpFxLmdK https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WCCO\/status\/662831120392712192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/iEfjZbNZVl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTLCW66W4AAr2ge.jpg",
        "id_str" : "662805794203820032",
        "id" : 662805794203820032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTLCW66W4AAr2ge.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/iEfjZbNZVl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/DxPpFxLmdK",
        "expanded_url" : "http:\/\/cbsloc.al\/1XVfsdE",
        "display_url" : "cbsloc.al\/1XVfsdE"
      } ]
    },
    "geo" : { },
    "id_str" : "662831120392712192",
    "text" : "Did you know there are thousands of sandhill cranes passing through Minnesota right now?  | https:\/\/t.co\/DxPpFxLmdK https:\/\/t.co\/iEfjZbNZVl",
    "id" : 662831120392712192,
    "created_at" : "2015-11-07 03:17:08 +0000",
    "user" : {
      "name" : "WCCO - CBS Minnesota",
      "screen_name" : "WCCO",
      "protected" : false,
      "id_str" : "13000872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570911478966808576\/V3Z-IVYi_normal.jpeg",
      "id" : 13000872,
      "verified" : true
    }
  },
  "id" : 662839418064117760,
  "created_at" : "2015-11-07 03:50:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmartNews",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/w5anM6YpaZ",
      "expanded_url" : "http:\/\/smar.ws\/xKmZc",
      "display_url" : "smar.ws\/xKmZc"
    } ]
  },
  "geo" : { },
  "id_str" : "662838328492957696",
  "text" : "RT @5thdimdreamz: Ex-NFL Player Says Weed Helped Him Kick Pills, Suicidal Thoughts https:\/\/t.co\/w5anM6YpaZ #SmartNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmartNews",
        "indices" : [ 89, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/w5anM6YpaZ",
        "expanded_url" : "http:\/\/smar.ws\/xKmZc",
        "display_url" : "smar.ws\/xKmZc"
      } ]
    },
    "geo" : { },
    "id_str" : "662837085766860800",
    "text" : "Ex-NFL Player Says Weed Helped Him Kick Pills, Suicidal Thoughts https:\/\/t.co\/w5anM6YpaZ #SmartNews",
    "id" : 662837085766860800,
    "created_at" : "2015-11-07 03:40:50 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 662838328492957696,
  "created_at" : "2015-11-07 03:45:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imperator Letha \uD83C\uDD70",
      "screen_name" : "Letha_Hughes",
      "indices" : [ 3, 16 ],
      "id_str" : "550423777",
      "id" : 550423777
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Humanist",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "Atheist",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "Secular",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "Skeptic",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662830852984971264",
  "text" : "RT @Letha_Hughes: We can't have freedom OF religion without a government free FROM religion\n\n#Humanist\n#Atheist\n#Secular\n#Skeptic https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Letha_Hughes\/status\/661032993109110785\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/5TmIn3NgDG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSx1-qtUwAA0y4T.jpg",
        "id_str" : "661032964793352192",
        "id" : 661032964793352192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSx1-qtUwAA0y4T.jpg",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 420
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 420
        } ],
        "display_url" : "pic.twitter.com\/5TmIn3NgDG"
      } ],
      "hashtags" : [ {
        "text" : "Humanist",
        "indices" : [ 75, 84 ]
      }, {
        "text" : "Atheist",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "Secular",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "Skeptic",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661032993109110785",
    "text" : "We can't have freedom OF religion without a government free FROM religion\n\n#Humanist\n#Atheist\n#Secular\n#Skeptic https:\/\/t.co\/5TmIn3NgDG",
    "id" : 661032993109110785,
    "created_at" : "2015-11-02 04:12:01 +0000",
    "user" : {
      "name" : "Imperator Letha \uD83C\uDD70",
      "screen_name" : "Letha_Hughes",
      "protected" : false,
      "id_str" : "550423777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798199882934878208\/Wl25SyR-_normal.jpg",
      "id" : 550423777,
      "verified" : false
    }
  },
  "id" : 662830852984971264,
  "created_at" : "2015-11-07 03:16:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Fine Art America",
      "screen_name" : "FineArtAmerica",
      "indices" : [ 85, 100 ],
      "id_str" : "16828262",
      "id" : 16828262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/nUCq6dTppZ",
      "expanded_url" : "http:\/\/fineartamerica.com\/featured\/house-hunting-kerri-farley.html",
      "display_url" : "fineartamerica.com\/featured\/house\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662812047307091968",
  "text" : "RT @KerriFar: Mr Bluebird was .... - 'House Hunting' - https:\/\/t.co\/nUCq6dTppZ - via @FineArtAmerica  #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fine Art America",
        "screen_name" : "FineArtAmerica",
        "indices" : [ 71, 86 ],
        "id_str" : "16828262",
        "id" : 16828262
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/nUCq6dTppZ",
        "expanded_url" : "http:\/\/fineartamerica.com\/featured\/house-hunting-kerri-farley.html",
        "display_url" : "fineartamerica.com\/featured\/house\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "662808043588067328",
    "text" : "Mr Bluebird was .... - 'House Hunting' - https:\/\/t.co\/nUCq6dTppZ - via @FineArtAmerica  #birds",
    "id" : 662808043588067328,
    "created_at" : "2015-11-07 01:45:26 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 662812047307091968,
  "created_at" : "2015-11-07 02:01:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "indices" : [ 3, 15 ],
      "id_str" : "2233154425",
      "id" : 2233154425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StephenKing\/status\/660632294256975872\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8hj3wUb5KI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSsJkgmWoAA-aZq.jpg",
      "id_str" : "660632293170651136",
      "id" : 660632293170651136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSsJkgmWoAA-aZq.jpg",
      "sizes" : [ {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 956
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 956
      } ],
      "display_url" : "pic.twitter.com\/8hj3wUb5KI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662810943840210944",
  "text" : "RT @StephenKing: Molly, aka the Thing of Evil, demonstrates the difficult yoga posture called My Ass Is Up. https:\/\/t.co\/8hj3wUb5KI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StephenKing\/status\/660632294256975872\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/8hj3wUb5KI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSsJkgmWoAA-aZq.jpg",
        "id_str" : "660632293170651136",
        "id" : 660632293170651136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSsJkgmWoAA-aZq.jpg",
        "sizes" : [ {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 956
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 956
        } ],
        "display_url" : "pic.twitter.com\/8hj3wUb5KI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660632294256975872",
    "text" : "Molly, aka the Thing of Evil, demonstrates the difficult yoga posture called My Ass Is Up. https:\/\/t.co\/8hj3wUb5KI",
    "id" : 660632294256975872,
    "created_at" : "2015-11-01 01:39:47 +0000",
    "user" : {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "protected" : false,
      "id_str" : "2233154425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000836981162\/b683f7509ec792c3e481ead332940cdc_normal.jpeg",
      "id" : 2233154425,
      "verified" : true
    }
  },
  "id" : 662810943840210944,
  "created_at" : "2015-11-07 01:56:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSNBCDebate",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662810243169165312",
  "text" : "Go Bernie! &lt;3 #MSNBCDebate",
  "id" : 662810243169165312,
  "created_at" : "2015-11-07 01:54:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Hogben",
      "screen_name" : "MyDaughtersArmy",
      "indices" : [ 3, 19 ],
      "id_str" : "2196201139",
      "id" : 2196201139
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mydaughtersarmy\/status\/662669794815049728\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/69o0k6xYVH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJGqqMUkAEj4-I.jpg",
      "id_str" : "662669793871302657",
      "id" : 662669793871302657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJGqqMUkAEj4-I.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 733
      } ],
      "display_url" : "pic.twitter.com\/69o0k6xYVH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662722780408889345",
  "text" : "RT @mydaughtersarmy: Race https:\/\/t.co\/69o0k6xYVH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mydaughtersarmy\/status\/662669794815049728\/photo\/1",
        "indices" : [ 5, 28 ],
        "url" : "https:\/\/t.co\/69o0k6xYVH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJGqqMUkAEj4-I.jpg",
        "id_str" : "662669793871302657",
        "id" : 662669793871302657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJGqqMUkAEj4-I.jpg",
        "sizes" : [ {
          "h" : 380,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 733
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 733
        } ],
        "display_url" : "pic.twitter.com\/69o0k6xYVH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662669794815049728",
    "text" : "Race https:\/\/t.co\/69o0k6xYVH",
    "id" : 662669794815049728,
    "created_at" : "2015-11-06 16:36:05 +0000",
    "user" : {
      "name" : "Greg Hogben",
      "screen_name" : "MyDaughtersArmy",
      "protected" : false,
      "id_str" : "2196201139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562051396070289411\/Ivgy9n2R_normal.jpeg",
      "id" : 2196201139,
      "verified" : true
    }
  },
  "id" : 662722780408889345,
  "created_at" : "2015-11-06 20:06:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey North",
      "screen_name" : "journeynorthorg",
      "indices" : [ 3, 19 ],
      "id_str" : "1158168006",
      "id" : 1158168006
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "monarch",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/w60KILHfpO",
      "expanded_url" : "http:\/\/bit.ly\/1SouPs5",
      "display_url" : "bit.ly\/1SouPs5"
    } ]
  },
  "geo" : { },
  "id_str" : "662474974414905344",
  "text" : "RT @journeynorthorg: First #monarch butterflies arriving! Crossing finish line at winter home in Mexico.\nhttps:\/\/t.co\/w60KILHfpO https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/journeynorthorg\/status\/661942201941942272\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/QdziYMIwpO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS-w7NAUcAAJoZz.jpg",
        "id_str" : "661942201396523008",
        "id" : 661942201396523008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS-w7NAUcAAJoZz.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QdziYMIwpO"
      } ],
      "hashtags" : [ {
        "text" : "monarch",
        "indices" : [ 6, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/w60KILHfpO",
        "expanded_url" : "http:\/\/bit.ly\/1SouPs5",
        "display_url" : "bit.ly\/1SouPs5"
      } ]
    },
    "geo" : { },
    "id_str" : "661942201941942272",
    "text" : "First #monarch butterflies arriving! Crossing finish line at winter home in Mexico.\nhttps:\/\/t.co\/w60KILHfpO https:\/\/t.co\/QdziYMIwpO",
    "id" : 661942201941942272,
    "created_at" : "2015-11-04 16:24:53 +0000",
    "user" : {
      "name" : "Journey North",
      "screen_name" : "journeynorthorg",
      "protected" : false,
      "id_str" : "1158168006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609076526533869569\/4F1_-A7s_normal.png",
      "id" : 1158168006,
      "verified" : false
    }
  },
  "id" : 662474974414905344,
  "created_at" : "2015-11-06 03:41:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deanna Raybourn",
      "screen_name" : "deannaraybourn",
      "indices" : [ 3, 18 ],
      "id_str" : "24889807",
      "id" : 24889807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662471746457595904",
  "text" : "RT @deannaraybourn: I've. Got. Stars. Nobody move. Don't look directly at them. You might scare them off.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662463020895969282",
    "text" : "I've. Got. Stars. Nobody move. Don't look directly at them. You might scare them off.",
    "id" : 662463020895969282,
    "created_at" : "2015-11-06 02:54:26 +0000",
    "user" : {
      "name" : "Deanna Raybourn",
      "screen_name" : "deannaraybourn",
      "protected" : false,
      "id_str" : "24889807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3490197253\/67d0a672dea7ca616826d9e7a7953402_normal.jpeg",
      "id" : 24889807,
      "verified" : true
    }
  },
  "id" : 662471746457595904,
  "created_at" : "2015-11-06 03:29:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 52, 64 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/589414927837822977\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/EwYMOhY9QM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC4Frg3W8AAx0h7.jpg",
      "id_str" : "589414846346752000",
      "id" : 589414846346752000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC4Frg3W8AAx0h7.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EwYMOhY9QM"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/589414927837822977\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/EwYMOhY9QM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC4FrhZWEAAiX0P.jpg",
      "id_str" : "589414846489300992",
      "id" : 589414846489300992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC4FrhZWEAAiX0P.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EwYMOhY9QM"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/589414927837822977\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/EwYMOhY9QM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC4FrjaWgAAP-uP.jpg",
      "id_str" : "589414847030394880",
      "id" : 589414847030394880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC4FrjaWgAAP-uP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EwYMOhY9QM"
    } ],
    "hashtags" : [ {
      "text" : "calfpix",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662466891710144512",
  "text" : "Sooo smoochable!! I just kissed my screen! &lt;3 RT @newlandfarm: Mrs Hooper's Morag #calfpix https:\/\/t.co\/EwYMOhY9QM",
  "id" : 662466891710144512,
  "created_at" : "2015-11-06 03:09:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662464122630610944",
  "text" : "RT @ZachsMind: not to be \"Politically Correct\" about it, but those who have intellectual disabilities don't deserve to be the butt of our j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662456424019046400",
    "text" : "not to be \"Politically Correct\" about it, but those who have intellectual disabilities don't deserve to be the butt of our jokes.",
    "id" : 662456424019046400,
    "created_at" : "2015-11-06 02:28:13 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 662464122630610944,
  "created_at" : "2015-11-06 02:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "PhrenologyToday",
      "screen_name" : "Phrenologicus",
      "indices" : [ 72, 86 ],
      "id_str" : "465672119",
      "id" : 465672119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662464075893460992",
  "text" : "RT @ZachsMind: i'm not a fan of using \"mental retardation\" as an insult @Phrenologicus the term is outdated &amp; ppl who actually suffer it ar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PhrenologyToday",
        "screen_name" : "Phrenologicus",
        "indices" : [ 57, 71 ],
        "id_str" : "465672119",
        "id" : 465672119
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "662454646712221696",
    "geo" : { },
    "id_str" : "662456115167236096",
    "in_reply_to_user_id" : 465672119,
    "text" : "i'm not a fan of using \"mental retardation\" as an insult @Phrenologicus the term is outdated &amp; ppl who actually suffer it are nice.",
    "id" : 662456115167236096,
    "in_reply_to_status_id" : 662454646712221696,
    "created_at" : "2015-11-06 02:27:00 +0000",
    "in_reply_to_screen_name" : "Phrenologicus",
    "in_reply_to_user_id_str" : "465672119",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 662464075893460992,
  "created_at" : "2015-11-06 02:58:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "indices" : [ 3, 18 ],
      "id_str" : "32522055",
      "id" : 32522055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/1QktkiYmUt",
      "expanded_url" : "https:\/\/twitter.com\/dick_nixon\/status\/662410238906212352",
      "display_url" : "twitter.com\/dick_nixon\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662450623279988737",
  "text" : "RT @Kris_Sacrebleu: Yes.  https:\/\/t.co\/1QktkiYmUt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/1QktkiYmUt",
        "expanded_url" : "https:\/\/twitter.com\/dick_nixon\/status\/662410238906212352",
        "display_url" : "twitter.com\/dick_nixon\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "662446941314220032",
    "text" : "Yes.  https:\/\/t.co\/1QktkiYmUt",
    "id" : 662446941314220032,
    "created_at" : "2015-11-06 01:50:33 +0000",
    "user" : {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "protected" : false,
      "id_str" : "32522055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797097618245459968\/x-mwuPEt_normal.jpg",
      "id" : 32522055,
      "verified" : false
    }
  },
  "id" : 662450623279988737,
  "created_at" : "2015-11-06 02:05:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QuantumNothingness",
      "screen_name" : "fuelandseed",
      "indices" : [ 3, 15 ],
      "id_str" : "497652988",
      "id" : 497652988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662449612930854912",
  "text" : "RT @fuelandseed: The gate of your pen is not locked. You can open it and walk out, if you choose.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662446985018867712",
    "text" : "The gate of your pen is not locked. You can open it and walk out, if you choose.",
    "id" : 662446985018867712,
    "created_at" : "2015-11-06 01:50:43 +0000",
    "user" : {
      "name" : "QuantumNothingness",
      "screen_name" : "fuelandseed",
      "protected" : false,
      "id_str" : "497652988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745739382565416960\/WMxCUN8u_normal.jpg",
      "id" : 497652988,
      "verified" : false
    }
  },
  "id" : 662449612930854912,
  "created_at" : "2015-11-06 02:01:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662435019881897985",
  "text" : "i know how Haley Dunphy feels about feeling stupid...  (modern family season 6, ep 2)",
  "id" : 662435019881897985,
  "created_at" : "2015-11-06 01:03:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 3, 18 ],
      "id_str" : "17376893",
      "id" : 17376893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/ygUXNMMqa7",
      "expanded_url" : "http:\/\/bit.ly\/1St6wcw",
      "display_url" : "bit.ly\/1St6wcw"
    } ]
  },
  "geo" : { },
  "id_str" : "662389131952177153",
  "text" : "RT @RightWingWatch: The far-right theology behind the conference Cruz, Huckabee &amp; Jindal are attending this weekend https:\/\/t.co\/ygUXNMMqa7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/ygUXNMMqa7",
        "expanded_url" : "http:\/\/bit.ly\/1St6wcw",
        "display_url" : "bit.ly\/1St6wcw"
      } ]
    },
    "geo" : { },
    "id_str" : "662378296475275265",
    "text" : "The far-right theology behind the conference Cruz, Huckabee &amp; Jindal are attending this weekend https:\/\/t.co\/ygUXNMMqa7",
    "id" : 662378296475275265,
    "created_at" : "2015-11-05 21:17:46 +0000",
    "user" : {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "protected" : false,
      "id_str" : "17376893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64767765\/rww-twitter130_normal.jpg",
      "id" : 17376893,
      "verified" : false
    }
  },
  "id" : 662389131952177153,
  "created_at" : "2015-11-05 22:00:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662386084928729088",
  "text" : "RT @Swanwhisperer: Managed too save this little one and weighed it named sparkle 501 , released in the hedgehog box in the garden https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/662384650401239040\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/PbBARxyH4t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTFDSWDXAAA0dcn.jpg",
        "id_str" : "662384602636550144",
        "id" : 662384602636550144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTFDSWDXAAA0dcn.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PbBARxyH4t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662384650401239040",
    "text" : "Managed too save this little one and weighed it named sparkle 501 , released in the hedgehog box in the garden https:\/\/t.co\/PbBARxyH4t",
    "id" : 662384650401239040,
    "created_at" : "2015-11-05 21:43:01 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 662386084928729088,
  "created_at" : "2015-11-05 21:48:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi",
      "screen_name" : "Themaddane79",
      "indices" : [ 3, 16 ],
      "id_str" : "97868609",
      "id" : 97868609
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Themaddane79\/status\/662338392408109056\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/PJYH2dEhiS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTEZQfLWsAA1Q3F.jpg",
      "id_str" : "662338391237898240",
      "id" : 662338391237898240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTEZQfLWsAA1Q3F.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PJYH2dEhiS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662376139093053440",
  "text" : "RT @Themaddane79: This sign is outside an airport in Denmark :-) https:\/\/t.co\/PJYH2dEhiS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Themaddane79\/status\/662338392408109056\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/PJYH2dEhiS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTEZQfLWsAA1Q3F.jpg",
        "id_str" : "662338391237898240",
        "id" : 662338391237898240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTEZQfLWsAA1Q3F.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PJYH2dEhiS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662338392408109056",
    "text" : "This sign is outside an airport in Denmark :-) https:\/\/t.co\/PJYH2dEhiS",
    "id" : 662338392408109056,
    "created_at" : "2015-11-05 18:39:13 +0000",
    "user" : {
      "name" : "Heidi",
      "screen_name" : "Themaddane79",
      "protected" : false,
      "id_str" : "97868609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789934870805958656\/mKDe5SYf_normal.png",
      "id" : 97868609,
      "verified" : false
    }
  },
  "id" : 662376139093053440,
  "created_at" : "2015-11-05 21:09:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna Guillaume",
      "screen_name" : "JennaGuillaume",
      "indices" : [ 3, 18 ],
      "id_str" : "21079407",
      "id" : 21079407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/T9fl3pEWSn",
      "expanded_url" : "https:\/\/vine.co\/v\/eLJeHQ3MbZn",
      "display_url" : "vine.co\/v\/eLJeHQ3MbZn"
    } ]
  },
  "geo" : { },
  "id_str" : "662375699295174657",
  "text" : "RT @JennaGuillaume: This vine tho  https:\/\/t.co\/T9fl3pEWSn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/T9fl3pEWSn",
        "expanded_url" : "https:\/\/vine.co\/v\/eLJeHQ3MbZn",
        "display_url" : "vine.co\/v\/eLJeHQ3MbZn"
      } ]
    },
    "geo" : { },
    "id_str" : "662368393148829696",
    "text" : "This vine tho  https:\/\/t.co\/T9fl3pEWSn",
    "id" : 662368393148829696,
    "created_at" : "2015-11-05 20:38:25 +0000",
    "user" : {
      "name" : "Jenna Guillaume",
      "screen_name" : "JennaGuillaume",
      "protected" : false,
      "id_str" : "21079407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733168064376635392\/PJKiYDI3_normal.jpg",
      "id" : 21079407,
      "verified" : true
    }
  },
  "id" : 662375699295174657,
  "created_at" : "2015-11-05 21:07:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662373922256629760",
  "text" : "RT @SenatorReid: The Kochs will spend until they get the government they want. If media rolls over for them, our country's in trouble https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ABLeJB86mh",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/11\/03\/charles_kochs_power_trip_billionaire_libertarian_sees_no_problem_in_buying_the_sort_of_government_he_prefers\/",
        "display_url" : "salon.com\/2015\/11\/03\/cha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661928469991833600",
    "text" : "The Kochs will spend until they get the government they want. If media rolls over for them, our country's in trouble https:\/\/t.co\/ABLeJB86mh",
    "id" : 661928469991833600,
    "created_at" : "2015-11-04 15:30:19 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 662373922256629760,
  "created_at" : "2015-11-05 21:00:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662325458395074560",
  "text" : "Testing out desktop calendars. Currently have 3. Had 4 but 1 messed things up.",
  "id" : 662325458395074560,
  "created_at" : "2015-11-05 17:47:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/662104829112754176\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/HWpOTcRgSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTBE1XxWwAA14or.jpg",
      "id_str" : "662104828928245760",
      "id" : 662104828928245760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTBE1XxWwAA14or.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HWpOTcRgSe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/T9l2yI05jY",
      "expanded_url" : "http:\/\/flip.it\/z8yvC",
      "display_url" : "flip.it\/z8yvC"
    } ]
  },
  "geo" : { },
  "id_str" : "662116139988852736",
  "text" : "RT @SpiritualNurse: How Is Guinness Making Its Beer Vegan?\n\n https:\/\/t.co\/T9l2yI05jY https:\/\/t.co\/HWpOTcRgSe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/662104829112754176\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/HWpOTcRgSe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTBE1XxWwAA14or.jpg",
        "id_str" : "662104828928245760",
        "id" : 662104828928245760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTBE1XxWwAA14or.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HWpOTcRgSe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/T9l2yI05jY",
        "expanded_url" : "http:\/\/flip.it\/z8yvC",
        "display_url" : "flip.it\/z8yvC"
      } ]
    },
    "geo" : { },
    "id_str" : "662104829112754176",
    "text" : "How Is Guinness Making Its Beer Vegan?\n\n https:\/\/t.co\/T9l2yI05jY https:\/\/t.co\/HWpOTcRgSe",
    "id" : 662104829112754176,
    "created_at" : "2015-11-05 03:11:07 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 662116139988852736,
  "created_at" : "2015-11-05 03:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Menschel",
      "screen_name" : "davidminpdx",
      "indices" : [ 3, 15 ],
      "id_str" : "540435194",
      "id" : 540435194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662115271017152512",
  "text" : "RT @davidminpdx: 1. Tomorrow, for 2nd time this year, Missouri Gov Jay Nixon will execute a man with a hole in his head. Not kidding. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/davidminpdx\/status\/661205151483432961\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LSeJdkq3pg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0SlMhUYAA8Wu4.jpg",
        "id_str" : "661205150518763520",
        "id" : 661205150518763520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0SlMhUYAA8Wu4.jpg",
        "sizes" : [ {
          "h" : 462,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LSeJdkq3pg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661205151483432961",
    "text" : "1. Tomorrow, for 2nd time this year, Missouri Gov Jay Nixon will execute a man with a hole in his head. Not kidding. https:\/\/t.co\/LSeJdkq3pg",
    "id" : 661205151483432961,
    "created_at" : "2015-11-02 15:36:07 +0000",
    "user" : {
      "name" : "David Menschel",
      "screen_name" : "davidminpdx",
      "protected" : false,
      "id_str" : "540435194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793356622038966272\/HKHEKfGu_normal.jpg",
      "id" : 540435194,
      "verified" : false
    }
  },
  "id" : 662115271017152512,
  "created_at" : "2015-11-05 03:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662106394212962304",
  "geo" : { },
  "id_str" : "662114242112434176",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste Canada 1 USA 0 : )",
  "id" : 662114242112434176,
  "in_reply_to_status_id" : 662106394212962304,
  "created_at" : "2015-11-05 03:48:31 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.J. McCullough",
      "screen_name" : "JJ_McCullough",
      "indices" : [ 3, 17 ],
      "id_str" : "30800681",
      "id" : 30800681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662113769376583680",
  "text" : "RT @JJ_McCullough: In all, 14 members of Trudeau's cabinet did not take their oath on a bible (or some other holy book) nor say \"so help me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661954761294352384",
    "text" : "In all, 14 members of Trudeau's cabinet did not take their oath on a bible (or some other holy book) nor say \"so help me God.\"",
    "id" : 661954761294352384,
    "created_at" : "2015-11-04 17:14:48 +0000",
    "user" : {
      "name" : "J.J. McCullough",
      "screen_name" : "JJ_McCullough",
      "protected" : false,
      "id_str" : "30800681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701651108561727488\/ixgX5-Kj_normal.jpg",
      "id" : 30800681,
      "verified" : false
    }
  },
  "id" : 662113769376583680,
  "created_at" : "2015-11-05 03:46:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Lost One",
      "screen_name" : "SweetLilTracy",
      "indices" : [ 49, 63 ],
      "id_str" : "141776465",
      "id" : 141776465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662111888222912512",
  "text" : "RT @ZachsMind: Do you believe Adam preceded Eve? @SweetLilTracy That's in the bible, but DNA contradicts it. proto X preceded Y chromosome.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lost One",
        "screen_name" : "SweetLilTracy",
        "indices" : [ 34, 48 ],
        "id_str" : "141776465",
        "id" : 141776465
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "662108968827908097",
    "geo" : { },
    "id_str" : "662110542409039873",
    "in_reply_to_user_id" : 141776465,
    "text" : "Do you believe Adam preceded Eve? @SweetLilTracy That's in the bible, but DNA contradicts it. proto X preceded Y chromosome. cc @Medcanpoet",
    "id" : 662110542409039873,
    "in_reply_to_status_id" : 662108968827908097,
    "created_at" : "2015-11-05 03:33:49 +0000",
    "in_reply_to_screen_name" : "SweetLilTracy",
    "in_reply_to_user_id_str" : "141776465",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 662111888222912512,
  "created_at" : "2015-11-05 03:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 3, 18 ],
      "id_str" : "24165761",
      "id" : 24165761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662111670660132864",
  "text" : "RT @MichaelSkolnik: Jeremy Mardis is youngest person killed by police in the U.S. this year.  He was 6. Yes, you read that right. 6. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MichaelSkolnik\/status\/662108060903710720\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/K1K5Jg0KUR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTBHodyXAAUAIBr.jpg",
        "id_str" : "662107905739653125",
        "id" : 662107905739653125,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTBHodyXAAUAIBr.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 845,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 845,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/K1K5Jg0KUR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662108060903710720",
    "text" : "Jeremy Mardis is youngest person killed by police in the U.S. this year.  He was 6. Yes, you read that right. 6. https:\/\/t.co\/K1K5Jg0KUR",
    "id" : 662108060903710720,
    "created_at" : "2015-11-05 03:23:57 +0000",
    "user" : {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "protected" : false,
      "id_str" : "24165761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364600220045313\/L-103cVr_normal.jpg",
      "id" : 24165761,
      "verified" : true
    }
  },
  "id" : 662111670660132864,
  "created_at" : "2015-11-05 03:38:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RiskyLiberal",
      "screen_name" : "RiskyLiberal",
      "indices" : [ 3, 16 ],
      "id_str" : "869049313",
      "id" : 869049313
    }, {
      "name" : "(((L'EtatC'estMoi)))",
      "screen_name" : "letat_lechat",
      "indices" : [ 18, 31 ],
      "id_str" : "275714700",
      "id" : 275714700
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 32, 38 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662111628230569984",
  "text" : "RT @RiskyLiberal: @letat_lechat @slate The answer to Bevin is single-payer Medicare for All. Even vets. Let vets go to any doc, hospital.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((L'EtatC'estMoi)))",
        "screen_name" : "letat_lechat",
        "indices" : [ 0, 13 ],
        "id_str" : "275714700",
        "id" : 275714700
      }, {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 14, 20 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "662108615847731200",
    "geo" : { },
    "id_str" : "662109174562553856",
    "in_reply_to_user_id" : 275714700,
    "text" : "@letat_lechat @slate The answer to Bevin is single-payer Medicare for All. Even vets. Let vets go to any doc, hospital.",
    "id" : 662109174562553856,
    "in_reply_to_status_id" : 662108615847731200,
    "created_at" : "2015-11-05 03:28:23 +0000",
    "in_reply_to_screen_name" : "letat_lechat",
    "in_reply_to_user_id_str" : "275714700",
    "user" : {
      "name" : "RiskyLiberal",
      "screen_name" : "RiskyLiberal",
      "protected" : false,
      "id_str" : "869049313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797382677913485313\/dIzjFmH-_normal.jpg",
      "id" : 869049313,
      "verified" : false
    }
  },
  "id" : 662111628230569984,
  "created_at" : "2015-11-05 03:38:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soul Healing Wisdom",
      "screen_name" : "Wizdomly",
      "indices" : [ 3, 12 ],
      "id_str" : "141614526",
      "id" : 141614526
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Wizdomly\/status\/661990400299634688\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/1Hy4b4rhuy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_cwonUcAACkv3.jpg",
      "id_str" : "661990398340919296",
      "id" : 661990398340919296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_cwonUcAACkv3.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1Hy4b4rhuy"
    } ],
    "hashtags" : [ {
      "text" : "wizdomly",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662099094748401664",
  "text" : "RT @Wizdomly: Take a deep breath.\n\n#wizdomly https:\/\/t.co\/1Hy4b4rhuy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wizdomly\/status\/661990400299634688\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/1Hy4b4rhuy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_cwonUcAACkv3.jpg",
        "id_str" : "661990398340919296",
        "id" : 661990398340919296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_cwonUcAACkv3.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1Hy4b4rhuy"
      } ],
      "hashtags" : [ {
        "text" : "wizdomly",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661990400299634688",
    "text" : "Take a deep breath.\n\n#wizdomly https:\/\/t.co\/1Hy4b4rhuy",
    "id" : 661990400299634688,
    "created_at" : "2015-11-04 19:36:25 +0000",
    "user" : {
      "name" : "Soul Healing Wisdom",
      "screen_name" : "Wizdomly",
      "protected" : false,
      "id_str" : "141614526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714502813380964353\/Zgnzrer7_normal.jpg",
      "id" : 141614526,
      "verified" : false
    }
  },
  "id" : 662099094748401664,
  "created_at" : "2015-11-05 02:48:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle (Poptart)",
      "screen_name" : "TheKyleConrad",
      "indices" : [ 3, 17 ],
      "id_str" : "18867490",
      "id" : 18867490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662098959209512960",
  "text" : "RT @TheKyleConrad: Reminder, I'm doing a 12 hour twitch stream on Saturday, and giving away a $15 Xbox card!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662087055304953856",
    "text" : "Reminder, I'm doing a 12 hour twitch stream on Saturday, and giving away a $15 Xbox card!",
    "id" : 662087055304953856,
    "created_at" : "2015-11-05 02:00:29 +0000",
    "user" : {
      "name" : "Kyle (Poptart)",
      "screen_name" : "TheKyleConrad",
      "protected" : false,
      "id_str" : "18867490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737982504192315396\/lIAW04eE_normal.jpg",
      "id" : 18867490,
      "verified" : false
    }
  },
  "id" : 662098959209512960,
  "created_at" : "2015-11-05 02:47:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Nintendo News",
      "screen_name" : "MyNintendoNews",
      "indices" : [ 3, 18 ],
      "id_str" : "1317671",
      "id" : 1317671
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MyNintendoNews\/status\/662086820759404544\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/35feZSqdzg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTA0dJyUkAAY4zt.jpg",
      "id_str" : "662086820671295488",
      "id" : 662086820671295488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTA0dJyUkAAY4zt.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/35feZSqdzg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/WNJ1CBn2dk",
      "expanded_url" : "http:\/\/bit.ly\/1Sq2JwC",
      "display_url" : "bit.ly\/1Sq2JwC"
    } ]
  },
  "geo" : { },
  "id_str" : "662098889722494978",
  "text" : "RT @MyNintendoNews: GameStop: $100 Credit If Trade A 3DS Or Vita Towards New Nintendo 3DS XL https:\/\/t.co\/WNJ1CBn2dk https:\/\/t.co\/35feZSqdzg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MyNintendoNews\/status\/662086820759404544\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/35feZSqdzg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTA0dJyUkAAY4zt.jpg",
        "id_str" : "662086820671295488",
        "id" : 662086820671295488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTA0dJyUkAAY4zt.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/35feZSqdzg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/WNJ1CBn2dk",
        "expanded_url" : "http:\/\/bit.ly\/1Sq2JwC",
        "display_url" : "bit.ly\/1Sq2JwC"
      } ]
    },
    "geo" : { },
    "id_str" : "662086820759404544",
    "text" : "GameStop: $100 Credit If Trade A 3DS Or Vita Towards New Nintendo 3DS XL https:\/\/t.co\/WNJ1CBn2dk https:\/\/t.co\/35feZSqdzg",
    "id" : 662086820759404544,
    "created_at" : "2015-11-05 01:59:33 +0000",
    "user" : {
      "name" : "My Nintendo News",
      "screen_name" : "MyNintendoNews",
      "protected" : false,
      "id_str" : "1317671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1371521063\/toad_small_normal.jpg",
      "id" : 1317671,
      "verified" : false
    }
  },
  "id" : 662098889722494978,
  "created_at" : "2015-11-05 02:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Johnson",
      "screen_name" : "kurtjohnson",
      "indices" : [ 3, 15 ],
      "id_str" : "13357852",
      "id" : 13357852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kurtjohnson\/status\/652719661793046528\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/H3eV1n8Hqo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ7tEcbWIAQ9xGs.jpg",
      "id_str" : "652719656621449220",
      "id" : 652719656621449220,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ7tEcbWIAQ9xGs.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 503
      } ],
      "display_url" : "pic.twitter.com\/H3eV1n8Hqo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662073041057423361",
  "text" : "RT @kurtjohnson: Meet Jonathan Edwards... Beloved preacher of a certain kind of Calvinism. Lover of a monster god. http:\/\/t.co\/H3eV1n8Hqo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kurtjohnson\/status\/652719661793046528\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/H3eV1n8Hqo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ7tEcbWIAQ9xGs.jpg",
        "id_str" : "652719656621449220",
        "id" : 652719656621449220,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ7tEcbWIAQ9xGs.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 503
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 503
        } ],
        "display_url" : "pic.twitter.com\/H3eV1n8Hqo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652719661793046528",
    "text" : "Meet Jonathan Edwards... Beloved preacher of a certain kind of Calvinism. Lover of a monster god. http:\/\/t.co\/H3eV1n8Hqo",
    "id" : 652719661793046528,
    "created_at" : "2015-10-10 05:37:48 +0000",
    "user" : {
      "name" : "Kurt Johnson",
      "screen_name" : "kurtjohnson",
      "protected" : false,
      "id_str" : "13357852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656591554417659905\/Lw0evFus_normal.jpg",
      "id" : 13357852,
      "verified" : false
    }
  },
  "id" : 662073041057423361,
  "created_at" : "2015-11-05 01:04:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One Hut Full",
      "screen_name" : "OneHutFull",
      "indices" : [ 3, 14 ],
      "id_str" : "2314056150",
      "id" : 2314056150
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OneHutFull\/status\/662022459462459393\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/6aTLr7D0LO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_56zgXIAAKQz1.jpg",
      "id_str" : "662022458900422656",
      "id" : 662022458900422656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_56zgXIAAKQz1.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1299,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6aTLr7D0LO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662071748117049344",
  "text" : "RT @OneHutFull: caption\u2026..? https:\/\/t.co\/6aTLr7D0LO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OneHutFull\/status\/662022459462459393\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/6aTLr7D0LO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_56zgXIAAKQz1.jpg",
        "id_str" : "662022458900422656",
        "id" : 662022458900422656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_56zgXIAAKQz1.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1211
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1299,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 761,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6aTLr7D0LO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662022459462459393",
    "text" : "caption\u2026..? https:\/\/t.co\/6aTLr7D0LO",
    "id" : 662022459462459393,
    "created_at" : "2015-11-04 21:43:48 +0000",
    "user" : {
      "name" : "One Hut Full",
      "screen_name" : "OneHutFull",
      "protected" : false,
      "id_str" : "2314056150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448853608235147265\/rAbYYPLk_normal.jpeg",
      "id" : 2314056150,
      "verified" : false
    }
  },
  "id" : 662071748117049344,
  "created_at" : "2015-11-05 00:59:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662056390375116801",
  "geo" : { },
  "id_str" : "662070940944228352",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH you got it, my dear one. ((prayers)) (((hugs)))",
  "id" : 662070940944228352,
  "in_reply_to_status_id" : 662056390375116801,
  "created_at" : "2015-11-05 00:56:27 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "indices" : [ 3, 15 ],
      "id_str" : "18761076",
      "id" : 18761076
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PocketGamer\/status\/661941126895689728\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/SnlRT0BADO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS-v8pPWwAAwSxj.jpg",
      "id_str" : "661941126644023296",
      "id" : 661941126644023296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS-v8pPWwAAwSxj.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SnlRT0BADO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/u0KR1L14TD",
      "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/iPad\/The+Room+Three\/news.asp?c=68188",
      "display_url" : "pocketgamer.co.uk\/r\/iPad\/The+Roo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661944976914403328",
  "text" : "RT @PocketGamer: Woah! The Room Three is out now on iPhone and iPad - https:\/\/t.co\/u0KR1L14TD https:\/\/t.co\/SnlRT0BADO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PocketGamer\/status\/661941126895689728\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/SnlRT0BADO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS-v8pPWwAAwSxj.jpg",
        "id_str" : "661941126644023296",
        "id" : 661941126644023296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS-v8pPWwAAwSxj.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SnlRT0BADO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/u0KR1L14TD",
        "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/iPad\/The+Room+Three\/news.asp?c=68188",
        "display_url" : "pocketgamer.co.uk\/r\/iPad\/The+Roo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661941126895689728",
    "text" : "Woah! The Room Three is out now on iPhone and iPad - https:\/\/t.co\/u0KR1L14TD https:\/\/t.co\/SnlRT0BADO",
    "id" : 661941126895689728,
    "created_at" : "2015-11-04 16:20:37 +0000",
    "user" : {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "protected" : false,
      "id_str" : "18761076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479184281449660417\/JEbx7R5G_normal.jpeg",
      "id" : 18761076,
      "verified" : false
    }
  },
  "id" : 661944976914403328,
  "created_at" : "2015-11-04 16:35:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fireproof Games",
      "screen_name" : "Fireproof_Games",
      "indices" : [ 3, 19 ],
      "id_str" : "607384486",
      "id" : 607384486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661944556473200640",
  "text" : "RT @Fireproof_Games: The Room Three for Android is progressing well and we\u2019ll post more info at a later date.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661941517544747008",
    "text" : "The Room Three for Android is progressing well and we\u2019ll post more info at a later date.",
    "id" : 661941517544747008,
    "created_at" : "2015-11-04 16:22:10 +0000",
    "user" : {
      "name" : "Fireproof Games",
      "screen_name" : "Fireproof_Games",
      "protected" : false,
      "id_str" : "607384486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793386416344600576\/LoK1OXWL_normal.jpg",
      "id" : 607384486,
      "verified" : false
    }
  },
  "id" : 661944556473200640,
  "created_at" : "2015-11-04 16:34:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Haseltine",
      "screen_name" : "scribblepotemus",
      "indices" : [ 3, 19 ],
      "id_str" : "16278375",
      "id" : 16278375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661943747022843905",
  "text" : "RT @scribblepotemus: So are we stressing \"awareness\"? or being aware of stress today? This is making me anxious.  #NationalStressAwarenessD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalStressAwarenessDay",
        "indices" : [ 93, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661941733358465024",
    "text" : "So are we stressing \"awareness\"? or being aware of stress today? This is making me anxious.  #NationalStressAwarenessDay",
    "id" : 661941733358465024,
    "created_at" : "2015-11-04 16:23:02 +0000",
    "user" : {
      "name" : "Dan Haseltine",
      "screen_name" : "scribblepotemus",
      "protected" : false,
      "id_str" : "16278375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762829630491365376\/eeTxy1px_normal.jpg",
      "id" : 16278375,
      "verified" : true
    }
  },
  "id" : 661943747022843905,
  "created_at" : "2015-11-04 16:31:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "indices" : [ 3, 15 ],
      "id_str" : "14345566",
      "id" : 14345566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661943628487593984",
  "text" : "RT @TheBloggess: \"Work out! Clean! Do yoga!\" I'm stressing out about all the things I'm being told to do to destress on #NationalStressAwar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalStressAwarenessDay",
        "indices" : [ 103, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661941842481582081",
    "text" : "\"Work out! Clean! Do yoga!\" I'm stressing out about all the things I'm being told to do to destress on #NationalStressAwarenessDay.  Nope.",
    "id" : 661941842481582081,
    "created_at" : "2015-11-04 16:23:28 +0000",
    "user" : {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "protected" : false,
      "id_str" : "14345566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1459362861\/cheesecake_copy2_normal.jpg",
      "id" : 14345566,
      "verified" : true
    }
  },
  "id" : 661943628487593984,
  "created_at" : "2015-11-04 16:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661934911717289984",
  "text" : "RT @dhammagirl: Every day should be an Exercise\n\nLife should be a Workout\n\nBurn your self out with Good Intentions\/No Regrets\n\nDon't even T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661870244571586560",
    "text" : "Every day should be an Exercise\n\nLife should be a Workout\n\nBurn your self out with Good Intentions\/No Regrets\n\nDon't even Think of quitting!",
    "id" : 661870244571586560,
    "created_at" : "2015-11-04 11:38:57 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 661934911717289984,
  "created_at" : "2015-11-04 15:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Offworld",
      "screen_name" : "offworld",
      "indices" : [ 3, 12 ],
      "id_str" : "17493611",
      "id" : 17493611
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/offworld\/status\/660154405740679172\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/izXqODxOdh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlW4OHU8AAWTLr.jpg",
      "id_str" : "660154344247980032",
      "id" : 660154344247980032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlW4OHU8AAWTLr.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/izXqODxOdh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/97ay6aXWfX",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/10\/30\/neko-atsume-english-cats.html",
      "display_url" : "boingboing.net\/2015\/10\/30\/nek\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661933102848167936",
  "text" : "RT @offworld: The Japanese cat collecting game Neko Atsume is finally in English\nhttps:\/\/t.co\/97ay6aXWfX https:\/\/t.co\/izXqODxOdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/offworld\/status\/660154405740679172\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/izXqODxOdh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlW4OHU8AAWTLr.jpg",
        "id_str" : "660154344247980032",
        "id" : 660154344247980032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlW4OHU8AAWTLr.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/izXqODxOdh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/97ay6aXWfX",
        "expanded_url" : "http:\/\/boingboing.net\/2015\/10\/30\/neko-atsume-english-cats.html",
        "display_url" : "boingboing.net\/2015\/10\/30\/nek\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660154405740679172",
    "text" : "The Japanese cat collecting game Neko Atsume is finally in English\nhttps:\/\/t.co\/97ay6aXWfX https:\/\/t.co\/izXqODxOdh",
    "id" : 660154405740679172,
    "created_at" : "2015-10-30 18:00:50 +0000",
    "user" : {
      "name" : "Offworld",
      "screen_name" : "offworld",
      "protected" : false,
      "id_str" : "17493611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573508026776227840\/ri9zOQsa_normal.png",
      "id" : 17493611,
      "verified" : false
    }
  },
  "id" : 661933102848167936,
  "created_at" : "2015-11-04 15:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    }, {
      "name" : "Julie Francella",
      "screen_name" : "JulieFrancella",
      "indices" : [ 93, 108 ],
      "id_str" : "157134692",
      "id" : 157134692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661932622776549376",
  "text" : "RT @JohnFugelsang: It's getting cold in Canada, especially for the homeless.  Please support @JulieFrancella's fine and essential work- htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Francella",
        "screen_name" : "JulieFrancella",
        "indices" : [ 74, 89 ],
        "id_str" : "157134692",
        "id" : 157134692
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnFugelsang\/status\/661930548152164352\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XW7TvWgYyl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS-mU3DXAAE4IEu.jpg",
        "id_str" : "661930547552387073",
        "id" : 661930547552387073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS-mU3DXAAE4IEu.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/XW7TvWgYyl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661930548152164352",
    "text" : "It's getting cold in Canada, especially for the homeless.  Please support @JulieFrancella's fine and essential work- https:\/\/t.co\/XW7TvWgYyl",
    "id" : 661930548152164352,
    "created_at" : "2015-11-04 15:38:35 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 661932622776549376,
  "created_at" : "2015-11-04 15:46:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0",
      "screen_name" : "ieisia",
      "indices" : [ 3, 10 ],
      "id_str" : "1137072878",
      "id" : 1137072878
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ieisia\/status\/661745254144581632\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/vPru091LGr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS79zIcWcAAL-CN.jpg",
      "id_str" : "661745250151591936",
      "id" : 661745250151591936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS79zIcWcAAL-CN.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/vPru091LGr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661748399297925120",
  "text" : "RT @ieisia: We are not alone https:\/\/t.co\/vPru091LGr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ieisia\/status\/661745254144581632\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/vPru091LGr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS79zIcWcAAL-CN.jpg",
        "id_str" : "661745250151591936",
        "id" : 661745250151591936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS79zIcWcAAL-CN.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/vPru091LGr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661745254144581632",
    "text" : "We are not alone https:\/\/t.co\/vPru091LGr",
    "id" : 661745254144581632,
    "created_at" : "2015-11-04 03:22:17 +0000",
    "user" : {
      "name" : "\u0AD0",
      "screen_name" : "ieisia",
      "protected" : false,
      "id_str" : "1137072878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784924675990286336\/gDkclXtc_normal.jpg",
      "id" : 1137072878,
      "verified" : false
    }
  },
  "id" : 661748399297925120,
  "created_at" : "2015-11-04 03:34:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Leahy",
      "screen_name" : "thepunningman",
      "indices" : [ 3, 17 ],
      "id_str" : "80064003",
      "id" : 80064003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661638219373654016",
  "text" : "RT @thepunningman: \"My folks smacked me and I turned out ok\"\nSo you think it's fine to hit children?\n\"Sure\"\n[leans in real close] Then you \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650937013592567809",
    "text" : "\"My folks smacked me and I turned out ok\"\nSo you think it's fine to hit children?\n\"Sure\"\n[leans in real close] Then you didn't turn out ok",
    "id" : 650937013592567809,
    "created_at" : "2015-10-05 07:34:12 +0000",
    "user" : {
      "name" : "Sean Leahy",
      "screen_name" : "thepunningman",
      "protected" : false,
      "id_str" : "80064003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750286042318696448\/akwVzWCQ_normal.jpg",
      "id" : 80064003,
      "verified" : false
    }
  },
  "id" : 661638219373654016,
  "created_at" : "2015-11-03 20:16:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661637966654255104",
  "text" : "RT @AnnotatedBible: Jesus did NOT go around condemning the \"sexual sinners\" or the \"immoral,\" instead He condemned those who were condemnin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661625170105204736",
    "text" : "Jesus did NOT go around condemning the \"sexual sinners\" or the \"immoral,\" instead He condemned those who were condemning the \"sinners!\"",
    "id" : 661625170105204736,
    "created_at" : "2015-11-03 19:25:07 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 661637966654255104,
  "created_at" : "2015-11-03 20:15:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    }, {
      "name" : "Beth Moore",
      "screen_name" : "BethMooreLPM",
      "indices" : [ 41, 54 ],
      "id_str" : "156012476",
      "id" : 156012476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661589980263878656",
  "text" : "RT @rachelheldevans: I've been told that @BethMooreLPM is \"off limits\" for criticism. Not in this case. LGBT people are not \"Satanic.\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Beth Moore",
        "screen_name" : "BethMooreLPM",
        "indices" : [ 20, 33 ],
        "id_str" : "156012476",
        "id" : 156012476
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/dk7NTaKe8S",
        "expanded_url" : "https:\/\/www.facebook.com\/rachelheldevans.page\/posts\/10153452734229442",
        "display_url" : "facebook.com\/rachelheldevan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661564629001326592",
    "text" : "I've been told that @BethMooreLPM is \"off limits\" for criticism. Not in this case. LGBT people are not \"Satanic.\" https:\/\/t.co\/dk7NTaKe8S",
    "id" : 661564629001326592,
    "created_at" : "2015-11-03 15:24:33 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 661589980263878656,
  "created_at" : "2015-11-03 17:05:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/578068476352286720\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/aBU9kNbTya",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAW2N2eU0AAXeWe.jpg",
      "id_str" : "578068476264239104",
      "id" : 578068476264239104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAW2N2eU0AAXeWe.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/aBU9kNbTya"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661587826992128000",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/aBU9kNbTya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/578068476352286720\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/aBU9kNbTya",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAW2N2eU0AAXeWe.jpg",
        "id_str" : "578068476264239104",
        "id" : 578068476264239104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAW2N2eU0AAXeWe.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/aBU9kNbTya"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661586149165674496",
    "text" : "https:\/\/t.co\/aBU9kNbTya",
    "id" : 661586149165674496,
    "created_at" : "2015-11-03 16:50:04 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 661587826992128000,
  "created_at" : "2015-11-03 16:56:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenzie",
      "screen_name" : "accordingtokenz",
      "indices" : [ 3, 19 ],
      "id_str" : "607805945",
      "id" : 607805945
    }, {
      "name" : "Julie Cerrone",
      "screen_name" : "justagoodlife",
      "indices" : [ 60, 74 ],
      "id_str" : "1723493144",
      "id" : 1723493144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChronicLife",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661388162736988161",
  "text" : "RT @accordingtokenz: 5 Stages of #ChronicLife Grief\/Loss by @justagoodlife :: Thanks for reminding me + many others that we aren't alone! h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Cerrone",
        "screen_name" : "justagoodlife",
        "indices" : [ 39, 53 ],
        "id_str" : "1723493144",
        "id" : 1723493144
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChronicLife",
        "indices" : [ 12, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Ha1LmMmqkB",
        "expanded_url" : "http:\/\/buff.ly\/1RHUafE",
        "display_url" : "buff.ly\/1RHUafE"
      } ]
    },
    "geo" : { },
    "id_str" : "661256533729243137",
    "text" : "5 Stages of #ChronicLife Grief\/Loss by @justagoodlife :: Thanks for reminding me + many others that we aren't alone! https:\/\/t.co\/Ha1LmMmqkB",
    "id" : 661256533729243137,
    "created_at" : "2015-11-02 19:00:17 +0000",
    "user" : {
      "name" : "Kenzie",
      "screen_name" : "accordingtokenz",
      "protected" : false,
      "id_str" : "607805945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791824331353358337\/YQJjxYEf_normal.jpg",
      "id" : 607805945,
      "verified" : false
    }
  },
  "id" : 661388162736988161,
  "created_at" : "2015-11-03 03:43:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Sid Kelly",
      "screen_name" : "MSidKelly",
      "indices" : [ 3, 13 ],
      "id_str" : "1210753170",
      "id" : 1210753170
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MSidKelly\/status\/661377603236855808\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/tp9iFpH4x8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2vbOaUAAAqDtI.jpg",
      "id_str" : "661377602553118720",
      "id" : 661377602553118720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2vbOaUAAAqDtI.jpg",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 866,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 739,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tp9iFpH4x8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661387368906272768",
  "text" : "RT @MSidKelly: A handsome raven with its iridescence on dropped in to taunt my dog at the beach yesterday. https:\/\/t.co\/tp9iFpH4x8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MSidKelly\/status\/661377603236855808\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/tp9iFpH4x8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2vbOaUAAAqDtI.jpg",
        "id_str" : "661377602553118720",
        "id" : 661377602553118720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2vbOaUAAAqDtI.jpg",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 866,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 739,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tp9iFpH4x8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661377603236855808",
    "text" : "A handsome raven with its iridescence on dropped in to taunt my dog at the beach yesterday. https:\/\/t.co\/tp9iFpH4x8",
    "id" : 661377603236855808,
    "created_at" : "2015-11-03 03:01:23 +0000",
    "user" : {
      "name" : "M. Sid Kelly",
      "screen_name" : "MSidKelly",
      "protected" : false,
      "id_str" : "1210753170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712494343173459968\/2mTM_1dA_normal.jpg",
      "id" : 1210753170,
      "verified" : false
    }
  },
  "id" : 661387368906272768,
  "created_at" : "2015-11-03 03:40:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Space Pics",
      "screen_name" : "SPACEPlX",
      "indices" : [ 3, 12 ],
      "id_str" : "3423006567",
      "id" : 3423006567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SPACEPlX\/status\/659793412066050048\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/1WRQab4SRR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSgOnLLXIAAkm7x.jpg",
      "id_str" : "659793411587907584",
      "id" : 659793411587907584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSgOnLLXIAAkm7x.jpg",
      "sizes" : [ {
        "h" : 716,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1072
      }, {
        "h" : 1223,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1WRQab4SRR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661386638556332032",
  "text" : "RT @SPACEPlX: The Butterfly Nebula in the constellation Scorpius. https:\/\/t.co\/1WRQab4SRR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SPACEPlX\/status\/659793412066050048\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/1WRQab4SRR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSgOnLLXIAAkm7x.jpg",
        "id_str" : "659793411587907584",
        "id" : 659793411587907584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSgOnLLXIAAkm7x.jpg",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1072
        }, {
          "h" : 1223,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1WRQab4SRR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659793412066050048",
    "text" : "The Butterfly Nebula in the constellation Scorpius. https:\/\/t.co\/1WRQab4SRR",
    "id" : 659793412066050048,
    "created_at" : "2015-10-29 18:06:22 +0000",
    "user" : {
      "name" : "Space Pics",
      "screen_name" : "SPACEPlX",
      "protected" : false,
      "id_str" : "3423006567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637703307063111680\/7rXu_0Rd_normal.jpg",
      "id" : 3423006567,
      "verified" : false
    }
  },
  "id" : 661386638556332032,
  "created_at" : "2015-11-03 03:37:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/661386468540194816\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/oGTvvkOidY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS23fSEW4AACB0j.jpg",
      "id_str" : "661386468347273216",
      "id" : 661386468347273216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS23fSEW4AACB0j.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oGTvvkOidY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661386468540194816",
  "text" : "That was some love nip, dear kitty! Left a bruise. https:\/\/t.co\/oGTvvkOidY",
  "id" : 661386468540194816,
  "created_at" : "2015-11-03 03:36:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661349740748107776",
  "text" : "Reformatting c drive again....",
  "id" : 661349740748107776,
  "created_at" : "2015-11-03 01:10:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/661332664784261120\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/tProNDfHVf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2GjZDUEAA1q7F.jpg",
      "id_str" : "661332662871658496",
      "id" : 661332662871658496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2GjZDUEAA1q7F.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/tProNDfHVf"
    } ],
    "hashtags" : [ {
      "text" : "vabirdlibrary",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661338864989138944",
  "text" : "RT @Library4birds: Miss Dove's bosom is full of love for libraries.\n#vabirdlibrary https:\/\/t.co\/tProNDfHVf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/661332664784261120\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/tProNDfHVf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2GjZDUEAA1q7F.jpg",
        "id_str" : "661332662871658496",
        "id" : 661332662871658496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2GjZDUEAA1q7F.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/tProNDfHVf"
      } ],
      "hashtags" : [ {
        "text" : "vabirdlibrary",
        "indices" : [ 49, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661332664784261120",
    "text" : "Miss Dove's bosom is full of love for libraries.\n#vabirdlibrary https:\/\/t.co\/tProNDfHVf",
    "id" : 661332664784261120,
    "created_at" : "2015-11-03 00:02:48 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 661338864989138944,
  "created_at" : "2015-11-03 00:27:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661337558643826688",
  "text" : "Why are calendars so complicated? Gah!",
  "id" : 661337558643826688,
  "created_at" : "2015-11-03 00:22:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "661228001682571265",
  "geo" : { },
  "id_str" : "661238204637540352",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre may I ask how? (thyroid pt 1st) (DD #hashimotos) sorry for bad day ((hugs))",
  "id" : 661238204637540352,
  "in_reply_to_status_id" : 661228001682571265,
  "created_at" : "2015-11-02 17:47:27 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661031178833633280",
  "text" : "RT @AnAmericanMonk: Our task is not to judge or punish. Karma will take care of that. Our task is love. Aarti Jain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661030681385005060",
    "text" : "Our task is not to judge or punish. Karma will take care of that. Our task is love. Aarti Jain",
    "id" : 661030681385005060,
    "created_at" : "2015-11-02 04:02:50 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 661031178833633280,
  "created_at" : "2015-11-02 04:04:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Johnson",
      "screen_name" : "rjohnson7707",
      "indices" : [ 3, 16 ],
      "id_str" : "363347628",
      "id" : 363347628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rjohnson7707\/status\/660914020258451456\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/uJ67zqO7fY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSwJyeeUcAE-iIp.jpg",
      "id_str" : "660914008094961665",
      "id" : 660914008094961665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSwJyeeUcAE-iIp.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/uJ67zqO7fY"
    } ],
    "hashtags" : [ {
      "text" : "nationalbisonday",
      "indices" : [ 18, 35 ]
    }, {
      "text" : "bison",
      "indices" : [ 36, 42 ]
    }, {
      "text" : "westcdnag",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661027685443989504",
  "text" : "RT @rjohnson7707: #nationalbisonday #bison Here's Molly and her 2015 calf #westcdnag https:\/\/t.co\/uJ67zqO7fY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rjohnson7707\/status\/660914020258451456\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/uJ67zqO7fY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSwJyeeUcAE-iIp.jpg",
        "id_str" : "660914008094961665",
        "id" : 660914008094961665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSwJyeeUcAE-iIp.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 581,
          "resize" : "fit",
          "w" : 1032
        } ],
        "display_url" : "pic.twitter.com\/uJ67zqO7fY"
      } ],
      "hashtags" : [ {
        "text" : "nationalbisonday",
        "indices" : [ 0, 17 ]
      }, {
        "text" : "bison",
        "indices" : [ 18, 24 ]
      }, {
        "text" : "westcdnag",
        "indices" : [ 56, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660914020258451456",
    "text" : "#nationalbisonday #bison Here's Molly and her 2015 calf #westcdnag https:\/\/t.co\/uJ67zqO7fY",
    "id" : 660914020258451456,
    "created_at" : "2015-11-01 20:19:16 +0000",
    "user" : {
      "name" : "Robert Johnson",
      "screen_name" : "rjohnson7707",
      "protected" : false,
      "id_str" : "363347628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779352060370178048\/_-CY1cub_normal.jpg",
      "id" : 363347628,
      "verified" : false
    }
  },
  "id" : 661027685443989504,
  "created_at" : "2015-11-02 03:50:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "indices" : [ 3, 15 ],
      "id_str" : "896548279",
      "id" : 896548279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "life",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "moments",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661027556645347329",
  "text" : "RT @NaamaYehuda: Find #kindness in small things. A smile, a door held open, room made on a seat. #life is made of caring #moments. Feed hea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindness",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "life",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "moments",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661025501541244928",
    "text" : "Find #kindness in small things. A smile, a door held open, room made on a seat. #life is made of caring #moments. Feed hearts.",
    "id" : 661025501541244928,
    "created_at" : "2015-11-02 03:42:15 +0000",
    "user" : {
      "name" : "Naama Yehuda",
      "screen_name" : "NaamaYehuda",
      "protected" : false,
      "id_str" : "896548279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2748712360\/5665839cb74057117f99ea3245bba181_normal.jpeg",
      "id" : 896548279,
      "verified" : false
    }
  },
  "id" : 661027556645347329,
  "created_at" : "2015-11-02 03:50:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/DfbDNHj4em",
      "expanded_url" : "https:\/\/twitter.com\/jmart4info\/status\/660819129901838340",
      "display_url" : "twitter.com\/jmart4info\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661017696386080768",
  "text" : "RT @Irish_Atheist: Be the next Marvel supervillian. Join the Gay. https:\/\/t.co\/DfbDNHj4em",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/DfbDNHj4em",
        "expanded_url" : "https:\/\/twitter.com\/jmart4info\/status\/660819129901838340",
        "display_url" : "twitter.com\/jmart4info\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661013662447108096",
    "text" : "Be the next Marvel supervillian. Join the Gay. https:\/\/t.co\/DfbDNHj4em",
    "id" : 661013662447108096,
    "created_at" : "2015-11-02 02:55:12 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 661017696386080768,
  "created_at" : "2015-11-02 03:11:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661016625601241092",
  "text" : "RT @ChristianDems: 1 Cor 13:13 And now abide faith, hope, love, these three; but the greatest of these is love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661015201945427968",
    "text" : "1 Cor 13:13 And now abide faith, hope, love, these three; but the greatest of these is love.",
    "id" : 661015201945427968,
    "created_at" : "2015-11-02 03:01:19 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 661016625601241092,
  "created_at" : "2015-11-02 03:06:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661015210531115008",
  "text" : "RT @jamesbeatleyjr: Not even related. Calling someone a human isn't derogatory. Calling them a f***** is, even if you're joking. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/wFxbpWn2kB",
        "expanded_url" : "https:\/\/twitter.com\/rbeatz97\/status\/659829598256037888",
        "display_url" : "twitter.com\/rbeatz97\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659830321714720768",
    "text" : "Not even related. Calling someone a human isn't derogatory. Calling them a f***** is, even if you're joking. https:\/\/t.co\/wFxbpWn2kB",
    "id" : 659830321714720768,
    "created_at" : "2015-10-29 20:33:02 +0000",
    "user" : {
      "name" : "James Beatley Jr.",
      "screen_name" : "JB4LP",
      "protected" : false,
      "id_str" : "465702407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787349782398238720\/Ds_-2Pj7_normal.jpg",
      "id" : 465702407,
      "verified" : false
    }
  },
  "id" : 661015210531115008,
  "created_at" : "2015-11-02 03:01:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wrLZmHheyC",
      "expanded_url" : "https:\/\/twitter.com\/rbeatz97\/status\/659831658472972288",
      "display_url" : "twitter.com\/rbeatz97\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661015163840122881",
  "text" : "RT @jamesbeatleyjr: What? Something is wrong when you use it in a way that degrades the person, or their culture.  https:\/\/t.co\/wrLZmHheyC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/wrLZmHheyC",
        "expanded_url" : "https:\/\/twitter.com\/rbeatz97\/status\/659831658472972288",
        "display_url" : "twitter.com\/rbeatz97\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659831987058974720",
    "text" : "What? Something is wrong when you use it in a way that degrades the person, or their culture.  https:\/\/t.co\/wrLZmHheyC",
    "id" : 659831987058974720,
    "created_at" : "2015-10-29 20:39:39 +0000",
    "user" : {
      "name" : "James Beatley Jr.",
      "screen_name" : "JB4LP",
      "protected" : false,
      "id_str" : "465702407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787349782398238720\/Ds_-2Pj7_normal.jpg",
      "id" : 465702407,
      "verified" : false
    }
  },
  "id" : 661015163840122881,
  "created_at" : "2015-11-02 03:01:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/500198753253740544\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/UwH9vdrHCp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvEQHaYIQAAlLra.jpg",
      "id_str" : "500198753140490240",
      "id" : 500198753140490240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvEQHaYIQAAlLra.jpg",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/UwH9vdrHCp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661001040557379584",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/UwH9vdrHCp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/500198753253740544\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/UwH9vdrHCp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvEQHaYIQAAlLra.jpg",
        "id_str" : "500198753140490240",
        "id" : 500198753140490240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvEQHaYIQAAlLra.jpg",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/UwH9vdrHCp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660997276018548736",
    "text" : "https:\/\/t.co\/UwH9vdrHCp",
    "id" : 660997276018548736,
    "created_at" : "2015-11-02 01:50:05 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 661001040557379584,
  "created_at" : "2015-11-02 02:05:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Surly Temple",
      "screen_name" : "wicked_cricket",
      "indices" : [ 3, 18 ],
      "id_str" : "282916183",
      "id" : 282916183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wicked_cricket\/status\/660997354888298496\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/qURQ64VTQx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSxVl28W4AA3P_0.jpg",
      "id_str" : "660997354208813056",
      "id" : 660997354208813056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSxVl28W4AA3P_0.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/qURQ64VTQx"
    } ],
    "hashtags" : [ {
      "text" : "DaylightSavingTime",
      "indices" : [ 20, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661000643910492160",
  "text" : "RT @wicked_cricket: #DaylightSavingTime https:\/\/t.co\/qURQ64VTQx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wicked_cricket\/status\/660997354888298496\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/qURQ64VTQx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSxVl28W4AA3P_0.jpg",
        "id_str" : "660997354208813056",
        "id" : 660997354208813056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSxVl28W4AA3P_0.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/qURQ64VTQx"
      } ],
      "hashtags" : [ {
        "text" : "DaylightSavingTime",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660997354888298496",
    "text" : "#DaylightSavingTime https:\/\/t.co\/qURQ64VTQx",
    "id" : 660997354888298496,
    "created_at" : "2015-11-02 01:50:24 +0000",
    "user" : {
      "name" : "Surly Temple",
      "screen_name" : "wicked_cricket",
      "protected" : false,
      "id_str" : "282916183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797829909175472129\/l5-9yHmq_normal.jpg",
      "id" : 282916183,
      "verified" : false
    }
  },
  "id" : 661000643910492160,
  "created_at" : "2015-11-02 02:03:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XavZYjjuz2",
      "expanded_url" : "http:\/\/klou.tt\/2d68fb22wo2a",
      "display_url" : "klou.tt\/2d68fb22wo2a"
    } ]
  },
  "geo" : { },
  "id_str" : "660960925030162432",
  "text" : "RT @5thdimdreamz: The Crime Your Brain Commits Against You (And What to Do About It) - https:\/\/t.co\/XavZYjjuz2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/XavZYjjuz2",
        "expanded_url" : "http:\/\/klou.tt\/2d68fb22wo2a",
        "display_url" : "klou.tt\/2d68fb22wo2a"
      } ]
    },
    "geo" : { },
    "id_str" : "660954528749981696",
    "text" : "The Crime Your Brain Commits Against You (And What to Do About It) - https:\/\/t.co\/XavZYjjuz2",
    "id" : 660954528749981696,
    "created_at" : "2015-11-01 23:00:14 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 660960925030162432,
  "created_at" : "2015-11-01 23:25:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/660954553630785536\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/6SJUpDdbk3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSwuqh8WcAEPzi-.jpg",
      "id_str" : "660954553517502465",
      "id" : 660954553517502465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSwuqh8WcAEPzi-.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/6SJUpDdbk3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/NmGjlvZhB5",
      "expanded_url" : "http:\/\/bit.ly\/1kvE1Qb",
      "display_url" : "bit.ly\/1kvE1Qb"
    } ]
  },
  "geo" : { },
  "id_str" : "660960284400578560",
  "text" : "RT @jonlieffmd: Immune T Cells Are Critical for Cognitive Function: https:\/\/t.co\/NmGjlvZhB5 https:\/\/t.co\/6SJUpDdbk3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/660954553630785536\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/6SJUpDdbk3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSwuqh8WcAEPzi-.jpg",
        "id_str" : "660954553517502465",
        "id" : 660954553517502465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSwuqh8WcAEPzi-.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/6SJUpDdbk3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/NmGjlvZhB5",
        "expanded_url" : "http:\/\/bit.ly\/1kvE1Qb",
        "display_url" : "bit.ly\/1kvE1Qb"
      } ]
    },
    "geo" : { },
    "id_str" : "660954553630785536",
    "text" : "Immune T Cells Are Critical for Cognitive Function: https:\/\/t.co\/NmGjlvZhB5 https:\/\/t.co\/6SJUpDdbk3",
    "id" : 660954553630785536,
    "created_at" : "2015-11-01 23:00:20 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 660960284400578560,
  "created_at" : "2015-11-01 23:23:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franchesca Ramsey",
      "screen_name" : "chescaleigh",
      "indices" : [ 3, 15 ],
      "id_str" : "20110424",
      "id" : 20110424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660959455698419712",
  "text" : "RT @chescaleigh: no one is born conscious or \"woke\" we have to actively unlearn every day. that takes time &amp; maturity. it doesn't happen ov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "660921221027090432",
    "geo" : { },
    "id_str" : "660921537348968448",
    "in_reply_to_user_id" : 20110424,
    "text" : "no one is born conscious or \"woke\" we have to actively unlearn every day. that takes time &amp; maturity. it doesn't happen overnight",
    "id" : 660921537348968448,
    "in_reply_to_status_id" : 660921221027090432,
    "created_at" : "2015-11-01 20:49:08 +0000",
    "in_reply_to_screen_name" : "chescaleigh",
    "in_reply_to_user_id_str" : "20110424",
    "user" : {
      "name" : "Franchesca Ramsey",
      "screen_name" : "chescaleigh",
      "protected" : false,
      "id_str" : "20110424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744865423343099905\/oQUlqN5m_normal.jpg",
      "id" : 20110424,
      "verified" : true
    }
  },
  "id" : 660959455698419712,
  "created_at" : "2015-11-01 23:19:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660917518618533889",
  "text" : "Think I broke windows updater thingy. Gets stuck on \"checking for updates\" and no cancel button. Hmm..",
  "id" : 660917518618533889,
  "created_at" : "2015-11-01 20:33:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "indices" : [ 3, 17 ],
      "id_str" : "255780065",
      "id" : 255780065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660906349136633856",
  "text" : "RT @Crowtographer: Not the best photo.This is my new friend in Coquitlam. I call her Microw, and she eats out of my hand most days now. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Crowtographer\/status\/660905958105739269\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/yX4Ahla68C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSwCd4uUsAA_DsA.jpg",
        "id_str" : "660905957782761472",
        "id" : 660905957782761472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSwCd4uUsAA_DsA.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yX4Ahla68C"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660905958105739269",
    "text" : "Not the best photo.This is my new friend in Coquitlam. I call her Microw, and she eats out of my hand most days now. https:\/\/t.co\/yX4Ahla68C",
    "id" : 660905958105739269,
    "created_at" : "2015-11-01 19:47:14 +0000",
    "user" : {
      "name" : "The Crowtographer",
      "screen_name" : "Crowtographer",
      "protected" : false,
      "id_str" : "255780065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737547028062863361\/1tOrY86w_normal.jpg",
      "id" : 255780065,
      "verified" : false
    }
  },
  "id" : 660906349136633856,
  "created_at" : "2015-11-01 19:48:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660903157212520448",
  "geo" : { },
  "id_str" : "660906179959365633",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides I don't even use as phone. Just for apps and camera. Hoping to get new touch laptop after Xmas.",
  "id" : 660906179959365633,
  "in_reply_to_status_id" : 660903157212520448,
  "created_at" : "2015-11-01 19:48:07 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geeky",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660899483123884032",
  "geo" : { },
  "id_str" : "660902805914431488",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides I have a Lumia 1520 and want to use apps on both. Plus I love new software\/tech #geeky",
  "id" : 660902805914431488,
  "in_reply_to_status_id" : 660899483123884032,
  "created_at" : "2015-11-01 19:34:42 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Bernardo Kastrup",
      "screen_name" : "BernardoKastrup",
      "indices" : [ 20, 36 ],
      "id_str" : "2616900355",
      "id" : 2616900355
    }, {
      "name" : "Lawrence M. Krauss",
      "screen_name" : "LKrauss1",
      "indices" : [ 37, 46 ],
      "id_str" : "556151596",
      "id" : 556151596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660900934709563392",
  "text" : "RT @DeepakChopra: . @BernardoKastrup @LKrauss1 Space and time are not independent realities but abstract ideas based on our perceptual expe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernardo Kastrup",
        "screen_name" : "BernardoKastrup",
        "indices" : [ 2, 18 ],
        "id_str" : "2616900355",
        "id" : 2616900355
      }, {
        "name" : "Lawrence M. Krauss",
        "screen_name" : "LKrauss1",
        "indices" : [ 19, 28 ],
        "id_str" : "556151596",
        "id" : 556151596
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "660812410232639489",
    "geo" : { },
    "id_str" : "660898946852646912",
    "in_reply_to_user_id" : 2616900355,
    "text" : ". @BernardoKastrup @LKrauss1 Space and time are not independent realities but abstract ideas based on our perceptual experiences",
    "id" : 660898946852646912,
    "in_reply_to_status_id" : 660812410232639489,
    "created_at" : "2015-11-01 19:19:22 +0000",
    "in_reply_to_screen_name" : "BernardoKastrup",
    "in_reply_to_user_id_str" : "2616900355",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 660900934709563392,
  "created_at" : "2015-11-01 19:27:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "660863553025531905",
  "geo" : { },
  "id_str" : "660872806259904513",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides if I had win 8 I prob wouldn't care but I want access to apps.",
  "id" : 660872806259904513,
  "in_reply_to_status_id" : 660863553025531905,
  "created_at" : "2015-11-01 17:35:30 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660860273637617664",
  "text" : "Every time I see \"reunited\" on lost pets posts, my brain sings that song.",
  "id" : 660860273637617664,
  "created_at" : "2015-11-01 16:45:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660859443433897985",
  "text" : "Restored my win 7. Still working on getting win 10 up. (Yes it should work on my specific laptop.)",
  "id" : 660859443433897985,
  "created_at" : "2015-11-01 16:42:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5MbKxLO3jg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgEwXIAExdt6.jpg",
      "id_str" : "660814735907168257",
      "id" : 660814735907168257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgEwXIAExdt6.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5MbKxLO3jg"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5MbKxLO3jg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgGmXIAAAhKN.jpg",
      "id_str" : "660814736402096128",
      "id" : 660814736402096128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgGmXIAAAhKN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5MbKxLO3jg"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5MbKxLO3jg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgI7WoAASxKf.jpg",
      "id_str" : "660814737027014656",
      "id" : 660814737027014656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgI7WoAASxKf.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5MbKxLO3jg"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5MbKxLO3jg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgLhW4AAdYP8.jpg",
      "id_str" : "660814737723285504",
      "id" : 660814737723285504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgLhW4AAdYP8.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5MbKxLO3jg"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660836993102962688",
  "text" : "RT @dailyMorag: Slow pokes were Verging going back to grass #dailyMorag https:\/\/t.co\/5MbKxLO3jg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/5MbKxLO3jg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgEwXIAExdt6.jpg",
        "id_str" : "660814735907168257",
        "id" : 660814735907168257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgEwXIAExdt6.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5MbKxLO3jg"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/5MbKxLO3jg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgGmXIAAAhKN.jpg",
        "id_str" : "660814736402096128",
        "id" : 660814736402096128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgGmXIAAAhKN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5MbKxLO3jg"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/5MbKxLO3jg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgI7WoAASxKf.jpg",
        "id_str" : "660814737027014656",
        "id" : 660814737027014656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgI7WoAASxKf.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5MbKxLO3jg"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/660814902727168000\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/5MbKxLO3jg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSuvgLhW4AAdYP8.jpg",
        "id_str" : "660814737723285504",
        "id" : 660814737723285504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSuvgLhW4AAdYP8.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5MbKxLO3jg"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 44, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660814902727168000",
    "text" : "Slow pokes were Verging going back to grass #dailyMorag https:\/\/t.co\/5MbKxLO3jg",
    "id" : 660814902727168000,
    "created_at" : "2015-11-01 13:45:24 +0000",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 660836993102962688,
  "created_at" : "2015-11-01 15:13:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 14, 27 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/QpIx5TH3BO",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/660835821960957953\/photo\/1",
      "display_url" : "pic.twitter.com\/QpIx5TH3BO"
    } ]
  },
  "geo" : { },
  "id_str" : "660836207849553920",
  "text" : "Love this. RT @dwaynereaves: Have a good day everyone! https:\/\/t.co\/QpIx5TH3BO",
  "id" : 660836207849553920,
  "created_at" : "2015-11-01 15:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]