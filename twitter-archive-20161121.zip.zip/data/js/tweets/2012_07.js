Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Alan Lucas",
      "screen_name" : "Owlkenpowriter",
      "indices" : [ 3, 18 ],
      "id_str" : "23521939",
      "id" : 23521939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230349058844274689",
  "text" : "RT @Owlkenpowriter: Everyone in my book accuses everyone else of being crazy. Frankly, I think the whole society is nuts--Joseph Heller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230346082582925312",
    "text" : "Everyone in my book accuses everyone else of being crazy. Frankly, I think the whole society is nuts--Joseph Heller",
    "id" : 230346082582925312,
    "created_at" : "2012-07-31 16:56:00 +0000",
    "user" : {
      "name" : "David Alan Lucas",
      "screen_name" : "Owlkenpowriter",
      "protected" : false,
      "id_str" : "23521939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1685605927\/David_Logo_white_normal.jpg",
      "id" : 23521939,
      "verified" : false
    }
  },
  "id" : 230349058844274689,
  "created_at" : "2012-07-31 17:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 52, 65 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230117804534272000",
  "text" : "@BibleAlsoSays oh to be a fly on the wall.. LOL : ) @SisterSadist",
  "id" : 230117804534272000,
  "created_at" : "2012-07-31 01:48:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230116260237684736",
  "text" : "RT @ShipsofSong: Darkness cannot dwell where God lives.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230115753838403584",
    "text" : "Darkness cannot dwell where God lives.",
    "id" : 230115753838403584,
    "created_at" : "2012-07-31 01:40:45 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 230116260237684736,
  "created_at" : "2012-07-31 01:42:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 23, 37 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230113612092559361",
  "geo" : { },
  "id_str" : "230116026883383296",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist ((hugs)) @BibleAlsoSays",
  "id" : 230116026883383296,
  "in_reply_to_status_id" : 230113612092559361,
  "created_at" : "2012-07-31 01:41:50 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230113261213851648",
  "text" : "RT @DeepakChopra: God's ability to give is infinite. We limit it by our own unloving perception.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230089315449962497",
    "text" : "God's ability to give is infinite. We limit it by our own unloving perception.",
    "id" : 230089315449962497,
    "created_at" : "2012-07-30 23:55:42 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 230113261213851648,
  "created_at" : "2012-07-31 01:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "The Denver Post",
      "screen_name" : "denverpost",
      "indices" : [ 78, 89 ],
      "id_str" : "8216772",
      "id" : 8216772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230023558317879296",
  "text" : "RT @DuttonBooks: \"LINE OF FIRE is a Stephen White thriller at its best,\" says @DenverPost. Follow us &amp; RT to enter to #win a copy! U ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Denver Post",
        "screen_name" : "denverpost",
        "indices" : [ 61, 72 ],
        "id_str" : "8216772",
        "id" : 8216772
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 105, 109 ]
      }, {
        "text" : "Mondaygiveaway",
        "indices" : [ 129, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230023091324080130",
    "text" : "\"LINE OF FIRE is a Stephen White thriller at its best,\" says @DenverPost. Follow us &amp; RT to enter to #win a copy! U.S. only. #Mondaygiveaway",
    "id" : 230023091324080130,
    "created_at" : "2012-07-30 19:32:33 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 230023558317879296,
  "created_at" : "2012-07-30 19:34:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 3, 18 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229993461728813056",
  "text" : "RT @TheAtheistFool: If anyone knows how human consciousness is supposed to survive beyond brain death, I'd like to hear it. #atheist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229991063547412480",
    "text" : "If anyone knows how human consciousness is supposed to survive beyond brain death, I'd like to hear it. #atheist",
    "id" : 229991063547412480,
    "created_at" : "2012-07-30 17:25:17 +0000",
    "user" : {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "protected" : false,
      "id_str" : "550304910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363295063\/image_normal.jpg",
      "id" : 550304910,
      "verified" : false
    }
  },
  "id" : 229993461728813056,
  "created_at" : "2012-07-30 17:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N. John Shore, Jr.",
      "screen_name" : "johnshore",
      "indices" : [ 11, 21 ],
      "id_str" : "74710075",
      "id" : 74710075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/GqzCaiNR",
      "expanded_url" : "http:\/\/wp.me\/p17ivu-6ua",
      "display_url" : "wp.me\/p17ivu-6ua"
    } ]
  },
  "geo" : { },
  "id_str" : "229982400820678656",
  "text" : "LOL : ) RT @johnshore What went through my head reading the recent Samaritan's Purse newsletter from Franklin Graham: http:\/\/t.co\/GqzCaiNR",
  "id" : 229982400820678656,
  "created_at" : "2012-07-30 16:50:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229949341316562945",
  "text" : "RT @By_Bashar: When you dance, your purpose is not to get to a certain place on the floor. It's to Experience the dance ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229947561392369665",
    "text" : "When you dance, your purpose is not to get to a certain place on the floor. It's to Experience the dance ~ bashar",
    "id" : 229947561392369665,
    "created_at" : "2012-07-30 14:32:25 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 229949341316562945,
  "created_at" : "2012-07-30 14:39:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Christian Worldviews",
      "screen_name" : "CVIEWS",
      "indices" : [ 48, 55 ],
      "id_str" : "67350721",
      "id" : 67350721
    }, {
      "name" : "\u271EHisKingdomCome",
      "screen_name" : "onewhitetiger",
      "indices" : [ 56, 70 ],
      "id_str" : "565425097",
      "id" : 565425097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229948226030170112",
  "geo" : { },
  "id_str" : "229949223343366144",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny oh I love it when you do that! : ) @cviews @onewhitetiger",
  "id" : 229949223343366144,
  "in_reply_to_status_id" : 229948226030170112,
  "created_at" : "2012-07-30 14:39:01 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229942679860043776",
  "text" : "RT @adamrshields: Livrada: e-book gift cards for your Kindle or Nook (would you use a physical gift card for digital books?) http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/tl8Yiazh",
        "expanded_url" : "http:\/\/bookwi.se\/livrada\/",
        "display_url" : "bookwi.se\/livrada\/"
      } ]
    },
    "geo" : { },
    "id_str" : "229939078135697408",
    "text" : "Livrada: e-book gift cards for your Kindle or Nook (would you use a physical gift card for digital books?) http:\/\/t.co\/tl8Yiazh",
    "id" : 229939078135697408,
    "created_at" : "2012-07-30 13:58:42 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 229942679860043776,
  "created_at" : "2012-07-30 14:13:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 111, 124 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 125, 139 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229935736042975234",
  "geo" : { },
  "id_str" : "229936829099565056",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia they are trying to convert you, you're trying to convert them... it just goes on and on and on. @SisterSadist @BibleAlsoSays",
  "id" : 229936829099565056,
  "in_reply_to_status_id" : 229935736042975234,
  "created_at" : "2012-07-30 13:49:46 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229931337224683520",
  "text" : "RT @ZachsMind: Anyway back to Tennant, my point is not only does the universe constantly change but my subjective perception of it const ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229931220346212352",
    "text" : "Anyway back to Tennant, my point is not only does the universe constantly change but my subjective perception of it constantly changes.",
    "id" : 229931220346212352,
    "created_at" : "2012-07-30 13:27:29 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 229931337224683520,
  "created_at" : "2012-07-30 13:27:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229930954221813760",
  "text" : "RT @Buddhaworld: the time will come even for the biggest fool to let go of craving. Its nature unfolding.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229925029847109632",
    "text" : "the time will come even for the biggest fool to let go of craving. Its nature unfolding.",
    "id" : 229925029847109632,
    "created_at" : "2012-07-30 13:02:53 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 229930954221813760,
  "created_at" : "2012-07-30 13:26:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 90, 103 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229930657797795840",
  "text" : "@BibleAlsoSays you're insisting they behave a certain way? sounds familiar ; ) @UfoIogist @SisterSadist",
  "id" : 229930657797795840,
  "created_at" : "2012-07-30 13:25:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/WD2oYoa1",
      "expanded_url" : "http:\/\/bit.ly\/5uzQZ1",
      "display_url" : "bit.ly\/5uzQZ1"
    } ]
  },
  "geo" : { },
  "id_str" : "229906353563500544",
  "text" : "RT @drbloem: Vaccine-Induced Disease Epidemic Outbreaks http:\/\/t.co\/WD2oYoa1 #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/WD2oYoa1",
        "expanded_url" : "http:\/\/bit.ly\/5uzQZ1",
        "display_url" : "bit.ly\/5uzQZ1"
      } ]
    },
    "geo" : { },
    "id_str" : "229905129346838528",
    "text" : "Vaccine-Induced Disease Epidemic Outbreaks http:\/\/t.co\/WD2oYoa1 #health",
    "id" : 229905129346838528,
    "created_at" : "2012-07-30 11:43:48 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 229906353563500544,
  "created_at" : "2012-07-30 11:48:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Koshko",
      "screen_name" : "mattkoshko",
      "indices" : [ 3, 14 ],
      "id_str" : "16154379",
      "id" : 16154379
    }, {
      "name" : "Xtrema Cookware",
      "screen_name" : "XtremaCookware",
      "indices" : [ 16, 31 ],
      "id_str" : "30024157",
      "id" : 30024157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229906089586610177",
  "text" : "RT @mattkoshko: @XtremaCookware Thanks! It turns out, Xtrema Cookware pans are tough and resistant. Not even a scratch from the SOS pads ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xtrema Cookware",
        "screen_name" : "XtremaCookware",
        "indices" : [ 0, 15 ],
        "id_str" : "30024157",
        "id" : 30024157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "229749380750639105",
    "geo" : { },
    "id_str" : "229768817570611200",
    "in_reply_to_user_id" : 30024157,
    "text" : "@XtremaCookware Thanks! It turns out, Xtrema Cookware pans are tough and resistant. Not even a scratch from the SOS pads and 100% clean now!",
    "id" : 229768817570611200,
    "in_reply_to_status_id" : 229749380750639105,
    "created_at" : "2012-07-30 02:42:09 +0000",
    "in_reply_to_screen_name" : "XtremaCookware",
    "in_reply_to_user_id_str" : "30024157",
    "user" : {
      "name" : "Matt Koshko",
      "screen_name" : "mattkoshko",
      "protected" : false,
      "id_str" : "16154379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769825220\/BlueShirt-Wedding_normal.jpg",
      "id" : 16154379,
      "verified" : false
    }
  },
  "id" : 229906089586610177,
  "created_at" : "2012-07-30 11:47:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 3, 16 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 18, 32 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 33, 47 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229904921640722433",
  "text" : "RT @SisterSadist: @deisidiamonia @biblealsosays I just want people to coexist with the same rights and freedoms as everyone. And be free ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amalek",
        "screen_name" : "deisidiamonia",
        "indices" : [ 0, 14 ],
        "id_str" : "280827427",
        "id" : 280827427
      }, {
        "name" : "BibleAlsoSays",
        "screen_name" : "BibleAlsoSays",
        "indices" : [ 15, 29 ],
        "id_str" : "2511428924",
        "id" : 2511428924
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "229789596966346752",
    "geo" : { },
    "id_str" : "229904132545335297",
    "in_reply_to_user_id" : 280827427,
    "text" : "@deisidiamonia @biblealsosays I just want people to coexist with the same rights and freedoms as everyone. And be free of judgment.",
    "id" : 229904132545335297,
    "in_reply_to_status_id" : 229789596966346752,
    "created_at" : "2012-07-30 11:39:51 +0000",
    "in_reply_to_screen_name" : "deisidiamonia",
    "in_reply_to_user_id_str" : "280827427",
    "user" : {
      "name" : "Cam",
      "screen_name" : "WrathOfCam",
      "protected" : false,
      "id_str" : "20987411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769322135336652801\/9R_a4UjJ_normal.jpg",
      "id" : 20987411,
      "verified" : false
    }
  },
  "id" : 229904921640722433,
  "created_at" : "2012-07-30 11:42:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura",
      "screen_name" : "VenusManTrap22",
      "indices" : [ 0, 15 ],
      "id_str" : "286942658",
      "id" : 286942658
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 107, 121 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229771374133141504",
  "geo" : { },
  "id_str" : "229774163055882240",
  "in_reply_to_user_id" : 286942658,
  "text" : "@VenusManTrap22 I do think BAS gets a bit over zealous but I also agree w you that he must please himself  @biblealsosays",
  "id" : 229774163055882240,
  "in_reply_to_status_id" : 229771374133141504,
  "created_at" : "2012-07-30 03:03:24 +0000",
  "in_reply_to_screen_name" : "VenusManTrap22",
  "in_reply_to_user_id_str" : "286942658",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Montano",
      "screen_name" : "Daezarkian",
      "indices" : [ 26, 37 ],
      "id_str" : "31248960",
      "id" : 31248960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229600430303346688",
  "geo" : { },
  "id_str" : "229601509359382528",
  "in_reply_to_user_id" : 31248960,
  "text" : "story of my life.. LOL RT @Daezarkian I'm carefully avoiding being responsible right now.",
  "id" : 229601509359382528,
  "in_reply_to_status_id" : 229600430303346688,
  "created_at" : "2012-07-29 15:37:20 +0000",
  "in_reply_to_screen_name" : "Daezarkian",
  "in_reply_to_user_id_str" : "31248960",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "indices" : [ 3, 16 ],
      "id_str" : "525383338",
      "id" : 525383338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229596773616852992",
  "text" : "RT @ClosureForKC: The sun doesnt give light to the moon thinking the moons gonna owe it one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229596385857642497",
    "text" : "The sun doesnt give light to the moon thinking the moons gonna owe it one.",
    "id" : 229596385857642497,
    "created_at" : "2012-07-29 15:16:58 +0000",
    "user" : {
      "name" : "Dive~in~me",
      "screen_name" : "ClosureForKC",
      "protected" : false,
      "id_str" : "525383338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2036373342\/Kurt_Cobain_normal_normal.jpg",
      "id" : 525383338,
      "verified" : false
    }
  },
  "id" : 229596773616852992,
  "created_at" : "2012-07-29 15:18:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229596275161567232",
  "text" : "RT @parkstepp: \u201CPeople are often unreasonable and self-centered. Forgive them anyway. If you are kind, people may accu...\u201D http:\/\/t.co\/g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/g0jTKV64",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyQKorzE",
        "display_url" : "tmblr.co\/ZwrrNyQKorzE"
      } ]
    },
    "geo" : { },
    "id_str" : "229594120992223235",
    "text" : "\u201CPeople are often unreasonable and self-centered. Forgive them anyway. If you are kind, people may accu...\u201D http:\/\/t.co\/g0jTKV64",
    "id" : 229594120992223235,
    "created_at" : "2012-07-29 15:07:58 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 229596275161567232,
  "created_at" : "2012-07-29 15:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaile",
      "screen_name" : "SototG",
      "indices" : [ 3, 10 ],
      "id_str" : "44868806",
      "id" : 44868806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229593870890057728",
  "text" : "RT @SototG: God works when man rests. I never realized that",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229591639826509824",
    "text" : "God works when man rests. I never realized that",
    "id" : 229591639826509824,
    "created_at" : "2012-07-29 14:58:07 +0000",
    "user" : {
      "name" : "Gaile",
      "screen_name" : "SototG",
      "protected" : false,
      "id_str" : "44868806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750405556150542337\/34nz7-0g_normal.jpg",
      "id" : 44868806,
      "verified" : false
    }
  },
  "id" : 229593870890057728,
  "created_at" : "2012-07-29 15:06:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229585637647454210",
  "text" : "RT @By_Bashar: You don't have a soul. You are a Soul. Your body is in your soul ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229585147467554816",
    "text" : "You don't have a soul. You are a Soul. Your body is in your soul ~ bashar",
    "id" : 229585147467554816,
    "created_at" : "2012-07-29 14:32:19 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 229585637647454210,
  "created_at" : "2012-07-29 14:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229577784060674049",
  "geo" : { },
  "id_str" : "229581480668590080",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves my coffee does not please me but other than that i'm good..lol",
  "id" : 229581480668590080,
  "in_reply_to_status_id" : 229577784060674049,
  "created_at" : "2012-07-29 14:17:45 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BrianMerritt\/status\/229573776180928512\/photo\/1",
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/6BhF4gbW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay-cIhNCYAEttof.jpg",
      "id_str" : "229573776185122817",
      "id" : 229573776185122817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay-cIhNCYAEttof.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6BhF4gbW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229576517741580288",
  "text" : "RT @BrianMerritt: Trying to relax with this stressful view.  ;-) http:\/\/t.co\/6BhF4gbW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrianMerritt\/status\/229573776180928512\/photo\/1",
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/6BhF4gbW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay-cIhNCYAEttof.jpg",
        "id_str" : "229573776185122817",
        "id" : 229573776185122817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay-cIhNCYAEttof.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6BhF4gbW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.7411148081, -84.4327003204 ]
    },
    "id_str" : "229573776180928512",
    "text" : "Trying to relax with this stressful view.  ;-) http:\/\/t.co\/6BhF4gbW",
    "id" : 229573776180928512,
    "created_at" : "2012-07-29 13:47:08 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 229576517741580288,
  "created_at" : "2012-07-29 13:58:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 51, 61 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/S07DX0W1",
      "expanded_url" : "http:\/\/shar.es\/vHgte",
      "display_url" : "shar.es\/vHgte"
    } ]
  },
  "geo" : { },
  "id_str" : "229576040501092353",
  "text" : "Enough to make me smile!\n http:\/\/t.co\/S07DX0W1 via @sharethis",
  "id" : 229576040501092353,
  "created_at" : "2012-07-29 13:56:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 21, 28 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/a6YSuvV8",
      "expanded_url" : "http:\/\/bit.ly\/QBLirj",
      "display_url" : "bit.ly\/QBLirj"
    } ]
  },
  "geo" : { },
  "id_str" : "229575640582615041",
  "text" : "RT @DwayneReaves: RT @screek: My Photos For The Day \"The Custer State Park Begging Burros\" http:\/\/t.co\/a6YSuvV8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 3, 10 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/a6YSuvV8",
        "expanded_url" : "http:\/\/bit.ly\/QBLirj",
        "display_url" : "bit.ly\/QBLirj"
      } ]
    },
    "geo" : { },
    "id_str" : "229573100017172480",
    "text" : "RT @screek: My Photos For The Day \"The Custer State Park Begging Burros\" http:\/\/t.co\/a6YSuvV8",
    "id" : 229573100017172480,
    "created_at" : "2012-07-29 13:44:26 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 229575640582615041,
  "created_at" : "2012-07-29 13:54:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 3, 15 ],
      "id_str" : "14676842",
      "id" : 14676842
    }, {
      "name" : "HuffPost Religion",
      "screen_name" : "HuffPostRelig",
      "indices" : [ 17, 31 ],
      "id_str" : "117189136",
      "id" : 117189136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229573310298607616",
  "text" : "RT @muichimotsu: @HuffPostRelig Why shouldn't we forgive those who commit atrocities if those atrocities only survive because of feeling ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Religion",
        "screen_name" : "HuffPostRelig",
        "indices" : [ 0, 14 ],
        "id_str" : "117189136",
        "id" : 117189136
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "228893765572628480",
    "geo" : { },
    "id_str" : "228895197910679552",
    "in_reply_to_user_id" : 117189136,
    "text" : "@HuffPostRelig Why shouldn't we forgive those who commit atrocities if those atrocities only survive because of feelings of hatred?",
    "id" : 228895197910679552,
    "in_reply_to_status_id" : 228893765572628480,
    "created_at" : "2012-07-27 16:50:42 +0000",
    "in_reply_to_screen_name" : "HuffPostRelig",
    "in_reply_to_user_id_str" : "117189136",
    "user" : {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "protected" : false,
      "id_str" : "14676842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2798375662\/865b411510587724a85034a3bda101c0_normal.jpeg",
      "id" : 14676842,
      "verified" : false
    }
  },
  "id" : 229573310298607616,
  "created_at" : "2012-07-29 13:45:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229407318595469312",
  "geo" : { },
  "id_str" : "229408892440956928",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny haven't seen it... Maybe tomorrow when I open up my lappie for the day..lol (on my iPod touch now)",
  "id" : 229408892440956928,
  "in_reply_to_status_id" : 229407318595469312,
  "created_at" : "2012-07-29 02:51:56 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 2, 14 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229405595084677120",
  "geo" : { },
  "id_str" : "229407033563152384",
  "in_reply_to_user_id" : 51880276,
  "text" : ". @VirgoJohnny I'm soooo proud of you! ((hugs))",
  "id" : 229407033563152384,
  "in_reply_to_status_id" : 229405595084677120,
  "created_at" : "2012-07-29 02:44:33 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/y0VekkNE",
      "expanded_url" : "http:\/\/Bookwi.se",
      "display_url" : "Bookwi.se"
    } ]
  },
  "geo" : { },
  "id_str" : "229406611360317440",
  "text" : "RT @adamrshields: Anyone want to write a Book review for my blog http:\/\/t.co\/y0VekkNE, I need some more this week",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/y0VekkNE",
        "expanded_url" : "http:\/\/Bookwi.se",
        "display_url" : "Bookwi.se"
      } ]
    },
    "geo" : { },
    "id_str" : "229406400588156928",
    "text" : "Anyone want to write a Book review for my blog http:\/\/t.co\/y0VekkNE, I need some more this week",
    "id" : 229406400588156928,
    "created_at" : "2012-07-29 02:42:02 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 229406611360317440,
  "created_at" : "2012-07-29 02:42:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 13, 28 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "choice",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229316361443241984",
  "geo" : { },
  "id_str" : "229316826503450624",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu @thesexyatheist LOL #freedom #choice",
  "id" : 229316826503450624,
  "in_reply_to_status_id" : 229316361443241984,
  "created_at" : "2012-07-28 20:46:06 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 10, 22 ],
      "id_str" : "14676842",
      "id" : 14676842
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 53, 68 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/fE1y1NDG",
      "expanded_url" : "http:\/\/bit.ly\/OuacJE",
      "display_url" : "bit.ly\/OuacJE"
    } ]
  },
  "in_reply_to_status_id_str" : "229313182374711297",
  "geo" : { },
  "id_str" : "229316021427765248",
  "in_reply_to_user_id" : 14676842,
  "text" : "good post @muichimotsu .. you might be interested in @thesexyatheist post: Fuck Purity Balls...They're Creepy http:\/\/t.co\/fE1y1NDG",
  "id" : 229316021427765248,
  "in_reply_to_status_id" : 229313182374711297,
  "created_at" : "2012-07-28 20:42:54 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 54, 66 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229041135329374208",
  "text" : ". @RushLevinBeck why is liberalism a mental disorder? @virgojohnny",
  "id" : 229041135329374208,
  "created_at" : "2012-07-28 02:30:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Daniel Huber",
      "screen_name" : "docforestal",
      "indices" : [ 64, 76 ],
      "id_str" : "22374870",
      "id" : 22374870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/lVzfImps",
      "expanded_url" : "http:\/\/www.natureobservances.com\/feeder-birds-for-friday-2\/",
      "display_url" : "natureobservances.com\/feeder-birds-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "229028943339073536",
  "text" : "RT @gemswinc: Feeder Birds for Friday: http:\/\/t.co\/lVzfImps via @docforestal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Huber",
        "screen_name" : "docforestal",
        "indices" : [ 50, 62 ],
        "id_str" : "22374870",
        "id" : 22374870
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/lVzfImps",
        "expanded_url" : "http:\/\/www.natureobservances.com\/feeder-birds-for-friday-2\/",
        "display_url" : "natureobservances.com\/feeder-birds-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "229022694862106624",
    "text" : "Feeder Birds for Friday: http:\/\/t.co\/lVzfImps via @docforestal",
    "id" : 229022694862106624,
    "created_at" : "2012-07-28 01:17:20 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 229028943339073536,
  "created_at" : "2012-07-28 01:42:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "30steps",
      "screen_name" : "JeremiahBilas",
      "indices" : [ 3, 17 ],
      "id_str" : "142393765",
      "id" : 142393765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Consciousness",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/NzoU2lU4",
      "expanded_url" : "http:\/\/lnkd.in\/q9xEp5",
      "display_url" : "lnkd.in\/q9xEp5"
    } ]
  },
  "geo" : { },
  "id_str" : "229028823390367744",
  "text" : "RT @JeremiahBilas: Non-Human #Consciousness Exists Say Experts. Now What? | Singularity Hub http:\/\/t.co\/NzoU2lU4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Consciousness",
        "indices" : [ 10, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/NzoU2lU4",
        "expanded_url" : "http:\/\/lnkd.in\/q9xEp5",
        "display_url" : "lnkd.in\/q9xEp5"
      } ]
    },
    "geo" : { },
    "id_str" : "229023094289879040",
    "text" : "Non-Human #Consciousness Exists Say Experts. Now What? | Singularity Hub http:\/\/t.co\/NzoU2lU4",
    "id" : 229023094289879040,
    "created_at" : "2012-07-28 01:18:55 +0000",
    "user" : {
      "name" : "30steps",
      "screen_name" : "JeremiahBilas",
      "protected" : false,
      "id_str" : "142393765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2188701998\/downloadfile_normal.jpeg",
      "id" : 142393765,
      "verified" : false
    }
  },
  "id" : 229028823390367744,
  "created_at" : "2012-07-28 01:41:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229017563089231872",
  "text" : "well.. not totally broken.. just had to delete a plugin..",
  "id" : 229017563089231872,
  "created_at" : "2012-07-28 00:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229000359656423424",
  "text" : "oops..i broke my test website today... o-O",
  "id" : 229000359656423424,
  "created_at" : "2012-07-27 23:48:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228959705144369152",
  "geo" : { },
  "id_str" : "228962212256038912",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin leave? sounds ominous...",
  "id" : 228962212256038912,
  "in_reply_to_status_id" : 228959705144369152,
  "created_at" : "2012-07-27 21:16:59 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 3, 16 ],
      "id_str" : "256540769",
      "id" : 256540769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/42FXlAeJ",
      "expanded_url" : "http:\/\/bit.ly\/MKe8d2",
      "display_url" : "bit.ly\/MKe8d2"
    } ]
  },
  "geo" : { },
  "id_str" : "228885704141316096",
  "text" : "RT @HarryShannon: Health care as kindess. A shot in the dark - Roger Ebert's Journal http:\/\/t.co\/42FXlAeJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/42FXlAeJ",
        "expanded_url" : "http:\/\/bit.ly\/MKe8d2",
        "display_url" : "bit.ly\/MKe8d2"
      } ]
    },
    "geo" : { },
    "id_str" : "228883464370393088",
    "text" : "Health care as kindess. A shot in the dark - Roger Ebert's Journal http:\/\/t.co\/42FXlAeJ",
    "id" : 228883464370393088,
    "created_at" : "2012-07-27 16:04:05 +0000",
    "user" : {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "protected" : false,
      "id_str" : "256540769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798645625289965568\/8ai82ECm_normal.jpg",
      "id" : 256540769,
      "verified" : false
    }
  },
  "id" : 228885704141316096,
  "created_at" : "2012-07-27 16:12:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Care2.com",
      "screen_name" : "Care2",
      "indices" : [ 70, 76 ],
      "id_str" : "14143921",
      "id" : 14143921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228879879079354368",
  "text" : "RT @mindymayhem: Why would it be offensive? People wear swimsuits. RT @Care2: Down Syndrome swimsuit model: progressive or offensive? ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Care2.com",
        "screen_name" : "Care2",
        "indices" : [ 53, 59 ],
        "id_str" : "14143921",
        "id" : 14143921
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/evZh4wAT",
        "expanded_url" : "http:\/\/buff.ly\/OrOSoe",
        "display_url" : "buff.ly\/OrOSoe"
      } ]
    },
    "in_reply_to_status_id_str" : "228874999186997248",
    "geo" : { },
    "id_str" : "228878941794992129",
    "in_reply_to_user_id" : 14143921,
    "text" : "Why would it be offensive? People wear swimsuits. RT @Care2: Down Syndrome swimsuit model: progressive or offensive? http:\/\/t.co\/evZh4wAT",
    "id" : 228878941794992129,
    "in_reply_to_status_id" : 228874999186997248,
    "created_at" : "2012-07-27 15:46:06 +0000",
    "in_reply_to_screen_name" : "Care2",
    "in_reply_to_user_id_str" : "14143921",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 228879879079354368,
  "created_at" : "2012-07-27 15:49:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228868659186130944",
  "text" : "oh she's smooth.. weather gal stealthily adjusts her dress without missing a beat : )",
  "id" : 228868659186130944,
  "created_at" : "2012-07-27 15:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ryan",
      "screen_name" : "ChrisDelorey",
      "indices" : [ 3, 16 ],
      "id_str" : "190100756",
      "id" : 190100756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/Pn0IEUpK",
      "expanded_url" : "http:\/\/gma.yahoo.com\/blogs\/abc-blogs\/conn-man-rescues-80-old-lobster-restaurant-menu-154047429--abc-news-topstories.html",
      "display_url" : "gma.yahoo.com\/blogs\/abc-blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228867275015454720",
  "text" : "RT @chrisdelorey: Conn. Man Rescues 80-Year-Old Lobster From Restaurant Menu http:\/\/t.co\/Pn0IEUpK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/Pn0IEUpK",
        "expanded_url" : "http:\/\/gma.yahoo.com\/blogs\/abc-blogs\/conn-man-rescues-80-old-lobster-restaurant-menu-154047429--abc-news-topstories.html",
        "display_url" : "gma.yahoo.com\/blogs\/abc-blog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "228865385473114112",
    "text" : "Conn. Man Rescues 80-Year-Old Lobster From Restaurant Menu http:\/\/t.co\/Pn0IEUpK",
    "id" : 228865385473114112,
    "created_at" : "2012-07-27 14:52:14 +0000",
    "user" : {
      "name" : "Christine DeLorey",
      "screen_name" : "the9numbers",
      "protected" : false,
      "id_str" : "24301880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1288489336\/ChristineDeLorey_normal.jpg",
      "id" : 24301880,
      "verified" : false
    }
  },
  "id" : 228867275015454720,
  "created_at" : "2012-07-27 14:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228863183186706432",
  "geo" : { },
  "id_str" : "228864798329294848",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool that's what they all say..lol. I do them sometimes but I follow so many awesome peeps, its hard to choose.",
  "id" : 228864798329294848,
  "in_reply_to_status_id" : 228863183186706432,
  "created_at" : "2012-07-27 14:49:54 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228653055707602944",
  "geo" : { },
  "id_str" : "228653552099262464",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses on logo channel on directv.. hubby says from 1999.",
  "id" : 228653552099262464,
  "in_reply_to_status_id" : 228653055707602944,
  "created_at" : "2012-07-27 00:50:29 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228649829734174721",
  "geo" : { },
  "id_str" : "228651249791279105",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses hubby's got House on Haunted Hill on now...",
  "id" : 228651249791279105,
  "in_reply_to_status_id" : 228649829734174721,
  "created_at" : "2012-07-27 00:41:20 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228638761800589312",
  "geo" : { },
  "id_str" : "228642028907528194",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses Me, too!! ; )",
  "id" : 228642028907528194,
  "in_reply_to_status_id" : 228638761800589312,
  "created_at" : "2012-07-27 00:04:42 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PlaybillKenneth\/status\/228636270442708993\/photo\/1",
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/Q3mO17iC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyxHegLCAAEQpL2.jpg",
      "id_str" : "228636270446903297",
      "id" : 228636270446903297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyxHegLCAAEQpL2.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Q3mO17iC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228638475921002496",
  "text" : "RT @PlaybillKenneth: Creepy Ghostbusters skies over Manhattan. http:\/\/t.co\/Q3mO17iC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PlaybillKenneth\/status\/228636270442708993\/photo\/1",
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/Q3mO17iC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AyxHegLCAAEQpL2.jpg",
        "id_str" : "228636270446903297",
        "id" : 228636270446903297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyxHegLCAAEQpL2.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Q3mO17iC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228636270442708993",
    "text" : "Creepy Ghostbusters skies over Manhattan. http:\/\/t.co\/Q3mO17iC",
    "id" : 228636270442708993,
    "created_at" : "2012-07-26 23:41:50 +0000",
    "user" : {
      "name" : "Kenneth Jones",
      "screen_name" : "ByKennethJones",
      "protected" : false,
      "id_str" : "125356747",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000046792612\/cb146d96aea1b5be38ec4cc79dd7e7c6_normal.jpeg",
      "id" : 125356747,
      "verified" : false
    }
  },
  "id" : 228638475921002496,
  "created_at" : "2012-07-26 23:50:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 2, 14 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228609035799244800",
  "geo" : { },
  "id_str" : "228619825600151552",
  "in_reply_to_user_id" : 51880276,
  "text" : ". @VirgoJohnny \"worrying about what other people do is not a healthy lifestyle\" - me : )",
  "id" : 228619825600151552,
  "in_reply_to_status_id" : 228609035799244800,
  "created_at" : "2012-07-26 22:36:28 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228617303321890816",
  "text" : "RT @nakedpastor: I just wrote a post for those of us grieving after leaving the church... \"don't let anyone rush your grief\": http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/Je6B7S0E",
        "expanded_url" : "http:\/\/www.nakedpastor.com\/?p=11781",
        "display_url" : "nakedpastor.com\/?p=11781"
      } ]
    },
    "geo" : { },
    "id_str" : "228611188383158272",
    "text" : "I just wrote a post for those of us grieving after leaving the church... \"don't let anyone rush your grief\": http:\/\/t.co\/Je6B7S0E",
    "id" : 228611188383158272,
    "created_at" : "2012-07-26 22:02:09 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 228617303321890816,
  "created_at" : "2012-07-26 22:26:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228616648834306048",
  "text" : "RT @TheGoldenMirror: Don't let other people tell you what's in front of you. Make up your own mind about it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228614087423188992",
    "text" : "Don't let other people tell you what's in front of you. Make up your own mind about it.",
    "id" : 228614087423188992,
    "created_at" : "2012-07-26 22:13:40 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 228616648834306048,
  "created_at" : "2012-07-26 22:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 78, 88 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Possum",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/p7JJgSxO",
      "expanded_url" : "http:\/\/shar.es\/vnvaz",
      "display_url" : "shar.es\/vnvaz"
    } ]
  },
  "geo" : { },
  "id_str" : "228611399033708544",
  "text" : "SQUEEE! too cute! &gt;&gt; #Possum Noms a Strawberry http:\/\/t.co\/p7JJgSxO via @sharethis",
  "id" : 228611399033708544,
  "created_at" : "2012-07-26 22:02:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Android Authority",
      "screen_name" : "AndroidAuth",
      "indices" : [ 3, 15 ],
      "id_str" : "95438524",
      "id" : 95438524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/HYf8N7cT",
      "expanded_url" : "http:\/\/bit.ly\/O1kyAl",
      "display_url" : "bit.ly\/O1kyAl"
    } ]
  },
  "geo" : { },
  "id_str" : "228507154720649216",
  "text" : "RT @AndroidAuth: Keek: Android app for 36-second video status updates http:\/\/t.co\/HYf8N7cT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/HYf8N7cT",
        "expanded_url" : "http:\/\/bit.ly\/O1kyAl",
        "display_url" : "bit.ly\/O1kyAl"
      } ]
    },
    "geo" : { },
    "id_str" : "228497947841667074",
    "text" : "Keek: Android app for 36-second video status updates http:\/\/t.co\/HYf8N7cT",
    "id" : 228497947841667074,
    "created_at" : "2012-07-26 14:32:10 +0000",
    "user" : {
      "name" : "Android Authority",
      "screen_name" : "AndroidAuth",
      "protected" : false,
      "id_str" : "95438524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651260268236812289\/vbpawQ35_normal.png",
      "id" : 95438524,
      "verified" : true
    }
  },
  "id" : 228507154720649216,
  "created_at" : "2012-07-26 15:08:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228506972046110720",
  "text" : "RT @angelaharms: \"if u\u2026 want to make fewer errors, make an environment where sharing errors is psychologically easier than not.\u201D\n -- @cj ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "June Kim",
        "screen_name" : "cjunekim",
        "indices" : [ 116, 125 ],
        "id_str" : "21382169",
        "id" : 21382169
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228502713678327810",
    "text" : "\"if u\u2026 want to make fewer errors, make an environment where sharing errors is psychologically easier than not.\u201D\n -- @cjunekim",
    "id" : 228502713678327810,
    "created_at" : "2012-07-26 14:51:06 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 228506972046110720,
  "created_at" : "2012-07-26 15:08:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228460943997284352",
  "geo" : { },
  "id_str" : "228462438218088450",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool LOL.. my heaven is gonna have a lot of atheists in it ; )",
  "id" : 228462438218088450,
  "in_reply_to_status_id" : 228460943997284352,
  "created_at" : "2012-07-26 12:11:04 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228306360297725952",
  "text" : "RT @Soulseedzforall: You are the right person, alive at the right time, to leave a legacy of love in the world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228305276867076096",
    "text" : "You are the right person, alive at the right time, to leave a legacy of love in the world.",
    "id" : 228305276867076096,
    "created_at" : "2012-07-26 01:46:34 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 228306360297725952,
  "created_at" : "2012-07-26 01:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 0, 11 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228302055394144256",
  "geo" : { },
  "id_str" : "228306250398564352",
  "in_reply_to_user_id" : 25030624,
  "text" : "@shanecrash why didn't I think of that before? : )",
  "id" : 228306250398564352,
  "in_reply_to_status_id" : 228302055394144256,
  "created_at" : "2012-07-26 01:50:26 +0000",
  "in_reply_to_screen_name" : "shanecrash",
  "in_reply_to_user_id_str" : "25030624",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/h06bt95C",
      "expanded_url" : "http:\/\/www.shanecrash.com",
      "display_url" : "shanecrash.com"
    } ]
  },
  "geo" : { },
  "id_str" : "228305900962725890",
  "text" : "RT @shanecrash: God is Schrodinger's Cat.\nhttp:\/\/t.co\/h06bt95C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/h06bt95C",
        "expanded_url" : "http:\/\/www.shanecrash.com",
        "display_url" : "shanecrash.com"
      } ]
    },
    "geo" : { },
    "id_str" : "228302055394144256",
    "text" : "God is Schrodinger's Cat.\nhttp:\/\/t.co\/h06bt95C",
    "id" : 228302055394144256,
    "created_at" : "2012-07-26 01:33:46 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 228305900962725890,
  "created_at" : "2012-07-26 01:49:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/nC0SnNTM",
      "expanded_url" : "http:\/\/ebookne.ws\/STOyl6",
      "display_url" : "ebookne.ws\/STOyl6"
    } ]
  },
  "geo" : { },
  "id_str" : "228132701050388481",
  "text" : "RT @thDigitalReader: eBook Gift Cards Now Taking Off in Germany http:\/\/t.co\/nC0SnNTM by Nate Hoffelder",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wordpress.org\/extend\/plugins\/twitter-publisher\/\" rel=\"nofollow\"\u003ETwitPublisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/nC0SnNTM",
        "expanded_url" : "http:\/\/ebookne.ws\/STOyl6",
        "display_url" : "ebookne.ws\/STOyl6"
      } ]
    },
    "geo" : { },
    "id_str" : "228129797707014144",
    "text" : "eBook Gift Cards Now Taking Off in Germany http:\/\/t.co\/nC0SnNTM by Nate Hoffelder",
    "id" : 228129797707014144,
    "created_at" : "2012-07-25 14:09:16 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 228132701050388481,
  "created_at" : "2012-07-25 14:20:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MasterChef",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228127916700098562",
  "text" : "hubby had to hook up the generator so we could watch #MasterChef last night. Monty was so cute w prawns. I adore her!",
  "id" : 228127916700098562,
  "created_at" : "2012-07-25 14:01:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228122827948163072",
  "geo" : { },
  "id_str" : "228127422363607040",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny cool beans.. sharing this with hubby (scottish descent and loves scotland..lol)",
  "id" : 228127422363607040,
  "in_reply_to_status_id" : 228122827948163072,
  "created_at" : "2012-07-25 13:59:50 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 32, 42 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/Mw750c8T",
      "expanded_url" : "http:\/\/wp.me\/szgRU-stands",
      "display_url" : "wp.me\/szgRU-stands"
    } ]
  },
  "geo" : { },
  "id_str" : "228125547576836096",
  "text" : "Stands http:\/\/t.co\/Mw750c8T via @ZachsMind",
  "id" : 228125547576836096,
  "created_at" : "2012-07-25 13:52:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227942633782251520",
  "text" : "electric out for a few hours due to quick freak storm in the area.. lots of trees down.",
  "id" : 227942633782251520,
  "created_at" : "2012-07-25 01:45:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "COG_Bingo0819",
      "screen_name" : "Dotte_Boy78",
      "indices" : [ 0, 12 ],
      "id_str" : "355910668",
      "id" : 355910668
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 13, 25 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Liberal Rehab",
      "screen_name" : "LibRehab",
      "indices" : [ 26, 35 ],
      "id_str" : "577825345",
      "id" : 577825345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227841216472027136",
  "geo" : { },
  "id_str" : "227942385676591105",
  "in_reply_to_user_id" : 355910668,
  "text" : "@Dotte_Boy78 @VirgoJohnny @LibRehab no, I don't agree with it.",
  "id" : 227942385676591105,
  "in_reply_to_status_id" : 227841216472027136,
  "created_at" : "2012-07-25 01:44:34 +0000",
  "in_reply_to_screen_name" : "Dotte_Boy78",
  "in_reply_to_user_id_str" : "355910668",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "Lake_Travis_TX",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/UznlXZ2J",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/7699",
      "display_url" : "wildobs.com\/wo\/7699"
    } ]
  },
  "geo" : { },
  "id_str" : "227858426783469568",
  "text" : "RT @wildobs: In case you missed it: Deer http:\/\/t.co\/UznlXZ2J #EOTD #wildlife #Lake_Travis_TX Bird Feeder?  Hmmmmmmmmmmm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 49, 54 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 55, 64 ]
      }, {
        "text" : "Lake_Travis_TX",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/UznlXZ2J",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/7699",
        "display_url" : "wildobs.com\/wo\/7699"
      } ]
    },
    "geo" : { },
    "id_str" : "227854877957705728",
    "text" : "In case you missed it: Deer http:\/\/t.co\/UznlXZ2J #EOTD #wildlife #Lake_Travis_TX Bird Feeder?  Hmmmmmmmmmmm",
    "id" : 227854877957705728,
    "created_at" : "2012-07-24 19:56:50 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 227858426783469568,
  "created_at" : "2012-07-24 20:10:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    }, {
      "name" : "Lee Child",
      "screen_name" : "LeeChildReacher",
      "indices" : [ 30, 46 ],
      "id_str" : "27877874",
      "id" : 27877874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227830438272593921",
  "text" : "RT @RichardMabry: Want to ask @LeeChildReacher why Tom Cruise is cast as Jack Reacher in new movie. Did they give you no creative input? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lee Child",
        "screen_name" : "LeeChildReacher",
        "indices" : [ 12, 28 ],
        "id_str" : "27877874",
        "id" : 27877874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/JmughZxg",
        "expanded_url" : "http:\/\/bit.ly\/NSTZgL",
        "display_url" : "bit.ly\/NSTZgL"
      } ]
    },
    "geo" : { },
    "id_str" : "227829492196990976",
    "text" : "Want to ask @LeeChildReacher why Tom Cruise is cast as Jack Reacher in new movie. Did they give you no creative input? http:\/\/t.co\/JmughZxg",
    "id" : 227829492196990976,
    "created_at" : "2012-07-24 18:15:58 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 227830438272593921,
  "created_at" : "2012-07-24 18:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "animals",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "nature",
      "indices" : [ 93, 100 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/brq4vqQP",
      "expanded_url" : "http:\/\/ow.ly\/cs4uN",
      "display_url" : "ow.ly\/cs4uN"
    } ]
  },
  "geo" : { },
  "id_str" : "227824788759015424",
  "text" : "RT @KerriFar: Mink seen at Bisset Park - beautiful little #animals ~ http:\/\/t.co\/brq4vqQP  ~ #nature #wildlife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "animals",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "nature",
        "indices" : [ 79, 86 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/brq4vqQP",
        "expanded_url" : "http:\/\/ow.ly\/cs4uN",
        "display_url" : "ow.ly\/cs4uN"
      } ]
    },
    "geo" : { },
    "id_str" : "227821731203645440",
    "text" : "Mink seen at Bisset Park - beautiful little #animals ~ http:\/\/t.co\/brq4vqQP  ~ #nature #wildlife",
    "id" : 227821731203645440,
    "created_at" : "2012-07-24 17:45:08 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 227824788759015424,
  "created_at" : "2012-07-24 17:57:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Liberal Rehab",
      "screen_name" : "LibRehab",
      "indices" : [ 60, 69 ],
      "id_str" : "577825345",
      "id" : 577825345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227822147911954432",
  "geo" : { },
  "id_str" : "227824438865973248",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny you dont like it, either? yay VJ! ((highfive)) @librehab",
  "id" : 227824438865973248,
  "in_reply_to_status_id" : 227822147911954432,
  "created_at" : "2012-07-24 17:55:53 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan M Steele",
      "screen_name" : "susan_m_steele",
      "indices" : [ 3, 18 ],
      "id_str" : "16012759",
      "id" : 16012759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/sCmR4T5j",
      "expanded_url" : "http:\/\/fb.me\/CyF6siAw",
      "display_url" : "fb.me\/CyF6siAw"
    } ]
  },
  "geo" : { },
  "id_str" : "227809668720893952",
  "text" : "RT @susan_m_steele: I move slowly.  That's just the way it is.  Do you feel the same?... http:\/\/t.co\/sCmR4T5j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/sCmR4T5j",
        "expanded_url" : "http:\/\/fb.me\/CyF6siAw",
        "display_url" : "fb.me\/CyF6siAw"
      } ]
    },
    "geo" : { },
    "id_str" : "227809015076356097",
    "text" : "I move slowly.  That's just the way it is.  Do you feel the same?... http:\/\/t.co\/sCmR4T5j",
    "id" : 227809015076356097,
    "created_at" : "2012-07-24 16:54:36 +0000",
    "user" : {
      "name" : "Susan M Steele",
      "screen_name" : "susan_m_steele",
      "protected" : false,
      "id_str" : "16012759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721385053658292224\/rFADa5qy_normal.jpg",
      "id" : 16012759,
      "verified" : false
    }
  },
  "id" : 227809668720893952,
  "created_at" : "2012-07-24 16:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "indices" : [ 17, 25 ],
      "id_str" : "6753582",
      "id" : 6753582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/5NUbidab",
      "expanded_url" : "http:\/\/ow.ly\/csPmJ",
      "display_url" : "ow.ly\/csPmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "227809228528701440",
  "text" : "RT @AniKnits: RT @BlogHer A mother, asking for accommodations, is chastised in public: Autism is No Excuse? Really? http:\/\/t.co\/5NUbidab ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BlogHer",
        "screen_name" : "BlogHer",
        "indices" : [ 3, 11 ],
        "id_str" : "6753582",
        "id" : 6753582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/5NUbidab",
        "expanded_url" : "http:\/\/ow.ly\/csPmJ",
        "display_url" : "ow.ly\/csPmJ"
      } ]
    },
    "geo" : { },
    "id_str" : "227805970565312512",
    "text" : "RT @BlogHer A mother, asking for accommodations, is chastised in public: Autism is No Excuse? Really? http:\/\/t.co\/5NUbidab -Momo",
    "id" : 227805970565312512,
    "created_at" : "2012-07-24 16:42:30 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 227809228528701440,
  "created_at" : "2012-07-24 16:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tasmanian Pup",
      "screen_name" : "AteSomeClowns",
      "indices" : [ 3, 17 ],
      "id_str" : "59211658",
      "id" : 59211658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227803692085149696",
  "text" : "RT @AteSomeClowns: My cooking show is 30 minutes of me staring into the fridge.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202474492587556865",
    "text" : "My cooking show is 30 minutes of me staring into the fridge.",
    "id" : 202474492587556865,
    "created_at" : "2012-05-15 19:04:15 +0000",
    "user" : {
      "name" : "Tasmanian Pup",
      "screen_name" : "AteSomeClowns",
      "protected" : false,
      "id_str" : "59211658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2521606821\/9kiynowheafb5yu5tbcs_normal.jpeg",
      "id" : 59211658,
      "verified" : false
    }
  },
  "id" : 227803692085149696,
  "created_at" : "2012-07-24 16:33:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 3, 14 ],
      "id_str" : "94608663",
      "id" : 94608663
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hiring",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "job",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "offer",
      "indices" : [ 64, 70 ]
    }, {
      "text" : "jobfair",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/UhJfKbaE",
      "expanded_url" : "http:\/\/www.facebook.com\/photo.php?fbid=10150969840506947&set=a.209276626946.133097.190018231946&type=1&theater&notif_t=photo_comment",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227803307899490304",
  "text" : "RT @MEDGESTORE: We're hiring! http:\/\/t.co\/UhJfKbaE #hiring #job #offer #jobfair",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hiring",
        "indices" : [ 35, 42 ]
      }, {
        "text" : "job",
        "indices" : [ 43, 47 ]
      }, {
        "text" : "offer",
        "indices" : [ 48, 54 ]
      }, {
        "text" : "jobfair",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http:\/\/t.co\/UhJfKbaE",
        "expanded_url" : "http:\/\/www.facebook.com\/photo.php?fbid=10150969840506947&set=a.209276626946.133097.190018231946&type=1&theater&notif_t=photo_comment",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "227802146328948737",
    "text" : "We're hiring! http:\/\/t.co\/UhJfKbaE #hiring #job #offer #jobfair",
    "id" : 227802146328948737,
    "created_at" : "2012-07-24 16:27:18 +0000",
    "user" : {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "protected" : false,
      "id_str" : "94608663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684834758027681792\/AxmlNGOl_normal.jpg",
      "id" : 94608663,
      "verified" : false
    }
  },
  "id" : 227803307899490304,
  "created_at" : "2012-07-24 16:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227803297535377408",
  "text" : "RT @JAScribbles: I'm looking for one or two more authors to be a part of my mega giveaway. Must be willing to give away multiple copies  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227802139332861954",
    "text" : "I'm looking for one or two more authors to be a part of my mega giveaway. Must be willing to give away multiple copies of a title. @ me! :)",
    "id" : 227802139332861954,
    "created_at" : "2012-07-24 16:27:17 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 227803297535377408,
  "created_at" : "2012-07-24 16:31:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227796980800319488",
  "text" : "@SocialistXian LOL.. from yr tweets, thought you were mid-20's or so.. (until a recent disney tweet\/pic)",
  "id" : 227796980800319488,
  "created_at" : "2012-07-24 16:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 40, 55 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drawsomething",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227796028135469056",
  "text" : "im addicted to #drawsomething thanks to @peggysuecusses .. LOL",
  "id" : 227796028135469056,
  "created_at" : "2012-07-24 16:03:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227741794400612352",
  "geo" : { },
  "id_str" : "227743303540539392",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny to show my gay affirming (right word?lol) spirit, ima gonna give you a BIG (((HUG)))",
  "id" : 227743303540539392,
  "in_reply_to_status_id" : 227741794400612352,
  "created_at" : "2012-07-24 12:33:29 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227740963924230144",
  "text" : "RT @RichardMabry: Shaking my head at the choice of Tom Cruise to play one of my favorite fiction characters. What were they thinking? ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/JmughZxg",
        "expanded_url" : "http:\/\/bit.ly\/NSTZgL",
        "display_url" : "bit.ly\/NSTZgL"
      } ]
    },
    "geo" : { },
    "id_str" : "227737505980633088",
    "text" : "Shaking my head at the choice of Tom Cruise to play one of my favorite fiction characters. What were they thinking? http:\/\/t.co\/JmughZxg",
    "id" : 227737505980633088,
    "created_at" : "2012-07-24 12:10:27 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 227740963924230144,
  "created_at" : "2012-07-24 12:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sigh",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "bleh",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227737934319726592",
  "text" : "becuz Ted Nugent's coming to area, am DJ question: what did you kill with what? #sigh #bleh",
  "id" : 227737934319726592,
  "created_at" : "2012-07-24 12:12:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E. Bearington-Smythe",
      "screen_name" : "beebearninja",
      "indices" : [ 3, 16 ],
      "id_str" : "375936112",
      "id" : 375936112
    }, {
      "name" : "Leo",
      "screen_name" : "Ieonardobonilla",
      "indices" : [ 112, 128 ],
      "id_str" : "597934309",
      "id" : 597934309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227535834499391488",
  "text" : "RT @beebearninja: So the most moral thing religion's taught u is that rejoicing in the torture of others is ok?\"@Ieonardobonilla:Athiest ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leo",
        "screen_name" : "Ieonardobonilla",
        "indices" : [ 94, 110 ],
        "id_str" : "597934309",
        "id" : 597934309
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227527511947476993",
    "text" : "So the most moral thing religion's taught u is that rejoicing in the torture of others is ok?\"@Ieonardobonilla:Athiests can rot in hell..lol",
    "id" : 227527511947476993,
    "created_at" : "2012-07-23 22:16:00 +0000",
    "user" : {
      "name" : "E. Bearington-Smythe",
      "screen_name" : "beebearninja",
      "protected" : false,
      "id_str" : "375936112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528269801722871808\/9alToNC0_normal.jpeg",
      "id" : 375936112,
      "verified" : false
    }
  },
  "id" : 227535834499391488,
  "created_at" : "2012-07-23 22:49:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 4, 16 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geeks",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/HejydOXw",
      "expanded_url" : "http:\/\/geekli.st\/home",
      "display_url" : "geekli.st\/home"
    } ]
  },
  "geo" : { },
  "id_str" : "227452190627856386",
  "text" : "hey @angelaharms .. this looks up your alley &gt;&gt; http:\/\/t.co\/HejydOXw #geeks : )",
  "id" : 227452190627856386,
  "created_at" : "2012-07-23 17:16:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Buddha",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227219665879957504",
  "text" : "RT @AnAmericanMonk: Hatred does not cease by hatred, but only by love; this is the eternal rule.#Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Buddha",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227218274033737728",
    "text" : "Hatred does not cease by hatred, but only by love; this is the eternal rule.#Buddha",
    "id" : 227218274033737728,
    "created_at" : "2012-07-23 01:47:12 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 227219665879957504,
  "created_at" : "2012-07-23 01:52:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227212717889556480",
  "text" : "My mom is not in this realm anymore but I'm still learning from her...",
  "id" : 227212717889556480,
  "created_at" : "2012-07-23 01:25:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227212117869215744",
  "text" : "These sons on Hoarders are making me so angry... It's yr effing mother!!!",
  "id" : 227212117869215744,
  "created_at" : "2012-07-23 01:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 3, 16 ],
      "id_str" : "145890580",
      "id" : 145890580
    }, {
      "name" : "Nichole Bernier",
      "screen_name" : "NicholeBernier",
      "indices" : [ 26, 41 ],
      "id_str" : "16150527",
      "id" : 16150527
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NicholeBernier\/status\/227145187355398144\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/kJd9EafL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ayb7WC0CEAAU34_.jpg",
      "id_str" : "227145187359592448",
      "id" : 227145187359592448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ayb7WC0CEAAU34_.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com\/kJd9EafL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227153650550718464",
  "text" : "RT @AmyRBromberg: Awww RT @nicholebernier: Cutest. Baby. Sheep. Ever. http:\/\/t.co\/kJd9EafL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nichole Bernier",
        "screen_name" : "NicholeBernier",
        "indices" : [ 8, 23 ],
        "id_str" : "16150527",
        "id" : 16150527
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NicholeBernier\/status\/227145187355398144\/photo\/1",
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/kJd9EafL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ayb7WC0CEAAU34_.jpg",
        "id_str" : "227145187359592448",
        "id" : 227145187359592448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ayb7WC0CEAAU34_.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/kJd9EafL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227153490089213952",
    "text" : "Awww RT @nicholebernier: Cutest. Baby. Sheep. Ever. http:\/\/t.co\/kJd9EafL",
    "id" : 227153490089213952,
    "created_at" : "2012-07-22 21:29:47 +0000",
    "user" : {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "protected" : false,
      "id_str" : "145890580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754371483720376320\/lPjb2W1B_normal.jpg",
      "id" : 145890580,
      "verified" : false
    }
  },
  "id" : 227153650550718464,
  "created_at" : "2012-07-22 21:30:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227148098793787392",
  "geo" : { },
  "id_str" : "227150390305624064",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses WOW! good deal!",
  "id" : 227150390305624064,
  "in_reply_to_status_id" : 227148098793787392,
  "created_at" : "2012-07-22 21:17:27 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Wylie",
      "screen_name" : "jen_wylie",
      "indices" : [ 3, 13 ],
      "id_str" : "145658286",
      "id" : 145658286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/VesSMBE9",
      "expanded_url" : "http:\/\/wp.me\/pZGHr-tu",
      "display_url" : "wp.me\/pZGHr-tu"
    } ]
  },
  "geo" : { },
  "id_str" : "227141318441332736",
  "text" : "RT @jen_wylie: Book Bloggers! Swag packs available! http:\/\/t.co\/VesSMBE9 Only a few left! Great for giveaways on your blog! Review copie ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/VesSMBE9",
        "expanded_url" : "http:\/\/wp.me\/pZGHr-tu",
        "display_url" : "wp.me\/pZGHr-tu"
      } ]
    },
    "geo" : { },
    "id_str" : "227140678327599105",
    "text" : "Book Bloggers! Swag packs available! http:\/\/t.co\/VesSMBE9 Only a few left! Great for giveaways on your blog! Review copies also avail(ebook)",
    "id" : 227140678327599105,
    "created_at" : "2012-07-22 20:38:52 +0000",
    "user" : {
      "name" : "Jen Wylie",
      "screen_name" : "jen_wylie",
      "protected" : false,
      "id_str" : "145658286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1222111242\/jw1A_normal.jpg",
      "id" : 145658286,
      "verified" : false
    }
  },
  "id" : 227141318441332736,
  "created_at" : "2012-07-22 20:41:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Picture",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "Cute",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/i2kHBUnn",
      "expanded_url" : "http:\/\/imgur.com\/OGpkI",
      "display_url" : "imgur.com\/OGpkI"
    } ]
  },
  "geo" : { },
  "id_str" : "227140119239487488",
  "text" : "RT @UnseeingEyes: \"Just two Timber Wolves cuddling.\" http:\/\/t.co\/i2kHBUnn #Picture #Cute",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Picture",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "Cute",
        "indices" : [ 65, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/i2kHBUnn",
        "expanded_url" : "http:\/\/imgur.com\/OGpkI",
        "display_url" : "imgur.com\/OGpkI"
      } ]
    },
    "geo" : { },
    "id_str" : "227139668834140161",
    "text" : "\"Just two Timber Wolves cuddling.\" http:\/\/t.co\/i2kHBUnn #Picture #Cute",
    "id" : 227139668834140161,
    "created_at" : "2012-07-22 20:34:51 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 227140119239487488,
  "created_at" : "2012-07-22 20:36:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227132623208730624",
  "text" : "blogging folks.. what comment system do you use?",
  "id" : 227132623208730624,
  "created_at" : "2012-07-22 20:06:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "indices" : [ 3, 19 ],
      "id_str" : "29251361",
      "id" : 29251361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SHERLOCK",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227131475655524352",
  "text" : "RT @WorldOfJoeRiggs: It's #SHERLOCK time! The Game Is Afoot! The Clue has been posted to FB with instructions on submitting  your answer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SHERLOCK",
        "indices" : [ 5, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/1q2o7CIn",
        "expanded_url" : "http:\/\/on.fb.me\/MwLU3w",
        "display_url" : "on.fb.me\/MwLU3w"
      } ]
    },
    "geo" : { },
    "id_str" : "227110702081536001",
    "text" : "It's #SHERLOCK time! The Game Is Afoot! The Clue has been posted to FB with instructions on submitting  your answers: http:\/\/t.co\/1q2o7CIn",
    "id" : 227110702081536001,
    "created_at" : "2012-07-22 18:39:45 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 227131475655524352,
  "created_at" : "2012-07-22 20:02:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227130249643704320",
  "text" : "RT @CaroleODell: Can't teach people who are unwilling to learn.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227128124427624448",
    "text" : "Can't teach people who are unwilling to learn.",
    "id" : 227128124427624448,
    "created_at" : "2012-07-22 19:48:59 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 227130249643704320,
  "created_at" : "2012-07-22 19:57:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "westpalmbeach",
      "indices" : [ 17, 31 ]
    }, {
      "text" : "bridge",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "night",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/yl9tnHij",
      "expanded_url" : "http:\/\/instagr.am\/p\/NZUFGtuuBN\/",
      "display_url" : "instagr.am\/p\/NZUFGtuuBN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "227130172858572800",
  "text" : "RT @CaroleODell: #westpalmbeach #bridge #night http:\/\/t.co\/yl9tnHij",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "westpalmbeach",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "bridge",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "night",
        "indices" : [ 23, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/yl9tnHij",
        "expanded_url" : "http:\/\/instagr.am\/p\/NZUFGtuuBN\/",
        "display_url" : "instagr.am\/p\/NZUFGtuuBN\/"
      } ]
    },
    "geo" : { },
    "id_str" : "227128903792226304",
    "text" : "#westpalmbeach #bridge #night http:\/\/t.co\/yl9tnHij",
    "id" : 227128903792226304,
    "created_at" : "2012-07-22 19:52:05 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 227130172858572800,
  "created_at" : "2012-07-22 19:57:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227129744997634048",
  "text" : "RT @UnseeingEyes: I said it as a joke once, but not really a joke... ...about combating war by \"bombing\" countries with \"food, beverages ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227127806151237632",
    "text" : "I said it as a joke once, but not really a joke... ...about combating war by \"bombing\" countries with \"food, beverages, &amp; clothing.\"",
    "id" : 227127806151237632,
    "created_at" : "2012-07-22 19:47:43 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 227129744997634048,
  "created_at" : "2012-07-22 19:55:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227111825534246912",
  "geo" : { },
  "id_str" : "227112277940252672",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver yup! heehee",
  "id" : 227112277940252672,
  "in_reply_to_status_id" : 227111825534246912,
  "created_at" : "2012-07-22 18:46:01 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 4, 19 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227107220498817025",
  "geo" : { },
  "id_str" : "227109284129943552",
  "in_reply_to_user_id" : 96152195,
  "text" : "wow @luminanceriver me, too! not too sure how I feel about it yet..lol",
  "id" : 227109284129943552,
  "in_reply_to_status_id" : 227107220498817025,
  "created_at" : "2012-07-22 18:34:07 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "indices" : [ 3, 13 ],
      "id_str" : "21636840",
      "id" : 21636840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227104765774016512",
  "text" : "RT @Halfbrick: Want to win 25,000 Starfruit in Fruit Ninja? Simply tell us which of Sensei's Fruit Facts is most interesting and the pri ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227100984239849472",
    "text" : "Want to win 25,000 Starfruit in Fruit Ninja? Simply tell us which of Sensei's Fruit Facts is most interesting and the prize could be yours!",
    "id" : 227100984239849472,
    "created_at" : "2012-07-22 18:01:08 +0000",
    "user" : {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "protected" : false,
      "id_str" : "21636840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780664592758247424\/SkdeHP5x_normal.jpg",
      "id" : 21636840,
      "verified" : true
    }
  },
  "id" : 227104765774016512,
  "created_at" : "2012-07-22 18:16:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Halfbrick",
      "screen_name" : "Halfbrick",
      "indices" : [ 0, 10 ],
      "id_str" : "21636840",
      "id" : 21636840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227100984239849472",
  "geo" : { },
  "id_str" : "227104740213923840",
  "in_reply_to_user_id" : 21636840,
  "text" : "@Halfbrick \"You can rub the inside of a banana skin on mosquito bites to stop the itchiness\" I want to try this one..lol",
  "id" : 227104740213923840,
  "in_reply_to_status_id" : 227100984239849472,
  "created_at" : "2012-07-22 18:16:04 +0000",
  "in_reply_to_screen_name" : "Halfbrick",
  "in_reply_to_user_id_str" : "21636840",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/DLzlhbez",
      "expanded_url" : "http:\/\/lnkd.in\/yB4nBV",
      "display_url" : "lnkd.in\/yB4nBV"
    } ]
  },
  "geo" : { },
  "id_str" : "227101256760578049",
  "text" : "RT @Alaskachic907: Nancy Stewart Photography: Alaska Wildlife Baby Moose http:\/\/t.co\/DLzlhbez",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/DLzlhbez",
        "expanded_url" : "http:\/\/lnkd.in\/yB4nBV",
        "display_url" : "lnkd.in\/yB4nBV"
      } ]
    },
    "geo" : { },
    "id_str" : "227100334735122433",
    "text" : "Nancy Stewart Photography: Alaska Wildlife Baby Moose http:\/\/t.co\/DLzlhbez",
    "id" : 227100334735122433,
    "created_at" : "2012-07-22 17:58:33 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 227101256760578049,
  "created_at" : "2012-07-22 18:02:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227098638336290816",
  "geo" : { },
  "id_str" : "227100856170979328",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind I like the face on the movie screen",
  "id" : 227100856170979328,
  "in_reply_to_status_id" : 227098638336290816,
  "created_at" : "2012-07-22 18:00:38 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 3, 12 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/eDeznL8e",
      "expanded_url" : "http:\/\/www.thislife.com",
      "display_url" : "thislife.com"
    } ]
  },
  "geo" : { },
  "id_str" : "227096953962508288",
  "text" : "RT @thislife: Want an easy way to protect and organize all your photos and videos? Try us free! http:\/\/t.co\/eDeznL8e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/eDeznL8e",
        "expanded_url" : "http:\/\/www.thislife.com",
        "display_url" : "thislife.com"
      } ]
    },
    "geo" : { },
    "id_str" : "227096158508556288",
    "text" : "Want an easy way to protect and organize all your photos and videos? Try us free! http:\/\/t.co\/eDeznL8e",
    "id" : 227096158508556288,
    "created_at" : "2012-07-22 17:41:58 +0000",
    "user" : {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "protected" : false,
      "id_str" : "15474394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488837647981240321\/X8WiCtaq_normal.jpeg",
      "id" : 15474394,
      "verified" : false
    }
  },
  "id" : 227096953962508288,
  "created_at" : "2012-07-22 17:45:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Maddy",
      "screen_name" : "FabulousFlea",
      "indices" : [ 51, 64 ],
      "id_str" : "2993138860",
      "id" : 2993138860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227095740223193089",
  "text" : "RT @ZachsMind: there's many more choices than that @FabulousFlea it's not all black and white there's well over fifty shades of grey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maddy",
        "screen_name" : "FabulousFlea",
        "indices" : [ 36, 49 ],
        "id_str" : "2993138860",
        "id" : 2993138860
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227095284386246656",
    "text" : "there's many more choices than that @FabulousFlea it's not all black and white there's well over fifty shades of grey",
    "id" : 227095284386246656,
    "created_at" : "2012-07-22 17:38:29 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 227095740223193089,
  "created_at" : "2012-07-22 17:40:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "21c | POLITICS",
      "screen_name" : "Political_Bill",
      "indices" : [ 3, 18 ],
      "id_str" : "16790797",
      "id" : 16790797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227095445816610816",
  "text" : "RT @Political_Bill: FAITH is your personal journey &amp; should be respected. But we GOVERN for Society, not a Deity. Beliefs are person ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 141, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227078897093726208",
    "text" : "FAITH is your personal journey &amp; should be respected. But we GOVERN for Society, not a Deity. Beliefs are personal, Facts are universal. #p2",
    "id" : 227078897093726208,
    "created_at" : "2012-07-22 16:33:22 +0000",
    "user" : {
      "name" : "21c | POLITICS",
      "screen_name" : "Political_Bill",
      "protected" : false,
      "id_str" : "16790797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3537817815\/98cdb28dca8955c1dd503d9d16203e43_normal.jpeg",
      "id" : 16790797,
      "verified" : false
    }
  },
  "id" : 227095445816610816,
  "created_at" : "2012-07-22 17:39:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227095428192161792",
  "text" : "RT @ZachsMind: i don't believe this. i observe this. it's the only reasonable explanation given the evidence at hand.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227093622619783168",
    "text" : "i don't believe this. i observe this. it's the only reasonable explanation given the evidence at hand.",
    "id" : 227093622619783168,
    "created_at" : "2012-07-22 17:31:53 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 227095428192161792,
  "created_at" : "2012-07-22 17:39:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Ciel Bleu Media",
      "screen_name" : "CielBleuMedia",
      "indices" : [ 37, 51 ],
      "id_str" : "336837648",
      "id" : 336837648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/DhUqkLTX",
      "expanded_url" : "http:\/\/goo.gl\/fb\/8yYig",
      "display_url" : "goo.gl\/fb\/8yYig"
    } ]
  },
  "geo" : { },
  "id_str" : "227095289230675968",
  "text" : "RT @KerriFar: Absolutely Amazing! RT @cielbleumedia: A Mother\u2019s Love by Jacky Parker http:\/\/t.co\/DhUqkLTX  ~ New Today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ciel Bleu Media",
        "screen_name" : "CielBleuMedia",
        "indices" : [ 23, 37 ],
        "id_str" : "336837648",
        "id" : 336837648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/DhUqkLTX",
        "expanded_url" : "http:\/\/goo.gl\/fb\/8yYig",
        "display_url" : "goo.gl\/fb\/8yYig"
      } ]
    },
    "geo" : { },
    "id_str" : "227094423492775936",
    "text" : "Absolutely Amazing! RT @cielbleumedia: A Mother\u2019s Love by Jacky Parker http:\/\/t.co\/DhUqkLTX  ~ New Today",
    "id" : 227094423492775936,
    "created_at" : "2012-07-22 17:35:04 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 227095289230675968,
  "created_at" : "2012-07-22 17:38:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 0, 11 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227090203255382016",
  "geo" : { },
  "id_str" : "227090850289688577",
  "in_reply_to_user_id" : 2772041,
  "text" : "@adampknave : )",
  "id" : 227090850289688577,
  "in_reply_to_status_id" : 227090203255382016,
  "created_at" : "2012-07-22 17:20:52 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "indices" : [ 3, 16 ],
      "id_str" : "88325042",
      "id" : 88325042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227090605669494784",
  "text" : "RT @MurderNovels: \"Classmate Murders \" is free for everyone, not just Prime Members, get your free copy today. Find it at http:\/\/t.co\/AT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/AT1QT6bw",
        "expanded_url" : "http:\/\/amzn.to\/ecoB2M",
        "display_url" : "amzn.to\/ecoB2M"
      } ]
    },
    "geo" : { },
    "id_str" : "227090006169251840",
    "text" : "\"Classmate Murders \" is free for everyone, not just Prime Members, get your free copy today. Find it at http:\/\/t.co\/AT1QT6bw",
    "id" : 227090006169251840,
    "created_at" : "2012-07-22 17:17:31 +0000",
    "user" : {
      "name" : "Bob Moats",
      "screen_name" : "MurderNovels",
      "protected" : false,
      "id_str" : "88325042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2060694033\/BloodSplat_normal.jpg",
      "id" : 88325042,
      "verified" : false
    }
  },
  "id" : 227090605669494784,
  "created_at" : "2012-07-22 17:19:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Montano",
      "screen_name" : "Daezarkian",
      "indices" : [ 0, 11 ],
      "id_str" : "31248960",
      "id" : 31248960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227089681983094784",
  "geo" : { },
  "id_str" : "227090176248266752",
  "in_reply_to_user_id" : 31248960,
  "text" : "@Daezarkian my DD does this all the time..lol",
  "id" : 227090176248266752,
  "in_reply_to_status_id" : 227089681983094784,
  "created_at" : "2012-07-22 17:18:11 +0000",
  "in_reply_to_screen_name" : "Daezarkian",
  "in_reply_to_user_id_str" : "31248960",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227076892593901568",
  "text" : "had a nightmare.. I was carrying my niece's infant. was afraid I would drop her. then I got separated from group and got lost.",
  "id" : 227076892593901568,
  "created_at" : "2012-07-22 16:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 3, 12 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    }, {
      "name" : "Target",
      "screen_name" : "Target",
      "indices" : [ 87, 94 ],
      "id_str" : "89084561",
      "id" : 89084561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227074442243743745",
  "text" : "RT @iLivrada: Have you spotted our e-book cards on the electronics aisle of YOUR local @Target? We're anxious to get a look at them acro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Target",
        "screen_name" : "Target",
        "indices" : [ 73, 80 ],
        "id_str" : "89084561",
        "id" : 89084561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227074043726155776",
    "text" : "Have you spotted our e-book cards on the electronics aisle of YOUR local @Target? We're anxious to get a look at them across the country!",
    "id" : 227074043726155776,
    "created_at" : "2012-07-22 16:14:05 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 227074442243743745,
  "created_at" : "2012-07-22 16:15:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 86, 97 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/hAth2xuP",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/07\/22\/jack-daniels-has-a-very-nice.html",
      "display_url" : "boingboing.net\/2012\/07\/22\/jac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227072135326232576",
  "text" : "Jack Daniel's has a very nice trademark lawyer - Boing Boing http:\/\/t.co\/hAth2xuP via @BoingBoing",
  "id" : 227072135326232576,
  "created_at" : "2012-07-22 16:06:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227070423014195201",
  "geo" : { },
  "id_str" : "227071803254771713",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses exactly. I can be more myself here. lol",
  "id" : 227071803254771713,
  "in_reply_to_status_id" : 227070423014195201,
  "created_at" : "2012-07-22 16:05:11 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227067887611940865",
  "geo" : { },
  "id_str" : "227071217209851904",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses heehee \"peace\" was your word... coincidence? (inserttwilightzonemusichere) lol",
  "id" : 227071217209851904,
  "in_reply_to_status_id" : 227067887611940865,
  "created_at" : "2012-07-22 16:02:51 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 2, 17 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227066507610431488",
  "geo" : { },
  "id_str" : "227069815074983937",
  "in_reply_to_user_id" : 63804234,
  "text" : ". @PeggySueCusses twitter has my ppl on it.. I love it. It's like High School but I belong..LOL",
  "id" : 227069815074983937,
  "in_reply_to_status_id" : 227066507610431488,
  "created_at" : "2012-07-22 15:57:17 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227067366641639424",
  "geo" : { },
  "id_str" : "227069380310228993",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOL.. my lines are all over the place.. very messy looking. Love how yours are so neat. : )",
  "id" : 227069380310228993,
  "in_reply_to_status_id" : 227067366641639424,
  "created_at" : "2012-07-22 15:55:33 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227061464337375232",
  "geo" : { },
  "id_str" : "227062817243664384",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses most of my FB ppl are ppl I met on forums. and family members. Twitter is my real playground..lol",
  "id" : 227062817243664384,
  "in_reply_to_status_id" : 227061464337375232,
  "created_at" : "2012-07-22 15:29:28 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 2, 17 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227057660279812096",
  "geo" : { },
  "id_str" : "227061916831449089",
  "in_reply_to_user_id" : 63804234,
  "text" : ". @PeggySueCusses excluding me... LOL",
  "id" : 227061916831449089,
  "in_reply_to_status_id" : 227057660279812096,
  "created_at" : "2012-07-22 15:25:54 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226876093578235904",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses I will continue DS game tomorrow.. Going to bed : )",
  "id" : 226876093578235904,
  "created_at" : "2012-07-22 03:07:30 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226840742922956800",
  "text" : "RT @Matth3ous: I wish there was a Netflix -type service for eBooks. :(",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226840454942052352",
    "text" : "I wish there was a Netflix -type service for eBooks. :(",
    "id" : 226840454942052352,
    "created_at" : "2012-07-22 00:45:53 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 226840742922956800,
  "created_at" : "2012-07-22 00:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226832495021281282",
  "geo" : { },
  "id_str" : "226833314621833217",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind thanks for explaining about it : )",
  "id" : 226833314621833217,
  "in_reply_to_status_id" : 226832495021281282,
  "created_at" : "2012-07-22 00:17:31 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226832235087675392",
  "geo" : { },
  "id_str" : "226832983619956736",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind just watched the one you posted.. so, basically walk too fast and light for the heat to reach.. hmmm..",
  "id" : 226832983619956736,
  "in_reply_to_status_id" : 226832235087675392,
  "created_at" : "2012-07-22 00:16:12 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226829187741261824",
  "geo" : { },
  "id_str" : "226830456451104768",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind how does it work?",
  "id" : 226830456451104768,
  "in_reply_to_status_id" : 226829187741261824,
  "created_at" : "2012-07-22 00:06:09 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226829979139325953",
  "text" : "oh and there was a mouse in the grill..lol. Hubby got him out safely. : )",
  "id" : 226829979139325953,
  "created_at" : "2012-07-22 00:04:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK Rising",
      "screen_name" : "DKRising",
      "indices" : [ 3, 12 ],
      "id_str" : "716678263855267840",
      "id" : 716678263855267840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226829392603672576",
  "text" : "RT @DKRising: All these social networks. Just a variety of venues for people to ignore me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226828470393634816",
    "text" : "All these social networks. Just a variety of venues for people to ignore me.",
    "id" : 226828470393634816,
    "created_at" : "2012-07-21 23:58:16 +0000",
    "user" : {
      "name" : "DK",
      "screen_name" : "horseandahalf",
      "protected" : false,
      "id_str" : "28032888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2250219073\/3622258089_0d9032f127_b_normal.jpg",
      "id" : 28032888,
      "verified" : false
    }
  },
  "id" : 226829392603672576,
  "created_at" : "2012-07-22 00:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226825144574828544",
  "text" : "miss me?? been playing on my sites today.. trying to decide on commenting system...",
  "id" : 226825144574828544,
  "created_at" : "2012-07-21 23:45:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 6, 16 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getnorespect",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226491055569256448",
  "geo" : { },
  "id_str" : "226493361534676992",
  "in_reply_to_user_id" : 16181537,
  "text" : "bah.. @ZachsMind join the club... #getnorespect",
  "id" : 226493361534676992,
  "in_reply_to_status_id" : 226491055569256448,
  "created_at" : "2012-07-21 01:46:40 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "trippfuller",
      "screen_name" : "trippfuller",
      "indices" : [ 3, 15 ],
      "id_str" : "17016789",
      "id" : 17016789
    }, {
      "name" : "Richard D. Wolff",
      "screen_name" : "profwolff",
      "indices" : [ 18, 28 ],
      "id_str" : "78768913",
      "id" : 78768913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226464540915806209",
  "text" : "RT @trippfuller: \u201C@profwolff: The House just voted $ 606 billion for Defense\/wars (= $12 billion per week) and cut food stamps by $5 bil ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard D. Wolff",
        "screen_name" : "profwolff",
        "indices" : [ 1, 11 ],
        "id_str" : "78768913",
        "id" : 78768913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226462002644676608",
    "text" : "\u201C@profwolff: The House just voted $ 606 billion for Defense\/wars (= $12 billion per week) and cut food stamps by $5 billion. Says it all.\u201D",
    "id" : 226462002644676608,
    "created_at" : "2012-07-20 23:42:03 +0000",
    "user" : {
      "name" : "trippfuller",
      "screen_name" : "trippfuller",
      "protected" : false,
      "id_str" : "17016789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792413548374728705\/ogjYbAuZ_normal.jpg",
      "id" : 17016789,
      "verified" : false
    }
  },
  "id" : 226464540915806209,
  "created_at" : "2012-07-20 23:52:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226444430515781632",
  "geo" : { },
  "id_str" : "226446401645735936",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 Damn... : (",
  "id" : 226446401645735936,
  "in_reply_to_status_id" : 226444430515781632,
  "created_at" : "2012-07-20 22:40:03 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226408373254488065",
  "geo" : { },
  "id_str" : "226409268146999297",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings ahh.. you got it. (the issue isn't gun control... it's the whole way society works...)",
  "id" : 226409268146999297,
  "in_reply_to_status_id" : 226408373254488065,
  "created_at" : "2012-07-20 20:12:30 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FantasiCakes",
      "screen_name" : "FantasiCakes",
      "indices" : [ 46, 59 ],
      "id_str" : "453168805",
      "id" : 453168805
    }, {
      "name" : "JANAE CHANG",
      "screen_name" : "pinkdandy",
      "indices" : [ 65, 75 ],
      "id_str" : "24666070",
      "id" : 24666070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Win",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/1l2PiDD6",
      "expanded_url" : "http:\/\/tinyurl.com\/bm2mexq",
      "display_url" : "tinyurl.com\/bm2mexq"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/gGYEVjlB",
      "expanded_url" : "http:\/\/www.pinkdandychatter.com\/2012\/07\/review-giveaway-cinnamon-coffee-cake-by-fantasicakes.html",
      "display_url" : "pinkdandychatter.com\/2012\/07\/review\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "226403423476674560",
  "text" : "#Win an 8\" Cake of Your Choice (3 winners) by @fantasicakes from @pinkdandy #giveaway http:\/\/t.co\/1l2PiDD6 http:\/\/t.co\/gGYEVjlB",
  "id" : 226403423476674560,
  "created_at" : "2012-07-20 19:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 94, 103 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226399088361488384",
  "geo" : { },
  "id_str" : "226400065697243137",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields btw: did you see about the new ebook gift cards coming out in Target? check out @iLivrada .. nice idea!",
  "id" : 226400065697243137,
  "in_reply_to_status_id" : 226399088361488384,
  "created_at" : "2012-07-20 19:35:56 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazon",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226397817663537152",
  "geo" : { },
  "id_str" : "226398882198867968",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields i also don't like how my Kindle books show.. very difficult to search through. they need to hire good database ppl. #amazon",
  "id" : 226398882198867968,
  "in_reply_to_status_id" : 226397817663537152,
  "created_at" : "2012-07-20 19:31:14 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226396996209090562",
  "geo" : { },
  "id_str" : "226397402872020992",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields exactly!!",
  "id" : 226397402872020992,
  "in_reply_to_status_id" : 226396996209090562,
  "created_at" : "2012-07-20 19:25:21 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226397250958553088",
  "text" : "RT @adamrshields: Realized today that it is not possible to search in your own Amazon wish list.  Seems like a pretty basic feature. #My ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyWishListIsTooBig",
        "indices" : [ 115, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226396996209090562",
    "text" : "Realized today that it is not possible to search in your own Amazon wish list.  Seems like a pretty basic feature. #MyWishListIsTooBig",
    "id" : 226396996209090562,
    "created_at" : "2012-07-20 19:23:44 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 226397250958553088,
  "created_at" : "2012-07-20 19:24:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED",
      "screen_name" : "Laughbook",
      "indices" : [ 3, 13 ],
      "id_str" : "215537170",
      "id" : 215537170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226383015025205249",
  "text" : "RT @Laughbook: Twitter is like a fridge. If you're bored you keep opening &amp; closing it every few minutes to see if there's anything  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226380976698318848",
    "text" : "Twitter is like a fridge. If you're bored you keep opening &amp; closing it every few minutes to see if there's anything good in it.",
    "id" : 226380976698318848,
    "created_at" : "2012-07-20 18:20:05 +0000",
    "user" : {
      "name" : "TED",
      "screen_name" : "Laughbook",
      "protected" : false,
      "id_str" : "215537170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690699317825273856\/p3ZMgwNO_normal.jpg",
      "id" : 215537170,
      "verified" : false
    }
  },
  "id" : 226383015025205249,
  "created_at" : "2012-07-20 18:28:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/xDnbuehV",
      "expanded_url" : "http:\/\/bit.ly\/yF9oZL",
      "display_url" : "bit.ly\/yF9oZL"
    } ]
  },
  "geo" : { },
  "id_str" : "226376701771386880",
  "text" : "RT @Lesism: \u201CTime\u201D - Does it even exist? http:\/\/t.co\/xDnbuehV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/xDnbuehV",
        "expanded_url" : "http:\/\/bit.ly\/yF9oZL",
        "display_url" : "bit.ly\/yF9oZL"
      } ]
    },
    "geo" : { },
    "id_str" : "226376213621510145",
    "text" : "\u201CTime\u201D - Does it even exist? http:\/\/t.co\/xDnbuehV",
    "id" : 226376213621510145,
    "created_at" : "2012-07-20 18:01:09 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 226376701771386880,
  "created_at" : "2012-07-20 18:03:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226350490798129152",
  "text" : "RT @PeggySueCusses: Directv got the missing channels turned back on today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226349205202026498",
    "text" : "Directv got the missing channels turned back on today.",
    "id" : 226349205202026498,
    "created_at" : "2012-07-20 16:13:50 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 226350490798129152,
  "created_at" : "2012-07-20 16:18:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 3, 12 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/dk8JljAX",
      "expanded_url" : "http:\/\/ow.ly\/cnFKK",
      "display_url" : "ow.ly\/cnFKK"
    } ]
  },
  "geo" : { },
  "id_str" : "226326615821524993",
  "text" : "RT @iLivrada: We'd love to know: Which book would you read next from this group?\n  http:\/\/t.co\/dk8JljAX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/dk8JljAX",
        "expanded_url" : "http:\/\/ow.ly\/cnFKK",
        "display_url" : "ow.ly\/cnFKK"
      } ]
    },
    "geo" : { },
    "id_str" : "226325820220776448",
    "text" : "We'd love to know: Which book would you read next from this group?\n  http:\/\/t.co\/dk8JljAX",
    "id" : 226325820220776448,
    "created_at" : "2012-07-20 14:40:55 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 226326615821524993,
  "created_at" : "2012-07-20 14:44:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/qXtZ8q6l",
      "expanded_url" : "http:\/\/lesism.blogspot.com\/2012\/06\/myths-of-ego.html?spref=tw",
      "display_url" : "lesism.blogspot.com\/2012\/06\/myths-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "226323446374735872",
  "text" : "Lesism - by Les Floyd: The Myths of Ego http:\/\/t.co\/qXtZ8q6l",
  "id" : 226323446374735872,
  "created_at" : "2012-07-20 14:31:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/fcOFMjhZ",
      "expanded_url" : "http:\/\/bit.ly\/phbK3K",
      "display_url" : "bit.ly\/phbK3K"
    } ]
  },
  "geo" : { },
  "id_str" : "226320776381476865",
  "text" : "RT @Lesism: \u201CAwakening\u201D ~ The story of my spiritual awakening, in February 2010: http:\/\/t.co\/fcOFMjhZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/fcOFMjhZ",
        "expanded_url" : "http:\/\/bit.ly\/phbK3K",
        "display_url" : "bit.ly\/phbK3K"
      } ]
    },
    "geo" : { },
    "id_str" : "226304314690400256",
    "text" : "\u201CAwakening\u201D ~ The story of my spiritual awakening, in February 2010: http:\/\/t.co\/fcOFMjhZ",
    "id" : 226304314690400256,
    "created_at" : "2012-07-20 13:15:27 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 226320776381476865,
  "created_at" : "2012-07-20 14:20:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliott Teters",
      "screen_name" : "Elliott_Teters",
      "indices" : [ 3, 18 ],
      "id_str" : "46923217",
      "id" : 46923217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226050918079160321",
  "text" : "RT @Elliott_Teters: I am so grateful for each of you who follow here. Every one of you have such value to me. Thank you for being here.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226050443313303552",
    "text" : "I am so grateful for each of you who follow here. Every one of you have such value to me. Thank you for being here.",
    "id" : 226050443313303552,
    "created_at" : "2012-07-19 20:26:40 +0000",
    "user" : {
      "name" : "Elliott Teters",
      "screen_name" : "Elliott_Teters",
      "protected" : false,
      "id_str" : "46923217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774089006678093825\/yzGaGcF5_normal.jpg",
      "id" : 46923217,
      "verified" : false
    }
  },
  "id" : 226050918079160321,
  "created_at" : "2012-07-19 20:28:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226048097002848257",
  "text" : "RT @By_Bashar: if you understand everything is happening as it needs to, Then you do not have to fear losing anything ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226045363335884800",
    "text" : "if you understand everything is happening as it needs to, Then you do not have to fear losing anything ~ bashar",
    "id" : 226045363335884800,
    "created_at" : "2012-07-19 20:06:28 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 226048097002848257,
  "created_at" : "2012-07-19 20:17:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 88, 94 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/owQN5VPB",
      "expanded_url" : "http:\/\/bit.ly\/OeSk77",
      "display_url" : "bit.ly\/OeSk77"
    } ]
  },
  "geo" : { },
  "id_str" : "226035055296929792",
  "text" : "RT @DwayneReaves: Dolphins appear to do nonlinear mathematics: http:\/\/t.co\/owQN5VPB via @msnbc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 70, 76 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/owQN5VPB",
        "expanded_url" : "http:\/\/bit.ly\/OeSk77",
        "display_url" : "bit.ly\/OeSk77"
      } ]
    },
    "geo" : { },
    "id_str" : "225460096359075840",
    "text" : "Dolphins appear to do nonlinear mathematics: http:\/\/t.co\/owQN5VPB via @msnbc",
    "id" : 225460096359075840,
    "created_at" : "2012-07-18 05:20:50 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 226035055296929792,
  "created_at" : "2012-07-19 19:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keek",
      "screen_name" : "Keek",
      "indices" : [ 3, 8 ],
      "id_str" : "313586546",
      "id" : 313586546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/4fygaF0U",
      "expanded_url" : "http:\/\/www.keek.com\/!h2Mmaab",
      "display_url" : "keek.com\/!h2Mmaab"
    } ]
  },
  "geo" : { },
  "id_str" : "226022188141133824",
  "text" : "RT @Keek: This is crazy - &gt; Death circle http:\/\/t.co\/4fygaF0U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/4fygaF0U",
        "expanded_url" : "http:\/\/www.keek.com\/!h2Mmaab",
        "display_url" : "keek.com\/!h2Mmaab"
      } ]
    },
    "geo" : { },
    "id_str" : "226020667018080257",
    "text" : "This is crazy - &gt; Death circle http:\/\/t.co\/4fygaF0U",
    "id" : 226020667018080257,
    "created_at" : "2012-07-19 18:28:20 +0000",
    "user" : {
      "name" : "Keek",
      "screen_name" : "Keek",
      "protected" : false,
      "id_str" : "313586546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673976180123418625\/h5lXockp_normal.png",
      "id" : 313586546,
      "verified" : true
    }
  },
  "id" : 226022188141133824,
  "created_at" : "2012-07-19 18:34:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/KIslIl6K",
      "expanded_url" : "http:\/\/via.me\/-37a1ou6",
      "display_url" : "via.me\/-37a1ou6"
    } ]
  },
  "geo" : { },
  "id_str" : "226018011876835328",
  "text" : "My librarian look.. Lol http:\/\/t.co\/KIslIl6K",
  "id" : 226018011876835328,
  "created_at" : "2012-07-19 18:17:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "indices" : [ 3, 17 ],
      "id_str" : "30038832",
      "id" : 30038832
    }, {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 22, 35 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225994765215346688",
  "text" : "RT @LilithsPriest: RT @damienechols \"I walked off of Death Row exactly 11 months ago today.\" &amp; a whole bunch of people cheered...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Damien Echols",
        "screen_name" : "damienechols",
        "indices" : [ 3, 16 ],
        "id_str" : "358311362",
        "id" : 358311362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225993377978658818",
    "text" : "RT @damienechols \"I walked off of Death Row exactly 11 months ago today.\" &amp; a whole bunch of people cheered...",
    "id" : 225993377978658818,
    "created_at" : "2012-07-19 16:39:54 +0000",
    "user" : {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "protected" : false,
      "id_str" : "30038832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684842001372594176\/nMbJUZ5Q_normal.jpg",
      "id" : 30038832,
      "verified" : false
    }
  },
  "id" : 225994765215346688,
  "created_at" : "2012-07-19 16:45:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MySocialCloud",
      "screen_name" : "My_SocialCloud",
      "indices" : [ 3, 18 ],
      "id_str" : "148150032",
      "id" : 148150032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 49, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225944637704118273",
  "text" : "RT @My_SocialCloud: List ideas: create a list of #books you'd like to read, or if they are pdfs, save them directly to your list! http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 29, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/wh2ZUQkW",
        "expanded_url" : "http:\/\/bit.ly\/Lt6cqx",
        "display_url" : "bit.ly\/Lt6cqx"
      } ]
    },
    "geo" : { },
    "id_str" : "225939853274120193",
    "text" : "List ideas: create a list of #books you'd like to read, or if they are pdfs, save them directly to your list! http:\/\/t.co\/wh2ZUQkW",
    "id" : 225939853274120193,
    "created_at" : "2012-07-19 13:07:13 +0000",
    "user" : {
      "name" : "MySocialCloud",
      "screen_name" : "My_SocialCloud",
      "protected" : false,
      "id_str" : "148150032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3372558360\/1624a4e1209e06345beb43e83f68139d_normal.png",
      "id" : 148150032,
      "verified" : false
    }
  },
  "id" : 225944637704118273,
  "created_at" : "2012-07-19 13:26:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 3, 18 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "let",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/UtAFdJXl",
      "expanded_url" : "http:\/\/instagr.am\/p\/LtkJopKfyD\/",
      "display_url" : "instagr.am\/p\/LtkJopKfyD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "225940814398906370",
  "text" : "RT @JulianneGarska: Here's my Instagram photo of rocks, it currently has 6 likes.  RT? #let'sgetitto10+!Woot! http:\/\/t.co\/UtAFdJXl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "let",
        "indices" : [ 67, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/UtAFdJXl",
        "expanded_url" : "http:\/\/instagr.am\/p\/LtkJopKfyD\/",
        "display_url" : "instagr.am\/p\/LtkJopKfyD\/"
      } ]
    },
    "geo" : { },
    "id_str" : "225924473369534464",
    "text" : "Here's my Instagram photo of rocks, it currently has 6 likes.  RT? #let'sgetitto10+!Woot! http:\/\/t.co\/UtAFdJXl",
    "id" : 225924473369534464,
    "created_at" : "2012-07-19 12:06:06 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 225940814398906370,
  "created_at" : "2012-07-19 13:11:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225937074048614400",
  "text" : "RT @By_Bashar: whenever you hear something, . What you hear is YOUR interpretation of a vibration",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225932076044660737",
    "text" : "whenever you hear something, . What you hear is YOUR interpretation of a vibration",
    "id" : 225932076044660737,
    "created_at" : "2012-07-19 12:36:19 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 225937074048614400,
  "created_at" : "2012-07-19 12:56:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E_is for EverLong",
      "screen_name" : "E_FillingaHole",
      "indices" : [ 0, 15 ],
      "id_str" : "371326384",
      "id" : 371326384
    }, {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 74, 86 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Uncle Bubba",
      "screen_name" : "EricAlder",
      "indices" : [ 104, 114 ],
      "id_str" : "3151649740",
      "id" : 3151649740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225672134490476544",
  "geo" : { },
  "id_str" : "225706661296353281",
  "in_reply_to_user_id" : 371326384,
  "text" : "@E_FillingaHole I didn't know him long but he was a blessing to the world @Silvercrone @fracturedphrase @EricAlder @SamsaricWarrior",
  "id" : 225706661296353281,
  "in_reply_to_status_id" : 225672134490476544,
  "created_at" : "2012-07-18 21:40:36 +0000",
  "in_reply_to_screen_name" : "E_FillingaHole",
  "in_reply_to_user_id_str" : "371326384",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 79, 88 ],
      "id_str" : "352053266",
      "id" : 352053266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinkagain",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 136 ],
      "url" : "https:\/\/t.co\/5JtamULN",
      "expanded_url" : "https:\/\/www.coursera.org\/course\/thinkagain",
      "display_url" : "coursera.org\/course\/thinkag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225672280531927041",
  "text" : "I just signed up for Think Again: How to Reason and Argue #thinkagain - a free @coursera online class. Join me at  https:\/\/t.co\/5JtamULN",
  "id" : 225672280531927041,
  "created_at" : "2012-07-18 19:23:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED News",
      "screen_name" : "TEDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "36843988",
      "id" : 36843988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225669839904190465",
  "text" : "RT @TEDNews: A way to take Princeton, Stanford, Duke, CalTech courses for free, with no worries of being thrown out by security http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TED",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/qA252ki5",
        "expanded_url" : "http:\/\/blog.ted.com\/2012\/07\/18\/completely-free-online-classes-coursera-org-now-offering-courses-from-14-top-colleges\/",
        "display_url" : "blog.ted.com\/2012\/07\/18\/com\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "225667457170432001",
    "text" : "A way to take Princeton, Stanford, Duke, CalTech courses for free, with no worries of being thrown out by security http:\/\/t.co\/qA252ki5 #TED",
    "id" : 225667457170432001,
    "created_at" : "2012-07-18 19:04:49 +0000",
    "user" : {
      "name" : "TED News",
      "screen_name" : "TEDNews",
      "protected" : false,
      "id_str" : "36843988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3279174286\/5de7d7794205fc0ba09bdf54e6c16707_normal.png",
      "id" : 36843988,
      "verified" : true
    }
  },
  "id" : 225669839904190465,
  "created_at" : "2012-07-18 19:14:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225657461741334528",
  "text" : "RT @BlackenedTrail: There is no substitute for someone who gets you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210054066242465793",
    "text" : "There is no substitute for someone who gets you.",
    "id" : 210054066242465793,
    "created_at" : "2012-06-05 17:02:46 +0000",
    "user" : {
      "name" : "The Planet",
      "screen_name" : "ShipInTheKnight",
      "protected" : false,
      "id_str" : "530887571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743604904539807748\/oi9L1ngP_normal.jpg",
      "id" : 530887571,
      "verified" : false
    }
  },
  "id" : 225657461741334528,
  "created_at" : "2012-07-18 18:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 3, 12 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    }, {
      "name" : "Target",
      "screen_name" : "Target",
      "indices" : [ 43, 50 ],
      "id_str" : "89084561",
      "id" : 89084561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/P5i51snu",
      "expanded_url" : "http:\/\/ow.ly\/ciLSz",
      "display_url" : "ow.ly\/ciLSz"
    } ]
  },
  "geo" : { },
  "id_str" : "225645997588639744",
  "text" : "RT @iLivrada: Look what we just spotted at @Target! http:\/\/t.co\/P5i51snu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Target",
        "screen_name" : "Target",
        "indices" : [ 29, 36 ],
        "id_str" : "89084561",
        "id" : 89084561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/P5i51snu",
        "expanded_url" : "http:\/\/ow.ly\/ciLSz",
        "display_url" : "ow.ly\/ciLSz"
      } ]
    },
    "geo" : { },
    "id_str" : "225284553646940162",
    "text" : "Look what we just spotted at @Target! http:\/\/t.co\/P5i51snu",
    "id" : 225284553646940162,
    "created_at" : "2012-07-17 17:43:17 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 225645997588639744,
  "created_at" : "2012-07-18 17:39:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 23, 32 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebook",
      "indices" : [ 0, 6 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "Nook",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225645590426562561",
  "text" : "#ebook lovers, support @iLivrada #Kindle #Nook - ebook gift cards with cover art &amp; description!",
  "id" : 225645590426562561,
  "created_at" : "2012-07-18 17:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 0, 9 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225640918823354368",
  "geo" : { },
  "id_str" : "225642103408046080",
  "in_reply_to_user_id" : 508402674,
  "text" : "@iLivrada i have so many books on my kindle and I forget WHY i wanted to read.. these cards would be helpful to remind! : )",
  "id" : 225642103408046080,
  "in_reply_to_status_id" : 225640918823354368,
  "created_at" : "2012-07-18 17:24:04 +0000",
  "in_reply_to_screen_name" : "livrada",
  "in_reply_to_user_id_str" : "508402674",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "BookBriefs",
      "indices" : [ 101, 112 ],
      "id_str" : "34554366",
      "id" : 34554366
    }, {
      "name" : "isabel livrada",
      "screen_name" : "ILivrada",
      "indices" : [ 113, 122 ],
      "id_str" : "4071164169",
      "id" : 4071164169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225634126303215617",
  "geo" : { },
  "id_str" : "225638609892552705",
  "in_reply_to_user_id" : 276486305,
  "text" : "@kindlefever would be awesome if it catches on! also sell w\/out codes 4 those who already have ebook @BookBriefs @iLivrada",
  "id" : 225638609892552705,
  "in_reply_to_status_id" : 225634126303215617,
  "created_at" : "2012-07-18 17:10:11 +0000",
  "in_reply_to_screen_name" : "mssherlocked",
  "in_reply_to_user_id_str" : "276486305",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 118, 132 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/I3jFD95K",
      "expanded_url" : "http:\/\/bit.ly\/M9aogI",
      "display_url" : "bit.ly\/M9aogI"
    } ]
  },
  "geo" : { },
  "id_str" : "225632663480967168",
  "text" : "he was brainwashed.. sad.  &gt;&gt; Chad Holtz now believes in hell. As to homosexuality \u2026 ? http:\/\/t.co\/I3jFD95K cc: @BibleAlsoSays",
  "id" : 225632663480967168,
  "created_at" : "2012-07-18 16:46:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "VA League",
      "screen_name" : "VA_League",
      "indices" : [ 16, 26 ],
      "id_str" : "188015337",
      "id" : 188015337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/IbXA4rxH",
      "expanded_url" : "http:\/\/ow.ly\/ckdYD",
      "display_url" : "ow.ly\/ckdYD"
    } ]
  },
  "geo" : { },
  "id_str" : "225612194446979072",
  "text" : "RT @CandyTX: RT @va_league: We are holding a FREE social chat for all VAs and aspiring VAs today at 3pm Eastern! http:\/\/t.co\/IbXA4rxH Jo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VA League",
        "screen_name" : "VA_League",
        "indices" : [ 3, 13 ],
        "id_str" : "188015337",
        "id" : 188015337
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/IbXA4rxH",
        "expanded_url" : "http:\/\/ow.ly\/ckdYD",
        "display_url" : "ow.ly\/ckdYD"
      } ]
    },
    "geo" : { },
    "id_str" : "225602956354007040",
    "text" : "RT @va_league: We are holding a FREE social chat for all VAs and aspiring VAs today at 3pm Eastern! http:\/\/t.co\/IbXA4rxH Join us!",
    "id" : 225602956354007040,
    "created_at" : "2012-07-18 14:48:30 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 225612194446979072,
  "created_at" : "2012-07-18 15:25:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225611496619655168",
  "text" : "RT @By_Bashar: Act like you are what you imagine you want to be - and you will be it ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225607464077377537",
    "text" : "Act like you are what you imagine you want to be - and you will be it ~ bashar",
    "id" : 225607464077377537,
    "created_at" : "2012-07-18 15:06:25 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 225611496619655168,
  "created_at" : "2012-07-18 15:22:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225411464326938624",
  "text" : "RT @By_Bashar: The path of timidity yields no gain . let us Be bold in Being our True selves ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225411179126861825",
    "text" : "The path of timidity yields no gain . let us Be bold in Being our True selves ~ bashar",
    "id" : 225411179126861825,
    "created_at" : "2012-07-18 02:06:27 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 225411464326938624,
  "created_at" : "2012-07-18 02:07:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225399629158678528",
  "geo" : { },
  "id_str" : "225411054530867201",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist no problem. : ) (I'm just fascinated by nde type stuff.)",
  "id" : 225411054530867201,
  "in_reply_to_status_id" : 225399629158678528,
  "created_at" : "2012-07-18 02:05:57 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225382039355002881",
  "text" : "RT @By_Bashar: You have only a choice between Expansion or Contraction. Love or Fear ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225380979693465600",
    "text" : "You have only a choice between Expansion or Contraction. Love or Fear ~ bashar",
    "id" : 225380979693465600,
    "created_at" : "2012-07-18 00:06:27 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 225382039355002881,
  "created_at" : "2012-07-18 00:10:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225374786593894401",
  "geo" : { },
  "id_str" : "225377296868052992",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench oh.. the expression.. : )",
  "id" : 225377296868052992,
  "in_reply_to_status_id" : 225374786593894401,
  "created_at" : "2012-07-17 23:51:49 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "Hank",
      "screen_name" : "hankgolfer",
      "indices" : [ 64, 75 ],
      "id_str" : "149851544",
      "id" : 149851544
    }, {
      "name" : "adam lockett",
      "screen_name" : "adaminberlin",
      "indices" : [ 76, 89 ],
      "id_str" : "25659210",
      "id" : 25659210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225375662200987648",
  "geo" : { },
  "id_str" : "225376610193391616",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool dunno why but this comment made me chuckle..lol @hankgolfer @adaminberlin",
  "id" : 225376610193391616,
  "in_reply_to_status_id" : 225375662200987648,
  "created_at" : "2012-07-17 23:49:05 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zen",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225368353101983744",
  "text" : "RT @CoyoteSings: Make fun of yourself. Once you aren't afraid of yourself, you're not afraid of anyone. #zen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zen",
        "indices" : [ 87, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225362753945223168",
    "text" : "Make fun of yourself. Once you aren't afraid of yourself, you're not afraid of anyone. #zen",
    "id" : 225362753945223168,
    "created_at" : "2012-07-17 22:54:02 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 225368353101983744,
  "created_at" : "2012-07-17 23:16:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 2, 17 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225362733804163072",
  "geo" : { },
  "id_str" : "225368314812170240",
  "in_reply_to_user_id" : 550304910,
  "text" : ". @TheAtheistFool i have meltdowns all the time..LOLOL",
  "id" : 225368314812170240,
  "in_reply_to_status_id" : 225362733804163072,
  "created_at" : "2012-07-17 23:16:08 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "birds",
      "indices" : [ 48, 54 ]
    }, {
      "text" : "photo",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/0kvHNxbb",
      "expanded_url" : "http:\/\/www.martinbelan.com\/p912283134\/e285b3b4c",
      "display_url" : "martinbelan.com\/p912283134\/e28\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225367498864865280",
  "text" : "RT @MartinBelan: #Bluebird http:\/\/t.co\/0kvHNxbb #birds #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "birds",
        "indices" : [ 31, 37 ]
      }, {
        "text" : "photo",
        "indices" : [ 38, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 10, 30 ],
        "url" : "http:\/\/t.co\/0kvHNxbb",
        "expanded_url" : "http:\/\/www.martinbelan.com\/p912283134\/e285b3b4c",
        "display_url" : "martinbelan.com\/p912283134\/e28\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "225367052494442496",
    "text" : "#Bluebird http:\/\/t.co\/0kvHNxbb #birds #photo",
    "id" : 225367052494442496,
    "created_at" : "2012-07-17 23:11:07 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 225367498864865280,
  "created_at" : "2012-07-17 23:12:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225367336708882432",
  "text" : "I ran over an animal while driving home.. literally over the top of it..lol. Might have been a squirrel.",
  "id" : 225367336708882432,
  "created_at" : "2012-07-17 23:12:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.keek.com\" rel=\"nofollow\"\u003EKeek\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/G3FoWmWH",
      "expanded_url" : "http:\/\/www.keek.com\/!OOzmaab",
      "display_url" : "keek.com\/!OOzmaab"
    } ]
  },
  "geo" : { },
  "id_str" : "225346188835176448",
  "text" : "Annoying daughter http:\/\/t.co\/G3FoWmWH",
  "id" : 225346188835176448,
  "created_at" : "2012-07-17 21:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 9, 21 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equality",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "marriage",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/5seGKs44",
      "expanded_url" : "http:\/\/rationalapparel.com\/products\/get-the-state-out-of-marriage",
      "display_url" : "rationalapparel.com\/products\/get-t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "225338522947682305",
  "geo" : { },
  "id_str" : "225339954270715904",
  "in_reply_to_user_id" : 15349954,
  "text" : "NICE! RT @angelaharms Woah. My kid designed this shirt. http:\/\/t.co\/5seGKs44 #equality #marriage",
  "id" : 225339954270715904,
  "in_reply_to_status_id" : 225338522947682305,
  "created_at" : "2012-07-17 21:23:26 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 10, 22 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225317432112324608",
  "geo" : { },
  "id_str" : "225318276450885632",
  "in_reply_to_user_id" : 51880276,
  "text" : "AMEN!! RT @VirgoJohnny On behalf of gays everywhere, christians, we don't care if you don't like it, we WILL get marriage rights!",
  "id" : 225318276450885632,
  "in_reply_to_status_id" : 225317432112324608,
  "created_at" : "2012-07-17 19:57:17 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225315926365577216",
  "text" : "RT @ificouldtellu: Life has no beginning nor ending.All boundaries are conceptual.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225313981655564288",
    "text" : "Life has no beginning nor ending.All boundaries are conceptual.",
    "id" : 225313981655564288,
    "created_at" : "2012-07-17 19:40:14 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 225315926365577216,
  "created_at" : "2012-07-17 19:47:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 14, 27 ],
      "id_str" : "135615040",
      "id" : 135615040
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 71, 85 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/UAp2W5z0",
      "expanded_url" : "http:\/\/fb.me\/28h7uzNjK",
      "display_url" : "fb.me\/28h7uzNjK"
    } ]
  },
  "in_reply_to_status_id_str" : "225312519919648769",
  "geo" : { },
  "id_str" : "225314572473602048",
  "in_reply_to_user_id" : 135615040,
  "text" : "heehee : ) RT @CrystalLewis Check. And. Mate. http:\/\/t.co\/UAp2W5z0 cc: @BibleAlsoSays",
  "id" : 225314572473602048,
  "in_reply_to_status_id" : 225312519919648769,
  "created_at" : "2012-07-17 19:42:34 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Phillip Tanner",
      "screen_name" : "PTanner34",
      "indices" : [ 21, 31 ],
      "id_str" : "388521075",
      "id" : 388521075
    }, {
      "name" : "Cameron Jackson",
      "screen_name" : "MrCrue2009",
      "indices" : [ 34, 45 ],
      "id_str" : "635099003",
      "id" : 635099003
    }, {
      "name" : "Phillip Tanner",
      "screen_name" : "PTanner34",
      "indices" : [ 47, 57 ],
      "id_str" : "388521075",
      "id" : 388521075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveIt",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225306550145794048",
  "text" : "RT @DwayneReaves: RT @PTanner34: \u201C@MrCrue2009: @PTanner34  \"Every saint has a past. Every sinner has a future\"\u201D #LoveIt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phillip Tanner",
        "screen_name" : "PTanner34",
        "indices" : [ 3, 13 ],
        "id_str" : "388521075",
        "id" : 388521075
      }, {
        "name" : "Cameron Jackson",
        "screen_name" : "MrCrue2009",
        "indices" : [ 16, 27 ],
        "id_str" : "635099003",
        "id" : 635099003
      }, {
        "name" : "Phillip Tanner",
        "screen_name" : "PTanner34",
        "indices" : [ 29, 39 ],
        "id_str" : "388521075",
        "id" : 388521075
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveIt",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225306149858193408",
    "text" : "RT @PTanner34: \u201C@MrCrue2009: @PTanner34  \"Every saint has a past. Every sinner has a future\"\u201D #LoveIt",
    "id" : 225306149858193408,
    "created_at" : "2012-07-17 19:09:06 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 225306550145794048,
  "created_at" : "2012-07-17 19:10:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 41, 55 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225297796859834368",
  "geo" : { },
  "id_str" : "225299349003972609",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist sorry.. dont understand? @BibleAlsoSays",
  "id" : 225299349003972609,
  "in_reply_to_status_id" : 225297796859834368,
  "created_at" : "2012-07-17 18:42:05 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225298478891417600",
  "geo" : { },
  "id_str" : "225299166077796352",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny oh yes! love, love hm soap! mm.. esp. vanilla or honey oatmeal type scents",
  "id" : 225299166077796352,
  "in_reply_to_status_id" : 225298478891417600,
  "created_at" : "2012-07-17 18:41:21 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 66, 81 ],
      "id_str" : "544382308",
      "id" : 544382308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225295395415269376",
  "geo" : { },
  "id_str" : "225296451838816256",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny what soap you like VG? i like ivory (it floats! lol) @gospelguidance",
  "id" : 225296451838816256,
  "in_reply_to_status_id" : 225295395415269376,
  "created_at" : "2012-07-17 18:30:34 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225294892908290049",
  "text" : "its too hot to wear a bra so im wearing 2 shirts...",
  "id" : 225294892908290049,
  "created_at" : "2012-07-17 18:24:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225283706015858688",
  "text" : "think im turning to stone.. or mutating.. my joints feels weird..",
  "id" : 225283706015858688,
  "created_at" : "2012-07-17 17:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225280364292210688",
  "text" : "RT @CandyTX: Speakers: Looking to speak to a small group of female small business owners (online webinar format)? VA_League is looking!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225279977262825472",
    "text" : "Speakers: Looking to speak to a small group of female small business owners (online webinar format)? VA_League is looking!",
    "id" : 225279977262825472,
    "created_at" : "2012-07-17 17:25:06 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 225280364292210688,
  "created_at" : "2012-07-17 17:26:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miranda Mclean",
      "screen_name" : "Mouthy_",
      "indices" : [ 23, 31 ],
      "id_str" : "911706140",
      "id" : 911706140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225274349890969600",
  "text" : "Hey, that's me! LOL RT @Mouthy_  Awesome on twitter, retarded in real life.",
  "id" : 225274349890969600,
  "created_at" : "2012-07-17 17:02:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 75, 90 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225273516394680320",
  "text" : "@BibleAlsoSays oh, cool! I'd love to read about your experience as well as @thesexyatheist who mentioned having one. : )",
  "id" : 225273516394680320,
  "created_at" : "2012-07-17 16:59:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyall Furphy RN",
      "screen_name" : "Lyall",
      "indices" : [ 3, 9 ],
      "id_str" : "15062981",
      "id" : 15062981
    }, {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "indices" : [ 14, 25 ],
      "id_str" : "283660852",
      "id" : 283660852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/dcF2MnzK",
      "expanded_url" : "http:\/\/fb.me\/1p04qFXWg",
      "display_url" : "fb.me\/1p04qFXWg"
    } ]
  },
  "geo" : { },
  "id_str" : "225272181741985792",
  "text" : "RT @Lyall: MT @slothville: Who said Tasmanian Devils weren't cute? Here I am with a baby (also called Lucy). http:\/\/t.co\/dcF2MnzK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slothville",
        "screen_name" : "slothville",
        "indices" : [ 3, 14 ],
        "id_str" : "283660852",
        "id" : 283660852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/dcF2MnzK",
        "expanded_url" : "http:\/\/fb.me\/1p04qFXWg",
        "display_url" : "fb.me\/1p04qFXWg"
      } ]
    },
    "in_reply_to_status_id_str" : "225247123623526404",
    "geo" : { },
    "id_str" : "225250689905987585",
    "in_reply_to_user_id" : 283660852,
    "text" : "MT @slothville: Who said Tasmanian Devils weren't cute? Here I am with a baby (also called Lucy). http:\/\/t.co\/dcF2MnzK",
    "id" : 225250689905987585,
    "in_reply_to_status_id" : 225247123623526404,
    "created_at" : "2012-07-17 15:28:44 +0000",
    "in_reply_to_screen_name" : "slothville",
    "in_reply_to_user_id_str" : "283660852",
    "user" : {
      "name" : "Lyall Furphy RN",
      "screen_name" : "Lyall",
      "protected" : false,
      "id_str" : "15062981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706211166935076865\/6qOmkfyz_normal.jpg",
      "id" : 15062981,
      "verified" : false
    }
  },
  "id" : 225272181741985792,
  "created_at" : "2012-07-17 16:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225247393799614464",
  "text" : "RT @BrianMerritt: Depression sucks.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225244685495578625",
    "text" : "Depression sucks.",
    "id" : 225244685495578625,
    "created_at" : "2012-07-17 15:04:52 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 225247393799614464,
  "created_at" : "2012-07-17 15:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "indices" : [ 19, 35 ],
      "id_str" : "478216296",
      "id" : 478216296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225245762399899650",
  "geo" : { },
  "id_str" : "225247156242628610",
  "in_reply_to_user_id" : 478216296,
  "text" : "they do.. sigh. RT @JesusWithIssues How would you like it if everyone kept saying how you were meek and mild?",
  "id" : 225247156242628610,
  "in_reply_to_status_id" : 225245762399899650,
  "created_at" : "2012-07-17 15:14:41 +0000",
  "in_reply_to_screen_name" : "JesusWithIssues",
  "in_reply_to_user_id_str" : "478216296",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "indices" : [ 3, 16 ],
      "id_str" : "78155553",
      "id" : 78155553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225044873668071424",
  "text" : "RT @angelmagicjp: So long as you see yourself as less than whole you will only see a fraction of what you truly are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225044143569772544",
    "text" : "So long as you see yourself as less than whole you will only see a fraction of what you truly are.",
    "id" : 225044143569772544,
    "created_at" : "2012-07-17 01:47:59 +0000",
    "user" : {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "protected" : false,
      "id_str" : "78155553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1497479357\/Hand_Heart_Sun_2_normal.jpg",
      "id" : 78155553,
      "verified" : false
    }
  },
  "id" : 225044873668071424,
  "created_at" : "2012-07-17 01:50:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225034109536317440",
  "text" : "RT @By_Bashar: You only fear - what you have not yet understood ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225033706019098624",
    "text" : "You only fear - what you have not yet understood ~ bashar",
    "id" : 225033706019098624,
    "created_at" : "2012-07-17 01:06:31 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 225034109536317440,
  "created_at" : "2012-07-17 01:08:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "indices" : [ 3, 12 ],
      "id_str" : "8234572",
      "id" : 8234572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/5f4pnZBD",
      "expanded_url" : "http:\/\/www3.griffith.edu.au\/03\/ertiki\/tiki-read_article.php?articleId=37742",
      "display_url" : "www3.griffith.edu.au\/03\/ertiki\/tiki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225034086559907840",
  "text" : "RT @cantrell: The first photograph of a single atom.\nhttp:\/\/t.co\/5f4pnZBD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/5f4pnZBD",
        "expanded_url" : "http:\/\/www3.griffith.edu.au\/03\/ertiki\/tiki-read_article.php?articleId=37742",
        "display_url" : "www3.griffith.edu.au\/03\/ertiki\/tiki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "225033707537436672",
    "text" : "The first photograph of a single atom.\nhttp:\/\/t.co\/5f4pnZBD",
    "id" : 225033707537436672,
    "created_at" : "2012-07-17 01:06:31 +0000",
    "user" : {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "protected" : false,
      "id_str" : "8234572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3466700371\/ca68118063303c7fe19a3cf79e68a9f8_normal.jpeg",
      "id" : 8234572,
      "verified" : true
    }
  },
  "id" : 225034086559907840,
  "created_at" : "2012-07-17 01:08:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225022411836366848",
  "text" : "RT @TheGoldenMirror: Talk to those you normally wouldn't talk to, to broaden your perspective.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225020385563914240",
    "text" : "Talk to those you normally wouldn't talk to, to broaden your perspective.",
    "id" : 225020385563914240,
    "created_at" : "2012-07-17 00:13:35 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 225022411836366848,
  "created_at" : "2012-07-17 00:21:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224993671181910017",
  "text" : "omg.. temple run is fun.. but too stressful for me.. lol",
  "id" : 224993671181910017,
  "created_at" : "2012-07-16 22:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/gtftraJ1",
      "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwPUqO1h",
      "display_url" : "tmblr.co\/ZYrEZwPUqO1h"
    } ]
  },
  "geo" : { },
  "id_str" : "224992144291667968",
  "text" : "RT @GeneDoucette: cat in a box. Photo: http:\/\/t.co\/gtftraJ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/gtftraJ1",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwPUqO1h",
        "display_url" : "tmblr.co\/ZYrEZwPUqO1h"
      } ]
    },
    "geo" : { },
    "id_str" : "224991861381664769",
    "text" : "cat in a box. Photo: http:\/\/t.co\/gtftraJ1",
    "id" : 224991861381664769,
    "created_at" : "2012-07-16 22:20:14 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 224992144291667968,
  "created_at" : "2012-07-16 22:21:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224976432886054912",
  "text" : "RT @TyrusBooks: Oh, Internet Justice! Your sweet, sweet lynch mobs and pitchforks are a constant source of cheap and captivating enterta ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224970777903116289",
    "text" : "Oh, Internet Justice! Your sweet, sweet lynch mobs and pitchforks are a constant source of cheap and captivating entertainment.",
    "id" : 224970777903116289,
    "created_at" : "2012-07-16 20:56:27 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 224976432886054912,
  "created_at" : "2012-07-16 21:18:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/rtoJyZEC",
      "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwPUP3aH",
      "display_url" : "tmblr.co\/ZYrEZwPUP3aH"
    } ]
  },
  "geo" : { },
  "id_str" : "224969718988161024",
  "text" : "RT @GeneDoucette: gardening: fun and games until someone summons satan. Photo: http:\/\/t.co\/rtoJyZEC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/rtoJyZEC",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwPUP3aH",
        "display_url" : "tmblr.co\/ZYrEZwPUP3aH"
      } ]
    },
    "geo" : { },
    "id_str" : "224966679694802945",
    "text" : "gardening: fun and games until someone summons satan. Photo: http:\/\/t.co\/rtoJyZEC",
    "id" : 224966679694802945,
    "created_at" : "2012-07-16 20:40:10 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 224969718988161024,
  "created_at" : "2012-07-16 20:52:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/NsXxxKK3",
      "expanded_url" : "http:\/\/huff.to\/O38lgk",
      "display_url" : "huff.to\/O38lgk"
    } ]
  },
  "geo" : { },
  "id_str" : "224965825998749696",
  "text" : "RT @HuffPostWeird: Man's act of love for wife. http:\/\/t.co\/NsXxxKK3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/NsXxxKK3",
        "expanded_url" : "http:\/\/huff.to\/O38lgk",
        "display_url" : "huff.to\/O38lgk"
      } ]
    },
    "geo" : { },
    "id_str" : "224964152433717248",
    "text" : "Man's act of love for wife. http:\/\/t.co\/NsXxxKK3",
    "id" : 224964152433717248,
    "created_at" : "2012-07-16 20:30:08 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 224965825998749696,
  "created_at" : "2012-07-16 20:36:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224962419137576960",
  "geo" : { },
  "id_str" : "224964804660576256",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell (((jealous))) : )",
  "id" : 224964804660576256,
  "in_reply_to_status_id" : 224962419137576960,
  "created_at" : "2012-07-16 20:32:43 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Hurricane",
      "screen_name" : "Bullhornman",
      "indices" : [ 39, 51 ],
      "id_str" : "130568094",
      "id" : 130568094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224950380608503808",
  "geo" : { },
  "id_str" : "224951661234372608",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny I bet you'd look awesome! @bullhornman",
  "id" : 224951661234372608,
  "in_reply_to_status_id" : 224950380608503808,
  "created_at" : "2012-07-16 19:40:30 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224949744231907329",
  "text" : "there is no black. there is no white.",
  "id" : 224949744231907329,
  "created_at" : "2012-07-16 19:32:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224946335466528769",
  "text" : "i think one can be sane and insane at the same time.",
  "id" : 224946335466528769,
  "created_at" : "2012-07-16 19:19:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "indices" : [ 3, 16 ],
      "id_str" : "8659362",
      "id" : 8659362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Lv8klaCh",
      "expanded_url" : "http:\/\/wp.me\/paUB-jAW",
      "display_url" : "wp.me\/paUB-jAW"
    } ]
  },
  "geo" : { },
  "id_str" : "224944917326217216",
  "text" : "RT @CuteOverload: Raccoon Fell Down The Hole http:\/\/t.co\/Lv8klaCh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/Lv8klaCh",
        "expanded_url" : "http:\/\/wp.me\/paUB-jAW",
        "display_url" : "wp.me\/paUB-jAW"
      } ]
    },
    "geo" : { },
    "id_str" : "224944519991410691",
    "text" : "Raccoon Fell Down The Hole http:\/\/t.co\/Lv8klaCh",
    "id" : 224944519991410691,
    "created_at" : "2012-07-16 19:12:07 +0000",
    "user" : {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "protected" : false,
      "id_str" : "8659362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680609450495873025\/0RV8NzVo_normal.png",
      "id" : 8659362,
      "verified" : false
    }
  },
  "id" : 224944917326217216,
  "created_at" : "2012-07-16 19:13:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/FryfQeAb",
      "expanded_url" : "http:\/\/krissthesexyatheist.blogspot.com\/2012\/07\/fuck-purity-ballstheyre-creepy.html?spref=tw",
      "display_url" : "krissthesexyatheist.blogspot.com\/2012\/07\/fuck-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224938434622537729",
  "text" : "RT @thesexyatheist: krissthesexyatheist: Fuck Purity Balls...They're Creepy http:\/\/t.co\/FryfQeAb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/FryfQeAb",
        "expanded_url" : "http:\/\/krissthesexyatheist.blogspot.com\/2012\/07\/fuck-purity-ballstheyre-creepy.html?spref=tw",
        "display_url" : "krissthesexyatheist.blogspot.com\/2012\/07\/fuck-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224935296599465985",
    "text" : "krissthesexyatheist: Fuck Purity Balls...They're Creepy http:\/\/t.co\/FryfQeAb",
    "id" : 224935296599465985,
    "created_at" : "2012-07-16 18:35:28 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 224938434622537729,
  "created_at" : "2012-07-16 18:47:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 70, 85 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "Hank",
      "screen_name" : "hankgolfer",
      "indices" : [ 86, 97 ],
      "id_str" : "149851544",
      "id" : 149851544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keek",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "justsayin",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224931320839675904",
  "text" : "@BibleAlsoSays would have been more dramatic as a #keek .. #justsayin @GospelGuidance @hankgolfer",
  "id" : 224931320839675904,
  "created_at" : "2012-07-16 18:19:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224930864432300034",
  "text" : "my DD says you cannot buy friends in a jar...",
  "id" : 224930864432300034,
  "created_at" : "2012-07-16 18:17:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224914162403393536",
  "text" : "RT @JacksonPearce: I love you, twitter. You are full of knowledge.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224913143082663936",
    "text" : "I love you, twitter. You are full of knowledge.",
    "id" : 224913143082663936,
    "created_at" : "2012-07-16 17:07:26 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 224914162403393536,
  "created_at" : "2012-07-16 17:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 82, 96 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keek",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/NvX63a3d",
      "expanded_url" : "http:\/\/www.keek.com\/!hximaab",
      "display_url" : "keek.com\/!hximaab"
    } ]
  },
  "in_reply_to_status_id_str" : "224902049014358016",
  "geo" : { },
  "id_str" : "224903459688808448",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind What is #keek ? http:\/\/t.co\/NvX63a3d .. cuz yr funny! u'd B great! : ) @BibleAlsoSays",
  "id" : 224903459688808448,
  "in_reply_to_status_id" : 224902049014358016,
  "created_at" : "2012-07-16 16:28:57 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 65, 75 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 78, 92 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keek",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224901719329480705",
  "text" : "c'mon ppl.. I need some of you on #keek so I have ppl to follow! @ZachsMind ? @BibleAlsoSays ?",
  "id" : 224901719329480705,
  "created_at" : "2012-07-16 16:22:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Montano",
      "screen_name" : "Daezarkian",
      "indices" : [ 0, 11 ],
      "id_str" : "31248960",
      "id" : 31248960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224892023075909632",
  "geo" : { },
  "id_str" : "224892302726938625",
  "in_reply_to_user_id" : 31248960,
  "text" : "@Daezarkian thats me everyday! : )",
  "id" : 224892302726938625,
  "in_reply_to_status_id" : 224892023075909632,
  "created_at" : "2012-07-16 15:44:37 +0000",
  "in_reply_to_screen_name" : "Daezarkian",
  "in_reply_to_user_id_str" : "31248960",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.keek.com\" rel=\"nofollow\"\u003EKeek\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keek",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/NvX63a3d",
      "expanded_url" : "http:\/\/www.keek.com\/!hximaab",
      "display_url" : "keek.com\/!hximaab"
    } ]
  },
  "geo" : { },
  "id_str" : "224890722476769281",
  "text" : "What is #keek ? http:\/\/t.co\/NvX63a3d",
  "id" : 224890722476769281,
  "created_at" : "2012-07-16 15:38:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "peterjames48",
      "screen_name" : "peterjames48",
      "indices" : [ 3, 16 ],
      "id_str" : "25146223",
      "id" : 25146223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224854458671169537",
  "text" : "RT @peterjames48: Twitter is the best bar I've ever been to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224243299173666816",
    "text" : "Twitter is the best bar I've ever been to.",
    "id" : 224243299173666816,
    "created_at" : "2012-07-14 20:45:43 +0000",
    "user" : {
      "name" : "peterjames48",
      "screen_name" : "peterjames48",
      "protected" : false,
      "id_str" : "25146223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537816920645722112\/-mqSLIXC_normal.jpeg",
      "id" : 25146223,
      "verified" : false
    }
  },
  "id" : 224854458671169537,
  "created_at" : "2012-07-16 13:14:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224851993473204224",
  "text" : "RT @DeepakChopra: Never stoop to the level of those who put you down",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224850507322241024",
    "text" : "Never stoop to the level of those who put you down",
    "id" : 224850507322241024,
    "created_at" : "2012-07-16 12:58:33 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 224851993473204224,
  "created_at" : "2012-07-16 13:04:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/EcMcpVJc",
      "expanded_url" : "http:\/\/bit.ly\/MyACaA",
      "display_url" : "bit.ly\/MyACaA"
    } ]
  },
  "geo" : { },
  "id_str" : "224848508509884416",
  "text" : "RT @FreeRangeKids: The more things we make illegal, the more judgmental we become. Good theory, nice essay: http:\/\/t.co\/EcMcpVJc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/EcMcpVJc",
        "expanded_url" : "http:\/\/bit.ly\/MyACaA",
        "display_url" : "bit.ly\/MyACaA"
      } ]
    },
    "geo" : { },
    "id_str" : "224847178458333184",
    "text" : "The more things we make illegal, the more judgmental we become. Good theory, nice essay: http:\/\/t.co\/EcMcpVJc",
    "id" : 224847178458333184,
    "created_at" : "2012-07-16 12:45:19 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 224848508509884416,
  "created_at" : "2012-07-16 12:50:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "QuotePlayground",
      "indices" : [ 3, 19 ],
      "id_str" : "161148795",
      "id" : 161148795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224842647532085248",
  "text" : "RT @QuotePlayground: I see my purpose in life as making the world a happier place to be in. - David Niven",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224841161754419200",
    "text" : "I see my purpose in life as making the world a happier place to be in. - David Niven",
    "id" : 224841161754419200,
    "created_at" : "2012-07-16 12:21:24 +0000",
    "user" : {
      "name" : "Daniel",
      "screen_name" : "QuotePlayground",
      "protected" : false,
      "id_str" : "161148795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1692187292\/a36887995_normal.jpg",
      "id" : 161148795,
      "verified" : false
    }
  },
  "id" : 224842647532085248,
  "created_at" : "2012-07-16 12:27:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224842497237585922",
  "text" : "@BibleAlsoSays LOL",
  "id" : 224842497237585922,
  "created_at" : "2012-07-16 12:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224840709365182466",
  "text" : "@SocialistXian you lucky dog.. enjoy!",
  "id" : 224840709365182466,
  "created_at" : "2012-07-16 12:19:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224840343244390401",
  "text" : "good morning my lovelies",
  "id" : 224840343244390401,
  "created_at" : "2012-07-16 12:18:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WitchinWebs \u263E",
      "screen_name" : "WitchinWebs",
      "indices" : [ 3, 15 ],
      "id_str" : "33900739",
      "id" : 33900739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224674888756109314",
  "text" : "RT @WitchinWebs: Very Pretty... I like the idea of tying them on gifts! Set 5 Handmade Crochet Headbands by HipChickCrochet http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Etsy",
        "screen_name" : "Etsy",
        "indices" : [ 132, 137 ],
        "id_str" : "11522502",
        "id" : 11522502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/DbR5vQWx",
        "expanded_url" : "http:\/\/etsy.me\/PXqDSG",
        "display_url" : "etsy.me\/PXqDSG"
      } ]
    },
    "geo" : { },
    "id_str" : "224674380251279360",
    "text" : "Very Pretty... I like the idea of tying them on gifts! Set 5 Handmade Crochet Headbands by HipChickCrochet http:\/\/t.co\/DbR5vQWx via @Etsy",
    "id" : 224674380251279360,
    "created_at" : "2012-07-16 01:18:41 +0000",
    "user" : {
      "name" : "WitchinWebs \u263E",
      "screen_name" : "WitchinWebs",
      "protected" : false,
      "id_str" : "33900739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2825062281\/5af4585de71515ca828c742b1326704b_normal.jpeg",
      "id" : 33900739,
      "verified" : false
    }
  },
  "id" : 224674888756109314,
  "created_at" : "2012-07-16 01:20:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Only Psychics Online",
      "screen_name" : "PsychicsOnly",
      "indices" : [ 3, 16 ],
      "id_str" : "604065984",
      "id" : 604065984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224668956282208257",
  "text" : "RT @PsychicsOnly: Death is no more than passing from one room into another.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224668378017693696",
    "text" : "Death is no more than passing from one room into another.",
    "id" : 224668378017693696,
    "created_at" : "2012-07-16 00:54:50 +0000",
    "user" : {
      "name" : "Only Psychics Online",
      "screen_name" : "PsychicsOnly",
      "protected" : false,
      "id_str" : "604065984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2293807842\/PsychicCircle_normal.png",
      "id" : 604065984,
      "verified" : false
    }
  },
  "id" : 224668956282208257,
  "created_at" : "2012-07-16 00:57:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 43, 57 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224667955848417281",
  "text" : "@akicktotheeye hehehe .. makes me think of @BibleAlsoSays ; )",
  "id" : 224667955848417281,
  "created_at" : "2012-07-16 00:53:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Gillianheadbang",
      "screen_name" : "OctavianD",
      "indices" : [ 48, 58 ],
      "id_str" : "2560382726",
      "id" : 2560382726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224665376364048385",
  "geo" : { },
  "id_str" : "224665908428279811",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind dude, you are on a roll tonight! lol @OctavianD",
  "id" : 224665908428279811,
  "in_reply_to_status_id" : 224665376364048385,
  "created_at" : "2012-07-16 00:45:01 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 38, 50 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 55, 69 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "sinicrowther",
      "screen_name" : "sinicrowther",
      "indices" : [ 76, 89 ],
      "id_str" : "184504324",
      "id" : 184504324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224651825708670976",
  "geo" : { },
  "id_str" : "224653036734255106",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind this is what I try to tell @VirgoJohnny and @BibleAlsoSays ..LOL @sinicrowther",
  "id" : 224653036734255106,
  "in_reply_to_status_id" : 224651825708670976,
  "created_at" : "2012-07-15 23:53:52 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "birds",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "nature",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/InsYbA5o",
      "expanded_url" : "http:\/\/ow.ly\/cceU7",
      "display_url" : "ow.ly\/cceU7"
    } ]
  },
  "geo" : { },
  "id_str" : "224651016728084480",
  "text" : "RT @KerriFar: The Wide Open Wings of a #Bluebird in flight ~ http:\/\/t.co\/InsYbA5o  ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 25, 34 ]
      }, {
        "text" : "birds",
        "indices" : [ 71, 77 ]
      }, {
        "text" : "nature",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/InsYbA5o",
        "expanded_url" : "http:\/\/ow.ly\/cceU7",
        "display_url" : "ow.ly\/cceU7"
      } ]
    },
    "geo" : { },
    "id_str" : "224650818996027392",
    "text" : "The Wide Open Wings of a #Bluebird in flight ~ http:\/\/t.co\/InsYbA5o  ~ #birds #nature",
    "id" : 224650818996027392,
    "created_at" : "2012-07-15 23:45:03 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 224651016728084480,
  "created_at" : "2012-07-15 23:45:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TGFBook",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224649748152467456",
  "text" : "RT @alanhdawe: The very worst thing that can happen is that we die and the earthly experience ends. #TGFBook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224647550030987266",
    "text" : "The very worst thing that can happen is that we die and the earthly experience ends. #TGFBook",
    "id" : 224647550030987266,
    "created_at" : "2012-07-15 23:32:04 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 224649748152467456,
  "created_at" : "2012-07-15 23:40:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224639913189060608",
  "geo" : { },
  "id_str" : "224640882463358976",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep heehee.. he has expression like \"Really, Dad?\" lol .. cute pic!",
  "id" : 224640882463358976,
  "in_reply_to_status_id" : 224639913189060608,
  "created_at" : "2012-07-15 23:05:34 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224569619313197056",
  "text" : "RT @_NealeDWalsch: This is not a journey from nowhere to nowhere. This is a process. Life is a process. It is a process with purpose and ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nealedonaldwalsch.com\" rel=\"nofollow\"\u003ENeale Donald Walsch\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224564478954569730",
    "text" : "This is not a journey from nowhere to nowhere. This is a process. Life is a process. It is a process with purpose and meaning.",
    "id" : 224564478954569730,
    "created_at" : "2012-07-15 18:01:58 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 224569619313197056,
  "created_at" : "2012-07-15 18:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/A06GSG9c",
      "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/p\/help-bring-nick-home.html?spref=tw",
      "display_url" : "thesimpleboxcar.com\/p\/help-bring-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224553751342616576",
  "text" : "RT @AniKnits: \u007Bblogged\u007D I wrote this today because so many don't know what is really happening. http:\/\/t.co\/A06GSG9c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/A06GSG9c",
        "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/p\/help-bring-nick-home.html?spref=tw",
        "display_url" : "thesimpleboxcar.com\/p\/help-bring-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224541599013666816",
    "text" : "\u007Bblogged\u007D I wrote this today because so many don't know what is really happening. http:\/\/t.co\/A06GSG9c",
    "id" : 224541599013666816,
    "created_at" : "2012-07-15 16:31:03 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 224553751342616576,
  "created_at" : "2012-07-15 17:19:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Online Store\/Auction",
      "screen_name" : "tweetAmiracle",
      "indices" : [ 41, 55 ],
      "id_str" : "218193050",
      "id" : 218193050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224547058563026944",
  "geo" : { },
  "id_str" : "224552340903034881",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind its the nature of the beast.. @tweetAmiracle",
  "id" : 224552340903034881,
  "in_reply_to_status_id" : 224547058563026944,
  "created_at" : "2012-07-15 17:13:44 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224527421897048064",
  "text" : "Google for Zerg Rush .. lol",
  "id" : 224527421897048064,
  "created_at" : "2012-07-15 15:34:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/uPUozO8c",
      "expanded_url" : "http:\/\/MySocialCloud.com",
      "display_url" : "MySocialCloud.com"
    } ]
  },
  "geo" : { },
  "id_str" : "224526687977746433",
  "text" : "I'm checking out http:\/\/t.co\/uPUozO8c. Save your logins, generate random pw, bookmark ws, share ws, and more...",
  "id" : 224526687977746433,
  "created_at" : "2012-07-15 15:31:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224234589093236736",
  "geo" : { },
  "id_str" : "224315588237996032",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous yay!",
  "id" : 224315588237996032,
  "in_reply_to_status_id" : 224234589093236736,
  "created_at" : "2012-07-15 01:32:58 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224313256368545793",
  "geo" : { },
  "id_str" : "224315330779029504",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous out of hospital then?? : )",
  "id" : 224315330779029504,
  "in_reply_to_status_id" : 224313256368545793,
  "created_at" : "2012-07-15 01:31:57 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/JGQZxQlg",
      "expanded_url" : "http:\/\/via.me\/-31qkd9s",
      "display_url" : "via.me\/-31qkd9s"
    } ]
  },
  "geo" : { },
  "id_str" : "224313777485660160",
  "text" : "Weird bug with long \"tail\" http:\/\/t.co\/JGQZxQlg",
  "id" : 224313777485660160,
  "created_at" : "2012-07-15 01:25:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "A. Sims",
      "screen_name" : "gundersmoot",
      "indices" : [ 15, 27 ],
      "id_str" : "45168246",
      "id" : 45168246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224313416381239297",
  "text" : "@BibleAlsoSays @gundersmoot i have found hate 2B detrimental to my wellbeing : )",
  "id" : 224313416381239297,
  "created_at" : "2012-07-15 01:24:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Just Bill",
      "screen_name" : "WilliamAder",
      "indices" : [ 18, 30 ],
      "id_str" : "331017753",
      "id" : 331017753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224311856242761728",
  "text" : "RT @CaroleODell: \"@WilliamAder: You ever get the feeling most of your followers don't even know you're alive?\" Yeah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Just Bill",
        "screen_name" : "WilliamAder",
        "indices" : [ 1, 13 ],
        "id_str" : "331017753",
        "id" : 331017753
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224305204030476289",
    "text" : "\"@WilliamAder: You ever get the feeling most of your followers don't even know you're alive?\" Yeah",
    "id" : 224305204030476289,
    "created_at" : "2012-07-15 00:51:42 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 224311856242761728,
  "created_at" : "2012-07-15 01:18:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheila",
      "screen_name" : "Sheila_Mac420",
      "indices" : [ 3, 17 ],
      "id_str" : "31329800",
      "id" : 31329800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224311114517839873",
  "text" : "RT @Sheila_Mac420: We are all a little damaged on here. Be kind to everyone. Some people break easier than others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224307774329331713",
    "text" : "We are all a little damaged on here. Be kind to everyone. Some people break easier than others.",
    "id" : 224307774329331713,
    "created_at" : "2012-07-15 01:01:55 +0000",
    "user" : {
      "name" : "Sheila",
      "screen_name" : "Sheila_Mac420",
      "protected" : false,
      "id_str" : "31329800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2051866233\/GUITAR_normal.jpg",
      "id" : 31329800,
      "verified" : false
    }
  },
  "id" : 224311114517839873,
  "created_at" : "2012-07-15 01:15:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/LuwP3ORD",
      "expanded_url" : "http:\/\/ducksandclucks.com\/blog\/2012\/07\/14\/baby-crow-rescue\/",
      "display_url" : "ducksandclucks.com\/blog\/2012\/07\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224311022050222080",
  "text" : "RT @ducksandclucks: A little baby crow rescue today. http:\/\/t.co\/LuwP3ORD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/LuwP3ORD",
        "expanded_url" : "http:\/\/ducksandclucks.com\/blog\/2012\/07\/14\/baby-crow-rescue\/",
        "display_url" : "ducksandclucks.com\/blog\/2012\/07\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224309134378532864",
    "text" : "A little baby crow rescue today. http:\/\/t.co\/LuwP3ORD",
    "id" : 224309134378532864,
    "created_at" : "2012-07-15 01:07:19 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 224311022050222080,
  "created_at" : "2012-07-15 01:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "A. Sims",
      "screen_name" : "gundersmoot",
      "indices" : [ 15, 27 ],
      "id_str" : "45168246",
      "id" : 45168246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224297242901741569",
  "text" : "@BibleAlsoSays @gundersmoot hate is so... icky.",
  "id" : 224297242901741569,
  "created_at" : "2012-07-15 00:20:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas W Lance",
      "screen_name" : "douglance",
      "indices" : [ 3, 13 ],
      "id_str" : "757782870329024512",
      "id" : 757782870329024512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224290705168797696",
  "text" : "RT @DougLance: Anybody want to make money selling eFiction?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/Streamified.com\" rel=\"nofollow\"\u003EStreamified\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "224290031131561984",
    "text" : "Anybody want to make money selling eFiction?",
    "id" : 224290031131561984,
    "created_at" : "2012-07-14 23:51:25 +0000",
    "user" : {
      "name" : "Douglas W. Lance",
      "screen_name" : "DouglasWLance",
      "protected" : false,
      "id_str" : "14164456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000334743376\/a99c70bf244662760a73dc24c1b1588f_normal.png",
      "id" : 14164456,
      "verified" : false
    }
  },
  "id" : 224290705168797696,
  "created_at" : "2012-07-14 23:54:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/fcBKjp7a",
      "expanded_url" : "http:\/\/soundcloud.com\/b-rofl\/grind",
      "display_url" : "soundcloud.com\/b-rofl\/grind"
    } ]
  },
  "geo" : { },
  "id_str" : "224287960005226496",
  "text" : "RT @brandonrofl: Hey! Listen to this song I made today http:\/\/t.co\/fcBKjp7a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/fcBKjp7a",
        "expanded_url" : "http:\/\/soundcloud.com\/b-rofl\/grind",
        "display_url" : "soundcloud.com\/b-rofl\/grind"
      } ]
    },
    "geo" : { },
    "id_str" : "224278481251471361",
    "text" : "Hey! Listen to this song I made today http:\/\/t.co\/fcBKjp7a",
    "id" : 224278481251471361,
    "created_at" : "2012-07-14 23:05:31 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 224287960005226496,
  "created_at" : "2012-07-14 23:43:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224217065928671234",
  "text" : "who knew you'd need a degree to get right bra size.. OY!!",
  "id" : 224217065928671234,
  "created_at" : "2012-07-14 19:01:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sun Ray",
      "screen_name" : "Raycman",
      "indices" : [ 3, 11 ],
      "id_str" : "381608060",
      "id" : 381608060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223947405689753600",
  "text" : "RT @Raycman: Your fear is 100% dependent on you for it's survival.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223940029276364800",
    "text" : "Your fear is 100% dependent on you for it's survival.",
    "id" : 223940029276364800,
    "created_at" : "2012-07-14 00:40:38 +0000",
    "user" : {
      "name" : "Sun Ray",
      "screen_name" : "Raycman",
      "protected" : false,
      "id_str" : "381608060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655377112933781504\/dLyFlplX_normal.jpg",
      "id" : 381608060,
      "verified" : false
    }
  },
  "id" : 223947405689753600,
  "created_at" : "2012-07-14 01:09:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "staugustine",
      "indices" : [ 35, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/DVna4J1r",
      "expanded_url" : "http:\/\/instagr.am\/p\/NCbxHWOuLh\/",
      "display_url" : "instagr.am\/p\/NCbxHWOuLh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "223911836163121153",
  "text" : "RT @CaroleODell: Fountain at night #staugustine  http:\/\/t.co\/DVna4J1r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "staugustine",
        "indices" : [ 18, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/DVna4J1r",
        "expanded_url" : "http:\/\/instagr.am\/p\/NCbxHWOuLh\/",
        "display_url" : "instagr.am\/p\/NCbxHWOuLh\/"
      } ]
    },
    "geo" : { },
    "id_str" : "223908829669232641",
    "text" : "Fountain at night #staugustine  http:\/\/t.co\/DVna4J1r",
    "id" : 223908829669232641,
    "created_at" : "2012-07-13 22:36:39 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 223911836163121153,
  "created_at" : "2012-07-13 22:48:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 36, 47 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 48, 61 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 62, 75 ],
      "id_str" : "17374293",
      "id" : 17374293
    }, {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 76, 86 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 87, 94 ],
      "id_str" : "6872302",
      "id" : 6872302
    }, {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 95, 104 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 105, 119 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keek",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223911499230482432",
  "text" : "FYI: i'd love to see them #keek : ) @TyrusBooks @adamrshields @JeremyCShipp @ZachsMind @Mahala @Tideliar @HeathenRabbit",
  "id" : 223911499230482432,
  "created_at" : "2012-07-13 22:47:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 9, 25 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/yaa2WjDq",
      "expanded_url" : "http:\/\/instagr.am\/p\/NCPlkHh4Vf\/",
      "display_url" : "instagr.am\/p\/NCPlkHh4Vf\/"
    } ]
  },
  "in_reply_to_status_id_str" : "223882036681785344",
  "geo" : { },
  "id_str" : "223882997437448193",
  "in_reply_to_user_id" : 10206812,
  "text" : "YUM!! RT @JesusNeedsNewPR ...I've been baking... http:\/\/t.co\/yaa2WjDq",
  "id" : 223882997437448193,
  "in_reply_to_status_id" : 223882036681785344,
  "created_at" : "2012-07-13 20:54:00 +0000",
  "in_reply_to_screen_name" : "HeyMPT",
  "in_reply_to_user_id_str" : "10206812",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 20, 32 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 33, 47 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 65, 75 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 76, 88 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 89, 102 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keek",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223877689134694400",
  "text" : "I would love to see @VirgoJohnny @BibleAlsoSays @SamsaricWarrior @Matth3ous @MindyMayhem @DwayneReaves #keek : )",
  "id" : 223877689134694400,
  "created_at" : "2012-07-13 20:32:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quartersongs",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223796518803619840",
  "text" : "RT @amazonmp3: Tell us what song you'd like to buy for $.25, tag it #quartersongs and we might use your pick next week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.amazon.com\/ref=tsm_1_tw_s9mapps\" rel=\"nofollow\"\u003ESocial Manager Publisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quartersongs",
        "indices" : [ 53, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223795301557866497",
    "text" : "Tell us what song you'd like to buy for $.25, tag it #quartersongs and we might use your pick next week.",
    "id" : 223795301557866497,
    "created_at" : "2012-07-13 15:05:32 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 223796518803619840,
  "created_at" : "2012-07-13 15:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 13, 28 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keekideas",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "keek",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223786402263994369",
  "text" : "#keekideas - @PeggySueCusses could #keek her cute totes; authors could keek their books or read a sample..",
  "id" : 223786402263994369,
  "created_at" : "2012-07-13 14:30:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keek",
      "screen_name" : "Keek",
      "indices" : [ 36, 41 ],
      "id_str" : "313586546",
      "id" : 313586546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223784822970134529",
  "text" : "so many ppl on here I'd love to see @keek .. it's complementary to twitter..",
  "id" : 223784822970134529,
  "created_at" : "2012-07-13 14:23:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mystic Soul Fire",
      "screen_name" : "FireMystic",
      "indices" : [ 3, 14 ],
      "id_str" : "2613385775",
      "id" : 2613385775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/ZCJ28KtE",
      "expanded_url" : "http:\/\/fb.me\/1ldyivQml",
      "display_url" : "fb.me\/1ldyivQml"
    } ]
  },
  "geo" : { },
  "id_str" : "223776328208490497",
  "text" : "RT @FireMystic: One of De La Mer Cross Stitch Cards offerings.  I love her Celtic knotwork designs! http:\/\/t.co\/ZCJ28KtE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/ZCJ28KtE",
        "expanded_url" : "http:\/\/fb.me\/1ldyivQml",
        "display_url" : "fb.me\/1ldyivQml"
      } ]
    },
    "geo" : { },
    "id_str" : "223775373488422913",
    "text" : "One of De La Mer Cross Stitch Cards offerings.  I love her Celtic knotwork designs! http:\/\/t.co\/ZCJ28KtE",
    "id" : 223775373488422913,
    "created_at" : "2012-07-13 13:46:21 +0000",
    "user" : {
      "name" : "Raven",
      "screen_name" : "RavenWilliamsFA",
      "protected" : false,
      "id_str" : "51579001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765929761466048512\/5bgR2mAE_normal.jpg",
      "id" : 51579001,
      "verified" : false
    }
  },
  "id" : 223776328208490497,
  "created_at" : "2012-07-13 13:50:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.keek.com\" rel=\"nofollow\"\u003EKeek\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/acIzaOgi",
      "expanded_url" : "http:\/\/www.keek.com\/!9H8laab",
      "display_url" : "keek.com\/!9H8laab"
    } ]
  },
  "geo" : { },
  "id_str" : "223775398381633536",
  "text" : "Good morning! It's Friday! : ) http:\/\/t.co\/acIzaOgi",
  "id" : 223775398381633536,
  "created_at" : "2012-07-13 13:46:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223754358683209728",
  "text" : "RT @richarddoetsch: Don't ever assume that those friends around the corner have the perfect life... because they don't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223752875791228928",
    "text" : "Don't ever assume that those friends around the corner have the perfect life... because they don't.",
    "id" : 223752875791228928,
    "created_at" : "2012-07-13 12:16:57 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 223754358683209728,
  "created_at" : "2012-07-13 12:22:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandro Stealth",
      "screen_name" : "mutalabala",
      "indices" : [ 3, 14 ],
      "id_str" : "245750555",
      "id" : 245750555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223754219495231490",
  "text" : "RT @mutalabala: We have failed to grasp the fact that mankind is becoming a single unit,  that for a unit to fight against itself is sui ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223753178309595136",
    "text" : "We have failed to grasp the fact that mankind is becoming a single unit,  that for a unit to fight against itself is suicide. Havelock Ellis",
    "id" : 223753178309595136,
    "created_at" : "2012-07-13 12:18:09 +0000",
    "user" : {
      "name" : "Sandro Stealth",
      "screen_name" : "mutalabala",
      "protected" : false,
      "id_str" : "245750555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587246653117071360\/16-509Lp_normal.png",
      "id" : 245750555,
      "verified" : false
    }
  },
  "id" : 223754219495231490,
  "created_at" : "2012-07-13 12:22:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223752085500473346",
  "text" : "RT @paulocoelho: Don't rush: what is really important always finds a way of revealing itself",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223590784421724160",
    "text" : "Don't rush: what is really important always finds a way of revealing itself",
    "id" : 223590784421724160,
    "created_at" : "2012-07-13 01:32:51 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 223752085500473346,
  "created_at" : "2012-07-13 12:13:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Hurricane",
      "screen_name" : "Bullhornman",
      "indices" : [ 52, 64 ],
      "id_str" : "130568094",
      "id" : 130568094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223573963438170112",
  "geo" : { },
  "id_str" : "223574505640034305",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny Can I ride in the basket with you, VJ? @Bullhornman",
  "id" : 223574505640034305,
  "in_reply_to_status_id" : 223573963438170112,
  "created_at" : "2012-07-13 00:28:10 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 17, 26 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223532801662779394",
  "geo" : { },
  "id_str" : "223574093902004224",
  "in_reply_to_user_id" : 15474394,
  "text" : "Thanks Nicole at @thislife .. the clicking on pic brings up tag box! I'm also using \"activity\" to tag items.. it's working out well. : )",
  "id" : 223574093902004224,
  "in_reply_to_status_id" : 223532801662779394,
  "created_at" : "2012-07-13 00:26:32 +0000",
  "in_reply_to_screen_name" : "ThisLife",
  "in_reply_to_user_id_str" : "15474394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 0, 9 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223530067794477059",
  "geo" : { },
  "id_str" : "223531988013948928",
  "in_reply_to_user_id" : 15474394,
  "text" : "@thislife cool beans! : ) email sent from abfabgab",
  "id" : 223531988013948928,
  "in_reply_to_status_id" : 223530067794477059,
  "created_at" : "2012-07-12 21:39:13 +0000",
  "in_reply_to_screen_name" : "ThisLife",
  "in_reply_to_user_id_str" : "15474394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 28, 37 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/UMwEShxl",
      "expanded_url" : "http:\/\/tl.gd\/ia291r",
      "display_url" : "tl.gd\/ia291r"
    } ]
  },
  "geo" : { },
  "id_str" : "223523564215746560",
  "text" : "im enjoying service so far! @thislife .. one note: want to tag pics w no face (some pics dont regcognize face) (cont) http:\/\/t.co\/UMwEShxl",
  "id" : 223523564215746560,
  "created_at" : "2012-07-12 21:05:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "indices" : [ 3, 13 ],
      "id_str" : "27142719",
      "id" : 27142719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223509825252896768",
  "text" : "RT @robkroese: I forgot to tell you guys this hour that my novel, Mercury Falls, is only $1.99 right now. 270 reviews, 4.3 stars http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/tSufIlif",
        "expanded_url" : "http:\/\/amzn.to\/PPPjwr",
        "display_url" : "amzn.to\/PPPjwr"
      } ]
    },
    "geo" : { },
    "id_str" : "223509091123863553",
    "text" : "I forgot to tell you guys this hour that my novel, Mercury Falls, is only $1.99 right now. 270 reviews, 4.3 stars http:\/\/t.co\/tSufIlif",
    "id" : 223509091123863553,
    "created_at" : "2012-07-12 20:08:14 +0000",
    "user" : {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "protected" : false,
      "id_str" : "27142719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759449467435229184\/Kqa5_jGt_normal.jpg",
      "id" : 27142719,
      "verified" : false
    }
  },
  "id" : 223509825252896768,
  "created_at" : "2012-07-12 20:11:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/DYPNlmjp",
      "expanded_url" : "http:\/\/ashkuff.com",
      "display_url" : "ashkuff.com"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/QTSRrfNE",
      "expanded_url" : "http:\/\/bit.ly\/OenrvZ",
      "display_url" : "bit.ly\/OenrvZ"
    } ]
  },
  "geo" : { },
  "id_str" : "223505794757431296",
  "text" : "Why Online Job Applications, and Most Other Questionnaires, Make Me Want to Yank my Hair Out \u00AB http:\/\/t.co\/DYPNlmjp http:\/\/t.co\/QTSRrfNE",
  "id" : 223505794757431296,
  "created_at" : "2012-07-12 19:55:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederick Merat",
      "screen_name" : "MeratFred",
      "indices" : [ 3, 13 ],
      "id_str" : "490820218",
      "id" : 490820218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223464495081725953",
  "text" : "RT @MeratFred: Humankind shall make it's greatest progress when it learns to LOVE because of LOVE, and not because it was commanded to L ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223456648973398017",
    "text" : "Humankind shall make it's greatest progress when it learns to LOVE because of LOVE, and not because it was commanded to LOVE!  LOL!",
    "id" : 223456648973398017,
    "created_at" : "2012-07-12 16:39:51 +0000",
    "user" : {
      "name" : "Frederick Merat",
      "screen_name" : "MeratFred",
      "protected" : false,
      "id_str" : "490820218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1904701400\/fred_xmas_pic-crop_normal.jpg",
      "id" : 490820218,
      "verified" : false
    }
  },
  "id" : 223464495081725953,
  "created_at" : "2012-07-12 17:11:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Lindsey Patrick",
      "screen_name" : "lindseyjane01",
      "indices" : [ 23, 37 ],
      "id_str" : "229212438",
      "id" : 229212438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223464206031261696",
  "text" : "RT @KerriFar: CUTE! RT @lindseyjane01: 'Mo' our sheep having a rest in the old flowerbed behind the house,the other day.   http:\/\/t.co\/z ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lindsey Patrick",
        "screen_name" : "lindseyjane01",
        "indices" : [ 9, 23 ],
        "id_str" : "229212438",
        "id" : 229212438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/za9Ktbpr",
        "expanded_url" : "http:\/\/instagr.am\/p\/M-cfVzHxBa\/",
        "display_url" : "instagr.am\/p\/M-cfVzHxBa\/"
      } ]
    },
    "geo" : { },
    "id_str" : "223457115023478784",
    "text" : "CUTE! RT @lindseyjane01: 'Mo' our sheep having a rest in the old flowerbed behind the house,the other day.   http:\/\/t.co\/za9Ktbpr",
    "id" : 223457115023478784,
    "created_at" : "2012-07-12 16:41:42 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 223464206031261696,
  "created_at" : "2012-07-12 17:09:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conservation Intl",
      "screen_name" : "ConservationOrg",
      "indices" : [ 3, 19 ],
      "id_str" : "19940791",
      "id" : 19940791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/z0GQPFY7",
      "expanded_url" : "http:\/\/ow.ly\/cc3bz",
      "display_url" : "ow.ly\/cc3bz"
    } ]
  },
  "geo" : { },
  "id_str" : "223447724597579776",
  "text" : "RT @ConservationOrg: This buffalo species is struggling for survival: http:\/\/t.co\/z0GQPFY7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/z0GQPFY7",
        "expanded_url" : "http:\/\/ow.ly\/cc3bz",
        "display_url" : "ow.ly\/cc3bz"
      } ]
    },
    "geo" : { },
    "id_str" : "223444116602761218",
    "text" : "This buffalo species is struggling for survival: http:\/\/t.co\/z0GQPFY7",
    "id" : 223444116602761218,
    "created_at" : "2012-07-12 15:50:03 +0000",
    "user" : {
      "name" : "Conservation Intl",
      "screen_name" : "ConservationOrg",
      "protected" : false,
      "id_str" : "19940791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1123121696\/CI_VerticalLockup_PMSFor_Facebook_normal.jpg",
      "id" : 19940791,
      "verified" : true
    }
  },
  "id" : 223447724597579776,
  "created_at" : "2012-07-12 16:04:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logically Critical",
      "screen_name" : "WhyIAmNotAXtian",
      "indices" : [ 3, 19 ],
      "id_str" : "337119411",
      "id" : 337119411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223447333394849794",
  "text" : "RT @WhyIAmNotAXtian: GOD: 1) Define sin 2) Design humans to sin 3) Create hell for sinners 4) Blame predicament on humans 5) Say it's be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheism",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223445442682302465",
    "text" : "GOD: 1) Define sin 2) Design humans to sin 3) Create hell for sinners 4) Blame predicament on humans 5) Say it's because of love \/\/ #atheism",
    "id" : 223445442682302465,
    "created_at" : "2012-07-12 15:55:19 +0000",
    "user" : {
      "name" : "Logically Critical",
      "screen_name" : "WhyIAmNotAXtian",
      "protected" : false,
      "id_str" : "337119411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995428970\/d75fca84150c5751017e4e27ae6cf3aa_normal.jpeg",
      "id" : 337119411,
      "verified" : false
    }
  },
  "id" : 223447333394849794,
  "created_at" : "2012-07-12 16:02:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "HailGalvatron",
      "indices" : [ 3, 17 ],
      "id_str" : "52461517",
      "id" : 52461517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/y0zeErtM",
      "expanded_url" : "http:\/\/bit.ly\/Od8lqh",
      "display_url" : "bit.ly\/Od8lqh"
    } ]
  },
  "geo" : { },
  "id_str" : "223447253770178560",
  "text" : "RT @HailGalvatron: Yeah Rick Perry Will Spend $25 Million Renovating Governor\u2019s Mansion, Wanna Make Something Of It? http:\/\/t.co\/y0zeErtM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\"\u003ESilver Bird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/y0zeErtM",
        "expanded_url" : "http:\/\/bit.ly\/Od8lqh",
        "display_url" : "bit.ly\/Od8lqh"
      } ]
    },
    "geo" : { },
    "id_str" : "223444848668188672",
    "text" : "Yeah Rick Perry Will Spend $25 Million Renovating Governor\u2019s Mansion, Wanna Make Something Of It? http:\/\/t.co\/y0zeErtM",
    "id" : 223444848668188672,
    "created_at" : "2012-07-12 15:52:57 +0000",
    "user" : {
      "name" : "Matt",
      "screen_name" : "HailGalvatron",
      "protected" : false,
      "id_str" : "52461517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479817442\/GluttonyOfWar_normal.jpg",
      "id" : 52461517,
      "verified" : false
    }
  },
  "id" : 223447253770178560,
  "created_at" : "2012-07-12 16:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 7, 20 ],
      "id_str" : "7350962",
      "id" : 7350962
    }, {
      "name" : "ThisLife",
      "screen_name" : "ThisLife",
      "indices" : [ 81, 90 ],
      "id_str" : "15474394",
      "id" : 15474394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223425593339944960",
  "geo" : { },
  "id_str" : "223445553571303425",
  "in_reply_to_user_id" : 7350962,
  "text" : "thanks @earthXplorer for sharing.. i just signed up. Looks like a great service! @thislife",
  "id" : 223445553571303425,
  "in_reply_to_status_id" : 223425593339944960,
  "created_at" : "2012-07-12 15:55:46 +0000",
  "in_reply_to_screen_name" : "earthXplorer",
  "in_reply_to_user_id_str" : "7350962",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bible Students Say..",
      "screen_name" : "BibleStdntsSay",
      "indices" : [ 3, 18 ],
      "id_str" : "197509449",
      "id" : 197509449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223443664100270082",
  "text" : "RT @BibleStdntsSay: \"The message of the Bible gets twisted when we try to or are free to interpret it, thus diluting it.\"  (Multiple Fac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223436552397783040",
    "text" : "\"The message of the Bible gets twisted when we try to or are free to interpret it, thus diluting it.\"  (Multiple Facepalms)",
    "id" : 223436552397783040,
    "created_at" : "2012-07-12 15:20:00 +0000",
    "user" : {
      "name" : "Bible Students Say..",
      "screen_name" : "BibleStdntsSay",
      "protected" : false,
      "id_str" : "197509449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1701408921\/BSS_facepalm_normal.jpg",
      "id" : 197509449,
      "verified" : false
    }
  },
  "id" : 223443664100270082,
  "created_at" : "2012-07-12 15:48:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgia About",
      "screen_name" : "GeorgiaAbout",
      "indices" : [ 53, 66 ],
      "id_str" : "619821507",
      "id" : 619821507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/uN8Jhay2",
      "expanded_url" : "http:\/\/wp.me\/p2rmkB-ox",
      "display_url" : "wp.me\/p2rmkB-ox"
    } ]
  },
  "geo" : { },
  "id_str" : "223436933790056448",
  "text" : "Georgia Loves the Internet! http:\/\/t.co\/uN8Jhay2 via @GeorgiaAbout",
  "id" : 223436933790056448,
  "created_at" : "2012-07-12 15:21:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mohan pande",
      "screen_name" : "DoctorMP",
      "indices" : [ 3, 12 ],
      "id_str" : "60193717",
      "id" : 60193717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223428928365264897",
  "text" : "RT @DoctorMP: There is no pot of gold in end of life journey.The journey is the reward.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223427542009397248",
    "text" : "There is no pot of gold in end of life journey.The journey is the reward.",
    "id" : 223427542009397248,
    "created_at" : "2012-07-12 14:44:11 +0000",
    "user" : {
      "name" : "mohan pande",
      "screen_name" : "DoctorMP",
      "protected" : false,
      "id_str" : "60193717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459189041506680832\/GETk_w-p_normal.jpeg",
      "id" : 60193717,
      "verified" : false
    }
  },
  "id" : 223428928365264897,
  "created_at" : "2012-07-12 14:49:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marsha",
      "screen_name" : "vistadiva",
      "indices" : [ 3, 13 ],
      "id_str" : "37016783",
      "id" : 37016783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223427552134434816",
  "text" : "RT @vistadiva: Queen fan: \"this guy LOST American Idol?? Who the fuck won..Jesus Christ??\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223419781716525057",
    "text" : "Queen fan: \"this guy LOST American Idol?? Who the fuck won..Jesus Christ??\"",
    "id" : 223419781716525057,
    "created_at" : "2012-07-12 14:13:21 +0000",
    "user" : {
      "name" : "Marsha",
      "screen_name" : "vistadiva",
      "protected" : false,
      "id_str" : "37016783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2164691063\/ZB6K5CAI10645CABKH8PJCAL5LK3SCAUVMDKGCAFGBAZ4CAARKYD1CAAGXNS2CAPY7NWZCAES43AVCA4CT1OWCATFRCW1CANQKHMQCAUOR6QTCAIQLYPPCA0SQT7SCAZW0YGKCAUT5EKCCAHXPDFGCAYUVCMN_normal.jpg",
      "id" : 37016783,
      "verified" : false
    }
  },
  "id" : 223427552134434816,
  "created_at" : "2012-07-12 14:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Che Garman",
      "screen_name" : "AffirmYourLife",
      "indices" : [ 3, 18 ],
      "id_str" : "35741196",
      "id" : 35741196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223426772144893952",
  "text" : "RT @AffirmYourLife: Remember that everyone you meet wears an invisible sign. It reads: Notice me. Make me feel important. - H J Brown  h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/EI1JtC10",
        "expanded_url" : "http:\/\/bit.ly\/keRjK",
        "display_url" : "bit.ly\/keRjK"
      } ]
    },
    "geo" : { },
    "id_str" : "223424922159022081",
    "text" : "Remember that everyone you meet wears an invisible sign. It reads: Notice me. Make me feel important. - H J Brown  http:\/\/t.co\/EI1JtC10",
    "id" : 223424922159022081,
    "created_at" : "2012-07-12 14:33:47 +0000",
    "user" : {
      "name" : "Che Garman",
      "screen_name" : "AffirmYourLife",
      "protected" : false,
      "id_str" : "35741196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697082102664208385\/s3GB5JEh_normal.jpg",
      "id" : 35741196,
      "verified" : false
    }
  },
  "id" : 223426772144893952,
  "created_at" : "2012-07-12 14:41:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 3, 14 ],
      "id_str" : "94608663",
      "id" : 94608663
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 86, 95 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/0LHcm7xp",
      "expanded_url" : "http:\/\/mashable.com\/2012\/07\/11\/new-york-payphone-hotspot\/",
      "display_url" : "mashable.com\/2012\/07\/11\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223423114707599360",
  "text" : "RT @MEDGESTORE: NYC Is Turning Payphones Into Wi-Fi Hotspots http:\/\/t.co\/0LHcm7xp via @mashable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 70, 79 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/0LHcm7xp",
        "expanded_url" : "http:\/\/mashable.com\/2012\/07\/11\/new-york-payphone-hotspot\/",
        "display_url" : "mashable.com\/2012\/07\/11\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "223422692659970048",
    "text" : "NYC Is Turning Payphones Into Wi-Fi Hotspots http:\/\/t.co\/0LHcm7xp via @mashable",
    "id" : 223422692659970048,
    "created_at" : "2012-07-12 14:24:55 +0000",
    "user" : {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "protected" : false,
      "id_str" : "94608663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684834758027681792\/AxmlNGOl_normal.jpg",
      "id" : 94608663,
      "verified" : false
    }
  },
  "id" : 223423114707599360,
  "created_at" : "2012-07-12 14:26:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223414692167692288",
  "geo" : { },
  "id_str" : "223422778089545728",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool that, to me, is God. the ultimate love, joy, goodness. : )",
  "id" : 223422778089545728,
  "in_reply_to_status_id" : 223414692167692288,
  "created_at" : "2012-07-12 14:25:15 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223415604592394240",
  "geo" : { },
  "id_str" : "223422198151516160",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh no.. ((hugs)) feel better soon!!",
  "id" : 223422198151516160,
  "in_reply_to_status_id" : 223415604592394240,
  "created_at" : "2012-07-12 14:22:57 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223421700530905091",
  "text" : "RT @shanecrash: Wife: we already have a couch.\nMe: not one shaped like the Interprise.\nWife: we don't need one like that.\nMe: yes we do. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223417639819681792",
    "text" : "Wife: we already have a couch.\nMe: not one shaped like the Interprise.\nWife: we don't need one like that.\nMe: yes we do.\nWife: go away.",
    "id" : 223417639819681792,
    "created_at" : "2012-07-12 14:04:50 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 223421700530905091,
  "created_at" : "2012-07-12 14:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 31, 45 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/AK0xPm02",
      "expanded_url" : "http:\/\/tl.gd\/i9iubl",
      "display_url" : "tl.gd\/i9iubl"
    } ]
  },
  "geo" : { },
  "id_str" : "223227310868926466",
  "text" : "sounds like movie \"In Time\" RT @Wylieknowords If Mitt Romney wins, there will be 2 Americas. One will look a lot (cont) http:\/\/t.co\/AK0xPm02",
  "id" : 223227310868926466,
  "created_at" : "2012-07-12 01:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223219999207198720",
  "geo" : { },
  "id_str" : "223224227057238016",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind I adore your avatar! LOL",
  "id" : 223224227057238016,
  "in_reply_to_status_id" : 223219999207198720,
  "created_at" : "2012-07-12 01:16:17 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Kraft, MD",
      "screen_name" : "daniel_kraft",
      "indices" : [ 3, 16 ],
      "id_str" : "17240190",
      "id" : 17240190
    }, {
      "name" : "Philip Low",
      "screen_name" : "PhilipStevenLow",
      "indices" : [ 115, 131 ],
      "id_str" : "18132245",
      "id" : 18132245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/AZYKDfAV",
      "expanded_url" : "http:\/\/www.gizmag.com\/ibrain-stephen-hawking-communicate-brainwaves\/23182\/",
      "display_url" : "gizmag.com\/ibrain-stephen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223223917215617024",
  "text" : "RT @daniel_kraft: iBrain to allow Stephen Hawking to communicate through brainwaves alone http:\/\/t.co\/AZYKDfAV via @philipstevenlow #fut ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philip Low",
        "screen_name" : "PhilipStevenLow",
        "indices" : [ 97, 113 ],
        "id_str" : "18132245",
        "id" : 18132245
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "futuremed",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "singularityu",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/AZYKDfAV",
        "expanded_url" : "http:\/\/www.gizmag.com\/ibrain-stephen-hawking-communicate-brainwaves\/23182\/",
        "display_url" : "gizmag.com\/ibrain-stephen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "223218895027306497",
    "text" : "iBrain to allow Stephen Hawking to communicate through brainwaves alone http:\/\/t.co\/AZYKDfAV via @philipstevenlow #futuremed #singularityu",
    "id" : 223218895027306497,
    "created_at" : "2012-07-12 00:55:06 +0000",
    "user" : {
      "name" : "Daniel Kraft, MD",
      "screen_name" : "daniel_kraft",
      "protected" : false,
      "id_str" : "17240190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63876002\/Kraft-PicColor_normal.jpg",
      "id" : 17240190,
      "verified" : false
    }
  },
  "id" : 223223917215617024,
  "created_at" : "2012-07-12 01:15:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 27, 38 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/iJOSAzia",
      "expanded_url" : "https:\/\/twitter.com\/shanecrash\/status\/223220804488413185\/photo\/1",
      "display_url" : "pic.twitter.com\/iJOSAzia"
    } ]
  },
  "in_reply_to_status_id_str" : "223220804488413185",
  "geo" : { },
  "id_str" : "223223357775155201",
  "in_reply_to_user_id" : 25030624,
  "text" : "omg.. is that real? o-O RT @shanecrash This photo is my life since telling people I don't have faith. http:\/\/t.co\/iJOSAzia",
  "id" : 223223357775155201,
  "in_reply_to_status_id" : 223220804488413185,
  "created_at" : "2012-07-12 01:12:50 +0000",
  "in_reply_to_screen_name" : "shanecrash",
  "in_reply_to_user_id_str" : "25030624",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223216905576656898",
  "text" : "RT @TheGoldenMirror: Those who sooner learn the lessons hard times bring, sooner find their way back out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "223208628545531906",
    "text" : "Those who sooner learn the lessons hard times bring, sooner find their way back out.",
    "id" : 223208628545531906,
    "created_at" : "2012-07-12 00:14:18 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 223216905576656898,
  "created_at" : "2012-07-12 00:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hank",
      "screen_name" : "hankgolfer",
      "indices" : [ 0, 11 ],
      "id_str" : "149851544",
      "id" : 149851544
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 77, 91 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "wrong",
      "screen_name" : "YoureWrongSorry",
      "indices" : [ 92, 108 ],
      "id_str" : "623155729",
      "id" : 623155729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223159227512922112",
  "geo" : { },
  "id_str" : "223215949908684801",
  "in_reply_to_user_id" : 149851544,
  "text" : "@hankgolfer thats all any of us can do.. follow our own path as best we can. @BibleAlsoSays @YoureWrongSorry",
  "id" : 223215949908684801,
  "in_reply_to_status_id" : 223159227512922112,
  "created_at" : "2012-07-12 00:43:24 +0000",
  "in_reply_to_screen_name" : "hankgolfer",
  "in_reply_to_user_id_str" : "149851544",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 60, 70 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/9vdoua1i",
      "expanded_url" : "http:\/\/shar.es\/tv4ie",
      "display_url" : "shar.es\/tv4ie"
    } ]
  },
  "geo" : { },
  "id_str" : "223122453361201154",
  "text" : "Rescued Raccoon is One Happy Fella http:\/\/t.co\/9vdoua1i via @sharethis",
  "id" : 223122453361201154,
  "created_at" : "2012-07-11 18:31:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/GCTmGfpx",
      "expanded_url" : "http:\/\/bit.ly\/MyWdQx",
      "display_url" : "bit.ly\/MyWdQx"
    } ]
  },
  "geo" : { },
  "id_str" : "223056041938653185",
  "text" : "Nice! &gt;&gt; Amazing baby bird pictures http:\/\/t.co\/GCTmGfpx",
  "id" : 223056041938653185,
  "created_at" : "2012-07-11 14:07:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/YBzG2yFK",
      "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/2012\/07\/when-your-family-is-one-suffering.html?spref=tw",
      "display_url" : "thesimpleboxcar.com\/2012\/07\/when-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223035600318631938",
  "text" : "RT @AniKnits: \u007Bblogged\u007D The Simple Boxcar: When Your Family is the One Suffering... http:\/\/t.co\/YBzG2yFK (please RT &amp; share.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/YBzG2yFK",
        "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/2012\/07\/when-your-family-is-one-suffering.html?spref=tw",
        "display_url" : "thesimpleboxcar.com\/2012\/07\/when-y\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "223034040687661056",
    "text" : "\u007Bblogged\u007D The Simple Boxcar: When Your Family is the One Suffering... http:\/\/t.co\/YBzG2yFK (please RT &amp; share.)",
    "id" : 223034040687661056,
    "created_at" : "2012-07-11 12:40:33 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 223035600318631938,
  "created_at" : "2012-07-11 12:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/ArQb6T2H",
      "expanded_url" : "http:\/\/tinyurl.com\/6p8z43y",
      "display_url" : "tinyurl.com\/6p8z43y"
    } ]
  },
  "geo" : { },
  "id_str" : "223033368302977024",
  "text" : "RT @Seeds4Parents: There aren't any illegal Human Beings as far as I'm concerned. D Kucinich, http:\/\/t.co\/ArQb6T2H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/ArQb6T2H",
        "expanded_url" : "http:\/\/tinyurl.com\/6p8z43y",
        "display_url" : "tinyurl.com\/6p8z43y"
      } ]
    },
    "geo" : { },
    "id_str" : "223030392834367488",
    "text" : "There aren't any illegal Human Beings as far as I'm concerned. D Kucinich, http:\/\/t.co\/ArQb6T2H",
    "id" : 223030392834367488,
    "created_at" : "2012-07-11 12:26:04 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 223033368302977024,
  "created_at" : "2012-07-11 12:37:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/DfRns6uw",
      "expanded_url" : "http:\/\/jimmccormac.blogspot.com\/2012\/07\/juvenile-turkey-vultures-so-ugly-theyre.html",
      "display_url" : "jimmccormac.blogspot.com\/2012\/07\/juveni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223033025389268993",
  "text" : "awww! &gt;&gt; Juvenile Turkey Vultures: so ugly, they're... ugly: http:\/\/t.co\/DfRns6uw",
  "id" : 223033025389268993,
  "created_at" : "2012-07-11 12:36:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 53, 64 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222863746224226305",
  "text" : "RT @GaribaldiRous: Happy Caplin Day! Please remember @caplinrous by eating a Popsicle or some yogurt.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caplin Rous",
        "screen_name" : "CaplinROUS",
        "indices" : [ 34, 45 ],
        "id_str" : "18840386",
        "id" : 18840386
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222680190722129921",
    "text" : "Happy Caplin Day! Please remember @caplinrous by eating a Popsicle or some yogurt.",
    "id" : 222680190722129921,
    "created_at" : "2012-07-10 13:14:29 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 222863746224226305,
  "created_at" : "2012-07-11 01:23:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/aQSwh6cW",
      "expanded_url" : "http:\/\/icont.ac\/19M2M",
      "display_url" : "icont.ac\/19M2M"
    } ]
  },
  "geo" : { },
  "id_str" : "222863608097411073",
  "text" : "RT @GaribaldiRous: Today is Caplin Day. http:\/\/t.co\/aQSwh6cW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.icontact.com\" rel=\"nofollow\"\u003EiContact's Social Tools\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/aQSwh6cW",
        "expanded_url" : "http:\/\/icont.ac\/19M2M",
        "display_url" : "icont.ac\/19M2M"
      } ]
    },
    "geo" : { },
    "id_str" : "222858263518117888",
    "text" : "Today is Caplin Day. http:\/\/t.co\/aQSwh6cW",
    "id" : 222858263518117888,
    "created_at" : "2012-07-11 01:02:05 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 222863608097411073,
  "created_at" : "2012-07-11 01:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringNickHome",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222863055007137794",
  "text" : "RT @AniKnits: Nick isn't home. #BringNickHome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringNickHome",
        "indices" : [ 17, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222860909775822848",
    "text" : "Nick isn't home. #BringNickHome",
    "id" : 222860909775822848,
    "created_at" : "2012-07-11 01:12:36 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 222863055007137794,
  "created_at" : "2012-07-11 01:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 11, 20 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringNickHome",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/2tBgPcJh",
      "expanded_url" : "http:\/\/ow.ly\/1Ofpdc",
      "display_url" : "ow.ly\/1Ofpdc"
    } ]
  },
  "in_reply_to_status_id_str" : "222861460924141569",
  "geo" : { },
  "id_str" : "222862489925337089",
  "in_reply_to_user_id" : 184401626,
  "text" : "WHAT??? RT @AniKnits The judge found he was not abused or neglected but \"dependent.\" http:\/\/t.co\/2tBgPcJh #BringNickHome",
  "id" : 222862489925337089,
  "in_reply_to_status_id" : 222861460924141569,
  "created_at" : "2012-07-11 01:18:52 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/BgzFfLFZ",
      "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/11508884-voyage-of-purpose",
      "display_url" : "goodreads.com\/book\/show\/1150\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222838950740504576",
  "text" : "RT @DharmaTalks: Summer Book Giveaway (only 2 days left) for Voyage of Purpose ~ Win a Copy  http:\/\/t.co\/BgzFfLFZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/BgzFfLFZ",
        "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/11508884-voyage-of-purpose",
        "display_url" : "goodreads.com\/book\/show\/1150\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "222837647599599619",
    "text" : "Summer Book Giveaway (only 2 days left) for Voyage of Purpose ~ Win a Copy  http:\/\/t.co\/BgzFfLFZ",
    "id" : 222837647599599619,
    "created_at" : "2012-07-10 23:40:09 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 222838950740504576,
  "created_at" : "2012-07-10 23:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222821058602991616",
  "text" : "RT @ShipsofSong: You are an eternal consciousness in a momentary thought.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222820844789964800",
    "text" : "You are an eternal consciousness in a momentary thought.",
    "id" : 222820844789964800,
    "created_at" : "2012-07-10 22:33:23 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 222821058602991616,
  "created_at" : "2012-07-10 22:34:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 0, 15 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "Andrew Wilson",
      "screen_name" : "Stooshie",
      "indices" : [ 63, 72 ],
      "id_str" : "6598362",
      "id" : 6598362
    }, {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 73, 88 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "Tom",
      "screen_name" : "TomEcho6",
      "indices" : [ 89, 98 ],
      "id_str" : "37208927",
      "id" : 37208927
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 99, 113 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "oscar eduardo",
      "screen_name" : "oskar78",
      "indices" : [ 114, 122 ],
      "id_str" : "733588182",
      "id" : 733588182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222789167581626369",
  "geo" : { },
  "id_str" : "222818873609699328",
  "in_reply_to_user_id" : 544382308,
  "text" : "@GospelGuidance we all have worldview bias as we r each unique @Stooshie @TheAtheistFool @TomEcho6 @BibleAlsoSays @Oskar78",
  "id" : 222818873609699328,
  "in_reply_to_status_id" : 222789167581626369,
  "created_at" : "2012-07-10 22:25:33 +0000",
  "in_reply_to_screen_name" : "GospelGuidance",
  "in_reply_to_user_id_str" : "544382308",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wilson",
      "screen_name" : "Stooshie",
      "indices" : [ 0, 9 ],
      "id_str" : "6598362",
      "id" : 6598362
    }, {
      "name" : "Hank",
      "screen_name" : "hankgolfer",
      "indices" : [ 49, 60 ],
      "id_str" : "149851544",
      "id" : 149851544
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 61, 76 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 77, 91 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 92, 107 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222809544630341634",
  "geo" : { },
  "id_str" : "222817897620312064",
  "in_reply_to_user_id" : 6598362,
  "text" : "@Stooshie sounds like you have a heart 4 ppl : ) @hankgolfer @GospelGuidance @BibleAlsoSays @TheAtheistFool",
  "id" : 222817897620312064,
  "in_reply_to_status_id" : 222809544630341634,
  "created_at" : "2012-07-10 22:21:41 +0000",
  "in_reply_to_screen_name" : "Stooshie",
  "in_reply_to_user_id_str" : "6598362",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wilson",
      "screen_name" : "Stooshie",
      "indices" : [ 0, 9 ],
      "id_str" : "6598362",
      "id" : 6598362
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 10, 25 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "Fat Jacques",
      "screen_name" : "Fat_Jacques",
      "indices" : [ 26, 38 ],
      "id_str" : "184160423",
      "id" : 184160423
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 39, 51 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222805684104859648",
  "geo" : { },
  "id_str" : "222817582674223108",
  "in_reply_to_user_id" : 6598362,
  "text" : "@Stooshie @GospelGuidance @Fat_Jacques @VirgoJohnny bcuz we r all unique w own perceptions",
  "id" : 222817582674223108,
  "in_reply_to_status_id" : 222805684104859648,
  "created_at" : "2012-07-10 22:20:26 +0000",
  "in_reply_to_screen_name" : "Stooshie",
  "in_reply_to_user_id_str" : "6598362",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222813197323874305",
  "text" : "feel ill after looking up sea urchins and ended up on youtube and saw icky stuff... bleh..",
  "id" : 222813197323874305,
  "created_at" : "2012-07-10 22:03:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Sashuk",
      "screen_name" : "StockTradeCoach",
      "indices" : [ 3, 19 ],
      "id_str" : "30295186",
      "id" : 30295186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222766516746194944",
  "text" : "RT @StockTradeCoach: The Circle of Money 2012 Group Stock Trade Training Program starts today ,,, you can start immediately go here ...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/9KuPGT86",
        "expanded_url" : "http:\/\/thecircleofmoney.com\/JOIN",
        "display_url" : "thecircleofmoney.com\/JOIN"
      } ]
    },
    "geo" : { },
    "id_str" : "222766258477740032",
    "text" : "The Circle of Money 2012 Group Stock Trade Training Program starts today ,,, you can start immediately go here ... http:\/\/t.co\/9KuPGT86",
    "id" : 222766258477740032,
    "created_at" : "2012-07-10 18:56:29 +0000",
    "user" : {
      "name" : "Brian Sashuk",
      "screen_name" : "StockTradeCoach",
      "protected" : false,
      "id_str" : "30295186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485310297\/DSC00036_normal.JPG",
      "id" : 30295186,
      "verified" : false
    }
  },
  "id" : 222766516746194944,
  "created_at" : "2012-07-10 18:57:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gardasil",
      "screen_name" : "GardasilNews",
      "indices" : [ 3, 16 ],
      "id_str" : "401133245",
      "id" : 401133245
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gardasil",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "vaccine",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/IK4hM6Ga",
      "expanded_url" : "http:\/\/truthaboutgardasil.org",
      "display_url" : "truthaboutgardasil.org"
    } ]
  },
  "in_reply_to_status_id_str" : "222745481787359232",
  "geo" : { },
  "id_str" : "222764442033725440",
  "in_reply_to_user_id" : 401133245,
  "text" : "RT @GardasilNews tell them to go to http:\/\/t.co\/IK4hM6Ga IF You get #Gardasil u should research it, almost killed my daughter #vaccine",
  "id" : 222764442033725440,
  "in_reply_to_status_id" : 222745481787359232,
  "created_at" : "2012-07-10 18:49:16 +0000",
  "in_reply_to_screen_name" : "GardasilNews",
  "in_reply_to_user_id_str" : "401133245",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DuckDuckGo",
      "screen_name" : "duckduckgo",
      "indices" : [ 3, 14 ],
      "id_str" : "14504859",
      "id" : 14504859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222733682560081920",
  "text" : "RT @duckduckgo: We don't have to settle with the FTC because we already protect your privacy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222732606893068289",
    "text" : "We don't have to settle with the FTC because we already protect your privacy.",
    "id" : 222732606893068289,
    "created_at" : "2012-07-10 16:42:46 +0000",
    "user" : {
      "name" : "DuckDuckGo",
      "screen_name" : "duckduckgo",
      "protected" : false,
      "id_str" : "14504859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467502291415617536\/SP8_ylk9_normal.png",
      "id" : 14504859,
      "verified" : true
    }
  },
  "id" : 222733682560081920,
  "created_at" : "2012-07-10 16:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222732814121046016",
  "geo" : { },
  "id_str" : "222733443354730496",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott its wonderful. dropped a lot of baggage. still have a wee bit of baggage but its shrinking..lol",
  "id" : 222733443354730496,
  "in_reply_to_status_id" : 222732814121046016,
  "created_at" : "2012-07-10 16:46:05 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222731927835262976",
  "text" : "once I realized that there would ALWAYS be someone unhappy with me, it opened up my world! woohoo!",
  "id" : 222731927835262976,
  "created_at" : "2012-07-10 16:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222729827583664130",
  "text" : "no matter what you think, feel, believe, perceive, there will be someone who is against it. those ppl don't matter 2U.",
  "id" : 222729827583664130,
  "created_at" : "2012-07-10 16:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 2, 12 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222728746417922048",
  "geo" : { },
  "id_str" : "222729426121654272",
  "in_reply_to_user_id" : 48215218,
  "text" : ". @bend_time becuz I dont trust gardasil vaccine.. someone said it was child abuse 4 not giving it 2 my DD.. ppl r weird..",
  "id" : 222729426121654272,
  "in_reply_to_status_id" : 222728746417922048,
  "created_at" : "2012-07-10 16:30:07 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pre-Crisis CS999",
      "screen_name" : "CS999",
      "indices" : [ 3, 9 ],
      "id_str" : "29586953",
      "id" : 29586953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222728759676108801",
  "text" : "RT @CS999: Not to disappoint anyone, but the only thing on my Official Gay Agenda Checklist for today is buying a new tennis racquet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222726284118208512",
    "text" : "Not to disappoint anyone, but the only thing on my Official Gay Agenda Checklist for today is buying a new tennis racquet",
    "id" : 222726284118208512,
    "created_at" : "2012-07-10 16:17:38 +0000",
    "user" : {
      "name" : "Pre-Crisis CS999",
      "screen_name" : "CS999",
      "protected" : false,
      "id_str" : "29586953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696100325279735810\/ecmI0euY_normal.jpg",
      "id" : 29586953,
      "verified" : false
    }
  },
  "id" : 222728759676108801,
  "created_at" : "2012-07-10 16:27:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "indices" : [ 3, 13 ],
      "id_str" : "22380908",
      "id" : 22380908
    }, {
      "name" : "Lori D.",
      "screen_name" : "AQuietWeek",
      "indices" : [ 73, 84 ],
      "id_str" : "19838924",
      "id" : 19838924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/qqOzWorh",
      "expanded_url" : "http:\/\/wp.me\/p1B10T-12v",
      "display_url" : "wp.me\/p1B10T-12v"
    } ]
  },
  "geo" : { },
  "id_str" : "222724889533095936",
  "text" : "RT @BethLayne: How To Be Friends with an Aspie: http:\/\/t.co\/qqOzWorh via @AQuietWeek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lori D.",
        "screen_name" : "AQuietWeek",
        "indices" : [ 58, 69 ],
        "id_str" : "19838924",
        "id" : 19838924
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/qqOzWorh",
        "expanded_url" : "http:\/\/wp.me\/p1B10T-12v",
        "display_url" : "wp.me\/p1B10T-12v"
      } ]
    },
    "geo" : { },
    "id_str" : "222723982091239424",
    "text" : "How To Be Friends with an Aspie: http:\/\/t.co\/qqOzWorh via @AQuietWeek",
    "id" : 222723982091239424,
    "created_at" : "2012-07-10 16:08:30 +0000",
    "user" : {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "protected" : false,
      "id_str" : "22380908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796841124904116224\/6H0GAfoZ_normal.jpg",
      "id" : 22380908,
      "verified" : false
    }
  },
  "id" : 222724889533095936,
  "created_at" : "2012-07-10 16:12:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "indices" : [ 3, 13 ],
      "id_str" : "17052345",
      "id" : 17052345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222716676825812994",
  "text" : "RT @TedDekker: All spiritual truths, until they are personally encountered, are hearsay.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222689143682109442",
    "text" : "All spiritual truths, until they are personally encountered, are hearsay.",
    "id" : 222689143682109442,
    "created_at" : "2012-07-10 13:50:03 +0000",
    "user" : {
      "name" : "Ted Dekker",
      "screen_name" : "TedDekker",
      "protected" : false,
      "id_str" : "17052345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742685559\/Picture_2_normal.png",
      "id" : 17052345,
      "verified" : false
    }
  },
  "id" : 222716676825812994,
  "created_at" : "2012-07-10 15:39:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 0, 15 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "Andrew Wilson",
      "screen_name" : "Stooshie",
      "indices" : [ 16, 25 ],
      "id_str" : "6598362",
      "id" : 6598362
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 26, 38 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222712317039751169",
  "geo" : { },
  "id_str" : "222713930538156032",
  "in_reply_to_user_id" : 544382308,
  "text" : "@GospelGuidance @Stooshie @VirgoJohnny then where does their lovingness come from? most atheists I know have lovingness.",
  "id" : 222713930538156032,
  "in_reply_to_status_id" : 222712317039751169,
  "created_at" : "2012-07-10 15:28:33 +0000",
  "in_reply_to_screen_name" : "GospelGuidance",
  "in_reply_to_user_id_str" : "544382308",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222713099604606976",
  "text" : "RT @Rodd4Real: I have nothing to hide... I am who I am... Bruises, Scars and Bumps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222712459566395393",
    "text" : "I have nothing to hide... I am who I am... Bruises, Scars and Bumps",
    "id" : 222712459566395393,
    "created_at" : "2012-07-10 15:22:42 +0000",
    "user" : {
      "name" : "Rodd Cruz",
      "screen_name" : "ItsYaBoyRodd",
      "protected" : false,
      "id_str" : "21929308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799436282309046272\/bWYxsyqQ_normal.jpg",
      "id" : 21929308,
      "verified" : false
    }
  },
  "id" : 222713099604606976,
  "created_at" : "2012-07-10 15:25:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 48, 63 ],
      "id_str" : "544382308",
      "id" : 544382308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222710866846560256",
  "geo" : { },
  "id_str" : "222711447996743680",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny perhaps becuz the laws dont matter @gospelguidance",
  "id" : 222711447996743680,
  "in_reply_to_status_id" : 222710866846560256,
  "created_at" : "2012-07-10 15:18:41 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/QL7lcWtR",
      "expanded_url" : "http:\/\/goo.gl\/fb\/3XnIg",
      "display_url" : "goo.gl\/fb\/3XnIg"
    } ]
  },
  "geo" : { },
  "id_str" : "222710284152864768",
  "text" : "RT @grouchypuppy: Sharing: More companies letting pets join employees on the job http:\/\/t.co\/QL7lcWtR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/QL7lcWtR",
        "expanded_url" : "http:\/\/goo.gl\/fb\/3XnIg",
        "display_url" : "goo.gl\/fb\/3XnIg"
      } ]
    },
    "geo" : { },
    "id_str" : "222709620639154176",
    "text" : "Sharing: More companies letting pets join employees on the job http:\/\/t.co\/QL7lcWtR",
    "id" : 222709620639154176,
    "created_at" : "2012-07-10 15:11:25 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 222710284152864768,
  "created_at" : "2012-07-10 15:14:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Have No Doubt",
      "screen_name" : "haveNOdoubt",
      "indices" : [ 3, 15 ],
      "id_str" : "25725048",
      "id" : 25725048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222710250892042240",
  "text" : "RT @haveNOdoubt: Have no doubt...you are meant to enjoy this journey.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222709546467065856",
    "text" : "Have no doubt...you are meant to enjoy this journey.",
    "id" : 222709546467065856,
    "created_at" : "2012-07-10 15:11:08 +0000",
    "user" : {
      "name" : "Have No Doubt",
      "screen_name" : "haveNOdoubt",
      "protected" : false,
      "id_str" : "25725048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883464239\/bald-eagle-wings-soar_normal.jpg",
      "id" : 25725048,
      "verified" : false
    }
  },
  "id" : 222710250892042240,
  "created_at" : "2012-07-10 15:13:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 60, 75 ],
      "id_str" : "544382308",
      "id" : 544382308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222708858760597504",
  "geo" : { },
  "id_str" : "222709912113905665",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny obedience or else.. sounds like dictatorship.. @Gospelguidance",
  "id" : 222709912113905665,
  "in_reply_to_status_id" : 222708858760597504,
  "created_at" : "2012-07-10 15:12:35 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "148Apps",
      "screen_name" : "148Apps",
      "indices" : [ 3, 11 ],
      "id_str" : "15600475",
      "id" : 15600475
    }, {
      "name" : "Ticci MacStories",
      "screen_name" : "macstories",
      "indices" : [ 120, 131 ],
      "id_str" : "33573625",
      "id" : 33573625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/NM5UKsnL",
      "expanded_url" : "http:\/\/Walmart.com",
      "display_url" : "Walmart.com"
    } ]
  },
  "geo" : { },
  "id_str" : "222709411616006144",
  "text" : "RT @148Apps: iTunes Gift Cards on sale at http:\/\/t.co\/NM5UKsnL (electronic delivery) - $100 for $85, $50 for $45 - via: @MacStories http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ticci MacStories",
        "screen_name" : "macstories",
        "indices" : [ 107, 118 ],
        "id_str" : "33573625",
        "id" : 33573625
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/NM5UKsnL",
        "expanded_url" : "http:\/\/Walmart.com",
        "display_url" : "Walmart.com"
      }, {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/HMgdAhZf",
        "expanded_url" : "http:\/\/www.macstories.net\/mac\/macstoriesdeals-monday-62\/",
        "display_url" : "macstories.net\/mac\/macstories\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "222707690156212224",
    "text" : "iTunes Gift Cards on sale at http:\/\/t.co\/NM5UKsnL (electronic delivery) - $100 for $85, $50 for $45 - via: @MacStories http:\/\/t.co\/HMgdAhZf",
    "id" : 222707690156212224,
    "created_at" : "2012-07-10 15:03:45 +0000",
    "user" : {
      "name" : "148Apps",
      "screen_name" : "148Apps",
      "protected" : false,
      "id_str" : "15600475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654323790545993728\/XrcMdHjm_normal.jpg",
      "id" : 15600475,
      "verified" : false
    }
  },
  "id" : 222709411616006144,
  "created_at" : "2012-07-10 15:10:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Chatterley",
      "screen_name" : "Nufkin",
      "indices" : [ 3, 10 ],
      "id_str" : "26000138",
      "id" : 26000138
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 12, 27 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 28, 40 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222708994089824256",
  "text" : "RT @Nufkin: @GospelGuidance @VirgoJohnny punishes justly? Can you think of any crime where you would torture the person for ever?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gospel Guidance",
        "screen_name" : "GospelGuidance",
        "indices" : [ 0, 15 ],
        "id_str" : "544382308",
        "id" : 544382308
      }, {
        "name" : "Bad Hombre Juanito",
        "screen_name" : "VirgoJohnny",
        "indices" : [ 16, 28 ],
        "id_str" : "51880276",
        "id" : 51880276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "222705766111526913",
    "geo" : { },
    "id_str" : "222708024379322369",
    "in_reply_to_user_id" : 544382308,
    "text" : "@GospelGuidance @VirgoJohnny punishes justly? Can you think of any crime where you would torture the person for ever?",
    "id" : 222708024379322369,
    "in_reply_to_status_id" : 222705766111526913,
    "created_at" : "2012-07-10 15:05:05 +0000",
    "in_reply_to_screen_name" : "GospelGuidance",
    "in_reply_to_user_id_str" : "544382308",
    "user" : {
      "name" : "Mark Chatterley",
      "screen_name" : "Nufkin",
      "protected" : false,
      "id_str" : "26000138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570565377157148673\/Ft9ycJUl_normal.jpeg",
      "id" : 26000138,
      "verified" : false
    }
  },
  "id" : 222708994089824256,
  "created_at" : "2012-07-10 15:08:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 13, 28 ],
      "id_str" : "544382308",
      "id" : 544382308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222705112752205824",
  "geo" : { },
  "id_str" : "222705910118760448",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny @Gospelguidance we love becuz we are love. its where we came from and where we go when done here.",
  "id" : 222705910118760448,
  "in_reply_to_status_id" : 222705112752205824,
  "created_at" : "2012-07-10 14:56:41 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gospel Guidance",
      "screen_name" : "GospelGuidance",
      "indices" : [ 0, 15 ],
      "id_str" : "544382308",
      "id" : 544382308
    }, {
      "name" : "Tom",
      "screen_name" : "TomEcho6",
      "indices" : [ 16, 25 ],
      "id_str" : "37208927",
      "id" : 37208927
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 26, 38 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 39, 53 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Hank",
      "screen_name" : "hankgolfer",
      "indices" : [ 54, 65 ],
      "id_str" : "149851544",
      "id" : 149851544
    }, {
      "name" : "oscar eduardo",
      "screen_name" : "oskar78",
      "indices" : [ 66, 74 ],
      "id_str" : "733588182",
      "id" : 733588182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222702052021780481",
  "geo" : { },
  "id_str" : "222703847108378624",
  "in_reply_to_user_id" : 544382308,
  "text" : "@GospelGuidance @TomEcho6 @VirgoJohnny @BibleAlsoSays @hankgolfer @Oskar78 what did he create from? must be creator and the created...",
  "id" : 222703847108378624,
  "in_reply_to_status_id" : 222702052021780481,
  "created_at" : "2012-07-10 14:48:29 +0000",
  "in_reply_to_screen_name" : "GospelGuidance",
  "in_reply_to_user_id_str" : "544382308",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222701700530708481",
  "text" : "RT @lisarobbinyoung: Just heard my teenage son tell his girlfriend \"My mom's a badass.\" I've trained him well. :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222701415519363073",
    "text" : "Just heard my teenage son tell his girlfriend \"My mom's a badass.\" I've trained him well. :-)",
    "id" : 222701415519363073,
    "created_at" : "2012-07-10 14:38:49 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 222701700530708481,
  "created_at" : "2012-07-10 14:39:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "indices" : [ 3, 19 ],
      "id_str" : "29251361",
      "id" : 29251361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fact",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222682348938989569",
  "text" : "RT @WorldOfJoeRiggs: #Fact When people ask me 'what's todays date?' I almost always answer with \"I don't keep up, it changes every day.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fact",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222679104212844545",
    "text" : "#Fact When people ask me 'what's todays date?' I almost always answer with \"I don't keep up, it changes every day.\"",
    "id" : 222679104212844545,
    "created_at" : "2012-07-10 13:10:10 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 222682348938989569,
  "created_at" : "2012-07-10 13:23:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/JJeekXxp",
      "expanded_url" : "http:\/\/via.me\/-2w8rnvc",
      "display_url" : "via.me\/-2w8rnvc"
    } ]
  },
  "geo" : { },
  "id_str" : "222515432509292544",
  "text" : "Hubby making a new friend http:\/\/t.co\/JJeekXxp",
  "id" : 222515432509292544,
  "created_at" : "2012-07-10 02:19:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222509289451954176",
  "text" : "hubby made a friend with the raccoon tonight : )",
  "id" : 222509289451954176,
  "created_at" : "2012-07-10 01:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222509097981976578",
  "text" : "sea urchin on master chef tonight.. ick. they were beautiful creatures.",
  "id" : 222509097981976578,
  "created_at" : "2012-07-10 01:54:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "indices" : [ 3, 17 ],
      "id_str" : "37490555",
      "id" : 37490555
    }, {
      "name" : "Vicki Cook",
      "screen_name" : "vscook",
      "indices" : [ 80, 87 ],
      "id_str" : "161021600",
      "id" : 161021600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/yA6Skv1w",
      "expanded_url" : "http:\/\/goo.gl\/w9QvA",
      "display_url" : "goo.gl\/w9QvA"
    } ]
  },
  "geo" : { },
  "id_str" : "222466934682292225",
  "text" : "RT @doggiestylish: Dogs May Grieve as Deeply as Humans http:\/\/t.co\/yA6Skv1w via @vscook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vicki Cook",
        "screen_name" : "vscook",
        "indices" : [ 61, 68 ],
        "id_str" : "161021600",
        "id" : 161021600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/yA6Skv1w",
        "expanded_url" : "http:\/\/goo.gl\/w9QvA",
        "display_url" : "goo.gl\/w9QvA"
      } ]
    },
    "geo" : { },
    "id_str" : "222462675664379906",
    "text" : "Dogs May Grieve as Deeply as Humans http:\/\/t.co\/yA6Skv1w via @vscook",
    "id" : 222462675664379906,
    "created_at" : "2012-07-09 22:50:09 +0000",
    "user" : {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "protected" : false,
      "id_str" : "37490555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466092491\/jersey_normal.jpg",
      "id" : 37490555,
      "verified" : false
    }
  },
  "id" : 222466934682292225,
  "created_at" : "2012-07-09 23:07:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Julie Sharp",
      "screen_name" : "TexasJul",
      "indices" : [ 17, 26 ],
      "id_str" : "18554346",
      "id" : 18554346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222466436600311808",
  "text" : "RT @mindymayhem: @TexasJul \"Enjoy hell\"... Isn't that precious? Is there anything truly more xian, than deriving pleasure from someone's ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Sharp",
        "screen_name" : "TexasJul",
        "indices" : [ 0, 9 ],
        "id_str" : "18554346",
        "id" : 18554346
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "222456147309887488",
    "geo" : { },
    "id_str" : "222458482991955971",
    "in_reply_to_user_id" : 18554346,
    "text" : "@TexasJul \"Enjoy hell\"... Isn't that precious? Is there anything truly more xian, than deriving pleasure from someone's eternal torture? LOL",
    "id" : 222458482991955971,
    "in_reply_to_status_id" : 222456147309887488,
    "created_at" : "2012-07-09 22:33:30 +0000",
    "in_reply_to_screen_name" : "TexasJul",
    "in_reply_to_user_id_str" : "18554346",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 222466436600311808,
  "created_at" : "2012-07-09 23:05:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222425883770753025",
  "text" : "got a headache and im out of sorts... : (",
  "id" : 222425883770753025,
  "created_at" : "2012-07-09 20:23:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/qCiaWsM3",
      "expanded_url" : "http:\/\/fb.me\/W60EG8k1",
      "display_url" : "fb.me\/W60EG8k1"
    } ]
  },
  "geo" : { },
  "id_str" : "222403296177037314",
  "text" : "RT @theCheapK: Use code HEARTMP3 to get $2 credit! http:\/\/t.co\/qCiaWsM3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/qCiaWsM3",
        "expanded_url" : "http:\/\/fb.me\/W60EG8k1",
        "display_url" : "fb.me\/W60EG8k1"
      } ]
    },
    "geo" : { },
    "id_str" : "222401850245255170",
    "text" : "Use code HEARTMP3 to get $2 credit! http:\/\/t.co\/qCiaWsM3",
    "id" : 222401850245255170,
    "created_at" : "2012-07-09 18:48:27 +0000",
    "user" : {
      "name" : "April Floyd, Author",
      "screen_name" : "aprilkfloyd",
      "protected" : false,
      "id_str" : "350693950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649333742230614016\/xmMNuuIj_normal.jpg",
      "id" : 350693950,
      "verified" : false
    }
  },
  "id" : 222403296177037314,
  "created_at" : "2012-07-09 18:54:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222401751276462080",
  "text" : "DD is pissed at me...",
  "id" : 222401751276462080,
  "created_at" : "2012-07-09 18:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222318276619927553",
  "text" : "RT @TyrusBooks: Those of you with Kindles should pick up Robert Ward's RED BAKER (free). Classic book, new intro from Daniel Woodrell -  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/WP9WznQo",
        "expanded_url" : "http:\/\/amzn.to\/MNDbeP",
        "display_url" : "amzn.to\/MNDbeP"
      } ]
    },
    "geo" : { },
    "id_str" : "222317382021033984",
    "text" : "Those of you with Kindles should pick up Robert Ward's RED BAKER (free). Classic book, new intro from Daniel Woodrell - http:\/\/t.co\/WP9WznQo",
    "id" : 222317382021033984,
    "created_at" : "2012-07-09 13:12:48 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 222318276619927553,
  "created_at" : "2012-07-09 13:16:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222314183126036481",
  "text" : "this keek thing could be fun. i'd love to see my tweeps use it! : )",
  "id" : 222314183126036481,
  "created_at" : "2012-07-09 13:00:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 0, 12 ],
      "id_str" : "261888721",
      "id" : 261888721
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 75, 86 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222312243579199488",
  "geo" : { },
  "id_str" : "222313363034746880",
  "in_reply_to_user_id" : 17592150,
  "text" : "@tommysalami just started it a few days ago..lol.. but love it already : ) @tyrusbooks",
  "id" : 222313363034746880,
  "in_reply_to_status_id" : 222312243579199488,
  "created_at" : "2012-07-09 12:56:50 +0000",
  "in_reply_to_screen_name" : "thomaspluck",
  "in_reply_to_user_id_str" : "17592150",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 24, 36 ],
      "id_str" : "261888721",
      "id" : 261888721
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 55, 66 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/kdCQg2Rr",
      "expanded_url" : "http:\/\/www.keek.com\/!9zHkaab",
      "display_url" : "keek.com\/!9zHkaab"
    } ]
  },
  "geo" : { },
  "id_str" : "222311926267527168",
  "text" : "Thanks to Thomas Pluck (@tommysalami) and Tyrus Books (@tyrusbooks) for book. http:\/\/t.co\/kdCQg2Rr",
  "id" : 222311926267527168,
  "created_at" : "2012-07-09 12:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Birkenmeyer",
      "screen_name" : "metalpalace",
      "indices" : [ 3, 15 ],
      "id_str" : "17779151",
      "id" : 17779151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222307859516502016",
  "text" : "RT @metalpalace: What you feed will flourish, what you neglect will die.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222298682748448768",
    "text" : "What you feed will flourish, what you neglect will die.",
    "id" : 222298682748448768,
    "created_at" : "2012-07-09 11:58:30 +0000",
    "user" : {
      "name" : "Tom Birkenmeyer",
      "screen_name" : "metalpalace",
      "protected" : false,
      "id_str" : "17779151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639148341163655168\/mmdvcmQf_normal.jpg",
      "id" : 17779151,
      "verified" : false
    }
  },
  "id" : 222307859516502016,
  "created_at" : "2012-07-09 12:34:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222307442703335424",
  "text" : "RT @TheGoldenMirror: Don't promote the path you took. Help others find their own way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222302463917690881",
    "text" : "Don't promote the path you took. Help others find their own way.",
    "id" : 222302463917690881,
    "created_at" : "2012-07-09 12:13:32 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 222307442703335424,
  "created_at" : "2012-07-09 12:33:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222145385769086976",
  "geo" : { },
  "id_str" : "222146066382991362",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth feel better soon ((hugs))",
  "id" : 222146066382991362,
  "in_reply_to_status_id" : 222145385769086976,
  "created_at" : "2012-07-09 01:52:04 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.keek.com\" rel=\"nofollow\"\u003EKeek\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/kdCQg2Rr",
      "expanded_url" : "http:\/\/www.keek.com\/!9zHkaab",
      "display_url" : "keek.com\/!9zHkaab"
    } ]
  },
  "geo" : { },
  "id_str" : "222145529977638912",
  "text" : "My 1st Keek.. Lol http:\/\/t.co\/kdCQg2Rr",
  "id" : 222145529977638912,
  "created_at" : "2012-07-09 01:49:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222144160302510080",
  "geo" : { },
  "id_str" : "222144716697907200",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell up to no good, eh? LOL",
  "id" : 222144716697907200,
  "in_reply_to_status_id" : 222144160302510080,
  "created_at" : "2012-07-09 01:46:42 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222078970320003073",
  "text" : "RT @Silvercrone: I saw this and had to share. Star image caused by flash of someone taking picture of this guy taking picture. COOL! htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Silvercrone\/status\/222078418391547905\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/9YADHmJ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxT7JRjCQAApJ65.jpg",
        "id_str" : "222078418395742208",
        "id" : 222078418395742208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxT7JRjCQAApJ65.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 585
        } ],
        "display_url" : "pic.twitter.com\/9YADHmJ2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222078418391547905",
    "text" : "I saw this and had to share. Star image caused by flash of someone taking picture of this guy taking picture. COOL! http:\/\/t.co\/9YADHmJ2",
    "id" : 222078418391547905,
    "created_at" : "2012-07-08 21:23:16 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 222078970320003073,
  "created_at" : "2012-07-08 21:25:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222073962476208128",
  "text" : "I like Simple Tags in WP but it does not show my tags in dashboard so I have to remember tag names..",
  "id" : 222073962476208128,
  "created_at" : "2012-07-08 21:05:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.keek.com\" rel=\"nofollow\"\u003EKeek\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 24, 36 ],
      "id_str" : "261888721",
      "id" : 261888721
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 55, 66 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/kdCQg2Rr",
      "expanded_url" : "http:\/\/www.keek.com\/!9zHkaab",
      "display_url" : "keek.com\/!9zHkaab"
    } ]
  },
  "geo" : { },
  "id_str" : "222069300276625408",
  "text" : "Thanks to Thomas Pluck (@tommysalami) and Tyrus Books (@tyrusbooks) for book. http:\/\/t.co\/kdCQg2Rr",
  "id" : 222069300276625408,
  "created_at" : "2012-07-08 20:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "indices" : [ 3, 17 ],
      "id_str" : "37490555",
      "id" : 37490555
    }, {
      "name" : "Penelope",
      "screen_name" : "bhpenny",
      "indices" : [ 22, 30 ],
      "id_str" : "543828184",
      "id" : 543828184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/bH1ufnoq",
      "expanded_url" : "http:\/\/bit.ly\/Aa0Boa",
      "display_url" : "bit.ly\/Aa0Boa"
    } ]
  },
  "geo" : { },
  "id_str" : "222042312686051328",
  "text" : "RT @doggiestylish: RT @bhpenny: Tigger died from a Hartz product containing TCVP. Danger to animals &amp; children. http:\/\/t.co\/bH1ufnoq ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Penelope",
        "screen_name" : "bhpenny",
        "indices" : [ 3, 11 ],
        "id_str" : "543828184",
        "id" : 543828184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/bH1ufnoq",
        "expanded_url" : "http:\/\/bit.ly\/Aa0Boa",
        "display_url" : "bit.ly\/Aa0Boa"
      }, {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/9weeFmRs",
        "expanded_url" : "http:\/\/twitpic.com\/94ehyh",
        "display_url" : "twitpic.com\/94ehyh"
      } ]
    },
    "geo" : { },
    "id_str" : "222040599132504065",
    "text" : "RT @bhpenny: Tigger died from a Hartz product containing TCVP. Danger to animals &amp; children. http:\/\/t.co\/bH1ufnoq http:\/\/t.co\/9weeFmRs",
    "id" : 222040599132504065,
    "created_at" : "2012-07-08 18:52:58 +0000",
    "user" : {
      "name" : "karen friesecke",
      "screen_name" : "doggiestylish",
      "protected" : false,
      "id_str" : "37490555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466092491\/jersey_normal.jpg",
      "id" : 37490555,
      "verified" : false
    }
  },
  "id" : 222042312686051328,
  "created_at" : "2012-07-08 18:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TGFBook",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222041948956016641",
  "text" : "RT @alanhdawe: He knows everything that is, because He is everything that is. There is nothing else that exists. #TGFBook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222040623828574208",
    "text" : "He knows everything that is, because He is everything that is. There is nothing else that exists. #TGFBook",
    "id" : 222040623828574208,
    "created_at" : "2012-07-08 18:53:04 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 222041948956016641,
  "created_at" : "2012-07-08 18:58:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/uHWGok0J",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/daves4\/25-animals-you-never-knew-could-be-cute?sub=1652435_410972",
      "display_url" : "buzzfeed.com\/daves4\/25-anim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222039405098057728",
  "text" : "Toads: http:\/\/t.co\/uHWGok0J",
  "id" : 222039405098057728,
  "created_at" : "2012-07-08 18:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/jszVWLwW",
      "expanded_url" : "http:\/\/bit.ly\/PvKpo5",
      "display_url" : "bit.ly\/PvKpo5"
    } ]
  },
  "geo" : { },
  "id_str" : "222027868178358272",
  "text" : "Saturday Situation | Readers Win http:\/\/t.co\/jszVWLwW",
  "id" : 222027868178358272,
  "created_at" : "2012-07-08 18:02:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/pq0MJCQ4",
      "expanded_url" : "http:\/\/fb.me\/2iFEfC4O0",
      "display_url" : "fb.me\/2iFEfC4O0"
    } ]
  },
  "geo" : { },
  "id_str" : "222010189824528385",
  "text" : "RT @petersonguides: For your calendar. If you're into crows, or just curious, this looks like a great event. http:\/\/t.co\/pq0MJCQ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/pq0MJCQ4",
        "expanded_url" : "http:\/\/fb.me\/2iFEfC4O0",
        "display_url" : "fb.me\/2iFEfC4O0"
      } ]
    },
    "geo" : { },
    "id_str" : "222006017410609153",
    "text" : "For your calendar. If you're into crows, or just curious, this looks like a great event. http:\/\/t.co\/pq0MJCQ4",
    "id" : 222006017410609153,
    "created_at" : "2012-07-08 16:35:33 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 222010189824528385,
  "created_at" : "2012-07-08 16:52:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WoolyBumblebee \u2718",
      "screen_name" : "WoolyBumblebee",
      "indices" : [ 3, 18 ],
      "id_str" : "97282602",
      "id" : 97282602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222009718086975488",
  "text" : "RT @WoolyBumblebee: I had a dream where I had to throw a goldfish at a border agent to get into the USA. Only then would I be let in. WT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222008346985762816",
    "text" : "I had a dream where I had to throw a goldfish at a border agent to get into the USA. Only then would I be let in. WTF does that mean??",
    "id" : 222008346985762816,
    "created_at" : "2012-07-08 16:44:49 +0000",
    "user" : {
      "name" : "WoolyBumblebee \u2718",
      "screen_name" : "WoolyBumblebee",
      "protected" : false,
      "id_str" : "97282602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799845160670461952\/IXV4TeTi_normal.jpg",
      "id" : 97282602,
      "verified" : false
    }
  },
  "id" : 222009718086975488,
  "created_at" : "2012-07-08 16:50:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222000546423382017",
  "geo" : { },
  "id_str" : "222002558829477890",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott cool beans! : )",
  "id" : 222002558829477890,
  "in_reply_to_status_id" : 222000546423382017,
  "created_at" : "2012-07-08 16:21:49 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221994157315600384",
  "text" : "giant turkey sized bluebirds in my dream last night..lol",
  "id" : 221994157315600384,
  "created_at" : "2012-07-08 15:48:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 14, 27 ],
      "id_str" : "88882302",
      "id" : 88882302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/yjYGi37b",
      "expanded_url" : "http:\/\/goo.gl\/nCs8j",
      "display_url" : "goo.gl\/nCs8j"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/xxv52oDf",
      "expanded_url" : "http:\/\/shrtn.us\/XolF",
      "display_url" : "shrtn.us\/XolF"
    } ]
  },
  "geo" : { },
  "id_str" : "221789712371818497",
  "text" : "Life, also RT @TweetTheBook: Stop The Negativity. It Ain't Over Till It's Over http:\/\/t.co\/yjYGi37b [Like it? http:\/\/t.co\/xxv52oDf ]",
  "id" : 221789712371818497,
  "created_at" : "2012-07-08 02:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221768373875388417",
  "text" : "stupid bug zapper thingy.. scares the dog turrible.. she almost didnt go w hubby in car cuz he was swinging it around.. ugh!",
  "id" : 221768373875388417,
  "created_at" : "2012-07-08 00:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Palmer",
      "screen_name" : "amandapalmer",
      "indices" : [ 3, 16 ],
      "id_str" : "10798802",
      "id" : 10798802
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/amandapalmer\/status\/221754641308848128\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/mrWNvBjP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxPUq98CEAArsmf.jpg",
      "id_str" : "221754641317236736",
      "id" : 221754641317236736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxPUq98CEAArsmf.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 1224
      } ],
      "display_url" : "pic.twitter.com\/mrWNvBjP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221765173147467778",
  "text" : "RT @amandapalmer: DUDE. RACCOON ON MY FIRE ESCAPE. JUST STARING AT ME LIKE IT'S NO BIG FUCKING THING http:\/\/t.co\/mrWNvBjP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amandapalmer\/status\/221754641308848128\/photo\/1",
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/mrWNvBjP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxPUq98CEAArsmf.jpg",
        "id_str" : "221754641317236736",
        "id" : 221754641317236736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxPUq98CEAArsmf.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        } ],
        "display_url" : "pic.twitter.com\/mrWNvBjP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221754641308848128",
    "text" : "DUDE. RACCOON ON MY FIRE ESCAPE. JUST STARING AT ME LIKE IT'S NO BIG FUCKING THING http:\/\/t.co\/mrWNvBjP",
    "id" : 221754641308848128,
    "created_at" : "2012-07-07 23:56:42 +0000",
    "user" : {
      "name" : "Amanda Palmer",
      "screen_name" : "amandapalmer",
      "protected" : false,
      "id_str" : "10798802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510069541200617473\/OiX5QHDB_normal.jpeg",
      "id" : 10798802,
      "verified" : true
    }
  },
  "id" : 221765173147467778,
  "created_at" : "2012-07-08 00:38:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/BZFe7a3p",
      "expanded_url" : "http:\/\/bit.ly\/MdkpKv",
      "display_url" : "bit.ly\/MdkpKv"
    } ]
  },
  "geo" : { },
  "id_str" : "221743475983519746",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny for you : )  &gt;&gt; MJ1309 \u2013 Mahoney Joe http:\/\/t.co\/BZFe7a3p",
  "id" : 221743475983519746,
  "created_at" : "2012-07-07 23:12:19 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221739164599717888",
  "geo" : { },
  "id_str" : "221740024394293248",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny hun, why you even pay them attention? they dont deserve the space in your head! ((hugs))",
  "id" : 221740024394293248,
  "in_reply_to_status_id" : 221739164599717888,
  "created_at" : "2012-07-07 22:58:36 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221735108695166977",
  "text" : "RT @CoyoteSings: You don't have to come to my church. You are already there, blessed and forgiven.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221734618632695809",
    "text" : "You don't have to come to my church. You are already there, blessed and forgiven.",
    "id" : 221734618632695809,
    "created_at" : "2012-07-07 22:37:07 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 221735108695166977,
  "created_at" : "2012-07-07 22:39:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ODS",
      "screen_name" : "TheLogicalOne70",
      "indices" : [ 0, 16 ],
      "id_str" : "46848957",
      "id" : 46848957
    }, {
      "name" : "Homunculus aka #Hom",
      "screen_name" : "HomunculusLoikm",
      "indices" : [ 76, 92 ],
      "id_str" : "233933230",
      "id" : 233933230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/7e9GZQwd",
      "expanded_url" : "http:\/\/bit.ly\/N59lkp",
      "display_url" : "bit.ly\/N59lkp"
    } ]
  },
  "in_reply_to_status_id_str" : "221730535200923648",
  "geo" : { },
  "id_str" : "221734695879188480",
  "in_reply_to_user_id" : 46848957,
  "text" : "@TheLogicalOne70 found it..lol.. Remember the love bit http:\/\/t.co\/7e9GZQwd @HomunculusLoikm",
  "id" : 221734695879188480,
  "in_reply_to_status_id" : 221730535200923648,
  "created_at" : "2012-07-07 22:37:25 +0000",
  "in_reply_to_screen_name" : "TheLogicalOne70",
  "in_reply_to_user_id_str" : "46848957",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/7e9GZQwd",
      "expanded_url" : "http:\/\/bit.ly\/N59lkp",
      "display_url" : "bit.ly\/N59lkp"
    } ]
  },
  "geo" : { },
  "id_str" : "221734325320822784",
  "text" : "Hitchens' Words of Farewell: 'Remember the love bit' - YouTube http:\/\/t.co\/7e9GZQwd",
  "id" : 221734325320822784,
  "created_at" : "2012-07-07 22:35:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfpub",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "IndieAuthor",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/xDxIjYoW",
      "expanded_url" : "http:\/\/www.ReadingFreebies.blogspot.com",
      "display_url" : "ReadingFreebies.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "221728023785910273",
  "text" : "RT @JAScribbles: I'm sharing the love of ebook freebies with this blog: http:\/\/t.co\/xDxIjYoW #selfpub #Kindle #IndieAuthor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfpub",
        "indices" : [ 76, 84 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "IndieAuthor",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/xDxIjYoW",
        "expanded_url" : "http:\/\/www.ReadingFreebies.blogspot.com",
        "display_url" : "ReadingFreebies.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "221727415624409088",
    "text" : "I'm sharing the love of ebook freebies with this blog: http:\/\/t.co\/xDxIjYoW #selfpub #Kindle #IndieAuthor",
    "id" : 221727415624409088,
    "created_at" : "2012-07-07 22:08:30 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 221728023785910273,
  "created_at" : "2012-07-07 22:10:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221727798191075328",
  "text" : "DD has such a wonderful heart. feels compassion for the lobsters in grocery stores.",
  "id" : 221727798191075328,
  "created_at" : "2012-07-07 22:10:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyme",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "VBID",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221727519676694530",
  "text" : "RT @AlisynGayle: Anyone in #Lyme #VBID community ever have Bell's Palsy &amp; SEVERE pain at base of skull? Need info. PLS RT! TIA :-) x ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lyme",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "VBID",
        "indices" : [ 16, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221725964261003265",
    "text" : "Anyone in #Lyme #VBID community ever have Bell's Palsy &amp; SEVERE pain at base of skull? Need info. PLS RT! TIA :-) xox&lt;3",
    "id" : 221725964261003265,
    "created_at" : "2012-07-07 22:02:44 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 221727519676694530,
  "created_at" : "2012-07-07 22:08:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homunculus aka #Hom",
      "screen_name" : "HomunculusLoikm",
      "indices" : [ 0, 16 ],
      "id_str" : "233933230",
      "id" : 233933230
    }, {
      "name" : "ODS",
      "screen_name" : "TheLogicalOne70",
      "indices" : [ 113, 129 ],
      "id_str" : "46848957",
      "id" : 46848957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221723819671425024",
  "geo" : { },
  "id_str" : "221727179401203712",
  "in_reply_to_user_id" : 233933230,
  "text" : "@HomunculusLoikm dont know a lot about hitchens but did see a touching video of him w young girl at book signing @TheLogicalOne70",
  "id" : 221727179401203712,
  "in_reply_to_status_id" : 221723819671425024,
  "created_at" : "2012-07-07 22:07:33 +0000",
  "in_reply_to_screen_name" : "HomunculusLoikm",
  "in_reply_to_user_id_str" : "233933230",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221718514422124544",
  "text" : "had a wonderful girls day out with my niece today. shopping then lunch.. woohoo! got a new light for my kindle and some fudge..lol",
  "id" : 221718514422124544,
  "created_at" : "2012-07-07 21:33:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/xGKe211Z",
      "expanded_url" : "http:\/\/apadv.co\/L7yv28",
      "display_url" : "apadv.co\/L7yv28"
    } ]
  },
  "geo" : { },
  "id_str" : "221611147764305920",
  "text" : "RT @AppAdvice: Fruit Ninja gets some new swag with its v1.8.1 update. http:\/\/t.co\/xGKe211Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/appadvice.com\" rel=\"nofollow\"\u003EAppAdvice Website\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/xGKe211Z",
        "expanded_url" : "http:\/\/apadv.co\/L7yv28",
        "display_url" : "apadv.co\/L7yv28"
      } ]
    },
    "geo" : { },
    "id_str" : "221551607026958337",
    "text" : "Fruit Ninja gets some new swag with its v1.8.1 update. http:\/\/t.co\/xGKe211Z",
    "id" : 221551607026958337,
    "created_at" : "2012-07-07 10:29:54 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 221611147764305920,
  "created_at" : "2012-07-07 14:26:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/LcIK9bDg",
      "expanded_url" : "http:\/\/bit.ly\/NcWTyw",
      "display_url" : "bit.ly\/NcWTyw"
    } ]
  },
  "geo" : { },
  "id_str" : "221610326939017216",
  "text" : "been working on this &gt;&gt; Readers Win | Finding book giveaways and more http:\/\/t.co\/LcIK9bDg",
  "id" : 221610326939017216,
  "created_at" : "2012-07-07 14:23:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221599187354128384",
  "text" : "RT @RichardMabry: Are book covers important? Give your opinion, and get a sneak peek at the cover of my next novel of medical suspense.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/HFFBE7IP",
        "expanded_url" : "http:\/\/bit.ly\/M7sKmH",
        "display_url" : "bit.ly\/M7sKmH"
      } ]
    },
    "geo" : { },
    "id_str" : "221595714701111296",
    "text" : "Are book covers important? Give your opinion, and get a sneak peek at the cover of my next novel of medical suspense. http:\/\/t.co\/HFFBE7IP",
    "id" : 221595714701111296,
    "created_at" : "2012-07-07 13:25:10 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 221599187354128384,
  "created_at" : "2012-07-07 13:38:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/69FtIxNw",
      "expanded_url" : "http:\/\/shar.es\/t3rYz",
      "display_url" : "shar.es\/t3rYz"
    } ]
  },
  "geo" : { },
  "id_str" : "221332745211748352",
  "text" : "And Now, a Tiny Baby Raccoon in a Bag of Mud http:\/\/t.co\/69FtIxNw",
  "id" : 221332745211748352,
  "created_at" : "2012-07-06 20:00:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/zSdNAeZX",
      "expanded_url" : "http:\/\/apadv.co\/Nt6aRt",
      "display_url" : "apadv.co\/Nt6aRt"
    } ]
  },
  "geo" : { },
  "id_str" : "221312789262778369",
  "text" : "RT @AppAdvice: Where there's smoke ... Amazon expected to launch first Kindle Phone. http:\/\/t.co\/zSdNAeZX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/appadvice.com\" rel=\"nofollow\"\u003EAppAdvice Website\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/zSdNAeZX",
        "expanded_url" : "http:\/\/apadv.co\/Nt6aRt",
        "display_url" : "apadv.co\/Nt6aRt"
      } ]
    },
    "geo" : { },
    "id_str" : "221277721358118913",
    "text" : "Where there's smoke ... Amazon expected to launch first Kindle Phone. http:\/\/t.co\/zSdNAeZX",
    "id" : 221277721358118913,
    "created_at" : "2012-07-06 16:21:34 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 221312789262778369,
  "created_at" : "2012-07-06 18:40:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/KCjhVIEI",
      "expanded_url" : "http:\/\/apadv.co\/NI9m9I",
      "display_url" : "apadv.co\/NI9m9I"
    } ]
  },
  "geo" : { },
  "id_str" : "221312065808236545",
  "text" : "RT @AppAdvice: Add a whole new set of Emoji icons to your iPhone by winning Emoji 2: http:\/\/t.co\/KCjhVIEI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/appadvice.com\" rel=\"nofollow\"\u003EAppAdvice Website\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/KCjhVIEI",
        "expanded_url" : "http:\/\/apadv.co\/NI9m9I",
        "display_url" : "apadv.co\/NI9m9I"
      } ]
    },
    "geo" : { },
    "id_str" : "221266689659113476",
    "text" : "Add a whole new set of Emoji icons to your iPhone by winning Emoji 2: http:\/\/t.co\/KCjhVIEI",
    "id" : 221266689659113476,
    "created_at" : "2012-07-06 15:37:44 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 221312065808236545,
  "created_at" : "2012-07-06 18:38:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/QOP7dBhw",
      "expanded_url" : "http:\/\/twittercounter.com\/pages\/twitter-widget",
      "display_url" : "twittercounter.com\/pages\/twitter-\u2026"
    }, {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/US06ZTC2",
      "expanded_url" : "http:\/\/www.abfabgab.com",
      "display_url" : "abfabgab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "221244084914892800",
  "text" : "Just installed the Twitter Counter Widget: http:\/\/t.co\/QOP7dBhw on my blog: http:\/\/t.co\/US06ZTC2",
  "id" : 221244084914892800,
  "created_at" : "2012-07-06 14:07:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Zeman",
      "screen_name" : "natezemanphoto",
      "indices" : [ 3, 18 ],
      "id_str" : "247378651",
      "id" : 247378651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/natezemanphoto\/status\/219982169303560193\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/c8C3xXm9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aw2InhKCMAMYQmZ.jpg",
      "id_str" : "219982169307754499",
      "id" : 219982169307754499,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aw2InhKCMAMYQmZ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c8C3xXm9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221230029873483776",
  "text" : "RT @natezemanphoto: Awesome sunset over Buffalo Mountain right now. Wish I had more than my cell phone with me. http:\/\/t.co\/c8C3xXm9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/natezemanphoto\/status\/219982169303560193\/photo\/1",
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/c8C3xXm9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Aw2InhKCMAMYQmZ.jpg",
        "id_str" : "219982169307754499",
        "id" : 219982169307754499,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aw2InhKCMAMYQmZ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/c8C3xXm9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219982169303560193",
    "text" : "Awesome sunset over Buffalo Mountain right now. Wish I had more than my cell phone with me. http:\/\/t.co\/c8C3xXm9",
    "id" : 219982169303560193,
    "created_at" : "2012-07-03 02:33:33 +0000",
    "user" : {
      "name" : "Nate Zeman",
      "screen_name" : "natezemanphoto",
      "protected" : false,
      "id_str" : "247378651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798881181265752065\/sR95gG6L_normal.jpg",
      "id" : 247378651,
      "verified" : false
    }
  },
  "id" : 221230029873483776,
  "created_at" : "2012-07-06 13:12:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/QJJoBQVd",
      "expanded_url" : "http:\/\/huff.to\/M7VSXg",
      "display_url" : "huff.to\/M7VSXg"
    } ]
  },
  "geo" : { },
  "id_str" : "221026493705355265",
  "text" : "WTF?? &gt;&gt; British 14-Year-Old, Urged To Get Breast Implants By Mother http:\/\/t.co\/QJJoBQVd",
  "id" : 221026493705355265,
  "created_at" : "2012-07-05 23:43:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221009598436483073",
  "text" : "RT @SangyeH: We're asking for donations to reduce the amt of the $600,000 loan. At 7p EST TONITE we'll have a webathon 2 raise funds htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/oKuhFDoP",
        "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
        "display_url" : "bit.ly\/LQcG6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "221009183565287424",
    "text" : "We're asking for donations to reduce the amt of the $600,000 loan. At 7p EST TONITE we'll have a webathon 2 raise funds http:\/\/t.co\/oKuhFDoP",
    "id" : 221009183565287424,
    "created_at" : "2012-07-05 22:34:30 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 221009598436483073,
  "created_at" : "2012-07-05 22:36:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221009556887699457",
  "text" : "RT @SangyeH: We're also hoping to sell 4.5 acres of the land. Pristine wilderness, spectacular views. By the sacred Amitaba stupa http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/oKuhFDoP",
        "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
        "display_url" : "bit.ly\/LQcG6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "221008924298588160",
    "text" : "We're also hoping to sell 4.5 acres of the land. Pristine wilderness, spectacular views. By the sacred Amitaba stupa http:\/\/t.co\/oKuhFDoP",
    "id" : 221008924298588160,
    "created_at" : "2012-07-05 22:33:28 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 221009556887699457,
  "created_at" : "2012-07-05 22:35:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sedona",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "AZ",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/oKuhFDoP",
      "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
      "display_url" : "bit.ly\/LQcG6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "221009532443303937",
  "text" : "RT @SangyeH: Friends, I need your help! We're at risk of losing our Amitaba stupa &amp; sacred land in #Sedona #AZ http:\/\/t.co\/oKuhFDoP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sedona",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "AZ",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/oKuhFDoP",
        "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
        "display_url" : "bit.ly\/LQcG6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "221008721432686592",
    "text" : "Friends, I need your help! We're at risk of losing our Amitaba stupa &amp; sacred land in #Sedona #AZ http:\/\/t.co\/oKuhFDoP",
    "id" : 221008721432686592,
    "created_at" : "2012-07-05 22:32:39 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 221009532443303937,
  "created_at" : "2012-07-05 22:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "indices" : [ 79, 91 ],
      "id_str" : "14345566",
      "id" : 14345566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/ueO0vr0J",
      "expanded_url" : "http:\/\/thebloggess.com\/2012\/07\/the-man-deserves-a-damn-medal\/",
      "display_url" : "thebloggess.com\/2012\/07\/the-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220935460489408512",
  "text" : "I want a sloth hug!! \/\/ The man deserves a damn medal http:\/\/t.co\/ueO0vr0J via @thebloggess",
  "id" : 220935460489408512,
  "created_at" : "2012-07-05 17:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    }, {
      "name" : "Ayesha Priest",
      "screen_name" : "amazonlocal",
      "indices" : [ 24, 36 ],
      "id_str" : "4607198955",
      "id" : 4607198955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/wUJGVtb6",
      "expanded_url" : "http:\/\/bit.ly\/N0YEOC",
      "display_url" : "bit.ly\/N0YEOC"
    } ]
  },
  "geo" : { },
  "id_str" : "220907957842481152",
  "text" : "RT @amazonmp3: Our pals @amazonlocal have a deal for a free voucher for $3 to spend at Amazon MP3 today. Details: http:\/\/t.co\/wUJGVtb6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ayesha Priest",
        "screen_name" : "amazonlocal",
        "indices" : [ 9, 21 ],
        "id_str" : "4607198955",
        "id" : 4607198955
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/wUJGVtb6",
        "expanded_url" : "http:\/\/bit.ly\/N0YEOC",
        "display_url" : "bit.ly\/N0YEOC"
      } ]
    },
    "geo" : { },
    "id_str" : "220905404023054336",
    "text" : "Our pals @amazonlocal have a deal for a free voucher for $3 to spend at Amazon MP3 today. Details: http:\/\/t.co\/wUJGVtb6",
    "id" : 220905404023054336,
    "created_at" : "2012-07-05 15:42:07 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 220907957842481152,
  "created_at" : "2012-07-05 15:52:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220897908768251904",
  "text" : "RT @TheGoldenMirror: When you are locked into place by the empire you build around you, you can only become liberated when you're prepar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220896977230106627",
    "text" : "When you are locked into place by the empire you build around you, you can only become liberated when you're prepared to let it go.",
    "id" : 220896977230106627,
    "created_at" : "2012-07-05 15:08:38 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 220897908768251904,
  "created_at" : "2012-07-05 15:12:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "Sarah Felts",
      "screen_name" : "sarahfelts",
      "indices" : [ 13, 24 ],
      "id_str" : "20121960",
      "id" : 20121960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220883388469481472",
  "text" : "RT @screek: \u201C@sarahfelts: The picture is amazing. San Diego accidentally set off all of its fireworks at once last night. http:\/\/t.co\/LF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Felts",
        "screen_name" : "sarahfelts",
        "indices" : [ 1, 12 ],
        "id_str" : "20121960",
        "id" : 20121960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/LFSaCwY5",
        "expanded_url" : "http:\/\/theatln.tc\/N0k9z0",
        "display_url" : "theatln.tc\/N0k9z0"
      } ]
    },
    "geo" : { },
    "id_str" : "220881771288461312",
    "text" : "\u201C@sarahfelts: The picture is amazing. San Diego accidentally set off all of its fireworks at once last night. http:\/\/t.co\/LFSaCwY5\u201D",
    "id" : 220881771288461312,
    "created_at" : "2012-07-05 14:08:12 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 220883388469481472,
  "created_at" : "2012-07-05 14:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 3, 19 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hudsonvalley",
      "indices" : [ 100, 113 ]
    }, {
      "text" : "4thofjuly",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "fireworks",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220882092114984962",
  "text" : "RT @TheHudsonValley: Fourth of July celebration over the Mid-Hudson Bridge. Photo by Skip Pearlman. #hudsonvalley #4thofjuly #fireworks  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheHudsonValley\/status\/220881623166623744\/photo\/1",
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/vckb29fW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxC6qn7CIAEn6OK.jpg",
        "id_str" : "220881623175012353",
        "id" : 220881623175012353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxC6qn7CIAEn6OK.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1346
        }, {
          "h" : 913,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1558,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vckb29fW"
      } ],
      "hashtags" : [ {
        "text" : "hudsonvalley",
        "indices" : [ 79, 92 ]
      }, {
        "text" : "4thofjuly",
        "indices" : [ 93, 103 ]
      }, {
        "text" : "fireworks",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220881623166623744",
    "text" : "Fourth of July celebration over the Mid-Hudson Bridge. Photo by Skip Pearlman. #hudsonvalley #4thofjuly #fireworks http:\/\/t.co\/vckb29fW",
    "id" : 220881623166623744,
    "created_at" : "2012-07-05 14:07:38 +0000",
    "user" : {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "protected" : false,
      "id_str" : "102313523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567810424549044227\/C6iux0NV_normal.png",
      "id" : 102313523,
      "verified" : false
    }
  },
  "id" : 220882092114984962,
  "created_at" : "2012-07-05 14:09:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/cc6CWDpX",
      "expanded_url" : "http:\/\/tinyurl.com\/85opfhw",
      "display_url" : "tinyurl.com\/85opfhw"
    } ]
  },
  "geo" : { },
  "id_str" : "220881773117177857",
  "text" : "RT @Soulseedzforall: A horse is freedom in motion. http:\/\/t.co\/cc6CWDpX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/cc6CWDpX",
        "expanded_url" : "http:\/\/tinyurl.com\/85opfhw",
        "display_url" : "tinyurl.com\/85opfhw"
      } ]
    },
    "geo" : { },
    "id_str" : "220881608268464128",
    "text" : "A horse is freedom in motion. http:\/\/t.co\/cc6CWDpX",
    "id" : 220881608268464128,
    "created_at" : "2012-07-05 14:07:33 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 220881773117177857,
  "created_at" : "2012-07-05 14:08:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/QxBoeNCR",
      "expanded_url" : "http:\/\/www.facebook.com\/appadvice?sk=app_211922635540356",
      "display_url" : "facebook.com\/appadvice?sk=a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220877717007114241",
  "text" : "Follow AppAdvice on Twitter and Facebook for your chance to win iOS apps! http:\/\/t.co\/QxBoeNCR",
  "id" : 220877717007114241,
  "created_at" : "2012-07-05 13:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 11, 24 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Science",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220873904766459904",
  "text" : "Heehee! RT @DeepakChopra Scripture \" God said -let there be light \" #Science \"Goddamn you - it's a Higgs Boson !\"",
  "id" : 220873904766459904,
  "created_at" : "2012-07-05 13:36:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "indices" : [ 3, 18 ],
      "id_str" : "233966512",
      "id" : 233966512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220872607615037440",
  "text" : "RT @authorkingsley: When children are grown and look back where they went, it is love they'll remember, not the money you spent. Ian Kin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220872379528777728",
    "text" : "When children are grown and look back where they went, it is love they'll remember, not the money you spent. Ian Kingsley",
    "id" : 220872379528777728,
    "created_at" : "2012-07-05 13:30:53 +0000",
    "user" : {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "protected" : false,
      "id_str" : "233966512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1206687416\/ian-spinaker-90ppi-smallest_normal.JPG",
      "id" : 233966512,
      "verified" : false
    }
  },
  "id" : 220872607615037440,
  "created_at" : "2012-07-05 13:31:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220872394506641408",
  "text" : "I wish I could catch pic of racoon standing looking in thru glass in door. adorable! he did it again last night.",
  "id" : 220872394506641408,
  "created_at" : "2012-07-05 13:30:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220724831824527360",
  "geo" : { },
  "id_str" : "220871672222334976",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves we went out for ice cream so it was good. nice to see you in my timeline! : )",
  "id" : 220871672222334976,
  "in_reply_to_status_id" : 220724831824527360,
  "created_at" : "2012-07-05 13:28:04 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220690571805736960",
  "geo" : { },
  "id_str" : "220695469603553282",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny of course there is, silly.. and you\"ll be there along w everyone else! ((hugs))",
  "id" : 220695469603553282,
  "in_reply_to_status_id" : 220690571805736960,
  "created_at" : "2012-07-05 01:47:54 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220688837515550720",
  "text" : "RT @SangyeH: We're also hoping to sell 4.5 acres of the land. Pristine wilderness, spectacular views. By the sacred Amitaba stupa. http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/oKuhFDoP",
        "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
        "display_url" : "bit.ly\/LQcG6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "220688620611321856",
    "text" : "We're also hoping to sell 4.5 acres of the land. Pristine wilderness, spectacular views. By the sacred Amitaba stupa. http:\/\/t.co\/oKuhFDoP",
    "id" : 220688620611321856,
    "created_at" : "2012-07-05 01:20:42 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 220688837515550720,
  "created_at" : "2012-07-05 01:21:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sedona",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "AZ",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/oKuhFDoP",
      "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
      "display_url" : "bit.ly\/LQcG6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "220688223842729985",
  "text" : "RT @SangyeH: Friends, I need your help! We're at risk of losing our Amitaba stupa &amp; sacred land in #Sedona #AZ  http:\/\/t.co\/oKuhFDoP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sedona",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "AZ",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/oKuhFDoP",
        "expanded_url" : "http:\/\/bit.ly\/LQcG6Q",
        "display_url" : "bit.ly\/LQcG6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "220686763147010048",
    "text" : "Friends, I need your help! We're at risk of losing our Amitaba stupa &amp; sacred land in #Sedona #AZ  http:\/\/t.co\/oKuhFDoP",
    "id" : 220686763147010048,
    "created_at" : "2012-07-05 01:13:19 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 220688223842729985,
  "created_at" : "2012-07-05 01:19:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/4p0iFFg0",
      "expanded_url" : "http:\/\/bit.ly\/M6oIFM",
      "display_url" : "bit.ly\/M6oIFM"
    } ]
  },
  "geo" : { },
  "id_str" : "220634788128768003",
  "text" : "Learn How to Trade Stocks http:\/\/t.co\/4p0iFFg0",
  "id" : 220634788128768003,
  "created_at" : "2012-07-04 21:46:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jade Samson",
      "screen_name" : "divafabulosa",
      "indices" : [ 57, 70 ],
      "id_str" : "400117999",
      "id" : 400117999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hellosummer",
      "indices" : [ 4, 16 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/oPtnLJex",
      "expanded_url" : "http:\/\/www.divafabulosa.com\/hello-summer-1000-cash-giveaway-open-worldwide\/",
      "display_url" : "divafabulosa.com\/hello-summer-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220585903792463872",
  "text" : "Win #hellosummer $1000 cash #giveaway OPEN WORLDWIDE via @divafabulosa @pinayjade http:\/\/t.co\/oPtnLJex",
  "id" : 220585903792463872,
  "created_at" : "2012-07-04 18:32:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "divafabulosa",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "ipodtouch",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/9O0ol5EQ",
      "expanded_url" : "http:\/\/www.divafabulosa.com\/apple-ipod-shuffle-giveaway\/",
      "display_url" : "divafabulosa.com\/apple-ipod-shu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220585540678987777",
  "text" : "Join #divafabulosa #ipodtouch giveaway for a chance to win an IPOD Touch or $220 Cash. OPEN WORLDWIDE! http:\/\/t.co\/9O0ol5EQ",
  "id" : 220585540678987777,
  "created_at" : "2012-07-04 18:31:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ClouDrop for iOS",
      "screen_name" : "ClouDrop",
      "indices" : [ 3, 12 ],
      "id_str" : "581532978",
      "id" : 581532978
    }, {
      "name" : "ClouDrop for iOS",
      "screen_name" : "ClouDrop",
      "indices" : [ 34, 43 ],
      "id_str" : "581532978",
      "id" : 581532978
    }, {
      "name" : "CloudApp",
      "screen_name" : "cloudapp",
      "indices" : [ 59, 68 ],
      "id_str" : "74575590",
      "id" : 74575590
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4thofJuly",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220570672257179649",
  "text" : "RT @ClouDrop: If you havent tried @cloudrop, the universal @cloudapp client for iOS then now should be the time! free for #4thofJuly! ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ClouDrop for iOS",
        "screen_name" : "ClouDrop",
        "indices" : [ 20, 29 ],
        "id_str" : "581532978",
        "id" : 581532978
      }, {
        "name" : "CloudApp",
        "screen_name" : "cloudapp",
        "indices" : [ 45, 54 ],
        "id_str" : "74575590",
        "id" : 74575590
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4thofJuly",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/H1pTPTMo",
        "expanded_url" : "http:\/\/bit.ly\/dropcloud",
        "display_url" : "bit.ly\/dropcloud"
      } ]
    },
    "geo" : { },
    "id_str" : "220570320824827904",
    "text" : "If you havent tried @cloudrop, the universal @cloudapp client for iOS then now should be the time! free for #4thofJuly! http:\/\/t.co\/H1pTPTMo",
    "id" : 220570320824827904,
    "created_at" : "2012-07-04 17:30:37 +0000",
    "user" : {
      "name" : "ClouDrop for iOS",
      "screen_name" : "ClouDrop",
      "protected" : false,
      "id_str" : "581532978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414296288004284416\/IeviNLg1_normal.png",
      "id" : 581532978,
      "verified" : false
    }
  },
  "id" : 220570672257179649,
  "created_at" : "2012-07-04 17:32:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Mbs3U8Rn",
      "expanded_url" : "http:\/\/via.me\/-2q2wl80",
      "display_url" : "via.me\/-2q2wl80"
    } ]
  },
  "geo" : { },
  "id_str" : "220563305327112192",
  "text" : "My precious girl. Love the bow in her hair! http:\/\/t.co\/Mbs3U8Rn",
  "id" : 220563305327112192,
  "created_at" : "2012-07-04 17:02:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/KUekMoZo",
      "expanded_url" : "http:\/\/via.me\/-2q1lcuk",
      "display_url" : "via.me\/-2q1lcuk"
    } ]
  },
  "geo" : { },
  "id_str" : "220551841350553600",
  "text" : "Dirty hubby from fixing belt on van. http:\/\/t.co\/KUekMoZo",
  "id" : 220551841350553600,
  "created_at" : "2012-07-04 16:17:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220511839258292225",
  "text" : "i still don't like holidays...",
  "id" : 220511839258292225,
  "created_at" : "2012-07-04 13:38:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/lkMabcXM",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/cxu",
      "display_url" : "omgf.ac\/ts\/cxu"
    } ]
  },
  "geo" : { },
  "id_str" : "220511632885956609",
  "text" : "RT @OMGFacts: Japan is constitutionally forbidden from participating in wars! Details ---&gt; http:\/\/t.co\/lkMabcXM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/lkMabcXM",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/cxu",
        "display_url" : "omgf.ac\/ts\/cxu"
      } ]
    },
    "geo" : { },
    "id_str" : "220502622388502528",
    "text" : "Japan is constitutionally forbidden from participating in wars! Details ---&gt; http:\/\/t.co\/lkMabcXM",
    "id" : 220502622388502528,
    "created_at" : "2012-07-04 13:01:36 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 220511632885956609,
  "created_at" : "2012-07-04 13:37:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220314476900139008",
  "text" : "dog is hiding in DD's room bcuz they are testing fireworks across the street.",
  "id" : 220314476900139008,
  "created_at" : "2012-07-04 00:33:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hammons",
      "screen_name" : "TheBeanStraw",
      "indices" : [ 3, 16 ],
      "id_str" : "236673427",
      "id" : 236673427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220313868436643840",
  "text" : "RT @TheBeanStraw: My baby sitting philosophy: As long as the kids can still be located when the parents get home, it's been a good night.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220298580232114176",
    "text" : "My baby sitting philosophy: As long as the kids can still be located when the parents get home, it's been a good night.",
    "id" : 220298580232114176,
    "created_at" : "2012-07-03 23:30:49 +0000",
    "user" : {
      "name" : "David Hammons",
      "screen_name" : "TheBeanStraw",
      "protected" : false,
      "id_str" : "236673427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1216125480\/My_Pic_normal.jpg",
      "id" : 236673427,
      "verified" : false
    }
  },
  "id" : 220313868436643840,
  "created_at" : "2012-07-04 00:31:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/phaAI7qp",
      "expanded_url" : "http:\/\/tl.gd\/i578sq",
      "display_url" : "tl.gd\/i578sq"
    } ]
  },
  "geo" : { },
  "id_str" : "220170357179547649",
  "text" : "\"Adding value is the only way to true prosperity.\" - John Durham source: (cont) http:\/\/t.co\/phaAI7qp",
  "id" : 220170357179547649,
  "created_at" : "2012-07-03 15:01:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/azOsMFyz",
      "expanded_url" : "http:\/\/via.me\/-2ob8ihg",
      "display_url" : "via.me\/-2ob8ihg"
    } ]
  },
  "geo" : { },
  "id_str" : "219970152970715138",
  "text" : "Running from the camera..lol http:\/\/t.co\/azOsMFyz",
  "id" : 219970152970715138,
  "created_at" : "2012-07-03 01:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219948008794619904",
  "text" : "RT @TheGoldenMirror: You can't reach a positive outcome when you don't trust in it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219946938001391617",
    "text" : "You can't reach a positive outcome when you don't trust in it.",
    "id" : 219946938001391617,
    "created_at" : "2012-07-03 00:13:31 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 219948008794619904,
  "created_at" : "2012-07-03 00:17:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219945983881117696",
  "text" : "RT @shanecrash: Irony is celebrating the independence day of a country that we stole from the natives who had been living peacefully and ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219945779396218880",
    "text" : "Irony is celebrating the independence day of a country that we stole from the natives who had been living peacefully and thriving.",
    "id" : 219945779396218880,
    "created_at" : "2012-07-03 00:08:54 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 219945983881117696,
  "created_at" : "2012-07-03 00:09:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/ezhjh1e8",
      "expanded_url" : "http:\/\/pulse.me\/s\/aSF7k",
      "display_url" : "pulse.me\/s\/aSF7k"
    } ]
  },
  "geo" : { },
  "id_str" : "219942097501949952",
  "text" : "RT @Matth3ous: WTF? \uD83D\uDC49Texas Republicans call for an end to critical thinking in schools http:\/\/t.co\/ezhjh1e8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/ezhjh1e8",
        "expanded_url" : "http:\/\/pulse.me\/s\/aSF7k",
        "display_url" : "pulse.me\/s\/aSF7k"
      } ]
    },
    "geo" : { },
    "id_str" : "219939766714642432",
    "text" : "WTF? \uD83D\uDC49Texas Republicans call for an end to critical thinking in schools http:\/\/t.co\/ezhjh1e8",
    "id" : 219939766714642432,
    "created_at" : "2012-07-02 23:45:01 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 219942097501949952,
  "created_at" : "2012-07-02 23:54:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JANAE CHANG",
      "screen_name" : "pinkdandy",
      "indices" : [ 3, 13 ],
      "id_str" : "24666070",
      "id" : 24666070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/cw4A6GxR",
      "expanded_url" : "http:\/\/fb.me\/1QQ4FzPKw",
      "display_url" : "fb.me\/1QQ4FzPKw"
    } ]
  },
  "geo" : { },
  "id_str" : "219867855104114688",
  "text" : "RT @pinkdandy: Even little birdies do whatever it takes to get hydrated lol! http:\/\/t.co\/cw4A6GxR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/cw4A6GxR",
        "expanded_url" : "http:\/\/fb.me\/1QQ4FzPKw",
        "display_url" : "fb.me\/1QQ4FzPKw"
      } ]
    },
    "geo" : { },
    "id_str" : "219866936027254785",
    "text" : "Even little birdies do whatever it takes to get hydrated lol! http:\/\/t.co\/cw4A6GxR",
    "id" : 219866936027254785,
    "created_at" : "2012-07-02 18:55:37 +0000",
    "user" : {
      "name" : "JANAE CHANG",
      "screen_name" : "pinkdandy",
      "protected" : false,
      "id_str" : "24666070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2463804063\/j8r9odd5nvizwwehxxuq_normal.jpeg",
      "id" : 24666070,
      "verified" : false
    }
  },
  "id" : 219867855104114688,
  "created_at" : "2012-07-02 18:59:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taryn Elliott",
      "screen_name" : "TarynElliottFic",
      "indices" : [ 3, 19 ],
      "id_str" : "71674793",
      "id" : 71674793
    }, {
      "name" : "Alexandra Kerr",
      "screen_name" : "kerr_alexandra",
      "indices" : [ 37, 52 ],
      "id_str" : "76568830",
      "id" : 76568830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219867377964298240",
  "text" : "RT @TarynElliottFic: CUTENESS ALERT \"@kerr_alexandra:A FOX, A KITTEN AND A DOG. Snuggled together. Shut down the internet. http:\/\/t.co\/D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexandra Kerr",
        "screen_name" : "kerr_alexandra",
        "indices" : [ 16, 31 ],
        "id_str" : "76568830",
        "id" : 76568830
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kerr_alexandra\/status\/219764230763712513\/photo\/1",
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/DjZX7wRT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AwzCZ01CEAI348a.jpg",
        "id_str" : "219764230767906818",
        "id" : 219764230767906818,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwzCZ01CEAI348a.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/DjZX7wRT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219849331379941376",
    "text" : "CUTENESS ALERT \"@kerr_alexandra:A FOX, A KITTEN AND A DOG. Snuggled together. Shut down the internet. http:\/\/t.co\/DjZX7wRT\"",
    "id" : 219849331379941376,
    "created_at" : "2012-07-02 17:45:39 +0000",
    "user" : {
      "name" : "Taryn Elliott",
      "screen_name" : "TarynElliottFic",
      "protected" : false,
      "id_str" : "71674793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788192746062376960\/MMGqTnvd_normal.jpg",
      "id" : 71674793,
      "verified" : false
    }
  },
  "id" : 219867377964298240,
  "created_at" : "2012-07-02 18:57:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/Bkwj9ogn",
      "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/id502210059",
      "display_url" : "itunes.apple.com\/us\/app\/id50221\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219855212561702913",
  "text" : "RT @AppAdvice: Retweet this now for your chance to win Mahjong 123! http:\/\/t.co\/Bkwj9ogn Be sure you're following us; winners will be DM'ed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/Bkwj9ogn",
        "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/id502210059",
        "display_url" : "itunes.apple.com\/us\/app\/id50221\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "219850790242754561",
    "text" : "Retweet this now for your chance to win Mahjong 123! http:\/\/t.co\/Bkwj9ogn Be sure you're following us; winners will be DM'ed.",
    "id" : 219850790242754561,
    "created_at" : "2012-07-02 17:51:27 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 219855212561702913,
  "created_at" : "2012-07-02 18:09:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NextTopApp",
      "screen_name" : "NextTopApp",
      "indices" : [ 3, 14 ],
      "id_str" : "273188735",
      "id" : 273188735
    }, {
      "name" : "Yardsale",
      "screen_name" : "getyardsale",
      "indices" : [ 30, 42 ],
      "id_str" : "155608683",
      "id" : 155608683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/0x1heRPm",
      "expanded_url" : "http:\/\/bit.ly\/NWioEs",
      "display_url" : "bit.ly\/NWioEs"
    } ]
  },
  "geo" : { },
  "id_str" : "219829522084802561",
  "text" : "RT @NextTopApp: 'Yardsale' by @getyardsale Is Now a TOP 10 FREE iPhone LIFESTYLE APP! - http:\/\/t.co\/0x1heRPm - Simple Buying &amp; Selli ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yardsale",
        "screen_name" : "getyardsale",
        "indices" : [ 14, 26 ],
        "id_str" : "155608683",
        "id" : 155608683
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/0x1heRPm",
        "expanded_url" : "http:\/\/bit.ly\/NWioEs",
        "display_url" : "bit.ly\/NWioEs"
      } ]
    },
    "geo" : { },
    "id_str" : "218766072055209986",
    "text" : "'Yardsale' by @getyardsale Is Now a TOP 10 FREE iPhone LIFESTYLE APP! - http:\/\/t.co\/0x1heRPm - Simple Buying &amp; Selling With Your Neighbors!",
    "id" : 218766072055209986,
    "created_at" : "2012-06-29 18:01:10 +0000",
    "user" : {
      "name" : "NextTopApp",
      "screen_name" : "NextTopApp",
      "protected" : false,
      "id_str" : "273188735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1289679103\/iphone_normal.jpg",
      "id" : 273188735,
      "verified" : false
    }
  },
  "id" : 219829522084802561,
  "created_at" : "2012-07-02 16:26:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 17, 33 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219767175655862272",
  "text" : "RT @AniKnits: RT @TheGoldenMirror Other people's interpretations of you are essentially their restrictions. Be careful not to make them  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Golden Mirror",
        "screen_name" : "TheGoldenMirror",
        "indices" : [ 3, 19 ],
        "id_str" : "395797972",
        "id" : 395797972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219766572397510656",
    "text" : "RT @TheGoldenMirror Other people's interpretations of you are essentially their restrictions. Be careful not to make them yours.",
    "id" : 219766572397510656,
    "created_at" : "2012-07-02 12:16:48 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 219767175655862272,
  "created_at" : "2012-07-02 12:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219528121077080065",
  "text" : "RT @stevetheseeker: Psst. There is no fear in love. Pass it on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "219167008414105601",
    "text" : "Psst. There is no fear in love. Pass it on.",
    "id" : 219167008414105601,
    "created_at" : "2012-06-30 20:34:21 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 219528121077080065,
  "created_at" : "2012-07-01 20:29:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219522832659517441",
  "text" : "I think I'm gonna cry now.. did I take my pill?? yes, yes I did..",
  "id" : 219522832659517441,
  "created_at" : "2012-07-01 20:08:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 75, 88 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219521446467211264",
  "text" : "I do believe in miracles... I am so grateful things are turning around for @dwaynereaves finally!!",
  "id" : 219521446467211264,
  "created_at" : "2012-07-01 20:02:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 58, 71 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/n9BDPMIv",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/07\/on-borrowed-time-now.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/07\/on-bor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219471066869927938",
  "text" : "hang in there, buddy. im glad you contacted legal aid. RT @DwayneReaves On borrowed time now. http:\/\/t.co\/n9BDPMIv",
  "id" : 219471066869927938,
  "created_at" : "2012-07-01 16:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219429966360752128",
  "text" : "DD had fun taking lots of pics yesterday.. especially pics of the food. interesting.. a food photographer in the making? lol",
  "id" : 219429966360752128,
  "created_at" : "2012-07-01 13:59:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather HAL",
      "screen_name" : "HeatherHAL",
      "indices" : [ 3, 14 ],
      "id_str" : "19388491",
      "id" : 19388491
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 53, 66 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Iw3ExR1V",
      "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/troubled-day.html?spref=tw",
      "display_url" : "mrreaves.blogspot.com\/2012\/06\/troubl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219429560146608132",
  "text" : "RT @HeatherHAL: If you feel like making a real gift, @DwayneReaves really could use a donation, a tank of gas worth?  http:\/\/t.co\/Iw3ExR1V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dwayne Reaves",
        "screen_name" : "dwaynereaves",
        "indices" : [ 37, 50 ],
        "id_str" : "73908822",
        "id" : 73908822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/Iw3ExR1V",
        "expanded_url" : "http:\/\/mrreaves.blogspot.com\/2012\/06\/troubled-day.html?spref=tw",
        "display_url" : "mrreaves.blogspot.com\/2012\/06\/troubl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "219164859605057536",
    "text" : "If you feel like making a real gift, @DwayneReaves really could use a donation, a tank of gas worth?  http:\/\/t.co\/Iw3ExR1V",
    "id" : 219164859605057536,
    "created_at" : "2012-06-30 20:25:49 +0000",
    "user" : {
      "name" : "Heather HAL",
      "screen_name" : "HeatherHAL",
      "protected" : false,
      "id_str" : "19388491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2706695310\/815e46411ea1f74673b8ff5605667ef7_normal.jpeg",
      "id" : 19388491,
      "verified" : false
    }
  },
  "id" : 219429560146608132,
  "created_at" : "2012-07-01 13:57:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]