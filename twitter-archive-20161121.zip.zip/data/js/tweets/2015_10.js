Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Living 400lbs",
      "screen_name" : "Living400lbs",
      "indices" : [ 3, 16 ],
      "id_str" : "228915951",
      "id" : 228915951
    }, {
      "name" : "Marcus AureliUS",
      "screen_name" : "UnacceptableOne",
      "indices" : [ 37, 53 ],
      "id_str" : "22797045",
      "id" : 22797045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/UnacceptableOne\/status\/660496377315749889\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hYNNJuGk68",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSqN82IUEAAHAKR.jpg",
      "id_str" : "660496371825250304",
      "id" : 660496371825250304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSqN82IUEAAHAKR.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/hYNNJuGk68"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660656515838255108",
  "text" : "RT @Living400lbs: Tiny porcupine RT  @UnacceptableOne: Take all my candy https:\/\/t.co\/hYNNJuGk68",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweedleapp.com\/\" rel=\"nofollow\"\u003E Tweedle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcus AureliUS",
        "screen_name" : "UnacceptableOne",
        "indices" : [ 19, 35 ],
        "id_str" : "22797045",
        "id" : 22797045
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UnacceptableOne\/status\/660496377315749889\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/hYNNJuGk68",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSqN82IUEAAHAKR.jpg",
        "id_str" : "660496371825250304",
        "id" : 660496371825250304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSqN82IUEAAHAKR.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/hYNNJuGk68"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660651413261848580",
    "text" : "Tiny porcupine RT  @UnacceptableOne: Take all my candy https:\/\/t.co\/hYNNJuGk68",
    "id" : 660651413261848580,
    "created_at" : "2015-11-01 02:55:45 +0000",
    "user" : {
      "name" : "Living 400lbs",
      "screen_name" : "Living400lbs",
      "protected" : false,
      "id_str" : "228915951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000676652430\/7fea35fa50ded779cd7947ddd07c89f1_normal.jpeg",
      "id" : 228915951,
      "verified" : false
    }
  },
  "id" : 660656515838255108,
  "created_at" : "2015-11-01 03:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501760043474489344\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/jkmCuo7xsH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvacGdoIUAEzvvk.jpg",
      "id_str" : "501760043344482305",
      "id" : 501760043344482305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvacGdoIUAEzvvk.jpg",
      "sizes" : [ {
        "h" : 602,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com\/jkmCuo7xsH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660655561483141122",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/jkmCuo7xsH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501760043474489344\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/jkmCuo7xsH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvacGdoIUAEzvvk.jpg",
        "id_str" : "501760043344482305",
        "id" : 501760043344482305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvacGdoIUAEzvvk.jpg",
        "sizes" : [ {
          "h" : 602,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/jkmCuo7xsH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660649992567332864",
    "text" : "https:\/\/t.co\/jkmCuo7xsH",
    "id" : 660649992567332864,
    "created_at" : "2015-11-01 02:50:07 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 660655561483141122,
  "created_at" : "2015-11-01 03:12:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "U.S. Postal Service",
      "screen_name" : "USPS",
      "indices" : [ 56, 61 ],
      "id_str" : "386507775",
      "id" : 386507775
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/660466793274830848\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ugrI8YAYM1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpzCUnVAAABwqt.jpg",
      "id_str" : "660466779093794816",
      "id" : 660466779093794816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpzCUnVAAABwqt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ugrI8YAYM1"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/660466793274830848\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ugrI8YAYM1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpzCVaUkAAeaEk.jpg",
      "id_str" : "660466779307675648",
      "id" : 660466779307675648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpzCVaUkAAeaEk.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ugrI8YAYM1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660547206252990464",
  "text" : "RT @ErinEFarley: 21 minute (11 mile) drive to pick up a @USPS COD package. Lovely. Not creepy at all. https:\/\/t.co\/ugrI8YAYM1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Postal Service",
        "screen_name" : "USPS",
        "indices" : [ 39, 44 ],
        "id_str" : "386507775",
        "id" : 386507775
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/660466793274830848\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ugrI8YAYM1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpzCUnVAAABwqt.jpg",
        "id_str" : "660466779093794816",
        "id" : 660466779093794816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpzCUnVAAABwqt.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ugrI8YAYM1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/660466793274830848\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ugrI8YAYM1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpzCVaUkAAeaEk.jpg",
        "id_str" : "660466779307675648",
        "id" : 660466779307675648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpzCVaUkAAeaEk.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ugrI8YAYM1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660466793274830848",
    "text" : "21 minute (11 mile) drive to pick up a @USPS COD package. Lovely. Not creepy at all. https:\/\/t.co\/ugrI8YAYM1",
    "id" : 660466793274830848,
    "created_at" : "2015-10-31 14:42:09 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 660547206252990464,
  "created_at" : "2015-10-31 20:01:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosalea Jerseys",
      "screen_name" : "RosaleaJerseys",
      "indices" : [ 3, 18 ],
      "id_str" : "1359681031",
      "id" : 1359681031
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RosaleaJerseys\/status\/660432139549335553\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/W1RvWhWgiI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpTdadWsAAp30P.jpg",
      "id_str" : "660432060146954240",
      "id" : 660432060146954240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpTdadWsAAp30P.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/W1RvWhWgiI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/RosaleaJerseys\/status\/660432139549335553\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/W1RvWhWgiI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpTdS1WIAAkr_S.jpg",
      "id_str" : "660432058100097024",
      "id" : 660432058100097024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpTdS1WIAAkr_S.jpg",
      "sizes" : [ {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 638,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 638,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/W1RvWhWgiI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660546181320286212",
  "text" : "RT @RosaleaJerseys: Happy Halloween! https:\/\/t.co\/W1RvWhWgiI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RosaleaJerseys\/status\/660432139549335553\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/W1RvWhWgiI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpTdadWsAAp30P.jpg",
        "id_str" : "660432060146954240",
        "id" : 660432060146954240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpTdadWsAAp30P.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 638
        } ],
        "display_url" : "pic.twitter.com\/W1RvWhWgiI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/RosaleaJerseys\/status\/660432139549335553\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/W1RvWhWgiI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSpTdS1WIAAkr_S.jpg",
        "id_str" : "660432058100097024",
        "id" : 660432058100097024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSpTdS1WIAAkr_S.jpg",
        "sizes" : [ {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/W1RvWhWgiI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660432139549335553",
    "text" : "Happy Halloween! https:\/\/t.co\/W1RvWhWgiI",
    "id" : 660432139549335553,
    "created_at" : "2015-10-31 12:24:26 +0000",
    "user" : {
      "name" : "Rosalea Jerseys",
      "screen_name" : "RosaleaJerseys",
      "protected" : false,
      "id_str" : "1359681031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422838791062028288\/0LCATM2Y_normal.jpeg",
      "id" : 1359681031,
      "verified" : false
    }
  },
  "id" : 660546181320286212,
  "created_at" : "2015-10-31 19:57:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Fargo",
      "screen_name" : "alphabetsuccess",
      "indices" : [ 3, 19 ],
      "id_str" : "200583835",
      "id" : 200583835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660271641688190976",
  "text" : "RT @alphabetsuccess: Neurologists claim that every time you resist acting on your anger, you're actually rewiring your brain to be calmer a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660078470878359556",
    "text" : "Neurologists claim that every time you resist acting on your anger, you're actually rewiring your brain to be calmer and more loving.",
    "id" : 660078470878359556,
    "created_at" : "2015-10-30 12:59:05 +0000",
    "user" : {
      "name" : "Tim Fargo",
      "screen_name" : "alphabetsuccess",
      "protected" : false,
      "id_str" : "200583835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1141054939\/Twitter_Image_normal.jpg",
      "id" : 200583835,
      "verified" : false
    }
  },
  "id" : 660271641688190976,
  "created_at" : "2015-10-31 01:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660173798424125440",
  "text" : "RT @Buddhaworld: Let's love be your religion. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660159829663735808",
    "text" : "Let's love be your religion. Volko",
    "id" : 660159829663735808,
    "created_at" : "2015-10-30 18:22:23 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 660173798424125440,
  "created_at" : "2015-10-30 19:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris VetSchoolDiary",
      "screen_name" : "vetschooldiary",
      "indices" : [ 3, 18 ],
      "id_str" : "511647812",
      "id" : 511647812
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vetschooldiary\/status\/660151847735439361\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/EqSAWFETxn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlUm4OUkAA4w5k.jpg",
      "id_str" : "660151847290703872",
      "id" : 660151847290703872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlUm4OUkAA4w5k.jpg",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 927,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EqSAWFETxn"
    } ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 38, 42 ]
    }, {
      "text" : "vetstudent",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "behaviour",
      "indices" : [ 70, 80 ]
    }, {
      "text" : "language",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660173563882774528",
  "text" : "RT @vetschooldiary: Just what is your #cat trying to say? #vetstudent #behaviour #language https:\/\/t.co\/EqSAWFETxn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vetschooldiary\/status\/660151847735439361\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/EqSAWFETxn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlUm4OUkAA4w5k.jpg",
        "id_str" : "660151847290703872",
        "id" : 660151847290703872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlUm4OUkAA4w5k.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 927,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/EqSAWFETxn"
      } ],
      "hashtags" : [ {
        "text" : "cat",
        "indices" : [ 18, 22 ]
      }, {
        "text" : "vetstudent",
        "indices" : [ 38, 49 ]
      }, {
        "text" : "behaviour",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "language",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660151847735439361",
    "text" : "Just what is your #cat trying to say? #vetstudent #behaviour #language https:\/\/t.co\/EqSAWFETxn",
    "id" : 660151847735439361,
    "created_at" : "2015-10-30 17:50:40 +0000",
    "user" : {
      "name" : "Chris VetSchoolDiary",
      "screen_name" : "vetschooldiary",
      "protected" : false,
      "id_str" : "511647812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501830544347234304\/xaseZgUs_normal.jpeg",
      "id" : 511647812,
      "verified" : false
    }
  },
  "id" : 660173563882774528,
  "created_at" : "2015-10-30 19:16:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/a1rtTOJjpm",
      "expanded_url" : "https:\/\/twitter.com\/SojournGSD\/status\/660135719931801600",
      "display_url" : "twitter.com\/SojournGSD\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660171213097037824",
  "text" : "RT @rjmedwed: So many people think the story of Sodom and Gomorrah is about homosexuality. It\u2019s not.  https:\/\/t.co\/a1rtTOJjpm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/a1rtTOJjpm",
        "expanded_url" : "https:\/\/twitter.com\/SojournGSD\/status\/660135719931801600",
        "display_url" : "twitter.com\/SojournGSD\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660135896700706816",
    "text" : "So many people think the story of Sodom and Gomorrah is about homosexuality. It\u2019s not.  https:\/\/t.co\/a1rtTOJjpm",
    "id" : 660135896700706816,
    "created_at" : "2015-10-30 16:47:17 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 660171213097037824,
  "created_at" : "2015-10-30 19:07:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660136740544454656",
  "text" : "oops.. it's doing something now..",
  "id" : 660136740544454656,
  "created_at" : "2015-10-30 16:50:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KSOD",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660135923322118144",
  "text" : "C: drive restore didn't work. Still got #KSOD : (",
  "id" : 660135923322118144,
  "created_at" : "2015-10-30 16:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha",
      "screen_name" : "sammmnic",
      "indices" : [ 3, 12 ],
      "id_str" : "186935955",
      "id" : 186935955
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sammmnic\/status\/660131030674731008\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/xjHaLf9gDQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlBq-MUcAEA_kg.jpg",
      "id_str" : "660131026891468801",
      "id" : 660131026891468801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlBq-MUcAEA_kg.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xjHaLf9gDQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660135358584258560",
  "text" : "RT @sammmnic: https:\/\/t.co\/xjHaLf9gDQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sammmnic\/status\/660131030674731008\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/xjHaLf9gDQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlBq-MUcAEA_kg.jpg",
        "id_str" : "660131026891468801",
        "id" : 660131026891468801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlBq-MUcAEA_kg.jpg",
        "sizes" : [ {
          "h" : 643,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xjHaLf9gDQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660131030674731008",
    "text" : "https:\/\/t.co\/xjHaLf9gDQ",
    "id" : 660131030674731008,
    "created_at" : "2015-10-30 16:27:57 +0000",
    "user" : {
      "name" : "Samantha",
      "screen_name" : "sammmnic",
      "protected" : false,
      "id_str" : "186935955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778337699321122816\/FoLXj_G-_normal.jpg",
      "id" : 186935955,
      "verified" : false
    }
  },
  "id" : 660135358584258560,
  "created_at" : "2015-10-30 16:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/BtBXzbmB2T",
      "expanded_url" : "https:\/\/shar.es\/153c2B",
      "display_url" : "shar.es\/153c2B"
    } ]
  },
  "geo" : { },
  "id_str" : "660123344314961920",
  "text" : "How To Respond to Other Christians Who Quote \u201CI am THE Way\u201D https:\/\/t.co\/BtBXzbmB2T",
  "id" : 660123344314961920,
  "created_at" : "2015-10-30 15:57:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Taylor",
      "screen_name" : "Via",
      "indices" : [ 81, 85 ],
      "id_str" : "23029067",
      "id" : 23029067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/CkLxxA5VTt",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/10\/a-late-night-existential-experience-with-an-asian-beetle\/",
      "display_url" : "brucegerencser.net\/2015\/10\/a-late\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660122313942310912",
  "text" : "A Late Night Existential Experience with An Asian Beetle https:\/\/t.co\/CkLxxA5VTt @via BruceGerencser",
  "id" : 660122313942310912,
  "created_at" : "2015-10-30 15:53:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FACE",
      "screen_name" : "FACEmafia",
      "indices" : [ 3, 13 ],
      "id_str" : "21633042",
      "id" : 21633042
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FACEmafia\/status\/659903883922272256\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/9gjkrXBodl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CShzFRnXIAA8yLZ.jpg",
      "id_str" : "659903879874813952",
      "id" : 659903879874813952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShzFRnXIAA8yLZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/9gjkrXBodl"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/FACEmafia\/status\/659903883922272256\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/9gjkrXBodl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CShzFRrWoAAMxAE.jpg",
      "id_str" : "659903879891558400",
      "id" : 659903879891558400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShzFRrWoAAMxAE.jpg",
      "sizes" : [ {
        "h" : 348,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/9gjkrXBodl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660116801884446725",
  "text" : "RT @FACEmafia: Killed it https:\/\/t.co\/9gjkrXBodl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FACEmafia\/status\/659903883922272256\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/9gjkrXBodl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CShzFRnXIAA8yLZ.jpg",
        "id_str" : "659903879874813952",
        "id" : 659903879874813952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShzFRnXIAA8yLZ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 566
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 566
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 566
        } ],
        "display_url" : "pic.twitter.com\/9gjkrXBodl"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FACEmafia\/status\/659903883922272256\/photo\/1",
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/9gjkrXBodl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CShzFRrWoAAMxAE.jpg",
        "id_str" : "659903879891558400",
        "id" : 659903879891558400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShzFRrWoAAMxAE.jpg",
        "sizes" : [ {
          "h" : 348,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/9gjkrXBodl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659903883922272256",
    "text" : "Killed it https:\/\/t.co\/9gjkrXBodl",
    "id" : 659903883922272256,
    "created_at" : "2015-10-30 01:25:21 +0000",
    "user" : {
      "name" : "FACE",
      "screen_name" : "FACEmafia",
      "protected" : false,
      "id_str" : "21633042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564143049849450496\/aHsVywYE_normal.jpeg",
      "id" : 21633042,
      "verified" : false
    }
  },
  "id" : 660116801884446725,
  "created_at" : "2015-10-30 15:31:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fowl Language Comics",
      "screen_name" : "fowlcomics",
      "indices" : [ 3, 14 ],
      "id_str" : "2211333032",
      "id" : 2211333032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/oaMvxRLG84",
      "expanded_url" : "http:\/\/www.fowllanguagecomics.com\/princess-costume-bonus-panel\/",
      "display_url" : "fowllanguagecomics.com\/princess-costu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660114008234729472",
  "text" : "RT @fowlcomics: This made a bunch of folks mad last year when I posted it...so here it is again. \uD83D\uDE09\nhttps:\/\/t.co\/oaMvxRLG84 https:\/\/t.co\/U20\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fowlcomics\/status\/659807683554357248\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/U20AVcGDNB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSgblg8U8AAZU44.jpg",
        "id_str" : "659807676721852416",
        "id" : 659807676721852416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSgblg8U8AAZU44.jpg",
        "sizes" : [ {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/U20AVcGDNB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/oaMvxRLG84",
        "expanded_url" : "http:\/\/www.fowllanguagecomics.com\/princess-costume-bonus-panel\/",
        "display_url" : "fowllanguagecomics.com\/princess-costu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659807683554357248",
    "text" : "This made a bunch of folks mad last year when I posted it...so here it is again. \uD83D\uDE09\nhttps:\/\/t.co\/oaMvxRLG84 https:\/\/t.co\/U20AVcGDNB",
    "id" : 659807683554357248,
    "created_at" : "2015-10-29 19:03:05 +0000",
    "user" : {
      "name" : "Fowl Language Comics",
      "screen_name" : "fowlcomics",
      "protected" : false,
      "id_str" : "2211333032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700010615859875841\/716iEWW6_normal.jpg",
      "id" : 2211333032,
      "verified" : false
    }
  },
  "id" : 660114008234729472,
  "created_at" : "2015-10-30 15:20:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BetaList",
      "screen_name" : "BetaList",
      "indices" : [ 3, 12 ],
      "id_str" : "212711552",
      "id" : 212711552
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BetaList\/status\/660111571805425665\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/yTtgQk1IND",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkv-hxWwAATwhn.jpg",
      "id_str" : "660111571650265088",
      "id" : 660111571650265088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkv-hxWwAATwhn.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/yTtgQk1IND"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/ucnBhFT5uh",
      "expanded_url" : "http:\/\/bit.ly\/1MxAE7Q",
      "display_url" : "bit.ly\/1MxAE7Q"
    } ]
  },
  "geo" : { },
  "id_str" : "660113317550301184",
  "text" : "RT @BetaList: local web: The last mile of the world wide web https:\/\/t.co\/ucnBhFT5uh https:\/\/t.co\/yTtgQk1IND",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/betalist.com\" rel=\"nofollow\"\u003EBetaList\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BetaList\/status\/660111571805425665\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/yTtgQk1IND",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkv-hxWwAATwhn.jpg",
        "id_str" : "660111571650265088",
        "id" : 660111571650265088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkv-hxWwAATwhn.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 774,
          "resize" : "fit",
          "w" : 1032
        } ],
        "display_url" : "pic.twitter.com\/yTtgQk1IND"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/ucnBhFT5uh",
        "expanded_url" : "http:\/\/bit.ly\/1MxAE7Q",
        "display_url" : "bit.ly\/1MxAE7Q"
      } ]
    },
    "geo" : { },
    "id_str" : "660111571805425665",
    "text" : "local web: The last mile of the world wide web https:\/\/t.co\/ucnBhFT5uh https:\/\/t.co\/yTtgQk1IND",
    "id" : 660111571805425665,
    "created_at" : "2015-10-30 15:10:37 +0000",
    "user" : {
      "name" : "BetaList",
      "screen_name" : "BetaList",
      "protected" : false,
      "id_str" : "212711552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752893007188389888\/3NA2j8vv_normal.jpg",
      "id" : 212711552,
      "verified" : true
    }
  },
  "id" : 660113317550301184,
  "created_at" : "2015-10-30 15:17:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/505203304297943040\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/PZ6FGX3rGx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwLXunoIMAAJK_D.jpg",
      "id_str" : "505203304130162688",
      "id" : 505203304130162688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwLXunoIMAAJK_D.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 556
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 556
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 556
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PZ6FGX3rGx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660111994054422529",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/PZ6FGX3rGx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/505203304297943040\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/PZ6FGX3rGx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwLXunoIMAAJK_D.jpg",
        "id_str" : "505203304130162688",
        "id" : 505203304130162688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwLXunoIMAAJK_D.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 556
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 556
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 556
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PZ6FGX3rGx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660109152056942592",
    "text" : "https:\/\/t.co\/PZ6FGX3rGx",
    "id" : 660109152056942592,
    "created_at" : "2015-10-30 15:01:00 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 660111994054422529,
  "created_at" : "2015-10-30 15:12:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Android Authority",
      "screen_name" : "AndroidAuth",
      "indices" : [ 3, 15 ],
      "id_str" : "95438524",
      "id" : 95438524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deal",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "monster",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/zOirBNzNDd",
      "expanded_url" : "http:\/\/goo.gl\/PfGAR9",
      "display_url" : "goo.gl\/PfGAR9"
    } ]
  },
  "geo" : { },
  "id_str" : "660110593576321028",
  "text" : "RT @AndroidAuth: #deal: only $24.99 for two #monster flash drives you can stick right into smartphones https:\/\/t.co\/zOirBNzNDd https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.androidauthority.com\" rel=\"nofollow\"\u003EAndroidAuth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndroidAuth\/status\/660108010749054976\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/ttiXrrhp6N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSksvNuUEAAsJE1.jpg",
        "id_str" : "660108010035875840",
        "id" : 660108010035875840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSksvNuUEAAsJE1.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/ttiXrrhp6N"
      } ],
      "hashtags" : [ {
        "text" : "deal",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "monster",
        "indices" : [ 27, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/zOirBNzNDd",
        "expanded_url" : "http:\/\/goo.gl\/PfGAR9",
        "display_url" : "goo.gl\/PfGAR9"
      } ]
    },
    "geo" : { },
    "id_str" : "660108010749054976",
    "text" : "#deal: only $24.99 for two #monster flash drives you can stick right into smartphones https:\/\/t.co\/zOirBNzNDd https:\/\/t.co\/ttiXrrhp6N",
    "id" : 660108010749054976,
    "created_at" : "2015-10-30 14:56:28 +0000",
    "user" : {
      "name" : "Android Authority",
      "screen_name" : "AndroidAuth",
      "protected" : false,
      "id_str" : "95438524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651260268236812289\/vbpawQ35_normal.png",
      "id" : 95438524,
      "verified" : true
    }
  },
  "id" : 660110593576321028,
  "created_at" : "2015-10-30 15:06:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660102330449321985",
  "text" : "ugh.. Back to Vista? Hope it lets me upgrade back to 7 again.",
  "id" : 660102330449321985,
  "created_at" : "2015-10-30 14:33:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660096997517602816",
  "text" : "Restoring c: drive underway. Goodbye old stuff.",
  "id" : 660096997517602816,
  "created_at" : "2015-10-30 14:12:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/gYbQKxF0Pz",
      "expanded_url" : "http:\/\/too.lol",
      "display_url" : "too.lol"
    } ]
  },
  "in_reply_to_status_id_str" : "659921778446237696",
  "geo" : { },
  "id_str" : "659923061479751680",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind omg.. me,https:\/\/t.co\/gYbQKxF0Pz",
  "id" : 659923061479751680,
  "in_reply_to_status_id" : 659921778446237696,
  "created_at" : "2015-10-30 02:41:33 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura B.",
      "screen_name" : "ABBestphotos",
      "indices" : [ 3, 16 ],
      "id_str" : "963523560",
      "id" : 963523560
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pumpkin",
      "indices" : [ 44, 52 ]
    }, {
      "text" : "birds",
      "indices" : [ 57, 63 ]
    }, {
      "text" : "squirrels",
      "indices" : [ 64, 74 ]
    }, {
      "text" : "birdfeeder",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "halloween",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659914065079308288",
  "text" : "RT @ABBestphotos: Reminder to grab an extra #pumpkin for #birds #squirrels :) can be used as #birdfeeder all winter. #halloween https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/659881028547444737\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/89lUrhDboF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSheSQ9U8AANZXL.jpg",
        "id_str" : "659881013292625920",
        "id" : 659881013292625920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSheSQ9U8AANZXL.jpg",
        "sizes" : [ {
          "h" : 463,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/89lUrhDboF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/659881028547444737\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/89lUrhDboF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSheRx8UcAEexcv.jpg",
        "id_str" : "659881004966899713",
        "id" : 659881004966899713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSheRx8UcAEexcv.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 860,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1008,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/89lUrhDboF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/659881028547444737\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/89lUrhDboF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSheTBSUkAA1QPO.jpg",
        "id_str" : "659881026265583616",
        "id" : 659881026265583616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSheTBSUkAA1QPO.jpg",
        "sizes" : [ {
          "h" : 769,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/89lUrhDboF"
      } ],
      "hashtags" : [ {
        "text" : "pumpkin",
        "indices" : [ 26, 34 ]
      }, {
        "text" : "birds",
        "indices" : [ 39, 45 ]
      }, {
        "text" : "squirrels",
        "indices" : [ 46, 56 ]
      }, {
        "text" : "birdfeeder",
        "indices" : [ 75, 86 ]
      }, {
        "text" : "halloween",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659881028547444737",
    "text" : "Reminder to grab an extra #pumpkin for #birds #squirrels :) can be used as #birdfeeder all winter. #halloween https:\/\/t.co\/89lUrhDboF",
    "id" : 659881028547444737,
    "created_at" : "2015-10-29 23:54:31 +0000",
    "user" : {
      "name" : "Laura B.",
      "screen_name" : "ABBestphotos",
      "protected" : false,
      "id_str" : "963523560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762858708418244608\/qL1VkoJh_normal.jpg",
      "id" : 963523560,
      "verified" : false
    }
  },
  "id" : 659914065079308288,
  "created_at" : "2015-10-30 02:05:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/659837900792725504\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/SDZVmrIpzy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSg3EC3WoAAIi_T.jpg",
      "id_str" : "659837888037822464",
      "id" : 659837888037822464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSg3EC3WoAAIi_T.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SDZVmrIpzy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659839727160467456",
  "text" : "RT @zacaplus: https:\/\/t.co\/SDZVmrIpzy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/659837900792725504\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/SDZVmrIpzy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSg3EC3WoAAIi_T.jpg",
        "id_str" : "659837888037822464",
        "id" : 659837888037822464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSg3EC3WoAAIi_T.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/SDZVmrIpzy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659837900792725504",
    "text" : "https:\/\/t.co\/SDZVmrIpzy",
    "id" : 659837900792725504,
    "created_at" : "2015-10-29 21:03:09 +0000",
    "user" : {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "protected" : false,
      "id_str" : "1316959200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711110597593702400\/FL6-Tb30_normal.jpg",
      "id" : 1316959200,
      "verified" : false
    }
  },
  "id" : 659839727160467456,
  "created_at" : "2015-10-29 21:10:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659818166449799168",
  "text" : "It feels sooo good! DD: Mom! Me: (puts it in her hands) DD: Ohhh.",
  "id" : 659818166449799168,
  "created_at" : "2015-10-29 19:44:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "indices" : [ 3, 14 ],
      "id_str" : "1922414958",
      "id" : 1922414958
    }, {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 35, 39 ],
      "id_str" : "15134240",
      "id" : 15134240
    }, {
      "name" : "Brian Vastag",
      "screen_name" : "brianvastag",
      "indices" : [ 106, 118 ],
      "id_str" : "117576644",
      "id" : 117576644
    }, {
      "name" : "Janet Dafoe",
      "screen_name" : "JanetDafoe",
      "indices" : [ 119, 130 ],
      "id_str" : "2544045019",
      "id" : 2544045019
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ME",
      "indices" : [ 55, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/twNMtrRNA9",
      "expanded_url" : "https:\/\/twitter.com\/nih\/status\/659732286141767684",
      "display_url" : "twitter.com\/nih\/status\/659\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659777413111484416",
  "text" : "RT @LonnieRhea: BREAKING NEWS: The @NIH is Launching A #ME\/CFS Clinical Study. https:\/\/t.co\/twNMtrRNA9 cc @brianvastag @JanetDafoe https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NIH",
        "screen_name" : "NIH",
        "indices" : [ 19, 23 ],
        "id_str" : "15134240",
        "id" : 15134240
      }, {
        "name" : "Brian Vastag",
        "screen_name" : "brianvastag",
        "indices" : [ 90, 102 ],
        "id_str" : "117576644",
        "id" : 117576644
      }, {
        "name" : "Janet Dafoe",
        "screen_name" : "JanetDafoe",
        "indices" : [ 103, 114 ],
        "id_str" : "2544045019",
        "id" : 2544045019
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LonnieRhea\/status\/659760151621013504\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/U86yz3Xu9Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfwXLLU8AACy0J.jpg",
        "id_str" : "659760151361024000",
        "id" : 659760151361024000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfwXLLU8AACy0J.jpg",
        "sizes" : [ {
          "h" : 261,
          "resize" : "fit",
          "w" : 623
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 623
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 142,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/U86yz3Xu9Z"
      } ],
      "hashtags" : [ {
        "text" : "ME",
        "indices" : [ 39, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/twNMtrRNA9",
        "expanded_url" : "https:\/\/twitter.com\/nih\/status\/659732286141767684",
        "display_url" : "twitter.com\/nih\/status\/659\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659760151621013504",
    "text" : "BREAKING NEWS: The @NIH is Launching A #ME\/CFS Clinical Study. https:\/\/t.co\/twNMtrRNA9 cc @brianvastag @JanetDafoe https:\/\/t.co\/U86yz3Xu9Z",
    "id" : 659760151621013504,
    "created_at" : "2015-10-29 15:54:12 +0000",
    "user" : {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "protected" : false,
      "id_str" : "1922414958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738411243678007297\/OesFzoaA_normal.jpg",
      "id" : 1922414958,
      "verified" : false
    }
  },
  "id" : 659777413111484416,
  "created_at" : "2015-10-29 17:02:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "indices" : [ 3, 14 ],
      "id_str" : "1922414958",
      "id" : 1922414958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LymeDisease",
      "indices" : [ 117, 129 ]
    }, {
      "text" : "MEcfs",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659777242269138944",
  "text" : "RT @LonnieRhea: This is where Myalgic Encephalomyelitis &amp; so many Late Diagnosis or Chronic Infections coincide. #LymeDisease #MEcfs https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LonnieRhea\/status\/659608547248832512\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/mCqYIuzxzW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSdmea9UkAADKQ2.jpg",
        "id_str" : "659608543251697664",
        "id" : 659608543251697664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSdmea9UkAADKQ2.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mCqYIuzxzW"
      } ],
      "hashtags" : [ {
        "text" : "LymeDisease",
        "indices" : [ 101, 113 ]
      }, {
        "text" : "MEcfs",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659608547248832512",
    "text" : "This is where Myalgic Encephalomyelitis &amp; so many Late Diagnosis or Chronic Infections coincide. #LymeDisease #MEcfs https:\/\/t.co\/mCqYIuzxzW",
    "id" : 659608547248832512,
    "created_at" : "2015-10-29 05:51:47 +0000",
    "user" : {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "protected" : false,
      "id_str" : "1922414958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738411243678007297\/OesFzoaA_normal.jpg",
      "id" : 1922414958,
      "verified" : false
    }
  },
  "id" : 659777242269138944,
  "created_at" : "2015-10-29 17:02:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659770717022482432",
  "geo" : { },
  "id_str" : "659776895832236034",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind my mom,too. Had a brain hemorrhage. Damn neuro didn't show for 6+ hours! Sorry now we didn't sue.",
  "id" : 659776895832236034,
  "in_reply_to_status_id" : 659770717022482432,
  "created_at" : "2015-10-29 17:00:44 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "indices" : [ 65, 75 ],
      "id_str" : "194209267",
      "id" : 194209267
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/herovshelf\/status\/659750551643676673\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/DaUftHLiUo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfnoJVWsAADNlj.jpg",
      "id_str" : "659750547319336960",
      "id" : 659750547319336960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfnoJVWsAADNlj.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DaUftHLiUo"
    } ],
    "hashtags" : [ {
      "text" : "NationalCatDay",
      "indices" : [ 49, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659758325735825408",
  "text" : "RT @herovshelf: The Cat on The Girl on the Train #NationalCatDay @EpicReads https:\/\/t.co\/DaUftHLiUo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Epic Reads",
        "screen_name" : "EpicReads",
        "indices" : [ 49, 59 ],
        "id_str" : "194209267",
        "id" : 194209267
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/herovshelf\/status\/659750551643676673\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/DaUftHLiUo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfnoJVWsAADNlj.jpg",
        "id_str" : "659750547319336960",
        "id" : 659750547319336960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfnoJVWsAADNlj.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DaUftHLiUo"
      } ],
      "hashtags" : [ {
        "text" : "NationalCatDay",
        "indices" : [ 33, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659750551643676673",
    "text" : "The Cat on The Girl on the Train #NationalCatDay @EpicReads https:\/\/t.co\/DaUftHLiUo",
    "id" : 659750551643676673,
    "created_at" : "2015-10-29 15:16:03 +0000",
    "user" : {
      "name" : "Nicole Schaefer",
      "screen_name" : "nebschaefer",
      "protected" : false,
      "id_str" : "627875407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489414231041638400\/kMYuASAU_normal.jpeg",
      "id" : 627875407,
      "verified" : false
    }
  },
  "id" : 659758325735825408,
  "created_at" : "2015-10-29 15:46:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659732690019737601",
  "geo" : { },
  "id_str" : "659751188649390080",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ((sneaksintoyoursuitcase))",
  "id" : 659751188649390080,
  "in_reply_to_status_id" : 659732690019737601,
  "created_at" : "2015-10-29 15:18:35 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659739966965067776",
  "geo" : { },
  "id_str" : "659750473705136128",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides what suit? I see books! : p",
  "id" : 659750473705136128,
  "in_reply_to_status_id" : 659739966965067776,
  "created_at" : "2015-10-29 15:15:45 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Hastings",
      "screen_name" : "BeckyCT",
      "indices" : [ 3, 11 ],
      "id_str" : "22464169",
      "id" : 22464169
    }, {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 77, 84 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDCwhistleblower",
      "indices" : [ 30, 47 ]
    }, {
      "text" : "CDCTruth",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659567964845441024",
  "text" : "RT @BeckyCT: Get the facts on #CDCwhistleblower Doctors rely on CDC, but the @CDCgov has been hiding &amp; destroying data\n#CDCTruth https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CDC",
        "screen_name" : "CDCgov",
        "indices" : [ 64, 71 ],
        "id_str" : "146569971",
        "id" : 146569971
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BeckyCT\/status\/659555522899812352\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/RPRGX4j9EW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSc2QMHWUAU2KvB.jpg",
        "id_str" : "659555522190921733",
        "id" : 659555522190921733,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSc2QMHWUAU2KvB.jpg",
        "sizes" : [ {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1384,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/RPRGX4j9EW"
      } ],
      "hashtags" : [ {
        "text" : "CDCwhistleblower",
        "indices" : [ 17, 34 ]
      }, {
        "text" : "CDCTruth",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659555522899812352",
    "text" : "Get the facts on #CDCwhistleblower Doctors rely on CDC, but the @CDCgov has been hiding &amp; destroying data\n#CDCTruth https:\/\/t.co\/RPRGX4j9EW",
    "id" : 659555522899812352,
    "created_at" : "2015-10-29 02:21:05 +0000",
    "user" : {
      "name" : "Becky Hastings",
      "screen_name" : "BeckyCT",
      "protected" : false,
      "id_str" : "22464169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655385552578064384\/TjnldwY4_normal.jpg",
      "id" : 22464169,
      "verified" : false
    }
  },
  "id" : 659567964845441024,
  "created_at" : "2015-10-29 03:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rod",
      "screen_name" : "rodimusprime",
      "indices" : [ 3, 16 ],
      "id_str" : "16028034",
      "id" : 16028034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659562094359150592",
  "text" : "RT @rodimusprime: \"The president's job is to protect the citizens of the united states by supporting the police that kill them without ques\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659550292195848192",
    "text" : "\"The president's job is to protect the citizens of the united states by supporting the police that kill them without question!\" #GOPDebate",
    "id" : 659550292195848192,
    "created_at" : "2015-10-29 02:00:18 +0000",
    "user" : {
      "name" : "Rod",
      "screen_name" : "rodimusprime",
      "protected" : false,
      "id_str" : "16028034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798596330679652352\/kyU7GJII_normal.jpg",
      "id" : 16028034,
      "verified" : true
    }
  },
  "id" : 659562094359150592,
  "created_at" : "2015-10-29 02:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 36, 52 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659551139591942144",
  "geo" : { },
  "id_str" : "659561960376176641",
  "in_reply_to_user_id" : 24233147,
  "text" : "Good question! I shall ponder... RT @fairlyspiritual So what's a plank God has shown you in your eye?",
  "id" : 659561960376176641,
  "in_reply_to_status_id" : 659551139591942144,
  "created_at" : "2015-10-29 02:46:40 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "indices" : [ 3, 12 ],
      "id_str" : "116786271",
      "id" : 116786271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659561028875894785",
  "text" : "RT @AniArene: #GOPDebate raising the age? Paul must not realize effects of aging are. People shouldn't have to work while losing sight, hea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659550739681951744",
    "text" : "#GOPDebate raising the age? Paul must not realize effects of aging are. People shouldn't have to work while losing sight, hearing, in pain",
    "id" : 659550739681951744,
    "created_at" : "2015-10-29 02:02:04 +0000",
    "user" : {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "protected" : false,
      "id_str" : "116786271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797875002725036032\/G_rxW-Dq_normal.jpg",
      "id" : 116786271,
      "verified" : false
    }
  },
  "id" : 659561028875894785,
  "created_at" : "2015-10-29 02:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "W. Kamau Bell",
      "screen_name" : "wkamaubell",
      "indices" : [ 3, 14 ],
      "id_str" : "19119809",
      "id" : 19119809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659559710308347904",
  "text" : "RT @wkamaubell: \"We don't know the whole story!\"\n\"Oh, It begins w\/ the transatlantic slave trade... Where you going? I THOUGHT YOU WANTED T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659144745151651841",
    "text" : "\"We don't know the whole story!\"\n\"Oh, It begins w\/ the transatlantic slave trade... Where you going? I THOUGHT YOU WANTED THE WHOLE STORY!\"",
    "id" : 659144745151651841,
    "created_at" : "2015-10-27 23:08:48 +0000",
    "user" : {
      "name" : "W. Kamau Bell",
      "screen_name" : "wkamaubell",
      "protected" : false,
      "id_str" : "19119809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719665099368112129\/utYxfXv1_normal.jpg",
      "id" : 19119809,
      "verified" : true
    }
  },
  "id" : 659559710308347904,
  "created_at" : "2015-10-29 02:37:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659558776182325248",
  "text" : "RT @CharlesBivona: Legitimate public service, as opposed to political public service... #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659548962207219712",
    "text" : "Legitimate public service, as opposed to political public service... #GOPDebate",
    "id" : 659548962207219712,
    "created_at" : "2015-10-29 01:55:01 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 659558776182325248,
  "created_at" : "2015-10-29 02:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Taibbi",
      "screen_name" : "mtaibbi",
      "indices" : [ 3, 11 ],
      "id_str" : "38271276",
      "id" : 38271276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659547214071623681",
  "text" : "RT @mtaibbi: Who overdoses on weed, Kasich? Just try!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659545080076849152",
    "text" : "Who overdoses on weed, Kasich? Just try!",
    "id" : 659545080076849152,
    "created_at" : "2015-10-29 01:39:35 +0000",
    "user" : {
      "name" : "Matt Taibbi",
      "screen_name" : "mtaibbi",
      "protected" : false,
      "id_str" : "38271276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793479965786406912\/oFwEUBrO_normal.jpg",
      "id" : 38271276,
      "verified" : true
    }
  },
  "id" : 659547214071623681,
  "created_at" : "2015-10-29 01:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Ritchie",
      "screen_name" : "AMRFCR",
      "indices" : [ 13, 20 ],
      "id_str" : "971676050",
      "id" : 971676050
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 51, 63 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AMRFCR\/status\/659081945947742208\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/fzhBv64tYq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWHiXiWoAAjZyc.jpg",
      "id_str" : "659081944983052288",
      "id" : 659081944983052288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWHiXiWoAAjZyc.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2796,
        "resize" : "fit",
        "w" : 3728
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fzhBv64tYq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659531135962189824",
  "text" : "Precious! RT @AMRFCR: Turnstones at Burghead today @wildlife_uk https:\/\/t.co\/fzhBv64tYq",
  "id" : 659531135962189824,
  "created_at" : "2015-10-29 00:44:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOH8 Campaign",
      "screen_name" : "NOH8Campaign",
      "indices" : [ 3, 16 ],
      "id_str" : "32774989",
      "id" : 32774989
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NOH8Campaign\/status\/659481868488695808\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/FaCrWNeaCr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSbzQ8uUkAA6ik7.jpg",
      "id_str" : "659481867960225792",
      "id" : 659481867960225792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSbzQ8uUkAA6ik7.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FaCrWNeaCr"
    } ],
    "hashtags" : [ {
      "text" : "NOH8",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659528729409028096",
  "text" : "RT @NOH8Campaign: A simple but important reminder for parents. #NOH8 https:\/\/t.co\/FaCrWNeaCr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOH8Campaign\/status\/659481868488695808\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/FaCrWNeaCr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSbzQ8uUkAA6ik7.jpg",
        "id_str" : "659481867960225792",
        "id" : 659481867960225792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSbzQ8uUkAA6ik7.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FaCrWNeaCr"
      } ],
      "hashtags" : [ {
        "text" : "NOH8",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659481868488695808",
    "text" : "A simple but important reminder for parents. #NOH8 https:\/\/t.co\/FaCrWNeaCr",
    "id" : 659481868488695808,
    "created_at" : "2015-10-28 21:28:24 +0000",
    "user" : {
      "name" : "NOH8 Campaign",
      "screen_name" : "NOH8Campaign",
      "protected" : false,
      "id_str" : "32774989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790969172234764288\/hBs2JudQ_normal.jpg",
      "id" : 32774989,
      "verified" : true
    }
  },
  "id" : 659528729409028096,
  "created_at" : "2015-10-29 00:34:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659482045073235968",
  "geo" : { },
  "id_str" : "659528309307502592",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe what?? Jeeeezzzz..",
  "id" : 659528309307502592,
  "in_reply_to_status_id" : 659482045073235968,
  "created_at" : "2015-10-29 00:32:57 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659468633706467328",
  "text" : "DD had a good 1st counsel session. Came out w worksheets very excited..lol",
  "id" : 659468633706467328,
  "created_at" : "2015-10-28 20:35:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KSOD",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659464924054319105",
  "text" : "Is there a way to save stuff from command prompt b4 I do recovery? Have USB drive. #KSOD",
  "id" : 659464924054319105,
  "created_at" : "2015-10-28 20:21:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659407992555765760",
  "geo" : { },
  "id_str" : "659435798677340160",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides uh-oh spider on the run!",
  "id" : 659435798677340160,
  "in_reply_to_status_id" : 659407992555765760,
  "created_at" : "2015-10-28 18:25:20 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooke Aitken",
      "screen_name" : "brookeaitken",
      "indices" : [ 3, 16 ],
      "id_str" : "67443483",
      "id" : 67443483
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/brookeaitken\/status\/659343999556128768\/video\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/5LALtZXMYI",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/659343623104794624\/pu\/img\/yCGaHmDoXZi70073.jpg",
      "id_str" : "659343623104794624",
      "id" : 659343623104794624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/659343623104794624\/pu\/img\/yCGaHmDoXZi70073.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5LALtZXMYI"
    } ],
    "hashtags" : [ {
      "text" : "sheepelk",
      "indices" : [ 60, 69 ]
    }, {
      "text" : "thingsyoudontseeeveryday",
      "indices" : [ 70, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659435479134314496",
  "text" : "RT @brookeaitken: One of these things is not like the other #sheepelk #thingsyoudontseeeveryday https:\/\/t.co\/5LALtZXMYI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brookeaitken\/status\/659343999556128768\/video\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/5LALtZXMYI",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/659343623104794624\/pu\/img\/yCGaHmDoXZi70073.jpg",
        "id_str" : "659343623104794624",
        "id" : 659343623104794624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/659343623104794624\/pu\/img\/yCGaHmDoXZi70073.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5LALtZXMYI"
      } ],
      "hashtags" : [ {
        "text" : "sheepelk",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "thingsyoudontseeeveryday",
        "indices" : [ 52, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659343999556128768",
    "text" : "One of these things is not like the other #sheepelk #thingsyoudontseeeveryday https:\/\/t.co\/5LALtZXMYI",
    "id" : 659343999556128768,
    "created_at" : "2015-10-28 12:20:34 +0000",
    "user" : {
      "name" : "Brooke Aitken",
      "screen_name" : "brookeaitken",
      "protected" : false,
      "id_str" : "67443483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2365315267\/oyysp0rly0ym4817791s_normal.jpeg",
      "id" : 67443483,
      "verified" : false
    }
  },
  "id" : 659435479134314496,
  "created_at" : "2015-10-28 18:24:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Jarvis \uD83D\uDC2D",
      "screen_name" : "pjrvs",
      "indices" : [ 3, 9 ],
      "id_str" : "133060482",
      "id" : 133060482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pjrvs\/status\/659197889122447361\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/XX5X4jiOhU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXw_F7UkAAxjPs.jpg",
      "id_str" : "659197887193059328",
      "id" : 659197887193059328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXw_F7UkAAxjPs.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XX5X4jiOhU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659199572460351488",
  "text" : "RT @pjrvs: https:\/\/t.co\/XX5X4jiOhU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pjrvs\/status\/659197889122447361\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/XX5X4jiOhU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXw_F7UkAAxjPs.jpg",
        "id_str" : "659197887193059328",
        "id" : 659197887193059328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXw_F7UkAAxjPs.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XX5X4jiOhU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659197889122447361",
    "text" : "https:\/\/t.co\/XX5X4jiOhU",
    "id" : 659197889122447361,
    "created_at" : "2015-10-28 02:39:58 +0000",
    "user" : {
      "name" : "Paul Jarvis \uD83D\uDC2D",
      "screen_name" : "pjrvs",
      "protected" : false,
      "id_str" : "133060482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730033625970794498\/RkP4yIqp_normal.jpg",
      "id" : 133060482,
      "verified" : true
    }
  },
  "id" : 659199572460351488,
  "created_at" : "2015-10-28 02:46:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "indices" : [ 3, 17 ],
      "id_str" : "195173057",
      "id" : 195173057
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lindapoitevin\/status\/659186304584802304\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/ZAVIVH2WrF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXmcPqVEAATVrg.jpg",
      "id_str" : "659186293394444288",
      "id" : 659186293394444288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXmcPqVEAATVrg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZAVIVH2WrF"
    } ],
    "hashtags" : [ {
      "text" : "crochet",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659192422686138368",
  "text" : "RT @lindapoitevin: And #crochet loses to floof again. \uD83D\uDE09 https:\/\/t.co\/ZAVIVH2WrF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lindapoitevin\/status\/659186304584802304\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/ZAVIVH2WrF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXmcPqVEAATVrg.jpg",
        "id_str" : "659186293394444288",
        "id" : 659186293394444288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXmcPqVEAATVrg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZAVIVH2WrF"
      } ],
      "hashtags" : [ {
        "text" : "crochet",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659186304584802304",
    "text" : "And #crochet loses to floof again. \uD83D\uDE09 https:\/\/t.co\/ZAVIVH2WrF",
    "id" : 659186304584802304,
    "created_at" : "2015-10-28 01:53:56 +0000",
    "user" : {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "protected" : false,
      "id_str" : "195173057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653593067958571008\/PyqlHnTV_normal.jpg",
      "id" : 195173057,
      "verified" : false
    }
  },
  "id" : 659192422686138368,
  "created_at" : "2015-10-28 02:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/659187331681927168\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/GuUyGseLYt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXnYrAXIAAo50v.jpg",
      "id_str" : "659187331526762496",
      "id" : 659187331526762496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXnYrAXIAAo50v.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 746,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GuUyGseLYt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659191628574388224",
  "text" : "RT @SciencePorn: Math tip https:\/\/t.co\/GuUyGseLYt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/659187331681927168\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/GuUyGseLYt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXnYrAXIAAo50v.jpg",
        "id_str" : "659187331526762496",
        "id" : 659187331526762496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXnYrAXIAAo50v.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 772
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GuUyGseLYt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659187331681927168",
    "text" : "Math tip https:\/\/t.co\/GuUyGseLYt",
    "id" : 659187331681927168,
    "created_at" : "2015-10-28 01:58:01 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 659191628574388224,
  "created_at" : "2015-10-28 02:15:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Ocean \u0950",
      "screen_name" : "Inside_Truth",
      "indices" : [ 3, 16 ],
      "id_str" : "1327416252",
      "id" : 1327416252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659190589146189825",
  "text" : "RT @Inside_Truth: I think, therefore I'm confused",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659162368820269056",
    "text" : "I think, therefore I'm confused",
    "id" : 659162368820269056,
    "created_at" : "2015-10-28 00:18:50 +0000",
    "user" : {
      "name" : "Cosmic Ocean \u0950",
      "screen_name" : "Inside_Truth",
      "protected" : false,
      "id_str" : "1327416252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786744947789684736\/giXyL4So_normal.jpg",
      "id" : 1327416252,
      "verified" : false
    }
  },
  "id" : 659190589146189825,
  "created_at" : "2015-10-28 02:10:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/MOrbvIzEh4",
      "expanded_url" : "http:\/\/omnideist.tumblr.com\/",
      "display_url" : "omnideist.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "659190274430779392",
  "text" : "RT @Pandeism: https:\/\/t.co\/MOrbvIzEh4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/MOrbvIzEh4",
        "expanded_url" : "http:\/\/omnideist.tumblr.com\/",
        "display_url" : "omnideist.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "659188821347692544",
    "text" : "https:\/\/t.co\/MOrbvIzEh4",
    "id" : 659188821347692544,
    "created_at" : "2015-10-28 02:03:56 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 659190274430779392,
  "created_at" : "2015-10-28 02:09:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Robbins",
      "screen_name" : "imstilljosh",
      "indices" : [ 3, 15 ],
      "id_str" : "489851075",
      "id" : 489851075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIVscoop",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659188555672064000",
  "text" : "RT @imstilljosh: \uD83D\uDCA5Prior to my interview w\/ Martin Shkreli, I've received an exclusive statement from Mark Baum of Imprimis #HIVscoop https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/imstilljosh\/status\/658106086331781120\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/0yd1a9rB7U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSIP_nwUsAAI70b.jpg",
        "id_str" : "658106081227354112",
        "id" : 658106081227354112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSIP_nwUsAAI70b.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0yd1a9rB7U"
      } ],
      "hashtags" : [ {
        "text" : "HIVscoop",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658106086331781120",
    "text" : "\uD83D\uDCA5Prior to my interview w\/ Martin Shkreli, I've received an exclusive statement from Mark Baum of Imprimis #HIVscoop https:\/\/t.co\/0yd1a9rB7U",
    "id" : 658106086331781120,
    "created_at" : "2015-10-25 02:21:32 +0000",
    "user" : {
      "name" : "Josh Robbins",
      "screen_name" : "imstilljosh",
      "protected" : false,
      "id_str" : "489851075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649272844497612800\/iCMC7JWE_normal.jpg",
      "id" : 489851075,
      "verified" : false
    }
  },
  "id" : 659188555672064000,
  "created_at" : "2015-10-28 02:02:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659148338416197633",
  "text" : "I guess I have to do recovery on laptop. I've tried many things to fix. Minor disappointment in scheme of things I suppose.",
  "id" : 659148338416197633,
  "created_at" : "2015-10-27 23:23:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 77, 85 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CISA",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659146968682397696",
  "text" : "RT @Silvercrone: The Public needs a PAC. Elected Officials not enough&gt; RT @Snowden: Banks, telcos happiest with #CISA while public disappoi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edward Snowden",
        "screen_name" : "Snowden",
        "indices" : [ 60, 68 ],
        "id_str" : "2916305152",
        "id" : 2916305152
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CISA",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "influence",
        "indices" : [ 131, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659146153502580736",
    "text" : "The Public needs a PAC. Elected Officials not enough&gt; RT @Snowden: Banks, telcos happiest with #CISA while public disappointed. #influence",
    "id" : 659146153502580736,
    "created_at" : "2015-10-27 23:14:23 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 659146968682397696,
  "created_at" : "2015-10-27 23:17:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Kiely",
      "screen_name" : "aroyallkiely",
      "indices" : [ 3, 16 ],
      "id_str" : "41524895",
      "id" : 41524895
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChronicLife",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659126242092929024",
  "text" : "RT @aroyallkiely: Very excited for this event - Dana has lots of tips to share for the #ChronicLife regardless of condition. https:\/\/t.co\/l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChronicLife",
        "indices" : [ 69, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/lAJsRwC4h6",
        "expanded_url" : "https:\/\/twitter.com\/HypothyroidMom\/status\/658698281380352000",
        "display_url" : "twitter.com\/HypothyroidMom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659015595208257536",
    "text" : "Very excited for this event - Dana has lots of tips to share for the #ChronicLife regardless of condition. https:\/\/t.co\/lAJsRwC4h6",
    "id" : 659015595208257536,
    "created_at" : "2015-10-27 14:35:36 +0000",
    "user" : {
      "name" : "Amanda Kiely",
      "screen_name" : "aroyallkiely",
      "protected" : false,
      "id_str" : "41524895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601046216961470464\/-QgkilpM_normal.jpg",
      "id" : 41524895,
      "verified" : false
    }
  },
  "id" : 659126242092929024,
  "created_at" : "2015-10-27 21:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debby Saunders",
      "screen_name" : "debbyseamist",
      "indices" : [ 3, 16 ],
      "id_str" : "973618075",
      "id" : 973618075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/debbyseamist\/status\/659055672802320384\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/88YBy1km8Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVvpDnXIAAVzGE.jpg",
      "id_str" : "659055671615365120",
      "id" : 659055671615365120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVvpDnXIAAVzGE.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/88YBy1km8Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659114197935091714",
  "text" : "RT @debbyseamist: A bit of cuteness on the patio this afternoon https:\/\/t.co\/88YBy1km8Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/debbyseamist\/status\/659055672802320384\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/88YBy1km8Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVvpDnXIAAVzGE.jpg",
        "id_str" : "659055671615365120",
        "id" : 659055671615365120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVvpDnXIAAVzGE.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/88YBy1km8Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659055672802320384",
    "text" : "A bit of cuteness on the patio this afternoon https:\/\/t.co\/88YBy1km8Q",
    "id" : 659055672802320384,
    "created_at" : "2015-10-27 17:14:51 +0000",
    "user" : {
      "name" : "Debby Saunders",
      "screen_name" : "debbyseamist",
      "protected" : false,
      "id_str" : "973618075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489034159046656001\/RboSPZ9w_normal.jpeg",
      "id" : 973618075,
      "verified" : false
    }
  },
  "id" : 659114197935091714,
  "created_at" : "2015-10-27 21:07:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Rowe",
      "screen_name" : "Knatolee",
      "indices" : [ 3, 12 ],
      "id_str" : "284198732",
      "id" : 284198732
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Knatolee\/status\/658605775183597568\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HXWQuGCN5N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSPWdg4VEAAE8Hv.jpg",
      "id_str" : "658605773056970752",
      "id" : 658605773056970752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSPWdg4VEAAE8Hv.jpg",
      "sizes" : [ {
        "h" : 909,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 909,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 909,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HXWQuGCN5N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659107214653833216",
  "text" : "RT @Knatolee: Saul and his cat-buddy Emerson. These two just LOVE each other. https:\/\/t.co\/HXWQuGCN5N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Knatolee\/status\/658605775183597568\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/HXWQuGCN5N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSPWdg4VEAAE8Hv.jpg",
        "id_str" : "658605773056970752",
        "id" : 658605773056970752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSPWdg4VEAAE8Hv.jpg",
        "sizes" : [ {
          "h" : 909,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 909,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 909,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HXWQuGCN5N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658605775183597568",
    "text" : "Saul and his cat-buddy Emerson. These two just LOVE each other. https:\/\/t.co\/HXWQuGCN5N",
    "id" : 658605775183597568,
    "created_at" : "2015-10-26 11:27:07 +0000",
    "user" : {
      "name" : "Natalie Rowe",
      "screen_name" : "Knatolee",
      "protected" : false,
      "id_str" : "284198732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774704162458079232\/IYroIU-W_normal.jpg",
      "id" : 284198732,
      "verified" : false
    }
  },
  "id" : 659107214653833216,
  "created_at" : "2015-10-27 20:39:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vicki johnson",
      "screen_name" : "vjzephyr",
      "indices" : [ 3, 12 ],
      "id_str" : "22277108",
      "id" : 22277108
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makesewbake",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659106486711361536",
  "text" : "RT @vjzephyr: My first ever original needlepoint is a portrait of my dear friend's Carmela in the garden #makesewbake https:\/\/t.co\/ElBRkolO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vjzephyr\/status\/659103237484728324\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/ElBRkolOBb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWa4TOWsAAlkcL.jpg",
        "id_str" : "659103212503478272",
        "id" : 659103212503478272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWa4TOWsAAlkcL.jpg",
        "sizes" : [ {
          "h" : 672,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 672,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ElBRkolOBb"
      } ],
      "hashtags" : [ {
        "text" : "makesewbake",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659103237484728324",
    "text" : "My first ever original needlepoint is a portrait of my dear friend's Carmela in the garden #makesewbake https:\/\/t.co\/ElBRkolOBb",
    "id" : 659103237484728324,
    "created_at" : "2015-10-27 20:23:52 +0000",
    "user" : {
      "name" : "vicki johnson",
      "screen_name" : "vjzephyr",
      "protected" : false,
      "id_str" : "22277108",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/202189027\/toes_2_normal.jpg",
      "id" : 22277108,
      "verified" : false
    }
  },
  "id" : 659106486711361536,
  "created_at" : "2015-10-27 20:36:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659103177019666432",
  "geo" : { },
  "id_str" : "659106212169039872",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH oh no, ani-la. ((prayersforyourwellbeing))",
  "id" : 659106212169039872,
  "in_reply_to_status_id" : 659103177019666432,
  "created_at" : "2015-10-27 20:35:41 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah Roseman",
      "screen_name" : "roseperson",
      "indices" : [ 3, 14 ],
      "id_str" : "114216255",
      "id" : 114216255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AssaultAtSpringValleyHigh",
      "indices" : [ 72, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/N2wrtkb6d7",
      "expanded_url" : "https:\/\/twitter.com\/Nettaaaaaaaa\/status\/659009650688331777",
      "display_url" : "twitter.com\/Nettaaaaaaaa\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659098627089022976",
  "text" : "RT @roseperson: Arrested. How on earth is what this girl did a *crime*? #AssaultAtSpringValleyHigh  https:\/\/t.co\/N2wrtkb6d7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AssaultAtSpringValleyHigh",
        "indices" : [ 56, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/N2wrtkb6d7",
        "expanded_url" : "https:\/\/twitter.com\/Nettaaaaaaaa\/status\/659009650688331777",
        "display_url" : "twitter.com\/Nettaaaaaaaa\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659011883140300800",
    "text" : "Arrested. How on earth is what this girl did a *crime*? #AssaultAtSpringValleyHigh  https:\/\/t.co\/N2wrtkb6d7",
    "id" : 659011883140300800,
    "created_at" : "2015-10-27 14:20:51 +0000",
    "user" : {
      "name" : "Deborah Roseman",
      "screen_name" : "roseperson",
      "protected" : false,
      "id_str" : "114216255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552970244906430464\/SOMI15bK_normal.jpeg",
      "id" : 114216255,
      "verified" : false
    }
  },
  "id" : 659098627089022976,
  "created_at" : "2015-10-27 20:05:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659097364771291136",
  "text" : "I've got chkdsk running now but not hopeful. Might have to do a recovery.",
  "id" : 659097364771291136,
  "created_at" : "2015-10-27 20:00:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "indices" : [ 3, 15 ],
      "id_str" : "26029878",
      "id" : 26029878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jedifistbump",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658818716998705152",
  "text" : "RT @ChuckWendig: What I'm saying is, be nice and not shitty and try to help others as much as you help yourself, if not more. #jedifistbump",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jedifistbump",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658816365223124993",
    "text" : "What I'm saying is, be nice and not shitty and try to help others as much as you help yourself, if not more. #jedifistbump",
    "id" : 658816365223124993,
    "created_at" : "2015-10-27 01:23:56 +0000",
    "user" : {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "protected" : false,
      "id_str" : "26029878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642026672636731392\/_krOPqwm_normal.jpg",
      "id" : 26029878,
      "verified" : true
    }
  },
  "id" : 658818716998705152,
  "created_at" : "2015-10-27 01:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimer Antonov",
      "screen_name" : "VladimerAntonov",
      "indices" : [ 3, 19 ],
      "id_str" : "2220283584",
      "id" : 2220283584
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VladimerAntonov\/status\/658723551663538177\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/UvDe0WvlJx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSRBk8UXAAA-d1-.jpg",
      "id_str" : "658723548425551872",
      "id" : 658723548425551872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSRBk8UXAAA-d1-.jpg",
      "sizes" : [ {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UvDe0WvlJx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658818068714532864",
  "text" : "RT @VladimerAntonov: Northern Lights Over Iceberg In Northeast Greenland https:\/\/t.co\/UvDe0WvlJx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VladimerAntonov\/status\/658723551663538177\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/UvDe0WvlJx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSRBk8UXAAA-d1-.jpg",
        "id_str" : "658723548425551872",
        "id" : 658723548425551872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSRBk8UXAAA-d1-.jpg",
        "sizes" : [ {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UvDe0WvlJx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658723551663538177",
    "text" : "Northern Lights Over Iceberg In Northeast Greenland https:\/\/t.co\/UvDe0WvlJx",
    "id" : 658723551663538177,
    "created_at" : "2015-10-26 19:15:07 +0000",
    "user" : {
      "name" : "Vladimer Antonov",
      "screen_name" : "VladimerAntonov",
      "protected" : false,
      "id_str" : "2220283584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745797621420285952\/5s9s4FDX_normal.jpg",
      "id" : 2220283584,
      "verified" : false
    }
  },
  "id" : 658818068714532864,
  "created_at" : "2015-10-27 01:30:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658794052385656833",
  "text" : "RT @CrystalLewis: There are so many folks on here who seem to live in a world where police never go too far. Tell me, how do you define \"po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658793215496167424",
    "text" : "There are so many folks on here who seem to live in a world where police never go too far. Tell me, how do you define \"police brutality\"?",
    "id" : 658793215496167424,
    "created_at" : "2015-10-26 23:51:57 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 658794052385656833,
  "created_at" : "2015-10-26 23:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CISA",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658792073269788672",
  "text" : "RT @Snowden: #CISA gives companies legal immunity for violating privacy laws if they also give your data to the government. Call Congress, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CISA",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "StopCISA",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658772744780316672",
    "text" : "#CISA gives companies legal immunity for violating privacy laws if they also give your data to the government. Call Congress, #StopCISA.",
    "id" : 658772744780316672,
    "created_at" : "2015-10-26 22:30:36 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 658792073269788672,
  "created_at" : "2015-10-26 23:47:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658791761775579136",
  "text" : "I broke my laptop. All I get is black screen now.. even in safe mode.",
  "id" : 658791761775579136,
  "created_at" : "2015-10-26 23:46:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658790540767531008",
  "text" : "RT @CrystalLewis: To say \"she should have obeyed\" is to miss the point. The officer can deescalate &amp; apprehend a recalcitrant child without\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "658785403034599425",
    "geo" : { },
    "id_str" : "658786653507596288",
    "in_reply_to_user_id" : 135615040,
    "text" : "To say \"she should have obeyed\" is to miss the point. The officer can deescalate &amp; apprehend a recalcitrant child without thrashing her.",
    "id" : 658786653507596288,
    "in_reply_to_status_id" : 658785403034599425,
    "created_at" : "2015-10-26 23:25:52 +0000",
    "in_reply_to_screen_name" : "CrystalLewis",
    "in_reply_to_user_id_str" : "135615040",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 658790540767531008,
  "created_at" : "2015-10-26 23:41:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 3, 12 ],
      "id_str" : "524396430",
      "id" : 524396430
    }, {
      "name" : "Brenna Twohy",
      "screen_name" : "brennatwohy",
      "indices" : [ 15, 27 ],
      "id_str" : "2884381956",
      "id" : 2884381956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/DX2zgUqHUu",
      "expanded_url" : "http:\/\/u.pw\/1KzAaqe",
      "display_url" : "u.pw\/1KzAaqe"
    } ]
  },
  "geo" : { },
  "id_str" : "658759283551653889",
  "text" : "RT @Upworthy: .@brennatwohy's poetry reveals how having anxiety can be like living in a haunted house. https:\/\/t.co\/DX2zgUqHUu https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brenna Twohy",
        "screen_name" : "brennatwohy",
        "indices" : [ 1, 13 ],
        "id_str" : "2884381956",
        "id" : 2884381956
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Upworthy\/status\/658690344574427136\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/gMpLxMhn5M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSQjYN3WUAAe18V.jpg",
        "id_str" : "658690344448577536",
        "id" : 658690344448577536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSQjYN3WUAAe18V.jpg",
        "sizes" : [ {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gMpLxMhn5M"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/DX2zgUqHUu",
        "expanded_url" : "http:\/\/u.pw\/1KzAaqe",
        "display_url" : "u.pw\/1KzAaqe"
      } ]
    },
    "geo" : { },
    "id_str" : "658690344574427136",
    "text" : ".@brennatwohy's poetry reveals how having anxiety can be like living in a haunted house. https:\/\/t.co\/DX2zgUqHUu https:\/\/t.co\/gMpLxMhn5M",
    "id" : 658690344574427136,
    "created_at" : "2015-10-26 17:03:10 +0000",
    "user" : {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "protected" : false,
      "id_str" : "524396430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723597465941766144\/piclWuSr_normal.jpg",
      "id" : 524396430,
      "verified" : true
    }
  },
  "id" : 658759283551653889,
  "created_at" : "2015-10-26 21:37:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658484005420056577",
  "text" : "RT @deray: \"Everything you want is on the other side of fear.\" - J.C.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658472675946442753",
    "text" : "\"Everything you want is on the other side of fear.\" - J.C.",
    "id" : 658472675946442753,
    "created_at" : "2015-10-26 02:38:14 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 658484005420056577,
  "created_at" : "2015-10-26 03:23:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Push Daily",
      "screen_name" : "ThePushDaily",
      "indices" : [ 3, 16 ],
      "id_str" : "2704479084",
      "id" : 2704479084
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThePushDaily\/status\/658476888373903360\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/0igtrpmrz2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSNhNbzUAAAHgA6.jpg",
      "id_str" : "658476853955395584",
      "id" : 658476853955395584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSNhNbzUAAAHgA6.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0igtrpmrz2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ThePushDaily\/status\/658476888373903360\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/0igtrpmrz2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSNhNbfUkAAoVLd.jpg",
      "id_str" : "658476853871546368",
      "id" : 658476853871546368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSNhNbfUkAAoVLd.jpg",
      "sizes" : [ {
        "h" : 165,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/0igtrpmrz2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658483893222420480",
  "text" : "RT @ThePushDaily: Awesome! https:\/\/t.co\/0igtrpmrz2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThePushDaily\/status\/658476888373903360\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/0igtrpmrz2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSNhNbzUAAAHgA6.jpg",
        "id_str" : "658476853955395584",
        "id" : 658476853955395584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSNhNbzUAAAHgA6.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0igtrpmrz2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ThePushDaily\/status\/658476888373903360\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/0igtrpmrz2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSNhNbfUkAAoVLd.jpg",
        "id_str" : "658476853871546368",
        "id" : 658476853871546368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSNhNbfUkAAoVLd.jpg",
        "sizes" : [ {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/0igtrpmrz2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658476888373903360",
    "text" : "Awesome! https:\/\/t.co\/0igtrpmrz2",
    "id" : 658476888373903360,
    "created_at" : "2015-10-26 02:54:58 +0000",
    "user" : {
      "name" : "The Push Daily",
      "screen_name" : "ThePushDaily",
      "protected" : false,
      "id_str" : "2704479084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550865114304245760\/D1e-iUIn_normal.jpeg",
      "id" : 2704479084,
      "verified" : false
    }
  },
  "id" : 658483893222420480,
  "created_at" : "2015-10-26 03:22:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abortion",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658482724311842816",
  "text" : "RT @Pandeism: The politics of #abortion are not about life and death; they are about insuring the generation of the next generation of wage\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "abortion",
        "indices" : [ 16, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658476688020525056",
    "text" : "The politics of #abortion are not about life and death; they are about insuring the generation of the next generation of wage slaves.",
    "id" : 658476688020525056,
    "created_at" : "2015-10-26 02:54:10 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 658482724311842816,
  "created_at" : "2015-10-26 03:18:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658471745544953856",
  "text" : "RT @DharmaTalks: Keep your thoughts positive.. Replace negative thoughts with positive.. This way you stay out of fear &amp; move into love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658466913195003905",
    "text" : "Keep your thoughts positive.. Replace negative thoughts with positive.. This way you stay out of fear &amp; move into love.",
    "id" : 658466913195003905,
    "created_at" : "2015-10-26 02:15:20 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 658471745544953856,
  "created_at" : "2015-10-26 02:34:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658435361757143040",
  "text" : "RT @Irish_Atheist: You might be a white supremacist if you believe in nativism when it benefits white people and imperialism when it benefi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658434151297757184",
    "text" : "You might be a white supremacist if you believe in nativism when it benefits white people and imperialism when it benefits white people.",
    "id" : 658434151297757184,
    "created_at" : "2015-10-26 00:05:09 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 658435361757143040,
  "created_at" : "2015-10-26 00:09:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/658420958265520128\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/11D1L36M0w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSMuXtjWEAA4T3I.jpg",
      "id_str" : "658420955425935360",
      "id" : 658420955425935360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSMuXtjWEAA4T3I.jpg",
      "sizes" : [ {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/11D1L36M0w"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/dEyGYVjiP7",
      "expanded_url" : "http:\/\/www.faithfulwordbaptist.org\/transcript_birth_control.html?_ts=1445814759",
      "display_url" : "faithfulwordbaptist.org\/transcript_bir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658420958265520128",
  "text" : "I want to punch him.. argg! The Effects of Birth Control https:\/\/t.co\/dEyGYVjiP7 https:\/\/t.co\/11D1L36M0w",
  "id" : 658420958265520128,
  "created_at" : "2015-10-25 23:12:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/7hsskM45ER",
      "expanded_url" : "http:\/\/www.freejinger.org\/topic\/24522-maxwells-doing-their-operation-christmas-child-crap-again\/?do=findComment&comment=1043678",
      "display_url" : "freejinger.org\/topic\/24522-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658411198937960448",
  "text" : "never thought about it that way before..hmm.. https:\/\/t.co\/7hsskM45ER",
  "id" : 658411198937960448,
  "created_at" : "2015-10-25 22:33:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/569301392038498306\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/l3c5IVVExJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-aQmYQIAAAvycM.jpg",
      "id_str" : "569301391928459264",
      "id" : 569301391928459264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-aQmYQIAAAvycM.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/l3c5IVVExJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658117154827542528",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/l3c5IVVExJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/569301392038498306\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/l3c5IVVExJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-aQmYQIAAAvycM.jpg",
        "id_str" : "569301391928459264",
        "id" : 569301391928459264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-aQmYQIAAAvycM.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 533
        } ],
        "display_url" : "pic.twitter.com\/l3c5IVVExJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658115895479414784",
    "text" : "https:\/\/t.co\/l3c5IVVExJ",
    "id" : 658115895479414784,
    "created_at" : "2015-10-25 03:00:31 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 658117154827542528,
  "created_at" : "2015-10-25 03:05:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Gangster",
      "screen_name" : "PhilosopherK1ng",
      "indices" : [ 9, 25 ],
      "id_str" : "2289045631",
      "id" : 2289045631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658114884320804864",
  "text" : "Hmm.. RT @PhilosopherK1ng: You literally treat ppl how you treat yourself",
  "id" : 658114884320804864,
  "created_at" : "2015-10-25 02:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "Wallace 'J' Nichols",
      "screen_name" : "wallacejnichols",
      "indices" : [ 29, 45 ],
      "id_str" : "15575625",
      "id" : 15575625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/shKRCsYdma",
      "expanded_url" : "https:\/\/twitter.com\/calestous\/status\/658070530331922432",
      "display_url" : "twitter.com\/calestous\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658110951628124160",
  "text" : "RT @oceanshaman: Love it! Cc @wallacejnichols  https:\/\/t.co\/shKRCsYdma",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wallace 'J' Nichols",
        "screen_name" : "wallacejnichols",
        "indices" : [ 12, 28 ],
        "id_str" : "15575625",
        "id" : 15575625
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/shKRCsYdma",
        "expanded_url" : "https:\/\/twitter.com\/calestous\/status\/658070530331922432",
        "display_url" : "twitter.com\/calestous\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "658107546205581312",
    "text" : "Love it! Cc @wallacejnichols  https:\/\/t.co\/shKRCsYdma",
    "id" : 658107546205581312,
    "created_at" : "2015-10-25 02:27:20 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 658110951628124160,
  "created_at" : "2015-10-25 02:40:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/658067205561692160\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/hmpSCZni26",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSHsomCWcAAqK3o.jpg",
      "id_str" : "658067202722131968",
      "id" : 658067202722131968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSHsomCWcAAqK3o.jpg",
      "sizes" : [ {
        "h" : 543,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1259
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hmpSCZni26"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ktBo04xofG",
      "expanded_url" : "https:\/\/instagram.com\/p\/9PITaHvUb4\/?_ts=1445730421",
      "display_url" : "instagram.com\/p\/9PITaHvUb4\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658067205561692160",
  "text" : "Cory Booker on Instagram: \u201CI heard the House needed a Speaker.\u201D https:\/\/t.co\/ktBo04xofG https:\/\/t.co\/hmpSCZni26",
  "id" : 658067205561692160,
  "created_at" : "2015-10-24 23:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paula Abdul",
      "screen_name" : "PaulaAbdul",
      "indices" : [ 3, 14 ],
      "id_str" : "27750488",
      "id" : 27750488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658064999861100544",
  "text" : "RT @PaulaAbdul: LOVE that! Gorgeous colors! xoP RT @dreavesphoto: @PaulaAbdul It looked like this! It\u2019s fall and beautiful outside! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paula Abdul",
        "screen_name" : "PaulaAbdul",
        "indices" : [ 50, 61 ],
        "id_str" : "27750488",
        "id" : 27750488
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/XzcFeJXI4K",
        "expanded_url" : "https:\/\/twitter.com\/dreavesphoto\/status\/658058480339820544\/photo\/1",
        "display_url" : "pic.twitter.com\/XzcFeJXI4K"
      } ]
    },
    "in_reply_to_status_id_str" : "658058480339820544",
    "geo" : { },
    "id_str" : "658059271343575040",
    "in_reply_to_user_id" : 73908822,
    "text" : "LOVE that! Gorgeous colors! xoP RT @dreavesphoto: @PaulaAbdul It looked like this! It\u2019s fall and beautiful outside! https:\/\/t.co\/XzcFeJXI4K",
    "id" : 658059271343575040,
    "in_reply_to_status_id" : 658058480339820544,
    "created_at" : "2015-10-24 23:15:31 +0000",
    "in_reply_to_screen_name" : "dwaynereaves",
    "in_reply_to_user_id_str" : "73908822",
    "user" : {
      "name" : "Paula Abdul",
      "screen_name" : "PaulaAbdul",
      "protected" : false,
      "id_str" : "27750488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657309439033118721\/_cf4v0qq_normal.jpg",
      "id" : 27750488,
      "verified" : true
    }
  },
  "id" : 658064999861100544,
  "created_at" : "2015-10-24 23:38:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658064416190148608",
  "text" : "RT @CoryBooker: \"Our idea of God tells us more about ourselves than about Him.\" \n\u2014 Thomas Merton",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656266986935160833",
    "text" : "\"Our idea of God tells us more about ourselves than about Him.\" \n\u2014 Thomas Merton",
    "id" : 656266986935160833,
    "created_at" : "2015-10-20 00:33:37 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 658064416190148608,
  "created_at" : "2015-10-24 23:35:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Support",
      "screen_name" : "WindowsSupport",
      "indices" : [ 0, 15 ],
      "id_str" : "875957876",
      "id" : 875957876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658055237710794753",
  "geo" : { },
  "id_str" : "658063635663712256",
  "in_reply_to_user_id" : 875957876,
  "text" : "@WindowsSupport I used media creation tool both directly and with usb.",
  "id" : 658063635663712256,
  "in_reply_to_status_id" : 658055237710794753,
  "created_at" : "2015-10-24 23:32:51 +0000",
  "in_reply_to_screen_name" : "WindowsSupport",
  "in_reply_to_user_id_str" : "875957876",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows Support",
      "screen_name" : "WindowsSupport",
      "indices" : [ 0, 15 ],
      "id_str" : "875957876",
      "id" : 875957876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658055237710794753",
  "geo" : { },
  "id_str" : "658063305198686208",
  "in_reply_to_user_id" : 875957876,
  "text" : "@WindowsSupport ohh..lol. well, 2 things..1) stuck at 32% but then I got past that once then 2) get black screen after install when restart.",
  "id" : 658063305198686208,
  "in_reply_to_status_id" : 658055237710794753,
  "created_at" : "2015-10-24 23:31:32 +0000",
  "in_reply_to_screen_name" : "WindowsSupport",
  "in_reply_to_user_id_str" : "875957876",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "indices" : [ 3, 18 ],
      "id_str" : "20281746",
      "id" : 20281746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CreativeArtwks\/status\/657991334964281344\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/9UWLYaDthD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSGnocSUcAA2zsZ.jpg",
      "id_str" : "657991333802438656",
      "id" : 657991333802438656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSGnocSUcAA2zsZ.jpg",
      "sizes" : [ {
        "h" : 563,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/9UWLYaDthD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/XdALaG90pC",
      "expanded_url" : "https:\/\/creativeartworksblog.wordpress.com\/2015\/10\/24\/maude-white-take-8",
      "display_url" : "creativeartworksblog.wordpress.com\/2015\/10\/24\/mau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657991777086021632",
  "text" : "RT @CreativeArtwks: Maude White \u2013 Take\u00A08 https:\/\/t.co\/XdALaG90pC https:\/\/t.co\/9UWLYaDthD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CreativeArtwks\/status\/657991334964281344\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/9UWLYaDthD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSGnocSUcAA2zsZ.jpg",
        "id_str" : "657991333802438656",
        "id" : 657991333802438656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSGnocSUcAA2zsZ.jpg",
        "sizes" : [ {
          "h" : 563,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/9UWLYaDthD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/XdALaG90pC",
        "expanded_url" : "https:\/\/creativeartworksblog.wordpress.com\/2015\/10\/24\/maude-white-take-8",
        "display_url" : "creativeartworksblog.wordpress.com\/2015\/10\/24\/mau\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657991334964281344",
    "text" : "Maude White \u2013 Take\u00A08 https:\/\/t.co\/XdALaG90pC https:\/\/t.co\/9UWLYaDthD",
    "id" : 657991334964281344,
    "created_at" : "2015-10-24 18:45:33 +0000",
    "user" : {
      "name" : "Linda Lewis",
      "screen_name" : "CreativeArtwks",
      "protected" : false,
      "id_str" : "20281746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/346199131\/linda_lewis6_normal.jpg",
      "id" : 20281746,
      "verified" : false
    }
  },
  "id" : 657991777086021632,
  "created_at" : "2015-10-24 18:47:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LJ",
      "screen_name" : "rebelready",
      "indices" : [ 3, 14 ],
      "id_str" : "107588384",
      "id" : 107588384
    }, {
      "name" : "Huffington Post Blog",
      "screen_name" : "HuffPostBlog",
      "indices" : [ 56, 69 ],
      "id_str" : "131500972",
      "id" : 131500972
    }, {
      "name" : "HuffPost Denver",
      "screen_name" : "HuffPostDenver",
      "indices" : [ 98, 113 ],
      "id_str" : "75053671",
      "id" : 75053671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Kp9X1W3PkS",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/erin-zahradka\/jailed-for-lyme-diesease-_b_6257162.html",
      "display_url" : "huffingtonpost.com\/erin-zahradka\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657980398450966529",
  "text" : "RT @rebelready: Jailed for Lyme Disease. Really? Really @HuffPostBlog https:\/\/t.co\/Kp9X1W3PkS via @HuffPostDenver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post Blog",
        "screen_name" : "HuffPostBlog",
        "indices" : [ 40, 53 ],
        "id_str" : "131500972",
        "id" : 131500972
      }, {
        "name" : "HuffPost Denver",
        "screen_name" : "HuffPostDenver",
        "indices" : [ 82, 97 ],
        "id_str" : "75053671",
        "id" : 75053671
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/Kp9X1W3PkS",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/erin-zahradka\/jailed-for-lyme-diesease-_b_6257162.html",
        "display_url" : "huffingtonpost.com\/erin-zahradka\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657380576593227776",
    "text" : "Jailed for Lyme Disease. Really? Really @HuffPostBlog https:\/\/t.co\/Kp9X1W3PkS via @HuffPostDenver",
    "id" : 657380576593227776,
    "created_at" : "2015-10-23 02:18:37 +0000",
    "user" : {
      "name" : "LJ",
      "screen_name" : "rebelready",
      "protected" : false,
      "id_str" : "107588384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654054620742840320\/iClcoLE2_normal.png",
      "id" : 107588384,
      "verified" : false
    }
  },
  "id" : 657980398450966529,
  "created_at" : "2015-10-24 18:02:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "indices" : [ 3, 9 ],
      "id_str" : "14075844",
      "id" : 14075844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/fS2s13sZnP",
      "expanded_url" : "https:\/\/www.bostonglobe.com\/opinion\/2015\/02\/03\/chronic-pain-isn-crime\/hTqwaGVgwX3YpDkXUJMsfI\/story.html",
      "display_url" : "bostonglobe.com\/opinion\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657964967807864838",
  "text" : "RT @rocza: My chronic pain isn\u2019t a crime https:\/\/t.co\/fS2s13sZnP Yes, to all of this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/fS2s13sZnP",
        "expanded_url" : "https:\/\/www.bostonglobe.com\/opinion\/2015\/02\/03\/chronic-pain-isn-crime\/hTqwaGVgwX3YpDkXUJMsfI\/story.html",
        "display_url" : "bostonglobe.com\/opinion\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657949195513540608",
    "text" : "My chronic pain isn\u2019t a crime https:\/\/t.co\/fS2s13sZnP Yes, to all of this.",
    "id" : 657949195513540608,
    "created_at" : "2015-10-24 15:58:06 +0000",
    "user" : {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "protected" : false,
      "id_str" : "14075844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788549856528859136\/dco0kme__normal.jpg",
      "id" : 14075844,
      "verified" : false
    }
  },
  "id" : 657964967807864838,
  "created_at" : "2015-10-24 17:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Cashin",
      "screen_name" : "AmandaCashin",
      "indices" : [ 3, 16 ],
      "id_str" : "38888220",
      "id" : 38888220
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmandaCashin\/status\/648632081770135552\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Sl3XY2wWZ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQBncMpWoAACCos.jpg",
      "id_str" : "648632080470024192",
      "id" : 648632080470024192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQBncMpWoAACCos.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2918,
        "resize" : "fit",
        "w" : 4377
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Sl3XY2wWZ5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657962639025418241",
  "text" : "RT @AmandaCashin: Made a little friend on our hike tonight. Nature is so precious. http:\/\/t.co\/Sl3XY2wWZ5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmandaCashin\/status\/648632081770135552\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/Sl3XY2wWZ5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQBncMpWoAACCos.jpg",
        "id_str" : "648632080470024192",
        "id" : 648632080470024192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQBncMpWoAACCos.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2918,
          "resize" : "fit",
          "w" : 4377
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Sl3XY2wWZ5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648632081770135552",
    "text" : "Made a little friend on our hike tonight. Nature is so precious. http:\/\/t.co\/Sl3XY2wWZ5",
    "id" : 648632081770135552,
    "created_at" : "2015-09-28 22:55:13 +0000",
    "user" : {
      "name" : "Amanda Cashin",
      "screen_name" : "AmandaCashin",
      "protected" : false,
      "id_str" : "38888220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780549465056870400\/j-V49dZI_normal.jpg",
      "id" : 38888220,
      "verified" : false
    }
  },
  "id" : 657962639025418241,
  "created_at" : "2015-10-24 16:51:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Thomas Bogan",
      "screen_name" : "mtbogan",
      "indices" : [ 3, 11 ],
      "id_str" : "2745226392",
      "id" : 2745226392
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mtbogan\/status\/657707748587520000\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/elp17jQWyN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSClqvoUEAAMxLp.jpg",
      "id_str" : "657707699354734592",
      "id" : 657707699354734592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSClqvoUEAAMxLp.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/elp17jQWyN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/mtbogan\/status\/657707748587520000\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/elp17jQWyN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSClq1RUcAAMrP0.jpg",
      "id_str" : "657707700868902912",
      "id" : 657707700868902912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSClq1RUcAAMrP0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/elp17jQWyN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/mtbogan\/status\/657707748587520000\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/elp17jQWyN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSClrEmUEAAEQQv.jpg",
      "id_str" : "657707704983490560",
      "id" : 657707704983490560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSClrEmUEAAEQQv.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/elp17jQWyN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657962117832835072",
  "text" : "RT @mtbogan: Cactus wren busy building a nest near my cabin this AM. Seems strange for October, but what do I know. https:\/\/t.co\/elp17jQWyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mtbogan\/status\/657707748587520000\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/elp17jQWyN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSClqvoUEAAMxLp.jpg",
        "id_str" : "657707699354734592",
        "id" : 657707699354734592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSClqvoUEAAMxLp.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/elp17jQWyN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mtbogan\/status\/657707748587520000\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/elp17jQWyN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSClq1RUcAAMrP0.jpg",
        "id_str" : "657707700868902912",
        "id" : 657707700868902912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSClq1RUcAAMrP0.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/elp17jQWyN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/mtbogan\/status\/657707748587520000\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/elp17jQWyN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSClrEmUEAAEQQv.jpg",
        "id_str" : "657707704983490560",
        "id" : 657707704983490560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSClrEmUEAAEQQv.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/elp17jQWyN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657707748587520000",
    "text" : "Cactus wren busy building a nest near my cabin this AM. Seems strange for October, but what do I know. https:\/\/t.co\/elp17jQWyN",
    "id" : 657707748587520000,
    "created_at" : "2015-10-23 23:58:41 +0000",
    "user" : {
      "name" : "Michael Thomas Bogan",
      "screen_name" : "mtbogan",
      "protected" : false,
      "id_str" : "2745226392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684083995722698753\/vl2y4DAy_normal.jpg",
      "id" : 2745226392,
      "verified" : false
    }
  },
  "id" : 657962117832835072,
  "created_at" : "2015-10-24 16:49:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sally garland",
      "screen_name" : "florestaqueen",
      "indices" : [ 3, 17 ],
      "id_str" : "762327451",
      "id" : 762327451
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/florestaqueen\/status\/657922730721943554\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/nCnI5SGQiD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSFpOxpXAAAG6gA.jpg",
      "id_str" : "657922723138699264",
      "id" : 657922723138699264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSFpOxpXAAAG6gA.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 819
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 819
      } ],
      "display_url" : "pic.twitter.com\/nCnI5SGQiD"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 51, 57 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 58, 71 ]
    }, {
      "text" : "nature",
      "indices" : [ 72, 79 ]
    }, {
      "text" : "photography",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "Devon",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657961381459828737",
  "text" : "RT @florestaqueen: Wood Pigeon...pretty in pink... #birds #birdwatching #nature #photography #Devon https:\/\/t.co\/nCnI5SGQiD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/florestaqueen\/status\/657922730721943554\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/nCnI5SGQiD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSFpOxpXAAAG6gA.jpg",
        "id_str" : "657922723138699264",
        "id" : 657922723138699264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSFpOxpXAAAG6gA.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 819
        } ],
        "display_url" : "pic.twitter.com\/nCnI5SGQiD"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 32, 38 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 39, 52 ]
      }, {
        "text" : "nature",
        "indices" : [ 53, 60 ]
      }, {
        "text" : "photography",
        "indices" : [ 61, 73 ]
      }, {
        "text" : "Devon",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657922730721943554",
    "text" : "Wood Pigeon...pretty in pink... #birds #birdwatching #nature #photography #Devon https:\/\/t.co\/nCnI5SGQiD",
    "id" : 657922730721943554,
    "created_at" : "2015-10-24 14:12:57 +0000",
    "user" : {
      "name" : "sally garland",
      "screen_name" : "florestaqueen",
      "protected" : false,
      "id_str" : "762327451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877902376\/3b4259b43bc2a8c0d9ba527562427f36_normal.jpeg",
      "id" : 762327451,
      "verified" : false
    }
  },
  "id" : 657961381459828737,
  "created_at" : "2015-10-24 16:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen",
      "screen_name" : "helen_a15",
      "indices" : [ 3, 13 ],
      "id_str" : "3495798616",
      "id" : 3495798616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657960866499993600",
  "text" : "RT @helen_a15: I've started to accept the healthier option is to accept my immune system is screwed and work within those limits.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657957814489522181",
    "text" : "I've started to accept the healthier option is to accept my immune system is screwed and work within those limits.",
    "id" : 657957814489522181,
    "created_at" : "2015-10-24 16:32:21 +0000",
    "user" : {
      "name" : "Helen",
      "screen_name" : "helen_a15",
      "protected" : false,
      "id_str" : "3495798616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798669600359596032\/0mmqSQAD_normal.jpg",
      "id" : 3495798616,
      "verified" : false
    }
  },
  "id" : 657960866499993600,
  "created_at" : "2015-10-24 16:44:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Los Angeles Times",
      "screen_name" : "latimes",
      "indices" : [ 3, 11 ],
      "id_str" : "16664681",
      "id" : 16664681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HurricanePatricia",
      "indices" : [ 13, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657960555592945664",
  "text" : "RT @latimes: #HurricanePatricia has been downgraded to a tropical depression; maximum sustained winds drop to just 35 mph https:\/\/t.co\/vQwG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HurricanePatricia",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/vQwGlpAJlF",
        "expanded_url" : "http:\/\/lat.ms\/1LttCgB",
        "display_url" : "lat.ms\/1LttCgB"
      } ]
    },
    "geo" : { },
    "id_str" : "657943402856751105",
    "text" : "#HurricanePatricia has been downgraded to a tropical depression; maximum sustained winds drop to just 35 mph https:\/\/t.co\/vQwGlpAJlF",
    "id" : 657943402856751105,
    "created_at" : "2015-10-24 15:35:05 +0000",
    "user" : {
      "name" : "Los Angeles Times",
      "screen_name" : "latimes",
      "protected" : false,
      "id_str" : "16664681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546329819919560704\/XMWy2Z50_normal.jpeg",
      "id" : 16664681,
      "verified" : true
    }
  },
  "id" : 657960555592945664,
  "created_at" : "2015-10-24 16:43:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Travelista",
      "screen_name" : "travelistajess",
      "indices" : [ 3, 18 ],
      "id_str" : "548624058",
      "id" : 548624058
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HurricanePatricia",
      "indices" : [ 20, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657960516971810818",
  "text" : "RT @travelistajess: #HurricanePatricia was predicted the worlds strongest storm and died down to a tropical storm overnight, with 0 deaths.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HurricanePatricia",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657934999606448128",
    "text" : "#HurricanePatricia was predicted the worlds strongest storm and died down to a tropical storm overnight, with 0 deaths. That's amazing",
    "id" : 657934999606448128,
    "created_at" : "2015-10-24 15:01:42 +0000",
    "user" : {
      "name" : "The Travelista",
      "screen_name" : "travelistajess",
      "protected" : false,
      "id_str" : "548624058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798564533597925376\/2ZFdq372_normal.jpg",
      "id" : 548624058,
      "verified" : false
    }
  },
  "id" : 657960516971810818,
  "created_at" : "2015-10-24 16:43:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657939344544649217",
  "text" : "RT @RustBeltRebel: predatory---&gt;Bankers Are Buying Baltimore\u2019s Debt, Charging Families Crazy Interest Rates, Then Taking Their Homes https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/pbxB3T3FF5",
        "expanded_url" : "http:\/\/thkpr.gs\/3695753",
        "display_url" : "thkpr.gs\/3695753"
      } ]
    },
    "geo" : { },
    "id_str" : "657938640337702912",
    "text" : "predatory---&gt;Bankers Are Buying Baltimore\u2019s Debt, Charging Families Crazy Interest Rates, Then Taking Their Homes https:\/\/t.co\/pbxB3T3FF5",
    "id" : 657938640337702912,
    "created_at" : "2015-10-24 15:16:10 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 657939344544649217,
  "created_at" : "2015-10-24 15:18:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "indices" : [ 3, 13 ],
      "id_str" : "15104467",
      "id" : 15104467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657931795191738368",
  "text" : "RT @FogBelter: FBI director doesn't understand what \"Public Servant\" means, nor that Law Enforcement is accountable to The People. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/7UeyacSyY5",
        "expanded_url" : "https:\/\/twitter.com\/adamserwer\/status\/657898424470212608",
        "display_url" : "twitter.com\/adamserwer\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657930097043730432",
    "text" : "FBI director doesn't understand what \"Public Servant\" means, nor that Law Enforcement is accountable to The People. https:\/\/t.co\/7UeyacSyY5",
    "id" : 657930097043730432,
    "created_at" : "2015-10-24 14:42:13 +0000",
    "user" : {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "protected" : false,
      "id_str" : "15104467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/263286875\/Joshua_A_Norton_normal.jpg",
      "id" : 15104467,
      "verified" : false
    }
  },
  "id" : 657931795191738368,
  "created_at" : "2015-10-24 14:48:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/657926860366458881\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ViefmtPBGz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSFs_g_UEAAEACm.jpg",
      "id_str" : "657926859015852032",
      "id" : 657926859015852032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSFs_g_UEAAEACm.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2851,
        "resize" : "fit",
        "w" : 3081
      }, {
        "h" : 948,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ViefmtPBGz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657931193208434689",
  "text" : "RT @ChippyCMunk: Peeking out from the leaves https:\/\/t.co\/ViefmtPBGz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/657926860366458881\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/ViefmtPBGz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSFs_g_UEAAEACm.jpg",
        "id_str" : "657926859015852032",
        "id" : 657926859015852032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSFs_g_UEAAEACm.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2851,
          "resize" : "fit",
          "w" : 3081
        }, {
          "h" : 948,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ViefmtPBGz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657926860366458881",
    "text" : "Peeking out from the leaves https:\/\/t.co\/ViefmtPBGz",
    "id" : 657926860366458881,
    "created_at" : "2015-10-24 14:29:21 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 657931193208434689,
  "created_at" : "2015-10-24 14:46:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Griffin",
      "screen_name" : "GDGriffin",
      "indices" : [ 3, 13 ],
      "id_str" : "224383563",
      "id" : 224383563
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdland",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/MARz7h6fnu",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/10\/24\/vets_for_bernie_why_the_most_anti_war_candidate_has_many_military_supporters_partner\/",
      "display_url" : "salon.com\/2015\/10\/24\/vet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657930241395048448",
  "text" : "RT @GDGriffin: Veterans for Bernie Sanders: Why an avowed pacifist is so beloved by former soldiers https:\/\/t.co\/MARz7h6fnu #nerdland @mhps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa @ MSNBC",
        "screen_name" : "MHPshow",
        "indices" : [ 119, 127 ],
        "id_str" : "475286355",
        "id" : 475286355
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nerdland",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/MARz7h6fnu",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/10\/24\/vets_for_bernie_why_the_most_anti_war_candidate_has_many_military_supporters_partner\/",
        "display_url" : "salon.com\/2015\/10\/24\/vet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657922148795863040",
    "text" : "Veterans for Bernie Sanders: Why an avowed pacifist is so beloved by former soldiers https:\/\/t.co\/MARz7h6fnu #nerdland @mhpshow",
    "id" : 657922148795863040,
    "created_at" : "2015-10-24 14:10:38 +0000",
    "user" : {
      "name" : "Greg Griffin",
      "screen_name" : "GDGriffin",
      "protected" : false,
      "id_str" : "224383563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1258716364\/Weeping_Norway_Spruce_Cropped_c_normal.jpg",
      "id" : 224383563,
      "verified" : false
    }
  },
  "id" : 657930241395048448,
  "created_at" : "2015-10-24 14:42:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657928881693847552",
  "geo" : { },
  "id_str" : "657929761101082624",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes oookay, then..lol. Blessings on your special day tomorrow! : )",
  "id" : 657929761101082624,
  "in_reply_to_status_id" : 657928881693847552,
  "created_at" : "2015-10-24 14:40:53 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "windows10",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "firstworldproblems",
      "indices" : [ 60, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657928915751739392",
  "text" : "trying to upgrade win7 laptop to #windows10 for past 3 days #firstworldproblems",
  "id" : 657928915751739392,
  "created_at" : "2015-10-24 14:37:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Espacio Ganadero",
      "screen_name" : "ganaderoespacio",
      "indices" : [ 3, 19 ],
      "id_str" : "1545661284",
      "id" : 1545661284
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ganaderoespacio\/status\/657904688440963077\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/oj7yF5yYhS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSFY1AvW0AAbpyR.jpg",
      "id_str" : "657904688327741440",
      "id" : 657904688327741440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSFY1AvW0AAbpyR.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 736
      } ],
      "display_url" : "pic.twitter.com\/oj7yF5yYhS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657917890746851328",
  "text" : "RT @ganaderoespacio: Foto del d\u00EDa: raza highland bajo cero! https:\/\/t.co\/oj7yF5yYhS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ganaderoespacio\/status\/657904688440963077\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/oj7yF5yYhS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSFY1AvW0AAbpyR.jpg",
        "id_str" : "657904688327741440",
        "id" : 657904688327741440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSFY1AvW0AAbpyR.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 552,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 552,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/oj7yF5yYhS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657904688440963077",
    "text" : "Foto del d\u00EDa: raza highland bajo cero! https:\/\/t.co\/oj7yF5yYhS",
    "id" : 657904688440963077,
    "created_at" : "2015-10-24 13:01:15 +0000",
    "user" : {
      "name" : "Espacio Ganadero",
      "screen_name" : "ganaderoespacio",
      "protected" : false,
      "id_str" : "1545661284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000043928926\/d464ad2332aa791b9e45cffd6761e08d_normal.jpeg",
      "id" : 1545661284,
      "verified" : false
    }
  },
  "id" : 657917890746851328,
  "created_at" : "2015-10-24 13:53:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen",
      "screen_name" : "helen_a15",
      "indices" : [ 3, 13 ],
      "id_str" : "3495798616",
      "id" : 3495798616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657740235577651200",
  "text" : "RT @helen_a15: I've just watched 'The Butterfly Circus'. \nOh and cried. \nWhat a stunningly beautiful short film.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657340031305195520",
    "text" : "I've just watched 'The Butterfly Circus'. \nOh and cried. \nWhat a stunningly beautiful short film.",
    "id" : 657340031305195520,
    "created_at" : "2015-10-22 23:37:30 +0000",
    "user" : {
      "name" : "Helen",
      "screen_name" : "helen_a15",
      "protected" : false,
      "id_str" : "3495798616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798669600359596032\/0mmqSQAD_normal.jpg",
      "id" : 3495798616,
      "verified" : false
    }
  },
  "id" : 657740235577651200,
  "created_at" : "2015-10-24 02:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/jBfySePFjf",
      "expanded_url" : "https:\/\/www.aclu.org\/blog\/speak-freely\/nypd-says-trust-us-potentially-dangerous-x-ray-vans-roaming-streets-new-york",
      "display_url" : "aclu.org\/blog\/speak-fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657626519943139329",
  "text" : "RT @deray: NYPD Says \u2018Trust Us\u2019 on Potentially Dangerous X-Ray Vans Roaming the Streets of New York https:\/\/t.co\/jBfySePFjf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/jBfySePFjf",
        "expanded_url" : "https:\/\/www.aclu.org\/blog\/speak-freely\/nypd-says-trust-us-potentially-dangerous-x-ray-vans-roaming-streets-new-york",
        "display_url" : "aclu.org\/blog\/speak-fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657540168996560896",
    "text" : "NYPD Says \u2018Trust Us\u2019 on Potentially Dangerous X-Ray Vans Roaming the Streets of New York https:\/\/t.co\/jBfySePFjf",
    "id" : 657540168996560896,
    "created_at" : "2015-10-23 12:52:47 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 657626519943139329,
  "created_at" : "2015-10-23 18:35:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Killrowan Farm",
      "screen_name" : "KillrowanFarm",
      "indices" : [ 3, 17 ],
      "id_str" : "1615765134",
      "id" : 1615765134
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VC9AqGfIng",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_j-MPXIAAFVNn.jpg",
      "id_str" : "657494728196431872",
      "id" : 657494728196431872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_j-MPXIAAFVNn.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2080,
        "resize" : "fit",
        "w" : 1560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VC9AqGfIng"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VC9AqGfIng",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_kACrXIAAizCg.jpg",
      "id_str" : "657494759989256192",
      "id" : 657494759989256192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_kACrXIAAizCg.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2080,
        "resize" : "fit",
        "w" : 1560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VC9AqGfIng"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VC9AqGfIng",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_kFdRWIAAWOJy.jpg",
      "id_str" : "657494853027241984",
      "id" : 657494853027241984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_kFdRWIAAWOJy.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2080,
        "resize" : "fit",
        "w" : 1560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VC9AqGfIng"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VC9AqGfIng",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_kJZ0WwAEtBI4.jpg",
      "id_str" : "657494920819818497",
      "id" : 657494920819818497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_kJZ0WwAEtBI4.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2080,
        "resize" : "fit",
        "w" : 1560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VC9AqGfIng"
    } ],
    "hashtags" : [ {
      "text" : "Highlandcattle",
      "indices" : [ 36, 51 ]
    }, {
      "text" : "notsocamerashy",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657553214120808448",
  "text" : "RT @KillrowanFarm: While one of our #Highlandcattle tries to eat the camera. #notsocamerashy https:\/\/t.co\/VC9AqGfIng",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/VC9AqGfIng",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_j-MPXIAAFVNn.jpg",
        "id_str" : "657494728196431872",
        "id" : 657494728196431872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_j-MPXIAAFVNn.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2080,
          "resize" : "fit",
          "w" : 1560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VC9AqGfIng"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/VC9AqGfIng",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_kACrXIAAizCg.jpg",
        "id_str" : "657494759989256192",
        "id" : 657494759989256192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_kACrXIAAizCg.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2080,
          "resize" : "fit",
          "w" : 1560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VC9AqGfIng"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/VC9AqGfIng",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_kFdRWIAAWOJy.jpg",
        "id_str" : "657494853027241984",
        "id" : 657494853027241984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_kFdRWIAAWOJy.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2080,
          "resize" : "fit",
          "w" : 1560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VC9AqGfIng"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KillrowanFarm\/status\/657495014788997120\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/VC9AqGfIng",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR_kJZ0WwAEtBI4.jpg",
        "id_str" : "657494920819818497",
        "id" : 657494920819818497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR_kJZ0WwAEtBI4.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2080,
          "resize" : "fit",
          "w" : 1560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VC9AqGfIng"
      } ],
      "hashtags" : [ {
        "text" : "Highlandcattle",
        "indices" : [ 17, 32 ]
      }, {
        "text" : "notsocamerashy",
        "indices" : [ 58, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657495014788997120",
    "text" : "While one of our #Highlandcattle tries to eat the camera. #notsocamerashy https:\/\/t.co\/VC9AqGfIng",
    "id" : 657495014788997120,
    "created_at" : "2015-10-23 09:53:21 +0000",
    "user" : {
      "name" : "Killrowan Farm",
      "screen_name" : "KillrowanFarm",
      "protected" : false,
      "id_str" : "1615765134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767624223301009408\/WoGqbocs_normal.jpg",
      "id" : 1615765134,
      "verified" : false
    }
  },
  "id" : 657553214120808448,
  "created_at" : "2015-10-23 13:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim",
      "screen_name" : "Playing_Dad",
      "indices" : [ 3, 15 ],
      "id_str" : "542901683",
      "id" : 542901683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657553016472674304",
  "text" : "RT @Playing_Dad: [At job interview] \nInterviewer: So tell me why you want this job. \nMe: I have no money and I prefer when I have money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583601900492353536",
    "text" : "[At job interview] \nInterviewer: So tell me why you want this job. \nMe: I have no money and I prefer when I have money.",
    "id" : 583601900492353536,
    "created_at" : "2015-04-02 12:08:30 +0000",
    "user" : {
      "name" : "Tim",
      "screen_name" : "Playing_Dad",
      "protected" : false,
      "id_str" : "542901683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722266384374194176\/Wrsp1VN6_normal.jpg",
      "id" : 542901683,
      "verified" : false
    }
  },
  "id" : 657553016472674304,
  "created_at" : "2015-10-23 13:43:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/yRpHzNiBfP",
      "expanded_url" : "http:\/\/tl.gd\/nl6mcn",
      "display_url" : "tl.gd\/nl6mcn"
    } ]
  },
  "geo" : { },
  "id_str" : "657364602443997184",
  "text" : "- (cont) https:\/\/t.co\/yRpHzNiBfP",
  "id" : 657364602443997184,
  "created_at" : "2015-10-23 01:15:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/lkBct4vpAS",
      "expanded_url" : "http:\/\/ow.ly\/35PSsQ",
      "display_url" : "ow.ly\/35PSsQ"
    } ]
  },
  "geo" : { },
  "id_str" : "657352656483151872",
  "text" : "RT @DharmaTalks: 5 Ways to Live Well With Chronic Pain and Illness https:\/\/t.co\/lkBct4vpAS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/lkBct4vpAS",
        "expanded_url" : "http:\/\/ow.ly\/35PSsQ",
        "display_url" : "ow.ly\/35PSsQ"
      } ]
    },
    "geo" : { },
    "id_str" : "657349653546053632",
    "text" : "5 Ways to Live Well With Chronic Pain and Illness https:\/\/t.co\/lkBct4vpAS",
    "id" : 657349653546053632,
    "created_at" : "2015-10-23 00:15:45 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 657352656483151872,
  "created_at" : "2015-10-23 00:27:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/earthXplorer\/status\/657338768672870400\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Njvn5oyULJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR9WIIUWcAE5EmI.jpg",
      "id_str" : "657338768291164161",
      "id" : 657338768291164161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR9WIIUWcAE5EmI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Njvn5oyULJ"
    } ],
    "hashtags" : [ {
      "text" : "Galapagos",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "Ecuador",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657342237441961984",
  "text" : "RT @earthXplorer: Giant tortoise #Galapagos #wildlife #Ecuador https:\/\/t.co\/Njvn5oyULJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/earthXplorer\/status\/657338768672870400\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/Njvn5oyULJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR9WIIUWcAE5EmI.jpg",
        "id_str" : "657338768291164161",
        "id" : 657338768291164161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR9WIIUWcAE5EmI.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Njvn5oyULJ"
      } ],
      "hashtags" : [ {
        "text" : "Galapagos",
        "indices" : [ 15, 25 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 26, 35 ]
      }, {
        "text" : "Ecuador",
        "indices" : [ 36, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657338768672870400",
    "text" : "Giant tortoise #Galapagos #wildlife #Ecuador https:\/\/t.co\/Njvn5oyULJ",
    "id" : 657338768672870400,
    "created_at" : "2015-10-22 23:32:29 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 657342237441961984,
  "created_at" : "2015-10-22 23:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657338503680937984",
  "text" : "RT @SenSanders: Democratic Socialism means democracy. It means creating a government that represents all of us, not just the wealthiest peo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656458453783851008",
    "text" : "Democratic Socialism means democracy. It means creating a government that represents all of us, not just the wealthiest people in America.",
    "id" : 656458453783851008,
    "created_at" : "2015-10-20 13:14:26 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 657338503680937984,
  "created_at" : "2015-10-22 23:31:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "indices" : [ 3, 13 ],
      "id_str" : "15104467",
      "id" : 15104467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/mkh72ZcJuy",
      "expanded_url" : "https:\/\/twitter.com\/rippdemup\/status\/657323406476615680",
      "display_url" : "twitter.com\/rippdemup\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657328368845766658",
  "text" : "RT @FogBelter: They are, he's correct. So are public school, Medicare and Social Security. https:\/\/t.co\/mkh72ZcJuy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/mkh72ZcJuy",
        "expanded_url" : "https:\/\/twitter.com\/rippdemup\/status\/657323406476615680",
        "display_url" : "twitter.com\/rippdemup\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657327027549171712",
    "text" : "They are, he's correct. So are public school, Medicare and Social Security. https:\/\/t.co\/mkh72ZcJuy",
    "id" : 657327027549171712,
    "created_at" : "2015-10-22 22:45:50 +0000",
    "user" : {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "protected" : false,
      "id_str" : "15104467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/263286875\/Joshua_A_Norton_normal.jpg",
      "id" : 15104467,
      "verified" : false
    }
  },
  "id" : 657328368845766658,
  "created_at" : "2015-10-22 22:51:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/1RoFUlcNtr",
      "expanded_url" : "https:\/\/twitter.com\/DawnFine\/status\/657289786814799876",
      "display_url" : "twitter.com\/DawnFine\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657292073415147520",
  "text" : "I'm moving in. Like!  https:\/\/t.co\/1RoFUlcNtr",
  "id" : 657292073415147520,
  "created_at" : "2015-10-22 20:26:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma",
      "screen_name" : "allneedles",
      "indices" : [ 3, 14 ],
      "id_str" : "429298253",
      "id" : 429298253
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/allneedles\/status\/657277788567769088\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/kTjmAAJOHk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8eqE6WwAEHloH.jpg",
      "id_str" : "657277778841223169",
      "id" : 657277778841223169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8eqE6WwAEHloH.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kTjmAAJOHk"
    } ],
    "hashtags" : [ {
      "text" : "testknitters",
      "indices" : [ 20, 33 ]
    }, {
      "text" : "cabled",
      "indices" : [ 72, 79 ]
    }, {
      "text" : "cowl",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/VD4bljfZpe",
      "expanded_url" : "http:\/\/www.ravelry.com\/groups\/designs-by-emma",
      "display_url" : "ravelry.com\/groups\/designs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657282428357189632",
  "text" : "RT @allneedles: Any #testknitters about who would like to test my short #cabled #cowl? https:\/\/t.co\/VD4bljfZpe https:\/\/t.co\/kTjmAAJOHk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/allneedles\/status\/657277788567769088\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/kTjmAAJOHk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8eqE6WwAEHloH.jpg",
        "id_str" : "657277778841223169",
        "id" : 657277778841223169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8eqE6WwAEHloH.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kTjmAAJOHk"
      } ],
      "hashtags" : [ {
        "text" : "testknitters",
        "indices" : [ 4, 17 ]
      }, {
        "text" : "cabled",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "cowl",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/VD4bljfZpe",
        "expanded_url" : "http:\/\/www.ravelry.com\/groups\/designs-by-emma",
        "display_url" : "ravelry.com\/groups\/designs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657277788567769088",
    "text" : "Any #testknitters about who would like to test my short #cabled #cowl? https:\/\/t.co\/VD4bljfZpe https:\/\/t.co\/kTjmAAJOHk",
    "id" : 657277788567769088,
    "created_at" : "2015-10-22 19:30:11 +0000",
    "user" : {
      "name" : "Emma",
      "screen_name" : "allneedles",
      "protected" : false,
      "id_str" : "429298253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703548110354706432\/zUGW5KDU_normal.jpg",
      "id" : 429298253,
      "verified" : false
    }
  },
  "id" : 657282428357189632,
  "created_at" : "2015-10-22 19:48:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/cjWvxsmgdc",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/10\/22\/dick-cheney-complained-that-do.html",
      "display_url" : "boingboing.net\/2015\/10\/22\/dic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657280993422909440",
  "text" : "RT @BoingBoing: Dick Cheney once complained Donald Rumsfeld drank too much coffee (don't they prefer blood?) https:\/\/t.co\/cjWvxsmgdc https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoingBoing\/status\/657263888367505408\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XZxhocVFlF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8SBidW0AEZFKY.jpg",
        "id_str" : "657263888258486273",
        "id" : 657263888258486273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8SBidW0AEZFKY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 793,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XZxhocVFlF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/cjWvxsmgdc",
        "expanded_url" : "http:\/\/boingboing.net\/2015\/10\/22\/dick-cheney-complained-that-do.html",
        "display_url" : "boingboing.net\/2015\/10\/22\/dic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657263888367505408",
    "text" : "Dick Cheney once complained Donald Rumsfeld drank too much coffee (don't they prefer blood?) https:\/\/t.co\/cjWvxsmgdc https:\/\/t.co\/XZxhocVFlF",
    "id" : 657263888367505408,
    "created_at" : "2015-10-22 18:34:57 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 657280993422909440,
  "created_at" : "2015-10-22 19:42:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bookmobile",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/UEzbVzbWvi",
      "expanded_url" : "http:\/\/ebks.to\/1WTkyH0",
      "display_url" : "ebks.to\/1WTkyH0"
    } ]
  },
  "geo" : { },
  "id_str" : "657269771587731456",
  "text" : "RT @ebookfriendly: US soldiers getting library books from a Kelly Field Library #bookmobile, 1920 https:\/\/t.co\/UEzbVzbWvi https:\/\/t.co\/kQpJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/657269220057698304\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/kQpJPCW6nE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8W34gXAAA4GTH.jpg",
        "id_str" : "657269219936108544",
        "id" : 657269219936108544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8W34gXAAA4GTH.jpg",
        "sizes" : [ {
          "h" : 433,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kQpJPCW6nE"
      } ],
      "hashtags" : [ {
        "text" : "bookmobile",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/UEzbVzbWvi",
        "expanded_url" : "http:\/\/ebks.to\/1WTkyH0",
        "display_url" : "ebks.to\/1WTkyH0"
      } ]
    },
    "geo" : { },
    "id_str" : "657269220057698304",
    "text" : "US soldiers getting library books from a Kelly Field Library #bookmobile, 1920 https:\/\/t.co\/UEzbVzbWvi https:\/\/t.co\/kQpJPCW6nE",
    "id" : 657269220057698304,
    "created_at" : "2015-10-22 18:56:08 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 657269771587731456,
  "created_at" : "2015-10-22 18:58:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolina Waterfowl",
      "screen_name" : "waterfowlrescue",
      "indices" : [ 3, 19 ],
      "id_str" : "295137192",
      "id" : 295137192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/TwEAb2NQRB",
      "expanded_url" : "https:\/\/instagram.com\/p\/9JpTeUwUzO\/",
      "display_url" : "instagram.com\/p\/9JpTeUwUzO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "657269706253017088",
  "text" : "RT @waterfowlrescue: Someone has dug herself into quite a nice hole today. @ Carolina Waterfowl Rescue https:\/\/t.co\/TwEAb2NQRB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/TwEAb2NQRB",
        "expanded_url" : "https:\/\/instagram.com\/p\/9JpTeUwUzO\/",
        "display_url" : "instagram.com\/p\/9JpTeUwUzO\/"
      } ]
    },
    "geo" : { },
    "id_str" : "657269229322944512",
    "text" : "Someone has dug herself into quite a nice hole today. @ Carolina Waterfowl Rescue https:\/\/t.co\/TwEAb2NQRB",
    "id" : 657269229322944512,
    "created_at" : "2015-10-22 18:56:10 +0000",
    "user" : {
      "name" : "Carolina Waterfowl",
      "screen_name" : "waterfowlrescue",
      "protected" : false,
      "id_str" : "295137192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2964403549\/84f3d8af57ffc4aef9c6de33e5e28894_normal.jpeg",
      "id" : 295137192,
      "verified" : false
    }
  },
  "id" : 657269706253017088,
  "created_at" : "2015-10-22 18:58:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/6w9bZUlWlD",
      "expanded_url" : "https:\/\/twitter.com\/theBerniePost\/status\/657149173800660992",
      "display_url" : "twitter.com\/theBerniePost\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657269350634754048",
  "text" : "RT @oceanshaman: . https:\/\/t.co\/6w9bZUlWlD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 2, 25 ],
        "url" : "https:\/\/t.co\/6w9bZUlWlD",
        "expanded_url" : "https:\/\/twitter.com\/theBerniePost\/status\/657149173800660992",
        "display_url" : "twitter.com\/theBerniePost\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657267166811697152",
    "text" : ". https:\/\/t.co\/6w9bZUlWlD",
    "id" : 657267166811697152,
    "created_at" : "2015-10-22 18:47:58 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 657269350634754048,
  "created_at" : "2015-10-22 18:56:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neen\u00E4  \u02C6\u2323\u02C6",
      "screen_name" : "Tum55",
      "indices" : [ 3, 9 ],
      "id_str" : "73623198",
      "id" : 73623198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657267967021961216",
  "text" : "RT @Tum55: Let karma do its thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657231040411385856",
    "text" : "Let karma do its thing.",
    "id" : 657231040411385856,
    "created_at" : "2015-10-22 16:24:25 +0000",
    "user" : {
      "name" : "neen\u00E4  \u02C6\u2323\u02C6",
      "screen_name" : "Tum55",
      "protected" : false,
      "id_str" : "73623198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797380621051924480\/SHP0yA94_normal.jpg",
      "id" : 73623198,
      "verified" : false
    }
  },
  "id" : 657267967021961216,
  "created_at" : "2015-10-22 18:51:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hearingloss",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "deaf",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Vs0jD4UllS",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/942774509129706\/?type=3&theater",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657267359510634496",
  "text" : "RT @dreavesphoto: A little about me.--- Like my page while you are there. #hearingloss #deaf https:\/\/t.co\/Vs0jD4UllS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hearingloss",
        "indices" : [ 56, 68 ]
      }, {
        "text" : "deaf",
        "indices" : [ 69, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Vs0jD4UllS",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/942774509129706\/?type=3&theater",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657252762703523840",
    "text" : "A little about me.--- Like my page while you are there. #hearingloss #deaf https:\/\/t.co\/Vs0jD4UllS",
    "id" : 657252762703523840,
    "created_at" : "2015-10-22 17:50:44 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 657267359510634496,
  "created_at" : "2015-10-22 18:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget Mellor",
      "screen_name" : "bidamellor",
      "indices" : [ 3, 14 ],
      "id_str" : "1101111733",
      "id" : 1101111733
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bidamellor\/status\/654220759653593088\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/VeEJSOjnPN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRRCUIpW8AAmJ-v.jpg",
      "id_str" : "654220759561334784",
      "id" : 654220759561334784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRRCUIpW8AAmJ-v.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VeEJSOjnPN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657219993277440000",
  "text" : "RT @bidamellor: Lovely Autumn Day Enjoy the colours out there and the lovely light http:\/\/t.co\/VeEJSOjnPN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bidamellor\/status\/654220759653593088\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/VeEJSOjnPN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRRCUIpW8AAmJ-v.jpg",
        "id_str" : "654220759561334784",
        "id" : 654220759561334784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRRCUIpW8AAmJ-v.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VeEJSOjnPN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654220759653593088",
    "text" : "Lovely Autumn Day Enjoy the colours out there and the lovely light http:\/\/t.co\/VeEJSOjnPN",
    "id" : 654220759653593088,
    "created_at" : "2015-10-14 09:02:38 +0000",
    "user" : {
      "name" : "Bridget Mellor",
      "screen_name" : "bidamellor",
      "protected" : false,
      "id_str" : "1101111733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749737384284225536\/sVfK4S-6_normal.jpg",
      "id" : 1101111733,
      "verified" : false
    }
  },
  "id" : 657219993277440000,
  "created_at" : "2015-10-22 15:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JulieL.",
      "screen_name" : "ellinjaa",
      "indices" : [ 3, 12 ],
      "id_str" : "134011467",
      "id" : 134011467
    }, {
      "name" : "Gardening Australia",
      "screen_name" : "GardeningAus",
      "indices" : [ 15, 28 ],
      "id_str" : "66924202",
      "id" : 66924202
    }, {
      "name" : "Fiona Lake",
      "screen_name" : "FionaLakeAus",
      "indices" : [ 29, 42 ],
      "id_str" : "192801292",
      "id" : 192801292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657219537595707392",
  "text" : "RT @ellinjaa: .@GardeningAus @FionaLakeAus I thought it was dead &amp; others in mourning, but up he got. (September last year) #birds http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gardening Australia",
        "screen_name" : "GardeningAus",
        "indices" : [ 1, 14 ],
        "id_str" : "66924202",
        "id" : 66924202
      }, {
        "name" : "Fiona Lake",
        "screen_name" : "FionaLakeAus",
        "indices" : [ 15, 28 ],
        "id_str" : "192801292",
        "id" : 192801292
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ellinjaa\/status\/655316984083578882\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/JepnUj4r4D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRgnUIZUcAEBPn-.jpg",
        "id_str" : "655316972586954753",
        "id" : 655316972586954753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRgnUIZUcAEBPn-.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JepnUj4r4D"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ellinjaa\/status\/655316984083578882\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/JepnUj4r4D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRgnUssVAAErHEe.jpg",
        "id_str" : "655316982330359809",
        "id" : 655316982330359809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRgnUssVAAErHEe.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JepnUj4r4D"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ellinjaa\/status\/655316984083578882\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/JepnUj4r4D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRgnTqIUwAEkiuT.jpg",
        "id_str" : "655316964462608385",
        "id" : 655316964462608385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRgnTqIUwAEkiuT.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JepnUj4r4D"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "655299738690977793",
    "geo" : { },
    "id_str" : "655316984083578882",
    "in_reply_to_user_id" : 66924202,
    "text" : ".@GardeningAus @FionaLakeAus I thought it was dead &amp; others in mourning, but up he got. (September last year) #birds http:\/\/t.co\/JepnUj4r4D",
    "id" : 655316984083578882,
    "in_reply_to_status_id" : 655299738690977793,
    "created_at" : "2015-10-17 09:38:38 +0000",
    "in_reply_to_screen_name" : "GardeningAus",
    "in_reply_to_user_id_str" : "66924202",
    "user" : {
      "name" : "JulieL.",
      "screen_name" : "ellinjaa",
      "protected" : false,
      "id_str" : "134011467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762633126333997056\/PEvlHovE_normal.jpg",
      "id" : 134011467,
      "verified" : false
    }
  },
  "id" : 657219537595707392,
  "created_at" : "2015-10-22 15:38:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patriarchy",
      "indices" : [ 44, 55 ]
    }, {
      "text" : "BreakingTheGlassSteeple",
      "indices" : [ 106, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657218527229825024",
  "text" : "RT @jorymicah: Hey YOU! Wanna help me crush #patriarchy in Jesus' Church? Like me on FB! I need your help #BreakingTheGlassSteeple! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "patriarchy",
        "indices" : [ 29, 40 ]
      }, {
        "text" : "BreakingTheGlassSteeple",
        "indices" : [ 91, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/x7XNN3LCJ7",
        "expanded_url" : "https:\/\/www.facebook.com\/Jory-Micah-Ministries-780402312021299\/",
        "display_url" : "facebook.com\/Jory-Micah-Min\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657216391309737984",
    "text" : "Hey YOU! Wanna help me crush #patriarchy in Jesus' Church? Like me on FB! I need your help #BreakingTheGlassSteeple! https:\/\/t.co\/x7XNN3LCJ7",
    "id" : 657216391309737984,
    "created_at" : "2015-10-22 15:26:12 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 657218527229825024,
  "created_at" : "2015-10-22 15:34:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 3, 15 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "Kevin Gibbon",
      "screen_name" : "kevingibbon",
      "indices" : [ 101, 113 ],
      "id_str" : "95589124",
      "id" : 95589124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/6C8BljYEY2",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/shyp-2-0",
      "display_url" : "producthunt.com\/tech\/shyp-2-0"
    } ]
  },
  "geo" : { },
  "id_str" : "657217393710768128",
  "text" : "RT @ProductHunt: Shyp Introduces Address-Free Shipping. https:\/\/t.co\/6C8BljYEY2 Co-Founder &amp; CEO @kevingibbon is doing a LIVE\uD83D\uDCAC @ 10am https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Gibbon",
        "screen_name" : "kevingibbon",
        "indices" : [ 84, 96 ],
        "id_str" : "95589124",
        "id" : 95589124
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ProductHunt\/status\/657215221371539456\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/QuTTIohebu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR7lwqeUEAAzdY6.jpg",
        "id_str" : "657215219840585728",
        "id" : 657215219840585728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR7lwqeUEAAzdY6.jpg",
        "sizes" : [ {
          "h" : 1148,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1148,
          "resize" : "fit",
          "w" : 690
        } ],
        "display_url" : "pic.twitter.com\/QuTTIohebu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/6C8BljYEY2",
        "expanded_url" : "https:\/\/www.producthunt.com\/tech\/shyp-2-0",
        "display_url" : "producthunt.com\/tech\/shyp-2-0"
      } ]
    },
    "geo" : { },
    "id_str" : "657215221371539456",
    "text" : "Shyp Introduces Address-Free Shipping. https:\/\/t.co\/6C8BljYEY2 Co-Founder &amp; CEO @kevingibbon is doing a LIVE\uD83D\uDCAC @ 10am https:\/\/t.co\/QuTTIohebu",
    "id" : 657215221371539456,
    "created_at" : "2015-10-22 15:21:33 +0000",
    "user" : {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "protected" : false,
      "id_str" : "2208027565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783677864831021057\/fNU8i_FW_normal.jpg",
      "id" : 2208027565,
      "verified" : true
    }
  },
  "id" : 657217393710768128,
  "created_at" : "2015-10-22 15:30:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "indices" : [ 3, 15 ],
      "id_str" : "14873767",
      "id" : 14873767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657217075413426176",
  "text" : "RT @DanteAtkins: This new \"you didn't email about it so you didn't care\" is kind of amazing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657214806840225792",
    "text" : "This new \"you didn't email about it so you didn't care\" is kind of amazing.",
    "id" : 657214806840225792,
    "created_at" : "2015-10-22 15:19:55 +0000",
    "user" : {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "protected" : false,
      "id_str" : "14873767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466040900196372480\/uSZa77kS_normal.jpeg",
      "id" : 14873767,
      "verified" : true
    }
  },
  "id" : 657217075413426176,
  "created_at" : "2015-10-22 15:28:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/657214548697600000\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Kr2hyt3q19",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR7lJfcW0AA6wd9.jpg",
      "id_str" : "657214546864689152",
      "id" : 657214546864689152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR7lJfcW0AA6wd9.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 634
      } ],
      "display_url" : "pic.twitter.com\/Kr2hyt3q19"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657217022485483520",
  "text" : "RT @jacqueduncalf: \"Do you Twitter peeps think this is fair coz I ruddy well don't , he'll be having me dinner next\" https:\/\/t.co\/Kr2hyt3q19",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/657214548697600000\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/Kr2hyt3q19",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR7lJfcW0AA6wd9.jpg",
        "id_str" : "657214546864689152",
        "id" : 657214546864689152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR7lJfcW0AA6wd9.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 634
        } ],
        "display_url" : "pic.twitter.com\/Kr2hyt3q19"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657214548697600000",
    "text" : "\"Do you Twitter peeps think this is fair coz I ruddy well don't , he'll be having me dinner next\" https:\/\/t.co\/Kr2hyt3q19",
    "id" : 657214548697600000,
    "created_at" : "2015-10-22 15:18:53 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 657217022485483520,
  "created_at" : "2015-10-22 15:28:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "indices" : [ 3, 15 ],
      "id_str" : "16126957",
      "id" : 16126957
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/657211163181207552\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/jnj6Nx8r5m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR7h_v6XAAEOGI6.jpg",
      "id_str" : "657211080951922689",
      "id" : 657211080951922689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR7h_v6XAAEOGI6.jpg",
      "sizes" : [ {
        "h" : 303,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 913,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 913,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jnj6Nx8r5m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657215475986866176",
  "text" : "RT @paul_steele: An afternoon stroll.. the new nosey neighbours \uD83D\uDE0A https:\/\/t.co\/jnj6Nx8r5m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/657211163181207552\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/jnj6Nx8r5m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR7h_v6XAAEOGI6.jpg",
        "id_str" : "657211080951922689",
        "id" : 657211080951922689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR7h_v6XAAEOGI6.jpg",
        "sizes" : [ {
          "h" : 303,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 913,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 913,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jnj6Nx8r5m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657211163181207552",
    "text" : "An afternoon stroll.. the new nosey neighbours \uD83D\uDE0A https:\/\/t.co\/jnj6Nx8r5m",
    "id" : 657211163181207552,
    "created_at" : "2015-10-22 15:05:26 +0000",
    "user" : {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "protected" : false,
      "id_str" : "16126957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788690057599283200\/-_rph72s_normal.jpg",
      "id" : 16126957,
      "verified" : true
    }
  },
  "id" : 657215475986866176,
  "created_at" : "2015-10-22 15:22:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duck of the day",
      "screen_name" : "duckoftheday",
      "indices" : [ 3, 16 ],
      "id_str" : "61876375",
      "id" : 61876375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/S4ZoCpP5lU",
      "expanded_url" : "https:\/\/youtu.be\/qQX214Ugre4",
      "display_url" : "youtu.be\/qQX214Ugre4"
    } ]
  },
  "geo" : { },
  "id_str" : "657204100766023681",
  "text" : "RT @duckoftheday: Nap time! https:\/\/t.co\/S4ZoCpP5lU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/S4ZoCpP5lU",
        "expanded_url" : "https:\/\/youtu.be\/qQX214Ugre4",
        "display_url" : "youtu.be\/qQX214Ugre4"
      } ]
    },
    "in_reply_to_status_id_str" : "657180664765239296",
    "geo" : { },
    "id_str" : "657198573310857217",
    "in_reply_to_user_id" : 61876375,
    "text" : "Nap time! https:\/\/t.co\/S4ZoCpP5lU",
    "id" : 657198573310857217,
    "in_reply_to_status_id" : 657180664765239296,
    "created_at" : "2015-10-22 14:15:24 +0000",
    "in_reply_to_screen_name" : "duckoftheday",
    "in_reply_to_user_id_str" : "61876375",
    "user" : {
      "name" : "Duck of the day",
      "screen_name" : "duckoftheday",
      "protected" : false,
      "id_str" : "61876375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664083826268880896\/nbZOBXQw_normal.jpg",
      "id" : 61876375,
      "verified" : false
    }
  },
  "id" : 657204100766023681,
  "created_at" : "2015-10-22 14:37:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657197037117644800",
  "text" : "RT @ZachsMind: ...the universe we perceive may not be what we take for granted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657171693052362752",
    "text" : "...the universe we perceive may not be what we take for granted.",
    "id" : 657171693052362752,
    "created_at" : "2015-10-22 12:28:35 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 657197037117644800,
  "created_at" : "2015-10-22 14:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stuart petch",
      "screen_name" : "thelightoutside",
      "indices" : [ 3, 19 ],
      "id_str" : "703687800",
      "id" : 703687800
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thelightoutside\/status\/657105100524142592\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/DYyokwbATT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR6Bmy-WIAAw5fd.jpg",
      "id_str" : "657105099160952832",
      "id" : 657105099160952832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR6Bmy-WIAAw5fd.jpg",
      "sizes" : [ {
        "h" : 696,
        "resize" : "fit",
        "w" : 684
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 684
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DYyokwbATT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657196477215842304",
  "text" : "RT @thelightoutside: - very Zen - https:\/\/t.co\/DYyokwbATT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thelightoutside\/status\/657105100524142592\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/DYyokwbATT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR6Bmy-WIAAw5fd.jpg",
        "id_str" : "657105099160952832",
        "id" : 657105099160952832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR6Bmy-WIAAw5fd.jpg",
        "sizes" : [ {
          "h" : 696,
          "resize" : "fit",
          "w" : 684
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 684
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DYyokwbATT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657105100524142592",
    "text" : "- very Zen - https:\/\/t.co\/DYyokwbATT",
    "id" : 657105100524142592,
    "created_at" : "2015-10-22 08:03:59 +0000",
    "user" : {
      "name" : "stuart petch",
      "screen_name" : "thelightoutside",
      "protected" : false,
      "id_str" : "703687800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749635913815392256\/l203QrUF_normal.jpg",
      "id" : 703687800,
      "verified" : false
    }
  },
  "id" : 657196477215842304,
  "created_at" : "2015-10-22 14:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hug Medic Kale",
      "screen_name" : "DarkestKale",
      "indices" : [ 3, 15 ],
      "id_str" : "273885352",
      "id" : 273885352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/RsyjLG32ha",
      "expanded_url" : "https:\/\/twitter.com\/pjf\/status\/657068364691406848",
      "display_url" : "twitter.com\/pjf\/status\/657\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657195222984732672",
  "text" : "RT @DarkestKale: Straight up https:\/\/t.co\/RsyjLG32ha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/RsyjLG32ha",
        "expanded_url" : "https:\/\/twitter.com\/pjf\/status\/657068364691406848",
        "display_url" : "twitter.com\/pjf\/status\/657\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657191494504214528",
    "text" : "Straight up https:\/\/t.co\/RsyjLG32ha",
    "id" : 657191494504214528,
    "created_at" : "2015-10-22 13:47:16 +0000",
    "user" : {
      "name" : "Hug Medic Kale",
      "screen_name" : "DarkestKale",
      "protected" : false,
      "id_str" : "273885352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495586185318658048\/Jv-I_BbN_normal.png",
      "id" : 273885352,
      "verified" : false
    }
  },
  "id" : 657195222984732672,
  "created_at" : "2015-10-22 14:02:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JC",
      "screen_name" : "rnadna2",
      "indices" : [ 3, 11 ],
      "id_str" : "139613298",
      "id" : 139613298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Republican",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/itu1NOLDjC",
      "expanded_url" : "https:\/\/twitter.com\/ROBENT805\/status\/656973850824069121",
      "display_url" : "twitter.com\/ROBENT805\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656992302985031680",
  "text" : "RT @rnadna2: He's a White Christian #Republican... https:\/\/t.co\/itu1NOLDjC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Republican",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/itu1NOLDjC",
        "expanded_url" : "https:\/\/twitter.com\/ROBENT805\/status\/656973850824069121",
        "display_url" : "twitter.com\/ROBENT805\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656990703428456448",
    "text" : "He's a White Christian #Republican... https:\/\/t.co\/itu1NOLDjC",
    "id" : 656990703428456448,
    "created_at" : "2015-10-22 00:29:24 +0000",
    "user" : {
      "name" : "JC",
      "screen_name" : "rnadna2",
      "protected" : false,
      "id_str" : "139613298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527669898525175809\/HaxIH4W9_normal.jpeg",
      "id" : 139613298,
      "verified" : false
    }
  },
  "id" : 656992302985031680,
  "created_at" : "2015-10-22 00:35:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/nAsumTlU0M",
      "expanded_url" : "https:\/\/twitter.com\/godless_mom\/status\/656923828967182336",
      "display_url" : "twitter.com\/godless_mom\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656972156191002624",
  "text" : "I'm not atheist but I like this. : )  https:\/\/t.co\/nAsumTlU0M",
  "id" : 656972156191002624,
  "created_at" : "2015-10-21 23:15:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656947979471814656",
  "geo" : { },
  "id_str" : "656970304430985216",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre me, too.. bless him.",
  "id" : 656970304430985216,
  "in_reply_to_status_id" : 656947979471814656,
  "created_at" : "2015-10-21 23:08:21 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mere Journal",
      "screen_name" : "MereJournal",
      "indices" : [ 3, 15 ],
      "id_str" : "1535828562",
      "id" : 1535828562
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MereJournal\/status\/656927401604202496\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/WnwDnl2g5C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR3f9aNW0AApj5W.jpg",
      "id_str" : "656927366766317568",
      "id" : 656927366766317568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR3f9aNW0AApj5W.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/WnwDnl2g5C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656969704637136896",
  "text" : "RT @MereJournal: https:\/\/t.co\/WnwDnl2g5C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MereJournal\/status\/656927401604202496\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/WnwDnl2g5C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR3f9aNW0AApj5W.jpg",
        "id_str" : "656927366766317568",
        "id" : 656927366766317568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR3f9aNW0AApj5W.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/WnwDnl2g5C"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656927401604202496",
    "text" : "https:\/\/t.co\/WnwDnl2g5C",
    "id" : 656927401604202496,
    "created_at" : "2015-10-21 20:17:52 +0000",
    "user" : {
      "name" : "Mere Journal",
      "screen_name" : "MereJournal",
      "protected" : false,
      "id_str" : "1535828562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502090831235276800\/wVNC75ez_normal.png",
      "id" : 1535828562,
      "verified" : false
    }
  },
  "id" : 656969704637136896,
  "created_at" : "2015-10-21 23:05:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656923130485542912",
  "geo" : { },
  "id_str" : "656923832750624768",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time well that's not good! wow.",
  "id" : 656923832750624768,
  "in_reply_to_status_id" : 656923130485542912,
  "created_at" : "2015-10-21 20:03:41 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Religulous",
      "screen_name" : "religulous",
      "indices" : [ 3, 14 ],
      "id_str" : "17502089",
      "id" : 17502089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656917524802613249",
  "text" : "RT @religulous: Conditional love demanded of followers by Jesus in NT (\"love me or burn in hell forever\") is antithesis of love. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/y4XG0PoaNs",
        "expanded_url" : "https:\/\/twitter.com\/doubtism\/status\/656840740140519424",
        "display_url" : "twitter.com\/doubtism\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656845970408255488",
    "text" : "Conditional love demanded of followers by Jesus in NT (\"love me or burn in hell forever\") is antithesis of love. https:\/\/t.co\/y4XG0PoaNs",
    "id" : 656845970408255488,
    "created_at" : "2015-10-21 14:54:17 +0000",
    "user" : {
      "name" : "Religulous",
      "screen_name" : "religulous",
      "protected" : false,
      "id_str" : "17502089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750440268210446336\/U6aS-iyn_normal.jpg",
      "id" : 17502089,
      "verified" : false
    }
  },
  "id" : 656917524802613249,
  "created_at" : "2015-10-21 19:38:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656856880044752896",
  "geo" : { },
  "id_str" : "656917289514770434",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe WHAT?? wtf... ((hugs))",
  "id" : 656917289514770434,
  "in_reply_to_status_id" : 656856880044752896,
  "created_at" : "2015-10-21 19:37:41 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaili Joy Gray",
      "screen_name" : "KailiJoy",
      "indices" : [ 3, 12 ],
      "id_str" : "211785295",
      "id" : 211785295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656915664322625536",
  "text" : "RT @KailiJoy: Now please imagine if a woman in Ryan's position insisted she have weekends off to spend with her family. \n\nYeah.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656651965821116416",
    "text" : "Now please imagine if a woman in Ryan's position insisted she have weekends off to spend with her family. \n\nYeah.",
    "id" : 656651965821116416,
    "created_at" : "2015-10-21 02:03:23 +0000",
    "user" : {
      "name" : "Kaili Joy Gray",
      "screen_name" : "KailiJoy",
      "protected" : false,
      "id_str" : "211785295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779829875972505600\/b835yeIu_normal.jpg",
      "id" : 211785295,
      "verified" : false
    }
  },
  "id" : 656915664322625536,
  "created_at" : "2015-10-21 19:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosalea Jerseys",
      "screen_name" : "RosaleaJerseys",
      "indices" : [ 3, 18 ],
      "id_str" : "1359681031",
      "id" : 1359681031
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RosaleaJerseys\/status\/656603899680260096\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Ejyu32lDc1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRy5u65U8AEqG8y.jpg",
      "id_str" : "656603861424074753",
      "id" : 656603861424074753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRy5u65U8AEqG8y.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ejyu32lDc1"
    } ],
    "hashtags" : [ {
      "text" : "farm365",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656841792592179202",
  "text" : "RT @RosaleaJerseys: These two are having fun following us around the barn tonight! #farm365 https:\/\/t.co\/Ejyu32lDc1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RosaleaJerseys\/status\/656603899680260096\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/Ejyu32lDc1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRy5u65U8AEqG8y.jpg",
        "id_str" : "656603861424074753",
        "id" : 656603861424074753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRy5u65U8AEqG8y.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ejyu32lDc1"
      } ],
      "hashtags" : [ {
        "text" : "farm365",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656603899680260096",
    "text" : "These two are having fun following us around the barn tonight! #farm365 https:\/\/t.co\/Ejyu32lDc1",
    "id" : 656603899680260096,
    "created_at" : "2015-10-20 22:52:23 +0000",
    "user" : {
      "name" : "Rosalea Jerseys",
      "screen_name" : "RosaleaJerseys",
      "protected" : false,
      "id_str" : "1359681031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422838791062028288\/0LCATM2Y_normal.jpeg",
      "id" : 1359681031,
      "verified" : false
    }
  },
  "id" : 656841792592179202,
  "created_at" : "2015-10-21 14:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656841077677248512",
  "text" : "RT @adamrshields: Audiobook of Dracula by Bram Stoker (narrated by Tim Curry) is free if you buy the free Kindle Edition first. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/QCb2dkDBgo",
        "expanded_url" : "http:\/\/amzn.to\/1GRSVVw",
        "display_url" : "amzn.to\/1GRSVVw"
      } ]
    },
    "geo" : { },
    "id_str" : "656671950899662848",
    "text" : "Audiobook of Dracula by Bram Stoker (narrated by Tim Curry) is free if you buy the free Kindle Edition first. https:\/\/t.co\/QCb2dkDBgo",
    "id" : 656671950899662848,
    "created_at" : "2015-10-21 03:22:48 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 656841077677248512,
  "created_at" : "2015-10-21 14:34:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ocean Conservancy",
      "screen_name" : "OurOcean",
      "indices" : [ 3, 12 ],
      "id_str" : "71019945",
      "id" : 71019945
    }, {
      "name" : "Smithsonian Magazine",
      "screen_name" : "SmithsonianMag",
      "indices" : [ 115, 130 ],
      "id_str" : "17998609",
      "id" : 17998609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/7avJ4hW9zp",
      "expanded_url" : "http:\/\/ow.ly\/TD3It",
      "display_url" : "ow.ly\/TD3It"
    } ]
  },
  "geo" : { },
  "id_str" : "656840550583279617",
  "text" : "RT @OurOcean: There are whales alive today who were born before Moby Dick was written. https:\/\/t.co\/7avJ4hW9zp via @SmithsonianMag https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smithsonian Magazine",
        "screen_name" : "SmithsonianMag",
        "indices" : [ 101, 116 ],
        "id_str" : "17998609",
        "id" : 17998609
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OurOcean\/status\/656592078022033408\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/EiJmfU7RQR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRyvBBfWsAEoUej.jpg",
        "id_str" : "656592077803925505",
        "id" : 656592077803925505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRyvBBfWsAEoUej.jpg",
        "sizes" : [ {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EiJmfU7RQR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/7avJ4hW9zp",
        "expanded_url" : "http:\/\/ow.ly\/TD3It",
        "display_url" : "ow.ly\/TD3It"
      } ]
    },
    "geo" : { },
    "id_str" : "656592078022033408",
    "text" : "There are whales alive today who were born before Moby Dick was written. https:\/\/t.co\/7avJ4hW9zp via @SmithsonianMag https:\/\/t.co\/EiJmfU7RQR",
    "id" : 656592078022033408,
    "created_at" : "2015-10-20 22:05:24 +0000",
    "user" : {
      "name" : "Ocean Conservancy",
      "screen_name" : "OurOcean",
      "protected" : false,
      "id_str" : "71019945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768901284124585984\/TJ_qyHRm_normal.jpg",
      "id" : 71019945,
      "verified" : false
    }
  },
  "id" : 656840550583279617,
  "created_at" : "2015-10-21 14:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/656608195591413760\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/DsHVpkRdPI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRy9rFrWIAAssgR.jpg",
      "id_str" : "656608193645256704",
      "id" : 656608193645256704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRy9rFrWIAAssgR.jpg",
      "sizes" : [ {
        "h" : 2592,
        "resize" : "fit",
        "w" : 3456
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DsHVpkRdPI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656614033014063105",
  "text" : "RT @wildwitchyju: https:\/\/t.co\/DsHVpkRdPI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/656608195591413760\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/DsHVpkRdPI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRy9rFrWIAAssgR.jpg",
        "id_str" : "656608193645256704",
        "id" : 656608193645256704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRy9rFrWIAAssgR.jpg",
        "sizes" : [ {
          "h" : 2592,
          "resize" : "fit",
          "w" : 3456
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DsHVpkRdPI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656608195591413760",
    "text" : "https:\/\/t.co\/DsHVpkRdPI",
    "id" : 656608195591413760,
    "created_at" : "2015-10-20 23:09:27 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 656614033014063105,
  "created_at" : "2015-10-20 23:32:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "indices" : [ 3, 17 ],
      "id_str" : "26642006",
      "id" : 26642006
    }, {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 108, 113 ],
      "id_str" : "23818581",
      "id" : 23818581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/a45M6QFPqz",
      "expanded_url" : "http:\/\/bit.ly\/1RkjEiY",
      "display_url" : "bit.ly\/1RkjEiY"
    } ]
  },
  "geo" : { },
  "id_str" : "656482512395489280",
  "text" : "RT @Alyssa_Milano: What Americans need to know about today's Canadian election https:\/\/t.co\/a45M6QFPqz \/via @VICE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VICE",
        "screen_name" : "VICE",
        "indices" : [ 89, 94 ],
        "id_str" : "23818581",
        "id" : 23818581
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/a45M6QFPqz",
        "expanded_url" : "http:\/\/bit.ly\/1RkjEiY",
        "display_url" : "bit.ly\/1RkjEiY"
      } ]
    },
    "geo" : { },
    "id_str" : "656333020740218880",
    "text" : "What Americans need to know about today's Canadian election https:\/\/t.co\/a45M6QFPqz \/via @VICE",
    "id" : 656333020740218880,
    "created_at" : "2015-10-20 04:56:00 +0000",
    "user" : {
      "name" : "Alyssa Milano",
      "screen_name" : "Alyssa_Milano",
      "protected" : false,
      "id_str" : "26642006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797077615064457217\/mSJCnze-_normal.jpg",
      "id" : 26642006,
      "verified" : true
    }
  },
  "id" : 656482512395489280,
  "created_at" : "2015-10-20 14:50:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656457924471070720",
  "geo" : { },
  "id_str" : "656479487333396480",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe I hope you have a very good day today.. you deserve it. Happy birthday! : )",
  "id" : 656479487333396480,
  "in_reply_to_status_id" : 656457924471070720,
  "created_at" : "2015-10-20 14:38:01 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656478593070055424",
  "text" : "found can of condensed milk so i got that in my creamerless coffee today.",
  "id" : 656478593070055424,
  "created_at" : "2015-10-20 14:34:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656306947365470208",
  "text" : "RT @Pandeism: There is a story being told and it is us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656305436736540672",
    "text" : "There is a story being told and it is us.",
    "id" : 656305436736540672,
    "created_at" : "2015-10-20 03:06:24 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 656306947365470208,
  "created_at" : "2015-10-20 03:12:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sockyarnshop.com",
      "screen_name" : "SockYarnShop",
      "indices" : [ 3, 16 ],
      "id_str" : "215578621",
      "id" : 215578621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SockYarnShop\/status\/656158513576677376\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/KAe8lA5o6S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRsksKWXAAEukhj.jpg",
      "id_str" : "656158511823519745",
      "id" : 656158511823519745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRsksKWXAAEukhj.jpg",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/KAe8lA5o6S"
    } ],
    "hashtags" : [ {
      "text" : "freepattern",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/E72Ip9W3zx",
      "expanded_url" : "http:\/\/yellowpinkandsparkly.blogspot.de\/2012\/04\/fair-isle-mice-pattern.html",
      "display_url" : "yellowpinkandsparkly.blogspot.de\/2012\/04\/fair-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656173246384050176",
  "text" : "RT @SockYarnShop: Fair Isle Mice #freepattern \uD83D\uDC2Dhttp:\/\/t.co\/E72Ip9W3zx http:\/\/t.co\/KAe8lA5o6S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SockYarnShop\/status\/656158513576677376\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/KAe8lA5o6S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRsksKWXAAEukhj.jpg",
        "id_str" : "656158511823519745",
        "id" : 656158511823519745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRsksKWXAAEukhj.jpg",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/KAe8lA5o6S"
      } ],
      "hashtags" : [ {
        "text" : "freepattern",
        "indices" : [ 15, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/E72Ip9W3zx",
        "expanded_url" : "http:\/\/yellowpinkandsparkly.blogspot.de\/2012\/04\/fair-isle-mice-pattern.html",
        "display_url" : "yellowpinkandsparkly.blogspot.de\/2012\/04\/fair-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656158513576677376",
    "text" : "Fair Isle Mice #freepattern \uD83D\uDC2Dhttp:\/\/t.co\/E72Ip9W3zx http:\/\/t.co\/KAe8lA5o6S",
    "id" : 656158513576677376,
    "created_at" : "2015-10-19 17:22:35 +0000",
    "user" : {
      "name" : "sockyarnshop.com",
      "screen_name" : "SockYarnShop",
      "protected" : false,
      "id_str" : "215578621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1409679918\/DSC_0212_normal.jpg",
      "id" : 215578621,
      "verified" : false
    }
  },
  "id" : 656173246384050176,
  "created_at" : "2015-10-19 18:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/3hJXtN2Ql0",
      "expanded_url" : "http:\/\/booky.io",
      "display_url" : "booky.io"
    } ]
  },
  "geo" : { },
  "id_str" : "656156217711173633",
  "text" : "new free private online bookmark manager http:\/\/t.co\/3hJXtN2Ql0",
  "id" : 656156217711173633,
  "created_at" : "2015-10-19 17:13:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656131224797343744",
  "geo" : { },
  "id_str" : "656143367139663873",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley ACK! my eyes!",
  "id" : 656143367139663873,
  "in_reply_to_status_id" : 656131224797343744,
  "created_at" : "2015-10-19 16:22:23 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gaymarriage",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "lgbt",
      "indices" : [ 115, 120 ]
    }, {
      "text" : "Bible",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "Jesus",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656118117018550272",
  "text" : "RT @AnnotatedBible: It's morally wrong to condemn someone for being the person they were born to be.\n\n#gaymarriage #lgbt #Bible #Jesus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gaymarriage",
        "indices" : [ 82, 94 ]
      }, {
        "text" : "lgbt",
        "indices" : [ 95, 100 ]
      }, {
        "text" : "Bible",
        "indices" : [ 101, 107 ]
      }, {
        "text" : "Jesus",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655927959497277440",
    "text" : "It's morally wrong to condemn someone for being the person they were born to be.\n\n#gaymarriage #lgbt #Bible #Jesus",
    "id" : 655927959497277440,
    "created_at" : "2015-10-19 02:06:26 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 656118117018550272,
  "created_at" : "2015-10-19 14:42:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656115995149402113",
  "geo" : { },
  "id_str" : "656117043046039552",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dreavesphoto ahh.. cool! : )",
  "id" : 656117043046039552,
  "in_reply_to_status_id" : 656115995149402113,
  "created_at" : "2015-10-19 14:37:47 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/KmeFEQ8qpB",
      "expanded_url" : "https:\/\/twitter.com\/dreavesphoto\/status\/655941753636130816",
      "display_url" : "twitter.com\/dreavesphoto\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656115347003674624",
  "text" : "Let's follow it and see where it goes. Adventure! https:\/\/t.co\/KmeFEQ8qpB",
  "id" : 656115347003674624,
  "created_at" : "2015-10-19 14:31:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat Quirke",
      "screen_name" : "patquirke",
      "indices" : [ 3, 13 ],
      "id_str" : "20155325",
      "id" : 20155325
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/656001671743541248\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/E4vfNIkhLe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRqWBz8WwAAh79_.jpg",
      "id_str" : "656001653603221504",
      "id" : 656001653603221504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRqWBz8WwAAh79_.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/E4vfNIkhLe"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/656001671743541248\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/E4vfNIkhLe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRqWB0VXAAAUFiC.jpg",
      "id_str" : "656001653708095488",
      "id" : 656001653708095488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRqWB0VXAAAUFiC.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/E4vfNIkhLe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656113029017444352",
  "text" : "RT @patquirke: Percy espies the dogs safely from his staging post vantage point. http:\/\/t.co\/E4vfNIkhLe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/656001671743541248\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/E4vfNIkhLe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRqWBz8WwAAh79_.jpg",
        "id_str" : "656001653603221504",
        "id" : 656001653603221504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRqWBz8WwAAh79_.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/E4vfNIkhLe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/patquirke\/status\/656001671743541248\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/E4vfNIkhLe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRqWB0VXAAAUFiC.jpg",
        "id_str" : "656001653708095488",
        "id" : 656001653708095488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRqWB0VXAAAUFiC.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/E4vfNIkhLe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656001671743541248",
    "text" : "Percy espies the dogs safely from his staging post vantage point. http:\/\/t.co\/E4vfNIkhLe",
    "id" : 656001671743541248,
    "created_at" : "2015-10-19 06:59:21 +0000",
    "user" : {
      "name" : "Pat Quirke",
      "screen_name" : "patquirke",
      "protected" : false,
      "id_str" : "20155325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2298721913\/jbjszykzpkp3kc1egu0v_normal.jpeg",
      "id" : 20155325,
      "verified" : false
    }
  },
  "id" : 656113029017444352,
  "created_at" : "2015-10-19 14:21:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa Wilson",
      "screen_name" : "AlexaDWilson",
      "indices" : [ 3, 16 ],
      "id_str" : "218081229",
      "id" : 218081229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlexaDWilson\/status\/656063987822501888\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/06s0lu3LWi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRrOuIFWIAAJx2b.jpg",
      "id_str" : "656063987575037952",
      "id" : 656063987575037952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRrOuIFWIAAJx2b.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/06s0lu3LWi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656112691237560320",
  "text" : "RT @AlexaDWilson: From this morning\u2019s walk. Look closely. http:\/\/t.co\/06s0lu3LWi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlexaDWilson\/status\/656063987822501888\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/06s0lu3LWi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRrOuIFWIAAJx2b.jpg",
        "id_str" : "656063987575037952",
        "id" : 656063987575037952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRrOuIFWIAAJx2b.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/06s0lu3LWi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656063987822501888",
    "text" : "From this morning\u2019s walk. Look closely. http:\/\/t.co\/06s0lu3LWi",
    "id" : 656063987822501888,
    "created_at" : "2015-10-19 11:06:58 +0000",
    "user" : {
      "name" : "Alexa Wilson",
      "screen_name" : "AlexaDWilson",
      "protected" : false,
      "id_str" : "218081229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485375150049591296\/Sa2eBCfB_normal.png",
      "id" : 218081229,
      "verified" : false
    }
  },
  "id" : 656112691237560320,
  "created_at" : "2015-10-19 14:20:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655918712705388544",
  "geo" : { },
  "id_str" : "655919561108254720",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis aww.. bless her. : )",
  "id" : 655919561108254720,
  "in_reply_to_status_id" : 655918712705388544,
  "created_at" : "2015-10-19 01:33:04 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/574202359703826433\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/25s2RFOyV3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_f6ALlWAAAi2o5.jpg",
      "id_str" : "574202358529392640",
      "id" : 574202358529392640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_f6ALlWAAAi2o5.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/25s2RFOyV3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655917900310646784",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/25s2RFOyV3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/574202359703826433\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/25s2RFOyV3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_f6ALlWAAAi2o5.jpg",
        "id_str" : "574202358529392640",
        "id" : 574202358529392640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_f6ALlWAAAi2o5.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/25s2RFOyV3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655913812969848832",
    "text" : "http:\/\/t.co\/25s2RFOyV3",
    "id" : 655913812969848832,
    "created_at" : "2015-10-19 01:10:13 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 655917900310646784,
  "created_at" : "2015-10-19 01:26:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GilenLinn",
      "screen_name" : "Gilenlinn",
      "indices" : [ 3, 13 ],
      "id_str" : "2854308140",
      "id" : 2854308140
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gilenlinn\/status\/655215486154633217\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/2LFZqGi7WA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRfLA1WUwAAHa0g.jpg",
      "id_str" : "655215485986848768",
      "id" : 655215485986848768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRfLA1WUwAAHa0g.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 1121
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2LFZqGi7WA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655889619209338880",
  "text" : "RT @Gilenlinn: Reflected willow http:\/\/t.co\/2LFZqGi7WA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gilenlinn\/status\/655215486154633217\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/2LFZqGi7WA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRfLA1WUwAAHa0g.jpg",
        "id_str" : "655215485986848768",
        "id" : 655215485986848768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRfLA1WUwAAHa0g.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 1121
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2LFZqGi7WA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655215486154633217",
    "text" : "Reflected willow http:\/\/t.co\/2LFZqGi7WA",
    "id" : 655215486154633217,
    "created_at" : "2015-10-17 02:55:19 +0000",
    "user" : {
      "name" : "GilenLinn",
      "screen_name" : "Gilenlinn",
      "protected" : false,
      "id_str" : "2854308140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521635248413495297\/oTq4lvGL_normal.jpeg",
      "id" : 2854308140,
      "verified" : false
    }
  },
  "id" : 655889619209338880,
  "created_at" : "2015-10-18 23:34:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/655788987337080832\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ZoFcW7TnNS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRnUm1SWcAEQmG9.jpg",
      "id_str" : "655788984363282433",
      "id" : 655788984363282433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRnUm1SWcAEQmG9.jpg",
      "sizes" : [ {
        "h" : 649,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/ZoFcW7TnNS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/1dhHDVVrwl",
      "expanded_url" : "http:\/\/singlepayercentral.com\/?_ts=1445187248",
      "display_url" : "singlepayercentral.com\/?_ts=1445187248"
    } ]
  },
  "geo" : { },
  "id_str" : "655788987337080832",
  "text" : "Single Payer Central http:\/\/t.co\/1dhHDVVrwl http:\/\/t.co\/ZoFcW7TnNS",
  "id" : 655788987337080832,
  "created_at" : "2015-10-18 16:54:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655497857978474496",
  "text" : "me: \"I hate it.\" DD: \"You hate a lot of things.\" o-O gah",
  "id" : 655497857978474496,
  "created_at" : "2015-10-17 21:37:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interfaith",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/rps5DYPje0",
      "expanded_url" : "https:\/\/twitter.com\/LibyaLiberty\/status\/655433211921702912",
      "display_url" : "twitter.com\/LibyaLiberty\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655441809968123904",
  "text" : "RT @CrystalLewis: This is what #interfaith dialogue does. https:\/\/t.co\/rps5DYPje0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "interfaith",
        "indices" : [ 13, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/rps5DYPje0",
        "expanded_url" : "https:\/\/twitter.com\/LibyaLiberty\/status\/655433211921702912",
        "display_url" : "twitter.com\/LibyaLiberty\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655434231342993408",
    "text" : "This is what #interfaith dialogue does. https:\/\/t.co\/rps5DYPje0",
    "id" : 655434231342993408,
    "created_at" : "2015-10-17 17:24:32 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 655441809968123904,
  "created_at" : "2015-10-17 17:54:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spry Guy",
      "screen_name" : "SpryGuy",
      "indices" : [ 3, 11 ],
      "id_str" : "228015335",
      "id" : 228015335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655440007839227904",
  "text" : "RT @SpryGuy: I'm voting for the Democratic Presidential Candidate in 2016 b\/c the Republican Party poses a clear &amp; present danger to Americ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "topprog",
        "indices" : [ 133, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655437458994102272",
    "text" : "I'm voting for the Democratic Presidential Candidate in 2016 b\/c the Republican Party poses a clear &amp; present danger to America. #topprog",
    "id" : 655437458994102272,
    "created_at" : "2015-10-17 17:37:22 +0000",
    "user" : {
      "name" : "Spry Guy",
      "screen_name" : "SpryGuy",
      "protected" : false,
      "id_str" : "228015335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3358487599\/b7e72aaa11db9b615a2017dc45c8ee13_normal.png",
      "id" : 228015335,
      "verified" : false
    }
  },
  "id" : 655440007839227904,
  "created_at" : "2015-10-17 17:47:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "indices" : [ 89, 98 ],
      "id_str" : "18851248",
      "id" : 18851248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/i8KaK9fEXD",
      "expanded_url" : "http:\/\/www.alternet.org\/election-2016\/bernie-gets-it-done-sanders-record-pushing-through-major-reforms-will-surprise-you",
      "display_url" : "alternet.org\/election-2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655438184344612864",
  "text" : "Bernie Gets It Done: Sanders' Record of Pushing Through Major Reforms Will Surprise You\n @alternet http:\/\/t.co\/i8KaK9fEXD",
  "id" : 655438184344612864,
  "created_at" : "2015-10-17 17:40:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655423049500610560",
  "text" : "RT @mikemchargue: Concussions are weird.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655418909609299968",
    "text" : "Concussions are weird.",
    "id" : 655418909609299968,
    "created_at" : "2015-10-17 16:23:39 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 655423049500610560,
  "created_at" : "2015-10-17 16:40:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655423027551842304",
  "text" : "RT @mikemchargue: Went to the grocery store with the Honey Badger and had to leave. Overwhelmed by the sounds-it's like I couldn't filter a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655418850935181313",
    "text" : "Went to the grocery store with the Honey Badger and had to leave. Overwhelmed by the sounds-it's like I couldn't filter anything.",
    "id" : 655418850935181313,
    "created_at" : "2015-10-17 16:23:25 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 655423027551842304,
  "created_at" : "2015-10-17 16:40:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655416238810746880",
  "text" : "ugh. coffee with plain milk.",
  "id" : 655416238810746880,
  "created_at" : "2015-10-17 16:13:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655410961722011648",
  "geo" : { },
  "id_str" : "655416027652734976",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides what a cutie. so smoochable!",
  "id" : 655416027652734976,
  "in_reply_to_status_id" : 655410961722011648,
  "created_at" : "2015-10-17 16:12:12 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Euphoric Expressions",
      "screen_name" : "PsychedelicAtom",
      "indices" : [ 3, 19 ],
      "id_str" : "2424454140",
      "id" : 2424454140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655215929366835200",
  "text" : "RT @PsychedelicAtom: Overthinking is the biggest cause of our unhappiness. Keep yourself occupied. Keep your mind off things that don\u2019t hel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655205338971533312",
    "text" : "Overthinking is the biggest cause of our unhappiness. Keep yourself occupied. Keep your mind off things that don\u2019t help you.",
    "id" : 655205338971533312,
    "created_at" : "2015-10-17 02:15:00 +0000",
    "user" : {
      "name" : "Euphoric Expressions",
      "screen_name" : "PsychedelicAtom",
      "protected" : false,
      "id_str" : "2424454140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650442566505246720\/MhJlptkO_normal.jpg",
      "id" : 2424454140,
      "verified" : false
    }
  },
  "id" : 655215929366835200,
  "created_at" : "2015-10-17 02:57:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/655187836094783488\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ZsQsA5Wb9X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRex3PhWoAAu5iv.jpg",
      "id_str" : "655187833423044608",
      "id" : 655187833423044608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRex3PhWoAAu5iv.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/ZsQsA5Wb9X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/7WDEItpGtJ",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2015\/07\/06\/revenge-killing?_ts=1445043923",
      "display_url" : "newyorker.com\/magazine\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655187836094783488",
  "text" : "This man is scary... The Death Penalty in Louisiana http:\/\/t.co\/7WDEItpGtJ http:\/\/t.co\/ZsQsA5Wb9X",
  "id" : 655187836094783488,
  "created_at" : "2015-10-17 01:05:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655171650732892160",
  "text" : "i really need a database, not a spreadsheet.. hmm.. but software is so complicated anymore..",
  "id" : 655171650732892160,
  "created_at" : "2015-10-17 00:01:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/654756448031739904\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/RmeCXSoLbz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYphTHUcAAKCOw.jpg",
      "id_str" : "654756447872380928",
      "id" : 654756447872380928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYphTHUcAAKCOw.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RmeCXSoLbz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655137336599138304",
  "text" : "RT @SciencePorn: Here's a tiny bison to cheer you up http:\/\/t.co\/RmeCXSoLbz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/654756448031739904\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/RmeCXSoLbz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYphTHUcAAKCOw.jpg",
        "id_str" : "654756447872380928",
        "id" : 654756447872380928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYphTHUcAAKCOw.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RmeCXSoLbz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654756448031739904",
    "text" : "Here's a tiny bison to cheer you up http:\/\/t.co\/RmeCXSoLbz",
    "id" : 654756448031739904,
    "created_at" : "2015-10-15 20:31:16 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 655137336599138304,
  "created_at" : "2015-10-16 21:44:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/655124157320052736\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/R62LVZkimI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRd38pjWIAE1gMs.jpg",
      "id_str" : "655124154635657217",
      "id" : 655124154635657217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRd38pjWIAE1gMs.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/R62LVZkimI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/50WDs5EP61",
      "expanded_url" : "http:\/\/www.strongwomenwildhorses.com\/?_ts=1445028743",
      "display_url" : "strongwomenwildhorses.com\/?_ts=1445028743"
    } ]
  },
  "geo" : { },
  "id_str" : "655124157320052736",
  "text" : "strongandwild http:\/\/t.co\/50WDs5EP61 STRONG WOMEN, WILD HORSES http:\/\/t.co\/R62LVZkimI",
  "id" : 655124157320052736,
  "created_at" : "2015-10-16 20:52:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655103795802865664",
  "text" : "RT @Angelapaints: Seniors didn't drain SSI to pay for wars, they sent their kids.  Seniors didn't crash Wall Street. Seniors are now the ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655063804523376640",
    "text" : "Seniors didn't drain SSI to pay for wars, they sent their kids.  Seniors didn't crash Wall Street. Seniors are now the target.",
    "id" : 655063804523376640,
    "created_at" : "2015-10-16 16:52:36 +0000",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 655103795802865664,
  "created_at" : "2015-10-16 19:31:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/el5RS9DR7R",
      "expanded_url" : "https:\/\/twitter.com\/JaneHoworthKnit\/status\/655045413146349568",
      "display_url" : "twitter.com\/JaneHoworthKni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655095816542158850",
  "text" : "pretty! perfect with denims. https:\/\/t.co\/el5RS9DR7R",
  "id" : 655095816542158850,
  "created_at" : "2015-10-16 18:59:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burner",
      "screen_name" : "burner",
      "indices" : [ 3, 10 ],
      "id_str" : "511190986",
      "id" : 511190986
    }, {
      "name" : "evernote",
      "screen_name" : "evernote",
      "indices" : [ 21, 30 ],
      "id_str" : "13837292",
      "id" : 13837292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ahsg7foWgi",
      "expanded_url" : "http:\/\/smarturl.it\/BurnerEvernote?IQid=twitter",
      "display_url" : "smarturl.it\/BurnerEvernote\u2026"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/eZvHfrDuN9",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/170437d4-2b39-4309-822d-7728c4c438f5",
      "display_url" : "amp.twimg.com\/v\/170437d4-2b3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655093118354771968",
  "text" : "RT @burner: Burner + @Evernote\u200B - easily make your own SMS auto-reply bot. Learn more at http:\/\/t.co\/ahsg7foWgi\nhttps:\/\/t.co\/eZvHfrDuN9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "evernote",
        "screen_name" : "evernote",
        "indices" : [ 9, 18 ],
        "id_str" : "13837292",
        "id" : 13837292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/ahsg7foWgi",
        "expanded_url" : "http:\/\/smarturl.it\/BurnerEvernote?IQid=twitter",
        "display_url" : "smarturl.it\/BurnerEvernote\u2026"
      }, {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/eZvHfrDuN9",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/170437d4-2b39-4309-822d-7728c4c438f5",
        "display_url" : "amp.twimg.com\/v\/170437d4-2b3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652264180012089344",
    "text" : "Burner + @Evernote\u200B - easily make your own SMS auto-reply bot. Learn more at http:\/\/t.co\/ahsg7foWgi\nhttps:\/\/t.co\/eZvHfrDuN9",
    "id" : 652264180012089344,
    "created_at" : "2015-10-08 23:27:53 +0000",
    "user" : {
      "name" : "Burner",
      "screen_name" : "burner",
      "protected" : false,
      "id_str" : "511190986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000510394358\/e2a4278203cd22fdb327833a61d027d8_normal.png",
      "id" : 511190986,
      "verified" : false
    }
  },
  "id" : 655093118354771968,
  "created_at" : "2015-10-16 18:49:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisadeemo",
      "screen_name" : "lisadeemo",
      "indices" : [ 3, 13 ],
      "id_str" : "1219481202",
      "id" : 1219481202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655078403654230016",
  "text" : "RT @lisadeemo: @moel_bryn  @jacqueduncalf @LillMagill @dianebartlett99 @Love4AnimalsNL @SharonHoole @nicnak40 @peteswildlife TYVM x http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jacqueline duncalf",
        "screen_name" : "jacqueduncalf",
        "indices" : [ 12, 26 ],
        "id_str" : "1963095853",
        "id" : 1963095853
      }, {
        "name" : "Jeanette Fletcher",
        "screen_name" : "LillMagill",
        "indices" : [ 27, 38 ],
        "id_str" : "1721534628",
        "id" : 1721534628
      }, {
        "name" : "Diane Bartlett",
        "screen_name" : "dianebartlett99",
        "indices" : [ 39, 55 ],
        "id_str" : "1715274199",
        "id" : 1715274199
      }, {
        "name" : "Sylvia",
        "screen_name" : "Love4AnimalsNL",
        "indices" : [ 56, 71 ],
        "id_str" : "1573044258",
        "id" : 1573044258
      }, {
        "name" : "Sharon Hoole",
        "screen_name" : "SharonHoole",
        "indices" : [ 72, 84 ],
        "id_str" : "1463611489",
        "id" : 1463611489
      }, {
        "name" : "Nic Vegan",
        "screen_name" : "nicnak40",
        "indices" : [ 85, 94 ],
        "id_str" : "1185165626",
        "id" : 1185165626
      }, {
        "name" : "peter burton",
        "screen_name" : "peteswildlife",
        "indices" : [ 95, 109 ],
        "id_str" : "1183947482",
        "id" : 1183947482
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisadeemo\/status\/655073784941162496\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/LtPCw58xd6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdKIVmWcAAIFm_.jpg",
        "id_str" : "655073777903104000",
        "id" : 655073777903104000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdKIVmWcAAIFm_.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 719
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 719
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1068,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LtPCw58xd6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655073784941162496",
    "text" : "@moel_bryn  @jacqueduncalf @LillMagill @dianebartlett99 @Love4AnimalsNL @SharonHoole @nicnak40 @peteswildlife TYVM x http:\/\/t.co\/LtPCw58xd6",
    "id" : 655073784941162496,
    "created_at" : "2015-10-16 17:32:15 +0000",
    "user" : {
      "name" : "Lisadeemo",
      "screen_name" : "lisadeemo",
      "protected" : false,
      "id_str" : "1219481202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793501385778196480\/NkusAAJD_normal.jpg",
      "id" : 1219481202,
      "verified" : false
    }
  },
  "id" : 655078403654230016,
  "created_at" : "2015-10-16 17:50:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/655075738291433472\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Gi3scUbPxZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdL6S2WoAA_PBA.jpg",
      "id_str" : "655075735670005760",
      "id" : 655075735670005760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdL6S2WoAA_PBA.jpg",
      "sizes" : [ {
        "h" : 688,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/Gi3scUbPxZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655077694460305408",
  "text" : "RT @CUMALi_YILDIZ: Zen........by Antonio Amati http:\/\/t.co\/Gi3scUbPxZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/655075738291433472\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/Gi3scUbPxZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdL6S2WoAA_PBA.jpg",
        "id_str" : "655075735670005760",
        "id" : 655075735670005760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdL6S2WoAA_PBA.jpg",
        "sizes" : [ {
          "h" : 688,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 688,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/Gi3scUbPxZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655075738291433472",
    "text" : "Zen........by Antonio Amati http:\/\/t.co\/Gi3scUbPxZ",
    "id" : 655075738291433472,
    "created_at" : "2015-10-16 17:40:01 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 655077694460305408,
  "created_at" : "2015-10-16 17:47:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 16, 27 ],
      "id_str" : "29442313",
      "id" : 29442313
    }, {
      "name" : "Rob Lowe",
      "screen_name" : "RobLowe",
      "indices" : [ 85, 93 ],
      "id_str" : "121626258",
      "id" : 121626258
    }, {
      "name" : "The Grinder",
      "screen_name" : "TheGrinderFOX",
      "indices" : [ 107, 121 ],
      "id_str" : "3041837322",
      "id" : 3041837322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FeelTheBern",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655072056409767937",
  "text" : "Some people say @SenSanders can't win... but I say \"But what if he could?\" (ref from @RobLowe character on @TheGrinderFOX ) #FeelTheBern",
  "id" : 655072056409767937,
  "created_at" : "2015-10-16 17:25:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard L. Trumka",
      "screen_name" : "RichardTrumka",
      "indices" : [ 3, 17 ],
      "id_str" : "394741838",
      "id" : 394741838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655069827141382148",
  "text" : "RT @RichardTrumka: Hard to argue w\/ science. Science says \"Raising the Minimum Wage Would Make America a Happier Place\" http:\/\/t.co\/67ZHAGs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisingwages",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/67ZHAGssC4",
        "expanded_url" : "http:\/\/ow.ly\/TuChL",
        "display_url" : "ow.ly\/TuChL"
      } ]
    },
    "geo" : { },
    "id_str" : "655062589597208576",
    "text" : "Hard to argue w\/ science. Science says \"Raising the Minimum Wage Would Make America a Happier Place\" http:\/\/t.co\/67ZHAGssC4 #raisingwages",
    "id" : 655062589597208576,
    "created_at" : "2015-10-16 16:47:46 +0000",
    "user" : {
      "name" : "Richard L. Trumka",
      "screen_name" : "RichardTrumka",
      "protected" : false,
      "id_str" : "394741838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796428317385752580\/Fd6iZWaJ_normal.jpg",
      "id" : 394741838,
      "verified" : true
    }
  },
  "id" : 655069827141382148,
  "created_at" : "2015-10-16 17:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "indices" : [ 3, 18 ],
      "id_str" : "25056239",
      "id" : 25056239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodallergies",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655069326429548544",
  "text" : "RT @foodawakenings: In the US, a pack of EpiPens costs $415. In France: $85. How EpiPen became a $1 billion brand #foodallergies http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "foodallergies",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/bhZePCjJud",
        "expanded_url" : "http:\/\/robynobrien.com\/u-s-of-allergies-how-epipen-became-a-billion-dollar-brand\/",
        "display_url" : "robynobrien.com\/u-s-of-allergi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655064786493812737",
    "text" : "In the US, a pack of EpiPens costs $415. In France: $85. How EpiPen became a $1 billion brand #foodallergies http:\/\/t.co\/bhZePCjJud",
    "id" : 655064786493812737,
    "created_at" : "2015-10-16 16:56:30 +0000",
    "user" : {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "protected" : false,
      "id_str" : "25056239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684904916184256512\/Zr_EBvr0_normal.jpg",
      "id" : 25056239,
      "verified" : false
    }
  },
  "id" : 655069326429548544,
  "created_at" : "2015-10-16 17:14:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/655068736240680961\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/6kw6EUrb5n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdFitHXIAE_m6R.jpg",
      "id_str" : "655068733334036481",
      "id" : 655068733334036481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdFitHXIAE_m6R.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 214
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 214
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 214
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 214
      } ],
      "display_url" : "pic.twitter.com\/6kw6EUrb5n"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/0MlhMRZvEj",
      "expanded_url" : "https:\/\/www.etsy.com\/market\/adult_coloring?ref=l2&_ts=1445015531",
      "display_url" : "etsy.com\/market\/adult_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655068736240680961",
  "text" : "Popular items for adult coloring on Etsy https:\/\/t.co\/0MlhMRZvEj http:\/\/t.co\/6kw6EUrb5n",
  "id" : 655068736240680961,
  "created_at" : "2015-10-16 17:12:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 0, 9 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655065290812870657",
  "geo" : { },
  "id_str" : "655068551116693504",
  "in_reply_to_user_id" : 889536330,
  "text" : "@rm123077 awesome catch!",
  "id" : 655068551116693504,
  "in_reply_to_status_id" : 655065290812870657,
  "created_at" : "2015-10-16 17:11:27 +0000",
  "in_reply_to_screen_name" : "rm123077",
  "in_reply_to_user_id_str" : "889536330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655068383336120320",
  "text" : "RT @rm123077: Love seeing the Sharp-tailed Grouse on our farm! And when they fly to the top of a tree, easy to get a photo. :) http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/655065290812870657\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/dcdTWQzFxr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdCYerU8AAzUnQ.jpg",
        "id_str" : "655065259124781056",
        "id" : 655065259124781056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdCYerU8AAzUnQ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dcdTWQzFxr"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/655065290812870657\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/dcdTWQzFxr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdCYmtUcAAzWG_.jpg",
        "id_str" : "655065261280620544",
        "id" : 655065261280620544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdCYmtUcAAzWG_.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dcdTWQzFxr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655065290812870657",
    "text" : "Love seeing the Sharp-tailed Grouse on our farm! And when they fly to the top of a tree, easy to get a photo. :) http:\/\/t.co\/dcdTWQzFxr",
    "id" : 655065290812870657,
    "created_at" : "2015-10-16 16:58:30 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 655068383336120320,
  "created_at" : "2015-10-16 17:10:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Davis Roth",
      "screen_name" : "SurlyAmy",
      "indices" : [ 3, 12 ],
      "id_str" : "20731652",
      "id" : 20731652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/GhE7350nSN",
      "expanded_url" : "https:\/\/www.etsy.com\/shop\/surly?section_id=11514575",
      "display_url" : "etsy.com\/shop\/surly?sec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655068195057967104",
  "text" : "RT @SurlyAmy: Get 10% off all of my coloring posters plus free markers. Use code BOOSTER shop link: https:\/\/t.co\/GhE7350nSN http:\/\/t.co\/xHu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SurlyAmy\/status\/652205648210472960\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/xHuGaPomm1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0ZiitUEAEibg7.jpg",
        "id_str" : "652205602261700609",
        "id" : 652205602261700609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0ZiitUEAEibg7.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xHuGaPomm1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/GhE7350nSN",
        "expanded_url" : "https:\/\/www.etsy.com\/shop\/surly?section_id=11514575",
        "display_url" : "etsy.com\/shop\/surly?sec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652205648210472960",
    "text" : "Get 10% off all of my coloring posters plus free markers. Use code BOOSTER shop link: https:\/\/t.co\/GhE7350nSN http:\/\/t.co\/xHuGaPomm1",
    "id" : 652205648210472960,
    "created_at" : "2015-10-08 19:35:18 +0000",
    "user" : {
      "name" : "Amy Davis Roth",
      "screen_name" : "SurlyAmy",
      "protected" : false,
      "id_str" : "20731652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762361735785218048\/1pMgqxuy_normal.jpg",
      "id" : 20731652,
      "verified" : true
    }
  },
  "id" : 655068195057967104,
  "created_at" : "2015-10-16 17:10:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/8aROq00JJl",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/654877498501636096",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655058113427611648",
  "text" : "nice https:\/\/t.co\/8aROq00JJl",
  "id" : 655058113427611648,
  "created_at" : "2015-10-16 16:29:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "feedly",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/iNTQduH45d",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/4a6ea962e01300\/37165?app_id=339",
      "display_url" : "producthunt.com\/r\/4a6ea962e013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655050914395496448",
  "text" : "JAWNS Notebook + Wallet \u2014 Thin + light 100% recyclable wallet + notebook https:\/\/t.co\/iNTQduH45d #tech #feedly",
  "id" : 655050914395496448,
  "created_at" : "2015-10-16 16:01:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 3, 15 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/654828620964327424\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/h2C7JRrnMp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRZrKSfXIAAoNGT.png",
      "id_str" : "654828620335226880",
      "id" : 654828620335226880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRZrKSfXIAAoNGT.png",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/h2C7JRrnMp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Vu6VFLw49n",
      "expanded_url" : "http:\/\/huff.to\/1VVP5qo",
      "display_url" : "huff.to\/1VVP5qo"
    } ]
  },
  "geo" : { },
  "id_str" : "654834323200286720",
  "text" : "RT @HuffPostPol: An unarmed teen flashed his brights at a cop and ended up dead http:\/\/t.co\/Vu6VFLw49n http:\/\/t.co\/h2C7JRrnMp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/654828620964327424\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/h2C7JRrnMp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRZrKSfXIAAoNGT.png",
        "id_str" : "654828620335226880",
        "id" : 654828620335226880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRZrKSfXIAAoNGT.png",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/h2C7JRrnMp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Vu6VFLw49n",
        "expanded_url" : "http:\/\/huff.to\/1VVP5qo",
        "display_url" : "huff.to\/1VVP5qo"
      } ]
    },
    "geo" : { },
    "id_str" : "654828620964327424",
    "text" : "An unarmed teen flashed his brights at a cop and ended up dead http:\/\/t.co\/Vu6VFLw49n http:\/\/t.co\/h2C7JRrnMp",
    "id" : 654828620964327424,
    "created_at" : "2015-10-16 01:18:04 +0000",
    "user" : {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "protected" : false,
      "id_str" : "15458694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696718733721542656\/2lsNdbhH_normal.png",
      "id" : 15458694,
      "verified" : true
    }
  },
  "id" : 654834323200286720,
  "created_at" : "2015-10-16 01:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654814825562836992",
  "geo" : { },
  "id_str" : "654818602722324481",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe it certainly has been for you... ((hugs))",
  "id" : 654818602722324481,
  "in_reply_to_status_id" : 654814825562836992,
  "created_at" : "2015-10-16 00:38:15 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/FLMrrJzzMJ",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/AskReddit\/comments\/3nyru1\/serious_soldiers_of_reddit_whove_fought_in\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654791822506528768",
  "text" : "\"I realized in that moment how wrong I was about everything.\" Soldiers of Reddit who've fought in Afghanistan https:\/\/t.co\/FLMrrJzzMJ",
  "id" : 654791822506528768,
  "created_at" : "2015-10-15 22:51:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654765361795981312",
  "geo" : { },
  "id_str" : "654786593950035970",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH amazing read. (ive been reading the comments on the reddit source.)",
  "id" : 654786593950035970,
  "in_reply_to_status_id" : 654765361795981312,
  "created_at" : "2015-10-15 22:31:04 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/ETYMbaqueR",
      "expanded_url" : "https:\/\/twitter.com\/pittgriffin\/status\/654764593269501953",
      "display_url" : "twitter.com\/pittgriffin\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654782078106505216",
  "text" : "RT @SangyeH: Truly a must read. https:\/\/t.co\/ETYMbaqueR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/ETYMbaqueR",
        "expanded_url" : "https:\/\/twitter.com\/pittgriffin\/status\/654764593269501953",
        "display_url" : "twitter.com\/pittgriffin\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654765361795981312",
    "text" : "Truly a must read. https:\/\/t.co\/ETYMbaqueR",
    "id" : 654765361795981312,
    "created_at" : "2015-10-15 21:06:41 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 654782078106505216,
  "created_at" : "2015-10-15 22:13:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654743683321888768",
  "text" : "RT @dhammagirl: Sometimes, just sit back from a problem, observe it and allow others a view.\nAnswers that don't come from within may come f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "One",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654697146743062528",
    "text" : "Sometimes, just sit back from a problem, observe it and allow others a view.\nAnswers that don't come from within may come from others.\n\n#One",
    "id" : 654697146743062528,
    "created_at" : "2015-10-15 16:35:38 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 654743683321888768,
  "created_at" : "2015-10-15 19:40:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/0WQwO8y62H",
      "expanded_url" : "http:\/\/FineArtAmerica.com",
      "display_url" : "FineArtAmerica.com"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jQMmvVAmtC",
      "expanded_url" : "http:\/\/fineartamerica.com\/saleannouncement.html?id=49df066de5fe629916259128cdbf7de8",
      "display_url" : "fineartamerica.com\/saleannounceme\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654696551508369409",
  "text" : "beautiful butterfly photo! &gt; Dwayne Reaves sold a Throw Pillow 16\" x 16\" on http:\/\/t.co\/0WQwO8y62H! http:\/\/t.co\/jQMmvVAmtC",
  "id" : 654696551508369409,
  "created_at" : "2015-10-15 16:33:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654695895326310402",
  "text" : "RT @UnseelieMe: So when you write an article saying bullying is a good thing &amp; helps in personal growth for the bullied, I call bullshit. R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654693268014301184",
    "text" : "So when you write an article saying bullying is a good thing &amp; helps in personal growth for the bullied, I call bullshit. Rant over.",
    "id" : 654693268014301184,
    "created_at" : "2015-10-15 16:20:13 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 654695895326310402,
  "created_at" : "2015-10-15 16:30:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654689984692121600",
  "geo" : { },
  "id_str" : "654695578010423297",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe \"He needed to learn to be normal.\" &lt; this makes me sooo angry!",
  "id" : 654695578010423297,
  "in_reply_to_status_id" : 654689984692121600,
  "created_at" : "2015-10-15 16:29:24 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654694854476238849",
  "text" : "RT @UnseelieMe: Hey! Lets tell kids w\/autism that theyre being bullied bcs of their behavior. Thats a real teachable moment. Wooo. \nFuck. T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654685443691184132",
    "text" : "Hey! Lets tell kids w\/autism that theyre being bullied bcs of their behavior. Thats a real teachable moment. Wooo. \nFuck. That. Woman.",
    "id" : 654685443691184132,
    "created_at" : "2015-10-15 15:49:07 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 654694854476238849,
  "created_at" : "2015-10-15 16:26:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IrelandsFarmers",
      "screen_name" : "IrelandsFarmers",
      "indices" : [ 3, 19 ],
      "id_str" : "1428104798",
      "id" : 1428104798
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IrelandsFarmers\/status\/654316338954006528\/video\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ErRyXC5olg",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/654316118115491841\/pu\/img\/jrp-bxjgKqeC4o9m.jpg",
      "id_str" : "654316118115491841",
      "id" : 654316118115491841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/654316118115491841\/pu\/img\/jrp-bxjgKqeC4o9m.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ErRyXC5olg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654694469728514049",
  "text" : "RT @IrelandsFarmers: She's right, it's not cold enough for a hat yet http:\/\/t.co\/ErRyXC5olg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IrelandsFarmers\/status\/654316338954006528\/video\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/ErRyXC5olg",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/654316118115491841\/pu\/img\/jrp-bxjgKqeC4o9m.jpg",
        "id_str" : "654316118115491841",
        "id" : 654316118115491841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/654316118115491841\/pu\/img\/jrp-bxjgKqeC4o9m.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ErRyXC5olg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654316338954006528",
    "text" : "She's right, it's not cold enough for a hat yet http:\/\/t.co\/ErRyXC5olg",
    "id" : 654316338954006528,
    "created_at" : "2015-10-14 15:22:26 +0000",
    "user" : {
      "name" : "IrelandsFarmers",
      "screen_name" : "IrelandsFarmers",
      "protected" : false,
      "id_str" : "1428104798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785206273277059072\/KpC9KqaW_normal.jpg",
      "id" : 1428104798,
      "verified" : false
    }
  },
  "id" : 654694469728514049,
  "created_at" : "2015-10-15 16:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/EJjKSc7CcR",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/9\/4\/9252489\/anti-vaxx-wife",
      "display_url" : "vox.com\/2015\/9\/4\/92524\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654688189311922176",
  "text" : "good post &gt; I married an anti-vaxxer. Here's what I learned trying to convince her to change. http:\/\/t.co\/EJjKSc7CcR",
  "id" : 654688189311922176,
  "created_at" : "2015-10-15 16:00:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/qOHVHw4bFd",
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/654558048950878208",
      "display_url" : "twitter.com\/ErinEFarley\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654665731385069568",
  "text" : "cute! https:\/\/t.co\/qOHVHw4bFd",
  "id" : 654665731385069568,
  "created_at" : "2015-10-15 14:30:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654664402826690561",
  "geo" : { },
  "id_str" : "654665404309110788",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time lolol",
  "id" : 654665404309110788,
  "in_reply_to_status_id" : 654664402826690561,
  "created_at" : "2015-10-15 14:29:30 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654661618362507265",
  "geo" : { },
  "id_str" : "654665125949890561",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley me, too. always makes me cry.",
  "id" : 654665125949890561,
  "in_reply_to_status_id" : 654661618362507265,
  "created_at" : "2015-10-15 14:28:23 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cowboy Antifascist",
      "screen_name" : "MPAVictoria",
      "indices" : [ 3, 15 ],
      "id_str" : "1056832406",
      "id" : 1056832406
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BREAKING",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "healthcare",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "USpoli",
      "indices" : [ 108, 115 ]
    }, {
      "text" : "singlepayer",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/dDpy2O9oqi",
      "expanded_url" : "http:\/\/www.motherjones.com\/kevin-drum\/2015\/10\/high-deductible-health-plans-dont-seem-encourage-price-shopping",
      "display_url" : "motherjones.com\/kevin-drum\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654463659276677121",
  "text" : "RT @MPAVictoria: #BREAKING Purchasing #healthcare isn't like buying a tv or a car!\n\nhttp:\/\/t.co\/dDpy2O9oqi\n\n#USpoli \n#singlepayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BREAKING",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "healthcare",
        "indices" : [ 21, 32 ]
      }, {
        "text" : "USpoli",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/dDpy2O9oqi",
        "expanded_url" : "http:\/\/www.motherjones.com\/kevin-drum\/2015\/10\/high-deductible-health-plans-dont-seem-encourage-price-shopping",
        "display_url" : "motherjones.com\/kevin-drum\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654400931367374849",
    "text" : "#BREAKING Purchasing #healthcare isn't like buying a tv or a car!\n\nhttp:\/\/t.co\/dDpy2O9oqi\n\n#USpoli \n#singlepayer",
    "id" : 654400931367374849,
    "created_at" : "2015-10-14 20:58:34 +0000",
    "user" : {
      "name" : "Cowboy Antifascist",
      "screen_name" : "MPAVictoria",
      "protected" : false,
      "id_str" : "1056832406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781868360376184833\/2K8dKKF4_normal.jpg",
      "id" : 1056832406,
      "verified" : false
    }
  },
  "id" : 654463659276677121,
  "created_at" : "2015-10-15 01:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bison",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "Montana",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654462939047591936",
  "text" : "RT @Interior: Things you do when you think no one is looking ... #Bison don't care at National Bison Range in #Montana https:\/\/t.co\/U2M7uj0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bison",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "Montana",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/U2M7uj044c",
        "expanded_url" : "https:\/\/vine.co\/v\/eEXEDBIBXVu",
        "display_url" : "vine.co\/v\/eEXEDBIBXVu"
      } ]
    },
    "geo" : { },
    "id_str" : "654427947609231360",
    "text" : "Things you do when you think no one is looking ... #Bison don't care at National Bison Range in #Montana https:\/\/t.co\/U2M7uj044c",
    "id" : 654427947609231360,
    "created_at" : "2015-10-14 22:45:56 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 654462939047591936,
  "created_at" : "2015-10-15 01:04:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0950",
      "screen_name" : "LSDTribe",
      "indices" : [ 3, 12 ],
      "id_str" : "546332225",
      "id" : 546332225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654454974949289984",
  "text" : "RT @LSDTribe: You know you are doing well when you lose the interest of looking back",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654082946870067205",
    "text" : "You know you are doing well when you lose the interest of looking back",
    "id" : 654082946870067205,
    "created_at" : "2015-10-13 23:55:01 +0000",
    "user" : {
      "name" : "\u0950",
      "screen_name" : "LSDTribe",
      "protected" : false,
      "id_str" : "546332225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647034704361750528\/uTs3hvlU_normal.jpg",
      "id" : 546332225,
      "verified" : false
    }
  },
  "id" : 654454974949289984,
  "created_at" : "2015-10-15 00:33:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654419023120232448",
  "text" : "its a strange sadness when you find out a HS classmate has passed. rip ted. #1984",
  "id" : 654419023120232448,
  "created_at" : "2015-10-14 22:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/20SWOHtLGD",
      "expanded_url" : "https:\/\/twitter.com\/jeffrey_ventre\/status\/654369735149142016",
      "display_url" : "twitter.com\/jeffrey_ventre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654400789377589248",
  "text" : "RT @oceanshaman: . https:\/\/t.co\/20SWOHtLGD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 2, 25 ],
        "url" : "https:\/\/t.co\/20SWOHtLGD",
        "expanded_url" : "https:\/\/twitter.com\/jeffrey_ventre\/status\/654369735149142016",
        "display_url" : "twitter.com\/jeffrey_ventre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654400267593613312",
    "text" : ". https:\/\/t.co\/20SWOHtLGD",
    "id" : 654400267593613312,
    "created_at" : "2015-10-14 20:55:56 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 654400789377589248,
  "created_at" : "2015-10-14 20:58:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/c6fEPoVJ7f",
      "expanded_url" : "https:\/\/twitter.com\/LOLGOP\/status\/654312616538587136",
      "display_url" : "twitter.com\/LOLGOP\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654322323655368704",
  "text" : "interesting read... https:\/\/t.co\/c6fEPoVJ7f",
  "id" : 654322323655368704,
  "created_at" : "2015-10-14 15:46:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654317027650334720",
  "text" : "RT @AllOnMedicare: It is impossible to \"shop\" for health care in America. \n\nCall doc and they are NOT HELPFUL w\/ prices.\n\nhttp:\/\/t.co\/td2or\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/td2orTuRb3",
        "expanded_url" : "http:\/\/www.vox.com\/2015\/10\/14\/9528441\/high-deductible-insurance-kolstad",
        "display_url" : "vox.com\/2015\/10\/14\/952\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654315413522640896",
    "text" : "It is impossible to \"shop\" for health care in America. \n\nCall doc and they are NOT HELPFUL w\/ prices.\n\nhttp:\/\/t.co\/td2orTuRb3\n\n#SinglePayer",
    "id" : 654315413522640896,
    "created_at" : "2015-10-14 15:18:45 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 654317027650334720,
  "created_at" : "2015-10-14 15:25:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654315985613254656",
  "text" : "across the sky, a lone goose honking. made me sad.",
  "id" : 654315985613254656,
  "created_at" : "2015-10-14 15:21:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/Vb5IsfvPZD",
      "expanded_url" : "https:\/\/twitter.com\/LynleyWyeth\/status\/654213871217995776",
      "display_url" : "twitter.com\/LynleyWyeth\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654306558596251648",
  "text" : "awww https:\/\/t.co\/Vb5IsfvPZD",
  "id" : 654306558596251648,
  "created_at" : "2015-10-14 14:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0950",
      "screen_name" : "SPIRITHUEL",
      "indices" : [ 3, 14 ],
      "id_str" : "2852564233",
      "id" : 2852564233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654305323377889280",
  "text" : "RT @SPIRITHUEL: Inhale blessings, exhale gratitude.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654303731178037248",
    "text" : "Inhale blessings, exhale gratitude.",
    "id" : 654303731178037248,
    "created_at" : "2015-10-14 14:32:20 +0000",
    "user" : {
      "name" : "\u0950",
      "screen_name" : "SPIRITHUEL",
      "protected" : false,
      "id_str" : "2852564233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686023408715337728\/IQPWPx8g_normal.png",
      "id" : 2852564233,
      "verified" : false
    }
  },
  "id" : 654305323377889280,
  "created_at" : "2015-10-14 14:38:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/654214754911809536\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/vxeYKCmQuy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRQ82NuWoAAJrgZ.jpg",
      "id_str" : "654214747970248704",
      "id" : 654214747970248704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRQ82NuWoAAJrgZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vxeYKCmQuy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654292996951801856",
  "text" : "RT @5thdimdreamz: http:\/\/t.co\/vxeYKCmQuy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/654214754911809536\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/vxeYKCmQuy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRQ82NuWoAAJrgZ.jpg",
        "id_str" : "654214747970248704",
        "id" : 654214747970248704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRQ82NuWoAAJrgZ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vxeYKCmQuy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654214754911809536",
    "text" : "http:\/\/t.co\/vxeYKCmQuy",
    "id" : 654214754911809536,
    "created_at" : "2015-10-14 08:38:46 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 654292996951801856,
  "created_at" : "2015-10-14 13:49:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conscious Crusader",
      "screen_name" : "TranscendentEye",
      "indices" : [ 3, 19 ],
      "id_str" : "1521771972",
      "id" : 1521771972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654291547991736322",
  "text" : "RT @TranscendentEye: I'm a generally quiet person. I spend more time observing than speaking",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654118401368043521",
    "text" : "I'm a generally quiet person. I spend more time observing than speaking",
    "id" : 654118401368043521,
    "created_at" : "2015-10-14 02:15:54 +0000",
    "user" : {
      "name" : "Conscious Crusader",
      "screen_name" : "TranscendentEye",
      "protected" : false,
      "id_str" : "1521771972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657647921303678976\/2dUobSur_normal.png",
      "id" : 1521771972,
      "verified" : false
    }
  },
  "id" : 654291547991736322,
  "created_at" : "2015-10-14 13:43:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/654123457035280385\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/pvLkXCQxHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRPp0J-WgAAYntw.jpg",
      "id_str" : "654123453138763776",
      "id" : 654123453138763776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRPp0J-WgAAYntw.jpg",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/pvLkXCQxHb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654290697714028545",
  "text" : "RT @5thdimdreamz: http:\/\/t.co\/pvLkXCQxHb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/654123457035280385\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/pvLkXCQxHb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRPp0J-WgAAYntw.jpg",
        "id_str" : "654123453138763776",
        "id" : 654123453138763776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRPp0J-WgAAYntw.jpg",
        "sizes" : [ {
          "h" : 363,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/pvLkXCQxHb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654123457035280385",
    "text" : "http:\/\/t.co\/pvLkXCQxHb",
    "id" : 654123457035280385,
    "created_at" : "2015-10-14 02:35:59 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 654290697714028545,
  "created_at" : "2015-10-14 13:40:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/xffx8IWXHR",
      "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/nova\/next\/body\/consciousness\/",
      "display_url" : "pbs.org\/wgbh\/nova\/next\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654287858228928512",
  "text" : "RT @onealexharms: Interesting post about detecting and measuring consciousness. http:\/\/t.co\/xffx8IWXHR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/xffx8IWXHR",
        "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/nova\/next\/body\/consciousness\/",
        "display_url" : "pbs.org\/wgbh\/nova\/next\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654283016517353472",
    "text" : "Interesting post about detecting and measuring consciousness. http:\/\/t.co\/xffx8IWXHR",
    "id" : 654283016517353472,
    "created_at" : "2015-10-14 13:10:01 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 654287858228928512,
  "created_at" : "2015-10-14 13:29:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IncrediblyRich",
      "screen_name" : "IncrediblyRich",
      "indices" : [ 3, 18 ],
      "id_str" : "29262592",
      "id" : 29262592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654118583413436417",
  "text" : "RT @IncrediblyRich: \"Hail to the guardians of the watchtowers of the North, by the powers of mother and earth, hear us! We invoke thee!\" ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IncrediblyRich\/status\/653884962941353984\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/WHEZBSJXkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRMQ59-WcAE6SKI.jpg",
        "id_str" : "653884958973521921",
        "id" : 653884958973521921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRMQ59-WcAE6SKI.jpg",
        "sizes" : [ {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 570
        } ],
        "display_url" : "pic.twitter.com\/WHEZBSJXkM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653884962941353984",
    "text" : "\"Hail to the guardians of the watchtowers of the North, by the powers of mother and earth, hear us! We invoke thee!\" http:\/\/t.co\/WHEZBSJXkM",
    "id" : 653884962941353984,
    "created_at" : "2015-10-13 10:48:18 +0000",
    "user" : {
      "name" : "IncrediblyRich",
      "screen_name" : "IncrediblyRich",
      "protected" : false,
      "id_str" : "29262592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767341928140697600\/1nDgkEP8_normal.jpg",
      "id" : 29262592,
      "verified" : false
    }
  },
  "id" : 654118583413436417,
  "created_at" : "2015-10-14 02:16:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 3, 16 ],
      "id_str" : "43298413",
      "id" : 43298413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DemDebate",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654111837533937664",
  "text" : "RT @NathanDunbar: FUCK YEAH BERNIE!!!!!! #DemDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemDebate",
        "indices" : [ 23, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654111709108563968",
    "text" : "FUCK YEAH BERNIE!!!!!! #DemDebate",
    "id" : 654111709108563968,
    "created_at" : "2015-10-14 01:49:18 +0000",
    "user" : {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "protected" : false,
      "id_str" : "43298413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683069342842503169\/t-eR15ya_normal.jpg",
      "id" : 43298413,
      "verified" : false
    }
  },
  "id" : 654111837533937664,
  "created_at" : "2015-10-14 01:49:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EJ Dionne",
      "screen_name" : "EJDionne",
      "indices" : [ 3, 12 ],
      "id_str" : "453319164",
      "id" : 453319164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654110849217523716",
  "text" : "RT @EJDionne: Just got this text from a friend:\n\"Talking about democratic socialism in the middle of a casino in Vegas. Gotta love it!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654105557897465856",
    "text" : "Just got this text from a friend:\n\"Talking about democratic socialism in the middle of a casino in Vegas. Gotta love it!\"",
    "id" : 654105557897465856,
    "created_at" : "2015-10-14 01:24:52 +0000",
    "user" : {
      "name" : "EJ Dionne",
      "screen_name" : "EJDionne",
      "protected" : false,
      "id_str" : "453319164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676849075652861952\/X-f5kcFx_normal.jpg",
      "id" : 453319164,
      "verified" : true
    }
  },
  "id" : 654110849217523716,
  "created_at" : "2015-10-14 01:45:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SangyeH\/status\/654059325355335680\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/5CZ1R3ekdw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CROve72WEAYTP51.jpg",
      "id_str" : "654059316895420422",
      "id" : 654059316895420422,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CROve72WEAYTP51.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5CZ1R3ekdw"
    } ],
    "hashtags" : [ {
      "text" : "FeelTheBern",
      "indices" : [ 36, 48 ]
    }, {
      "text" : "GoBernie",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654061596063477760",
  "text" : "RT @SangyeH: Debate Night Reminder\n\n#FeelTheBern #GoBernie http:\/\/t.co\/5CZ1R3ekdw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SangyeH\/status\/654059325355335680\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/5CZ1R3ekdw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CROve72WEAYTP51.jpg",
        "id_str" : "654059316895420422",
        "id" : 654059316895420422,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CROve72WEAYTP51.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5CZ1R3ekdw"
      } ],
      "hashtags" : [ {
        "text" : "FeelTheBern",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "GoBernie",
        "indices" : [ 36, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654059325355335680",
    "text" : "Debate Night Reminder\n\n#FeelTheBern #GoBernie http:\/\/t.co\/5CZ1R3ekdw",
    "id" : 654059325355335680,
    "created_at" : "2015-10-13 22:21:09 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 654061596063477760,
  "created_at" : "2015-10-13 22:30:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654044224116162561",
  "geo" : { },
  "id_str" : "654046382802780160",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides ewwwwwwwww!! ((goestofindsomethingcutetolookat))",
  "id" : 654046382802780160,
  "in_reply_to_status_id" : 654044224116162561,
  "created_at" : "2015-10-13 21:29:43 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653950709537349632",
  "geo" : { },
  "id_str" : "653985554493743104",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe whoa..",
  "id" : 653985554493743104,
  "in_reply_to_status_id" : 653950709537349632,
  "created_at" : "2015-10-13 17:28:01 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/UT7LvKyAHn",
      "expanded_url" : "https:\/\/www.healthinsurance.org\/blog\/2015\/10\/06\/the-casino-effect-on-your-health-insurance-rates\/",
      "display_url" : "healthinsurance.org\/blog\/2015\/10\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653980329267621888",
  "text" : "RT @AllOnMedicare: Health insurers are like casino owners: the house always wins, the guest always loses. https:\/\/t.co\/UT7LvKyAHn #SinglePa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 111, 123 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/UT7LvKyAHn",
        "expanded_url" : "https:\/\/www.healthinsurance.org\/blog\/2015\/10\/06\/the-casino-effect-on-your-health-insurance-rates\/",
        "display_url" : "healthinsurance.org\/blog\/2015\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653979232473862144",
    "text" : "Health insurers are like casino owners: the house always wins, the guest always loses. https:\/\/t.co\/UT7LvKyAHn #SinglePayer #MedicareForAll",
    "id" : 653979232473862144,
    "created_at" : "2015-10-13 17:02:54 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 653980329267621888,
  "created_at" : "2015-10-13 17:07:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653964862306033665",
  "text" : "i wonder is it on back order everywhere? would another pharmacy have it? I dont like not knowing when it gets back in stock... ugh.",
  "id" : 653964862306033665,
  "created_at" : "2015-10-13 16:05:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makesmenervous",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653964184724578304",
  "text" : "at my cvs venlaflaxine is on back order?? good thing I have extra pills!! they dont know when it will come in... #makesmenervous",
  "id" : 653964184724578304,
  "created_at" : "2015-10-13 16:03:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Elverojaguar\/status\/628458368521400320\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/o69i2dIOP5",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CLi7jjYWgAALneM.png",
      "id_str" : "628458367485378560",
      "id" : 628458367485378560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CLi7jjYWgAALneM.png",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/o69i2dIOP5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653955118451281920",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/o69i2dIOP5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Elverojaguar\/status\/628458368521400320\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/o69i2dIOP5",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CLi7jjYWgAALneM.png",
        "id_str" : "628458367485378560",
        "id" : 628458367485378560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CLi7jjYWgAALneM.png",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/o69i2dIOP5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653953388254769152",
    "text" : "http:\/\/t.co\/o69i2dIOP5",
    "id" : 653953388254769152,
    "created_at" : "2015-10-13 15:20:12 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 653955118451281920,
  "created_at" : "2015-10-13 15:27:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crown Publishing",
      "screen_name" : "CrownPublishing",
      "indices" : [ 3, 19 ],
      "id_str" : "26554371",
      "id" : 26554371
    }, {
      "name" : "Penguin Random House",
      "screen_name" : "penguinrandom",
      "indices" : [ 25, 39 ],
      "id_str" : "14360757",
      "id" : 14360757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nextread",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xmjyIXCFbC",
      "expanded_url" : "http:\/\/bit.ly\/next-read",
      "display_url" : "bit.ly\/next-read"
    } ]
  },
  "geo" : { },
  "id_str" : "653955102231937024",
  "text" : "RT @CrownPublishing: Let @penguinrandom recommend your #nextread &amp; enter to win a windfall of books! http:\/\/t.co\/xmjyIXCFbC http:\/\/t.co\/s0P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Penguin Random House",
        "screen_name" : "penguinrandom",
        "indices" : [ 4, 18 ],
        "id_str" : "14360757",
        "id" : 14360757
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CrownPublishing\/status\/653953404146987009\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/s0Pz0kG806",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRNPJiuUAAE31iG.png",
        "id_str" : "653953396257325057",
        "id" : 653953396257325057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRNPJiuUAAE31iG.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/s0Pz0kG806"
      } ],
      "hashtags" : [ {
        "text" : "nextread",
        "indices" : [ 34, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/xmjyIXCFbC",
        "expanded_url" : "http:\/\/bit.ly\/next-read",
        "display_url" : "bit.ly\/next-read"
      } ]
    },
    "geo" : { },
    "id_str" : "653953404146987009",
    "text" : "Let @penguinrandom recommend your #nextread &amp; enter to win a windfall of books! http:\/\/t.co\/xmjyIXCFbC http:\/\/t.co\/s0Pz0kG806",
    "id" : 653953404146987009,
    "created_at" : "2015-10-13 15:20:16 +0000",
    "user" : {
      "name" : "Crown Publishing",
      "screen_name" : "CrownPublishing",
      "protected" : false,
      "id_str" : "26554371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711976556080582657\/Y2oumJ6d_normal.jpg",
      "id" : 26554371,
      "verified" : true
    }
  },
  "id" : 653955102231937024,
  "created_at" : "2015-10-13 15:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "indices" : [ 3, 16 ],
      "id_str" : "255681332",
      "id" : 255681332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/653850783901949952\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/FvV6a9V0Gc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRLx0n_WcAApPi2.jpg",
      "id_str" : "653850782312329216",
      "id" : 653850782312329216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRLx0n_WcAApPi2.jpg",
      "sizes" : [ {
        "h" : 687,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FvV6a9V0Gc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653951323935797248",
  "text" : "RT @SouthYeoEast: \"You move first\"\r\"no, you move first...\"\r\"no, you...\" http:\/\/t.co\/FvV6a9V0Gc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SouthYeoEast\/status\/653850783901949952\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/FvV6a9V0Gc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRLx0n_WcAApPi2.jpg",
        "id_str" : "653850782312329216",
        "id" : 653850782312329216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRLx0n_WcAApPi2.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FvV6a9V0Gc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653850783901949952",
    "text" : "\"You move first\"\r\"no, you move first...\"\r\"no, you...\" http:\/\/t.co\/FvV6a9V0Gc",
    "id" : 653850783901949952,
    "created_at" : "2015-10-13 08:32:29 +0000",
    "user" : {
      "name" : "Farmer Dixon",
      "screen_name" : "SouthYeoEast",
      "protected" : false,
      "id_str" : "255681332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675738411777531904\/xpGSmCmI_normal.jpg",
      "id" : 255681332,
      "verified" : false
    }
  },
  "id" : 653951323935797248,
  "created_at" : "2015-10-13 15:12:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/653951063637262336\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/zgiiKpIns3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRNNBmbW8AAXd6n.jpg",
      "id_str" : "653951060789358592",
      "id" : 653951060789358592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRNNBmbW8AAXd6n.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zgiiKpIns3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/8jbNdNdjAQ",
      "expanded_url" : "http:\/\/thinktheology.co.uk\/blog\/article\/captive_and_the_christian_film_industry?_ts=1444749054#When:07:00:00Z",
      "display_url" : "thinktheology.co.uk\/blog\/article\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653951063637262336",
  "text" : "\u2018Captive\u2019 and the Christian Film Industry | Blog http:\/\/t.co\/8jbNdNdjAQ http:\/\/t.co\/zgiiKpIns3",
  "id" : 653951063637262336,
  "created_at" : "2015-10-13 15:10:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD83 The Internet \uD83E\uDD83",
      "screen_name" : "photosandbacon",
      "indices" : [ 3, 18 ],
      "id_str" : "33160996",
      "id" : 33160996
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/photosandbacon\/status\/653944578479796226\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Wih0KhCId3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRNHIMvVEAAIT2q.jpg",
      "id_str" : "653944577083117568",
      "id" : 653944577083117568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRNHIMvVEAAIT2q.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2400,
        "resize" : "fit",
        "w" : 3546
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wih0KhCId3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653946485281832962",
  "text" : "RT @photosandbacon: http:\/\/t.co\/Wih0KhCId3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/photosandbacon\/status\/653944578479796226\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/Wih0KhCId3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRNHIMvVEAAIT2q.jpg",
        "id_str" : "653944577083117568",
        "id" : 653944577083117568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRNHIMvVEAAIT2q.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2400,
          "resize" : "fit",
          "w" : 3546
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Wih0KhCId3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653944578479796226",
    "text" : "http:\/\/t.co\/Wih0KhCId3",
    "id" : 653944578479796226,
    "created_at" : "2015-10-13 14:45:11 +0000",
    "user" : {
      "name" : "\uD83E\uDD83 The Internet \uD83E\uDD83",
      "screen_name" : "photosandbacon",
      "protected" : false,
      "id_str" : "33160996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800042630709014528\/mSWw-OnS_normal.jpg",
      "id" : 33160996,
      "verified" : false
    }
  },
  "id" : 653946485281832962,
  "created_at" : "2015-10-13 14:52:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ara",
      "screen_name" : "luvvigilante_",
      "indices" : [ 3, 17 ],
      "id_str" : "1249467692",
      "id" : 1249467692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653744109216268288",
  "text" : "RT @luvvigilante_: We spend a lifetime unbecoming what  others have made us or protecting the beauty we've retained. Sometimes both.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653287725022466048",
    "text" : "We spend a lifetime unbecoming what  others have made us or protecting the beauty we've retained. Sometimes both.",
    "id" : 653287725022466048,
    "created_at" : "2015-10-11 19:15:05 +0000",
    "user" : {
      "name" : "Ara",
      "screen_name" : "luvvigilante_",
      "protected" : false,
      "id_str" : "1249467692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795217019717218304\/e9skBidT_normal.jpg",
      "id" : 1249467692,
      "verified" : false
    }
  },
  "id" : 653744109216268288,
  "created_at" : "2015-10-13 01:28:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653743141980348416",
  "text" : "RT @Snowden: If you want to protect your rights, you've got to protect the rights of others. Social justice is common sense.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653708727502151680",
    "text" : "If you want to protect your rights, you've got to protect the rights of others. Social justice is common sense.",
    "id" : 653708727502151680,
    "created_at" : "2015-10-12 23:08:00 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 653743141980348416,
  "created_at" : "2015-10-13 01:24:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/IfO3DW6Vcy",
      "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/emerging-diseases\/200910\/chronic-fatigue-lyme-medically-unexplained-no-more",
      "display_url" : "psychologytoday.com\/blog\/emerging-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653733606091849728",
  "text" : "RT @AlisynGayle: From Chronic Fatigue to Lyme: Medically Unexplained No More | Psychology Today https:\/\/t.co\/IfO3DW6Vcy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/IfO3DW6Vcy",
        "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/emerging-diseases\/200910\/chronic-fatigue-lyme-medically-unexplained-no-more",
        "display_url" : "psychologytoday.com\/blog\/emerging-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653720487667875840",
    "text" : "From Chronic Fatigue to Lyme: Medically Unexplained No More | Psychology Today https:\/\/t.co\/IfO3DW6Vcy",
    "id" : 653720487667875840,
    "created_at" : "2015-10-12 23:54:44 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 653733606091849728,
  "created_at" : "2015-10-13 00:46:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/eOJkrgattk",
      "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/emerging-diseases\/200902\/high-anxiety-neurological-lyme-disease-part-three",
      "display_url" : "psychologytoday.com\/blog\/emerging-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653732718132482048",
  "text" : "RT @AlisynGayle: High Anxiety  (Neurological Lyme Disease, Part Three) | Psychology Today https:\/\/t.co\/eOJkrgattk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/eOJkrgattk",
        "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/emerging-diseases\/200902\/high-anxiety-neurological-lyme-disease-part-three",
        "display_url" : "psychologytoday.com\/blog\/emerging-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653721878884970496",
    "text" : "High Anxiety  (Neurological Lyme Disease, Part Three) | Psychology Today https:\/\/t.co\/eOJkrgattk",
    "id" : 653721878884970496,
    "created_at" : "2015-10-13 00:00:16 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 653732718132482048,
  "created_at" : "2015-10-13 00:43:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653732703204982784",
  "text" : "RT @AlisynGayle: When physicians miss the diagnosis, pts can be stigmatized w\/psychiatric labels (Neurogical Lyme Disease, Part Two)  https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/eXGhN5gv4B",
        "expanded_url" : "https:\/\/www.psychologytoday.com\/blog\/emerging-diseases\/200901\/when-physicians-miss-the-diagnosis-patients-can-be-stigmatized",
        "display_url" : "psychologytoday.com\/blog\/emerging-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653721734370209792",
    "text" : "When physicians miss the diagnosis, pts can be stigmatized w\/psychiatric labels (Neurogical Lyme Disease, Part Two)  https:\/\/t.co\/eXGhN5gv4B",
    "id" : 653721734370209792,
    "created_at" : "2015-10-12 23:59:41 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 653732703204982784,
  "created_at" : "2015-10-13 00:43:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653629387120754690",
  "geo" : { },
  "id_str" : "653704185247072256",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH dear ani-la, prayers sent for all those feeling crappy.",
  "id" : 653704185247072256,
  "in_reply_to_status_id" : 653629387120754690,
  "created_at" : "2015-10-12 22:49:57 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653657521358442496",
  "geo" : { },
  "id_str" : "653703748657774592",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre ((hugs)) (ive got a few lessons still trying to get...)",
  "id" : 653703748657774592,
  "in_reply_to_status_id" : 653657521358442496,
  "created_at" : "2015-10-12 22:48:13 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653631580557176832",
  "geo" : { },
  "id_str" : "653703554562195456",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides feel better soon.",
  "id" : 653703554562195456,
  "in_reply_to_status_id" : 653631580557176832,
  "created_at" : "2015-10-12 22:47:27 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 126, 135 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/GvOPhu9U0h",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2015\/10\/12\/1430894\/-No-police-killing-12-y-o-Tamir-Rice-wasn-t-reasonable-it-was-a-heartless-murder-backed-by-lies",
      "display_url" : "dailykos.com\/story\/2015\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653607355515576321",
  "text" : "No, police killing pre-teen Tamir Rice wasn't reasonable; it was a heartless murder backed by lies http:\/\/t.co\/GvOPhu9U0h via @dailykos",
  "id" : 653607355515576321,
  "created_at" : "2015-10-12 16:25:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/G55ckOhfSU",
      "expanded_url" : "http:\/\/goo.gl\/kSZtRX",
      "display_url" : "goo.gl\/kSZtRX"
    } ]
  },
  "geo" : { },
  "id_str" : "653585492915679232",
  "text" : "RT @dailygalaxy: Image of the Day: \"Black Hole Observed With a Power Output 100 X's the Milky Way's\" (ESO) http:\/\/t.co\/G55ckOhfSU http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/653585036483039232\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/CpmjqbIbqv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIAIFXUsAADimX.jpg",
        "id_str" : "653585034801098752",
        "id" : 653585034801098752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIAIFXUsAADimX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 684
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 684
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CpmjqbIbqv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/G55ckOhfSU",
        "expanded_url" : "http:\/\/goo.gl\/kSZtRX",
        "display_url" : "goo.gl\/kSZtRX"
      } ]
    },
    "geo" : { },
    "id_str" : "653585036483039232",
    "text" : "Image of the Day: \"Black Hole Observed With a Power Output 100 X's the Milky Way's\" (ESO) http:\/\/t.co\/G55ckOhfSU http:\/\/t.co\/CpmjqbIbqv",
    "id" : 653585036483039232,
    "created_at" : "2015-10-12 14:56:30 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 653585492915679232,
  "created_at" : "2015-10-12 14:58:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653365796148613120",
  "geo" : { },
  "id_str" : "653375494965055488",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time glad you're feeling better : )",
  "id" : 653375494965055488,
  "in_reply_to_status_id" : 653365796148613120,
  "created_at" : "2015-10-12 01:03:51 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CNN",
      "indices" : [ 76, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653349006421180416",
  "text" : "RT @oceanshaman: NOTE THIS!!  Lots of  complaints from those who don't have #CNN Cable tier on their tvs! STREAMING LIVE TUESDAY! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CNN",
        "indices" : [ 59, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/jfSKQfP96w",
        "expanded_url" : "https:\/\/twitter.com\/theBerniePost\/status\/653341912175243264",
        "display_url" : "twitter.com\/theBerniePost\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653343189479387136",
    "text" : "NOTE THIS!!  Lots of  complaints from those who don't have #CNN Cable tier on their tvs! STREAMING LIVE TUESDAY! https:\/\/t.co\/jfSKQfP96w",
    "id" : 653343189479387136,
    "created_at" : "2015-10-11 22:55:29 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 653349006421180416,
  "created_at" : "2015-10-11 23:18:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/650742432766783488\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/asXrbz98U4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQfmw5BXAAAOAly.jpg",
      "id_str" : "650742398792957952",
      "id" : 650742398792957952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQfmw5BXAAAOAly.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/asXrbz98U4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653348853064822784",
  "text" : "RT @Salmonae1: Gardening today so most birds absent.Sparrows helped out with communal waterfall bath. http:\/\/t.co\/asXrbz98U4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/650742432766783488\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/asXrbz98U4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQfmw5BXAAAOAly.jpg",
        "id_str" : "650742398792957952",
        "id" : 650742398792957952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQfmw5BXAAAOAly.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/asXrbz98U4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650742432766783488",
    "text" : "Gardening today so most birds absent.Sparrows helped out with communal waterfall bath. http:\/\/t.co\/asXrbz98U4",
    "id" : 650742432766783488,
    "created_at" : "2015-10-04 18:41:00 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 653348853064822784,
  "created_at" : "2015-10-11 23:17:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/653343781643808769\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/u3ErvBv2Am",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CREktG0XAAAhw4j.png",
      "id_str" : "653343778288369664",
      "id" : 653343778288369664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CREktG0XAAAhw4j.png",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/u3ErvBv2Am"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/w7dalfKDyb",
      "expanded_url" : "https:\/\/www.facebook.com\/FoxFriendsFirst\/photos\/a.383290185016050.98210.365084476836621\/1070076226337439\/?type=3&_ts=1444604268",
      "display_url" : "facebook.com\/FoxFriendsFirs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653343781643808769",
  "text" : "Separation of church and state!!! &gt; In God we trust on police cars https:\/\/t.co\/w7dalfKDyb http:\/\/t.co\/u3ErvBv2Am",
  "id" : 653343781643808769,
  "created_at" : "2015-10-11 22:57:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653326251994808321",
  "geo" : { },
  "id_str" : "653336042318262274",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hellrothgar777 im sorry to hear about yr parents reaction. may they eventually come to their senses and see what they're missing.",
  "id" : 653336042318262274,
  "in_reply_to_status_id" : 653326251994808321,
  "created_at" : "2015-10-11 22:27:05 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Atkinson",
      "screen_name" : "Son_DeeRRF",
      "indices" : [ 3, 14 ],
      "id_str" : "194727650",
      "id" : 194727650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/QpbFIEgzpT",
      "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/653301701559087105",
      "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653311445887795201",
  "text" : "RT @Son_DeeRRF: The saw a black \"man\"  https:\/\/t.co\/QpbFIEgzpT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/QpbFIEgzpT",
        "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/653301701559087105",
        "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653301849148235776",
    "text" : "The saw a black \"man\"  https:\/\/t.co\/QpbFIEgzpT",
    "id" : 653301849148235776,
    "created_at" : "2015-10-11 20:11:13 +0000",
    "user" : {
      "name" : "Derek Atkinson",
      "screen_name" : "Son_DeeRRF",
      "protected" : false,
      "id_str" : "194727650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424169446975242240\/qOmHbjo7_normal.jpeg",
      "id" : 194727650,
      "verified" : false
    }
  },
  "id" : 653311445887795201,
  "created_at" : "2015-10-11 20:49:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/653310879048560640\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/dmVibRyaw7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CREGx9LWEAA_xxI.jpg",
      "id_str" : "653310876250935296",
      "id" : 653310876250935296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CREGx9LWEAA_xxI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com\/dmVibRyaw7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653311399679107073",
  "text" : "RT @Swanwhisperer: Wow Practice Flight (10 Months Old ) http:\/\/t.co\/dmVibRyaw7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/653310879048560640\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/dmVibRyaw7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CREGx9LWEAA_xxI.jpg",
        "id_str" : "653310876250935296",
        "id" : 653310876250935296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CREGx9LWEAA_xxI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1944,
          "resize" : "fit",
          "w" : 2592
        } ],
        "display_url" : "pic.twitter.com\/dmVibRyaw7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653310879048560640",
    "text" : "Wow Practice Flight (10 Months Old ) http:\/\/t.co\/dmVibRyaw7",
    "id" : 653310879048560640,
    "created_at" : "2015-10-11 20:47:06 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 653311399679107073,
  "created_at" : "2015-10-11 20:49:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/tIOccBU6tX",
      "expanded_url" : "http:\/\/etsy.me\/1NzqRxQ",
      "display_url" : "etsy.me\/1NzqRxQ"
    } ]
  },
  "geo" : { },
  "id_str" : "653251011021283328",
  "text" : "adorable! &gt; Crochet pattern SHEEP magnet\/key ring by by ATERGcrochet http:\/\/t.co\/tIOccBU6tX",
  "id" : 653251011021283328,
  "created_at" : "2015-10-11 16:49:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resistance Justice",
      "screen_name" : "justiceputnam",
      "indices" : [ 3, 17 ],
      "id_str" : "56613758",
      "id" : 56613758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653249591782035456",
  "text" : "RT @justiceputnam: Ohio is an Open Carry State unless you're a 12 yr old w\/ a toy gun in a park.\n\nThen the cops are justified killing you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653241335084814336",
    "text" : "Ohio is an Open Carry State unless you're a 12 yr old w\/ a toy gun in a park.\n\nThen the cops are justified killing you.",
    "id" : 653241335084814336,
    "created_at" : "2015-10-11 16:10:45 +0000",
    "user" : {
      "name" : "Resistance Justice",
      "screen_name" : "justiceputnam",
      "protected" : false,
      "id_str" : "56613758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800959805493915648\/CwXS7Cos_normal.jpg",
      "id" : 56613758,
      "verified" : false
    }
  },
  "id" : 653249591782035456,
  "created_at" : "2015-10-11 16:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653240711249195008",
  "geo" : { },
  "id_str" : "653248917728030721",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time sinuses? advil congestion relief is my go to.",
  "id" : 653248917728030721,
  "in_reply_to_status_id" : 653240711249195008,
  "created_at" : "2015-10-11 16:40:53 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653240711249195008",
  "geo" : { },
  "id_str" : "653248250628190208",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time damn. how long ago new glasses.. maybe head still adjusting? ((hugs))",
  "id" : 653248250628190208,
  "in_reply_to_status_id" : 653240711249195008,
  "created_at" : "2015-10-11 16:38:14 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CynnyB",
      "screen_name" : "CynnyB",
      "indices" : [ 3, 10 ],
      "id_str" : "46793086",
      "id" : 46793086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TamirRice",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "JohnCrawford",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "DarrienHunt",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653247868577415169",
  "text" : "RT @CynnyB: #TamirRice #JohnCrawford #DarrienHunt all lived in an Open Carry State! So tell me why were they all murdered by Cops for havin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TamirRice",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "JohnCrawford",
        "indices" : [ 11, 24 ]
      }, {
        "text" : "DarrienHunt",
        "indices" : [ 25, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653233885346725888",
    "text" : "#TamirRice #JohnCrawford #DarrienHunt all lived in an Open Carry State! So tell me why were they all murdered by Cops for havin toy weapons?",
    "id" : 653233885346725888,
    "created_at" : "2015-10-11 15:41:09 +0000",
    "user" : {
      "name" : "CynnyB",
      "screen_name" : "CynnyB",
      "protected" : false,
      "id_str" : "46793086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635181176559304704\/LFyX-iYH_normal.jpg",
      "id" : 46793086,
      "verified" : false
    }
  },
  "id" : 653247868577415169,
  "created_at" : "2015-10-11 16:36:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/653217453913182208\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/lltPGSgicJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRCx0AeVAAErQLg.jpg",
      "id_str" : "653217453007241217",
      "id" : 653217453007241217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRCx0AeVAAErQLg.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lltPGSgicJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/iYPd17nrBU",
      "expanded_url" : "http:\/\/goo.gl\/327G4o",
      "display_url" : "goo.gl\/327G4o"
    } ]
  },
  "geo" : { },
  "id_str" : "653219301793615872",
  "text" : "RT @dailygalaxy: The Dark Matter Enigma: \"Is It the 'Operating System' of Our Universe?\" http:\/\/t.co\/iYPd17nrBU http:\/\/t.co\/lltPGSgicJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/653217453913182208\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/lltPGSgicJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRCx0AeVAAErQLg.jpg",
        "id_str" : "653217453007241217",
        "id" : 653217453007241217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRCx0AeVAAErQLg.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/lltPGSgicJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/iYPd17nrBU",
        "expanded_url" : "http:\/\/goo.gl\/327G4o",
        "display_url" : "goo.gl\/327G4o"
      } ]
    },
    "geo" : { },
    "id_str" : "653217453913182208",
    "text" : "The Dark Matter Enigma: \"Is It the 'Operating System' of Our Universe?\" http:\/\/t.co\/iYPd17nrBU http:\/\/t.co\/lltPGSgicJ",
    "id" : 653217453913182208,
    "created_at" : "2015-10-11 14:35:51 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 653219301793615872,
  "created_at" : "2015-10-11 14:43:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652964357203214337",
  "geo" : { },
  "id_str" : "652969542763868161",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley ugh.. sigh.",
  "id" : 652969542763868161,
  "in_reply_to_status_id" : 652964357203214337,
  "created_at" : "2015-10-10 22:10:45 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D48\u1D43\u207F\u1D4D\u1D49\u02B3 \u02B7\u1D43\u1DA0\u1DA0\u02E1\u1D49 \uD83D\uDC3A",
      "screen_name" : "wolfiestyle",
      "indices" : [ 3, 15 ],
      "id_str" : "280346006",
      "id" : 280346006
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wolfiestyle\/status\/652916255700221952\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ek0G1snWgQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ-f39hWoAAc2g_.jpg",
      "id_str" : "652916254748090368",
      "id" : 652916254748090368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ-f39hWoAAc2g_.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ek0G1snWgQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652918180218830848",
  "text" : "RT @wolfiestyle: touch the fluffy waff http:\/\/t.co\/ek0G1snWgQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erased5328496.com\" rel=\"nofollow\"\u003Eerased5328496\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wolfiestyle\/status\/652916255700221952\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/ek0G1snWgQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ-f39hWoAAc2g_.jpg",
        "id_str" : "652916254748090368",
        "id" : 652916254748090368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ-f39hWoAAc2g_.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ek0G1snWgQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652916255700221952",
    "text" : "touch the fluffy waff http:\/\/t.co\/ek0G1snWgQ",
    "id" : 652916255700221952,
    "created_at" : "2015-10-10 18:39:00 +0000",
    "user" : {
      "name" : "\u1D48\u1D43\u207F\u1D4D\u1D49\u02B3 \u02B7\u1D43\u1DA0\u1DA0\u02E1\u1D49 \uD83D\uDC3A",
      "screen_name" : "wolfiestyle",
      "protected" : false,
      "id_str" : "280346006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791071255428534273\/xQMcjLsc_normal.jpg",
      "id" : 280346006,
      "verified" : false
    }
  },
  "id" : 652918180218830848,
  "created_at" : "2015-10-10 18:46:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Bruhns",
      "screen_name" : "NinaBruhns",
      "indices" : [ 3, 14 ],
      "id_str" : "128251972",
      "id" : 128251972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coloringforadults",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/c7Mt6d9XTI",
      "expanded_url" : "http:\/\/amzn.to\/1Pc06P9",
      "display_url" : "amzn.to\/1Pc06P9"
    } ]
  },
  "geo" : { },
  "id_str" : "652918080734162944",
  "text" : "RT @NinaBruhns: * LOVE TO COLOR? * LOVE AFFIRMATIONS? * Sweet, intricate designs! http:\/\/t.co\/c7Mt6d9XTI #coloringforadults\u00A0http:\/\/t.co\/Abl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NinaBruhns\/status\/650407172807852032\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/AblJ7IlNNO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQa14HnUEAA0prw.jpg",
        "id_str" : "650407171922857984",
        "id" : 650407171922857984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQa14HnUEAA0prw.jpg",
        "sizes" : [ {
          "h" : 253,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AblJ7IlNNO"
      } ],
      "hashtags" : [ {
        "text" : "coloringforadults",
        "indices" : [ 89, 107 ]
      }, {
        "text" : "mgtab",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/c7Mt6d9XTI",
        "expanded_url" : "http:\/\/amzn.to\/1Pc06P9",
        "display_url" : "amzn.to\/1Pc06P9"
      } ]
    },
    "geo" : { },
    "id_str" : "652917023782096900",
    "text" : "* LOVE TO COLOR? * LOVE AFFIRMATIONS? * Sweet, intricate designs! http:\/\/t.co\/c7Mt6d9XTI #coloringforadults\u00A0http:\/\/t.co\/AblJ7IlNNO #mgtab",
    "id" : 652917023782096900,
    "created_at" : "2015-10-10 18:42:03 +0000",
    "user" : {
      "name" : "Nina Bruhns",
      "screen_name" : "NinaBruhns",
      "protected" : false,
      "id_str" : "128251972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1637715804\/2011-Nina-sq_normal.jpg",
      "id" : 128251972,
      "verified" : false
    }
  },
  "id" : 652918080734162944,
  "created_at" : "2015-10-10 18:46:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KVUE News",
      "screen_name" : "KVUE",
      "indices" : [ 75, 80 ],
      "id_str" : "15232635",
      "id" : 15232635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/WC7sxMniCS",
      "expanded_url" : "http:\/\/kvue.tv\/1LlY5yg",
      "display_url" : "kvue.tv\/1LlY5yg"
    } ]
  },
  "geo" : { },
  "id_str" : "652892741756657665",
  "text" : "Police detain Round Rock HS student after fight http:\/\/t.co\/WC7sxMniCS via @kvue",
  "id" : 652892741756657665,
  "created_at" : "2015-10-10 17:05:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hayley Neill",
      "screen_name" : "ringraif",
      "indices" : [ 3, 12 ],
      "id_str" : "567373918",
      "id" : 567373918
    }, {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 14, 24 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652891022100426752",
  "text" : "RT @ringraif: @ShaunKing This is disgusting. No damn excuse. And people want to deny there's a problem with police violence",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shaun King",
        "screen_name" : "ShaunKing",
        "indices" : [ 0, 10 ],
        "id_str" : "755113",
        "id" : 755113
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "652630260807258112",
    "geo" : { },
    "id_str" : "652681029619060737",
    "in_reply_to_user_id" : 755113,
    "text" : "@ShaunKing This is disgusting. No damn excuse. And people want to deny there's a problem with police violence",
    "id" : 652681029619060737,
    "in_reply_to_status_id" : 652630260807258112,
    "created_at" : "2015-10-10 03:04:18 +0000",
    "in_reply_to_screen_name" : "ShaunKing",
    "in_reply_to_user_id_str" : "755113",
    "user" : {
      "name" : "Hayley Neill",
      "screen_name" : "ringraif",
      "protected" : false,
      "id_str" : "567373918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618165441240797185\/0lLEezvY_normal.jpg",
      "id" : 567373918,
      "verified" : false
    }
  },
  "id" : 652891022100426752,
  "created_at" : "2015-10-10 16:58:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winston Booth",
      "screen_name" : "WinstonBooth",
      "indices" : [ 3, 16 ],
      "id_str" : "191243320",
      "id" : 191243320
    }, {
      "name" : "\uF8FF Zack Hoffmaster \uF8FF",
      "screen_name" : "Zackhoff32",
      "indices" : [ 18, 29 ],
      "id_str" : "433540470",
      "id" : 433540470
    }, {
      "name" : "jay",
      "screen_name" : "jcali916_",
      "indices" : [ 30, 40 ],
      "id_str" : "2881558550",
      "id" : 2881558550
    }, {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 41, 51 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652890798602719232",
  "text" : "RT @WinstonBooth: @Zackhoff32 @jcali916_ @ShaunKing Yeah, we live in a fascist police state after all, do what they say or they'll hurt you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\uF8FF Zack Hoffmaster \uF8FF",
        "screen_name" : "Zackhoff32",
        "indices" : [ 0, 11 ],
        "id_str" : "433540470",
        "id" : 433540470
      }, {
        "name" : "jay",
        "screen_name" : "jcali916_",
        "indices" : [ 12, 22 ],
        "id_str" : "2881558550",
        "id" : 2881558550
      }, {
        "name" : "Shaun King",
        "screen_name" : "ShaunKing",
        "indices" : [ 23, 33 ],
        "id_str" : "755113",
        "id" : 755113
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "652683489003761664",
    "geo" : { },
    "id_str" : "652888986097049600",
    "in_reply_to_user_id" : 433540470,
    "text" : "@Zackhoff32 @jcali916_ @ShaunKing Yeah, we live in a fascist police state after all, do what they say or they'll hurt you. AMERICA!",
    "id" : 652888986097049600,
    "in_reply_to_status_id" : 652683489003761664,
    "created_at" : "2015-10-10 16:50:39 +0000",
    "in_reply_to_screen_name" : "Zackhoff32",
    "in_reply_to_user_id_str" : "433540470",
    "user" : {
      "name" : "Winston Booth",
      "screen_name" : "WinstonBooth",
      "protected" : false,
      "id_str" : "191243320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432321856876457984\/6Pg11oCO_normal.jpeg",
      "id" : 191243320,
      "verified" : false
    }
  },
  "id" : 652890798602719232,
  "created_at" : "2015-10-10 16:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Enns",
      "screen_name" : "peteenns",
      "indices" : [ 117, 126 ],
      "id_str" : "130267418",
      "id" : 130267418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/hD1xpzlj7I",
      "expanded_url" : "http:\/\/www.peteenns.com\/5-ways-to-see-the-bible-as-an-adult-but-let-me-explain-before-you-jump-down-my-throat\/",
      "display_url" : "peteenns.com\/5-ways-to-see-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652875377996636160",
  "text" : "3 ways to see the Bible \"as an adult\" (but let me explain before you jump down my throat) http:\/\/t.co\/hD1xpzlj7I via @peteenns",
  "id" : 652875377996636160,
  "created_at" : "2015-10-10 15:56:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "feedly",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/aNqiyOaFQQ",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/using-the-bible-to-run-from-jesus-what-if-jesus-actually-is-enough\/",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652870398879645696",
  "text" : "Using the Bible To Run From Jesus (What If Jesus Actually Is Enough?) http:\/\/t.co\/aNqiyOaFQQ #religion #feedly",
  "id" : 652870398879645696,
  "created_at" : "2015-10-10 15:36:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/652868528157147136\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/zCIxwxdvQh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ90dwcXAAAV7bZ.jpg",
      "id_str" : "652868525560889344",
      "id" : 652868525560889344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ90dwcXAAAV7bZ.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/zCIxwxdvQh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/6mDgpJKJfw",
      "expanded_url" : "http:\/\/samanthapfield.com\/2015\/10\/09\/the-not-so-ridiculous-reasons-people-leave-church\/?_ts=1444490957",
      "display_url" : "samanthapfield.com\/2015\/10\/09\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652868528157147136",
  "text" : "the not-so-ridiculous reasons people leave church \u2013 Samantha Field http:\/\/t.co\/6mDgpJKJfw http:\/\/t.co\/zCIxwxdvQh",
  "id" : 652868528157147136,
  "created_at" : "2015-10-10 15:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/jo27SOkkYw",
      "expanded_url" : "https:\/\/twitter.com\/rachelheldevans\/status\/651476025625473024",
      "display_url" : "twitter.com\/rachelheldevan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652618071362899968",
  "text" : "RT @Hellrothgar777: This. This! Have I mentioned this? https:\/\/t.co\/jo27SOkkYw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/jo27SOkkYw",
        "expanded_url" : "https:\/\/twitter.com\/rachelheldevans\/status\/651476025625473024",
        "display_url" : "twitter.com\/rachelheldevan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651477554164039680",
    "text" : "This. This! Have I mentioned this? https:\/\/t.co\/jo27SOkkYw",
    "id" : 651477554164039680,
    "created_at" : "2015-10-06 19:22:07 +0000",
    "user" : {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "protected" : false,
      "id_str" : "279783538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716784460700717057\/uqMbDmgI_normal.jpg",
      "id" : 279783538,
      "verified" : false
    }
  },
  "id" : 652618071362899968,
  "created_at" : "2015-10-09 22:54:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muriel B",
      "screen_name" : "QuiltingMuriel",
      "indices" : [ 3, 18 ],
      "id_str" : "283235743",
      "id" : 283235743
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/QuiltingMuriel\/status\/652565277331333120\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ASfLiLMw98",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ5gqWZUcAAUy9S.jpg",
      "id_str" : "652565276697849856",
      "id" : 652565276697849856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ5gqWZUcAAUy9S.jpg",
      "sizes" : [ {
        "h" : 543,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 880
      } ],
      "display_url" : "pic.twitter.com\/ASfLiLMw98"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652568684825808896",
  "text" : "RT @QuiltingMuriel: A great idea. LOL! http:\/\/t.co\/ASfLiLMw98",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/QuiltingMuriel\/status\/652565277331333120\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ASfLiLMw98",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ5gqWZUcAAUy9S.jpg",
        "id_str" : "652565276697849856",
        "id" : 652565276697849856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ5gqWZUcAAUy9S.jpg",
        "sizes" : [ {
          "h" : 543,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/ASfLiLMw98"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652565277331333120",
    "text" : "A great idea. LOL! http:\/\/t.co\/ASfLiLMw98",
    "id" : 652565277331333120,
    "created_at" : "2015-10-09 19:24:20 +0000",
    "user" : {
      "name" : "Muriel B",
      "screen_name" : "QuiltingMuriel",
      "protected" : false,
      "id_str" : "283235743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726165095366070272\/yLhpYNTs_normal.jpg",
      "id" : 283235743,
      "verified" : false
    }
  },
  "id" : 652568684825808896,
  "created_at" : "2015-10-09 19:37:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/P64nm29AjZ",
      "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/652548606252199936",
      "display_url" : "twitter.com\/ftcreature\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652550841438703616",
  "text" : "hehe https:\/\/t.co\/P64nm29AjZ",
  "id" : 652550841438703616,
  "created_at" : "2015-10-09 18:26:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Redwings",
      "screen_name" : "RedwingsHS",
      "indices" : [ 3, 14 ],
      "id_str" : "33876884",
      "id" : 33876884
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CuteFridayPhoto",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652550249609850880",
  "text" : "RT @RedwingsHS: Poitou donkey cuteness (and fluffiness) overload with Adel, Merlin and little Adoption Star Arya! #CuteFridayPhoto http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RedwingsHS\/status\/649931010914787328\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/7iztKrZmBw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQUExf3WEAA0Jmb.jpg",
        "id_str" : "649930969638637568",
        "id" : 649930969638637568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQUExf3WEAA0Jmb.jpg",
        "sizes" : [ {
          "h" : 269,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/7iztKrZmBw"
      } ],
      "hashtags" : [ {
        "text" : "CuteFridayPhoto",
        "indices" : [ 98, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649931010914787328",
    "text" : "Poitou donkey cuteness (and fluffiness) overload with Adel, Merlin and little Adoption Star Arya! #CuteFridayPhoto http:\/\/t.co\/7iztKrZmBw",
    "id" : 649931010914787328,
    "created_at" : "2015-10-02 12:56:42 +0000",
    "user" : {
      "name" : "Redwings",
      "screen_name" : "RedwingsHS",
      "protected" : false,
      "id_str" : "33876884",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483655825831886848\/yJHV6WPg_normal.jpeg",
      "id" : 33876884,
      "verified" : false
    }
  },
  "id" : 652550249609850880,
  "created_at" : "2015-10-09 18:24:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ChL8vPEVlW",
      "expanded_url" : "https:\/\/twitter.com\/FatesBastard\/status\/651814069796638720",
      "display_url" : "twitter.com\/FatesBastard\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652520605019951104",
  "text" : "hmm... https:\/\/t.co\/ChL8vPEVlW",
  "id" : 652520605019951104,
  "created_at" : "2015-10-09 16:26:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Smith",
      "screen_name" : "RealTaiji",
      "indices" : [ 3, 13 ],
      "id_str" : "18603177",
      "id" : 18603177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/L4cuHHj95Q",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/scott-santens\/why-should-we-support-the_b_7630162.html",
      "display_url" : "huffingtonpost.com\/scott-santens\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652519276478382082",
  "text" : "RT @RealTaiji: Because it's an awesome idea: Why Should We Support the Idea of Universal Basic Income? http:\/\/t.co\/L4cuHHj95Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/L4cuHHj95Q",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/scott-santens\/why-should-we-support-the_b_7630162.html",
        "display_url" : "huffingtonpost.com\/scott-santens\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652304864190464001",
    "text" : "Because it's an awesome idea: Why Should We Support the Idea of Universal Basic Income? http:\/\/t.co\/L4cuHHj95Q",
    "id" : 652304864190464001,
    "created_at" : "2015-10-09 02:09:33 +0000",
    "user" : {
      "name" : "Steven Smith",
      "screen_name" : "RealTaiji",
      "protected" : false,
      "id_str" : "18603177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1206968714\/srs-profile-600_normal.JPG",
      "id" : 18603177,
      "verified" : false
    }
  },
  "id" : 652519276478382082,
  "created_at" : "2015-10-09 16:21:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/CAYVa2hoOC",
      "expanded_url" : "https:\/\/twitter.com\/mjkspeaks\/status\/652445581680492544",
      "display_url" : "twitter.com\/mjkspeaks\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652507070693031936",
  "text" : "sometimes I need to.. just to stay sane. https:\/\/t.co\/CAYVa2hoOC",
  "id" : 652507070693031936,
  "created_at" : "2015-10-09 15:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "verypink",
      "screen_name" : "verypink",
      "indices" : [ 3, 12 ],
      "id_str" : "14335677",
      "id" : 14335677
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "knitallthethings",
      "indices" : [ 45, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/iPZirMFhgl",
      "expanded_url" : "https:\/\/twitter.com\/verypink\/status\/651481466220756992",
      "display_url" : "twitter.com\/verypink\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652260202218135552",
  "text" : "RT @verypink: Don't miss this one. #giveaway #knitallthethings https:\/\/t.co\/iPZirMFhgl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaway",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "knitallthethings",
        "indices" : [ 31, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/iPZirMFhgl",
        "expanded_url" : "https:\/\/twitter.com\/verypink\/status\/651481466220756992",
        "display_url" : "twitter.com\/verypink\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652254944377049088",
    "text" : "Don't miss this one. #giveaway #knitallthethings https:\/\/t.co\/iPZirMFhgl",
    "id" : 652254944377049088,
    "created_at" : "2015-10-08 22:51:11 +0000",
    "user" : {
      "name" : "verypink",
      "screen_name" : "verypink",
      "protected" : false,
      "id_str" : "14335677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512329469785174016\/Vqyw7gao_normal.jpeg",
      "id" : 14335677,
      "verified" : false
    }
  },
  "id" : 652260202218135552,
  "created_at" : "2015-10-08 23:12:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/QdJVmhieHG",
      "expanded_url" : "https:\/\/twitter.com\/ebruenig\/status\/652229201567838213",
      "display_url" : "twitter.com\/ebruenig\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652230663060500480",
  "text" : "ummm.. what?? https:\/\/t.co\/QdJVmhieHG",
  "id" : 652230663060500480,
  "created_at" : "2015-10-08 21:14:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Bernie NY",
      "screen_name" : "TeamBernieNY",
      "indices" : [ 3, 16 ],
      "id_str" : "3355088872",
      "id" : 3355088872
    }, {
      "name" : "John Del Signore",
      "screen_name" : "johndelsignore",
      "indices" : [ 121, 136 ],
      "id_str" : "101754147",
      "id" : 101754147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ymXku8Qgi9",
      "expanded_url" : "http:\/\/gothamist.com\/2015\/10\/06\/democracy_bureacracy.php",
      "display_url" : "gothamist.com\/2015\/10\/06\/dem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652226305887477760",
  "text" : "RT @TeamBernieNY: Finally somebody did a great piece on the ridiculousness of the Oct 9 deadline! http:\/\/t.co\/ymXku8Qgi9 @johndelsignore @G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Del Signore",
        "screen_name" : "johndelsignore",
        "indices" : [ 103, 118 ],
        "id_str" : "101754147",
        "id" : 101754147
      }, {
        "name" : "Gothamist",
        "screen_name" : "Gothamist",
        "indices" : [ 119, 129 ],
        "id_str" : "810424",
        "id" : 810424
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/ymXku8Qgi9",
        "expanded_url" : "http:\/\/gothamist.com\/2015\/10\/06\/democracy_bureacracy.php",
        "display_url" : "gothamist.com\/2015\/10\/06\/dem\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651463940891889668",
    "text" : "Finally somebody did a great piece on the ridiculousness of the Oct 9 deadline! http:\/\/t.co\/ymXku8Qgi9 @johndelsignore @Gothamist",
    "id" : 651463940891889668,
    "created_at" : "2015-10-06 18:28:01 +0000",
    "user" : {
      "name" : "Team Bernie NY",
      "screen_name" : "TeamBernieNY",
      "protected" : false,
      "id_str" : "3355088872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634918675598954496\/hM0z7lwT_normal.jpg",
      "id" : 3355088872,
      "verified" : false
    }
  },
  "id" : 652226305887477760,
  "created_at" : "2015-10-08 20:57:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/652209699476144128\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/zlHSiki7Dg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0dQ3LWgAAvCke.png",
      "id_str" : "652209696565264384",
      "id" : 652209696565264384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0dQ3LWgAAvCke.png",
      "sizes" : [ {
        "h" : 211,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 122,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 590
      } ],
      "display_url" : "pic.twitter.com\/zlHSiki7Dg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/JXJpSMoGEm",
      "expanded_url" : "http:\/\/www.imdb.com\/title\/tt1637688\/trivia?tab=qt&ref_=tt_trv_qu&_ts=1444333882",
      "display_url" : "imdb.com\/title\/tt163768\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652209699476144128",
  "text" : "this is society that koch bro want &gt; In Time (2011) - Quotes http:\/\/t.co\/JXJpSMoGEm http:\/\/t.co\/zlHSiki7Dg",
  "id" : 652209699476144128,
  "created_at" : "2015-10-08 19:51:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Fiet",
      "screen_name" : "aprilfiet",
      "indices" : [ 3, 13 ],
      "id_str" : "74924807",
      "id" : 74924807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652127225853177856",
  "text" : "RT @aprilfiet: For those who say God is not allowed in schools, I would ask when God suddenly needed our permission to be somewhere.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652122430819860480",
    "text" : "For those who say God is not allowed in schools, I would ask when God suddenly needed our permission to be somewhere.",
    "id" : 652122430819860480,
    "created_at" : "2015-10-08 14:04:38 +0000",
    "user" : {
      "name" : "April Fiet",
      "screen_name" : "aprilfiet",
      "protected" : false,
      "id_str" : "74924807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469457797642330113\/gDMwoMTY_normal.jpeg",
      "id" : 74924807,
      "verified" : false
    }
  },
  "id" : 652127225853177856,
  "created_at" : "2015-10-08 14:23:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/8F1tmsxDJS",
      "expanded_url" : "https:\/\/twitter.com\/bettergeorgia\/status\/652124055403761666",
      "display_url" : "twitter.com\/bettergeorgia\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652124556304453632",
  "text" : "RT @rjmedwed: They just got it backwards - they\u2019re the ones \u201Cstruggling\u201D, not us.  https:\/\/t.co\/8F1tmsxDJS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/8F1tmsxDJS",
        "expanded_url" : "https:\/\/twitter.com\/bettergeorgia\/status\/652124055403761666",
        "display_url" : "twitter.com\/bettergeorgia\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652124198140289025",
    "text" : "They just got it backwards - they\u2019re the ones \u201Cstruggling\u201D, not us.  https:\/\/t.co\/8F1tmsxDJS",
    "id" : 652124198140289025,
    "created_at" : "2015-10-08 14:11:39 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 652124556304453632,
  "created_at" : "2015-10-08 14:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/652034353678188544\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/3iUgQ9CF3e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQx9xwRWwAA-f-5.jpg",
      "id_str" : "652034339786637312",
      "id" : 652034339786637312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQx9xwRWwAA-f-5.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3iUgQ9CF3e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652124405414404097",
  "text" : "RT @Swanwhisperer: Good morning from Staffordshire http:\/\/t.co\/3iUgQ9CF3e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/652034353678188544\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/3iUgQ9CF3e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQx9xwRWwAA-f-5.jpg",
        "id_str" : "652034339786637312",
        "id" : 652034339786637312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQx9xwRWwAA-f-5.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3iUgQ9CF3e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652034353678188544",
    "text" : "Good morning from Staffordshire http:\/\/t.co\/3iUgQ9CF3e",
    "id" : 652034353678188544,
    "created_at" : "2015-10-08 08:14:38 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 652124405414404097,
  "created_at" : "2015-10-08 14:12:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sunset",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "camp",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/82rjMHTCne",
      "expanded_url" : "https:\/\/instagram.com\/p\/8jwQlcyhKv\/",
      "display_url" : "instagram.com\/p\/8jwQlcyhKv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "651937102913998848",
  "text" : "RT @_CabinGirl: Our last #sunset at #camp was a stunner. Sun broke out of the clouds to turn everything golden.\u2026 https:\/\/t.co\/82rjMHTCne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sunset",
        "indices" : [ 9, 16 ]
      }, {
        "text" : "camp",
        "indices" : [ 20, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/82rjMHTCne",
        "expanded_url" : "https:\/\/instagram.com\/p\/8jwQlcyhKv\/",
        "display_url" : "instagram.com\/p\/8jwQlcyhKv\/"
      } ]
    },
    "geo" : { },
    "id_str" : "651936506559356928",
    "text" : "Our last #sunset at #camp was a stunner. Sun broke out of the clouds to turn everything golden.\u2026 https:\/\/t.co\/82rjMHTCne",
    "id" : 651936506559356928,
    "created_at" : "2015-10-08 01:45:50 +0000",
    "user" : {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "protected" : false,
      "id_str" : "116807098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713963701\/me_and_fawnsm_normal.jpg",
      "id" : 116807098,
      "verified" : false
    }
  },
  "id" : 651937102913998848,
  "created_at" : "2015-10-08 01:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vjqCVEF68h",
      "expanded_url" : "http:\/\/voteforbernie.org\/",
      "display_url" : "voteforbernie.org"
    } ]
  },
  "geo" : { },
  "id_str" : "651927509429321729",
  "text" : "Find out how and when to vote for Bernie Sanders in the upcoming primaries!: http:\/\/t.co\/vjqCVEF68h NYS important date Oct 9",
  "id" : 651927509429321729,
  "created_at" : "2015-10-08 01:10:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zoe's Bag Boutique",
      "screen_name" : "zoesbagboutique",
      "indices" : [ 3, 19 ],
      "id_str" : "27628892",
      "id" : 27628892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/DOl6SC4x3r",
      "expanded_url" : "http:\/\/fb.me\/2cByUhQ8j",
      "display_url" : "fb.me\/2cByUhQ8j"
    } ]
  },
  "geo" : { },
  "id_str" : "651901783044976641",
  "text" : "RT @zoesbagboutique: Another large Suebee, this is so cute, cats on chairs. :-)\nNot in the shop yet. http:\/\/t.co\/DOl6SC4x3r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/DOl6SC4x3r",
        "expanded_url" : "http:\/\/fb.me\/2cByUhQ8j",
        "display_url" : "fb.me\/2cByUhQ8j"
      } ]
    },
    "geo" : { },
    "id_str" : "651900991407681537",
    "text" : "Another large Suebee, this is so cute, cats on chairs. :-)\nNot in the shop yet. http:\/\/t.co\/DOl6SC4x3r",
    "id" : 651900991407681537,
    "created_at" : "2015-10-07 23:24:42 +0000",
    "user" : {
      "name" : "Zoe's Bag Boutique",
      "screen_name" : "zoesbagboutique",
      "protected" : false,
      "id_str" : "27628892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2167261924\/188x188_for_new_facebook_page_normal.gif",
      "id" : 27628892,
      "verified" : false
    }
  },
  "id" : 651901783044976641,
  "created_at" : "2015-10-07 23:27:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forrest A Mow",
      "screen_name" : "chipsmow",
      "indices" : [ 3, 12 ],
      "id_str" : "218086325",
      "id" : 218086325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/L5Crd4JGtN",
      "expanded_url" : "http:\/\/www.complex.com\/pop-culture\/2015\/10\/student-wants-school-officials-and-local-police-held-responsible-for-classmate-suicide-after-verbal-attack",
      "display_url" : "complex.com\/pop-culture\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651893747706368001",
  "text" : "RT @chipsmow: SCHOOL OFFICIALS HARASS STUDENT INTO SUICIDE...\nhttp:\/\/t.co\/L5Crd4JGtN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/L5Crd4JGtN",
        "expanded_url" : "http:\/\/www.complex.com\/pop-culture\/2015\/10\/student-wants-school-officials-and-local-police-held-responsible-for-classmate-suicide-after-verbal-attack",
        "display_url" : "complex.com\/pop-culture\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651892201383858176",
    "text" : "SCHOOL OFFICIALS HARASS STUDENT INTO SUICIDE...\nhttp:\/\/t.co\/L5Crd4JGtN",
    "id" : 651892201383858176,
    "created_at" : "2015-10-07 22:49:47 +0000",
    "user" : {
      "name" : "Forrest A Mow",
      "screen_name" : "chipsmow",
      "protected" : false,
      "id_str" : "218086325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598051006518153217\/Z3nokPl6_normal.jpg",
      "id" : 218086325,
      "verified" : false
    }
  },
  "id" : 651893747706368001,
  "created_at" : "2015-10-07 22:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651885270938353665",
  "text" : "RT @worldtreeman: We have had enough of the puppet show",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651884307305340928",
    "text" : "We have had enough of the puppet show",
    "id" : 651884307305340928,
    "created_at" : "2015-10-07 22:18:24 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 651885270938353665,
  "created_at" : "2015-10-07 22:22:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651878332431208448",
  "text" : "legislating ourselves into boxes... gah.",
  "id" : 651878332431208448,
  "created_at" : "2015-10-07 21:54:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651878167351828480",
  "text" : "so illegal to smoke in car while minors in said car... where is the uproar over freedom, rights and all that. stupid law.",
  "id" : 651878167351828480,
  "created_at" : "2015-10-07 21:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N. John Shore, Jr.",
      "screen_name" : "johnshore",
      "indices" : [ 104, 114 ],
      "id_str" : "74710075",
      "id" : 74710075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/oDeCHwBQ2U",
      "expanded_url" : "http:\/\/johnshore.com\/2015\/10\/07\/is-this-fundamentalist-mothers-letter-to-her-daughter-loving-or-horrible\/",
      "display_url" : "johnshore.com\/2015\/10\/07\/is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651853629486448642",
  "text" : "Is this fundamentalist mother's letter to her daughter loving, or horrible?: http:\/\/t.co\/oDeCHwBQ2U via @johnshore",
  "id" : 651853629486448642,
  "created_at" : "2015-10-07 20:16:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651853151486771201",
  "text" : "therapist seems to think medicaid will cover neuro-psych eval. so I have to check that out.",
  "id" : 651853151486771201,
  "created_at" : "2015-10-07 20:14:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651852406901374976",
  "text" : "DDs intake part 2 done. reg session next time. therapist rec neuro visit for memory issues and neuro-psych eval for aspergers.",
  "id" : 651852406901374976,
  "created_at" : "2015-10-07 20:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EcoInteractive",
      "screen_name" : "EcoInteractive",
      "indices" : [ 3, 18 ],
      "id_str" : "18932935",
      "id" : 18932935
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arctic",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "butterflies",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 101, 115 ]
    }, {
      "text" : "climate",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "evolution",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/hukzfPZyKW",
      "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2015\/10\/151007033227.htm",
      "display_url" : "sciencedaily.com\/releases\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651784669986451457",
  "text" : "RT @EcoInteractive: High-#arctic #butterflies shrink with rising temperatures http:\/\/t.co\/hukzfPZyKW #climatechange #climate #evolution htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EcoInteractive\/status\/651760541858447360\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/OVbp8JrPCx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQuEwlIU8AYKpD5.jpg",
        "id_str" : "651760541220794374",
        "id" : 651760541220794374,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQuEwlIU8AYKpD5.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/OVbp8JrPCx"
      } ],
      "hashtags" : [ {
        "text" : "arctic",
        "indices" : [ 5, 12 ]
      }, {
        "text" : "butterflies",
        "indices" : [ 13, 25 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 81, 95 ]
      }, {
        "text" : "climate",
        "indices" : [ 96, 104 ]
      }, {
        "text" : "evolution",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/hukzfPZyKW",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2015\/10\/151007033227.htm",
        "display_url" : "sciencedaily.com\/releases\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651760541858447360",
    "text" : "High-#arctic #butterflies shrink with rising temperatures http:\/\/t.co\/hukzfPZyKW #climatechange #climate #evolution http:\/\/t.co\/OVbp8JrPCx",
    "id" : 651760541858447360,
    "created_at" : "2015-10-07 14:06:36 +0000",
    "user" : {
      "name" : "EcoInteractive",
      "screen_name" : "EcoInteractive",
      "protected" : false,
      "id_str" : "18932935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638530329062588416\/mRH7Nvja_normal.jpg",
      "id" : 18932935,
      "verified" : false
    }
  },
  "id" : 651784669986451457,
  "created_at" : "2015-10-07 15:42:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. News",
      "screen_name" : "usnews",
      "indices" : [ 3, 10 ],
      "id_str" : "6577642",
      "id" : 6577642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ggReI0NEv4",
      "expanded_url" : "http:\/\/trib.al\/zNV2IMi",
      "display_url" : "trib.al\/zNV2IMi"
    } ]
  },
  "geo" : { },
  "id_str" : "651781124482551808",
  "text" : "RT @usnews: After 25 years in jail for a murder he says he didn't commit, a N.Y. man is freed. http:\/\/t.co\/ggReI0NEv4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/ggReI0NEv4",
        "expanded_url" : "http:\/\/trib.al\/zNV2IMi",
        "display_url" : "trib.al\/zNV2IMi"
      } ]
    },
    "geo" : { },
    "id_str" : "651575927365873664",
    "text" : "After 25 years in jail for a murder he says he didn't commit, a N.Y. man is freed. http:\/\/t.co\/ggReI0NEv4",
    "id" : 651575927365873664,
    "created_at" : "2015-10-07 01:53:01 +0000",
    "user" : {
      "name" : "U.S. News",
      "screen_name" : "usnews",
      "protected" : false,
      "id_str" : "6577642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3217425773\/ef973bf9519503bd543ff48e2564f9da_normal.png",
      "id" : 6577642,
      "verified" : true
    }
  },
  "id" : 651781124482551808,
  "created_at" : "2015-10-07 15:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651630877206818816",
  "geo" : { },
  "id_str" : "651776246792220672",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley she is so precious! smooches sweet Blossom!",
  "id" : 651776246792220672,
  "in_reply_to_status_id" : 651630877206818816,
  "created_at" : "2015-10-07 15:09:01 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michala Banas",
      "screen_name" : "michalabanas",
      "indices" : [ 3, 16 ],
      "id_str" : "22249583",
      "id" : 22249583
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/michalabanas\/status\/649115715937505280\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/lbtknAj5Mc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQIfSwlUkAA4ptS.jpg",
      "id_str" : "649115703434317824",
      "id" : 649115703434317824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQIfSwlUkAA4ptS.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lbtknAj5Mc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651774924558888960",
  "text" : "RT @michalabanas: http:\/\/t.co\/lbtknAj5Mc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michalabanas\/status\/649115715937505280\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/lbtknAj5Mc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQIfSwlUkAA4ptS.jpg",
        "id_str" : "649115703434317824",
        "id" : 649115703434317824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQIfSwlUkAA4ptS.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lbtknAj5Mc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649115715937505280",
    "text" : "http:\/\/t.co\/lbtknAj5Mc",
    "id" : 649115715937505280,
    "created_at" : "2015-09-30 06:57:01 +0000",
    "user" : {
      "name" : "Michala Banas",
      "screen_name" : "michalabanas",
      "protected" : false,
      "id_str" : "22249583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772009818777194499\/L2gv7l0W_normal.jpg",
      "id" : 22249583,
      "verified" : true
    }
  },
  "id" : 651774924558888960,
  "created_at" : "2015-10-07 15:03:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michala Banas",
      "screen_name" : "michalabanas",
      "indices" : [ 3, 16 ],
      "id_str" : "22249583",
      "id" : 22249583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651774851741519872",
  "text" : "RT @michalabanas: It's mental health week. Please retweet- it may be helpful to someone you know (or even someone you don't)\nX Michala http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michalabanas\/status\/651353865288200192\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/URnK9tpiyL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQoS4X4U8AA2HOk.jpg",
        "id_str" : "651353855800700928",
        "id" : 651353855800700928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQoS4X4U8AA2HOk.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 813
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 813
        } ],
        "display_url" : "pic.twitter.com\/URnK9tpiyL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651353865288200192",
    "text" : "It's mental health week. Please retweet- it may be helpful to someone you know (or even someone you don't)\nX Michala http:\/\/t.co\/URnK9tpiyL",
    "id" : 651353865288200192,
    "created_at" : "2015-10-06 11:10:37 +0000",
    "user" : {
      "name" : "Michala Banas",
      "screen_name" : "michalabanas",
      "protected" : false,
      "id_str" : "22249583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772009818777194499\/L2gv7l0W_normal.jpg",
      "id" : 22249583,
      "verified" : true
    }
  },
  "id" : 651774851741519872,
  "created_at" : "2015-10-07 15:03:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Fraleigh",
      "screen_name" : "Casey_Pup",
      "indices" : [ 3, 13 ],
      "id_str" : "54759959",
      "id" : 54759959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651469088406007808",
  "text" : "RT @Casey_Pup: Exploitation of orca has always been their mandate. This is a for profit corporation whose priority is $ over morals https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DAlsKqnS6H",
        "expanded_url" : "https:\/\/twitter.com\/johnjhargrove\/status\/650706531089051648",
        "display_url" : "twitter.com\/johnjhargrove\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "650707353403326464",
    "text" : "Exploitation of orca has always been their mandate. This is a for profit corporation whose priority is $ over morals https:\/\/t.co\/DAlsKqnS6H",
    "id" : 650707353403326464,
    "created_at" : "2015-10-04 16:21:37 +0000",
    "user" : {
      "name" : "Diane Fraleigh",
      "screen_name" : "Casey_Pup",
      "protected" : false,
      "id_str" : "54759959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2898728542\/d2ef4eac59b2ad86dce53915b28820b4_normal.jpeg",
      "id" : 54759959,
      "verified" : false
    }
  },
  "id" : 651469088406007808,
  "created_at" : "2015-10-06 18:48:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 3, 14 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651467930782302209",
  "text" : "RT @UnseelieMe: ...it might even have saved my life. Reading is that instrumental to my well being.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651438540509814784",
    "text" : "...it might even have saved my life. Reading is that instrumental to my well being.",
    "id" : 651438540509814784,
    "created_at" : "2015-10-06 16:47:05 +0000",
    "user" : {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "protected" : false,
      "id_str" : "92123740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799065105182900231\/p9W4urrM_normal.jpg",
      "id" : 92123740,
      "verified" : false
    }
  },
  "id" : 651467930782302209,
  "created_at" : "2015-10-06 18:43:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katina",
      "screen_name" : "KatGad",
      "indices" : [ 3, 10 ],
      "id_str" : "23945498",
      "id" : 23945498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651436098812530688",
  "text" : "RT @KatGad: Nobody really knows what the fuck they are doing here, everyone is making it up as they go along. Life is created in the now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650865570104131584",
    "text" : "Nobody really knows what the fuck they are doing here, everyone is making it up as they go along. Life is created in the now.",
    "id" : 650865570104131584,
    "created_at" : "2015-10-05 02:50:19 +0000",
    "user" : {
      "name" : "Katina",
      "screen_name" : "KatGad",
      "protected" : false,
      "id_str" : "23945498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800516554559459328\/sc8vHjJ5_normal.jpg",
      "id" : 23945498,
      "verified" : false
    }
  },
  "id" : 651436098812530688,
  "created_at" : "2015-10-06 16:37:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sally garland",
      "screen_name" : "florestaqueen",
      "indices" : [ 3, 17 ],
      "id_str" : "762327451",
      "id" : 762327451
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Devon",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "birds",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "birding",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 109, 122 ]
    }, {
      "text" : "nature",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651411144939278336",
  "text" : "RT @florestaqueen: Now know these ducks seen last week are rare Swedish Blue Ducks... #Devon #birds #birding #birdwatching #nature http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/florestaqueen\/status\/648220154367709185\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/L27OhTbD0b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP7wyWxWoAAOmOm.jpg",
        "id_str" : "648220144284639232",
        "id" : 648220144284639232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP7wyWxWoAAOmOm.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/L27OhTbD0b"
      } ],
      "hashtags" : [ {
        "text" : "Devon",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "birds",
        "indices" : [ 74, 80 ]
      }, {
        "text" : "birding",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 90, 103 ]
      }, {
        "text" : "nature",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648220154367709185",
    "text" : "Now know these ducks seen last week are rare Swedish Blue Ducks... #Devon #birds #birding #birdwatching #nature http:\/\/t.co\/L27OhTbD0b",
    "id" : 648220154367709185,
    "created_at" : "2015-09-27 19:38:22 +0000",
    "user" : {
      "name" : "sally garland",
      "screen_name" : "florestaqueen",
      "protected" : false,
      "id_str" : "762327451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877902376\/3b4259b43bc2a8c0d9ba527562427f36_normal.jpeg",
      "id" : 762327451,
      "verified" : false
    }
  },
  "id" : 651411144939278336,
  "created_at" : "2015-10-06 14:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BC",
      "screen_name" : "savebutterflies",
      "indices" : [ 3, 19 ],
      "id_str" : "257396212",
      "id" : 257396212
    }, {
      "name" : "Wiltshire BC",
      "screen_name" : "BC_Wiltshire",
      "indices" : [ 89, 102 ],
      "id_str" : "252295881",
      "id" : 252295881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wiltshire",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651410952852774912",
  "text" : "RT @savebutterflies: We've had a sighting of a Monarch butterfly in #Wiltshire this week @BC_Wiltshire! A stunning, rare migrant to the UK \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wiltshire BC",
        "screen_name" : "BC_Wiltshire",
        "indices" : [ 68, 81 ],
        "id_str" : "252295881",
        "id" : 252295881
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/savebutterflies\/status\/649233943628238848\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/CvmzEGl86k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQKK1JcUYAAMxQ1.jpg",
        "id_str" : "649233941967167488",
        "id" : 649233941967167488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQKK1JcUYAAMxQ1.jpg",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2236,
          "resize" : "fit",
          "w" : 2694
        } ],
        "display_url" : "pic.twitter.com\/CvmzEGl86k"
      } ],
      "hashtags" : [ {
        "text" : "Wiltshire",
        "indices" : [ 47, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649233943628238848",
    "text" : "We've had a sighting of a Monarch butterfly in #Wiltshire this week @BC_Wiltshire! A stunning, rare migrant to the UK http:\/\/t.co\/CvmzEGl86k",
    "id" : 649233943628238848,
    "created_at" : "2015-09-30 14:46:49 +0000",
    "user" : {
      "name" : "BC",
      "screen_name" : "savebutterflies",
      "protected" : false,
      "id_str" : "257396212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1254616834\/174598_197665823580806_863740_n_normal.jpg",
      "id" : 257396212,
      "verified" : false
    }
  },
  "id" : 651410952852774912,
  "created_at" : "2015-10-06 14:57:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Cuthbert",
      "screen_name" : "CRCuthbert",
      "indices" : [ 3, 14 ],
      "id_str" : "2896449238",
      "id" : 2896449238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651410537302110209",
  "text" : "RT @CRCuthbert: Lovely Crimson Speckled moth (Utetheisa pulchella) in its Mediterranean home today (on unknown shrub!) @ButterfliesGB http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CRCuthbert\/status\/651103418283462656\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jguwAnTuiZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkvFWgUsAAeLRn.jpg",
        "id_str" : "651103390118752256",
        "id" : 651103390118752256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkvFWgUsAAeLRn.jpg",
        "sizes" : [ {
          "h" : 410,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jguwAnTuiZ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CRCuthbert\/status\/651103418283462656\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jguwAnTuiZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkvG5aVAAAEUnB.jpg",
        "id_str" : "651103416668717056",
        "id" : 651103416668717056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkvG5aVAAAEUnB.jpg",
        "sizes" : [ {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/jguwAnTuiZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651103418283462656",
    "text" : "Lovely Crimson Speckled moth (Utetheisa pulchella) in its Mediterranean home today (on unknown shrub!) @ButterfliesGB http:\/\/t.co\/jguwAnTuiZ",
    "id" : 651103418283462656,
    "created_at" : "2015-10-05 18:35:26 +0000",
    "user" : {
      "name" : "Charles Cuthbert",
      "screen_name" : "CRCuthbert",
      "protected" : false,
      "id_str" : "2896449238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608307317919129600\/tPJ_NHpa_normal.jpg",
      "id" : 2896449238,
      "verified" : false
    }
  },
  "id" : 651410537302110209,
  "created_at" : "2015-10-06 14:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/651185944687542272\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/BPcRFYb22e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQl6KflUkAAQptO.jpg",
      "id_str" : "651185941827063808",
      "id" : 651185941827063808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQl6KflUkAAQptO.jpg",
      "sizes" : [ {
        "h" : 98,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 76,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 98,
        "resize" : "crop",
        "w" : 98
      } ],
      "display_url" : "pic.twitter.com\/BPcRFYb22e"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/wLzT0tLsOQ",
      "expanded_url" : "http:\/\/www.towleroad.com\/2015\/10\/candace-cameron-bure-shames-danny-pinaturo-on-his-past-drug-use-hiv-status-watch\/?utm_content=buffer74dc2&utm_medium=social&utm_source=facebook.com&utm_campaign=buffer&_ts=1444089796",
      "display_url" : "towleroad.com\/2015\/10\/candac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651185944687542272",
  "text" : "whose business is it? re: protected sex o-O Candace Cameron Bure Shames Danny Pintauro http:\/\/t.co\/wLzT0tLsOQ http:\/\/t.co\/BPcRFYb22e",
  "id" : 651185944687542272,
  "created_at" : "2015-10-06 00:03:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/abIfifq19H",
      "expanded_url" : "http:\/\/www.towleroad.com\/2015\/10\/candace-cameron-bure-shames-danny-pinaturo-on-his-past-drug-use-hiv-status-watch\/",
      "display_url" : "towleroad.com\/2015\/10\/candac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651185235116228608",
  "text" : "she's a jerk &gt; Candace Cameron Bure Shames Danny Pintauro On His Past Drug Use, HIV Status: WATCH http:\/\/t.co\/abIfifq19H",
  "id" : 651185235116228608,
  "created_at" : "2015-10-06 00:00:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\/C holidays devon",
      "screen_name" : "beermillcottage",
      "indices" : [ 3, 19 ],
      "id_str" : "2457845372",
      "id" : 2457845372
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/beermillcottage\/status\/651163323350716416\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6R4ygJr98H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQllj5tVAAE-Si6.jpg",
      "id_str" : "651163288592515073",
      "id" : 651163288592515073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQllj5tVAAE-Si6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/6R4ygJr98H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651172884363120640",
  "text" : "RT @beermillcottage: Beer Mill conservation grazing team pause to check out humans \uD83D\uDE0A such teddy bears http:\/\/t.co\/6R4ygJr98H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/beermillcottage\/status\/651163323350716416\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/6R4ygJr98H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQllj5tVAAE-Si6.jpg",
        "id_str" : "651163288592515073",
        "id" : 651163288592515073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQllj5tVAAE-Si6.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/6R4ygJr98H"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651163323350716416",
    "text" : "Beer Mill conservation grazing team pause to check out humans \uD83D\uDE0A such teddy bears http:\/\/t.co\/6R4ygJr98H",
    "id" : 651163323350716416,
    "created_at" : "2015-10-05 22:33:28 +0000",
    "user" : {
      "name" : "S\/C holidays devon",
      "screen_name" : "beermillcottage",
      "protected" : false,
      "id_str" : "2457845372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464666711460179968\/PrBIL8hM_normal.jpeg",
      "id" : 2457845372,
      "verified" : false
    }
  },
  "id" : 651172884363120640,
  "created_at" : "2015-10-05 23:11:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/TBW296Y31Z",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/651062105207123968",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651112065139122176",
  "text" : "red barn in snow.. this one would make nice christmas cards. https:\/\/t.co\/TBW296Y31Z",
  "id" : 651112065139122176,
  "created_at" : "2015-10-05 19:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/85FhNbhI8C",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/651060970681446400",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651111476137197568",
  "text" : "((highfive)) : ) https:\/\/t.co\/85FhNbhI8C",
  "id" : 651111476137197568,
  "created_at" : "2015-10-05 19:07:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molly Crabapple",
      "screen_name" : "mollycrabapple",
      "indices" : [ 3, 18 ],
      "id_str" : "15644999",
      "id" : 15644999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651069374636421120",
  "text" : "RT @mollycrabapple: Andre Jacobs was arrested for drugs at age 15. 17 years later he's still imprisoned- the last 14 years in solitary http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Yw2qtcG3Xg",
        "expanded_url" : "http:\/\/www.vice.com\/read\/unauthorized-group-activity-0000772-v22n10",
        "display_url" : "vice.com\/read\/unauthori\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651033788215099393",
    "text" : "Andre Jacobs was arrested for drugs at age 15. 17 years later he's still imprisoned- the last 14 years in solitary http:\/\/t.co\/Yw2qtcG3Xg",
    "id" : 651033788215099393,
    "created_at" : "2015-10-05 13:58:45 +0000",
    "user" : {
      "name" : "Molly Crabapple",
      "screen_name" : "mollycrabapple",
      "protected" : false,
      "id_str" : "15644999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798306915075948544\/X0ZY_9-Z_normal.jpg",
      "id" : 15644999,
      "verified" : true
    }
  },
  "id" : 651069374636421120,
  "created_at" : "2015-10-05 16:20:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/gBhJP4Dddd",
      "expanded_url" : "http:\/\/animalsn.co\/?p=3572#.VhKdrSMZHs8.twitter",
      "display_url" : "animalsn.co\/?p=3572#.VhKdr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651063485204439040",
  "text" : "He Watched Helplessly As A Wild Wolf Approached His Dog. Then Something Incredible Happened. http:\/\/t.co\/gBhJP4Dddd",
  "id" : 651063485204439040,
  "created_at" : "2015-10-05 15:56:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "indices" : [ 3, 15 ],
      "id_str" : "318692762",
      "id" : 318692762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/G6m3xkAfvW",
      "expanded_url" : "http:\/\/www.csmonitor.com\/Business\/Robert-Reich\/2015\/0408\/How-the-Koch-brothers-and-the-super-rich-are-buying-their-way-out-of-criticism",
      "display_url" : "csmonitor.com\/Business\/Rober\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651048060211077121",
  "text" : "RT @SeanMcElwee: This is a worrying trend: the Koch brothers are literally buying economics departments. http:\/\/t.co\/G6m3xkAfvW http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SeanMcElwee\/status\/650824972038991872\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/JXz6JpWzKK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQgx2sYWgAAsMhI.png",
        "id_str" : "650824961851031552",
        "id" : 650824961851031552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQgx2sYWgAAsMhI.png",
        "sizes" : [ {
          "h" : 265,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 638
        } ],
        "display_url" : "pic.twitter.com\/JXz6JpWzKK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/G6m3xkAfvW",
        "expanded_url" : "http:\/\/www.csmonitor.com\/Business\/Robert-Reich\/2015\/0408\/How-the-Koch-brothers-and-the-super-rich-are-buying-their-way-out-of-criticism",
        "display_url" : "csmonitor.com\/Business\/Rober\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "650822407700258816",
    "geo" : { },
    "id_str" : "650824972038991872",
    "in_reply_to_user_id" : 318692762,
    "text" : "This is a worrying trend: the Koch brothers are literally buying economics departments. http:\/\/t.co\/G6m3xkAfvW http:\/\/t.co\/JXz6JpWzKK",
    "id" : 650824972038991872,
    "in_reply_to_status_id" : 650822407700258816,
    "created_at" : "2015-10-05 00:08:59 +0000",
    "in_reply_to_screen_name" : "SeanMcElwee",
    "in_reply_to_user_id_str" : "318692762",
    "user" : {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "protected" : false,
      "id_str" : "318692762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697656193737748480\/Hc-WgXJw_normal.jpg",
      "id" : 318692762,
      "verified" : false
    }
  },
  "id" : 651048060211077121,
  "created_at" : "2015-10-05 14:55:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650858157489659904",
  "text" : "DD got hit w strong nausea this eve. Grateful her anti-nausea med didn't take too long to kick in #hashimotos",
  "id" : 650858157489659904,
  "created_at" : "2015-10-05 02:20:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not That Ajax",
      "screen_name" : "AJaxRelax",
      "indices" : [ 3, 13 ],
      "id_str" : "3167884790",
      "id" : 3167884790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650717859677605888",
  "text" : "RT @AJaxRelax: Being 18-25 is like playing a video game where you skipped the tutorial and are just sort of running about with no idea how \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593431660605079552",
    "text" : "Being 18-25 is like playing a video game where you skipped the tutorial and are just sort of running about with no idea how anything works.",
    "id" : 593431660605079552,
    "created_at" : "2015-04-29 15:08:27 +0000",
    "user" : {
      "name" : "Not That Ajax",
      "screen_name" : "AJaxRelax",
      "protected" : false,
      "id_str" : "3167884790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668854739015065600\/GbnhLZu2_normal.jpg",
      "id" : 3167884790,
      "verified" : false
    }
  },
  "id" : 650717859677605888,
  "created_at" : "2015-10-04 17:03:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katina",
      "screen_name" : "KatGad",
      "indices" : [ 3, 10 ],
      "id_str" : "23945498",
      "id" : 23945498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/t1cY0qKkJD",
      "expanded_url" : "https:\/\/instagram.com\/p\/8a6yGCCEl2\/",
      "display_url" : "instagram.com\/p\/8a6yGCCEl2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "650695276420841472",
  "text" : "RT @KatGad: More cat, less bolero. Women's button back blouse size 16. Will be available in the etsy shop (along\u2026 https:\/\/t.co\/t1cY0qKkJD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/t1cY0qKkJD",
        "expanded_url" : "https:\/\/instagram.com\/p\/8a6yGCCEl2\/",
        "display_url" : "instagram.com\/p\/8a6yGCCEl2\/"
      } ]
    },
    "geo" : { },
    "id_str" : "650693008044625920",
    "text" : "More cat, less bolero. Women's button back blouse size 16. Will be available in the etsy shop (along\u2026 https:\/\/t.co\/t1cY0qKkJD",
    "id" : 650693008044625920,
    "created_at" : "2015-10-04 15:24:37 +0000",
    "user" : {
      "name" : "Katina",
      "screen_name" : "KatGad",
      "protected" : false,
      "id_str" : "23945498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800516554559459328\/sc8vHjJ5_normal.jpg",
      "id" : 23945498,
      "verified" : false
    }
  },
  "id" : 650695276420841472,
  "created_at" : "2015-10-04 15:33:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Gibson",
      "screen_name" : "dgpixphoto",
      "indices" : [ 3, 14 ],
      "id_str" : "114216659",
      "id" : 114216659
    }, {
      "name" : "NT - Murlough NNR",
      "screen_name" : "NtMurlough",
      "indices" : [ 29, 40 ],
      "id_str" : "3346385945",
      "id" : 3346385945
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dgpixphoto\/status\/643038267659681792\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/xaWZd2S28P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COyH5T3WsAAoxsi.jpg",
      "id_str" : "643038265461878784",
      "id" : 643038265461878784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COyH5T3WsAAoxsi.jpg",
      "sizes" : [ {
        "h" : 620,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2007,
        "resize" : "fit",
        "w" : 3317
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xaWZd2S28P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650694683442741248",
  "text" : "RT @dgpixphoto: wild pony of @NtMurlough http:\/\/t.co\/xaWZd2S28P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NT - Murlough NNR",
        "screen_name" : "NtMurlough",
        "indices" : [ 13, 24 ],
        "id_str" : "3346385945",
        "id" : 3346385945
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dgpixphoto\/status\/643038267659681792\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/xaWZd2S28P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COyH5T3WsAAoxsi.jpg",
        "id_str" : "643038265461878784",
        "id" : 643038265461878784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COyH5T3WsAAoxsi.jpg",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2007,
          "resize" : "fit",
          "w" : 3317
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xaWZd2S28P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643038267659681792",
    "text" : "wild pony of @NtMurlough http:\/\/t.co\/xaWZd2S28P",
    "id" : 643038267659681792,
    "created_at" : "2015-09-13 12:27:24 +0000",
    "user" : {
      "name" : "Danny Gibson",
      "screen_name" : "dgpixphoto",
      "protected" : false,
      "id_str" : "114216659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711610343689166848\/WKIBXWq-_normal.jpg",
      "id" : 114216659,
      "verified" : false
    }
  },
  "id" : 650694683442741248,
  "created_at" : "2015-10-04 15:31:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650481087852998656",
  "text" : "RT @BrianRathbone: Sometimes you just have to ask yourself, What would a tree do?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650476947693301760",
    "text" : "Sometimes you just have to ask yourself, What would a tree do?",
    "id" : 650476947693301760,
    "created_at" : "2015-10-04 01:06:04 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 650481087852998656,
  "created_at" : "2015-10-04 01:22:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/650420584602542081\/video\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/LES6jdk2EB",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/650420122448986116\/pu\/img\/T3LCOjx2yRKXngU6.jpg",
      "id_str" : "650420122448986116",
      "id" : 650420122448986116,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/650420122448986116\/pu\/img\/T3LCOjx2yRKXngU6.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LES6jdk2EB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650421652027777025",
  "text" : "RT @ravenmaster1: Raven Merlina enjoying the midday sun earlier today http:\/\/t.co\/LES6jdk2EB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/650420584602542081\/video\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/LES6jdk2EB",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/650420122448986116\/pu\/img\/T3LCOjx2yRKXngU6.jpg",
        "id_str" : "650420122448986116",
        "id" : 650420122448986116,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/650420122448986116\/pu\/img\/T3LCOjx2yRKXngU6.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LES6jdk2EB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650420584602542081",
    "text" : "Raven Merlina enjoying the midday sun earlier today http:\/\/t.co\/LES6jdk2EB",
    "id" : 650420584602542081,
    "created_at" : "2015-10-03 21:22:06 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 650421652027777025,
  "created_at" : "2015-10-03 21:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wisdom",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650411630400933888",
  "geo" : { },
  "id_str" : "650416336049426434",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind 2nd line = enlightenment : ) #wisdom",
  "id" : 650416336049426434,
  "in_reply_to_status_id" : 650411630400933888,
  "created_at" : "2015-10-03 21:05:13 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650415940522348544",
  "text" : "RT @ZachsMind: Most of the universe would kill us in seconds if we were exposed. When you get perspective, there is no reason for us to kil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650411630400933888",
    "text" : "Most of the universe would kill us in seconds if we were exposed. When you get perspective, there is no reason for us to kill each other.",
    "id" : 650411630400933888,
    "created_at" : "2015-10-03 20:46:31 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 650415940522348544,
  "created_at" : "2015-10-03 21:03:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650415707700764672",
  "text" : "RT @ZachsMind: This ain't rocket surgery people. Stop killing each other.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650413657512280064",
    "text" : "This ain't rocket surgery people. Stop killing each other.",
    "id" : 650413657512280064,
    "created_at" : "2015-10-03 20:54:34 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 650415707700764672,
  "created_at" : "2015-10-03 21:02:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650382479614963713",
  "geo" : { },
  "id_str" : "650401184495337472",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 oh what a face!! lol",
  "id" : 650401184495337472,
  "in_reply_to_status_id" : 650382479614963713,
  "created_at" : "2015-10-03 20:05:00 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/nBZPh6WxDk",
      "expanded_url" : "https:\/\/twitter.com\/Ah_Science\/status\/650340803387215872",
      "display_url" : "twitter.com\/Ah_Science\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650343368510341120",
  "text" : "interesting! https:\/\/t.co\/nBZPh6WxDk",
  "id" : 650343368510341120,
  "created_at" : "2015-10-03 16:15:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/26kZ7DjBQE",
      "expanded_url" : "https:\/\/twitter.com\/AmandaSinco\/status\/646447738457096192",
      "display_url" : "twitter.com\/AmandaSinco\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650331347370803201",
  "text" : "sweet pic. pekins? domestic?? (hope they're not dumped ducks...) https:\/\/t.co\/26kZ7DjBQE",
  "id" : 650331347370803201,
  "created_at" : "2015-10-03 15:27:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650329008261988352",
  "text" : "RT @jorymicah: To say that all men are inherently born leaders and all women are inherently born followers is to deny the reality of person\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650326128306077696",
    "text" : "To say that all men are inherently born leaders and all women are inherently born followers is to deny the reality of personalities.",
    "id" : 650326128306077696,
    "created_at" : "2015-10-03 15:06:46 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 650329008261988352,
  "created_at" : "2015-10-03 15:18:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650036500999090176",
  "text" : "but she is getting livelier as weeks go by. still has nausea on\/off, still anxious and attached to me.",
  "id" : 650036500999090176,
  "created_at" : "2015-10-02 19:55:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650035709789761536",
  "text" : "soo.. her current iron is 105 (30-105) .. dont have a prev iron level to compare but her ferritin went down from 28 to 21. #hashimotos",
  "id" : 650035709789761536,
  "created_at" : "2015-10-02 19:52:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/OrMRTbszMU",
      "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/649937472810565633",
      "display_url" : "twitter.com\/NorthWoodsRanc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649980887745101824",
  "text" : "adorable!! https:\/\/t.co\/OrMRTbszMU",
  "id" : 649980887745101824,
  "created_at" : "2015-10-02 16:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Some Copywriter",
      "screen_name" : "testicleas",
      "indices" : [ 3, 14 ],
      "id_str" : "82062932",
      "id" : 82062932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649980475872780289",
  "text" : "RT @testicleas: Life is like a box of fuck all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649950589124743168",
    "text" : "Life is like a box of fuck all.",
    "id" : 649950589124743168,
    "created_at" : "2015-10-02 14:14:30 +0000",
    "user" : {
      "name" : "Some Copywriter",
      "screen_name" : "testicleas",
      "protected" : false,
      "id_str" : "82062932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644742058129788928\/YPWGsDif_normal.jpg",
      "id" : 82062932,
      "verified" : false
    }
  },
  "id" : 649980475872780289,
  "created_at" : "2015-10-02 16:13:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649961461050159104",
  "geo" : { },
  "id_str" : "649979241887629312",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe : (",
  "id" : 649979241887629312,
  "in_reply_to_status_id" : 649961461050159104,
  "created_at" : "2015-10-02 16:08:21 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "indices" : [ 3, 18 ],
      "id_str" : "32522055",
      "id" : 32522055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/SRKpnSXr0t",
      "expanded_url" : "https:\/\/twitter.com\/daddyjew\/status\/649938458803335168",
      "display_url" : "twitter.com\/daddyjew\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649939818575736832",
  "text" : "RT @Kris_Sacrebleu: \uD83D\uDC4B\uD83C\uDFFBhi....mine too. Weird.  https:\/\/t.co\/SRKpnSXr0t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/SRKpnSXr0t",
        "expanded_url" : "https:\/\/twitter.com\/daddyjew\/status\/649938458803335168",
        "display_url" : "twitter.com\/daddyjew\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649939374247772160",
    "text" : "\uD83D\uDC4B\uD83C\uDFFBhi....mine too. Weird.  https:\/\/t.co\/SRKpnSXr0t",
    "id" : 649939374247772160,
    "created_at" : "2015-10-02 13:29:56 +0000",
    "user" : {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "protected" : false,
      "id_str" : "32522055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797097618245459968\/x-mwuPEt_normal.jpg",
      "id" : 32522055,
      "verified" : false
    }
  },
  "id" : 649939818575736832,
  "created_at" : "2015-10-02 13:31:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/649711764985262080\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/1gaU5qe1vp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQQ9ZAuXAAA2bgK.jpg",
      "id_str" : "649711746148663296",
      "id" : 649711746148663296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQQ9ZAuXAAA2bgK.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1gaU5qe1vp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649712259288182784",
  "text" : "RT @ravenmaster1: Please sir, can I have some more\uD83D\uDE14 http:\/\/t.co\/1gaU5qe1vp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/649711764985262080\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/1gaU5qe1vp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQQ9ZAuXAAA2bgK.jpg",
        "id_str" : "649711746148663296",
        "id" : 649711746148663296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQQ9ZAuXAAA2bgK.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1gaU5qe1vp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649711764985262080",
    "text" : "Please sir, can I have some more\uD83D\uDE14 http:\/\/t.co\/1gaU5qe1vp",
    "id" : 649711764985262080,
    "created_at" : "2015-10-01 22:25:30 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 649712259288182784,
  "created_at" : "2015-10-01 22:27:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/5zE7XN8b7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrvUYWUAA_rY4.jpg",
      "id_str" : "649621969428697088",
      "id" : 649621969428697088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrvUYWUAA_rY4.jpg",
      "sizes" : [ {
        "h" : 753,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5zE7XN8b7H"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/5zE7XN8b7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrvWRWcAAr3Eo.jpg",
      "id_str" : "649621969936216064",
      "id" : 649621969936216064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrvWRWcAAr3Eo.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5zE7XN8b7H"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/5zE7XN8b7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrvYMXAAEBkZm.jpg",
      "id_str" : "649621970452152321",
      "id" : 649621970452152321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrvYMXAAEBkZm.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5zE7XN8b7H"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/5zE7XN8b7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrv7SWoAAdqfn.jpg",
      "id_str" : "649621979872534528",
      "id" : 649621979872534528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrv7SWoAAdqfn.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5zE7XN8b7H"
    } ],
    "hashtags" : [ {
      "text" : "YoureNotMoving",
      "indices" : [ 38, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649656908060737536",
  "text" : "RT @newlandfarm: Mrs Hooper Roadblock #YoureNotMoving http:\/\/t.co\/5zE7XN8b7H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/5zE7XN8b7H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrvUYWUAA_rY4.jpg",
        "id_str" : "649621969428697088",
        "id" : 649621969428697088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrvUYWUAA_rY4.jpg",
        "sizes" : [ {
          "h" : 753,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 441,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5zE7XN8b7H"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/5zE7XN8b7H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrvWRWcAAr3Eo.jpg",
        "id_str" : "649621969936216064",
        "id" : 649621969936216064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrvWRWcAAr3Eo.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5zE7XN8b7H"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/5zE7XN8b7H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrvYMXAAEBkZm.jpg",
        "id_str" : "649621970452152321",
        "id" : 649621970452152321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrvYMXAAEBkZm.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5zE7XN8b7H"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/649622158977703936\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/5zE7XN8b7H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPrv7SWoAAdqfn.jpg",
        "id_str" : "649621979872534528",
        "id" : 649621979872534528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPrv7SWoAAdqfn.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5zE7XN8b7H"
      } ],
      "hashtags" : [ {
        "text" : "YoureNotMoving",
        "indices" : [ 21, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649622158977703936",
    "text" : "Mrs Hooper Roadblock #YoureNotMoving http:\/\/t.co\/5zE7XN8b7H",
    "id" : 649622158977703936,
    "created_at" : "2015-10-01 16:29:26 +0000",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 649656908060737536,
  "created_at" : "2015-10-01 18:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Blog",
      "screen_name" : "BernieBlogorg",
      "indices" : [ 3, 17 ],
      "id_str" : "3759052815",
      "id" : 3759052815
    }, {
      "name" : "Bernie Blog",
      "screen_name" : "BernieBlogorg",
      "indices" : [ 89, 103 ],
      "id_str" : "3759052815",
      "id" : 3759052815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/tCwY65TfUk",
      "expanded_url" : "https:\/\/bernieblog.org\/martin-luther-king-democratic-socialist\/",
      "display_url" : "bernieblog.org\/martin-luther-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649650888496295937",
  "text" : "RT @BernieBlogorg: Martin Luther King - Democratic Socialist https:\/\/t.co\/tCwY65TfUk via @BernieBlogorg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Blog",
        "screen_name" : "BernieBlogorg",
        "indices" : [ 70, 84 ],
        "id_str" : "3759052815",
        "id" : 3759052815
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/tCwY65TfUk",
        "expanded_url" : "https:\/\/bernieblog.org\/martin-luther-king-democratic-socialist\/",
        "display_url" : "bernieblog.org\/martin-luther-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649520894298165248",
    "text" : "Martin Luther King - Democratic Socialist https:\/\/t.co\/tCwY65TfUk via @BernieBlogorg",
    "id" : 649520894298165248,
    "created_at" : "2015-10-01 09:47:03 +0000",
    "user" : {
      "name" : "Bernie Blog",
      "screen_name" : "BernieBlogorg",
      "protected" : false,
      "id_str" : "3759052815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646992435424309248\/LAaMOZbz_normal.jpg",
      "id" : 3759052815,
      "verified" : false
    }
  },
  "id" : 649650888496295937,
  "created_at" : "2015-10-01 18:23:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649621047420014593",
  "text" : "so far.. good b-12 (went up since july), good thyroid except anti-bodies, good iron, low iron stores. #hashimotos",
  "id" : 649621047420014593,
  "created_at" : "2015-10-01 16:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iloveher",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649620760248614912",
  "text" : "DD's PCP calls us while on way to vacation with lab results. she's very dedicated. #iloveher",
  "id" : 649620760248614912,
  "created_at" : "2015-10-01 16:23:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Fox",
      "screen_name" : "kfury",
      "indices" : [ 3, 9 ],
      "id_str" : "785",
      "id" : 785
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/enniscath\/status\/531319255846125568\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/DzfNMixYrF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1-gDEeIEAAJnFe.jpg",
      "id_str" : "531319255653158912",
      "id" : 531319255653158912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1-gDEeIEAAJnFe.jpg",
      "sizes" : [ {
        "h" : 636,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 636,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/DzfNMixYrF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649608266469777408",
  "text" : "RT @kfury: \"Prof. Mandelbrot? It's Dr. Schr\u00F6dinger. I seem to have a problem.\" http:\/\/t.co\/DzfNMixYrF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/enniscath\/status\/531319255846125568\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/DzfNMixYrF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1-gDEeIEAAJnFe.jpg",
        "id_str" : "531319255653158912",
        "id" : 531319255653158912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1-gDEeIEAAJnFe.jpg",
        "sizes" : [ {
          "h" : 636,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/DzfNMixYrF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531873740200484864",
    "text" : "\"Prof. Mandelbrot? It's Dr. Schr\u00F6dinger. I seem to have a problem.\" http:\/\/t.co\/DzfNMixYrF",
    "id" : 531873740200484864,
    "created_at" : "2014-11-10 18:19:16 +0000",
    "user" : {
      "name" : "Kevin Fox",
      "screen_name" : "kfury",
      "protected" : false,
      "id_str" : "785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593841586573692930\/XY2_NLrT_normal.jpg",
      "id" : 785,
      "verified" : true
    }
  },
  "id" : 649608266469777408,
  "created_at" : "2015-10-01 15:34:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/649599009292722176\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/v2903lsohF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQPW2sCWsAAEzcq.png",
      "id_str" : "649599006293798912",
      "id" : 649599006293798912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQPW2sCWsAAEzcq.png",
      "sizes" : [ {
        "h" : 186,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/v2903lsohF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/8iDExPuVzn",
      "expanded_url" : "http:\/\/www.godofevolution.com\/thoughts-on-ken-ham-biblical-inerrancy-and-batman\/?_ts=1443711446#comment-927746957",
      "display_url" : "godofevolution.com\/thoughts-on-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649599009292722176",
  "text" : "inerrant bible comment &gt; Thoughts on Ken Ham, biblical inerrancy and Batman http:\/\/t.co\/8iDExPuVzn http:\/\/t.co\/v2903lsohF",
  "id" : 649599009292722176,
  "created_at" : "2015-10-01 14:57:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]