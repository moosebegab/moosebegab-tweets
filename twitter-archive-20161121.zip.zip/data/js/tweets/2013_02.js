Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307266316019068928",
  "text" : "no more war. take care of our ppl here (food, health, education) w that money!",
  "id" : 307266316019068928,
  "created_at" : "2013-02-28 23:09:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Common Dreams",
      "screen_name" : "commondreams",
      "indices" : [ 3, 16 ],
      "id_str" : "14296273",
      "id" : 14296273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/r9K8TWxYn9",
      "expanded_url" : "http:\/\/ow.ly\/i8SOW",
      "display_url" : "ow.ly\/i8SOW"
    } ]
  },
  "geo" : { },
  "id_str" : "307265874102984704",
  "text" : "RT @commondreams: Winning Medicare for All? \"I Like Our Chances\" http:\/\/t.co\/r9K8TWxYn9 #singlepayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 70, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/r9K8TWxYn9",
        "expanded_url" : "http:\/\/ow.ly\/i8SOW",
        "display_url" : "ow.ly\/i8SOW"
      } ]
    },
    "geo" : { },
    "id_str" : "307226298797928448",
    "text" : "Winning Medicare for All? \"I Like Our Chances\" http:\/\/t.co\/r9K8TWxYn9 #singlepayer",
    "id" : 307226298797928448,
    "created_at" : "2013-02-28 20:30:32 +0000",
    "user" : {
      "name" : "Common Dreams",
      "screen_name" : "commondreams",
      "protected" : false,
      "id_str" : "14296273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501442647722954752\/o2VYe4DO_normal.jpeg",
      "id" : 14296273,
      "verified" : false
    }
  },
  "id" : 307265874102984704,
  "created_at" : "2013-02-28 23:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307264448169664514",
  "text" : "RT @knittingknots: Bosses Refuse To Call Ambulance For Worker Severely Burned On The Job, He Dies | The Center for Public... http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/c9svW9QyNG",
        "expanded_url" : "http:\/\/tmblr.co\/ZwRd3yfDNojS",
        "display_url" : "tmblr.co\/ZwRd3yfDNojS"
      } ]
    },
    "geo" : { },
    "id_str" : "307263855829061632",
    "text" : "Bosses Refuse To Call Ambulance For Worker Severely Burned On The Job, He Dies | The Center for Public... http:\/\/t.co\/c9svW9QyNG",
    "id" : 307263855829061632,
    "created_at" : "2013-02-28 22:59:46 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 307264448169664514,
  "created_at" : "2013-02-28 23:02:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307261913568518144",
  "geo" : { },
  "id_str" : "307263395894276096",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 she was sooo angry!",
  "id" : 307263395894276096,
  "in_reply_to_status_id" : 307261913568518144,
  "created_at" : "2013-02-28 22:57:56 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307262094116536320",
  "geo" : { },
  "id_str" : "307262625501298688",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 darn.. missed that. DD took over tv.",
  "id" : 307262625501298688,
  "in_reply_to_status_id" : 307262094116536320,
  "created_at" : "2013-02-28 22:54:53 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307253999705391104",
  "text" : "and requirements to graduate should not include GYM!",
  "id" : 307253999705391104,
  "created_at" : "2013-02-28 22:20:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307253774232190976",
  "text" : "...and high schools do not need to be locked and run like prison!",
  "id" : 307253774232190976,
  "created_at" : "2013-02-28 22:19:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307253215592857600",
  "text" : "society would be better off w all ppl getting the education they are suited for.",
  "id" : 307253215592857600,
  "created_at" : "2013-02-28 22:17:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307252493459533825",
  "text" : "our whole school system needs to be changed...",
  "id" : 307252493459533825,
  "created_at" : "2013-02-28 22:14:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307252232762572800",
  "text" : "college education should be free...",
  "id" : 307252232762572800,
  "created_at" : "2013-02-28 22:13:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 0, 15 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307242444297211907",
  "geo" : { },
  "id_str" : "307244586521206784",
  "in_reply_to_user_id" : 466879335,
  "text" : "@ThatOtherChris granted.. but the whole idea of our military is to prepare for war.. fight, kill..",
  "id" : 307244586521206784,
  "in_reply_to_status_id" : 307242444297211907,
  "created_at" : "2013-02-28 21:43:12 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 2, 17 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307237259550269440",
  "geo" : { },
  "id_str" : "307239872043839488",
  "in_reply_to_user_id" : 466879335,
  "text" : ". @ThatOtherChris the military itself is just bad.. its brainwashing.. like child abuse.",
  "id" : 307239872043839488,
  "in_reply_to_status_id" : 307237259550269440,
  "created_at" : "2013-02-28 21:24:28 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307235730218942464",
  "geo" : { },
  "id_str" : "307238986030645248",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 thanks.. found it! (HLN channel on Direct TV)",
  "id" : 307238986030645248,
  "in_reply_to_status_id" : 307235730218942464,
  "created_at" : "2013-02-28 21:20:57 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307231122927022080",
  "geo" : { },
  "id_str" : "307235263258697728",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 what channnel are you watching? i was on trutv but its not showing #jodiarias now. (im in NY)",
  "id" : 307235263258697728,
  "in_reply_to_status_id" : 307231122927022080,
  "created_at" : "2013-02-28 21:06:09 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307234270387265536",
  "text" : "RT @ChristianDems: 1 Cor 13:13 And now abide faith, hope, love, these three; but the greatest of these is love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307234114753413120",
    "text" : "1 Cor 13:13 And now abide faith, hope, love, these three; but the greatest of these is love.",
    "id" : 307234114753413120,
    "created_at" : "2013-02-28 21:01:35 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 307234270387265536,
  "created_at" : "2013-02-28 21:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307205645260709890",
  "text" : "RT @MimiMadeira1: #JodiArias for dramatic effect I would love to see the prosecutor bring out a pig carcass and stab it 29 times to show ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307205042665041920",
    "text" : "#JodiArias for dramatic effect I would love to see the prosecutor bring out a pig carcass and stab it 29 times to show how long it takes",
    "id" : 307205042665041920,
    "created_at" : "2013-02-28 19:06:04 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 307205645260709890,
  "created_at" : "2013-02-28 19:08:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307205605842640896",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 apparently they were ex bf\/gf? is that the motive? #jodiarias",
  "id" : 307205605842640896,
  "created_at" : "2013-02-28 19:08:18 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307193809421348864",
  "geo" : { },
  "id_str" : "307195492842999808",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 wow.. the idea of the pic of him alive and minutes later bleeding to death..",
  "id" : 307195492842999808,
  "in_reply_to_status_id" : 307193809421348864,
  "created_at" : "2013-02-28 18:28:07 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307193483934965760",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 i was wondering why he was going on about these bathroom photos.. just read the wiki about his death.. whoa!  #jodiarias",
  "id" : 307193483934965760,
  "created_at" : "2013-02-28 18:20:08 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 3, 19 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307185829313392640",
  "text" : "RT @AlterEgoTrip_Se: \"Society prepares the crime; the criminal commits it.\" (an electronic fortune cookie)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307185575985819648",
    "text" : "\"Society prepares the crime; the criminal commits it.\" (an electronic fortune cookie)",
    "id" : 307185575985819648,
    "created_at" : "2013-02-28 17:48:43 +0000",
    "user" : {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "protected" : false,
      "id_str" : "344209049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779194958410579968\/qUDtmyLs_normal.jpg",
      "id" : 344209049,
      "verified" : false
    }
  },
  "id" : 307185829313392640,
  "created_at" : "2013-02-28 17:49:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bit Rebels",
      "screen_name" : "bitrebels",
      "indices" : [ 98, 108 ],
      "id_str" : "45369648",
      "id" : 45369648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/sodv1l95qr",
      "expanded_url" : "http:\/\/www.bitrebels.com\/apps\/urine-analysis-smartphone-app-camera\/",
      "display_url" : "bitrebels.com\/apps\/urine-ana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307183448232173568",
  "text" : "Smartphone App Provides An Accurate Urine Analysis Using Your Camera - http:\/\/t.co\/sodv1l95qr via @bitrebels",
  "id" : 307183448232173568,
  "created_at" : "2013-02-28 17:40:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307177600428679168",
  "geo" : { },
  "id_str" : "307181203046408193",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny its a sign of affection..lol",
  "id" : 307181203046408193,
  "in_reply_to_status_id" : 307177600428679168,
  "created_at" : "2013-02-28 17:31:20 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 78, 87 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nonconformist",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307173367365132290",
  "geo" : { },
  "id_str" : "307175101592395778",
  "in_reply_to_user_id" : 417054858,
  "text" : ". @Odd__Mama__Out normal being a good soldier following all the rules... UGH! @AniKnits #nonconformist",
  "id" : 307175101592395778,
  "in_reply_to_status_id" : 307173367365132290,
  "created_at" : "2013-02-28 17:07:05 +0000",
  "in_reply_to_screen_name" : "VidaConSol",
  "in_reply_to_user_id_str" : "417054858",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307153381590458370",
  "geo" : { },
  "id_str" : "307174375214424064",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny cuz im a little bird that likes to come to your window, peek in and chirp to you ; )",
  "id" : 307174375214424064,
  "in_reply_to_status_id" : 307153381590458370,
  "created_at" : "2013-02-28 17:04:12 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Untold Press",
      "screen_name" : "UntoldPress",
      "indices" : [ 3, 15 ],
      "id_str" : "499136312",
      "id" : 499136312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bloggers",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "giveaways",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307161156697612289",
  "text" : "RT @UntoldPress: Swag packs available to #bloggers for #giveaways! Includes magnets, bookmarks, postcards, note card  https:\/\/t.co\/zlO1c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bloggers",
        "indices" : [ 24, 33 ]
      }, {
        "text" : "giveaways",
        "indices" : [ 38, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/zlO1cmF5t0",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=503710833003284&set=a.354651397909229.83524.332870626753973&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307160670137360385",
    "text" : "Swag packs available to #bloggers for #giveaways! Includes magnets, bookmarks, postcards, note card  https:\/\/t.co\/zlO1cmF5t0 Pls RT",
    "id" : 307160670137360385,
    "created_at" : "2013-02-28 16:09:45 +0000",
    "user" : {
      "name" : "Untold Press",
      "screen_name" : "UntoldPress",
      "protected" : false,
      "id_str" : "499136312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844006349\/untold_logo_normal.jpg",
      "id" : 499136312,
      "verified" : false
    }
  },
  "id" : 307161156697612289,
  "created_at" : "2013-02-28 16:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "indices" : [ 3, 19 ],
      "id_str" : "362487813",
      "id" : 362487813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307159606659002368",
  "text" : "RT @MysteriousPress: HUGE two-book Thurs giveaway! Reply\/RT by 3pm EST to enter to win...DADDY LOVE and THE CORN MAIDEN AND OTHER NIGHTM ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joyce Carol Oates",
        "screen_name" : "JoyceCarolOates",
        "indices" : [ 123, 139 ],
        "id_str" : "845743333",
        "id" : 845743333
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307158799045758976",
    "text" : "HUGE two-book Thurs giveaway! Reply\/RT by 3pm EST to enter to win...DADDY LOVE and THE CORN MAIDEN AND OTHER NIGHTMARES by @JoyceCarolOates!",
    "id" : 307158799045758976,
    "created_at" : "2013-02-28 16:02:19 +0000",
    "user" : {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "protected" : false,
      "id_str" : "362487813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1514323844\/mysterious_normal.jpg",
      "id" : 362487813,
      "verified" : false
    }
  },
  "id" : 307159606659002368,
  "created_at" : "2013-02-28 16:05:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 0, 12 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 31, 43 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Tim Spalding",
      "screen_name" : "librarythingtim",
      "indices" : [ 44, 60 ],
      "id_str" : "5917472",
      "id" : 5917472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307155486665482240",
  "text" : "@HelloPoodle ty.. makes sense. @VirgoJohnny @librarythingtim",
  "id" : 307155486665482240,
  "created_at" : "2013-02-28 15:49:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307153381590458370",
  "geo" : { },
  "id_str" : "307154744894423040",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny we're all just trying to make sense of this crazy world...",
  "id" : 307154744894423040,
  "in_reply_to_status_id" : 307153381590458370,
  "created_at" : "2013-02-28 15:46:12 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307153381590458370",
  "geo" : { },
  "id_str" : "307154657132810240",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i butt in becuz isnt that what twitter is about? communicating? sharing ideas?",
  "id" : 307154657132810240,
  "in_reply_to_status_id" : 307153381590458370,
  "created_at" : "2013-02-28 15:45:51 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307153381590458370",
  "geo" : { },
  "id_str" : "307154328974680064",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i wouldnt follow you if I didnt find something about you that resonates w me.",
  "id" : 307154328974680064,
  "in_reply_to_status_id" : 307153381590458370,
  "created_at" : "2013-02-28 15:44:33 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Tim Spalding",
      "screen_name" : "librarythingtim",
      "indices" : [ 90, 106 ],
      "id_str" : "5917472",
      "id" : 5917472
    }, {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 107, 119 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307151761024626690",
  "geo" : { },
  "id_str" : "307153107815657472",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny why do you get so riled when ppl trying to discuss w you? understand yr POV? @librarythingtim @HelloPoodle",
  "id" : 307153107815657472,
  "in_reply_to_status_id" : 307151761024626690,
  "created_at" : "2013-02-28 15:39:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "Ray Goodwin",
      "screen_name" : "sonoranconnect",
      "indices" : [ 18, 33 ],
      "id_str" : "110171420",
      "id" : 110171420
    }, {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 131, 140 ],
      "id_str" : "17341213",
      "id" : 17341213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nature",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7FstygPGcG",
      "expanded_url" : "http:\/\/bit.ly\/Wn4gLI",
      "display_url" : "bit.ly\/Wn4gLI"
    } ]
  },
  "geo" : { },
  "id_str" : "307151649384833024",
  "text" : "RT @DawnFine: Via @sonoranconnect 44 of Americas Last Wild Buffalo Shot Dead Yards from Yellowstone http:\/\/t.co\/7FstygPGcG #Nature @DawnFine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ray Goodwin",
        "screen_name" : "sonoranconnect",
        "indices" : [ 4, 19 ],
        "id_str" : "110171420",
        "id" : 110171420
      }, {
        "name" : "Dawn",
        "screen_name" : "DawnFine",
        "indices" : [ 117, 126 ],
        "id_str" : "17341213",
        "id" : 17341213
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/7FstygPGcG",
        "expanded_url" : "http:\/\/bit.ly\/Wn4gLI",
        "display_url" : "bit.ly\/Wn4gLI"
      } ]
    },
    "geo" : { },
    "id_str" : "307150856447475712",
    "text" : "Via @sonoranconnect 44 of Americas Last Wild Buffalo Shot Dead Yards from Yellowstone http:\/\/t.co\/7FstygPGcG #Nature @DawnFine",
    "id" : 307150856447475712,
    "created_at" : "2013-02-28 15:30:45 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 307151649384833024,
  "created_at" : "2013-02-28 15:33:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307149462642511872",
  "text" : "RT @JALpalyul: Karma is nothing other than cause and effect.  That\u2019s all it is.  It\u2019s not somebody up there making check marks in a book.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307120796676014080",
    "text" : "Karma is nothing other than cause and effect.  That\u2019s all it is.  It\u2019s not somebody up there making check marks in a book.",
    "id" : 307120796676014080,
    "created_at" : "2013-02-28 13:31:18 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 307149462642511872,
  "created_at" : "2013-02-28 15:25:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "indices" : [ 3, 16 ],
      "id_str" : "16744783",
      "id" : 16744783
    }, {
      "name" : "Mark Kelso",
      "screen_name" : "audible",
      "indices" : [ 58, 66 ],
      "id_str" : "1579651",
      "id" : 1579651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307149360423124993",
  "text" : "RT @LisaTBergren: I'm listening to the dystopian WOOL, on @Audible. It's really good...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Kelso",
        "screen_name" : "audible",
        "indices" : [ 40, 48 ],
        "id_str" : "1579651",
        "id" : 1579651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307145001962459136",
    "text" : "I'm listening to the dystopian WOOL, on @Audible. It's really good...",
    "id" : 307145001962459136,
    "created_at" : "2013-02-28 15:07:29 +0000",
    "user" : {
      "name" : "Lisa Tawn Bergren",
      "screen_name" : "LisaTBergren",
      "protected" : false,
      "id_str" : "16744783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694980555096457216\/ApJGMyxi_normal.jpg",
      "id" : 16744783,
      "verified" : false
    }
  },
  "id" : 307149360423124993,
  "created_at" : "2013-02-28 15:24:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307142853694455809",
  "geo" : { },
  "id_str" : "307146892817616898",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time original sin is something that never clicked w me.. or hell..",
  "id" : 307146892817616898,
  "in_reply_to_status_id" : 307142853694455809,
  "created_at" : "2013-02-28 15:15:00 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/spBfBo4CyK",
      "expanded_url" : "http:\/\/www.whatthehellbook.com\/2012\/02\/23\/were-we-born-sinners\/",
      "display_url" : "whatthehellbook.com\/2012\/02\/23\/wer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307142476572008448",
  "text" : "Were We Born Sinners? http:\/\/t.co\/spBfBo4CyK",
  "id" : 307142476572008448,
  "created_at" : "2013-02-28 14:57:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 11, 27 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306906587619020802",
  "geo" : { },
  "id_str" : "306908148839632896",
  "in_reply_to_user_id" : 341002490,
  "text" : "@Msunbeams @rachelheldevans wth??",
  "id" : 306908148839632896,
  "in_reply_to_status_id" : 306906587619020802,
  "created_at" : "2013-02-27 23:26:19 +0000",
  "in_reply_to_screen_name" : "_bekkaleigh",
  "in_reply_to_user_id_str" : "341002490",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 50, 63 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horror",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306906098105982976",
  "text" : "I just bought: 'Heart-Shaped Box' by Joe Hill via @amazonkindle - curr 1.99 #horror",
  "id" : 306906098105982976,
  "created_at" : "2013-02-27 23:18:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 59, 72 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/IsZuHUwxf2",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B00902U0C2\/ref=cm_sw_r_tw_ask_F6d9F.0JFGKFM",
      "display_url" : "amazon.com\/dp\/B00902U0C2\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306905522974646272",
  "text" : "I just bought: 'Marines (Crimson Worlds)' by Jay Allan via @amazonkindle - curr 99 cents #scifi http:\/\/t.co\/IsZuHUwxf2",
  "id" : 306905522974646272,
  "created_at" : "2013-02-27 23:15:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Soulseeds",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/N54m9xT0cP",
      "expanded_url" : "http:\/\/tinyurl.com\/9bdp2yk",
      "display_url" : "tinyurl.com\/9bdp2yk"
    } ]
  },
  "geo" : { },
  "id_str" : "306890116754964480",
  "text" : "RT @Soulseedzforall: I am what I choose to become. #Soulseeds http:\/\/t.co\/N54m9xT0cP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Soulseeds",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/N54m9xT0cP",
        "expanded_url" : "http:\/\/tinyurl.com\/9bdp2yk",
        "display_url" : "tinyurl.com\/9bdp2yk"
      } ]
    },
    "geo" : { },
    "id_str" : "306886265037537280",
    "text" : "I am what I choose to become. #Soulseeds http:\/\/t.co\/N54m9xT0cP",
    "id" : 306886265037537280,
    "created_at" : "2013-02-27 21:59:21 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 306890116754964480,
  "created_at" : "2013-02-27 22:14:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "indices" : [ 3, 12 ],
      "id_str" : "394134197",
      "id" : 394134197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/L8BoIB0WEA",
      "expanded_url" : "http:\/\/ow.ly\/i5XS3",
      "display_url" : "ow.ly\/i5XS3"
    } ]
  },
  "geo" : { },
  "id_str" : "306888823579738112",
  "text" : "RT @mfpenney: Manning's Right to a Speedy Trial Not Violated After 1,000 Days, Judge Rules - http:\/\/t.co\/L8BoIB0WEA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/L8BoIB0WEA",
        "expanded_url" : "http:\/\/ow.ly\/i5XS3",
        "display_url" : "ow.ly\/i5XS3"
      } ]
    },
    "geo" : { },
    "id_str" : "306887761397420032",
    "text" : "Manning's Right to a Speedy Trial Not Violated After 1,000 Days, Judge Rules - http:\/\/t.co\/L8BoIB0WEA",
    "id" : 306887761397420032,
    "created_at" : "2013-02-27 22:05:18 +0000",
    "user" : {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "protected" : false,
      "id_str" : "394134197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596470057\/DSCN0545_normal.jpg",
      "id" : 394134197,
      "verified" : false
    }
  },
  "id" : 306888823579738112,
  "created_at" : "2013-02-27 22:09:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ClearHealthCosts",
      "screen_name" : "chcosts",
      "indices" : [ 3, 11 ],
      "id_str" : "264180341",
      "id" : 264180341
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcosts",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/N9WPBqaJya",
      "expanded_url" : "http:\/\/ow.ly\/hZcDL",
      "display_url" : "ow.ly\/hZcDL"
    } ]
  },
  "geo" : { },
  "id_str" : "306877624096014336",
  "text" : "RT @chcosts: How much does an MRI cost? $295 or $8,000? Take a look at our blog post + price lists http:\/\/t.co\/N9WPBqaJya  #healthcosts  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthcosts",
        "indices" : [ 110, 122 ]
      }, {
        "text" : "BitterPill",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/N9WPBqaJya",
        "expanded_url" : "http:\/\/ow.ly\/hZcDL",
        "display_url" : "ow.ly\/hZcDL"
      } ]
    },
    "geo" : { },
    "id_str" : "306872663937282048",
    "text" : "How much does an MRI cost? $295 or $8,000? Take a look at our blog post + price lists http:\/\/t.co\/N9WPBqaJya  #healthcosts #BitterPill",
    "id" : 306872663937282048,
    "created_at" : "2013-02-27 21:05:19 +0000",
    "user" : {
      "name" : "ClearHealthCosts",
      "screen_name" : "chcosts",
      "protected" : false,
      "id_str" : "264180341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461962690982727681\/wnvG7FeP_normal.jpeg",
      "id" : 264180341,
      "verified" : false
    }
  },
  "id" : 306877624096014336,
  "created_at" : "2013-02-27 21:25:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/L6b4xzC3oE",
      "expanded_url" : "http:\/\/www.viddler.com\/v\/70d1d214?secret=48017121",
      "display_url" : "viddler.com\/v\/70d1d214?sec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306877318486433793",
  "text" : "RT @DwayneReaves: High school basketball player passes ball to mentally challenged player on the other team: http:\/\/t.co\/L6b4xzC3oE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/L6b4xzC3oE",
        "expanded_url" : "http:\/\/www.viddler.com\/v\/70d1d214?secret=48017121",
        "display_url" : "viddler.com\/v\/70d1d214?sec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306876567630528512",
    "text" : "High school basketball player passes ball to mentally challenged player on the other team: http:\/\/t.co\/L6b4xzC3oE",
    "id" : 306876567630528512,
    "created_at" : "2013-02-27 21:20:49 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 306877318486433793,
  "created_at" : "2013-02-27 21:23:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/NM45NOxBXt",
      "expanded_url" : "http:\/\/bookwi.se\/buying-your-way-onto-the-bestsellers-list\/",
      "display_url" : "bookwi.se\/buying-your-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306877115758964736",
  "text" : "RT @adamrshields: Buying Your Way Onto the Bestseller's List http:\/\/t.co\/NM45NOxBXt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/NM45NOxBXt",
        "expanded_url" : "http:\/\/bookwi.se\/buying-your-way-onto-the-bestsellers-list\/",
        "display_url" : "bookwi.se\/buying-your-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306876815606173696",
    "text" : "Buying Your Way Onto the Bestseller's List http:\/\/t.co\/NM45NOxBXt",
    "id" : 306876815606173696,
    "created_at" : "2013-02-27 21:21:48 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 306877115758964736,
  "created_at" : "2013-02-27 21:23:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corvid",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/gr8OfnBgXD",
      "expanded_url" : "http:\/\/instagr.am\/p\/WPzi6-BH3K\/",
      "display_url" : "instagr.am\/p\/WPzi6-BH3K\/"
    } ]
  },
  "geo" : { },
  "id_str" : "306855705766395904",
  "text" : "RT @ducksandclucks: Schwoopie the crow and friends #corvid http:\/\/t.co\/gr8OfnBgXD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corvid",
        "indices" : [ 31, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/gr8OfnBgXD",
        "expanded_url" : "http:\/\/instagr.am\/p\/WPzi6-BH3K\/",
        "display_url" : "instagr.am\/p\/WPzi6-BH3K\/"
      } ]
    },
    "geo" : { },
    "id_str" : "306855483703173120",
    "text" : "Schwoopie the crow and friends #corvid http:\/\/t.co\/gr8OfnBgXD",
    "id" : 306855483703173120,
    "created_at" : "2013-02-27 19:57:03 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 306855705766395904,
  "created_at" : "2013-02-27 19:57:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xstrology",
      "screen_name" : "XSTROLOGY",
      "indices" : [ 20, 30 ],
      "id_str" : "130734452",
      "id" : 130734452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pisces",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306844218809262080",
  "geo" : { },
  "id_str" : "306851757022146560",
  "in_reply_to_user_id" : 130734452,
  "text" : "true for me..lol RT @XSTROLOGY #Pisces are admirable for their big hearts but they live in another world.",
  "id" : 306851757022146560,
  "in_reply_to_status_id" : 306844218809262080,
  "created_at" : "2013-02-27 19:42:14 +0000",
  "in_reply_to_screen_name" : "XSTROLOGY",
  "in_reply_to_user_id_str" : "130734452",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306848884024561664",
  "text" : "the van is gone now. i feel.. sad.",
  "id" : 306848884024561664,
  "created_at" : "2013-02-27 19:30:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306823084508332032",
  "text" : "i guess thats why i could never go with the idea of sin and fallen humanity. i see the beauty in humanity.",
  "id" : 306823084508332032,
  "created_at" : "2013-02-27 17:48:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306822697042726912",
  "text" : "when you say humanity sucks.. its an insult to those who show kindness.",
  "id" : 306822697042726912,
  "created_at" : "2013-02-27 17:46:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 3, 14 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TED2013",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/1EbNphhzD2",
      "expanded_url" : "http:\/\/bit.ly\/XCmHd9",
      "display_url" : "bit.ly\/XCmHd9"
    } ]
  },
  "geo" : { },
  "id_str" : "306819896078123008",
  "text" : "RT @MailOnline: VIDEO: 'Invisibility cloak' that makes objects DISAPPEAR behind it unveiled at #TED2013 http:\/\/t.co\/1EbNphhzD2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TED2013",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/1EbNphhzD2",
        "expanded_url" : "http:\/\/bit.ly\/XCmHd9",
        "display_url" : "bit.ly\/XCmHd9"
      } ]
    },
    "geo" : { },
    "id_str" : "306780810537758721",
    "text" : "VIDEO: 'Invisibility cloak' that makes objects DISAPPEAR behind it unveiled at #TED2013 http:\/\/t.co\/1EbNphhzD2",
    "id" : 306780810537758721,
    "created_at" : "2013-02-27 15:00:19 +0000",
    "user" : {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "protected" : false,
      "id_str" : "15438913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801023630226452480\/6LuyheVr_normal.jpg",
      "id" : 15438913,
      "verified" : true
    }
  },
  "id" : 306819896078123008,
  "created_at" : "2013-02-27 17:35:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306536643744124929",
  "geo" : { },
  "id_str" : "306546293960998913",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ohh so cute!",
  "id" : 306546293960998913,
  "in_reply_to_status_id" : 306536643744124929,
  "created_at" : "2013-02-26 23:28:26 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 24, 38 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/5rhjWRUurw",
      "expanded_url" : "http:\/\/charlesbivona.com\/michelle-bachmanns-sex-ed-class-at-oral-roberts-university-lgbt\/",
      "display_url" : "charlesbivona.com\/michelle-bachm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306524659300581377",
  "geo" : { },
  "id_str" : "306543185168048129",
  "in_reply_to_user_id" : 45254966,
  "text" : "umm... wow... crazy. MT @CharlesBivona Michelle Bachmann\u2019s Sex Ed. Class at Oral Roberts University http:\/\/t.co\/5rhjWRUurw",
  "id" : 306543185168048129,
  "in_reply_to_status_id" : 306524659300581377,
  "created_at" : "2013-02-26 23:16:05 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 2, 16 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "indices" : [ 72, 83 ],
      "id_str" : "598921658",
      "id" : 598921658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306517858400227328",
  "geo" : { },
  "id_str" : "306520784841621504",
  "in_reply_to_user_id" : 45254966,
  "text" : ". @CharlesBivona but it might help someone deemed unworthy! ((sarcasm)) @StrikeDebt",
  "id" : 306520784841621504,
  "in_reply_to_status_id" : 306517858400227328,
  "created_at" : "2013-02-26 21:47:04 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306503126981160960",
  "geo" : { },
  "id_str" : "306503425951162368",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth WTH?",
  "id" : 306503425951162368,
  "in_reply_to_status_id" : 306503126981160960,
  "created_at" : "2013-02-26 20:38:05 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/M1rfrVHKmk",
      "expanded_url" : "http:\/\/fb.me\/uGX7RbB4",
      "display_url" : "fb.me\/uGX7RbB4"
    } ]
  },
  "geo" : { },
  "id_str" : "306499850181160962",
  "text" : "RT @introvertmeetup: Teachers should not penalize introverts who have trouble speaking up in class  |  The Collegian http:\/\/t.co\/M1rfrVHKmk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/M1rfrVHKmk",
        "expanded_url" : "http:\/\/fb.me\/uGX7RbB4",
        "display_url" : "fb.me\/uGX7RbB4"
      } ]
    },
    "geo" : { },
    "id_str" : "306499140068724737",
    "text" : "Teachers should not penalize introverts who have trouble speaking up in class  |  The Collegian http:\/\/t.co\/M1rfrVHKmk",
    "id" : 306499140068724737,
    "created_at" : "2013-02-26 20:21:04 +0000",
    "user" : {
      "name" : "Social Introverts",
      "screen_name" : "proudintroverts",
      "protected" : false,
      "id_str" : "741558997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625876596486877184\/WZGimc1S_normal.png",
      "id" : 741558997,
      "verified" : false
    }
  },
  "id" : 306499850181160962,
  "created_at" : "2013-02-26 20:23:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    }, {
      "name" : "mylittlepogey",
      "screen_name" : "WhirlwindWisdom",
      "indices" : [ 16, 32 ],
      "id_str" : "388432699",
      "id" : 388432699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306499767679217664",
  "text" : "RT @MWM4444: RT @WhirlwindWisdom: My atheist son says, \"The meaning of life comes down to sacrifice for the vulnerable.\" || Wise &amp; c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mylittlepogey",
        "screen_name" : "WhirlwindWisdom",
        "indices" : [ 3, 19 ],
        "id_str" : "388432699",
        "id" : 388432699
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306499608719290369",
    "text" : "RT @WhirlwindWisdom: My atheist son says, \"The meaning of life comes down to sacrifice for the vulnerable.\" || Wise &amp; compassionate!",
    "id" : 306499608719290369,
    "created_at" : "2013-02-26 20:22:55 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 306499767679217664,
  "created_at" : "2013-02-26 20:23:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeaPuppets",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306495047468208128",
  "text" : "RT @MWM4444: Fear leads to anger. Anger leads to hate. Hate leads to the #TeaPuppets. Therefore learn to forgive \u2014 they REALLY know not  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeaPuppets",
        "indices" : [ 60, 71 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306494587160104960",
    "text" : "Fear leads to anger. Anger leads to hate. Hate leads to the #TeaPuppets. Therefore learn to forgive \u2014 they REALLY know not what they do. #p2",
    "id" : 306494587160104960,
    "created_at" : "2013-02-26 20:02:58 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 306495047468208128,
  "created_at" : "2013-02-26 20:04:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 3, 16 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306494838340206594",
  "text" : "RT @bigfishgames: 1M of the best jobs in America may go unfilled because only 1 in 10 schools teach students how to code. http:\/\/t.co\/OS ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Code.org",
        "screen_name" : "codeorg",
        "indices" : [ 130, 138 ],
        "id_str" : "850107536",
        "id" : 850107536
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/OS8jN379WQ",
        "expanded_url" : "http:\/\/bigfi.sh\/YyaJ05",
        "display_url" : "bigfi.sh\/YyaJ05"
      } ]
    },
    "geo" : { },
    "id_str" : "306494338614038529",
    "text" : "1M of the best jobs in America may go unfilled because only 1 in 10 schools teach students how to code. http:\/\/t.co\/OS8jN379WQ cc @codeorg",
    "id" : 306494338614038529,
    "created_at" : "2013-02-26 20:01:59 +0000",
    "user" : {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "protected" : false,
      "id_str" : "14124789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676860668365029376\/hAOsWfK1_normal.jpg",
      "id" : 14124789,
      "verified" : false
    }
  },
  "id" : 306494838340206594,
  "created_at" : "2013-02-26 20:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306492017981128706",
  "geo" : { },
  "id_str" : "306493657370988544",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny lol.. nah. he'd show her such immense love that would heal her from whatever crap holds her hostage.",
  "id" : 306493657370988544,
  "in_reply_to_status_id" : 306492017981128706,
  "created_at" : "2013-02-26 19:59:16 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306491144680919040",
  "geo" : { },
  "id_str" : "306492800873136128",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny from \"who you are\" to \"you are priceless\" I agree with but the rest of it stinks and I disagree with!",
  "id" : 306492800873136128,
  "in_reply_to_status_id" : 306491144680919040,
  "created_at" : "2013-02-26 19:55:52 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306488323218747392",
  "geo" : { },
  "id_str" : "306488960325132288",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny some ppl consider me insane for the things I believe...",
  "id" : 306488960325132288,
  "in_reply_to_status_id" : 306488323218747392,
  "created_at" : "2013-02-26 19:40:37 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/whUMVGsQay",
      "expanded_url" : "http:\/\/ow.ly\/i4utC",
      "display_url" : "ow.ly\/i4utC"
    } ]
  },
  "geo" : { },
  "id_str" : "306488208605196290",
  "text" : "RT @NewMindMirror: Learn to Code with Harvard\u2019s Intro to Computer Science Course And Other Free Tech Classes http:\/\/t.co\/whUMVGsQay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/whUMVGsQay",
        "expanded_url" : "http:\/\/ow.ly\/i4utC",
        "display_url" : "ow.ly\/i4utC"
      } ]
    },
    "geo" : { },
    "id_str" : "306487558550978560",
    "text" : "Learn to Code with Harvard\u2019s Intro to Computer Science Course And Other Free Tech Classes http:\/\/t.co\/whUMVGsQay",
    "id" : 306487558550978560,
    "created_at" : "2013-02-26 19:35:02 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 306488208605196290,
  "created_at" : "2013-02-26 19:37:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306482161945550848",
  "text" : "read some Leviticus today at bible study.. blood sacrifice and burnt offerings.. blech.",
  "id" : 306482161945550848,
  "created_at" : "2013-02-26 19:13:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    }, {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 21, 37 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/k9EVSdt35K",
      "expanded_url" : "http:\/\/ow.ly\/i4cUR",
      "display_url" : "ow.ly\/i4cUR"
    } ]
  },
  "geo" : { },
  "id_str" : "306477754784829442",
  "text" : "RT @davidpakmanshow: @davidpakmanshow is hiring, please visit for more info: http:\/\/t.co\/k9EVSdt35K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Pakman Show",
        "screen_name" : "davidpakmanshow",
        "indices" : [ 0, 16 ],
        "id_str" : "140060120",
        "id" : 140060120
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/k9EVSdt35K",
        "expanded_url" : "http:\/\/ow.ly\/i4cUR",
        "display_url" : "ow.ly\/i4cUR"
      } ]
    },
    "geo" : { },
    "id_str" : "306453842806067202",
    "in_reply_to_user_id" : 140060120,
    "text" : "@davidpakmanshow is hiring, please visit for more info: http:\/\/t.co\/k9EVSdt35K",
    "id" : 306453842806067202,
    "created_at" : "2013-02-26 17:21:04 +0000",
    "in_reply_to_screen_name" : "davidpakmanshow",
    "in_reply_to_user_id_str" : "140060120",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 306477754784829442,
  "created_at" : "2013-02-26 18:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306477548647358464",
  "text" : "RT @davidpakmanshow: Disgrace: Huckabee says pre-existing conditions are like a burned down house or totaled car, ie to be thrown out ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/3ydpGFBkqF",
        "expanded_url" : "http:\/\/ow.ly\/i3GhU",
        "display_url" : "ow.ly\/i3GhU"
      } ]
    },
    "geo" : { },
    "id_str" : "306418792668467201",
    "text" : "Disgrace: Huckabee says pre-existing conditions are like a burned down house or totaled car, ie to be thrown out http:\/\/t.co\/3ydpGFBkqF",
    "id" : 306418792668467201,
    "created_at" : "2013-02-26 15:01:47 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 306477548647358464,
  "created_at" : "2013-02-26 18:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Wood",
      "screen_name" : "IanWoodPhotos",
      "indices" : [ 3, 17 ],
      "id_str" : "345526929",
      "id" : 345526929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IanWoodPhotos\/status\/306382703975088128\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/W2Hu217vGT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEB9ciwCQAABC95.jpg",
      "id_str" : "306382703979282432",
      "id" : 306382703979282432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEB9ciwCQAABC95.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/W2Hu217vGT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306405883775160320",
  "text" : "RT @IanWoodPhotos: An afternoon squabble at my bird bath http:\/\/t.co\/W2Hu217vGT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IanWoodPhotos\/status\/306382703975088128\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/W2Hu217vGT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BEB9ciwCQAABC95.jpg",
        "id_str" : "306382703979282432",
        "id" : 306382703979282432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEB9ciwCQAABC95.jpg",
        "sizes" : [ {
          "h" : 597,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 597,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/W2Hu217vGT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306382703975088128",
    "text" : "An afternoon squabble at my bird bath http:\/\/t.co\/W2Hu217vGT",
    "id" : 306382703975088128,
    "created_at" : "2013-02-26 12:38:23 +0000",
    "user" : {
      "name" : "Ian Wood",
      "screen_name" : "IanWoodPhotos",
      "protected" : false,
      "id_str" : "345526929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2345709538\/syihau4tckdwbkgrqd3m_normal.jpeg",
      "id" : 345526929,
      "verified" : false
    }
  },
  "id" : 306405883775160320,
  "created_at" : "2013-02-26 14:10:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "C\u042F\u0423S\u0393\u0414L P\u039EG\u0414S\u0426S",
      "screen_name" : "TwinnerCat",
      "indices" : [ 43, 54 ],
      "id_str" : "756776816",
      "id" : 756776816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306182664560455681",
  "geo" : { },
  "id_str" : "306184106025304064",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny hey.. i resemble that remark! @TwinnerCat",
  "id" : 306184106025304064,
  "in_reply_to_status_id" : 306182664560455681,
  "created_at" : "2013-02-25 23:29:14 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    }, {
      "name" : "naked vegan cooking",
      "screen_name" : "nakedvegancooks",
      "indices" : [ 62, 78 ],
      "id_str" : "169068602",
      "id" : 169068602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/neyo6zX0T7",
      "expanded_url" : "http:\/\/huff.to\/13JdbV4",
      "display_url" : "huff.to\/13JdbV4"
    } ]
  },
  "geo" : { },
  "id_str" : "306182852163297280",
  "text" : "RT @HuffPostWeird: Naked cooking? Naked cooking! Introducing: @nakedvegancooks (NSFW PHOTOS) http:\/\/t.co\/neyo6zX0T7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "naked vegan cooking",
        "screen_name" : "nakedvegancooks",
        "indices" : [ 43, 59 ],
        "id_str" : "169068602",
        "id" : 169068602
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/neyo6zX0T7",
        "expanded_url" : "http:\/\/huff.to\/13JdbV4",
        "display_url" : "huff.to\/13JdbV4"
      } ]
    },
    "geo" : { },
    "id_str" : "306173001752268800",
    "text" : "Naked cooking? Naked cooking! Introducing: @nakedvegancooks (NSFW PHOTOS) http:\/\/t.co\/neyo6zX0T7",
    "id" : 306173001752268800,
    "created_at" : "2013-02-25 22:45:06 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 306182852163297280,
  "created_at" : "2013-02-25 23:24:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/YayoKFy1ET",
      "expanded_url" : "http:\/\/amzn.to\/NatcBo",
      "display_url" : "amzn.to\/NatcBo"
    } ]
  },
  "geo" : { },
  "id_str" : "306172895258873857",
  "text" : "finished Dominant Species Volume One -- Natural Selection (Dominant Species Series) by David Coy http:\/\/t.co\/YayoKFy1ET",
  "id" : 306172895258873857,
  "created_at" : "2013-02-25 22:44:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billionaire Gates",
      "screen_name" : "OmniPsyence",
      "indices" : [ 0, 12 ],
      "id_str" : "279522685",
      "id" : 279522685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306122604446638081",
  "geo" : { },
  "id_str" : "306123349959000065",
  "in_reply_to_user_id" : 279522685,
  "text" : "@OmniPsyence ha.. exactly what i was going to say! @Llimoner_",
  "id" : 306123349959000065,
  "in_reply_to_status_id" : 306122604446638081,
  "created_at" : "2013-02-25 19:27:48 +0000",
  "in_reply_to_screen_name" : "OmniPsyence",
  "in_reply_to_user_id_str" : "279522685",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306097334641639425",
  "text" : "RT @alanhdawe: Yep, available now - for absolutely nothing: Kindle or PC download The God Franchise: A Theory of Everything, http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/SbNbYjEDjs",
        "expanded_url" : "http:\/\/www.amazon.com\/The-God-Franchise-Everything-ebook\/dp\/B00AL8F43Y\/",
        "display_url" : "amazon.com\/The-God-Franch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305972939243790336",
    "text" : "Yep, available now - for absolutely nothing: Kindle or PC download The God Franchise: A Theory of Everything, http:\/\/t.co\/SbNbYjEDjs",
    "id" : 305972939243790336,
    "created_at" : "2013-02-25 09:30:08 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 306097334641639425,
  "created_at" : "2013-02-25 17:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "designing value",
      "screen_name" : "charles_consult",
      "indices" : [ 3, 19 ],
      "id_str" : "180770812",
      "id" : 180770812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rehabilitation",
      "indices" : [ 103, 118 ]
    }, {
      "text" : "prisons",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/clU5EexaMQ",
      "expanded_url" : "http:\/\/gu.com\/p\/3e298\/tw",
      "display_url" : "gu.com\/p\/3e298\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "306086019411869696",
  "text" : "RT @charles_consult: The Norwegian prison where inmates are treated like people http:\/\/t.co\/clU5EexaMQ #rehabilitation #prisons",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rehabilitation",
        "indices" : [ 82, 97 ]
      }, {
        "text" : "prisons",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/clU5EexaMQ",
        "expanded_url" : "http:\/\/gu.com\/p\/3e298\/tw",
        "display_url" : "gu.com\/p\/3e298\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "306039613972180993",
    "text" : "The Norwegian prison where inmates are treated like people http:\/\/t.co\/clU5EexaMQ #rehabilitation #prisons",
    "id" : 306039613972180993,
    "created_at" : "2013-02-25 13:55:04 +0000",
    "user" : {
      "name" : "designing value",
      "screen_name" : "charles_consult",
      "protected" : false,
      "id_str" : "180770812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788105114137559042\/Laubmf-w_normal.jpg",
      "id" : 180770812,
      "verified" : false
    }
  },
  "id" : 306086019411869696,
  "created_at" : "2013-02-25 16:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306080413749751808",
  "geo" : { },
  "id_str" : "306082017051803648",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields the juice example was a dingdong moment. how true!",
  "id" : 306082017051803648,
  "in_reply_to_status_id" : 306080413749751808,
  "created_at" : "2013-02-25 16:43:34 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "indices" : [ 0, 11 ],
      "id_str" : "21497211",
      "id" : 21497211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306078260838686720",
  "geo" : { },
  "id_str" : "306079827562209281",
  "in_reply_to_user_id" : 21497211,
  "text" : "@jedwards06 : ( ((hugs))",
  "id" : 306079827562209281,
  "in_reply_to_status_id" : 306078260838686720,
  "created_at" : "2013-02-25 16:34:52 +0000",
  "in_reply_to_screen_name" : "jedwards06",
  "in_reply_to_user_id_str" : "21497211",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Quk0SJeyCP",
      "expanded_url" : "http:\/\/experimentaltheology.blogspot.com\/2013\/02\/the-psychology-of-christian-purity.html",
      "display_url" : "experimentaltheology.blogspot.com\/2013\/02\/the-ps\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306076438229045248",
  "text" : "wow.. exc post! diff perspective on sin http:\/\/t.co\/Quk0SJeyCP",
  "id" : 306076438229045248,
  "created_at" : "2013-02-25 16:21:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 89, 102 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0Pdq8yiKsp",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B00908HW6I\/ref=cm_sw_r_tw_ask_-uq8F.06A7B18",
      "display_url" : "amazon.com\/dp\/B00908HW6I\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306061876905791488",
  "text" : "I just bought: 'Pro Bono - The 18-year defense of Caril Ann Fugate' by Jeff McArthur via @amazonkindle - curr. free http:\/\/t.co\/0Pdq8yiKsp",
  "id" : 306061876905791488,
  "created_at" : "2013-02-25 15:23:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306054476626812928",
  "text" : "RT @AnAmericanMonk: Most people are taught to be somebody other than who they are?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306046550088511488",
    "text" : "Most people are taught to be somebody other than who they are?",
    "id" : 306046550088511488,
    "created_at" : "2013-02-25 14:22:38 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 306054476626812928,
  "created_at" : "2013-02-25 14:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306054105837756419",
  "text" : "RT @adamrshields: Amazon takes a shot at removing affiliate income for sites that promote free books. What this means for Bookwi.se http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/v7xjcGSaYP",
        "expanded_url" : "http:\/\/bookwi.se\/amazon-changes-to-free-kindle-book-promotion\/",
        "display_url" : "bookwi.se\/amazon-changes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306048916867137537",
    "text" : "Amazon takes a shot at removing affiliate income for sites that promote free books. What this means for Bookwi.se http:\/\/t.co\/v7xjcGSaYP",
    "id" : 306048916867137537,
    "created_at" : "2013-02-25 14:32:02 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 306054105837756419,
  "created_at" : "2013-02-25 14:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "nprnews",
      "indices" : [ 4, 12 ],
      "id_str" : "3386439610",
      "id" : 3386439610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/VG4mdZADJZ",
      "expanded_url" : "http:\/\/n.pr\/XQzlkA",
      "display_url" : "n.pr\/XQzlkA"
    } ]
  },
  "geo" : { },
  "id_str" : "305819949409107968",
  "text" : "Via @nprnews: Dead Mice Are Going To Be Dropped On Guam From Helicopters (Really) http:\/\/t.co\/VG4mdZADJZ",
  "id" : 305819949409107968,
  "created_at" : "2013-02-24 23:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305813587178434560",
  "text" : "RT @micahjmurray: Atoms are the pixels of life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305809576178102272",
    "text" : "Atoms are the pixels of life.",
    "id" : 305809576178102272,
    "created_at" : "2013-02-24 22:40:59 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 305813587178434560,
  "created_at" : "2013-02-24 22:56:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305813503590141954",
  "text" : "RT @Master_Synaps: Welfare is the working of societal #compassion Now, who and why are those against it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compassion",
        "indices" : [ 35, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305810193944551424",
    "text" : "Welfare is the working of societal #compassion Now, who and why are those against it?",
    "id" : 305810193944551424,
    "created_at" : "2013-02-24 22:43:26 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 305813503590141954,
  "created_at" : "2013-02-24 22:56:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Other Version of YOU",
      "screen_name" : "TJayMacks",
      "indices" : [ 3, 13 ],
      "id_str" : "170790201",
      "id" : 170790201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305813368621641728",
  "text" : "RT @TJayMacks: The war machine is maintained by convincing the poor and working class to kill and die for resources they receive no prof ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305809851127328769",
    "text" : "The war machine is maintained by convincing the poor and working class to kill and die for resources they receive no profit from.",
    "id" : 305809851127328769,
    "created_at" : "2013-02-24 22:42:04 +0000",
    "user" : {
      "name" : "Other Version of YOU",
      "screen_name" : "TJayMacks",
      "protected" : false,
      "id_str" : "170790201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673867763908280320\/GXFphwNr_normal.jpg",
      "id" : 170790201,
      "verified" : false
    }
  },
  "id" : 305813368621641728,
  "created_at" : "2013-02-24 22:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PsyDMommy",
      "screen_name" : "PsyDMommy",
      "indices" : [ 3, 13 ],
      "id_str" : "155779297",
      "id" : 155779297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/u7noPZdORc",
      "expanded_url" : "http:\/\/bit.ly\/XuA1jG",
      "display_url" : "bit.ly\/XuA1jG"
    } ]
  },
  "geo" : { },
  "id_str" : "305790418967220224",
  "text" : "RT @PsyDMommy: Former FBI profiler: \u2018Video games do not cause violence\u2019 http:\/\/t.co\/u7noPZdORc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/u7noPZdORc",
        "expanded_url" : "http:\/\/bit.ly\/XuA1jG",
        "display_url" : "bit.ly\/XuA1jG"
      } ]
    },
    "geo" : { },
    "id_str" : "305765685647245312",
    "text" : "Former FBI profiler: \u2018Video games do not cause violence\u2019 http:\/\/t.co\/u7noPZdORc",
    "id" : 305765685647245312,
    "created_at" : "2013-02-24 19:46:34 +0000",
    "user" : {
      "name" : "PsyDMommy",
      "screen_name" : "PsyDMommy",
      "protected" : false,
      "id_str" : "155779297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2861654536\/bbbfbec0fca9b33270f85726f1289396_normal.jpeg",
      "id" : 155779297,
      "verified" : false
    }
  },
  "id" : 305790418967220224,
  "created_at" : "2013-02-24 21:24:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305780176309067776",
  "text" : "RT @TheGoldenMirror: Use bright thoughts to light your way out of darkness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305777724084060163",
    "text" : "Use bright thoughts to light your way out of darkness.",
    "id" : 305777724084060163,
    "created_at" : "2013-02-24 20:34:25 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 305780176309067776,
  "created_at" : "2013-02-24 20:44:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305763300589858817",
  "text" : "got a tickle in my throat.. might be something.. or maybe not. tired but had late night on friday.",
  "id" : 305763300589858817,
  "created_at" : "2013-02-24 19:37:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305762219696726017",
  "text" : "RT @MWM4444: Walmart earns more each year than 169 NATIONS, but it \"can't afford\" to pay its employees enough to cover food &amp; health ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305748162172301312",
    "text" : "Walmart earns more each year than 169 NATIONS, but it \"can't afford\" to pay its employees enough to cover food &amp; health care. WE pay.",
    "id" : 305748162172301312,
    "created_at" : "2013-02-24 18:36:57 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 305762219696726017,
  "created_at" : "2013-02-24 19:32:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    }, {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 16, 31 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305708278866927616",
  "text" : "@1stCitizenKane @TheEntertainer calls it a human suit : )",
  "id" : 305708278866927616,
  "created_at" : "2013-02-24 15:58:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twentyfeet.com\" rel=\"nofollow\"\u003ETwentyFeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/1awwEymWY4",
      "expanded_url" : "http:\/\/20ft.net\/p",
      "display_url" : "20ft.net\/p"
    } ]
  },
  "geo" : { },
  "id_str" : "305473468751826944",
  "text" : "My week on twitter: 8 retweets received, 49 mentions. Via: http:\/\/t.co\/1awwEymWY4",
  "id" : 305473468751826944,
  "created_at" : "2013-02-24 00:25:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eleanor henderson",
      "screen_name" : "elean0r_hx",
      "indices" : [ 88, 99 ],
      "id_str" : "30317536",
      "id" : 30317536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305387614276562945",
  "geo" : { },
  "id_str" : "305462478781960194",
  "in_reply_to_user_id" : 30317536,
  "text" : "@ryanholt94 uh-oh.. what did you do to the poor lass? better get her some chocolate : ) @elean0r_hx",
  "id" : 305462478781960194,
  "in_reply_to_status_id" : 305387614276562945,
  "created_at" : "2013-02-23 23:41:44 +0000",
  "in_reply_to_screen_name" : "elean0r_hx",
  "in_reply_to_user_id_str" : "30317536",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305461649584828417",
  "text" : "@Llimoner_ SSRI type anti-deppressant .. been on it for 14 years about. feel withdrawal within 6 hours or so of missed dose.",
  "id" : 305461649584828417,
  "created_at" : "2013-02-23 23:38:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psychiatricdrugs",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305458771658932224",
  "text" : "@Llimoner_ yup, me, too. they wanted to med DD but we said no. im addicted to effexor and read the horror stories #psychiatricdrugs",
  "id" : 305458771658932224,
  "created_at" : "2013-02-23 23:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 102, 115 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305448628430966784",
  "text" : "I just bought: 'Dominant Species Volume One -- Natural Selection (Dominant Species Series)' by... via @amazonkindle - curr. free",
  "id" : 305448628430966784,
  "created_at" : "2013-02-23 22:46:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/DxLbLoZIhQ",
      "expanded_url" : "http:\/\/amzn.to\/wZ4G6v",
      "display_url" : "amzn.to\/wZ4G6v"
    } ]
  },
  "geo" : { },
  "id_str" : "305426897981038593",
  "text" : "finished Gifts and Consequences by Daniel Coleman http:\/\/t.co\/DxLbLoZIhQ",
  "id" : 305426897981038593,
  "created_at" : "2013-02-23 21:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ADMKz8k2Sz",
      "expanded_url" : "http:\/\/www.thedailyshow.com\/watch\/thu-february-21-2013\/exclusive---steven-brill-extended-interview-pt--2",
      "display_url" : "thedailyshow.com\/watch\/thu-febr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305417672898801665",
  "text" : "RT @AllOnMedicare: The ambulance industry takes in more money every year than Hollywood: http:\/\/t.co\/ADMKz8k2Sz SAY WHAT?! #SinglePayer  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 104, 116 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 117, 132 ]
      }, {
        "text" : "p2",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/ADMKz8k2Sz",
        "expanded_url" : "http:\/\/www.thedailyshow.com\/watch\/thu-february-21-2013\/exclusive---steven-brill-extended-interview-pt--2",
        "display_url" : "thedailyshow.com\/watch\/thu-febr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305416695487537152",
    "text" : "The ambulance industry takes in more money every year than Hollywood: http:\/\/t.co\/ADMKz8k2Sz SAY WHAT?! #SinglePayer #MedicareForAll #p2",
    "id" : 305416695487537152,
    "created_at" : "2013-02-23 20:39:49 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 305417672898801665,
  "created_at" : "2013-02-23 20:43:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305414012080881665",
  "geo" : { },
  "id_str" : "305415166357561344",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone LOLOL :D",
  "id" : 305415166357561344,
  "in_reply_to_status_id" : 305414012080881665,
  "created_at" : "2013-02-23 20:33:44 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Yale New Haven Hosp",
      "screen_name" : "YNHH",
      "indices" : [ 115, 120 ],
      "id_str" : "17368500",
      "id" : 17368500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305409632619360257",
  "text" : "RT @AllOnMedicare: Non-profit hospitals in America earn more 'profit' in a year than for-profit hospitals. Head of @YNHH makes over 2 MI ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yale New Haven Hosp",
        "screen_name" : "YNHH",
        "indices" : [ 96, 101 ],
        "id_str" : "17368500",
        "id" : 17368500
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 129, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305409024432689153",
    "text" : "Non-profit hospitals in America earn more 'profit' in a year than for-profit hospitals. Head of @YNHH makes over 2 MILLION\/year. #p2",
    "id" : 305409024432689153,
    "created_at" : "2013-02-23 20:09:20 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 305409632619360257,
  "created_at" : "2013-02-23 20:11:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 3, 16 ],
      "id_str" : "88882302",
      "id" : 88882302
    }, {
      "name" : "Susan Calhoun",
      "screen_name" : "easywaytoinvest",
      "indices" : [ 113, 129 ],
      "id_str" : "781416200",
      "id" : 781416200
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305400121582047232",
  "text" : "RT @TweetTheBook: #FREE 02\/23-02\/24~&gt;The Easy Way to Invest: Start Small, Get Rich Investing by Susan Calhoun @easywaytoinvest http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Calhoun",
        "screen_name" : "easywaytoinvest",
        "indices" : [ 95, 111 ],
        "id_str" : "781416200",
        "id" : 781416200
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FREE",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "Invest",
        "indices" : [ 135, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/AgVnH5xeqZ",
        "expanded_url" : "http:\/\/ow.ly\/hX8FJ",
        "display_url" : "ow.ly\/hX8FJ"
      } ]
    },
    "geo" : { },
    "id_str" : "305396797952626688",
    "text" : "#FREE 02\/23-02\/24~&gt;The Easy Way to Invest: Start Small, Get Rich Investing by Susan Calhoun @easywaytoinvest http:\/\/t.co\/AgVnH5xeqZ #Invest",
    "id" : 305396797952626688,
    "created_at" : "2013-02-23 19:20:45 +0000",
    "user" : {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "protected" : false,
      "id_str" : "88882302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723538520174780416\/myOVJeXG_normal.jpg",
      "id" : 88882302,
      "verified" : false
    }
  },
  "id" : 305400121582047232,
  "created_at" : "2013-02-23 19:33:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ziEhKkhxya",
      "expanded_url" : "http:\/\/via.me\/-9yvnlvg",
      "display_url" : "via.me\/-9yvnlvg"
    } ]
  },
  "geo" : { },
  "id_str" : "305399248462176258",
  "text" : "One of them pulled dish onto first step. Funny squirrels! http:\/\/t.co\/ziEhKkhxya",
  "id" : 305399248462176258,
  "created_at" : "2013-02-23 19:30:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305390933061550080",
  "text" : "RT @petersonguides: A crow's brain may be small, but they make complex decisions\u2014like remembering faces\u2014in much the same way our... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/MZusSbPB49",
        "expanded_url" : "http:\/\/fb.me\/2q9uzqj5G",
        "display_url" : "fb.me\/2q9uzqj5G"
      } ]
    },
    "geo" : { },
    "id_str" : "305386473090334722",
    "text" : "A crow's brain may be small, but they make complex decisions\u2014like remembering faces\u2014in much the same way our... http:\/\/t.co\/MZusSbPB49",
    "id" : 305386473090334722,
    "created_at" : "2013-02-23 18:39:43 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 305390933061550080,
  "created_at" : "2013-02-23 18:57:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0435\u043F\u043E\u043C\u043D\u044F\u0449\u0438\u0445 \u0412\u0438\u043A\u0442\u043E\u0440",
      "screen_name" : "glassdimlyfaith",
      "indices" : [ 3, 19 ],
      "id_str" : "2826504890",
      "id" : 2826504890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305382090885705728",
  "text" : "RT @glassdimlyfaith: The problem critics of Xianity have is that we fail to live up to our own project. If you claim God, you better lov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305381065709715456",
    "text" : "The problem critics of Xianity have is that we fail to live up to our own project. If you claim God, you better love extraordinarily.",
    "id" : 305381065709715456,
    "created_at" : "2013-02-23 18:18:14 +0000",
    "user" : {
      "name" : "Jeremy John",
      "screen_name" : "glassdimly",
      "protected" : false,
      "id_str" : "247971836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/411886255576592384\/HounElWp_normal.jpeg",
      "id" : 247971836,
      "verified" : false
    }
  },
  "id" : 305382090885705728,
  "created_at" : "2013-02-23 18:22:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squeeeeeeee",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/mASH4i5xPo",
      "expanded_url" : "http:\/\/instagr.am\/p\/WFUzQoShCh\/",
      "display_url" : "instagr.am\/p\/WFUzQoShCh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "305381488373927936",
  "text" : "RT @_CabinGirl: Pupppppy!!  Sitting in the back of a pickup in Jerome. #squeeeeeeee http:\/\/t.co\/mASH4i5xPo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squeeeeeeee",
        "indices" : [ 55, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/mASH4i5xPo",
        "expanded_url" : "http:\/\/instagr.am\/p\/WFUzQoShCh\/",
        "display_url" : "instagr.am\/p\/WFUzQoShCh\/"
      } ]
    },
    "geo" : { },
    "id_str" : "305380605607165953",
    "text" : "Pupppppy!!  Sitting in the back of a pickup in Jerome. #squeeeeeeee http:\/\/t.co\/mASH4i5xPo",
    "id" : 305380605607165953,
    "created_at" : "2013-02-23 18:16:24 +0000",
    "user" : {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "protected" : false,
      "id_str" : "116807098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713963701\/me_and_fawnsm_normal.jpg",
      "id" : 116807098,
      "verified" : false
    }
  },
  "id" : 305381488373927936,
  "created_at" : "2013-02-23 18:19:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikola Tesla",
      "screen_name" : "NikolaTeslaBot",
      "indices" : [ 3, 18 ],
      "id_str" : "1325500879",
      "id" : 1325500879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305378991320223744",
  "text" : "RT @NikolaTeslaBot: This planet, with all its appalling immensity, is to electric currents virtually no more than a small metal ball.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/2log.biz\/\" rel=\"nofollow\"\u003ETeslaBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305370198561681409",
    "text" : "This planet, with all its appalling immensity, is to electric currents virtually no more than a small metal ball.",
    "id" : 305370198561681409,
    "created_at" : "2013-02-23 17:35:03 +0000",
    "user" : {
      "name" : "Sand Hill Exchange",
      "screen_name" : "SandHillX",
      "protected" : false,
      "id_str" : "135160644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568293519777742848\/3Co2gOo6_normal.png",
      "id" : 135160644,
      "verified" : false
    }
  },
  "id" : 305378991320223744,
  "created_at" : "2013-02-23 18:09:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/9B7g2z3IkN",
      "expanded_url" : "http:\/\/youtu.be\/XVxVdchyEdY",
      "display_url" : "youtu.be\/XVxVdchyEdY"
    } ]
  },
  "geo" : { },
  "id_str" : "305360968538546176",
  "text" : "my fave song he played.. Garnet Rogers \"Get A Witness\" http:\/\/t.co\/9B7g2z3IkN",
  "id" : 305360968538546176,
  "created_at" : "2013-02-23 16:58:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    }, {
      "name" : "HuffPostWomen",
      "screen_name" : "HuffPostWomen",
      "indices" : [ 81, 95 ],
      "id_str" : "309978842",
      "id" : 309978842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/e7vIL6wGt5",
      "expanded_url" : "http:\/\/huff.to\/13yLBKb",
      "display_url" : "huff.to\/13yLBKb"
    } ]
  },
  "geo" : { },
  "id_str" : "305356507917217792",
  "text" : "RT @HuffPostWeird: Not weird . . . just nude . . . and socially relevant! Thanks @HuffPostWomen http:\/\/t.co\/e7vIL6wGt5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPostWomen",
        "screen_name" : "HuffPostWomen",
        "indices" : [ 62, 76 ],
        "id_str" : "309978842",
        "id" : 309978842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/e7vIL6wGt5",
        "expanded_url" : "http:\/\/huff.to\/13yLBKb",
        "display_url" : "huff.to\/13yLBKb"
      } ]
    },
    "geo" : { },
    "id_str" : "305354027523248128",
    "text" : "Not weird . . . just nude . . . and socially relevant! Thanks @HuffPostWomen http:\/\/t.co\/e7vIL6wGt5",
    "id" : 305354027523248128,
    "created_at" : "2013-02-23 16:30:48 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 305356507917217792,
  "created_at" : "2013-02-23 16:40:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maine",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "farming",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/1Y9ULiAe2O",
      "expanded_url" : "http:\/\/twitpic.com\/c67y0r",
      "display_url" : "twitpic.com\/c67y0r"
    } ]
  },
  "geo" : { },
  "id_str" : "305352779780734977",
  "text" : "RT @ChickenJen: #Maine #farming I love this pic of our cows on the pond. http:\/\/t.co\/1Y9ULiAe2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Maine",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "farming",
        "indices" : [ 7, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/1Y9ULiAe2O",
        "expanded_url" : "http:\/\/twitpic.com\/c67y0r",
        "display_url" : "twitpic.com\/c67y0r"
      } ]
    },
    "geo" : { },
    "id_str" : "305351286038093826",
    "text" : "#Maine #farming I love this pic of our cows on the pond. http:\/\/t.co\/1Y9ULiAe2O",
    "id" : 305351286038093826,
    "created_at" : "2013-02-23 16:19:54 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 305352779780734977,
  "created_at" : "2013-02-23 16:25:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305343973474586625",
  "text" : "had a good time at the Garnet Rogers show in Woodstock last night. He sure is funny.. and tall.. lol",
  "id" : 305343973474586625,
  "created_at" : "2013-02-23 15:50:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305033184523993088",
  "text" : "@NowAtheist you are kind : )",
  "id" : 305033184523993088,
  "created_at" : "2013-02-22 19:15:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305032657996242944",
  "text" : "@imtoridee same goes for theists... every person is an individual w own experience.",
  "id" : 305032657996242944,
  "created_at" : "2013-02-22 19:13:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Hole",
      "screen_name" : "jhski",
      "indices" : [ 3, 9 ],
      "id_str" : "34328135",
      "id" : 34328135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jacksonhole",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Rj6T2GOqFD",
      "expanded_url" : "http:\/\/instagr.am\/p\/WC1mv6Js5q\/",
      "display_url" : "instagr.am\/p\/WC1mv6Js5q\/"
    } ]
  },
  "geo" : { },
  "id_str" : "305031544471433216",
  "text" : "RT @jhski: Moose-stagram on the mountain #jacksonhole http:\/\/t.co\/Rj6T2GOqFD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jacksonhole",
        "indices" : [ 30, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/Rj6T2GOqFD",
        "expanded_url" : "http:\/\/instagr.am\/p\/WC1mv6Js5q\/",
        "display_url" : "instagr.am\/p\/WC1mv6Js5q\/"
      } ]
    },
    "geo" : { },
    "id_str" : "305030468372418560",
    "text" : "Moose-stagram on the mountain #jacksonhole http:\/\/t.co\/Rj6T2GOqFD",
    "id" : 305030468372418560,
    "created_at" : "2013-02-22 19:05:05 +0000",
    "user" : {
      "name" : "Jackson Hole",
      "screen_name" : "jhski",
      "protected" : false,
      "id_str" : "34328135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563497651694358528\/QP1vZ6YF_normal.jpeg",
      "id" : 34328135,
      "verified" : false
    }
  },
  "id" : 305031544471433216,
  "created_at" : "2013-02-22 19:09:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nervous",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305031083068633089",
  "text" : "have to be social tonight. hubby and i going out w another couple for dinner and music. #nervous",
  "id" : 305031083068633089,
  "created_at" : "2013-02-22 19:07:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/2jpmrchle5",
      "expanded_url" : "http:\/\/via.me\/-9xpqk9k",
      "display_url" : "via.me\/-9xpqk9k"
    } ]
  },
  "geo" : { },
  "id_str" : "305028835051708416",
  "text" : "Squirrel getting some peanut butter http:\/\/t.co\/2jpmrchle5",
  "id" : 305028835051708416,
  "created_at" : "2013-02-22 18:58:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "healthcare",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/YqEspYKQjq",
      "expanded_url" : "http:\/\/www.pnhp.org\/facts\/what-is-single-payer",
      "display_url" : "pnhp.org\/facts\/what-is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305004397828653056",
  "text" : "http:\/\/t.co\/YqEspYKQjq #SinglePayer #healthcare",
  "id" : 305004397828653056,
  "created_at" : "2013-02-22 17:21:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305002265176047620",
  "text" : "squirrel thought he would take the dish away but it flipped over and scared him.. lol",
  "id" : 305002265176047620,
  "created_at" : "2013-02-22 17:13:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas W Lance",
      "screen_name" : "douglance",
      "indices" : [ 3, 13 ],
      "id_str" : "757782870329024512",
      "id" : 757782870329024512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304998167441731584",
  "text" : "RT @DougLance: Reader appreciation sale on Amazon!\n\nThere's a bunch of free eFiction Publishing issues on Amazon in almost all... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sharedby.co\" rel=\"nofollow\"\u003ESharedBy\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/s1iQKBYy62",
        "expanded_url" : "http:\/\/shrd.by\/TW5JwC",
        "display_url" : "shrd.by\/TW5JwC"
      } ]
    },
    "geo" : { },
    "id_str" : "304995464292466690",
    "text" : "Reader appreciation sale on Amazon!\n\nThere's a bunch of free eFiction Publishing issues on Amazon in almost all... http:\/\/t.co\/s1iQKBYy62",
    "id" : 304995464292466690,
    "created_at" : "2013-02-22 16:45:59 +0000",
    "user" : {
      "name" : "Douglas W. Lance",
      "screen_name" : "DouglasWLance",
      "protected" : false,
      "id_str" : "14164456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000334743376\/a99c70bf244662760a73dc24c1b1588f_normal.png",
      "id" : 14164456,
      "verified" : false
    }
  },
  "id" : 304998167441731584,
  "created_at" : "2013-02-22 16:56:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304984090996789249",
  "text" : "RT @Jamiastar: Postal Service is \u201Cmanufactured crisis\u201D, part of a larger strategy to privatize so it serves wealthy few  http:\/\/t.co\/GbR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USPS",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/GbReGdiU3o",
        "expanded_url" : "http:\/\/www.nationofchange.org\/talking-postal-service-and-privatization-huffington-post-live-1361545726",
        "display_url" : "nationofchange.org\/talking-postal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304983843897737218",
    "text" : "Postal Service is \u201Cmanufactured crisis\u201D, part of a larger strategy to privatize so it serves wealthy few  http:\/\/t.co\/GbReGdiU3o #USPS",
    "id" : 304983843897737218,
    "created_at" : "2013-02-22 15:59:49 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 304984090996789249,
  "created_at" : "2013-02-22 16:00:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "indices" : [ 3, 13 ],
      "id_str" : "90893629",
      "id" : 90893629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ZgiajWKeJ7",
      "expanded_url" : "http:\/\/mbist.ro\/YhGBKn",
      "display_url" : "mbist.ro\/YhGBKn"
    } ]
  },
  "geo" : { },
  "id_str" : "304983469367377921",
  "text" : "RT @AppNewser: MediSafe app sends reminders to take medications http:\/\/t.co\/ZgiajWKeJ7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/ZgiajWKeJ7",
        "expanded_url" : "http:\/\/mbist.ro\/YhGBKn",
        "display_url" : "mbist.ro\/YhGBKn"
      } ]
    },
    "geo" : { },
    "id_str" : "304981608304361472",
    "text" : "MediSafe app sends reminders to take medications http:\/\/t.co\/ZgiajWKeJ7",
    "id" : 304981608304361472,
    "created_at" : "2013-02-22 15:50:56 +0000",
    "user" : {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "protected" : false,
      "id_str" : "90893629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461987151496744960\/7LSAvXUw_normal.png",
      "id" : 90893629,
      "verified" : false
    }
  },
  "id" : 304983469367377921,
  "created_at" : "2013-02-22 15:58:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 53, 69 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/XCQZdFZlrS",
      "expanded_url" : "http:\/\/wp.me\/s2ji3N-labels",
      "display_url" : "wp.me\/s2ji3N-labels"
    } ]
  },
  "geo" : { },
  "id_str" : "304982281821487104",
  "text" : "RT @atheistlady76: Labels http:\/\/t.co\/XCQZdFZlrS via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 34, 50 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/XCQZdFZlrS",
        "expanded_url" : "http:\/\/wp.me\/s2ji3N-labels",
        "display_url" : "wp.me\/s2ji3N-labels"
      } ]
    },
    "geo" : { },
    "id_str" : "304979858717569025",
    "text" : "Labels http:\/\/t.co\/XCQZdFZlrS via @wordpressdotcom",
    "id" : 304979858717569025,
    "created_at" : "2013-02-22 15:43:59 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 304982281821487104,
  "created_at" : "2013-02-22 15:53:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304981547004616705",
  "text" : "freedom.. or security.. your choice.",
  "id" : 304981547004616705,
  "created_at" : "2013-02-22 15:50:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iDemocrat",
      "screen_name" : "iDemocrat",
      "indices" : [ 3, 13 ],
      "id_str" : "392235284",
      "id" : 392235284
    }, {
      "name" : "Auna",
      "screen_name" : "Aunamatopoeia",
      "indices" : [ 15, 29 ],
      "id_str" : "394482779",
      "id" : 394482779
    }, {
      "name" : "Dava Tyson",
      "screen_name" : "DavaJeanne",
      "indices" : [ 30, 41 ],
      "id_str" : "135593099",
      "id" : 135593099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304977043186126848",
  "text" : "RT @iDemocrat: @Aunamatopoeia @davajeanne agreed  all Bush 9\/11 polices should be repeal and our freedom and privacy restored",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Auna",
        "screen_name" : "Aunamatopoeia",
        "indices" : [ 0, 14 ],
        "id_str" : "394482779",
        "id" : 394482779
      }, {
        "name" : "Dava Tyson",
        "screen_name" : "DavaJeanne",
        "indices" : [ 15, 26 ],
        "id_str" : "135593099",
        "id" : 135593099
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "303586171966066689",
    "geo" : { },
    "id_str" : "303586755771260928",
    "in_reply_to_user_id" : 394482779,
    "text" : "@Aunamatopoeia @davajeanne agreed  all Bush 9\/11 polices should be repeal and our freedom and privacy restored",
    "id" : 303586755771260928,
    "in_reply_to_status_id" : 303586171966066689,
    "created_at" : "2013-02-18 19:28:17 +0000",
    "in_reply_to_screen_name" : "Aunamatopoeia",
    "in_reply_to_user_id_str" : "394482779",
    "user" : {
      "name" : "Theodore Harrison",
      "screen_name" : "tharrisoniii",
      "protected" : false,
      "id_str" : "21742407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000517313666\/e4756ef2887d1829d62dbe026e71ed12_normal.png",
      "id" : 21742407,
      "verified" : false
    }
  },
  "id" : 304977043186126848,
  "created_at" : "2013-02-22 15:32:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/OpAHjLpyW9",
      "expanded_url" : "http:\/\/ebookne.ws\/ZnaS9q",
      "display_url" : "ebookne.ws\/ZnaS9q"
    } ]
  },
  "geo" : { },
  "id_str" : "304976993684975617",
  "text" : "RT @thDigitalReader: Amazon Now Taking Steps to Discourage Free Kindle eBook Sites http:\/\/t.co\/OpAHjLpyW9 by Nate Hoffelder | The Digita ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wordpress.org\/extend\/plugins\/twitter-publisher\/\" rel=\"nofollow\"\u003ETwitPublisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/OpAHjLpyW9",
        "expanded_url" : "http:\/\/ebookne.ws\/ZnaS9q",
        "display_url" : "ebookne.ws\/ZnaS9q"
      } ]
    },
    "geo" : { },
    "id_str" : "304974328875872256",
    "text" : "Amazon Now Taking Steps to Discourage Free Kindle eBook Sites http:\/\/t.co\/OpAHjLpyW9 by Nate Hoffelder | The Digital Reader",
    "id" : 304974328875872256,
    "created_at" : "2013-02-22 15:22:00 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 304976993684975617,
  "created_at" : "2013-02-22 15:32:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304773058114252800",
  "text" : "RT @jonlieffmd: How do microbes respond simultaneously to multiple senses, make decisions, and communicate without a brain? http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "microbes",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/oevt5xDwGc",
        "expanded_url" : "http:\/\/bit.ly\/IsQBFe",
        "display_url" : "bit.ly\/IsQBFe"
      } ]
    },
    "geo" : { },
    "id_str" : "304772057663676418",
    "text" : "How do microbes respond simultaneously to multiple senses, make decisions, and communicate without a brain? http:\/\/t.co\/oevt5xDwGc #microbes",
    "id" : 304772057663676418,
    "created_at" : "2013-02-22 01:58:15 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 304773058114252800,
  "created_at" : "2013-02-22 02:02:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron",
      "screen_name" : "LdySkyfire",
      "indices" : [ 0, 11 ],
      "id_str" : "304244541",
      "id" : 304244541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304763805408305152",
  "geo" : { },
  "id_str" : "304764734027227137",
  "in_reply_to_user_id" : 304244541,
  "text" : "@LdySkyfire (((hugs)))",
  "id" : 304764734027227137,
  "in_reply_to_status_id" : 304763805408305152,
  "created_at" : "2013-02-22 01:29:09 +0000",
  "in_reply_to_screen_name" : "LdySkyfire",
  "in_reply_to_user_id_str" : "304244541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron",
      "screen_name" : "LdySkyfire",
      "indices" : [ 0, 11 ],
      "id_str" : "304244541",
      "id" : 304244541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304757491311448064",
  "geo" : { },
  "id_str" : "304759959063756800",
  "in_reply_to_user_id" : 304244541,
  "text" : "@LdySkyfire oh.. (just looked it up) that does look good!",
  "id" : 304759959063756800,
  "in_reply_to_status_id" : 304757491311448064,
  "created_at" : "2013-02-22 01:10:11 +0000",
  "in_reply_to_screen_name" : "LdySkyfire",
  "in_reply_to_user_id_str" : "304244541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304758325680168962",
  "text" : "hubby and i have started a tradition of having tea together each evening. herbal tea w honey.",
  "id" : 304758325680168962,
  "created_at" : "2013-02-22 01:03:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron",
      "screen_name" : "LdySkyfire",
      "indices" : [ 0, 11 ],
      "id_str" : "304244541",
      "id" : 304244541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304750737919983616",
  "geo" : { },
  "id_str" : "304757375708049408",
  "in_reply_to_user_id" : 304244541,
  "text" : "@LdySkyfire aww, sorry you're having issues w it.",
  "id" : 304757375708049408,
  "in_reply_to_status_id" : 304750737919983616,
  "created_at" : "2013-02-22 00:59:55 +0000",
  "in_reply_to_screen_name" : "LdySkyfire",
  "in_reply_to_user_id_str" : "304244541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/yEuliXt4eD",
      "expanded_url" : "http:\/\/www.tumblr.com\/blog\/your.username.here\/settings",
      "display_url" : "tumblr.com\/blog\/your.user\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304742019492880385",
  "geo" : { },
  "id_str" : "304744732993662978",
  "in_reply_to_user_id" : 99910224,
  "text" : "@PaganGmaSayin go to: http:\/\/t.co\/yEuliXt4eD ; scroll down to Twitter \"share posts on twitter\" and uncheck the box",
  "id" : 304744732993662978,
  "in_reply_to_status_id" : 304742019492880385,
  "created_at" : "2013-02-22 00:09:40 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/SbNbYjEDjs",
      "expanded_url" : "http:\/\/www.amazon.com\/The-God-Franchise-Everything-ebook\/dp\/B00AL8F43Y\/",
      "display_url" : "amazon.com\/The-God-Franch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304733749197815808",
  "text" : "RT @alanhdawe: Free Kindle or PC download my award-winning book The God Franchise: A Theory of Everything http:\/\/t.co\/SbNbYjEDjs Mon-Wed ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/SbNbYjEDjs",
        "expanded_url" : "http:\/\/www.amazon.com\/The-God-Franchise-Everything-ebook\/dp\/B00AL8F43Y\/",
        "display_url" : "amazon.com\/The-God-Franch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304724493161619456",
    "text" : "Free Kindle or PC download my award-winning book The God Franchise: A Theory of Everything http:\/\/t.co\/SbNbYjEDjs Mon-Wed next week. Go 4 it",
    "id" : 304724493161619456,
    "created_at" : "2013-02-21 22:49:15 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 304733749197815808,
  "created_at" : "2013-02-21 23:26:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vt",
      "indices" : [ 64, 67 ]
    }, {
      "text" : "Vermont",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "HCR",
      "indices" : [ 90, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/hbyOlnHT5P",
      "expanded_url" : "http:\/\/www.sanders.senate.gov\/newsroom\/news\/?id=6ECCDFB1-3627-4781-B9E6-FA093DAFAB87",
      "display_url" : "sanders.senate.gov\/newsroom\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304733460403212289",
  "text" : "RT @SenSanders: Single Payer in Vermont: http:\/\/t.co\/hbyOlnHT5P #Vt #Vermont #SinglePayer #HCR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vt",
        "indices" : [ 48, 51 ]
      }, {
        "text" : "Vermont",
        "indices" : [ 52, 60 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 61, 73 ]
      }, {
        "text" : "HCR",
        "indices" : [ 74, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/hbyOlnHT5P",
        "expanded_url" : "http:\/\/www.sanders.senate.gov\/newsroom\/news\/?id=6ECCDFB1-3627-4781-B9E6-FA093DAFAB87",
        "display_url" : "sanders.senate.gov\/newsroom\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304726172498014209",
    "text" : "Single Payer in Vermont: http:\/\/t.co\/hbyOlnHT5P #Vt #Vermont #SinglePayer #HCR",
    "id" : 304726172498014209,
    "created_at" : "2013-02-21 22:55:55 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 304733460403212289,
  "created_at" : "2013-02-21 23:24:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304732642337767424",
  "text" : "@IronAtheist and where is this mysterious place you disappear to? lol",
  "id" : 304732642337767424,
  "created_at" : "2013-02-21 23:21:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 0, 16 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304665298794078208",
  "geo" : { },
  "id_str" : "304708407384997889",
  "in_reply_to_user_id" : 344209049,
  "text" : "@AlterEgoTrip_Se thanks. its now added to my wishlist : )",
  "id" : 304708407384997889,
  "in_reply_to_status_id" : 304665298794078208,
  "created_at" : "2013-02-21 21:45:20 +0000",
  "in_reply_to_screen_name" : "AlterEgoTrip_se",
  "in_reply_to_user_id_str" : "344209049",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 0, 16 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304656099167059968",
  "geo" : { },
  "id_str" : "304656751662342144",
  "in_reply_to_user_id" : 344209049,
  "text" : "@AlterEgoTrip_Se what book is that?",
  "id" : 304656751662342144,
  "in_reply_to_status_id" : 304656099167059968,
  "created_at" : "2013-02-21 18:20:04 +0000",
  "in_reply_to_screen_name" : "AlterEgoTrip_se",
  "in_reply_to_user_id_str" : "344209049",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/0B08Rc0Bxj",
      "expanded_url" : "http:\/\/ti.me\/15wrtfl",
      "display_url" : "ti.me\/15wrtfl"
    } ]
  },
  "geo" : { },
  "id_str" : "304655337804423168",
  "text" : "RT @ZeitgeistGhost: Why medical bills are killing us http:\/\/t.co\/0B08Rc0Bxj FOR PROFIT HEALTHCARE IS EVIL!!! Add in insurance vultures a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/0B08Rc0Bxj",
        "expanded_url" : "http:\/\/ti.me\/15wrtfl",
        "display_url" : "ti.me\/15wrtfl"
      } ]
    },
    "geo" : { },
    "id_str" : "304654479226187776",
    "text" : "Why medical bills are killing us http:\/\/t.co\/0B08Rc0Bxj FOR PROFIT HEALTHCARE IS EVIL!!! Add in insurance vultures and we're screwed",
    "id" : 304654479226187776,
    "created_at" : "2013-02-21 18:11:02 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 304655337804423168,
  "created_at" : "2013-02-21 18:14:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 100, 113 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304617224956674048",
  "text" : "I just bought: 'No One Ever Asked Me That: Conversations on the Afterlife' by Catherine Levison via @amazonkindle - curr. free",
  "id" : 304617224956674048,
  "created_at" : "2013-02-21 15:43:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304615116794630145",
  "text" : "usa does not equal freedom. usa = one big prison.",
  "id" : 304615116794630145,
  "created_at" : "2013-02-21 15:34:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304614609309028352",
  "text" : "soon we will need permission just to step outside...",
  "id" : 304614609309028352,
  "created_at" : "2013-02-21 15:32:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOA",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304405258803757056",
  "text" : "RT @ificouldtellu: 1. Thought is creative. 2. Fear\nattracts like energy. 3. Love is all there is. #LOA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LOA",
        "indices" : [ 79, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304401963494297600",
    "text" : "1. Thought is creative. 2. Fear\nattracts like energy. 3. Love is all there is. #LOA",
    "id" : 304401963494297600,
    "created_at" : "2013-02-21 01:27:38 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 304405258803757056,
  "created_at" : "2013-02-21 01:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304393782005215234",
  "geo" : { },
  "id_str" : "304404610657955841",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater will they have any real info.. I wonder..",
  "id" : 304404610657955841,
  "in_reply_to_status_id" : 304393782005215234,
  "created_at" : "2013-02-21 01:38:09 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 39, 49 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "muoskypen",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/KOHXHAd55b",
      "expanded_url" : "http:\/\/makeuseof.com\/tag\/livescribe-sky-wi-fi-smartpen-review-and-giveaway-twitter-exclusive",
      "display_url" : "makeuseof.com\/tag\/livescribe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304359371654193152",
  "text" : "Retweet this and join the #giveaway at @makeuseof to win a FREE Livescribe Sky Wi-Fi Smartpen! #muoskypen http:\/\/t.co\/KOHXHAd55b",
  "id" : 304359371654193152,
  "created_at" : "2013-02-20 22:38:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peyton",
      "screen_name" : "PinkNotPanic",
      "indices" : [ 3, 16 ],
      "id_str" : "19316093",
      "id" : 19316093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304358455043571712",
  "text" : "RT @PinkNotPanic: Don't read the comments. Don't read the comments. Don't read the comments. Don't read the comments. Don't read the com ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304356508827795457",
    "text" : "Don't read the comments. Don't read the comments. Don't read the comments. Don't read the comments. Don't read the comments. Don't--damn it!",
    "id" : 304356508827795457,
    "created_at" : "2013-02-20 22:27:01 +0000",
    "user" : {
      "name" : "Peyton",
      "screen_name" : "PinkNotPanic",
      "protected" : false,
      "id_str" : "19316093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2332622496\/pd5hcos0ngqgay0iewzo_normal.jpeg",
      "id" : 19316093,
      "verified" : false
    }
  },
  "id" : 304358455043571712,
  "created_at" : "2013-02-20 22:34:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304357936573071360",
  "text" : "RT @abandontheherd: Get rid of anything that isn't useful, beautiful or joyful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304356756623085570",
    "text" : "Get rid of anything that isn't useful, beautiful or joyful.",
    "id" : 304356756623085570,
    "created_at" : "2013-02-20 22:28:00 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 304357936573071360,
  "created_at" : "2013-02-20 22:32:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304355247462162432",
  "text" : "law abiding citizens  o-O",
  "id" : 304355247462162432,
  "created_at" : "2013-02-20 22:22:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esmeralda",
      "screen_name" : "irelaxwithOH",
      "indices" : [ 3, 16 ],
      "id_str" : "1158709483",
      "id" : 1158709483
    }, {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 21, 32 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304346037856907264",
  "text" : "RT @irelaxwithOH: RT @lsfprogram: Treat others equally, with respect, kindness and support, free from judgments",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lou & Marilyn",
        "screen_name" : "LSFProgram",
        "indices" : [ 3, 14 ],
        "id_str" : "141944109",
        "id" : 141944109
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303257645647814656",
    "text" : "RT @lsfprogram: Treat others equally, with respect, kindness and support, free from judgments",
    "id" : 303257645647814656,
    "created_at" : "2013-02-17 21:40:31 +0000",
    "user" : {
      "name" : "Esmeralda",
      "screen_name" : "irelaxwithOH",
      "protected" : false,
      "id_str" : "1158709483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3528915875\/913ed85e62d03bc26c9685d7c94c80fd_normal.jpeg",
      "id" : 1158709483,
      "verified" : false
    }
  },
  "id" : 304346037856907264,
  "created_at" : "2013-02-20 21:45:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "God",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304341380002615297",
  "text" : "RT @ificouldtellu: #God does not create suffering nor does God create goodness. God is the infinite light of awareness that makes ALL ex ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "God",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304339876969578496",
    "text" : "#God does not create suffering nor does God create goodness. God is the infinite light of awareness that makes ALL experience possible",
    "id" : 304339876969578496,
    "created_at" : "2013-02-20 21:20:55 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 304341380002615297,
  "created_at" : "2013-02-20 21:26:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Untold Press",
      "screen_name" : "UntoldPress",
      "indices" : [ 3, 15 ],
      "id_str" : "499136312",
      "id" : 499136312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/kDG9jd0tA1",
      "expanded_url" : "http:\/\/www.amazon.com\/Flashy-Fiction-Other-Insane-ebook\/dp\/B009Q78TTM",
      "display_url" : "amazon.com\/Flashy-Fiction\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304341344946634754",
  "text" : "RT @UntoldPress: Last day FREE! Flashy Fiction and Other Insane Tales Vol 2 http:\/\/t.co\/kDG9jd0tA1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/kDG9jd0tA1",
        "expanded_url" : "http:\/\/www.amazon.com\/Flashy-Fiction-Other-Insane-ebook\/dp\/B009Q78TTM",
        "display_url" : "amazon.com\/Flashy-Fiction\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304339964617965568",
    "text" : "Last day FREE! Flashy Fiction and Other Insane Tales Vol 2 http:\/\/t.co\/kDG9jd0tA1",
    "id" : 304339964617965568,
    "created_at" : "2013-02-20 21:21:16 +0000",
    "user" : {
      "name" : "Untold Press",
      "screen_name" : "UntoldPress",
      "protected" : false,
      "id_str" : "499136312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844006349\/untold_logo_normal.jpg",
      "id" : 499136312,
      "verified" : false
    }
  },
  "id" : 304341344946634754,
  "created_at" : "2013-02-20 21:26:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 36, 52 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "subservientwoman",
      "indices" : [ 105, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/Zhocgt1e0b",
      "expanded_url" : "http:\/\/tiny.cc\/guntsw",
      "display_url" : "tiny.cc\/guntsw"
    } ]
  },
  "in_reply_to_status_id_str" : "304330889561784320",
  "geo" : { },
  "id_str" : "304336941976010754",
  "in_reply_to_user_id" : 116009507,
  "text" : "he's a twat. i want to slap him. MT @ChristnNitemare epically misogynistic sermon http:\/\/t.co\/Zhocgt1e0b #subservientwoman",
  "id" : 304336941976010754,
  "in_reply_to_status_id" : 304330889561784320,
  "created_at" : "2013-02-20 21:09:15 +0000",
  "in_reply_to_screen_name" : "ChristnNitemare",
  "in_reply_to_user_id_str" : "116009507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 3, 19 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Mo2VeloR",
      "expanded_url" : "http:\/\/tiny.cc\/guntsw",
      "display_url" : "tiny.cc\/guntsw"
    } ]
  },
  "geo" : { },
  "id_str" : "304334242157047809",
  "text" : "RT @ChristnNitemare: Pastor Steven Anderson delivers an epically misogynistic sermon entitled \u2018A Virtuous Woman\u2019 http:\/\/t.co\/Mo2VeloR @f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Feministing",
        "screen_name" : "feministing",
        "indices" : [ 113, 125 ],
        "id_str" : "30000912",
        "id" : 30000912
      }, {
        "name" : "Feministe",
        "screen_name" : "Feministe",
        "indices" : [ 127, 137 ],
        "id_str" : "16378267",
        "id" : 16378267
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/Mo2VeloR",
        "expanded_url" : "http:\/\/tiny.cc\/guntsw",
        "display_url" : "tiny.cc\/guntsw"
      } ]
    },
    "geo" : { },
    "id_str" : "304330889561784320",
    "in_reply_to_user_id" : 16378267,
    "text" : "Pastor Steven Anderson delivers an epically misogynistic sermon entitled \u2018A Virtuous Woman\u2019 http:\/\/t.co\/Mo2VeloR @feministing \n@Feministe",
    "id" : 304330889561784320,
    "created_at" : "2013-02-20 20:45:12 +0000",
    "in_reply_to_screen_name" : "Feministe",
    "in_reply_to_user_id_str" : "16378267",
    "user" : {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "protected" : false,
      "id_str" : "116009507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1537898085\/Christian_Nightmares_mug_normal.jpg",
      "id" : 116009507,
      "verified" : false
    }
  },
  "id" : 304334242157047809,
  "created_at" : "2013-02-20 20:58:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 66, 79 ]
    }, {
      "text" : "nature",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "photo",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/5AjiMs4X",
      "expanded_url" : "http:\/\/ow.ly\/hSwAR",
      "display_url" : "ow.ly\/hSwAR"
    } ]
  },
  "geo" : { },
  "id_str" : "304334145260224513",
  "text" : "RT @KerriFar: Woodpecker Wink :) ~ http:\/\/t.co\/5AjiMs4X  ~ #birds #birdwatching #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 52, 65 ]
      }, {
        "text" : "nature",
        "indices" : [ 66, 73 ]
      }, {
        "text" : "photo",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/5AjiMs4X",
        "expanded_url" : "http:\/\/ow.ly\/hSwAR",
        "display_url" : "ow.ly\/hSwAR"
      } ]
    },
    "geo" : { },
    "id_str" : "304330882276270080",
    "text" : "Woodpecker Wink :) ~ http:\/\/t.co\/5AjiMs4X  ~ #birds #birdwatching #nature #photo",
    "id" : 304330882276270080,
    "created_at" : "2013-02-20 20:45:11 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 304334145260224513,
  "created_at" : "2013-02-20 20:58:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304317254617677824",
  "geo" : { },
  "id_str" : "304333300779073536",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits Bingo! children are their own worlds unto themselves. we can provide direction but thats it.",
  "id" : 304333300779073536,
  "in_reply_to_status_id" : 304317254617677824,
  "created_at" : "2013-02-20 20:54:47 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304332225971888128",
  "text" : "RT @damienechols: The moment you say \"I am blessed\", blessings begin to move towards you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304319985466093569",
    "text" : "The moment you say \"I am blessed\", blessings begin to move towards you.",
    "id" : 304319985466093569,
    "created_at" : "2013-02-20 20:01:53 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 304332225971888128,
  "created_at" : "2013-02-20 20:50:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 21, 36 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304320211161595904",
  "geo" : { },
  "id_str" : "304332144086507522",
  "in_reply_to_user_id" : 96152195,
  "text" : "and everyday! : ) RT @luminanceriver Be in your own little bliss bubble today.",
  "id" : 304332144086507522,
  "in_reply_to_status_id" : 304320211161595904,
  "created_at" : "2013-02-20 20:50:12 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 52, 64 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304325737303900160",
  "geo" : { },
  "id_str" : "304330379240820736",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i always forget skin is an organ..lol  @Floridaline",
  "id" : 304330379240820736,
  "in_reply_to_status_id" : 304325737303900160,
  "created_at" : "2013-02-20 20:43:11 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris King",
      "screen_name" : "distant_angel",
      "indices" : [ 0, 14 ],
      "id_str" : "62819585",
      "id" : 62819585
    }, {
      "name" : "James Plaskett",
      "screen_name" : "JamesPlaskett",
      "indices" : [ 65, 79 ],
      "id_str" : "32552331",
      "id" : 32552331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304312638593191938",
  "geo" : { },
  "id_str" : "304329406518796289",
  "in_reply_to_user_id" : 62819585,
  "text" : "@distant_angel perhaps it has tricked us about everything... lol @JamesPlaskett @Skeptical_Lady",
  "id" : 304329406518796289,
  "in_reply_to_status_id" : 304312638593191938,
  "created_at" : "2013-02-20 20:39:19 +0000",
  "in_reply_to_screen_name" : "distant_angel",
  "in_reply_to_user_id_str" : "62819585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/5X1eUW4q",
      "expanded_url" : "http:\/\/amzn.to\/wpXG55",
      "display_url" : "amzn.to\/wpXG55"
    } ]
  },
  "geo" : { },
  "id_str" : "304060651851096064",
  "text" : "finished The Remaining by D.J. Molles http:\/\/t.co\/5X1eUW4q",
  "id" : 304060651851096064,
  "created_at" : "2013-02-20 02:51:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris King",
      "screen_name" : "distant_angel",
      "indices" : [ 0, 14 ],
      "id_str" : "62819585",
      "id" : 62819585
    }, {
      "name" : "James Plaskett",
      "screen_name" : "JamesPlaskett",
      "indices" : [ 67, 81 ],
      "id_str" : "32552331",
      "id" : 32552331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303991940800729088",
  "geo" : { },
  "id_str" : "304006798770323456",
  "in_reply_to_user_id" : 62819585,
  "text" : "@distant_angel hmph.. well, i like my twaddle and i'll keep it ; ) @JamesPlaskett @Skeptical_Lady",
  "id" : 304006798770323456,
  "in_reply_to_status_id" : 303991940800729088,
  "created_at" : "2013-02-19 23:17:23 +0000",
  "in_reply_to_screen_name" : "distant_angel",
  "in_reply_to_user_id_str" : "62819585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 3, 17 ],
      "id_str" : "186154646",
      "id" : 186154646
    }, {
      "name" : "John Bland",
      "screen_name" : "MrBland82",
      "indices" : [ 20, 30 ],
      "id_str" : "198939047",
      "id" : 198939047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303982644805398528",
  "text" : "RT @Cmdr_Hadfield: .@MrBland82 John, we go around Earth every 92 minutes, so we see 16 sunrises and 16 sunsets each day. They are beauti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Bland",
        "screen_name" : "MrBland82",
        "indices" : [ 1, 11 ],
        "id_str" : "198939047",
        "id" : 198939047
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "303980448965603330",
    "geo" : { },
    "id_str" : "303981256683704322",
    "in_reply_to_user_id" : 198939047,
    "text" : ".@MrBland82 John, we go around Earth every 92 minutes, so we see 16 sunrises and 16 sunsets each day. They are beautiful, and happen fast.",
    "id" : 303981256683704322,
    "in_reply_to_status_id" : 303980448965603330,
    "created_at" : "2013-02-19 21:35:53 +0000",
    "in_reply_to_screen_name" : "MrBland82",
    "in_reply_to_user_id_str" : "198939047",
    "user" : {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "protected" : false,
      "id_str" : "186154646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620788674414952456\/y_ozO3uO_normal.png",
      "id" : 186154646,
      "verified" : true
    }
  },
  "id" : 303982644805398528,
  "created_at" : "2013-02-19 21:41:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seanmay",
      "screen_name" : "seanmay",
      "indices" : [ 3, 11 ],
      "id_str" : "14446464",
      "id" : 14446464
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 13, 24 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/seanmay\/status\/303609384859209729\/photo\/1",
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ObmWKRTT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDajIH9CEAA0Lou.jpg",
      "id_str" : "303609384863404032",
      "id" : 303609384863404032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDajIH9CEAA0Lou.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ObmWKRTT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303976974890704896",
  "text" : "RT @seanmay: @TyrusBooks but did he ever ride a moose?!?! http:\/\/t.co\/ObmWKRTT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyrus Books",
        "screen_name" : "TyrusBooks",
        "indices" : [ 0, 11 ],
        "id_str" : "67336993",
        "id" : 67336993
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/seanmay\/status\/303609384859209729\/photo\/1",
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/ObmWKRTT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDajIH9CEAA0Lou.jpg",
        "id_str" : "303609384863404032",
        "id" : 303609384863404032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDajIH9CEAA0Lou.jpg",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ObmWKRTT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "303608386627436544",
    "geo" : { },
    "id_str" : "303609384859209729",
    "in_reply_to_user_id" : 67336993,
    "text" : "@TyrusBooks but did he ever ride a moose?!?! http:\/\/t.co\/ObmWKRTT",
    "id" : 303609384859209729,
    "in_reply_to_status_id" : 303608386627436544,
    "created_at" : "2013-02-18 20:58:12 +0000",
    "in_reply_to_screen_name" : "TyrusBooks",
    "in_reply_to_user_id_str" : "67336993",
    "user" : {
      "name" : "seanmay",
      "screen_name" : "seanmay",
      "protected" : false,
      "id_str" : "14446464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744726170868944896\/cdiY-g4P_normal.jpg",
      "id" : 14446464,
      "verified" : false
    }
  },
  "id" : 303976974890704896,
  "created_at" : "2013-02-19 21:18:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seanmay",
      "screen_name" : "seanmay",
      "indices" : [ 3, 11 ],
      "id_str" : "14446464",
      "id" : 14446464
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 38, 49 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303976773618651136",
  "text" : "RT @seanmay: Ok, last chance, because @TyrusBooks is awesome, I will buy someone a Kindle book. Any book. Just say so (no textbooks, you ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyrus Books",
        "screen_name" : "TyrusBooks",
        "indices" : [ 25, 36 ],
        "id_str" : "67336993",
        "id" : 67336993
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303974180314030080",
    "text" : "Ok, last chance, because @TyrusBooks is awesome, I will buy someone a Kindle book. Any book. Just say so (no textbooks, you vultures)",
    "id" : 303974180314030080,
    "created_at" : "2013-02-19 21:07:46 +0000",
    "user" : {
      "name" : "seanmay",
      "screen_name" : "seanmay",
      "protected" : false,
      "id_str" : "14446464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744726170868944896\/cdiY-g4P_normal.jpg",
      "id" : 14446464,
      "verified" : false
    }
  },
  "id" : 303976773618651136,
  "created_at" : "2013-02-19 21:18:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris King",
      "screen_name" : "distant_angel",
      "indices" : [ 0, 14 ],
      "id_str" : "62819585",
      "id" : 62819585
    }, {
      "name" : "James Plaskett",
      "screen_name" : "JamesPlaskett",
      "indices" : [ 46, 60 ],
      "id_str" : "32552331",
      "id" : 32552331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303941381846605824",
  "geo" : { },
  "id_str" : "303975675654713345",
  "in_reply_to_user_id" : 62819585,
  "text" : "@distant_angel so that makes them your enemy? @JamesPlaskett @Skeptical_Lady",
  "id" : 303975675654713345,
  "in_reply_to_status_id" : 303941381846605824,
  "created_at" : "2013-02-19 21:13:43 +0000",
  "in_reply_to_screen_name" : "distant_angel",
  "in_reply_to_user_id_str" : "62819585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303970132055687169",
  "text" : "we could have had a good healthcare system already.. or many science advances.. or everyone college educated.. etc.",
  "id" : 303970132055687169,
  "created_at" : "2013-02-19 20:51:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303969595671330817",
  "text" : "usa has no money due to it all going to WAR!",
  "id" : 303969595671330817,
  "created_at" : "2013-02-19 20:49:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303969411830800384",
  "text" : "RT @Jamiastar: Meet 6 Politicians Getting Rich from America's Endless Wars. The defense industry is a powerful and influential lobby htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/MP18QB9W",
        "expanded_url" : "http:\/\/www.alternet.org\/news-amp-politics\/meet-6-politicians-getting-rich-americas-endless-wars",
        "display_url" : "alternet.org\/news-amp-polit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303968389439844353",
    "text" : "Meet 6 Politicians Getting Rich from America's Endless Wars. The defense industry is a powerful and influential lobby http:\/\/t.co\/MP18QB9W",
    "id" : 303968389439844353,
    "created_at" : "2013-02-19 20:44:46 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 303969411830800384,
  "created_at" : "2013-02-19 20:48:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Debby Thorne",
      "screen_name" : "wildfreckle",
      "indices" : [ 27, 39 ],
      "id_str" : "42403735",
      "id" : 42403735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildfreckle\/status\/303834628337311746\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/cANKjHtt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDdv_BUCIAAm4PU.jpg",
      "id_str" : "303834628345700352",
      "id" : 303834628345700352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDdv_BUCIAAm4PU.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 476
      } ],
      "display_url" : "pic.twitter.com\/cANKjHtt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303968927199932416",
  "text" : "RT @KerriFar: FABULOUS! RT @wildfreckle: Look what I found chilling in the sun http:\/\/t.co\/cANKjHtt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Debby Thorne",
        "screen_name" : "wildfreckle",
        "indices" : [ 13, 25 ],
        "id_str" : "42403735",
        "id" : 42403735
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildfreckle\/status\/303834628337311746\/photo\/1",
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/cANKjHtt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDdv_BUCIAAm4PU.jpg",
        "id_str" : "303834628345700352",
        "id" : 303834628345700352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDdv_BUCIAAm4PU.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 476
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 476
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 476
        } ],
        "display_url" : "pic.twitter.com\/cANKjHtt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303967251558699009",
    "text" : "FABULOUS! RT @wildfreckle: Look what I found chilling in the sun http:\/\/t.co\/cANKjHtt",
    "id" : 303967251558699009,
    "created_at" : "2013-02-19 20:40:14 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 303968927199932416,
  "created_at" : "2013-02-19 20:46:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/W9ajTYMV",
      "expanded_url" : "http:\/\/www.alternet.org\/news-amp-politics\/texas-city-charge-car-accident-victims-2000-cost-first-responders",
      "display_url" : "alternet.org\/news-amp-polit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303968763387183104",
  "text" : "RT @Jamiastar: Texas City to Charge Car Accident Victims Up to $2,000 for the Cost of First Responders | Alternet http:\/\/t.co\/W9ajTYMV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/W9ajTYMV",
        "expanded_url" : "http:\/\/www.alternet.org\/news-amp-politics\/texas-city-charge-car-accident-victims-2000-cost-first-responders",
        "display_url" : "alternet.org\/news-amp-polit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303967724953038848",
    "text" : "Texas City to Charge Car Accident Victims Up to $2,000 for the Cost of First Responders | Alternet http:\/\/t.co\/W9ajTYMV",
    "id" : 303967724953038848,
    "created_at" : "2013-02-19 20:42:07 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 303968763387183104,
  "created_at" : "2013-02-19 20:46:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paperwhite",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303965913324060672",
  "geo" : { },
  "id_str" : "303967257694961664",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields LOVE my #paperwhite! : )",
  "id" : 303967257694961664,
  "in_reply_to_status_id" : 303965913324060672,
  "created_at" : "2013-02-19 20:40:16 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/BQGvLzbQ",
      "expanded_url" : "http:\/\/bookwi.se\/refurbished-kindle-paperwhite-for-99\/",
      "display_url" : "bookwi.se\/refurbished-ki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303967059329576960",
  "text" : "RT @adamrshields: Refurbished Kindle Paperwhite are back in stock for $99 http:\/\/t.co\/BQGvLzbQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/BQGvLzbQ",
        "expanded_url" : "http:\/\/bookwi.se\/refurbished-kindle-paperwhite-for-99\/",
        "display_url" : "bookwi.se\/refurbished-ki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303965913324060672",
    "text" : "Refurbished Kindle Paperwhite are back in stock for $99 http:\/\/t.co\/BQGvLzbQ",
    "id" : 303965913324060672,
    "created_at" : "2013-02-19 20:34:55 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 303967059329576960,
  "created_at" : "2013-02-19 20:39:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303966748326105089",
  "text" : "ok.. i probably wont bite.. just waddle off into the sunset..",
  "id" : 303966748326105089,
  "created_at" : "2013-02-19 20:38:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303965969242533888",
  "text" : "just dont put me in a box... i will climb out and then i'll bite you (maybe...)",
  "id" : 303965969242533888,
  "created_at" : "2013-02-19 20:35:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303965224766144512",
  "text" : "RT @TyrusBooks: Want digital review copies of our books months in advance of release date? Join Team Tyrus. I'm about to send out my fir ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303964976358518784",
    "text" : "Want digital review copies of our books months in advance of release date? Join Team Tyrus. I'm about to send out my first batch of books.",
    "id" : 303964976358518784,
    "created_at" : "2013-02-19 20:31:12 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 303965224766144512,
  "created_at" : "2013-02-19 20:32:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303962387487260672",
  "text" : "im too sensitive for my own good... sigh.",
  "id" : 303962387487260672,
  "created_at" : "2013-02-19 20:20:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "(((mikeyweasel)))",
      "screen_name" : "mikeytheweasel",
      "indices" : [ 105, 120 ],
      "id_str" : "372536288",
      "id" : 372536288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303958602933227520",
  "geo" : { },
  "id_str" : "303959659394519040",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny you wouldnt miss me just a teensy bit? jeepers kinda thought we were twitter friends... : ( @mikeytheweasel",
  "id" : 303959659394519040,
  "in_reply_to_status_id" : 303958602933227520,
  "created_at" : "2013-02-19 20:10:04 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 33, 47 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "(((mikeyweasel)))",
      "screen_name" : "mikeytheweasel",
      "indices" : [ 70, 85 ],
      "id_str" : "372536288",
      "id" : 372536288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303955310027083778",
  "geo" : { },
  "id_str" : "303955962132307968",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny ohh.. is that where @deisidiamonia gets amalek from? lol @mikeytheweasel",
  "id" : 303955962132307968,
  "in_reply_to_status_id" : 303955310027083778,
  "created_at" : "2013-02-19 19:55:23 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303954325418409984",
  "text" : "RT @TheGoldenMirror: Eyes are opened from the moment they see there's more to be seen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303954191112601600",
    "text" : "Eyes are opened from the moment they see there's more to be seen.",
    "id" : 303954191112601600,
    "created_at" : "2013-02-19 19:48:21 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 303954325418409984,
  "created_at" : "2013-02-19 19:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "(((mikeyweasel)))",
      "screen_name" : "mikeytheweasel",
      "indices" : [ 56, 71 ],
      "id_str" : "372536288",
      "id" : 372536288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303953379045044226",
  "geo" : { },
  "id_str" : "303954015471943680",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny arrgh.. depends upon the person behind it! @mikeytheweasel",
  "id" : 303954015471943680,
  "in_reply_to_status_id" : 303953379045044226,
  "created_at" : "2013-02-19 19:47:39 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "butterfly",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "nature",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "photo",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/khtXl1HG",
      "expanded_url" : "http:\/\/ow.ly\/hQm8I",
      "display_url" : "ow.ly\/hQm8I"
    } ]
  },
  "geo" : { },
  "id_str" : "303953792276258817",
  "text" : "RT @KerriFar: Gentleness IS Strength ~ http:\/\/t.co\/khtXl1HG  ~ #butterfly encounter ~ #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "butterfly",
        "indices" : [ 49, 59 ]
      }, {
        "text" : "nature",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "photo",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/khtXl1HG",
        "expanded_url" : "http:\/\/ow.ly\/hQm8I",
        "display_url" : "ow.ly\/hQm8I"
      } ]
    },
    "geo" : { },
    "id_str" : "303953439736614912",
    "text" : "Gentleness IS Strength ~ http:\/\/t.co\/khtXl1HG  ~ #butterfly encounter ~ #nature #photo",
    "id" : 303953439736614912,
    "created_at" : "2013-02-19 19:45:21 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 303953792276258817,
  "created_at" : "2013-02-19 19:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "(((mikeyweasel)))",
      "screen_name" : "mikeytheweasel",
      "indices" : [ 23, 38 ],
      "id_str" : "372536288",
      "id" : 372536288
    }, {
      "name" : "Anu Anzu",
      "screen_name" : "AnuAnzu",
      "indices" : [ 39, 47 ],
      "id_str" : "301791092",
      "id" : 301791092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303948415702822912",
  "geo" : { },
  "id_str" : "303948899427688448",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny buddhism? @mikeytheweasel @AnuAnzu",
  "id" : 303948899427688448,
  "in_reply_to_status_id" : 303948415702822912,
  "created_at" : "2013-02-19 19:27:19 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Anu Anzu",
      "screen_name" : "AnuAnzu",
      "indices" : [ 19, 27 ],
      "id_str" : "301791092",
      "id" : 301791092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303946340843532288",
  "geo" : { },
  "id_str" : "303946976062488576",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny : ((( @AnuAnzu",
  "id" : 303946976062488576,
  "in_reply_to_status_id" : 303946340843532288,
  "created_at" : "2013-02-19 19:19:40 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Anu Anzu",
      "screen_name" : "AnuAnzu",
      "indices" : [ 58, 66 ],
      "id_str" : "301791092",
      "id" : 301791092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303944967678722048",
  "geo" : { },
  "id_str" : "303946058084515840",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny faith is a tool. like guns, user's intent... @AnuAnzu",
  "id" : 303946058084515840,
  "in_reply_to_status_id" : 303944967678722048,
  "created_at" : "2013-02-19 19:16:01 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Anu Anzu",
      "screen_name" : "AnuAnzu",
      "indices" : [ 36, 44 ],
      "id_str" : "301791092",
      "id" : 301791092
    }, {
      "name" : "A michael hall",
      "screen_name" : "AAmichaelhall",
      "indices" : [ 45, 59 ],
      "id_str" : "898639093",
      "id" : 898639093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303943542798184448",
  "geo" : { },
  "id_str" : "303945181776969729",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny jeepers, johnny... : ( @AnuAnzu @AAmichaelhall",
  "id" : 303945181776969729,
  "in_reply_to_status_id" : 303943542798184448,
  "created_at" : "2013-02-19 19:12:33 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/N8gZsx0Y",
      "expanded_url" : "http:\/\/tinyurl.com\/75q2u2e",
      "display_url" : "tinyurl.com\/75q2u2e"
    } ]
  },
  "geo" : { },
  "id_str" : "303936731386900480",
  "text" : "RT @Soulseedzforall: No act of kindness, no matter how small, is ever wasted. Aesop, http:\/\/t.co\/N8gZsx0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/N8gZsx0Y",
        "expanded_url" : "http:\/\/tinyurl.com\/75q2u2e",
        "display_url" : "tinyurl.com\/75q2u2e"
      } ]
    },
    "geo" : { },
    "id_str" : "303936622242697216",
    "text" : "No act of kindness, no matter how small, is ever wasted. Aesop, http:\/\/t.co\/N8gZsx0Y",
    "id" : 303936622242697216,
    "created_at" : "2013-02-19 18:38:32 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 303936731386900480,
  "created_at" : "2013-02-19 18:38:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ynganid",
      "screen_name" : "ynganid",
      "indices" : [ 49, 57 ],
      "id_str" : "143145876",
      "id" : 143145876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303935498995523584",
  "geo" : { },
  "id_str" : "303936223439908864",
  "in_reply_to_user_id" : 143145876,
  "text" : "if i dont like it, i ignore it. works for me! RT @ynganid how does anyone ever deal with anything?",
  "id" : 303936223439908864,
  "in_reply_to_status_id" : 303935498995523584,
  "created_at" : "2013-02-19 18:36:57 +0000",
  "in_reply_to_screen_name" : "ynganid",
  "in_reply_to_user_id_str" : "143145876",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303934351731740672",
  "text" : "im not a wind person. its too aggressive for me. think thats why im not big on ocean, either. prefer the calmer lake.",
  "id" : 303934351731740672,
  "created_at" : "2013-02-19 18:29:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris King",
      "screen_name" : "distant_angel",
      "indices" : [ 0, 14 ],
      "id_str" : "62819585",
      "id" : 62819585
    }, {
      "name" : "James Plaskett",
      "screen_name" : "JamesPlaskett",
      "indices" : [ 69, 83 ],
      "id_str" : "32552331",
      "id" : 32552331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303912310806818816",
  "geo" : { },
  "id_str" : "303933489714192384",
  "in_reply_to_user_id" : 62819585,
  "text" : "@distant_angel but yes there are those ppl who use label w arrogance @JamesPlaskett @Skeptical_Lady",
  "id" : 303933489714192384,
  "in_reply_to_status_id" : 303912310806818816,
  "created_at" : "2013-02-19 18:26:05 +0000",
  "in_reply_to_screen_name" : "distant_angel",
  "in_reply_to_user_id_str" : "62819585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris King",
      "screen_name" : "distant_angel",
      "indices" : [ 0, 14 ],
      "id_str" : "62819585",
      "id" : 62819585
    }, {
      "name" : "James Plaskett",
      "screen_name" : "JamesPlaskett",
      "indices" : [ 99, 113 ],
      "id_str" : "32552331",
      "id" : 32552331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303912310806818816",
  "geo" : { },
  "id_str" : "303933235128320000",
  "in_reply_to_user_id" : 62819585,
  "text" : "@distant_angel that isnt fair to say cuz ppl can be theist yet not follow any particular religion. @JamesPlaskett @Skeptical_Lady",
  "id" : 303933235128320000,
  "in_reply_to_status_id" : 303912310806818816,
  "created_at" : "2013-02-19 18:25:04 +0000",
  "in_reply_to_screen_name" : "distant_angel",
  "in_reply_to_user_id_str" : "62819585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris King",
      "screen_name" : "distant_angel",
      "indices" : [ 67, 81 ],
      "id_str" : "62819585",
      "id" : 62819585
    }, {
      "name" : "James Plaskett",
      "screen_name" : "JamesPlaskett",
      "indices" : [ 82, 96 ],
      "id_str" : "32552331",
      "id" : 32552331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303920142604181504",
  "text" : "@Skeptical_Lady i follow my own path. doesnt mean i feel superior. @distant_angel @JamesPlaskett",
  "id" : 303920142604181504,
  "created_at" : "2013-02-19 17:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suleikha Snyder",
      "screen_name" : "suleikhasnyder",
      "indices" : [ 3, 18 ],
      "id_str" : "169033588",
      "id" : 169033588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303919338061197313",
  "text" : "RT @suleikhasnyder: The one disadvantage to a Kindle: It makes throwing a book against the wall rather inadvisable.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303912668715159552",
    "text" : "The one disadvantage to a Kindle: It makes throwing a book against the wall rather inadvisable.",
    "id" : 303912668715159552,
    "created_at" : "2013-02-19 17:03:21 +0000",
    "user" : {
      "name" : "Suleikha Snyder",
      "screen_name" : "suleikhasnyder",
      "protected" : false,
      "id_str" : "169033588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737772016627908608\/zmlcZOMF_normal.jpg",
      "id" : 169033588,
      "verified" : false
    }
  },
  "id" : 303919338061197313,
  "created_at" : "2013-02-19 17:29:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "A michael hall",
      "screen_name" : "AAmichaelhall",
      "indices" : [ 49, 63 ],
      "id_str" : "898639093",
      "id" : 898639093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303914523969073152",
  "geo" : { },
  "id_str" : "303918451762810880",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny and some of us are leeches, like me @AAmichaelhall",
  "id" : 303918451762810880,
  "in_reply_to_status_id" : 303914523969073152,
  "created_at" : "2013-02-19 17:26:20 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kam",
      "screen_name" : "kamtweeting",
      "indices" : [ 3, 15 ],
      "id_str" : "415710909",
      "id" : 415710909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303870200275664896",
  "text" : "RT @kamtweeting: When you open your mind to the impossible, sometimes you find the truth. And sometimes you start believing what once wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303868355243298817",
    "text" : "When you open your mind to the impossible, sometimes you find the truth. And sometimes you start believing what once was absurd.",
    "id" : 303868355243298817,
    "created_at" : "2013-02-19 14:07:16 +0000",
    "user" : {
      "name" : "kam",
      "screen_name" : "kamtweeting",
      "protected" : false,
      "id_str" : "415710909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781513917306724353\/lIzdnPCW_normal.jpg",
      "id" : 415710909,
      "verified" : false
    }
  },
  "id" : 303870200275664896,
  "created_at" : "2013-02-19 14:14:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kam",
      "screen_name" : "kamtweeting",
      "indices" : [ 3, 15 ],
      "id_str" : "415710909",
      "id" : 415710909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303870047795949570",
  "text" : "RT @kamtweeting: We are all fucked up. It's just remarkable how many of us appear to be normal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302929496825278464",
    "text" : "We are all fucked up. It's just remarkable how many of us appear to be normal.",
    "id" : 302929496825278464,
    "created_at" : "2013-02-16 23:56:34 +0000",
    "user" : {
      "name" : "kam",
      "screen_name" : "kamtweeting",
      "protected" : false,
      "id_str" : "415710909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781513917306724353\/lIzdnPCW_normal.jpg",
      "id" : 415710909,
      "verified" : false
    }
  },
  "id" : 303870047795949570,
  "created_at" : "2013-02-19 14:13:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303868994539102209",
  "text" : "what if im wrong... about everything?",
  "id" : 303868994539102209,
  "created_at" : "2013-02-19 14:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/OvIj8bIH",
      "expanded_url" : "http:\/\/tl.gd\/l37cvm",
      "display_url" : "tl.gd\/l37cvm"
    } ]
  },
  "geo" : { },
  "id_str" : "303678639214575616",
  "text" : "Driscoll is a twat. \u201CIn Revelation, Jesus is a pride fighter with a tattoo down His leg, a sword in His hand (cont) http:\/\/t.co\/OvIj8bIH",
  "id" : 303678639214575616,
  "created_at" : "2013-02-19 01:33:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 0, 10 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303639710058811392",
  "geo" : { },
  "id_str" : "303653954800205826",
  "in_reply_to_user_id" : 89621202,
  "text" : "@joyceetta he's such a twat! ugh!",
  "id" : 303653954800205826,
  "in_reply_to_status_id" : 303639710058811392,
  "created_at" : "2013-02-18 23:55:19 +0000",
  "in_reply_to_screen_name" : "joyceetta",
  "in_reply_to_user_id_str" : "89621202",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303634999939330049",
  "geo" : { },
  "id_str" : "303635624781553664",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon that does not sound like a good idea...",
  "id" : 303635624781553664,
  "in_reply_to_status_id" : 303634999939330049,
  "created_at" : "2013-02-18 22:42:28 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303595048329682944",
  "geo" : { },
  "id_str" : "303595714712334336",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses our aussie tried to bite when put into cage (4mo,spay surgery) .. was told she could never board there..lol",
  "id" : 303595714712334336,
  "in_reply_to_status_id" : 303595048329682944,
  "created_at" : "2013-02-18 20:03:53 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303595231297818624",
  "text" : "what makes one cause more deserving than another? nothing!",
  "id" : 303595231297818624,
  "created_at" : "2013-02-18 20:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303594898194575361",
  "text" : "im not big on causes...",
  "id" : 303594898194575361,
  "created_at" : "2013-02-18 20:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceGhoti",
      "screen_name" : "SpaceGhoti",
      "indices" : [ 0, 11 ],
      "id_str" : "441357531",
      "id" : 441357531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303578451611365376",
  "geo" : { },
  "id_str" : "303587635555864577",
  "in_reply_to_user_id" : 441357531,
  "text" : "@SpaceGhoti omg.. there's that icky word again! :O @mattylong28 @Skeptical_Lady",
  "id" : 303587635555864577,
  "in_reply_to_status_id" : 303578451611365376,
  "created_at" : "2013-02-18 19:31:47 +0000",
  "in_reply_to_screen_name" : "SpaceGhoti",
  "in_reply_to_user_id_str" : "441357531",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceGhoti",
      "screen_name" : "SpaceGhoti",
      "indices" : [ 91, 102 ],
      "id_str" : "441357531",
      "id" : 441357531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303587128569376769",
  "text" : "@Skeptical_Lady most ppl make decisions on emotions. thats why sex sells..lol @mattylong28 @SpaceGhoti",
  "id" : 303587128569376769,
  "created_at" : "2013-02-18 19:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303585738967093248",
  "text" : "a lake front vermont summer house.. go south for winter in RV. that sounds good.",
  "id" : 303585738967093248,
  "created_at" : "2013-02-18 19:24:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303585106696757248",
  "text" : "we could never live in a community. hubby likes privacy\/space and we have dog.",
  "id" : 303585106696757248,
  "created_at" : "2013-02-18 19:21:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Morrissey",
      "screen_name" : "drnickmorr",
      "indices" : [ 52, 63 ],
      "id_str" : "26351157",
      "id" : 26351157
    }, {
      "name" : "Think_For_Yourself",
      "screen_name" : "thinkblue77",
      "indices" : [ 64, 76 ],
      "id_str" : "386249411",
      "id" : 386249411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303576875668754432",
  "text" : "@Skeptical_Lady hmm.. no, thats not what i think... @drnickmorr @thinkblue77",
  "id" : 303576875668754432,
  "created_at" : "2013-02-18 18:49:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303556372530868224",
  "geo" : { },
  "id_str" : "303558131923972097",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses good luck, riley!",
  "id" : 303558131923972097,
  "in_reply_to_status_id" : 303556372530868224,
  "created_at" : "2013-02-18 17:34:33 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brain",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "cell",
      "indices" : [ 123, 128 ]
    }, {
      "text" : "DNA",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/D7cU8rm4",
      "expanded_url" : "http:\/\/bit.ly\/LlIr2x",
      "display_url" : "bit.ly\/LlIr2x"
    } ]
  },
  "geo" : { },
  "id_str" : "303557081963835393",
  "text" : "RT @jonlieffmd: The ability of a cell to elaborately self edit itself shows cellular awareness http:\/\/t.co\/D7cU8rm4 #brain #cell #DNA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brain",
        "indices" : [ 100, 106 ]
      }, {
        "text" : "cell",
        "indices" : [ 107, 112 ]
      }, {
        "text" : "DNA",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/D7cU8rm4",
        "expanded_url" : "http:\/\/bit.ly\/LlIr2x",
        "display_url" : "bit.ly\/LlIr2x"
      } ]
    },
    "geo" : { },
    "id_str" : "303207177013821441",
    "text" : "The ability of a cell to elaborately self edit itself shows cellular awareness http:\/\/t.co\/D7cU8rm4 #brain #cell #DNA",
    "id" : 303207177013821441,
    "created_at" : "2013-02-17 18:19:58 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 303557081963835393,
  "created_at" : "2013-02-18 17:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "indices" : [ 3, 15 ],
      "id_str" : "38205414",
      "id" : 38205414
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marcuschown\/status\/303409641256280064\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/E6qPbnwb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDXtdhFCYAEeYWe.png",
      "id_str" : "303409641268862977",
      "id" : 303409641268862977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDXtdhFCYAEeYWe.png",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E6qPbnwb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/yyqWPQia",
      "expanded_url" : "http:\/\/tinyurl.com\/bcnbmyb",
      "display_url" : "tinyurl.com\/bcnbmyb"
    } ]
  },
  "geo" : { },
  "id_str" : "303556085787267072",
  "text" : "RT @marcuschown: Sunset no human being has ever seen - on Mars http:\/\/t.co\/yyqWPQia http:\/\/t.co\/E6qPbnwb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marcuschown\/status\/303409641256280064\/photo\/1",
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/E6qPbnwb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDXtdhFCYAEeYWe.png",
        "id_str" : "303409641268862977",
        "id" : 303409641268862977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDXtdhFCYAEeYWe.png",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/E6qPbnwb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/yyqWPQia",
        "expanded_url" : "http:\/\/tinyurl.com\/bcnbmyb",
        "display_url" : "tinyurl.com\/bcnbmyb"
      } ]
    },
    "geo" : { },
    "id_str" : "303409641256280064",
    "text" : "Sunset no human being has ever seen - on Mars http:\/\/t.co\/yyqWPQia http:\/\/t.co\/E6qPbnwb",
    "id" : 303409641256280064,
    "created_at" : "2013-02-18 07:44:30 +0000",
    "user" : {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "protected" : false,
      "id_str" : "38205414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681518625090580480\/BJUBjRiS_normal.jpg",
      "id" : 38205414,
      "verified" : false
    }
  },
  "id" : 303556085787267072,
  "created_at" : "2013-02-18 17:26:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oshum",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303554670889168898",
  "text" : "RT @oshum: Neither Man nor God...do I fear...LOVE is the feeling I AM. #oshum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oshum",
        "indices" : [ 60, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303552262494633984",
    "text" : "Neither Man nor God...do I fear...LOVE is the feeling I AM. #oshum",
    "id" : 303552262494633984,
    "created_at" : "2013-02-18 17:11:13 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 303554670889168898,
  "created_at" : "2013-02-18 17:20:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303554250930274307",
  "text" : "RT @ChrisCapparell: What do I believe in? I believe in chasing the mysterious until it catches you, and the stars fall from the sky.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303545151928803329",
    "text" : "What do I believe in? I believe in chasing the mysterious until it catches you, and the stars fall from the sky.",
    "id" : 303545151928803329,
    "created_at" : "2013-02-18 16:42:58 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 303554250930274307,
  "created_at" : "2013-02-18 17:19:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/EAGHo14t",
      "expanded_url" : "http:\/\/bit.ly\/4Tl8rV",
      "display_url" : "bit.ly\/4Tl8rV"
    } ]
  },
  "geo" : { },
  "id_str" : "303545367348256768",
  "text" : "RT @drbloem: Student Suspended And Assaulted For Handing Out ANTI-VACCINE Fliers  http:\/\/t.co\/EAGHo14t #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/EAGHo14t",
        "expanded_url" : "http:\/\/bit.ly\/4Tl8rV",
        "display_url" : "bit.ly\/4Tl8rV"
      } ]
    },
    "geo" : { },
    "id_str" : "303543479945031680",
    "text" : "Student Suspended And Assaulted For Handing Out ANTI-VACCINE Fliers  http:\/\/t.co\/EAGHo14t #health",
    "id" : 303543479945031680,
    "created_at" : "2013-02-18 16:36:19 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 303545367348256768,
  "created_at" : "2013-02-18 16:43:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303545045221531648",
  "text" : "RT @LaughingBaba: Don't take yourself so seriously. No one else does.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303541716022067200",
    "text" : "Don't take yourself so seriously. No one else does.",
    "id" : 303541716022067200,
    "created_at" : "2013-02-18 16:29:19 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 303545045221531648,
  "created_at" : "2013-02-18 16:42:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Morrissey",
      "screen_name" : "drnickmorr",
      "indices" : [ 0, 11 ],
      "id_str" : "26351157",
      "id" : 26351157
    }, {
      "name" : "Think_For_Yourself",
      "screen_name" : "thinkblue77",
      "indices" : [ 76, 88 ],
      "id_str" : "386249411",
      "id" : 386249411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theist",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303531535708065792",
  "geo" : { },
  "id_str" : "303544963633913856",
  "in_reply_to_user_id" : 26351157,
  "text" : "@drnickmorr dont think ive ever been called arrogant..lol.. @Skeptical_Lady @thinkblue77 #theist",
  "id" : 303544963633913856,
  "in_reply_to_status_id" : 303531535708065792,
  "created_at" : "2013-02-18 16:42:13 +0000",
  "in_reply_to_screen_name" : "drnickmorr",
  "in_reply_to_user_id_str" : "26351157",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303533853082017792",
  "geo" : { },
  "id_str" : "303543943176536064",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste hmm.. maybe. in some cases. going outside your comfort zone for well-being of child. bucking social norms for child.",
  "id" : 303543943176536064,
  "in_reply_to_status_id" : 303533853082017792,
  "created_at" : "2013-02-18 16:38:10 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 0, 13 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303523329011240961",
  "geo" : { },
  "id_str" : "303528323894628352",
  "in_reply_to_user_id" : 67346912,
  "text" : "@wildwitchyju hehe.. my dad and i shared a weird sense of humor. fond memories. : )",
  "id" : 303528323894628352,
  "in_reply_to_status_id" : 303523329011240961,
  "created_at" : "2013-02-18 15:36:06 +0000",
  "in_reply_to_screen_name" : "wildwitchyju",
  "in_reply_to_user_id_str" : "67346912",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303524049638813696",
  "text" : "RT @Rodd4Real: I'm difficult and confused at times, but I promise I'm worth it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303520678970269696",
    "text" : "I'm difficult and confused at times, but I promise I'm worth it.",
    "id" : 303520678970269696,
    "created_at" : "2013-02-18 15:05:43 +0000",
    "user" : {
      "name" : "Rodd Cruz",
      "screen_name" : "ItsYaBoyRodd",
      "protected" : false,
      "id_str" : "21929308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799436282309046272\/bWYxsyqQ_normal.jpg",
      "id" : 21929308,
      "verified" : false
    }
  },
  "id" : 303524049638813696,
  "created_at" : "2013-02-18 15:19:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303523991283462145",
  "text" : "RT @NelsonFiction: You were created to be a light. So be that to the scared&amp;broken. Be that, &amp;watch what happens to fear. #Broke ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BrokenWings",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/vHsVKJpU",
        "expanded_url" : "http:\/\/ow.ly\/h6ADI",
        "display_url" : "ow.ly\/h6ADI"
      } ]
    },
    "geo" : { },
    "id_str" : "303520707005005824",
    "text" : "You were created to be a light. So be that to the scared&amp;broken. Be that, &amp;watch what happens to fear. #BrokenWings http:\/\/t.co\/vHsVKJpU",
    "id" : 303520707005005824,
    "created_at" : "2013-02-18 15:05:50 +0000",
    "user" : {
      "name" : "TNZFiction",
      "screen_name" : "TNZFiction",
      "protected" : false,
      "id_str" : "113483630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3476074316\/bb1f0680a3472e1f316fb930048ce35d_normal.jpeg",
      "id" : 113483630,
      "verified" : false
    }
  },
  "id" : 303523991283462145,
  "created_at" : "2013-02-18 15:18:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 98, 114 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/2o9S0qLc",
      "expanded_url" : "http:\/\/wp.me\/p2fXqB-Af",
      "display_url" : "wp.me\/p2fXqB-Af"
    } ]
  },
  "geo" : { },
  "id_str" : "303520584858472448",
  "text" : "Wiley the coyote:  A Wisconsin hunter\u2019s story of love and transformation http:\/\/t.co\/2o9S0qLc via @wordpressdotcom",
  "id" : 303520584858472448,
  "created_at" : "2013-02-18 15:05:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "S. L\u00E9vesque",
      "screen_name" : "StefanLevesque",
      "indices" : [ 28, 43 ],
      "id_str" : "29595882",
      "id" : 29595882
    }, {
      "name" : "Kat White",
      "screen_name" : "kat_white",
      "indices" : [ 48, 58 ],
      "id_str" : "20744206",
      "id" : 20744206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/lUHjIYjn",
      "expanded_url" : "http:\/\/bit.ly\/WQ96ix",
      "display_url" : "bit.ly\/WQ96ix"
    } ]
  },
  "geo" : { },
  "id_str" : "303323548162863105",
  "text" : "RT @KerriFar: Oh I LOVE! RT @stefanlevesque: RT @kat_white: He was peeking into my window http:\/\/t.co\/lUHjIYjn #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "S. L\u00E9vesque",
        "screen_name" : "StefanLevesque",
        "indices" : [ 14, 29 ],
        "id_str" : "29595882",
        "id" : 29595882
      }, {
        "name" : "Kat White",
        "screen_name" : "kat_white",
        "indices" : [ 34, 44 ],
        "id_str" : "20744206",
        "id" : 20744206
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/lUHjIYjn",
        "expanded_url" : "http:\/\/bit.ly\/WQ96ix",
        "display_url" : "bit.ly\/WQ96ix"
      } ]
    },
    "geo" : { },
    "id_str" : "303317943385743361",
    "text" : "Oh I LOVE! RT @stefanlevesque: RT @kat_white: He was peeking into my window http:\/\/t.co\/lUHjIYjn #photography",
    "id" : 303317943385743361,
    "created_at" : "2013-02-18 01:40:07 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 303323548162863105,
  "created_at" : "2013-02-18 02:02:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/RUBGlzeF",
      "expanded_url" : "http:\/\/amzn.to\/jppYm9",
      "display_url" : "amzn.to\/jppYm9"
    } ]
  },
  "geo" : { },
  "id_str" : "303321368060104704",
  "text" : "finished This Perfect Day by Ira Levin http:\/\/t.co\/RUBGlzeF",
  "id" : 303321368060104704,
  "created_at" : "2013-02-18 01:53:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "utopia",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303237527517675521",
  "text" : "wow.. loving This Perfect Day by Ira Levin .. so much to think about.. #utopia",
  "id" : 303237527517675521,
  "created_at" : "2013-02-17 20:20:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303215740935368706",
  "text" : "RT @ificouldtellu: Everything affects everything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303212740711948288",
    "text" : "Everything affects everything.",
    "id" : 303212740711948288,
    "created_at" : "2013-02-17 18:42:05 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 303215740935368706,
  "created_at" : "2013-02-17 18:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303213620634996736",
  "geo" : { },
  "id_str" : "303215594566717440",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides yes.. they dont understand same coin, diff side. \"im right, you're wrong\" (regarding militant atheism)",
  "id" : 303215594566717440,
  "in_reply_to_status_id" : 303213620634996736,
  "created_at" : "2013-02-17 18:53:25 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303200447118852096",
  "text" : "@CaseMyKindle any pics of inside of case?",
  "id" : 303200447118852096,
  "created_at" : "2013-02-17 17:53:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "doves",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "nature",
      "indices" : [ 83, 90 ]
    }, {
      "text" : "photo",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/fTZB5JsE",
      "expanded_url" : "http:\/\/ow.ly\/hMKZm",
      "display_url" : "ow.ly\/hMKZm"
    } ]
  },
  "geo" : { },
  "id_str" : "303198918949363713",
  "text" : "RT @KerriFar: Try a little Tenderness .... ~ http:\/\/t.co\/fTZB5JsE  ~ #birds #doves #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 55, 61 ]
      }, {
        "text" : "doves",
        "indices" : [ 62, 68 ]
      }, {
        "text" : "nature",
        "indices" : [ 69, 76 ]
      }, {
        "text" : "photo",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/fTZB5JsE",
        "expanded_url" : "http:\/\/ow.ly\/hMKZm",
        "display_url" : "ow.ly\/hMKZm"
      } ]
    },
    "geo" : { },
    "id_str" : "303198424101163008",
    "text" : "Try a little Tenderness .... ~ http:\/\/t.co\/fTZB5JsE  ~ #birds #doves #nature #photo",
    "id" : 303198424101163008,
    "created_at" : "2013-02-17 17:45:12 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 303198918949363713,
  "created_at" : "2013-02-17 17:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303194241935495168",
  "geo" : { },
  "id_str" : "303196852449316864",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny unicorns are real.. ive got a unicorn horn!",
  "id" : 303196852449316864,
  "in_reply_to_status_id" : 303194241935495168,
  "created_at" : "2013-02-17 17:38:57 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303169644997521409",
  "text" : "RT @LukeRomyn: Instead of prescribing antidepressant pills doctors should just prescribe puppies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303166831504543744",
    "text" : "Instead of prescribing antidepressant pills doctors should just prescribe puppies.",
    "id" : 303166831504543744,
    "created_at" : "2013-02-17 15:39:39 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 303169644997521409,
  "created_at" : "2013-02-17 15:50:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "indices" : [ 3, 16 ],
      "id_str" : "88882302",
      "id" : 88882302
    }, {
      "name" : "Quexistence",
      "screen_name" : "Quexistence",
      "indices" : [ 115, 127 ],
      "id_str" : "830155398",
      "id" : 830155398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303158948465344513",
  "text" : "RT @TweetTheBook: #FREE 02\/16-02\/17~Quexistence:The Quest for the Meaning of Existence:Time Dreams by Tom Stafford @quexistence http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quexistence",
        "screen_name" : "Quexistence",
        "indices" : [ 97, 109 ],
        "id_str" : "830155398",
        "id" : 830155398
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FREE",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "FreeWill",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/T2IeahiA",
        "expanded_url" : "http:\/\/ow.ly\/hL1mH",
        "display_url" : "ow.ly\/hL1mH"
      } ]
    },
    "geo" : { },
    "id_str" : "303157311491420161",
    "text" : "#FREE 02\/16-02\/17~Quexistence:The Quest for the Meaning of Existence:Time Dreams by Tom Stafford @quexistence http:\/\/t.co\/T2IeahiA #FreeWill",
    "id" : 303157311491420161,
    "created_at" : "2013-02-17 15:01:50 +0000",
    "user" : {
      "name" : "Jeff Bennington",
      "screen_name" : "TweetTheBook",
      "protected" : false,
      "id_str" : "88882302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723538520174780416\/myOVJeXG_normal.jpg",
      "id" : 88882302,
      "verified" : false
    }
  },
  "id" : 303158948465344513,
  "created_at" : "2013-02-17 15:08:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 77, 86 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/R5qJrXUk",
      "expanded_url" : "http:\/\/gu.com\/p\/3dyh4\/tw",
      "display_url" : "gu.com\/p\/3dyh4\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "303156369522053121",
  "text" : "It's not what a library stocks, it's what it shares http:\/\/t.co\/R5qJrXUk via @guardian",
  "id" : 303156369522053121,
  "created_at" : "2013-02-17 14:58:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 2, 15 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303139314425016321",
  "geo" : { },
  "id_str" : "303154116467761152",
  "in_reply_to_user_id" : 14835882,
  "text" : ". @adamrshields ooh, another good looking scifi &gt;&gt; Nightfall .. do I or don't I? hmm.. lol",
  "id" : 303154116467761152,
  "in_reply_to_status_id" : 303139314425016321,
  "created_at" : "2013-02-17 14:49:08 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/V3D26fWI",
      "expanded_url" : "http:\/\/amzn.to\/YoyNUV",
      "display_url" : "amzn.to\/YoyNUV"
    } ]
  },
  "geo" : { },
  "id_str" : "302957755021537280",
  "text" : "finished Seven Strange Years: Real Letters - Strange Stories by R.j Ruud http:\/\/t.co\/V3D26fWI",
  "id" : 302957755021537280,
  "created_at" : "2013-02-17 01:48:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 44, 57 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "litfic",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "mystery",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/ZkXD6IRd",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B0095YE65M\/ref=cm_sw_r_tw_ask_WO06F.188G6D9",
      "display_url" : "amazon.com\/dp\/B0095YE65M\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302943379430440962",
  "text" : "I just bought: 'BLUFF' by Lenore Skomal via @amazonkindle - curr. free #litfic #mystery http:\/\/t.co\/ZkXD6IRd",
  "id" : 302943379430440962,
  "created_at" : "2013-02-17 00:51:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302913009603461120",
  "text" : "@SamsaricWarrior (((hugs))) : ) yes, you are! lol",
  "id" : 302913009603461120,
  "created_at" : "2013-02-16 22:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302821807684218880",
  "geo" : { },
  "id_str" : "302912587992006657",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ohh so beautiful! : )",
  "id" : 302912587992006657,
  "in_reply_to_status_id" : 302821807684218880,
  "created_at" : "2013-02-16 22:49:23 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 51, 64 ],
      "id_str" : "84249568",
      "id" : 84249568
    }, {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 103, 116 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "hightech",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/YQiRUdpy",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B004XEC084\/ref=cm_sw_r_tw_ask_irv5F.1SZWPS2",
      "display_url" : "amazon.com\/dp\/B004XEC084\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302828285954510848",
  "text" : "I just bought: 'This Perfect Day' by Ira Levin via @amazonkindle - curr $1.99 #scifi #hightech (thanks @bookwiseblog ) http:\/\/t.co\/YQiRUdpy",
  "id" : 302828285954510848,
  "created_at" : "2013-02-16 17:14:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302788096095821825",
  "geo" : { },
  "id_str" : "302803472720461825",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny that man gets off on all the attention. ignore him.",
  "id" : 302803472720461825,
  "in_reply_to_status_id" : 302788096095821825,
  "created_at" : "2013-02-16 15:35:48 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302802755259613185",
  "text" : "@HEATHENRABBIT : O",
  "id" : 302802755259613185,
  "created_at" : "2013-02-16 15:32:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302802462375567360",
  "text" : "@AnarchistKevin you're a good daddy : )",
  "id" : 302802462375567360,
  "created_at" : "2013-02-16 15:31:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 0, 11 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302602746966704129",
  "geo" : { },
  "id_str" : "302603746691670016",
  "in_reply_to_user_id" : 105134401,
  "text" : "@TimGreaton my complaint is that it ended too soon... : )",
  "id" : 302603746691670016,
  "in_reply_to_status_id" : 302602746966704129,
  "created_at" : "2013-02-16 02:22:09 +0000",
  "in_reply_to_screen_name" : "TimGreaton",
  "in_reply_to_user_id_str" : "105134401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "christian",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "lovewins",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/j7MRrHCs",
      "expanded_url" : "http:\/\/www.christianpost.com\/news\/rob-bell-tackles-misconceptions-about-god-in-new-book-89987\/",
      "display_url" : "christianpost.com\/news\/rob-bell-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302597098875015169",
  "text" : "reading comments on this post, i can begin to understand #atheist anger w #christian http:\/\/t.co\/j7MRrHCs - PS. #lovewins !",
  "id" : 302597098875015169,
  "created_at" : "2013-02-16 01:55:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 2, 15 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302585453922619392",
  "geo" : { },
  "id_str" : "302591253399367680",
  "in_reply_to_user_id" : 135615040,
  "text" : ". @CrystalLewis they left because he was preaching love and mercy? tough crowd... smh",
  "id" : 302591253399367680,
  "in_reply_to_status_id" : 302585453922619392,
  "created_at" : "2013-02-16 01:32:31 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skegg",
      "screen_name" : "askegg",
      "indices" : [ 3, 10 ],
      "id_str" : "14300436",
      "id" : 14300436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302590387476905984",
  "text" : "RT @askegg: God: Gives you free will, send you to Hell for choosing incorrectly. #atheist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 69, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302562281299005440",
    "text" : "God: Gives you free will, send you to Hell for choosing incorrectly. #atheist",
    "id" : 302562281299005440,
    "created_at" : "2013-02-15 23:37:23 +0000",
    "user" : {
      "name" : "Andrew Skegg",
      "screen_name" : "askegg",
      "protected" : false,
      "id_str" : "14300436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630341533007384576\/IsQMDyzF_normal.jpg",
      "id" : 14300436,
      "verified" : false
    }
  },
  "id" : 302590387476905984,
  "created_at" : "2013-02-16 01:29:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302522470068523008",
  "text" : "RT @damienechols: Do NOT be moved by what people say. They said I would die on death row. I did not. I am well. And it is going to be we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302521021456592896",
    "text" : "Do NOT be moved by what people say. They said I would die on death row. I did not. I am well. And it is going to be well with you, too.",
    "id" : 302521021456592896,
    "created_at" : "2013-02-15 20:53:26 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 302522470068523008,
  "created_at" : "2013-02-15 20:59:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302521075286282241",
  "geo" : { },
  "id_str" : "302522405274918912",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits its just a way to get kids in system sooner, moms back in workforce. wish i kept my kid home extra year.",
  "id" : 302522405274918912,
  "in_reply_to_status_id" : 302521075286282241,
  "created_at" : "2013-02-15 20:58:56 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 49, 62 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scifi",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "military",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "hightech",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302521723549523968",
  "text" : "I just bought: 'Afterlife' by Doug Dandridge via @amazonkindle - curr. free #scifi #military #hightech",
  "id" : 302521723549523968,
  "created_at" : "2013-02-15 20:56:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302518988045447170",
  "geo" : { },
  "id_str" : "302519565441712128",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie O.M.G .. adorableness! smooches to that sweet darling!",
  "id" : 302519565441712128,
  "in_reply_to_status_id" : 302518988045447170,
  "created_at" : "2013-02-15 20:47:39 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302518557156192257",
  "text" : "im burping mushrooms. isnt that attractive? ; )",
  "id" : 302518557156192257,
  "created_at" : "2013-02-15 20:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302463626898440192",
  "geo" : { },
  "id_str" : "302476288235552768",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog no.. i'll check it out...",
  "id" : 302476288235552768,
  "in_reply_to_status_id" : 302463626898440192,
  "created_at" : "2013-02-15 17:55:41 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/EnILVPWE",
      "expanded_url" : "http:\/\/www.laridian.com\/catalog\/products\/PCDAPBPGM.asp",
      "display_url" : "laridian.com\/catalog\/produc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302450027740164096",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog http:\/\/t.co\/EnILVPWE \nPocketBible for Android - works on my KFHD so far \/ they have referral program",
  "id" : 302450027740164096,
  "created_at" : "2013-02-15 16:11:20 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Murphy",
      "screen_name" : "MattMurph24",
      "indices" : [ 3, 15 ],
      "id_str" : "49800332",
      "id" : 49800332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302223625505894401",
  "text" : "RT @MattMurph24: NOBODY should ever go hungry in this country.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302219445500268544",
    "text" : "NOBODY should ever go hungry in this country.",
    "id" : 302219445500268544,
    "created_at" : "2013-02-15 00:55:05 +0000",
    "user" : {
      "name" : "Matt Murphy",
      "screen_name" : "MattMurph24",
      "protected" : false,
      "id_str" : "49800332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796336815955394560\/smZzuaP4_normal.jpg",
      "id" : 49800332,
      "verified" : false
    }
  },
  "id" : 302223625505894401,
  "created_at" : "2013-02-15 01:11:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "indices" : [ 3, 18 ],
      "id_str" : "26560483",
      "id" : 26560483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302182769281351681",
  "text" : "RT @MacmillanAudio: Don't forget to enter  on FB to win a @DanaStabenow audiobook bundle http:\/\/t.co\/wGMD0Nqd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/wGMD0Nqd",
        "expanded_url" : "http:\/\/bit.ly\/XbLP76",
        "display_url" : "bit.ly\/XbLP76"
      } ]
    },
    "geo" : { },
    "id_str" : "302147173942972416",
    "text" : "Don't forget to enter  on FB to win a @DanaStabenow audiobook bundle http:\/\/t.co\/wGMD0Nqd",
    "id" : 302147173942972416,
    "created_at" : "2013-02-14 20:07:54 +0000",
    "user" : {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "protected" : false,
      "id_str" : "26560483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473834349394010112\/_cwv_j5v_normal.jpeg",
      "id" : 26560483,
      "verified" : true
    }
  },
  "id" : 302182769281351681,
  "created_at" : "2013-02-14 22:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302180491929477120",
  "geo" : { },
  "id_str" : "302182700498944001",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 that is beautiful : )",
  "id" : 302182700498944001,
  "in_reply_to_status_id" : 302180491929477120,
  "created_at" : "2013-02-14 22:29:04 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/J8Qt79zV",
      "expanded_url" : "http:\/\/www.facebook.com\/photo.php?fbid=10151519987986057&set=a.156488236056.137584.33118526056&type=1",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302108729413877761",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog audio book giveaway Ted Dekker \"Eyes Wide Open\" http:\/\/t.co\/J8Qt79zV",
  "id" : 302108729413877761,
  "created_at" : "2013-02-14 17:35:08 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302063804127272960",
  "geo" : { },
  "id_str" : "302068018094166016",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl ((huggles)) xoxo",
  "id" : 302068018094166016,
  "in_reply_to_status_id" : 302063804127272960,
  "created_at" : "2013-02-14 14:53:22 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301889113085341696",
  "text" : "RT @alanhdawe: Frankly, God's patience must have been stretched more by those who professed to love and worship Him than by the godless  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301887514812227584",
    "text" : "Frankly, God's patience must have been stretched more by those who professed to love and worship Him than by the godless masses. #TGFBook",
    "id" : 301887514812227584,
    "created_at" : "2013-02-14 02:56:06 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 301889113085341696,
  "created_at" : "2013-02-14 03:02:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "don",
      "screen_name" : "dbbandit",
      "indices" : [ 3, 12 ],
      "id_str" : "22126188",
      "id" : 22126188
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dbbandit\/status\/301863975262507008\/photo\/1",
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/tDpp3WkM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDBvr6iCUAAvDLh.jpg",
      "id_str" : "301863975270895616",
      "id" : 301863975270895616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDBvr6iCUAAvDLh.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/tDpp3WkM"
    } ],
    "hashtags" : [ {
      "text" : "tednugent",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301866493308719104",
  "text" : "RT @dbbandit: #tednugent http:\/\/t.co\/tDpp3WkM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dbbandit\/status\/301863975262507008\/photo\/1",
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/tDpp3WkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDBvr6iCUAAvDLh.jpg",
        "id_str" : "301863975270895616",
        "id" : 301863975270895616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDBvr6iCUAAvDLh.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/tDpp3WkM"
      } ],
      "hashtags" : [ {
        "text" : "tednugent",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301863975262507008",
    "text" : "#tednugent http:\/\/t.co\/tDpp3WkM",
    "id" : 301863975262507008,
    "created_at" : "2013-02-14 01:22:34 +0000",
    "user" : {
      "name" : "don",
      "screen_name" : "dbbandit",
      "protected" : false,
      "id_str" : "22126188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631426663465627648\/xzD-kLCg_normal.jpg",
      "id" : 22126188,
      "verified" : false
    }
  },
  "id" : 301866493308719104,
  "created_at" : "2013-02-14 01:32:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301862198299488256",
  "text" : "RT @ducksandclucks: Opened the door to the house and Carol let herself inside and hopped in her time out pen. I guess she\u2026 http:\/\/t.co\/9 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/9rnBXKx5",
        "expanded_url" : "http:\/\/instagr.am\/p\/VsUeU1BH7C\/",
        "display_url" : "instagr.am\/p\/VsUeU1BH7C\/"
      } ]
    },
    "geo" : { },
    "id_str" : "301861504217665536",
    "text" : "Opened the door to the house and Carol let herself inside and hopped in her time out pen. I guess she\u2026 http:\/\/t.co\/9rnBXKx5",
    "id" : 301861504217665536,
    "created_at" : "2013-02-14 01:12:45 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 301862198299488256,
  "created_at" : "2013-02-14 01:15:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luola",
      "screen_name" : "luola21",
      "indices" : [ 0, 8 ],
      "id_str" : "1005737413",
      "id" : 1005737413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301848705215107072",
  "geo" : { },
  "id_str" : "301854855104978944",
  "in_reply_to_user_id" : 1005737413,
  "text" : "@luola21 im sorry ((hugs))",
  "id" : 301854855104978944,
  "in_reply_to_status_id" : 301848705215107072,
  "created_at" : "2013-02-14 00:46:20 +0000",
  "in_reply_to_screen_name" : "luola21",
  "in_reply_to_user_id_str" : "1005737413",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301843782436020225",
  "geo" : { },
  "id_str" : "301849223387815937",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool your rt about \"Woman took pills before giving herself an abortion\" link",
  "id" : 301849223387815937,
  "in_reply_to_status_id" : 301843782436020225,
  "created_at" : "2013-02-14 00:23:57 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301842192706723840",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool oh my.. the comments on that article are awful.",
  "id" : 301842192706723840,
  "created_at" : "2013-02-13 23:56:01 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/oYoHIvPz",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/02\/13\/mississippi-lawmaker-wants-to.html",
      "display_url" : "boingboing.net\/2013\/02\/13\/mis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301829283922452481",
  "text" : "RT @Matth3ous: WTF? #fail http:\/\/t.co\/oYoHIvPz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fail",
        "indices" : [ 5, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/oYoHIvPz",
        "expanded_url" : "http:\/\/boingboing.net\/2013\/02\/13\/mississippi-lawmaker-wants-to.html",
        "display_url" : "boingboing.net\/2013\/02\/13\/mis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301820268878393345",
    "text" : "WTF? #fail http:\/\/t.co\/oYoHIvPz",
    "id" : 301820268878393345,
    "created_at" : "2013-02-13 22:28:54 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 301829283922452481,
  "created_at" : "2013-02-13 23:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301823319471181825",
  "geo" : { },
  "id_str" : "301828572388147200",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool hmm.. i see it more like cuz you're like little terriers that hang on the pant leg..lol ; )",
  "id" : 301828572388147200,
  "in_reply_to_status_id" : 301823319471181825,
  "created_at" : "2013-02-13 23:01:54 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "indices" : [ 3, 19 ],
      "id_str" : "20245651",
      "id" : 20245651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dorner",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301826444231860224",
  "text" : "RT @eScottNicholson: As sadly twisted as this #Dorner case is, the most chilling thing is how the media meekly looked away when the cops ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dorner",
        "indices" : [ 25, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301824125331181569",
    "text" : "As sadly twisted as this #Dorner case is, the most chilling thing is how the media meekly looked away when the cops told them to",
    "id" : 301824125331181569,
    "created_at" : "2013-02-13 22:44:13 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 301826444231860224,
  "created_at" : "2013-02-13 22:53:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301816918292197376",
  "text" : "i had a small glass of wine. not a good idea. ughhh.",
  "id" : 301816918292197376,
  "created_at" : "2013-02-13 22:15:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301810925650989056",
  "text" : "RT @luminanceriver: The willingness to just do what the authority figures our lives that have gotten unquestioning obedience from us \u2013 i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shift",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301810499396444162",
    "text" : "The willingness to just do what the authority figures our lives that have gotten unquestioning obedience from us \u2013 is falling away. #shift",
    "id" : 301810499396444162,
    "created_at" : "2013-02-13 21:50:05 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 301810925650989056,
  "created_at" : "2013-02-13 21:51:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Ecuyer",
      "screen_name" : "greenpilgrim13",
      "indices" : [ 3, 18 ],
      "id_str" : "359391845",
      "id" : 359391845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anipals",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/Megxn9zH",
      "expanded_url" : "http:\/\/www.tarasbabies.org",
      "display_url" : "tarasbabies.org"
    } ]
  },
  "geo" : { },
  "id_str" : "301795666802397184",
  "text" : "RT @greenpilgrim13: Dog Rescue Closing.Help find good homes for the remaining dogs.Visit http:\/\/t.co\/Megxn9zH  #anipals",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "anipals",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/Megxn9zH",
        "expanded_url" : "http:\/\/www.tarasbabies.org",
        "display_url" : "tarasbabies.org"
      } ]
    },
    "geo" : { },
    "id_str" : "301539759342354432",
    "text" : "Dog Rescue Closing.Help find good homes for the remaining dogs.Visit http:\/\/t.co\/Megxn9zH  #anipals",
    "id" : 301539759342354432,
    "created_at" : "2013-02-13 03:54:15 +0000",
    "user" : {
      "name" : "Adam Ecuyer",
      "screen_name" : "greenpilgrim13",
      "protected" : false,
      "id_str" : "359391845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608312138051002369\/KTWz-ytQ_normal.jpg",
      "id" : 359391845,
      "verified" : false
    }
  },
  "id" : 301795666802397184,
  "created_at" : "2013-02-13 20:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zaberdire1971",
      "screen_name" : "Love__Nino",
      "indices" : [ 3, 14 ],
      "id_str" : "2982421721",
      "id" : 2982421721
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 23, 37 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301790851565248513",
  "text" : "RT @Love__Nino: O_o RT @CharlesBivona: The manager at my bank says she just doesn't understand why poor people don't choose to make more ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 7, 21 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "njpoet",
        "indices" : [ 128, 135 ]
      }, {
        "text" : "p2",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301790507087040512",
    "text" : "O_o RT @CharlesBivona: The manager at my bank says she just doesn't understand why poor people don't choose to make more money. #njpoet #p2",
    "id" : 301790507087040512,
    "created_at" : "2013-02-13 20:30:38 +0000",
    "user" : {
      "name" : "(((Nino)))",
      "screen_name" : "Kishmishiani",
      "protected" : false,
      "id_str" : "98202324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797178567549284352\/kE-OvKVO_normal.jpg",
      "id" : 98202324,
      "verified" : false
    }
  },
  "id" : 301790851565248513,
  "created_at" : "2013-02-13 20:32:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301790757096939520",
  "text" : "DD said new kid in her grade (junior) .. reminds me when we moved summer of 11th grade and i grad from strange school.",
  "id" : 301790757096939520,
  "created_at" : "2013-02-13 20:31:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "indices" : [ 3, 19 ],
      "id_str" : "20245651",
      "id" : 20245651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dorner",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301784231070285825",
  "text" : "RT @eScottNicholson: \"I don't always burn myself inside a cabin, but when I do, I carefully fireproof my ID\" #Dorner",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dorner",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301779844990107648",
    "text" : "\"I don't always burn myself inside a cabin, but when I do, I carefully fireproof my ID\" #Dorner",
    "id" : 301779844990107648,
    "created_at" : "2013-02-13 19:48:16 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 301784231070285825,
  "created_at" : "2013-02-13 20:05:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301783926391853057",
  "text" : "RT @JosephRanseth: I love jaywalkers. Seriously. They remind me that life works fine without everything being governed &amp; regulated.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301780155980972032",
    "text" : "I love jaywalkers. Seriously. They remind me that life works fine without everything being governed &amp; regulated.",
    "id" : 301780155980972032,
    "created_at" : "2013-02-13 19:49:30 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 301783926391853057,
  "created_at" : "2013-02-13 20:04:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 0, 8 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301767553938780160",
  "geo" : { },
  "id_str" : "301769250098511873",
  "in_reply_to_user_id" : 61363491,
  "text" : "@mbekezm its quite special, well.. being a unicorn horn and all...",
  "id" : 301769250098511873,
  "in_reply_to_status_id" : 301767553938780160,
  "created_at" : "2013-02-13 19:06:10 +0000",
  "in_reply_to_screen_name" : "mbekezm",
  "in_reply_to_user_id_str" : "61363491",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301765168252207104",
  "geo" : { },
  "id_str" : "301769111598424064",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool lol.. see pic i tweeted",
  "id" : 301769111598424064,
  "in_reply_to_status_id" : 301765168252207104,
  "created_at" : "2013-02-13 19:05:37 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/qP7mZwzD",
      "expanded_url" : "http:\/\/via.me\/-9ofh2q6",
      "display_url" : "via.me\/-9ofh2q6"
    } ]
  },
  "geo" : { },
  "id_str" : "301767016635834368",
  "text" : "Unicorn horn hubby found in 2012. http:\/\/t.co\/qP7mZwzD",
  "id" : 301767016635834368,
  "created_at" : "2013-02-13 18:57:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301762842074427394",
  "geo" : { },
  "id_str" : "301764890698342400",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool ive got a unicorn horn in my house...",
  "id" : 301764890698342400,
  "in_reply_to_status_id" : 301762842074427394,
  "created_at" : "2013-02-13 18:48:51 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/I3Fn55VH",
      "expanded_url" : "http:\/\/www.naturalnews.com\/039081_LAPD_arson_Christopher_Dorner.html",
      "display_url" : "naturalnews.com\/039081_LAPD_ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301757792295997441",
  "text" : "RT @HealthRanger: Confirmed: LAPD commits premeditated arson, murder against homicide suspect Christopher Dorner http:\/\/t.co\/I3Fn55VH vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthRanger",
        "screen_name" : "HealthRanger",
        "indices" : [ 120, 133 ],
        "id_str" : "15843059",
        "id" : 15843059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/I3Fn55VH",
        "expanded_url" : "http:\/\/www.naturalnews.com\/039081_LAPD_arson_Christopher_Dorner.html",
        "display_url" : "naturalnews.com\/039081_LAPD_ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301754600288043008",
    "text" : "Confirmed: LAPD commits premeditated arson, murder against homicide suspect Christopher Dorner http:\/\/t.co\/I3Fn55VH via @HealthRanger",
    "id" : 301754600288043008,
    "created_at" : "2013-02-13 18:07:57 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 301757792295997441,
  "created_at" : "2013-02-13 18:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "indices" : [ 3, 12 ],
      "id_str" : "17304367",
      "id" : 17304367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301752500200013824",
  "text" : "RT @bookpage: Think you're free-thinking, politically correct? Sobering BLINDSPOT may reveal hidden \"ingrained habits.\u201D http:\/\/t.co\/2aJq ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Random House",
        "screen_name" : "randomhouse",
        "indices" : [ 127, 139 ],
        "id_str" : "7586362",
        "id" : 7586362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/2aJqIcc4",
        "expanded_url" : "http:\/\/ht.ly\/h8qxN",
        "display_url" : "ht.ly\/h8qxN"
      } ]
    },
    "geo" : { },
    "id_str" : "301751482871607297",
    "text" : "Think you're free-thinking, politically correct? Sobering BLINDSPOT may reveal hidden \"ingrained habits.\u201D http:\/\/t.co\/2aJqIcc4 @randomhouse",
    "id" : 301751482871607297,
    "created_at" : "2013-02-13 17:55:34 +0000",
    "user" : {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "protected" : false,
      "id_str" : "17304367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793482805435068416\/rGBg6Wdr_normal.jpg",
      "id" : 17304367,
      "verified" : false
    }
  },
  "id" : 301752500200013824,
  "created_at" : "2013-02-13 17:59:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 3, 18 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301751712522334208",
  "text" : "RT @HuffingtonPost: On this day in 1633, Galileo arrived in Rome to face charges of heresy for believing the Earth revolves around the Sun.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301740781549539328",
    "text" : "On this day in 1633, Galileo arrived in Rome to face charges of heresy for believing the Earth revolves around the Sun.",
    "id" : 301740781549539328,
    "created_at" : "2013-02-13 17:13:03 +0000",
    "user" : {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "protected" : false,
      "id_str" : "14511951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720642862551928832\/I58EQMCH_normal.jpg",
      "id" : 14511951,
      "verified" : true
    }
  },
  "id" : 301751712522334208,
  "created_at" : "2013-02-13 17:56:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301751435878604801",
  "text" : "RT @ggreenwald: I'm not endorsing all of this, but there are lots of questions about \"what really happened to Chris Dorner\"   http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/PtfY3YPC",
        "expanded_url" : "http:\/\/occupyblogosphere.wordpress.com\/2013\/02\/13\/what-really-happened-to-chris-dorner\/",
        "display_url" : "occupyblogosphere.wordpress.com\/2013\/02\/13\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301704068332654592",
    "text" : "I'm not endorsing all of this, but there are lots of questions about \"what really happened to Chris Dorner\"   http:\/\/t.co\/PtfY3YPC",
    "id" : 301704068332654592,
    "created_at" : "2013-02-13 14:47:09 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 301751435878604801,
  "created_at" : "2013-02-13 17:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301738950568079361",
  "text" : "RT @ificouldtellu: Every grain of sand is God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301738496564006913",
    "text" : "Every grain of sand is God.",
    "id" : 301738496564006913,
    "created_at" : "2013-02-13 17:03:58 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 301738950568079361,
  "created_at" : "2013-02-13 17:05:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301737858723618817",
  "geo" : { },
  "id_str" : "301738553136791552",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny get your zombie survival kit out!",
  "id" : 301738553136791552,
  "in_reply_to_status_id" : 301737858723618817,
  "created_at" : "2013-02-13 17:04:11 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 13, 28 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301726570081574913",
  "geo" : { },
  "id_str" : "301734807522639872",
  "in_reply_to_user_id" : 96152195,
  "text" : "im trying RT @luminanceriver You are meant to be here if you are in a body. There is a reason and purpose to your existence. Find it.",
  "id" : 301734807522639872,
  "in_reply_to_status_id" : 301726570081574913,
  "created_at" : "2013-02-13 16:49:18 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "indices" : [ 3, 15 ],
      "id_str" : "18994661",
      "id" : 18994661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/vw3KJgT4",
      "expanded_url" : "http:\/\/www.jonahlehrer.com\/2013\/02\/my-apology\/",
      "display_url" : "jonahlehrer.com\/2013\/02\/my-apo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301715718901202944",
  "text" : "RT @jonahlehrer: Here is the text of my speech. I'm deeply sorry for what I've done. http:\/\/t.co\/vw3KJgT4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/vw3KJgT4",
        "expanded_url" : "http:\/\/www.jonahlehrer.com\/2013\/02\/my-apology\/",
        "display_url" : "jonahlehrer.com\/2013\/02\/my-apo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301705779029872640",
    "text" : "Here is the text of my speech. I'm deeply sorry for what I've done. http:\/\/t.co\/vw3KJgT4",
    "id" : 301705779029872640,
    "created_at" : "2013-02-13 14:53:57 +0000",
    "user" : {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "protected" : false,
      "id_str" : "18994661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1488584320\/Untitled_normal.jpg",
      "id" : 18994661,
      "verified" : false
    }
  },
  "id" : 301715718901202944,
  "created_at" : "2013-02-13 15:33:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301713614308536322",
  "text" : "look beyond what you're seeing.. they don't want you to see that.",
  "id" : 301713614308536322,
  "created_at" : "2013-02-13 15:25:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301710780578017280",
  "text" : "RT @bend_time: whenever they find i.d. in otherwise burned to a crisp place- i am suspicious. dorner's d.l. found? as was passport of 9\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301704857725833216",
    "text" : "whenever they find i.d. in otherwise burned to a crisp place- i am suspicious. dorner's d.l. found? as was passport of 9\/11 hijacker in WTC.",
    "id" : 301704857725833216,
    "created_at" : "2013-02-13 14:50:18 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 301710780578017280,
  "created_at" : "2013-02-13 15:13:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301709549667237888",
  "text" : "RT @JohnFugelsang: The Bible's the greatest game of Telephone in history-Jesus said 'Love your enemies,' Rush Limbaugh heard 'Nuke Iran.'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301707429966647296",
    "text" : "The Bible's the greatest game of Telephone in history-Jesus said 'Love your enemies,' Rush Limbaugh heard 'Nuke Iran.'",
    "id" : 301707429966647296,
    "created_at" : "2013-02-13 15:00:31 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 301709549667237888,
  "created_at" : "2013-02-13 15:08:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/2UkmO6Hm",
      "expanded_url" : "http:\/\/amzn.to\/qlvK6V",
      "display_url" : "amzn.to\/qlvK6V"
    } ]
  },
  "geo" : { },
  "id_str" : "301516203720073216",
  "text" : "finished Bones in the Tree by Tim Greaton http:\/\/t.co\/2UkmO6Hm",
  "id" : 301516203720073216,
  "created_at" : "2013-02-13 02:20:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "indices" : [ 3, 18 ],
      "id_str" : "615318971",
      "id" : 615318971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301508811875840000",
  "text" : "RT @CuestionMarque: Most health insurers are profit-making concerns w\/shareholder base that demands an increasing level of earnings forc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301502469832310787",
    "text" : "Most health insurers are profit-making concerns w\/shareholder base that demands an increasing level of earnings forcing up costs for us all.",
    "id" : 301502469832310787,
    "created_at" : "2013-02-13 01:26:05 +0000",
    "user" : {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "protected" : false,
      "id_str" : "615318971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2347711009\/5slm7j57n6tf4g5d98ia_normal.jpeg",
      "id" : 615318971,
      "verified" : false
    }
  },
  "id" : 301508811875840000,
  "created_at" : "2013-02-13 01:51:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayron",
      "screen_name" : "Jayron26",
      "indices" : [ 3, 12 ],
      "id_str" : "391356320",
      "id" : 391356320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301506544888053760",
  "text" : "RT @Jayron26: FOX: He has been killed, CBS: He has escaped, NBC: He has hostages,Onion: He's riding through the forrest on a unicorn in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dorner",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301502734715191297",
    "text" : "FOX: He has been killed, CBS: He has escaped, NBC: He has hostages,Onion: He's riding through the forrest on a unicorn in ass pants. #Dorner",
    "id" : 301502734715191297,
    "created_at" : "2013-02-13 01:27:08 +0000",
    "user" : {
      "name" : "Jayron",
      "screen_name" : "Jayron26",
      "protected" : false,
      "id_str" : "391356320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546693243023282176\/nHX6SQrF_normal.jpeg",
      "id" : 391356320,
      "verified" : false
    }
  },
  "id" : 301506544888053760,
  "created_at" : "2013-02-13 01:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301505867629596672",
  "text" : "RT @JosephRanseth: Believe in magic. Believe in the undiscovered possibility.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301505235032096768",
    "text" : "Believe in magic. Believe in the undiscovered possibility.",
    "id" : 301505235032096768,
    "created_at" : "2013-02-13 01:37:04 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 301505867629596672,
  "created_at" : "2013-02-13 01:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301503338921488384",
  "text" : "RT @TheGoldenMirror: We make life heavy just by thinking it is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301501772957118464",
    "text" : "We make life heavy just by thinking it is.",
    "id" : 301501772957118464,
    "created_at" : "2013-02-13 01:23:18 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 301503338921488384,
  "created_at" : "2013-02-13 01:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301500581271465984",
  "text" : "RT @DharmaTalks: Our spiritual destiny is recognizing the ONE &amp; ALL are equal. Let us realize Evil in our community is a suggestion  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301498460924956672",
    "text" : "Our spiritual destiny is recognizing the ONE &amp; ALL are equal. Let us realize Evil in our community is a suggestion we do not have to accept.",
    "id" : 301498460924956672,
    "created_at" : "2013-02-13 01:10:09 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 301500581271465984,
  "created_at" : "2013-02-13 01:18:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301500463541518337",
  "text" : "RT @luminanceriver: Make your own life curriculum.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301498768224833538",
    "text" : "Make your own life curriculum.",
    "id" : 301498768224833538,
    "created_at" : "2013-02-13 01:11:22 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 301500463541518337,
  "created_at" : "2013-02-13 01:18:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301500440829378560",
  "text" : "RT @luminanceriver: Your parents and schools can have a plan of what they think you learn for the future, but only your higher self know ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301498708044963840",
    "text" : "Your parents and schools can have a plan of what they think you learn for the future, but only your higher self knows what is best.",
    "id" : 301498708044963840,
    "created_at" : "2013-02-13 01:11:08 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 301500440829378560,
  "created_at" : "2013-02-13 01:18:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 3, 13 ],
      "id_str" : "41457590",
      "id" : 41457590
    }, {
      "name" : "Wayne McEvilly",
      "screen_name" : "waynemcevilly",
      "indices" : [ 18, 32 ],
      "id_str" : "24256596",
      "id" : 24256596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301500048645169152",
  "text" : "RT @38harmony: RT @waynemcevilly: A2 energy fields, visible to the intuitive eye. REALizing the other's burdens, being compassionate. #l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wayne McEvilly",
        "screen_name" : "waynemcevilly",
        "indices" : [ 3, 17 ],
        "id_str" : "24256596",
        "id" : 24256596
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leadfromwithin",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301499575355719680",
    "text" : "RT @waynemcevilly: A2 energy fields, visible to the intuitive eye. REALizing the other's burdens, being compassionate. #leadfromwithin",
    "id" : 301499575355719680,
    "created_at" : "2013-02-13 01:14:35 +0000",
    "user" : {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "protected" : false,
      "id_str" : "41457590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1671334755\/2-HH-5-27-7_normal.jpg",
      "id" : 41457590,
      "verified" : false
    }
  },
  "id" : 301500048645169152,
  "created_at" : "2013-02-13 01:16:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301492870383288320",
  "text" : "we the people have been set up",
  "id" : 301492870383288320,
  "created_at" : "2013-02-13 00:47:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301491094749855744",
  "geo" : { },
  "id_str" : "301491538729508864",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool @T_Maric hey, i resemble that remark!",
  "id" : 301491538729508864,
  "in_reply_to_status_id" : 301491094749855744,
  "created_at" : "2013-02-13 00:42:38 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301488136700178433",
  "text" : "i dont know what to think",
  "id" : 301488136700178433,
  "created_at" : "2013-02-13 00:29:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301422977596153857",
  "text" : "have a hard time understanding how ppl can truly believe in hell...",
  "id" : 301422977596153857,
  "created_at" : "2013-02-12 20:10:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301421715534262273",
  "text" : "i can feel myself getting out of sorts...",
  "id" : 301421715534262273,
  "created_at" : "2013-02-12 20:05:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evil",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301410227939573761",
  "text" : "rick perry makes me sick... he thrives on the death penalty! #evil",
  "id" : 301410227939573761,
  "created_at" : "2013-02-12 19:19:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/7PHNZwin",
      "expanded_url" : "http:\/\/motherjones.com\/politics\/2011\/12\/tim-cole-rick-perry",
      "display_url" : "motherjones.com\/politics\/2011\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301408834709225473",
  "text" : "incorrect identification..a factor in convictions of more than 75% of people eventually exonerated by DNA http:\/\/t.co\/7PHNZwin",
  "id" : 301408834709225473,
  "created_at" : "2013-02-12 19:14:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "indices" : [ 3, 18 ],
      "id_str" : "7622122",
      "id" : 7622122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301400905629188096",
  "text" : "RT @indiebizchicks: I have some blogging opportunities - some are paid and some are reviews. If interested, please fill out this form: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 136 ],
        "url" : "https:\/\/t.co\/vviLoHe6",
        "expanded_url" : "https:\/\/docs.google.com\/spreadsheet\/viewform?formkey=dEJ5OTZRYTE4V1BXQnZpSld5YlVCcmc6MQ",
        "display_url" : "docs.google.com\/spreadsheet\/vi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301400422692818946",
    "text" : "I have some blogging opportunities - some are paid and some are reviews. If interested, please fill out this form: https:\/\/t.co\/vviLoHe6",
    "id" : 301400422692818946,
    "created_at" : "2013-02-12 18:40:35 +0000",
    "user" : {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "protected" : false,
      "id_str" : "7622122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653393257959936001\/6VMDqhz3_normal.jpg",
      "id" : 7622122,
      "verified" : false
    }
  },
  "id" : 301400905629188096,
  "created_at" : "2013-02-12 18:42:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 20, 32 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 117, 123 ]
    }, {
      "text" : "humanrights",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/qfh1ZMKu",
      "expanded_url" : "http:\/\/ow.ly\/hDUOg",
      "display_url" : "ow.ly\/hDUOg"
    } ]
  },
  "geo" : { },
  "id_str" : "301397576404582400",
  "text" : "RT @ReverendSue: RT @MotherJones Here are 13 men condemned to die despite severe mental illness http:\/\/t.co\/qfh1ZMKu #Texas #humanrights ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mother Jones",
        "screen_name" : "MotherJones",
        "indices" : [ 3, 15 ],
        "id_str" : "18510860",
        "id" : 18510860
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 100, 106 ]
      }, {
        "text" : "humanrights",
        "indices" : [ 107, 119 ]
      }, {
        "text" : "p2",
        "indices" : [ 120, 123 ]
      }, {
        "text" : "uniteblue",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/qfh1ZMKu",
        "expanded_url" : "http:\/\/ow.ly\/hDUOg",
        "display_url" : "ow.ly\/hDUOg"
      } ]
    },
    "geo" : { },
    "id_str" : "301395682240102400",
    "text" : "RT @MotherJones Here are 13 men condemned to die despite severe mental illness http:\/\/t.co\/qfh1ZMKu #Texas #humanrights #p2 #uniteblue",
    "id" : 301395682240102400,
    "created_at" : "2013-02-12 18:21:44 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 301397576404582400,
  "created_at" : "2013-02-12 18:29:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "indices" : [ 0, 11 ],
      "id_str" : "21497211",
      "id" : 21497211
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 27, 39 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liberal",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "equality",
      "indices" : [ 69, 78 ]
    }, {
      "text" : "socialissues",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301331387842174977",
  "in_reply_to_user_id" : 21497211,
  "text" : "@jedwards06 you might like @ReverendSue and @PartTimePreach #liberal #equality #socialissues",
  "id" : 301331387842174977,
  "created_at" : "2013-02-12 14:06:15 +0000",
  "in_reply_to_screen_name" : "jedwards06",
  "in_reply_to_user_id_str" : "21497211",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/geYria6x",
      "expanded_url" : "http:\/\/amzn.to\/LY0g8M",
      "display_url" : "amzn.to\/LY0g8M"
    } ]
  },
  "geo" : { },
  "id_str" : "301173894818168832",
  "text" : "finished Angels in Our Countryside by Robert John Burke http:\/\/t.co\/geYria6x",
  "id" : 301173894818168832,
  "created_at" : "2013-02-12 03:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Baker",
      "screen_name" : "KindleObsessed",
      "indices" : [ 0, 15 ],
      "id_str" : "29574025",
      "id" : 29574025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Win",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/iAoq4bZa",
      "expanded_url" : "http:\/\/www.kindleobsessed.com\/uncategorized\/blind-date-with-an-ebook-giveaway\/",
      "display_url" : "kindleobsessed.com\/uncategorized\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301117813991555072",
  "in_reply_to_user_id" : 29574025,
  "text" : "@KindleObsessed is hosting a DIGITAL version of Blind Date with a Book! Stop by &amp; Sign up to #Win a mystery book! http:\/\/t.co\/iAoq4bZa",
  "id" : 301117813991555072,
  "created_at" : "2013-02-11 23:57:36 +0000",
  "in_reply_to_screen_name" : "KindleObsessed",
  "in_reply_to_user_id_str" : "29574025",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301102840183672833",
  "text" : "RT @bunnybuddhism: I am my own refuge. No other bunny can be my refuge.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301099595151314944",
    "text" : "I am my own refuge. No other bunny can be my refuge.",
    "id" : 301099595151314944,
    "created_at" : "2013-02-11 22:45:12 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 301102840183672833,
  "created_at" : "2013-02-11 22:58:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301101095537750016",
  "geo" : { },
  "id_str" : "301102283180093441",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ((consolingwhine)) big squishy ((hug))",
  "id" : 301102283180093441,
  "in_reply_to_status_id" : 301101095537750016,
  "created_at" : "2013-02-11 22:55:53 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No Redemption Value*",
      "screen_name" : "PinchSuckBlow",
      "indices" : [ 3, 17 ],
      "id_str" : "634247376",
      "id" : 634247376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301101976647766016",
  "text" : "RT @PinchSuckBlow: never do anything you don't want to explain to a paramedic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "243768606171729920",
    "text" : "never do anything you don't want to explain to a paramedic",
    "id" : 243768606171729920,
    "created_at" : "2012-09-06 17:52:19 +0000",
    "user" : {
      "name" : "No Redemption Value*",
      "screen_name" : "PinchSuckBlow",
      "protected" : false,
      "id_str" : "634247376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671799090582286341\/4IMt4NTr_normal.jpg",
      "id" : 634247376,
      "verified" : false
    }
  },
  "id" : 301101976647766016,
  "created_at" : "2013-02-11 22:54:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "indices" : [ 3, 11 ],
      "id_str" : "124176955",
      "id" : 124176955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/5Sy9wy4B",
      "expanded_url" : "http:\/\/www.g5e.com\/sale",
      "display_url" : "g5e.com\/sale"
    } ]
  },
  "geo" : { },
  "id_str" : "300982639123386368",
  "text" : "RT @G5games: Big Kindle SALE starts now! Top-notch games for Kindle at half price! Learn more! (http:\/\/t.co\/5Sy9wy4B)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/5Sy9wy4B",
        "expanded_url" : "http:\/\/www.g5e.com\/sale",
        "display_url" : "g5e.com\/sale"
      } ]
    },
    "geo" : { },
    "id_str" : "300981349018378240",
    "text" : "Big Kindle SALE starts now! Top-notch games for Kindle at half price! Learn more! (http:\/\/t.co\/5Sy9wy4B)",
    "id" : 300981349018378240,
    "created_at" : "2013-02-11 14:55:20 +0000",
    "user" : {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "protected" : false,
      "id_str" : "124176955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554687863338438656\/TlbHHhe4_normal.png",
      "id" : 124176955,
      "verified" : false
    }
  },
  "id" : 300982639123386368,
  "created_at" : "2013-02-11 15:00:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/FmuB1zYd",
      "expanded_url" : "http:\/\/bookwi.se\/wool-books-1-3-by-hugh-howey\/",
      "display_url" : "bookwi.se\/wool-books-1-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300975652092387330",
  "text" : "RT @adamrshields: Book Review: Wool by Hugh Howey (Review of Books 1-3) - Creative post-apocalyptic independent novel. http:\/\/t.co\/FmuB1zYd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/FmuB1zYd",
        "expanded_url" : "http:\/\/bookwi.se\/wool-books-1-3-by-hugh-howey\/",
        "display_url" : "bookwi.se\/wool-books-1-3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "300970105641263105",
    "text" : "Book Review: Wool by Hugh Howey (Review of Books 1-3) - Creative post-apocalyptic independent novel. http:\/\/t.co\/FmuB1zYd",
    "id" : 300970105641263105,
    "created_at" : "2013-02-11 14:10:39 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 300975652092387330,
  "created_at" : "2013-02-11 14:32:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Cat",
      "screen_name" : "HenryCatTwo",
      "indices" : [ 0, 12 ],
      "id_str" : "366576169",
      "id" : 366576169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300959422694424576",
  "geo" : { },
  "id_str" : "300962506837471232",
  "in_reply_to_user_id" : 366576169,
  "text" : "@HenryCatTwo &lt;3 you Henry",
  "id" : 300962506837471232,
  "in_reply_to_status_id" : 300959422694424576,
  "created_at" : "2013-02-11 13:40:27 +0000",
  "in_reply_to_screen_name" : "HenryCatTwo",
  "in_reply_to_user_id_str" : "366576169",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/2PKiKkkf",
      "expanded_url" : "http:\/\/amzn.to\/QCYqwX",
      "display_url" : "amzn.to\/QCYqwX"
    } ]
  },
  "geo" : { },
  "id_str" : "300720987643707392",
  "text" : "finished Sara's Game by Ernie Lindsey http:\/\/t.co\/2PKiKkkf",
  "id" : 300720987643707392,
  "created_at" : "2013-02-10 21:40:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/ghbGFRqV",
      "expanded_url" : "http:\/\/zenpencils.com\/comic\/102-timothy-leary-you-arent-like-them\/#.URfYnWIpcTs.twitter",
      "display_url" : "zenpencils.com\/comic\/102-timo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300658250519568384",
  "text" : "102. TIMOTHY LEARY: You aren\u2019t like them  http:\/\/t.co\/ghbGFRqV",
  "id" : 300658250519568384,
  "created_at" : "2013-02-10 17:31:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MrOzAtheist",
      "screen_name" : "MrOzAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "296129356",
      "id" : 296129356
    }, {
      "name" : "Emma White",
      "screen_name" : "TheRealSupermum",
      "indices" : [ 13, 29 ],
      "id_str" : "254781401",
      "id" : 254781401
    }, {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 30, 45 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300378313942261760",
  "geo" : { },
  "id_str" : "300379089884303361",
  "in_reply_to_user_id" : 296129356,
  "text" : "@MrOzAtheist @TheRealSupermum @TheAtheistFool LOLOLOL :D",
  "id" : 300379089884303361,
  "in_reply_to_status_id" : 300378313942261760,
  "created_at" : "2013-02-09 23:02:10 +0000",
  "in_reply_to_screen_name" : "MrOzAtheist",
  "in_reply_to_user_id_str" : "296129356",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300314946481315840",
  "text" : "@IronAtheist i dunno.. most atheists i know are filled w marshmallow fluff.. lol (soft &amp; sweet on inside, not big bad bullies)",
  "id" : 300314946481315840,
  "created_at" : "2013-02-09 18:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 43, 56 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300308400221331456",
  "text" : "I just bought: 'Suffer' by E.E. Borton via @amazonkindle - curr. free #thriller",
  "id" : 300308400221331456,
  "created_at" : "2013-02-09 18:21:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 52, 64 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vermont",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "photo",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/ZqngbaF4",
      "expanded_url" : "http:\/\/bit.ly\/11vAje4",
      "display_url" : "bit.ly\/11vAje4"
    } ]
  },
  "in_reply_to_status_id_str" : "300276877283704832",
  "geo" : { },
  "id_str" : "300277724189184002",
  "in_reply_to_user_id" : 28461779,
  "text" : "perfect view for my cabin when i move there! : ) RT @MartinBelan Ricker Pond, #Vermont http:\/\/t.co\/ZqngbaF4 #photo",
  "id" : 300277724189184002,
  "in_reply_to_status_id" : 300276877283704832,
  "created_at" : "2013-02-09 16:19:22 +0000",
  "in_reply_to_screen_name" : "MartinBelan",
  "in_reply_to_user_id_str" : "28461779",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Williamson",
      "screen_name" : "vajramatt",
      "indices" : [ 3, 13 ],
      "id_str" : "14117768",
      "id" : 14117768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300054118020571138",
  "text" : "RT @vajramatt: One day it will make sense.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299708980010291200",
    "text" : "One day it will make sense.",
    "id" : 299708980010291200,
    "created_at" : "2013-02-08 02:39:23 +0000",
    "user" : {
      "name" : "Matthew Williamson",
      "screen_name" : "vajramatt",
      "protected" : false,
      "id_str" : "14117768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785846592314146816\/sJHQsbxP_normal.jpg",
      "id" : 14117768,
      "verified" : false
    }
  },
  "id" : 300054118020571138,
  "created_at" : "2013-02-09 01:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 52, 65 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300038747930632192",
  "text" : "I just bought: 'Silent Counsel' by Ken Isaacson via @amazonkindle - curr. free #thriller",
  "id" : 300038747930632192,
  "created_at" : "2013-02-09 00:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299995491754704897",
  "geo" : { },
  "id_str" : "299998234435260416",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny ohhh.. is that why i fly so high? lol",
  "id" : 299998234435260416,
  "in_reply_to_status_id" : 299995491754704897,
  "created_at" : "2013-02-08 21:48:47 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299991514661130241",
  "geo" : { },
  "id_str" : "299991812821614594",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny what do i have?",
  "id" : 299991812821614594,
  "in_reply_to_status_id" : 299991514661130241,
  "created_at" : "2013-02-08 21:23:16 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299974627738927104",
  "text" : "RT @adamrshields: I have started reading 1Q84.  It is nearly 1000 pages.  Anyone have a review they want to post on Bookwi.se until I fi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299974452387643393",
    "text" : "I have started reading 1Q84.  It is nearly 1000 pages.  Anyone have a review they want to post on Bookwi.se until I finish this?  :)",
    "id" : 299974452387643393,
    "created_at" : "2013-02-08 20:14:17 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 299974627738927104,
  "created_at" : "2013-02-08 20:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 45, 58 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299963865393922048",
  "text" : "I just bought: 'Singularity' by Joe Hart via @amazonkindle - curr. free #thriller",
  "id" : 299963865393922048,
  "created_at" : "2013-02-08 19:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Attaining Income",
      "screen_name" : "hyperionvoice",
      "indices" : [ 3, 17 ],
      "id_str" : "2186397289",
      "id" : 2186397289
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "contest",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299918762658914305",
  "text" : "RT @HyperionVoice: Snowing by u? Tweet us a pic of ur pet in the snow &amp; enter this #contest 2 win this must-read book http:\/\/t.co\/yD ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "contest",
        "indices" : [ 68, 76 ]
      }, {
        "text" : "PetPix",
        "indices" : [ 124, 131 ]
      }, {
        "text" : "giveaway",
        "indices" : [ 132, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/yDa6uTWC",
        "expanded_url" : "http:\/\/bit.ly\/WpKqwX",
        "display_url" : "bit.ly\/WpKqwX"
      } ]
    },
    "geo" : { },
    "id_str" : "299910717035925504",
    "text" : "Snowing by u? Tweet us a pic of ur pet in the snow &amp; enter this #contest 2 win this must-read book http:\/\/t.co\/yDa6uTWC #PetPix #giveaway RT",
    "id" : 299910717035925504,
    "created_at" : "2013-02-08 16:01:01 +0000",
    "user" : {
      "name" : "Hachette Books",
      "screen_name" : "HachetteBooks",
      "protected" : false,
      "id_str" : "19301765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744958368763252737\/XbAW0PTz_normal.jpg",
      "id" : 19301765,
      "verified" : false
    }
  },
  "id" : 299918762658914305,
  "created_at" : "2013-02-08 16:32:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299918340464472064",
  "text" : "RT @adamrshields: Last Day - $50 off Kindle Fire HD 8.9 - The Wifi only version is $269 &amp; LTE version is $449 with coupon code FIREL ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/aZeA1OKa",
        "expanded_url" : "http:\/\/bookwi.se\/50-off-kindle-fire-hd-8-9\/",
        "display_url" : "bookwi.se\/50-off-kindle-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299911581238718464",
    "text" : "Last Day - $50 off Kindle Fire HD 8.9 - The Wifi only version is $269 &amp; LTE version is $449 with coupon code FIRELOVE http:\/\/t.co\/aZeA1OKa",
    "id" : 299911581238718464,
    "created_at" : "2013-02-08 16:04:27 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 299918340464472064,
  "created_at" : "2013-02-08 16:31:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/7QFIygQn",
      "expanded_url" : "http:\/\/ow.ly\/hxHzN",
      "display_url" : "ow.ly\/hxHzN"
    } ]
  },
  "geo" : { },
  "id_str" : "299917423627362304",
  "text" : "RT @DuttonBooks: Continuing our recent animal-themed tweets....here's a bookcase that also serves as a \"catcase\": http:\/\/t.co\/7QFIygQn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/7QFIygQn",
        "expanded_url" : "http:\/\/ow.ly\/hxHzN",
        "display_url" : "ow.ly\/hxHzN"
      } ]
    },
    "geo" : { },
    "id_str" : "299915520482885632",
    "text" : "Continuing our recent animal-themed tweets....here's a bookcase that also serves as a \"catcase\": http:\/\/t.co\/7QFIygQn",
    "id" : 299915520482885632,
    "created_at" : "2013-02-08 16:20:06 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 299917423627362304,
  "created_at" : "2013-02-08 16:27:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Stan McCullars",
      "screen_name" : "StanMcCullars",
      "indices" : [ 13, 27 ],
      "id_str" : "128109208",
      "id" : 128109208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299916513559842816",
  "geo" : { },
  "id_str" : "299917096593268736",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny @StanMcCullars how about it's nobody's business but for those involved...",
  "id" : 299917096593268736,
  "in_reply_to_status_id" : 299916513559842816,
  "created_at" : "2013-02-08 16:26:22 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Reisz",
      "screen_name" : "tiffanyreisz",
      "indices" : [ 3, 16 ],
      "id_str" : "16593205",
      "id" : 16593205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299695788945182720",
  "text" : "RT @tiffanyreisz: Andrew's been watching too much reality tv. He said dinner was good enough that I 'earned immunity' &amp; get to stay  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299690244020789248",
    "text" : "Andrew's been watching too much reality tv. He said dinner was good enough that I 'earned immunity' &amp; get to stay in the house another week.",
    "id" : 299690244020789248,
    "created_at" : "2013-02-08 01:24:56 +0000",
    "user" : {
      "name" : "Tiffany Reisz",
      "screen_name" : "tiffanyreisz",
      "protected" : false,
      "id_str" : "16593205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769629052437078016\/BwmKp5WM_normal.jpg",
      "id" : 16593205,
      "verified" : true
    }
  },
  "id" : 299695788945182720,
  "created_at" : "2013-02-08 01:46:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299690207257698304",
  "text" : "prepared Valentine's Day card to send out to my sister.",
  "id" : 299690207257698304,
  "created_at" : "2013-02-08 01:24:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "indices" : [ 3, 16 ],
      "id_str" : "78155553",
      "id" : 78155553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299689599675023363",
  "text" : "RT @angelmagicjp: A tiny act of love can make the biggest difference in somebody's life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299684056621277185",
    "text" : "A tiny act of love can make the biggest difference in somebody's life.",
    "id" : 299684056621277185,
    "created_at" : "2013-02-08 01:00:21 +0000",
    "user" : {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "protected" : false,
      "id_str" : "78155553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1497479357\/Hand_Heart_Sun_2_normal.jpg",
      "id" : 78155553,
      "verified" : false
    }
  },
  "id" : 299689599675023363,
  "created_at" : "2013-02-08 01:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luola",
      "screen_name" : "luola21",
      "indices" : [ 0, 8 ],
      "id_str" : "1005737413",
      "id" : 1005737413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299684121528131584",
  "geo" : { },
  "id_str" : "299689536278122498",
  "in_reply_to_user_id" : 1005737413,
  "text" : "@luola21 twitter has some weird ratio formula. no one seems to know..lol",
  "id" : 299689536278122498,
  "in_reply_to_status_id" : 299684121528131584,
  "created_at" : "2013-02-08 01:22:08 +0000",
  "in_reply_to_screen_name" : "luola21",
  "in_reply_to_user_id_str" : "1005737413",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ladybugs",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "smile",
      "indices" : [ 41, 47 ]
    }, {
      "text" : "nature",
      "indices" : [ 77, 84 ]
    }, {
      "text" : "photo",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/wGLqIXM7",
      "expanded_url" : "http:\/\/ow.ly\/hvdMe",
      "display_url" : "ow.ly\/hvdMe"
    } ]
  },
  "geo" : { },
  "id_str" : "299561662829187072",
  "text" : "RT @KerriFar: #Ladybugs ~ always make me #smile :) ~ http:\/\/t.co\/wGLqIXM7  ~ #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ladybugs",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "smile",
        "indices" : [ 27, 33 ]
      }, {
        "text" : "nature",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "photo",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/wGLqIXM7",
        "expanded_url" : "http:\/\/ow.ly\/hvdMe",
        "display_url" : "ow.ly\/hvdMe"
      } ]
    },
    "geo" : { },
    "id_str" : "299559471078838273",
    "text" : "#Ladybugs ~ always make me #smile :) ~ http:\/\/t.co\/wGLqIXM7  ~ #nature #photo",
    "id" : 299559471078838273,
    "created_at" : "2013-02-07 16:45:18 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 299561662829187072,
  "created_at" : "2013-02-07 16:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 68, 81 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299558833766948864",
  "text" : "I just bought: 'Angels in Our Countryside' by Robert John Burke via @amazonkindle - curr. free",
  "id" : 299558833766948864,
  "created_at" : "2013-02-07 16:42:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299557221375807488",
  "text" : "RT @TheDailyHug: Your kindness can heal. Try, very hard, to BE KIND.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299553316315201537",
    "text" : "Your kindness can heal. Try, very hard, to BE KIND.",
    "id" : 299553316315201537,
    "created_at" : "2013-02-07 16:20:50 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 299557221375807488,
  "created_at" : "2013-02-07 16:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299549170048581632",
  "geo" : { },
  "id_str" : "299553389937840129",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields i have kindle copy but havent read yet. looking forward to it, tho.",
  "id" : 299553389937840129,
  "in_reply_to_status_id" : 299549170048581632,
  "created_at" : "2013-02-07 16:21:08 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299553231653191680",
  "text" : "RT @adamrshields: Book Review: Handmaid's Tale by Margaret Atwood - excellent dystopian audiobook narrated by Claire Danes. http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/IM2QwUVd",
        "expanded_url" : "http:\/\/bookwi.se\/the-handmaids-tale-by-margaret-atwood\/",
        "display_url" : "bookwi.se\/the-handmaids-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299549170048581632",
    "text" : "Book Review: Handmaid's Tale by Margaret Atwood - excellent dystopian audiobook narrated by Claire Danes. http:\/\/t.co\/IM2QwUVd",
    "id" : 299549170048581632,
    "created_at" : "2013-02-07 16:04:22 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 299553231653191680,
  "created_at" : "2013-02-07 16:20:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/MvP5oSOg",
      "expanded_url" : "http:\/\/www.booksneeze.com\/join",
      "display_url" : "booksneeze.com\/join"
    } ]
  },
  "geo" : { },
  "id_str" : "299552366913540096",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields you might be interested (or not) http:\/\/t.co\/MvP5oSOg - free books for review, christian",
  "id" : 299552366913540096,
  "created_at" : "2013-02-07 16:17:04 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299533701400891392",
  "text" : "had a school dream last night and it was wonderful! i wasn't afraid and i made a friend! #awesome",
  "id" : 299533701400891392,
  "created_at" : "2013-02-07 15:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299533067712884736",
  "text" : "RT @bend_time: love always wins. deal me in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299525494855057412",
    "text" : "love always wins. deal me in.",
    "id" : 299525494855057412,
    "created_at" : "2013-02-07 14:30:17 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 299533067712884736,
  "created_at" : "2013-02-07 15:00:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "indices" : [ 3, 19 ],
      "id_str" : "362487813",
      "id" : 362487813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thrillerthursday",
      "indices" : [ 21, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299532704788144128",
  "text" : "RT @MysteriousPress: #thrillerthursday giveaway! Reply or RT by 5pm EST to enter to win BEAR IS BROKEN, the phenomenal debut by Lachlan  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thrillerthursday",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299527976561823744",
    "text" : "#thrillerthursday giveaway! Reply or RT by 5pm EST to enter to win BEAR IS BROKEN, the phenomenal debut by Lachlan Smith!",
    "id" : 299527976561823744,
    "created_at" : "2013-02-07 14:40:09 +0000",
    "user" : {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "protected" : false,
      "id_str" : "362487813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1514323844\/mysterious_normal.jpg",
      "id" : 362487813,
      "verified" : false
    }
  },
  "id" : 299532704788144128,
  "created_at" : "2013-02-07 14:58:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/1OlrIoYc",
      "expanded_url" : "http:\/\/amzn.to\/eeijj1",
      "display_url" : "amzn.to\/eeijj1"
    } ]
  },
  "geo" : { },
  "id_str" : "299359420708683776",
  "text" : "finished Jerome and the Seraph (Quantum Cat) by Robina Williams http:\/\/t.co\/1OlrIoYc",
  "id" : 299359420708683776,
  "created_at" : "2013-02-07 03:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 103, 116 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299319542352580608",
  "text" : "I just bought: 'Death By A HoneyBee (Josiah Reynolds Mystery 1) (A Josiah Reynolds Mystery)' by... via @amazonkindle - curr. free",
  "id" : 299319542352580608,
  "created_at" : "2013-02-07 00:51:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TGFBook",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299312178756980736",
  "text" : "RT @alanhdawe: A Hell of eternal conscious torment and torture, with no hope of escape or redemption, is illogical and untenable. #TGFBook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299308780657721344",
    "text" : "A Hell of eternal conscious torment and torture, with no hope of escape or redemption, is illogical and untenable. #TGFBook",
    "id" : 299308780657721344,
    "created_at" : "2013-02-07 00:09:08 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 299312178756980736,
  "created_at" : "2013-02-07 00:22:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u044E\u0448\u0430 \u0410\u043D\u0433\u0435\u043B",
      "screen_name" : "Tomthunkit",
      "indices" : [ 3, 14 ],
      "id_str" : "2371889310",
      "id" : 2371889310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/jxOVytaB",
      "expanded_url" : "http:\/\/ow.ly\/gxDf1",
      "display_url" : "ow.ly\/gxDf1"
    }, {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/w3kRuZM5",
      "expanded_url" : "http:\/\/ow.ly\/gxDf3",
      "display_url" : "ow.ly\/gxDf3"
    } ]
  },
  "geo" : { },
  "id_str" : "299297155892523008",
  "text" : "RT @Tomthunkit: War is 60% of our budget. If the GOP are serious about cuts; cut defense. http:\/\/t.co\/jxOVytaB  CHART: http:\/\/t.co\/w3kRuZM5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/jxOVytaB",
        "expanded_url" : "http:\/\/ow.ly\/gxDf1",
        "display_url" : "ow.ly\/gxDf1"
      }, {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/w3kRuZM5",
        "expanded_url" : "http:\/\/ow.ly\/gxDf3",
        "display_url" : "ow.ly\/gxDf3"
      } ]
    },
    "geo" : { },
    "id_str" : "299216385064714240",
    "text" : "War is 60% of our budget. If the GOP are serious about cuts; cut defense. http:\/\/t.co\/jxOVytaB  CHART: http:\/\/t.co\/w3kRuZM5",
    "id" : 299216385064714240,
    "created_at" : "2013-02-06 18:02:00 +0000",
    "user" : {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "protected" : false,
      "id_str" : "289118612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720292487898783746\/B736BdgO_normal.jpg",
      "id" : 289118612,
      "verified" : false
    }
  },
  "id" : 299297155892523008,
  "created_at" : "2013-02-06 23:22:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Phelps-Roper",
      "screen_name" : "meganphelps",
      "indices" : [ 0, 12 ],
      "id_str" : "15920243",
      "id" : 15920243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299189908810117121",
  "geo" : { },
  "id_str" : "299293381513846788",
  "in_reply_to_user_id" : 15920243,
  "text" : "@meganphelps takes great courage to walk away from all you've known. an inspiration to the world.",
  "id" : 299293381513846788,
  "in_reply_to_status_id" : 299189908810117121,
  "created_at" : "2013-02-06 23:07:57 +0000",
  "in_reply_to_screen_name" : "meganphelps",
  "in_reply_to_user_id_str" : "15920243",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 19, 31 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 71 ],
      "url" : "https:\/\/t.co\/CH4r3rUd",
      "expanded_url" : "https:\/\/medium.com\/reporters-notebook\/d63ecca43e35",
      "display_url" : "medium.com\/reporters-note\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299291521524580355",
  "text" : "RT @atheistlady76: @ReverendSue did you see this? https:\/\/t.co\/CH4r3rUd What hope it gives me. I never thought to see this day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reverend Sue",
        "screen_name" : "ReverendSue",
        "indices" : [ 0, 12 ],
        "id_str" : "40585382",
        "id" : 40585382
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 52 ],
        "url" : "https:\/\/t.co\/CH4r3rUd",
        "expanded_url" : "https:\/\/medium.com\/reporters-notebook\/d63ecca43e35",
        "display_url" : "medium.com\/reporters-note\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299274650515546112",
    "in_reply_to_user_id" : 40585382,
    "text" : "@ReverendSue did you see this? https:\/\/t.co\/CH4r3rUd What hope it gives me. I never thought to see this day.",
    "id" : 299274650515546112,
    "created_at" : "2013-02-06 21:53:31 +0000",
    "in_reply_to_screen_name" : "ReverendSue",
    "in_reply_to_user_id_str" : "40585382",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 299291521524580355,
  "created_at" : "2013-02-06 23:00:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299257892538814465",
  "text" : "RT @MWM4444: Believe nothing, no matter where you read it, not even if I have said it, unless it agrees w\/your own reason &amp; your own ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299254904143355906",
    "text" : "Believe nothing, no matter where you read it, not even if I have said it, unless it agrees w\/your own reason &amp; your own common sense.~Buddha",
    "id" : 299254904143355906,
    "created_at" : "2013-02-06 20:35:03 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 299257892538814465,
  "created_at" : "2013-02-06 20:46:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Irvine",
      "screen_name" : "IanCPIrvine4",
      "indices" : [ 3, 16 ],
      "id_str" : "1148221298",
      "id" : 1148221298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Organ",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "Cellular",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "thriller",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "mystery",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299254907603677185",
  "text" : "RT @IanCPIrvine4: #Organ donation &amp; #Cellular Memory Phenomena-Read 1st #thriller to explore #mystery 'Haunted from Within' http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.DynamicTweets.com\" rel=\"nofollow\"\u003EDynamic Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Organ",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "Cellular",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "thriller",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "mystery",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "goodread",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/n6P2Bgg7",
        "expanded_url" : "http:\/\/bit.ly\/11EKuaF",
        "display_url" : "bit.ly\/11EKuaF"
      } ]
    },
    "geo" : { },
    "id_str" : "299251388456787968",
    "text" : "#Organ donation &amp; #Cellular Memory Phenomena-Read 1st #thriller to explore #mystery 'Haunted from Within' http:\/\/t.co\/n6P2Bgg7 #goodread",
    "id" : 299251388456787968,
    "created_at" : "2013-02-06 20:21:05 +0000",
    "user" : {
      "name" : "Ian Irvine",
      "screen_name" : "IanCPIrvine4",
      "protected" : false,
      "id_str" : "1148221298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207089158\/b5ec0a8896e4383e8dad567cf4d32a25_normal.jpeg",
      "id" : 1148221298,
      "verified" : false
    }
  },
  "id" : 299254907603677185,
  "created_at" : "2013-02-06 20:35:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299254629248675840",
  "text" : "RT @_CabinGirl: Update from WRC: 1st Lead Poisoned Swan of the Season Released!: Monday was a great day. Why, you ask? Be... http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WRCMN",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/eSltsXDK",
        "expanded_url" : "http:\/\/bit.ly\/11WWMeK",
        "display_url" : "bit.ly\/11WWMeK"
      } ]
    },
    "geo" : { },
    "id_str" : "299249665600258048",
    "text" : "Update from WRC: 1st Lead Poisoned Swan of the Season Released!: Monday was a great day. Why, you ask? Be... http:\/\/t.co\/eSltsXDK #WRCMN",
    "id" : 299249665600258048,
    "created_at" : "2013-02-06 20:14:14 +0000",
    "user" : {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "protected" : false,
      "id_str" : "116807098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713963701\/me_and_fawnsm_normal.jpg",
      "id" : 116807098,
      "verified" : false
    }
  },
  "id" : 299254629248675840,
  "created_at" : "2013-02-06 20:33:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299247395882012674",
  "text" : "sinus headache.",
  "id" : 299247395882012674,
  "created_at" : "2013-02-06 20:05:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    }, {
      "name" : "Christianbook.com",
      "screen_name" : "Christianbook",
      "indices" : [ 21, 35 ],
      "id_str" : "20616053",
      "id" : 20616053
    }, {
      "name" : "Abingdon Press",
      "screen_name" : "AbingdonPress",
      "indices" : [ 79, 93 ],
      "id_str" : "43784518",
      "id" : 43784518
    }, {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 122, 135 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiction",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/z61nt68d",
      "expanded_url" : "http:\/\/ht.ly\/cVFV4",
      "display_url" : "ht.ly\/cVFV4"
    } ]
  },
  "geo" : { },
  "id_str" : "299245196288356353",
  "text" : "RT @RichardMabry: RT @Christianbook: New Free eBook http:\/\/t.co\/z61nt68d from  @AbingdonPress #fiction - Lethal Remedy by @RichardMabry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christianbook.com",
        "screen_name" : "Christianbook",
        "indices" : [ 3, 17 ],
        "id_str" : "20616053",
        "id" : 20616053
      }, {
        "name" : "Abingdon Press",
        "screen_name" : "AbingdonPress",
        "indices" : [ 61, 75 ],
        "id_str" : "43784518",
        "id" : 43784518
      }, {
        "name" : "Richard Mabry",
        "screen_name" : "RichardMabry",
        "indices" : [ 104, 117 ],
        "id_str" : "17355721",
        "id" : 17355721
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fiction",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/z61nt68d",
        "expanded_url" : "http:\/\/ht.ly\/cVFV4",
        "display_url" : "ht.ly\/cVFV4"
      } ]
    },
    "geo" : { },
    "id_str" : "299236003162492928",
    "text" : "RT @Christianbook: New Free eBook http:\/\/t.co\/z61nt68d from  @AbingdonPress #fiction - Lethal Remedy by @RichardMabry",
    "id" : 299236003162492928,
    "created_at" : "2013-02-06 19:19:57 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 299245196288356353,
  "created_at" : "2013-02-06 19:56:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299214802809679872",
  "text" : "i hate child-locks!",
  "id" : 299214802809679872,
  "created_at" : "2013-02-06 17:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299190799063724032",
  "text" : "and the world is NOT frickin' black or white, ppl! infinite shades of gray. who are you to make final judgement?",
  "id" : 299190799063724032,
  "created_at" : "2013-02-06 16:20:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299189394441654274",
  "text" : "the world changes... accept that fact. these posts about \"when i was a kid, we...\" really annoy me.",
  "id" : 299189394441654274,
  "created_at" : "2013-02-06 16:14:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress.com",
      "screen_name" : "eMysteries",
      "indices" : [ 3, 14 ],
      "id_str" : "346852354",
      "id" : 346852354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299188435988647937",
  "text" : "RT @eMysteries: We've just released a dozen Ellery Queen novels as eBooks, plus a video profile about the cousins behind the pen name! h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/yl8B1Cib",
        "expanded_url" : "http:\/\/mysteriouspress.com\/authors\/ellery-queen\/default.asp",
        "display_url" : "mysteriouspress.com\/authors\/ellery\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299185477821542400",
    "text" : "We've just released a dozen Ellery Queen novels as eBooks, plus a video profile about the cousins behind the pen name! http:\/\/t.co\/yl8B1Cib",
    "id" : 299185477821542400,
    "created_at" : "2013-02-06 15:59:11 +0000",
    "user" : {
      "name" : "MysteriousPress.com",
      "screen_name" : "eMysteries",
      "protected" : false,
      "id_str" : "346852354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533239878\/MYsteriousPress_copy123_twitter_normal.jpg",
      "id" : 346852354,
      "verified" : false
    }
  },
  "id" : 299188435988647937,
  "created_at" : "2013-02-06 16:10:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299172870586785792",
  "text" : "looked at washers on monday. 95% are HE, digital. we werent looking for fancy but wanted good size. only smaller machines were old fashion.",
  "id" : 299172870586785792,
  "created_at" : "2013-02-06 15:09:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299172296864714753",
  "text" : "so we have a new washer. we have to learn how to use it..lol. its a HE top loader with digital panel. HE=HighEfficiency",
  "id" : 299172296864714753,
  "created_at" : "2013-02-06 15:06:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299171345521074177",
  "text" : "RT @JeffreyGuterman: USPS to stop delivering letters, first-class mail on Saturdays starting Aug 1, packages will continue to be deliver ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/nPK4fPCF",
        "expanded_url" : "http:\/\/cnnmon.ie\/X3qcsg",
        "display_url" : "cnnmon.ie\/X3qcsg"
      } ]
    },
    "geo" : { },
    "id_str" : "299167082728271872",
    "text" : "USPS to stop delivering letters, first-class mail on Saturdays starting Aug 1, packages will continue to be delivered: http:\/\/t.co\/nPK4fPCF",
    "id" : 299167082728271872,
    "created_at" : "2013-02-06 14:46:05 +0000",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 299171345521074177,
  "created_at" : "2013-02-06 15:03:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298931662694264832",
  "geo" : { },
  "id_str" : "298944258445029376",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous same mistakes.. ya, im familiar w that...",
  "id" : 298944258445029376,
  "in_reply_to_status_id" : 298931662694264832,
  "created_at" : "2013-02-06 00:00:39 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TreeHugger.com",
      "screen_name" : "TreeHugger",
      "indices" : [ 113, 124 ],
      "id_str" : "14634720",
      "id" : 14634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/QKc30J7s",
      "expanded_url" : "http:\/\/www.treehugger.com\/natural-sciences\/family-cleans-house-and-finds-pet-tortoise-went-missing-30-years-earlier.html",
      "display_url" : "treehugger.com\/natural-scienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298942962346364930",
  "text" : "Wow... &gt;&gt; Family Cleans House, Finds Pet Tortoise Missing Since 1982 : TreeHugger http:\/\/t.co\/QKc30J7s via @TreeHugger",
  "id" : 298942962346364930,
  "created_at" : "2013-02-05 23:55:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298925033340928000",
  "geo" : { },
  "id_str" : "298925251360866306",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous im sorry...",
  "id" : 298925251360866306,
  "in_reply_to_status_id" : 298925033340928000,
  "created_at" : "2013-02-05 22:45:08 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298921829312106496",
  "geo" : { },
  "id_str" : "298924551218266112",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous lol.. ((hugs))",
  "id" : 298924551218266112,
  "in_reply_to_status_id" : 298921829312106496,
  "created_at" : "2013-02-05 22:42:21 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marx Matterz",
      "screen_name" : "MarxMatterz",
      "indices" : [ 3, 15 ],
      "id_str" : "166404047",
      "id" : 166404047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298912901366956033",
  "text" : "RT @MarxMatterz: Everyone Is Living In Their Own World, Perceptions Will Be Different, Lifestyles Will Be Different, People Will Be Diff ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298911591771017216",
    "text" : "Everyone Is Living In Their Own World, Perceptions Will Be Different, Lifestyles Will Be Different, People Will Be Different. Accept.",
    "id" : 298911591771017216,
    "created_at" : "2013-02-05 21:50:51 +0000",
    "user" : {
      "name" : "Marx Matterz",
      "screen_name" : "MarxMatterz",
      "protected" : false,
      "id_str" : "166404047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800841068367351808\/LFrV-P28_normal.jpg",
      "id" : 166404047,
      "verified" : false
    }
  },
  "id" : 298912901366956033,
  "created_at" : "2013-02-05 21:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon & Schuster",
      "screen_name" : "simonschuster",
      "indices" : [ 3, 17 ],
      "id_str" : "24886025",
      "id" : 24886025
    }, {
      "name" : "Andrew Pyper",
      "screen_name" : "andrewpyper",
      "indices" : [ 60, 72 ],
      "id_str" : "216356419",
      "id" : 216356419
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/SLVaVnK5",
      "expanded_url" : "http:\/\/bit.ly\/VzHaLz",
      "display_url" : "bit.ly\/VzHaLz"
    } ]
  },
  "geo" : { },
  "id_str" : "298911197095395328",
  "text" : "RT @simonschuster: RT for a chance to #win 1 of 5 copies of @andrewpyper's THE DEMONOLOGIST. More info: http:\/\/t.co\/SLVaVnK5 (rules http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Pyper",
        "screen_name" : "andrewpyper",
        "indices" : [ 41, 53 ],
        "id_str" : "216356419",
        "id" : 216356419
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 19, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/SLVaVnK5",
        "expanded_url" : "http:\/\/bit.ly\/VzHaLz",
        "display_url" : "bit.ly\/VzHaLz"
      }, {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/HmputXpa",
        "expanded_url" : "http:\/\/ow.ly\/hpbQE",
        "display_url" : "ow.ly\/hpbQE"
      } ]
    },
    "geo" : { },
    "id_str" : "298902681685221377",
    "text" : "RT for a chance to #win 1 of 5 copies of @andrewpyper's THE DEMONOLOGIST. More info: http:\/\/t.co\/SLVaVnK5 (rules http:\/\/t.co\/HmputXpa)",
    "id" : 298902681685221377,
    "created_at" : "2013-02-05 21:15:27 +0000",
    "user" : {
      "name" : "Simon & Schuster",
      "screen_name" : "simonschuster",
      "protected" : false,
      "id_str" : "24886025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570600737525096448\/Hl2OHpQQ_normal.png",
      "id" : 24886025,
      "verified" : true
    }
  },
  "id" : 298911197095395328,
  "created_at" : "2013-02-05 21:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298900898195836929",
  "geo" : { },
  "id_str" : "298903735445356544",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ive always been very near-sighted. past few(?) years have to take glasses off to see small print.. ugh.",
  "id" : 298903735445356544,
  "in_reply_to_status_id" : 298900898195836929,
  "created_at" : "2013-02-05 21:19:38 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298632212163727360",
  "geo" : { },
  "id_str" : "298893878851956736",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields it made me think about status quo, freedom, truth, group politics...",
  "id" : 298893878851956736,
  "in_reply_to_status_id" : 298632212163727360,
  "created_at" : "2013-02-05 20:40:28 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298890090296537088",
  "text" : "RT @MWM4444: I have a friend who is 94 years old. Congress is contemplating cutting my friend's food budget by 44%, so as to cut the def ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298886435891732480",
    "text" : "I have a friend who is 94 years old. Congress is contemplating cutting my friend's food budget by 44%, so as to cut the deficit by 0.00044%.",
    "id" : 298886435891732480,
    "created_at" : "2013-02-05 20:10:54 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 298890090296537088,
  "created_at" : "2013-02-05 20:25:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/TGfGVrbX",
      "expanded_url" : "http:\/\/www.curate.us\/q\/WyWF",
      "display_url" : "curate.us\/q\/WyWF"
    } ]
  },
  "geo" : { },
  "id_str" : "298889356352053250",
  "text" : "Pink handguns and Hello Kitty assault rifles have been part of an effort to get firearms in the hands of women and\u2026 http:\/\/t.co\/TGfGVrbX",
  "id" : 298889356352053250,
  "created_at" : "2013-02-05 20:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298874351204323328",
  "geo" : { },
  "id_str" : "298884247375200257",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i have to take glasses off for that..lol",
  "id" : 298884247375200257,
  "in_reply_to_status_id" : 298874351204323328,
  "created_at" : "2013-02-05 20:02:12 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298882236973981696",
  "text" : "MIL made me so proud today! \"I don't see God like that.\" regarding being mean, judgement. Her heart knows the truth. : )",
  "id" : 298882236973981696,
  "created_at" : "2013-02-05 19:54:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weareone",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298881763734863873",
  "text" : "1 Corinthians 3:16 (NASB) Do you not know that you are a temple of God and that the Spirit of God dwells in you? #weareone",
  "id" : 298881763734863873,
  "created_at" : "2013-02-05 19:52:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298792508769595393",
  "geo" : { },
  "id_str" : "298798623758630912",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist awwww...",
  "id" : 298798623758630912,
  "in_reply_to_status_id" : 298792508769595393,
  "created_at" : "2013-02-05 14:21:57 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/AT92vMqE",
      "expanded_url" : "http:\/\/amzn.to\/A5FTwv",
      "display_url" : "amzn.to\/A5FTwv"
    } ]
  },
  "geo" : { },
  "id_str" : "298631646436028416",
  "text" : "finished Wool Omnibus Edition (Wool 1 - 5) by Hugh Howey - excellent! http:\/\/t.co\/AT92vMqE",
  "id" : 298631646436028416,
  "created_at" : "2013-02-05 03:18:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/BC2txPVH",
      "expanded_url" : "http:\/\/i.imgur.com\/thRqAbB.jpg",
      "display_url" : "i.imgur.com\/thRqAbB.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "298603726959169536",
  "text" : "RT @aliceinthewater: I swear to you I'd run up and hug this guy. This shirt is full of win: http:\/\/t.co\/BC2txPVH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/BC2txPVH",
        "expanded_url" : "http:\/\/i.imgur.com\/thRqAbB.jpg",
        "display_url" : "i.imgur.com\/thRqAbB.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "298603437518647296",
    "text" : "I swear to you I'd run up and hug this guy. This shirt is full of win: http:\/\/t.co\/BC2txPVH",
    "id" : 298603437518647296,
    "created_at" : "2013-02-05 01:26:21 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 298603726959169536,
  "created_at" : "2013-02-05 01:27:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Wagner",
      "screen_name" : "OrganicSister",
      "indices" : [ 3, 17 ],
      "id_str" : "16562278",
      "id" : 16562278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298592063707045889",
  "text" : "RT @OrganicSister: Rebel children, I urge you, fight the turgid slick of conformity with which they seek to smother your glory. (Russell ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sendible.com\" rel=\"nofollow\"\u003ESendible\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298588054329888768",
    "text" : "Rebel children, I urge you, fight the turgid slick of conformity with which they seek to smother your glory. (Russell Brand)",
    "id" : 298588054329888768,
    "created_at" : "2013-02-05 00:25:14 +0000",
    "user" : {
      "name" : "Tara Wagner",
      "screen_name" : "OrganicSister",
      "protected" : false,
      "id_str" : "16562278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669344750\/88cb4729aeaec0f33a774dba302f1346_normal.jpeg",
      "id" : 16562278,
      "verified" : false
    }
  },
  "id" : 298592063707045889,
  "created_at" : "2013-02-05 00:41:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298585990744899584",
  "geo" : { },
  "id_str" : "298588673572732928",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits ((highfive))",
  "id" : 298588673572732928,
  "in_reply_to_status_id" : 298585990744899584,
  "created_at" : "2013-02-05 00:27:41 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/9zEhfoBu",
      "expanded_url" : "http:\/\/www.collective-evolution.com\/2013\/02\/04\/jfk-blows-the-whistle-secret-society-speech\/",
      "display_url" : "collective-evolution.com\/2013\/02\/04\/jfk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298565743304388608",
  "text" : "JFK Blows The Whistle: Secret Society Speech http:\/\/t.co\/9zEhfoBu",
  "id" : 298565743304388608,
  "created_at" : "2013-02-04 22:56:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 3, 10 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/RRhZqoKM",
      "expanded_url" : "http:\/\/pops.ci\/XGgR85",
      "display_url" : "pops.ci\/XGgR85"
    } ]
  },
  "geo" : { },
  "id_str" : "298539841560408064",
  "text" : "RT @PopSci: Free super-WiFi for everyone! Crazy idea? The FCC doesn't think so !http:\/\/t.co\/RRhZqoKM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/RRhZqoKM",
        "expanded_url" : "http:\/\/pops.ci\/XGgR85",
        "display_url" : "pops.ci\/XGgR85"
      } ]
    },
    "geo" : { },
    "id_str" : "298534198090817536",
    "text" : "Free super-WiFi for everyone! Crazy idea? The FCC doesn't think so !http:\/\/t.co\/RRhZqoKM",
    "id" : 298534198090817536,
    "created_at" : "2013-02-04 20:51:13 +0000",
    "user" : {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "protected" : false,
      "id_str" : "19722699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793561660833267712\/Y5RPH9Te_normal.jpg",
      "id" : 19722699,
      "verified" : true
    }
  },
  "id" : 298539841560408064,
  "created_at" : "2013-02-04 21:13:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298534212049465345",
  "text" : "RT @DuttonBooks: Read it early! Follow us &amp; RT to enter to #win an advance copy of SIX YEARS by #1 NYTimes-bestselling author @Harla ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harlan Coben",
        "screen_name" : "HarlanCoben",
        "indices" : [ 113, 125 ],
        "id_str" : "18903971",
        "id" : 18903971
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 46, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298521561592381440",
    "text" : "Read it early! Follow us &amp; RT to enter to #win an advance copy of SIX YEARS by #1 NYTimes-bestselling author @HarlanCoben. US only.",
    "id" : 298521561592381440,
    "created_at" : "2013-02-04 20:01:01 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 298534212049465345,
  "created_at" : "2013-02-04 20:51:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298436913512194049",
  "text" : "RT @bend_time: much #gratitude for the ease of my life: washer\/dryer, heat, electricity, hot running water....so many dont have these.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gratitude",
        "indices" : [ 5, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298434968898641922",
    "text" : "much #gratitude for the ease of my life: washer\/dryer, heat, electricity, hot running water....so many dont have these.",
    "id" : 298434968898641922,
    "created_at" : "2013-02-04 14:16:55 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 298436913512194049,
  "created_at" : "2013-02-04 14:24:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/2TVARAB\/status\/298374005319139328\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/mRnbsq2j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCQJk7XCAAAE8BM.jpg",
      "id_str" : "298374005327527936",
      "id" : 298374005327527936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCQJk7XCAAAE8BM.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/mRnbsq2j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298436848492085251",
  "text" : "RT @ShhDragon: Ah yin-yang, you master of subtlety I thank you today for also being a master of clarity:\nhttp:\/\/t.co\/mRnbsq2j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/2TVARAB\/status\/298374005319139328\/photo\/1",
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/mRnbsq2j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCQJk7XCAAAE8BM.jpg",
        "id_str" : "298374005327527936",
        "id" : 298374005327527936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCQJk7XCAAAE8BM.jpg",
        "sizes" : [ {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/mRnbsq2j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298435281143623680",
    "text" : "Ah yin-yang, you master of subtlety I thank you today for also being a master of clarity:\nhttp:\/\/t.co\/mRnbsq2j",
    "id" : 298435281143623680,
    "created_at" : "2013-02-04 14:18:10 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 298436848492085251,
  "created_at" : "2013-02-04 14:24:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298244603562307588",
  "geo" : { },
  "id_str" : "298247384943702018",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray hehe.. yeah, mine, too! ((highfive))",
  "id" : 298247384943702018,
  "in_reply_to_status_id" : 298244603562307588,
  "created_at" : "2013-02-04 01:51:32 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alternative",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "health",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/8PYUPlzs",
      "expanded_url" : "http:\/\/nyti.ms\/11sjg7i",
      "display_url" : "nyti.ms\/11sjg7i"
    } ]
  },
  "geo" : { },
  "id_str" : "298246002882801665",
  "text" : "The Boy With a Thorn in His Joints http:\/\/t.co\/8PYUPlzs #alternative #health",
  "id" : 298246002882801665,
  "created_at" : "2013-02-04 01:46:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 99, 112 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOA",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298117902572335105",
  "text" : "I just bought: 'Unveil The Secret: Make The Law Of Attraction Work For You' by Robert A. Smith via @amazonkindle - curr. free #LOA",
  "id" : 298117902572335105,
  "created_at" : "2013-02-03 17:17:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298115360186585088",
  "text" : "RT @micahjmurray: If we say \"the Bible CLEARLY says\", knowing many Christians have another interpretation, are we elevating our opinion  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Romans14",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298113270219427840",
    "text" : "If we say \"the Bible CLEARLY says\", knowing many Christians have another interpretation, are we elevating our opinion above unity? #Romans14",
    "id" : 298113270219427840,
    "created_at" : "2013-02-03 16:58:36 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 298115360186585088,
  "created_at" : "2013-02-03 17:06:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297898877196042240",
  "text" : "RT @LSFProgram: Focus on what you did accomplish not on what you didn't accomplish",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297894999994011649",
    "text" : "Focus on what you did accomplish not on what you didn't accomplish",
    "id" : 297894999994011649,
    "created_at" : "2013-02-03 02:31:17 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 297898877196042240,
  "created_at" : "2013-02-03 02:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 0, 14 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297886551571042305",
  "text" : "@HEATHENRABBIT LOLOL ; )",
  "id" : 297886551571042305,
  "created_at" : "2013-02-03 01:57:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297755029572579330",
  "text" : "Thank you, Universe! found my library card and my bag.",
  "id" : 297755029572579330,
  "created_at" : "2013-02-02 17:15:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297733913915318272",
  "text" : "RT @adamrshields: The book Bookwi.se reviewed on Thursday, Every Day by David Levithan, is on sale for $4.99 right now for kindle.  http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/m6AZMXZt",
        "expanded_url" : "http:\/\/bookwi.se\/every-day-by-david-levithan\/",
        "display_url" : "bookwi.se\/every-day-by-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297729093863108608",
    "text" : "The book Bookwi.se reviewed on Thursday, Every Day by David Levithan, is on sale for $4.99 right now for kindle.  http:\/\/t.co\/m6AZMXZt",
    "id" : 297729093863108608,
    "created_at" : "2013-02-02 15:32:02 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 297733913915318272,
  "created_at" : "2013-02-02 15:51:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyrics",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297732072393539585",
  "text" : "RT @DarciaHelle: If you're only human, what gives you the right to be nailing me up here on your cross? #Lyrics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lyrics",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297724747884670977",
    "text" : "If you're only human, what gives you the right to be nailing me up here on your cross? #Lyrics",
    "id" : 297724747884670977,
    "created_at" : "2013-02-02 15:14:46 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 297732072393539585,
  "created_at" : "2013-02-02 15:43:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297731906114572289",
  "text" : "@Skeptical_Lady yup... lol",
  "id" : 297731906114572289,
  "created_at" : "2013-02-02 15:43:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ducksofinstagram",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/8JPggxef",
      "expanded_url" : "http:\/\/instagr.am\/p\/VO91NWhH2b\/",
      "display_url" : "instagr.am\/p\/VO91NWhH2b\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297730745353527296",
  "text" : "RT @ducksandclucks: Is Lenora Bea your perfect Valentine? #ducksofinstagram http:\/\/t.co\/8JPggxef",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ducksofinstagram",
        "indices" : [ 38, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/8JPggxef",
        "expanded_url" : "http:\/\/instagr.am\/p\/VO91NWhH2b\/",
        "display_url" : "instagr.am\/p\/VO91NWhH2b\/"
      } ]
    },
    "geo" : { },
    "id_str" : "297730204758065152",
    "text" : "Is Lenora Bea your perfect Valentine? #ducksofinstagram http:\/\/t.co\/8JPggxef",
    "id" : 297730204758065152,
    "created_at" : "2013-02-02 15:36:27 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 297730745353527296,
  "created_at" : "2013-02-02 15:38:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297715572353925121",
  "text" : "RT @TheGodLight: You help no one by climbing into someone's misery, you must pull them out whilst standing on the even ground of mindful ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297708438136451073",
    "text" : "You help no one by climbing into someone's misery, you must pull them out whilst standing on the even ground of mindfulness.",
    "id" : 297708438136451073,
    "created_at" : "2013-02-02 14:09:57 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 297715572353925121,
  "created_at" : "2013-02-02 14:38:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "April Thompson",
      "screen_name" : "oddlysaid",
      "indices" : [ 18, 28 ],
      "id_str" : "18835723",
      "id" : 18835723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/h5NmjdAr",
      "expanded_url" : "http:\/\/ow.ly\/hmdzf",
      "display_url" : "ow.ly\/hmdzf"
    } ]
  },
  "geo" : { },
  "id_str" : "297715055309492224",
  "text" : "RT @CaroleODell: \"@oddlysaid: Oddly blogged: Messy http:\/\/t.co\/h5NmjdAr\" I love this! Right on April. :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "April Thompson",
        "screen_name" : "oddlysaid",
        "indices" : [ 1, 11 ],
        "id_str" : "18835723",
        "id" : 18835723
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/h5NmjdAr",
        "expanded_url" : "http:\/\/ow.ly\/hmdzf",
        "display_url" : "ow.ly\/hmdzf"
      } ]
    },
    "geo" : { },
    "id_str" : "297711172084449282",
    "text" : "\"@oddlysaid: Oddly blogged: Messy http:\/\/t.co\/h5NmjdAr\" I love this! Right on April. :-)",
    "id" : 297711172084449282,
    "created_at" : "2013-02-02 14:20:49 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 297715055309492224,
  "created_at" : "2013-02-02 14:36:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luola",
      "screen_name" : "luola21",
      "indices" : [ 0, 8 ],
      "id_str" : "1005737413",
      "id" : 1005737413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297668026667507712",
  "geo" : { },
  "id_str" : "297714443746426880",
  "in_reply_to_user_id" : 1005737413,
  "text" : "@luola21 beautiful!",
  "id" : 297714443746426880,
  "in_reply_to_status_id" : 297668026667507712,
  "created_at" : "2013-02-02 14:33:49 +0000",
  "in_reply_to_screen_name" : "luola21",
  "in_reply_to_user_id_str" : "1005737413",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Nasty Nanoski",
      "screen_name" : "DarthWeiner75",
      "indices" : [ 80, 94 ],
      "id_str" : "55362005",
      "id" : 55362005
    }, {
      "name" : "Talking Points Memo",
      "screen_name" : "TPM",
      "indices" : [ 96, 100 ],
      "id_str" : "14717197",
      "id" : 14717197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297501841258848256",
  "text" : "RT @ZachsMind: Standing ground doesn't work for me. How about run away laws? RT @DarthWeiner75: @TPM There are already stand your ground ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nasty Nanoski",
        "screen_name" : "DarthWeiner75",
        "indices" : [ 65, 79 ],
        "id_str" : "55362005",
        "id" : 55362005
      }, {
        "name" : "Talking Points Memo",
        "screen_name" : "TPM",
        "indices" : [ 81, 85 ],
        "id_str" : "14717197",
        "id" : 14717197
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297500878439600128",
    "text" : "Standing ground doesn't work for me. How about run away laws? RT @DarthWeiner75: @TPM There are already stand your ground laws on the books.",
    "id" : 297500878439600128,
    "created_at" : "2013-02-02 00:25:11 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 297501841258848256,
  "created_at" : "2013-02-02 00:29:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "SlenderFrame71",
      "screen_name" : "SlenderFrame71",
      "indices" : [ 26, 41 ],
      "id_str" : "320742074",
      "id" : 320742074
    }, {
      "name" : "Mark Bridger",
      "screen_name" : "Bridge99",
      "indices" : [ 74, 83 ],
      "id_str" : "20454211",
      "id" : 20454211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Photo",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "500px",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/gPGtOEob",
      "expanded_url" : "http:\/\/500px.com\/photo\/24752147",
      "display_url" : "500px.com\/photo\/24752147"
    } ]
  },
  "geo" : { },
  "id_str" : "297500430399840256",
  "text" : "RT @KerriFar: Amazing! RT @slenderframe71: #Photo \"warm\" by Mark Bridger (@Bridge99) #500px http:\/\/t.co\/gPGtOEob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SlenderFrame71",
        "screen_name" : "SlenderFrame71",
        "indices" : [ 12, 27 ],
        "id_str" : "320742074",
        "id" : 320742074
      }, {
        "name" : "Mark Bridger",
        "screen_name" : "Bridge99",
        "indices" : [ 60, 69 ],
        "id_str" : "20454211",
        "id" : 20454211
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Photo",
        "indices" : [ 29, 35 ]
      }, {
        "text" : "500px",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/gPGtOEob",
        "expanded_url" : "http:\/\/500px.com\/photo\/24752147",
        "display_url" : "500px.com\/photo\/24752147"
      } ]
    },
    "geo" : { },
    "id_str" : "297497089594757120",
    "text" : "Amazing! RT @slenderframe71: #Photo \"warm\" by Mark Bridger (@Bridge99) #500px http:\/\/t.co\/gPGtOEob",
    "id" : 297497089594757120,
    "created_at" : "2013-02-02 00:10:08 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 297500430399840256,
  "created_at" : "2013-02-02 00:23:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa623",
      "screen_name" : "Teresa623",
      "indices" : [ 3, 13 ],
      "id_str" : "66849648",
      "id" : 66849648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297499643712004096",
  "text" : "RT @Teresa623: Please walk beside your dog when crossing the street. A car may whip around the corner trying to beat you in the Xwalk an ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297499100658663424",
    "text" : "Please walk beside your dog when crossing the street. A car may whip around the corner trying to beat you in the Xwalk and not see your dog.",
    "id" : 297499100658663424,
    "created_at" : "2013-02-02 00:18:07 +0000",
    "user" : {
      "name" : "Teresa623",
      "screen_name" : "Teresa623",
      "protected" : false,
      "id_str" : "66849648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652330171270234112\/wLm1Jzna_normal.jpg",
      "id" : 66849648,
      "verified" : false
    }
  },
  "id" : 297499643712004096,
  "created_at" : "2013-02-02 00:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297476907165966337",
  "geo" : { },
  "id_str" : "297492473201188865",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool yes, i am...",
  "id" : 297492473201188865,
  "in_reply_to_status_id" : 297476907165966337,
  "created_at" : "2013-02-01 23:51:47 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Macrae",
      "screen_name" : "acidic",
      "indices" : [ 3, 10 ],
      "id_str" : "7704042",
      "id" : 7704042
    }, {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 15, 30 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Ov6urQQN",
      "expanded_url" : "http:\/\/bit.ly\/WkmPxE",
      "display_url" : "bit.ly\/WkmPxE"
    } ]
  },
  "geo" : { },
  "id_str" : "297480120132845568",
  "text" : "RT @acidic: RT @stevesilberman: Japanese janitor spends 7 yrs drawing unbelievably intricate maze. http:\/\/t.co\/Ov6urQQN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Silberman",
        "screen_name" : "stevesilberman",
        "indices" : [ 3, 18 ],
        "id_str" : "18655567",
        "id" : 18655567
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/Ov6urQQN",
        "expanded_url" : "http:\/\/bit.ly\/WkmPxE",
        "display_url" : "bit.ly\/WkmPxE"
      } ]
    },
    "geo" : { },
    "id_str" : "297479619077079040",
    "text" : "RT @stevesilberman: Japanese janitor spends 7 yrs drawing unbelievably intricate maze. http:\/\/t.co\/Ov6urQQN",
    "id" : 297479619077079040,
    "created_at" : "2013-02-01 23:00:42 +0000",
    "user" : {
      "name" : "Andrew Macrae",
      "screen_name" : "acidic",
      "protected" : false,
      "id_str" : "7704042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615737099862413312\/ell1WBrJ_normal.jpg",
      "id" : 7704042,
      "verified" : false
    }
  },
  "id" : 297480120132845568,
  "created_at" : "2013-02-01 23:02:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Libertarian",
      "screen_name" : "jfktruther",
      "indices" : [ 3, 14 ],
      "id_str" : "243179624",
      "id" : 243179624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297478513664094208",
  "text" : "RT @jfktruther: Iceland's President kicks out FBI agents investigating Wikileaks. \"We arrest banksters, not activists - the opposite of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297236262581063680",
    "text" : "Iceland's President kicks out FBI agents investigating Wikileaks. \"We arrest banksters, not activists - the opposite of what America does.\"",
    "id" : 297236262581063680,
    "created_at" : "2013-02-01 06:53:42 +0000",
    "user" : {
      "name" : "A Libertarian",
      "screen_name" : "jfktruther",
      "protected" : false,
      "id_str" : "243179624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491110207871664128\/FAx2Rir6_normal.jpeg",
      "id" : 243179624,
      "verified" : false
    }
  },
  "id" : 297478513664094208,
  "created_at" : "2013-02-01 22:56:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 0, 15 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297469387286396929",
  "geo" : { },
  "id_str" : "297478322277986304",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulianneGarska ouch! (((hugs)))",
  "id" : 297478322277986304,
  "in_reply_to_status_id" : 297469387286396929,
  "created_at" : "2013-02-01 22:55:33 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297477780847865856",
  "text" : "RT @CoyoteSings: If you believe man is the superior species on Earth, you must also accept that man has the responsibility of being shep ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297471872340201473",
    "text" : "If you believe man is the superior species on Earth, you must also accept that man has the responsibility of being shepherds to all life.",
    "id" : 297471872340201473,
    "created_at" : "2013-02-01 22:29:55 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 297477780847865856,
  "created_at" : "2013-02-01 22:53:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297477495878451202",
  "text" : "RT @CoyoteSings: Why do we experiment on animals? \"Because they are like us.\" Why is it ok to experiment on animals? \"Because they are * ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297473609939705856",
    "text" : "Why do we experiment on animals? \"Because they are like us.\" Why is it ok to experiment on animals? \"Because they are *not* like us.\" ???",
    "id" : 297473609939705856,
    "created_at" : "2013-02-01 22:36:50 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 297477495878451202,
  "created_at" : "2013-02-01 22:52:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297475314865549313",
  "geo" : { },
  "id_str" : "297477251035975681",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool im just a total mutt. i dont fit anyones criteria. never have, never will i suppose.",
  "id" : 297477251035975681,
  "in_reply_to_status_id" : 297475314865549313,
  "created_at" : "2013-02-01 22:51:18 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Studios",
      "screen_name" : "WordHero",
      "indices" : [ 3, 12 ],
      "id_str" : "349186626",
      "id" : 349186626
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WordHero\/status\/297463384100708352\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/5CVecvH4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCDNXy-CIAASxuW.png",
      "id_str" : "297463384109096960",
      "id" : 297463384109096960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCDNXy-CIAASxuW.png",
      "sizes" : [ {
        "h" : 48,
        "resize" : "crop",
        "w" : 48
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 48
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 48
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 48
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 48
      } ],
      "display_url" : "pic.twitter.com\/5CVecvH4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297465935713935360",
  "text" : "RT @WordHero: Currently working on a new game... icon attached :) http:\/\/t.co\/5CVecvH4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WordHero\/status\/297463384100708352\/photo\/1",
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/5CVecvH4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCDNXy-CIAASxuW.png",
        "id_str" : "297463384109096960",
        "id" : 297463384109096960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCDNXy-CIAASxuW.png",
        "sizes" : [ {
          "h" : 48,
          "resize" : "crop",
          "w" : 48
        }, {
          "h" : 48,
          "resize" : "fit",
          "w" : 48
        }, {
          "h" : 48,
          "resize" : "fit",
          "w" : 48
        }, {
          "h" : 48,
          "resize" : "fit",
          "w" : 48
        }, {
          "h" : 48,
          "resize" : "fit",
          "w" : 48
        } ],
        "display_url" : "pic.twitter.com\/5CVecvH4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297463384100708352",
    "text" : "Currently working on a new game... icon attached :) http:\/\/t.co\/5CVecvH4",
    "id" : 297463384100708352,
    "created_at" : "2013-02-01 21:56:12 +0000",
    "user" : {
      "name" : "Sven Studios",
      "screen_name" : "WordHero",
      "protected" : false,
      "id_str" : "349186626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000775732053\/7ff02f57dc799cb7c1d08f75d0037084_normal.png",
      "id" : 349186626,
      "verified" : false
    }
  },
  "id" : 297465935713935360,
  "created_at" : "2013-02-01 22:06:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297457580991709185",
  "text" : "RT @Squirrely007: I think Adam's version of No Boundaries is perfect, I don't care who knows it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297456827589881856",
    "text" : "I think Adam's version of No Boundaries is perfect, I don't care who knows it!",
    "id" : 297456827589881856,
    "created_at" : "2013-02-01 21:30:08 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 297457580991709185,
  "created_at" : "2013-02-01 21:33:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297452698247233536",
  "geo" : { },
  "id_str" : "297454018748354562",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ohhh.. now i am even sadder... : (",
  "id" : 297454018748354562,
  "in_reply_to_status_id" : 297452698247233536,
  "created_at" : "2013-02-01 21:18:59 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297453502974799873",
  "text" : "CANTANKEROUS",
  "id" : 297453502974799873,
  "created_at" : "2013-02-01 21:16:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297451631723827200",
  "geo" : { },
  "id_str" : "297453375480549376",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool it takes faith just to want to live another day...",
  "id" : 297453375480549376,
  "in_reply_to_status_id" : 297451631723827200,
  "created_at" : "2013-02-01 21:16:25 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297452418990473217",
  "geo" : { },
  "id_str" : "297453050300338176",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool what's \"real\"? real doesnt exist...",
  "id" : 297453050300338176,
  "in_reply_to_status_id" : 297452418990473217,
  "created_at" : "2013-02-01 21:15:08 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297451146853879810",
  "text" : "cannot find my library card OR my old bag...",
  "id" : 297451146853879810,
  "created_at" : "2013-02-01 21:07:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297450959825694720",
  "text" : "feeling murderous right now...",
  "id" : 297450959825694720,
  "created_at" : "2013-02-01 21:06:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 0, 16 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 33, 49 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/shoeofallcosmos\/status\/140965521381277697\/photo\/1",
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/GG6jO5Dg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfTPZRPCQAA-zdF.jpg",
      "id_str" : "140965521385472000",
      "id" : 140965521385472000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfTPZRPCQAA-zdF.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/GG6jO5Dg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297438742644404224",
  "in_reply_to_user_id" : 1137858745,
  "text" : "@JourneyTheHedgi also you'd like @shoeofallcosmos she's got a pikachu onesie! : ) http:\/\/t.co\/GG6jO5Dg",
  "id" : 297438742644404224,
  "created_at" : "2013-02-01 20:18:17 +0000",
  "in_reply_to_screen_name" : "JourneyTheHedgi",
  "in_reply_to_user_id_str" : "1137858745",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297410300112687104",
  "geo" : { },
  "id_str" : "297411131830571008",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles awww... i love crows but we dont have too many and they dont seem to bother the others. but the starlings are aggressive. ugh.",
  "id" : 297411131830571008,
  "in_reply_to_status_id" : 297410300112687104,
  "created_at" : "2013-02-01 18:28:34 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297409661794131969",
  "text" : "we got starlings in our yard. keeping an eye out on feeder so they dont crowd out smaller birds.",
  "id" : 297409661794131969,
  "created_at" : "2013-02-01 18:22:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297409260650889218",
  "text" : "strangely DD wants a class ring. usually she wants nothing to do w her school. funny kid.",
  "id" : 297409260650889218,
  "created_at" : "2013-02-01 18:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297407563744563200",
  "text" : "Repent for thinking thou less than! God will indeed judge you w a boot to the head! then kiss you all over!",
  "id" : 297407563744563200,
  "created_at" : "2013-02-01 18:14:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 2, 15 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WTF",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297377646831087616",
  "geo" : { },
  "id_str" : "297386305724227584",
  "in_reply_to_user_id" : 20987411,
  "text" : ". @SisterSadist even w health insurance, getting care is unaffordable. so no sense getting everyone covered! #WTF",
  "id" : 297386305724227584,
  "in_reply_to_status_id" : 297377646831087616,
  "created_at" : "2013-02-01 16:49:55 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297378576314007552",
  "geo" : { },
  "id_str" : "297378920829947906",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 LOL",
  "id" : 297378920829947906,
  "in_reply_to_status_id" : 297378576314007552,
  "created_at" : "2013-02-01 16:20:34 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297370566497808385",
  "geo" : { },
  "id_str" : "297371749803241472",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous : (",
  "id" : 297371749803241472,
  "in_reply_to_status_id" : 297370566497808385,
  "created_at" : "2013-02-01 15:52:04 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]